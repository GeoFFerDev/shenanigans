-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
require(v4.Modules.CameraShaker)
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "TwirlingStrikesController"
})
function v9.KnitStart(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_6, (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (ref) v_u_7
	local v_u_23 = {
		["Startup"] = function(p10)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v11 = p10:FindFirstChild("HumanoidRootPart")
			if v11 then
				task.wait(0.2)
				v_u_8:PlaySound(v_u_6.Hiromi.Twirl.Start, v11, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p12)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_8:PlaySound(v_u_6.Hiromi.Twirl[math.random(1, 3)], v13, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p14)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_3, (ref) v_u_8, (ref) v_u_6
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = v_u_5.Gojo.Teleport:Clone()
				v16.CFrame = v15.CFrame
				v16.Parent = workspace.Effects
				v_u_2:AddItem(v16, 1.1)
				v16.Floor.Dust:Emit(30)
				local v17 = v_u_5.Gojo.Twofold:Clone()
				v17.CFrame = v15.CFrame * CFrame.new(0, -2, -3) * CFrame.Angles(-0.2617993877991494, 0, 0)
				v17.Transparency = 0.5
				v17.Parent = workspace.Effects
				v17.Swing2.Swing1:Emit(10)
				v_u_3:Create(v17, TweenInfo.new(0.2), {
					["CFrame"] = v17.CFrame + v17.CFrame.UpVector * 3,
					["Size"] = Vector3.new(0, 10, 0)
				}):Play()
				v_u_2:AddItem(v17, 0.4)
				v_u_8:PlaySound(v_u_6.Hiromi.Twirl.Final, v15, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p18)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_8:Flash(p18, Color3.new(1, 1, 1))
				v_u_8:PlaySound(v_u_6.Hiromi.Twirl.Hit, v19, game.SoundService.Effect)
			end
		end,
		["Hit2"] = function(p20)
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_5, (ref) v_u_2
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_8:Flash(p20, Color3.new(1, 1, 1))
				v_u_8:PlaySound(v_u_6.Itadori.CraniumSmash.Hit2, v21, game.SoundService.Effect)
				v_u_8:PlaySound(v_u_6.Hakari.EnergySurge.Hit2, v21, game.SoundService.Effect)
				local v22 = v_u_5.Mahito.CrushingRushdown.DrillImpact:Clone()
				v22.Position = v21.Position
				v22.Parent = workspace.Effects
				v_u_2:AddItem(v22, 1)
				v22.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v22.Wind.Color = v22.Sparks.Color
				v22.Wind2.Color = v22.Sparks.Color
				v22.Sparks:Emit(30)
				v22.Wind:Emit(7)
				v22.Wind2:Emit(7)
			end
		end
	}
	v_u_7.Effects:Connect(function(p24, ...)
		-- upvalues: (copy) v_u_23
		local v25 = v_u_23[p24]
		if v25 then
			v25(...)
		end
	end)
end
function v9.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("TwirlingStrikesService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v9