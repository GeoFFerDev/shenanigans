-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local _ = v_u_5.Utils
local v_u_6 = v_u_5.Sounds
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "NepController"
})
function v9.KnitStart(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_6, (copy) v_u_5, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (ref) v_u_7
	local v_u_29 = {
		["ToggleRadio"] = function(p10, _, _)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			v_u_8:PlaySound(v_u_6.Misc.Nep.Start, p10.Root, game.SoundService.Effect)
			if p10.Root:FindFirstChild("StaticLoop") then
				p10.Root.StaticLoop:Destroy()
			else
				local v11 = v_u_6.Misc.Nep.StaticLoop:Clone()
				v11.SoundGroup = game.SoundService.Effect
				v11.Parent = p10.Root
				v11:Play()
			end
		end,
		["RadioBeep"] = function(p12)
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_5, (ref) v_u_3
			v_u_8:PlaySound(v_u_6.Misc.Nep.Beep, p12.Root, game.SoundService.Effect)
			local v13 = v_u_5.Utils.Itadori.EyeTrails:Clone()
			v13.Eye1:Destroy()
			v13.Trail1:Destroy()
			v13.Trail2:Destroy()
			v13.Eye2.Glow.Enabled = false
			v13.Weld.Part0 = p12.Model.Button
			v13.Eye2.CFrame = CFrame.new()
			v13.Parent = workspace.Effects
			v13.Sparks.Color = ColorSequence.new(Color3.fromRGB(203, 0, 3))
			v13.Eye2.Glow.Color = ColorSequence.new(Color3.fromRGB(203, 0, 3))
			v13.Glow.Color = ColorSequence.new(Color3.fromRGB(203, 0, 3))
			v13.Glow.ZOffset = 0
			v13.Glow:Emit(1)
			v13.Eye2.Glow:Emit(1)
			v_u_3:AddItem(v13, 0.5)
		end,
		["RadioSignal"] = function(p14, p15)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			if p15 and p14.Root:FindFirstChild("Signal") then
				p14.Root.Signal:Destroy()
			else
				v_u_8:PlaySound(v_u_6.Misc.Nep.Signal, p14.Root, game.SoundService.Effect)
			end
		end,
		["RadioBounce"] = function(p_u_16)
			-- upvalues: (ref) v_u_2
			local v_u_17 = p_u_16.Root.Music
			if v_u_17.Playing then
				local v_u_18 = 0
				local v_u_19 = nil
				v_u_19 = v_u_2.Heartbeat:Connect(function(p20)
					-- upvalues: (ref) v_u_18, (copy) v_u_17, (copy) p_u_16, (ref) v_u_19
					v_u_18 = v_u_18 + p20 * 12
					if v_u_17.Playing then
						local v21 = v_u_17.Volume / 2
						if v21 <= 0 then
							p_u_16:ScaleTo(1)
						else
							local v22 = v_u_18
							p_u_16:ScaleTo(1 * (1 + math.sin(v22) * 0.15 * v21))
						end
					else
						p_u_16:ScaleTo(1)
						v_u_19:Disconnect()
						return
					end
				end)
			end
		end,
		["RadioTalk"] = function(p23, p24, p25)
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_4
			if p23.Root:FindFirstChild("Entry") then
				p23.Root.Entry:Destroy()
			end
			local v26 = p25 or 2.5
			v_u_8:PlaySound(v_u_6.Misc.Nep.Talk, p23.Root, game.SoundService.Voice)
			v_u_8:PlaySound(v_u_6.Misc.Nep.TalkStart, p23.Root, game.SoundService.Effect)
			local v_u_27 = p23.Root._Entry:Clone()
			v_u_27.Name = "Entry"
			v_u_27.TextLabel.Text = p24
			v_u_27.Enabled = true
			v_u_27.Parent = p23.Root
			v_u_3:AddItem(v_u_27, v26 + 0.5)
			task.delay(v26, function()
				-- upvalues: (copy) v_u_27, (ref) v_u_4
				if v_u_27.Parent then
					v_u_4:Create(v_u_27.TextLabel, TweenInfo.new(0.5), {
						["BackgroundTransparency"] = 1,
						["TextTransparency"] = 1
					}):Play()
					v_u_4:Create(v_u_27.TextLabel.UIStroke, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
			end)
		end,
		["UngezieferRage"] = function(p28)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			v_u_8:PlaySound(v_u_6.Misc.Nep.Rage, p28.HumanoidRootPart, game.SoundService.Effect)
		end
	}
	v_u_7.Effects:Connect(function(p30, ...)
		-- upvalues: (copy) v_u_29
		local v31 = v_u_29[p30]
		if v31 then
			v31(...)
		end
	end)
end
function v9.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("NepService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v9