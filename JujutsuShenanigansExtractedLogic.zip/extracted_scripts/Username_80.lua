-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("Players")
local v_u_10 = {
	["Autocomplete"] = function(p2)
		-- upvalues: (copy) v_u_1
		local v3 = next
		local v4, v5 = v_u_1:GetPlayers()
		local v6 = {}
		for _, v7 in v3, v4, v5 do
			if v7.Name:lower():find(p2:lower()) then
				local v8 = v7.Name
				table.insert(v6, v8)
			end
		end
		return v6
	end,
	["Parse"] = function(p9)
		return p9
	end
}
return function(p11)
	-- upvalues: (copy) v_u_10
	p11:RegisterType("username", v_u_10)
end