-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {
	["Btn"] = 4,
	["SortOrder"] = 5,
	["Val"] = "Outfit",
	["Desc"] = "Changes your look when awakened",
	["BtnText"] = "Outfits",
	["Gamepass"] = "857428668"
}
local v_u_2 = game.Players.LocalPlayer.PlayerGui:WaitForChild("Menus")
local v_u_3 = v_u_2.Group.Settings
local v_u_4 = game.ReplicatedStorage.Sounds
local v_u_5 = game:GetService("AvatarEditorService")
local v6 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_7 = v6.GetService("JoinService")
local v_u_8 = v6.GetController("FXController")
local function v_u_17()
	-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_2, (copy) v_u_1, (copy) v_u_8, (copy) v_u_4, (copy) v_u_7
	local v9 = v_u_5:GetOutfits(Enum.OutfitSource.Created)
	for _, v10 in v_u_3.Outfits.Outfits:GetChildren() do
		if v10:IsA("ImageButton") then
			v10:Destroy()
		end
	end
	while true do
		for _, v_u_11 in v9:GetCurrentPage() do
			local v_u_12 = v_u_2.Preset.Outfit:Clone()
			v_u_12.Image = "rbxthumb://type=Outfit&id=" .. v_u_11.Id .. "&w=150&h=150"
			local v13 = v_u_11.Id
			local v14 = _G.Settings[v_u_1.Val]
			v_u_12.BackgroundColor3 = v13 == tonumber(v14) and Color3.fromRGB(85, 170, 255) or Color3.new(1, 1, 1)
			v_u_12.Parent = v_u_3.Outfits.Outfits
			v_u_12.MouseButton1Down:Connect(function()
				-- upvalues: (copy) v_u_12, (ref) v_u_3, (ref) v_u_8, (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (copy) v_u_11
				local v15 = v_u_12.BackgroundColor3 == Color3.new(1, 1, 1)
				for _, v16 in v_u_3.Outfits.Outfits:GetChildren() do
					if v16:IsA("ImageButton") then
						v16.BackgroundColor3 = Color3.new(1, 1, 1)
					end
				end
				v_u_8:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
				if v15 == true then
					v_u_12.BackgroundColor3 = Color3.fromRGB(85, 170, 255)
					v_u_7.Setting:Fire(v_u_1.Val, v_u_11.Id)
				else
					v_u_7.Setting:Fire(v_u_1.Val, nil)
				end
			end)
		end
		if v9.IsFinished then
			return
		end
		v9:AdvanceToNextPageAsync()
	end
end
function v_u_1.Callback(_)
	-- upvalues: (copy) v_u_3, (copy) v_u_5
	v_u_3.Outfits.Visible = true
	v_u_3.Settings.Visible = false
	v_u_5:PromptAllowInventoryReadAccess()
end
v_u_3.Outfits.Return.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_3
	v_u_3.Outfits.Visible = false
	v_u_3.Settings.Visible = true
end)
v_u_3:GetPropertyChangedSignal("Visible"):Connect(function()
	-- upvalues: (copy) v_u_3
	if v_u_3.Visible ~= true then
		v_u_3.Outfits.Visible = false
		v_u_3.Settings.Visible = true
	end
end)
v_u_5.PromptAllowInventoryReadAccessCompleted:Connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_17
	if v_u_3.Outfits.Visible ~= false then
		pcall(v_u_17)
	end
end)
return v_u_1