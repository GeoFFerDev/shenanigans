-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 8,
	["Desc"] = "this will be what jjs will look like in 2014....."
}
local v_u_2 = nil
function v1.Callback(p3)
	-- upvalues: (ref) v_u_2
	if p3 == true then
		v_u_2 = game.ReplicatedStorage.Utils.Misc.FunBlm:Clone()
		v_u_2.Parent = game.Lighting
		return
	elseif v_u_2 then
		v_u_2:Destroy()
		v_u_2 = nil
	end
end
return v1