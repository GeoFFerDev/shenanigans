-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("UserInputService")
local v_u_2 = Enum.UserInputType.Touch
local v_u_3 = Enum.UserInputType.Keyboard
local v_u_4 = nil
local v_u_5 = {}
v_u_4 = {
	["Current"] = "MouseKeyboard",
	["Observe"] = function(p_u_6)
		-- upvalues: (copy) v_u_5, (ref) v_u_4
		if table.find(v_u_5, p_u_6) then
			error("function already subscribed", 2)
		end
		local v7 = v_u_5
		table.insert(v7, p_u_6)
		task.spawn(p_u_6, v_u_4.Current)
		return function()
			-- upvalues: (ref) v_u_5, (copy) p_u_6
			local v8 = table.find(v_u_5, p_u_6)
			if v8 then
				local v9 = #v_u_5
				local v10 = v_u_5
				v_u_5[v8] = v_u_5[v9]
				v10[v9] = nil
			end
		end
	end
}
local function v_u_13(p11)
	-- upvalues: (ref) v_u_4, (copy) v_u_5
	if p11 ~= v_u_4.Current then
		v_u_4.Current = p11
		for _, v12 in v_u_5 do
			task.spawn(v12, p11)
		end
	end
end
local function v17(p14)
	-- upvalues: (copy) v_u_2, (copy) v_u_13, (copy) v_u_3
	if p14 == v_u_2 then
		v_u_13("Touch")
	else
		if p14 ~= v_u_3 then
			local v15 = p14.Name
			if string.sub(v15, 1, 5) ~= "Mouse" then
				local v16 = p14.Name
				if string.sub(v16, 1, 7) == "Gamepad" then
					v_u_13("Gamepad")
				end
				return
			end
		end
		v_u_13("MouseKeyboard")
	end
end
v17(v1:GetLastInputType())
v1.LastInputTypeChanged:Connect(v17)
return v_u_4