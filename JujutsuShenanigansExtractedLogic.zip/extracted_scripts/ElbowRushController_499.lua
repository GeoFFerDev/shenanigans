-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
require(v_u_5.Modules.BloodyZee)
local v_u_9 = Random.new()
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "ElbowRushController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_6, (copy) v_u_9, (copy) v_u_2, (copy) v_u_7, (copy) v_u_5, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (ref) v_u_10
	local v_u_39 = {
		["BarrageHit"] = function(p14, p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_6, (ref) v_u_9, (ref) v_u_2
			if p14:FindFirstChild("HumanoidRootPart") then
				local v16 = p14:FindFirstChild("Torso")
				if v16 then
					v_u_12:Flash(p14, Color3.new(1, 1, 1))
					for _ = 1, p15 and 2 or 1 do
						local v17 = v_u_6.Yuta.ElbowRush.HitParticle:Clone()
						v17.WorldPosition = v16.Position + v_u_9:NextUnitVector() * 2
						v17.Parent = workspace.Effects
						v_u_2:AddItem(v17, 0.5)
						v17.Spark:Emit(1)
					end
				end
			else
				return
			end
		end,
		["BarrageSound"] = function(p18)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_12:PlaySound(v_u_7.Yuta.ElbowRush.Barrage, v19, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Yuta.ElbowRush.Barrage2, v19, game.SoundService.Voice)
			end
		end,
		["Dust"] = function(p20)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_12:DustTrail(p20, 0.4, CFrame.Angles(0, 1.5707963267948966, 0))
				v_u_12:PlaySound(v_u_7.Yuta.ElbowRush.Whiff, v21, game.SoundService.Effect)
			end
		end,
		["ElbowHit"] = function(p22, p23, p24)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v25 = p23:FindFirstChild("HumanoidRootPart")
			if v25 then
				if p22:FindFirstChild("HumanoidRootPart") then
					v_u_12:Flash(p23, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Yuta.MetalHit2, v25, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_7.Yuta.ElbowRush.Hit, v25, game.SoundService.Effect)
					local v26 = v_u_5.Utils.Itadori.RushWind:Clone()
					v26.CFrame = p24
					v26.Parent = workspace.Effects
					v26.Dust:Emit(7)
					v26.Ring:Emit(7)
					v26.Dash1.Dash:Emit(1)
					v26.Dash2.Dash:Emit(1)
					v_u_2:AddItem(v26, 2)
					if v_u_4.Character == p22 or v_u_4.Character == p23 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["StepSound"] = function(p27, p28)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v29 = p27:FindFirstChild("HumanoidRootPart")
			if v29 then
				v_u_12:PlaySound(v_u_7.Yuta.ElbowRush["Step" .. tonumber(p28)], v29, game.SoundService.Effect)
			end
		end,
		["HeavyHit"] = function(p30)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				v_u_12:PlaySound(v_u_7.Yuta.MetalHit, v31, game.SoundService.Effect)
			end
		end,
		["Vanish"] = function(p_u_32, p33)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8, (ref) v_u_3
			local v_u_34 = p_u_32:FindFirstChild("HumanoidRootPart")
			if v_u_34 then
				v_u_12:PlaySound(v_u_7.Yuta.ElbowRush.Teleport, v_u_34, game.SoundService.Effect);
				(function()
					-- upvalues: (ref) v_u_6, (copy) v_u_34, (ref) v_u_2, (ref) v_u_4, (copy) p_u_32, (ref) v_u_8
					local v35 = v_u_6.Gojo.Teleport:Clone()
					v35.CFrame = v_u_34.CFrame
					v35.Parent = workspace.Effects
					v_u_2:AddItem(v35, 1.1)
					v35.Floor.Dust:Emit(30)
					v35.Lines:Emit(30)
					if v_u_4.Character == p_u_32 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					end
				end)()
				local v36 = {}
				for _, v37 in p_u_32:GetDescendants() do
					if v37:IsA("BasePart") or v37:IsA("Decal") and v37.Transparency ~= 1 then
						v36[v37] = v37.Transparency
						v37.Transparency = 1
					end
				end
				p33.AncestryChanged:Wait()
				for _, v38 in p_u_32:GetDescendants() do
					if v36[v38] then
						v_u_3:Create(v38, TweenInfo.new(0.1), {
							["Transparency"] = v36[v38]
						}):Play()
					end
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p40, ...)
		-- upvalues: (copy) v_u_39
		local v41 = v_u_39[p40]
		if v41 then
			v41(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("ElbowRushService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13