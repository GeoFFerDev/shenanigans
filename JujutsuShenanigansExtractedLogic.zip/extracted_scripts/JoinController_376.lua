-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = v_u_6:WaitForChild("CmdrClient", 2)
if v_u_7 then
	v_u_7 = require(v_u_6.CmdrClient)
end
local v_u_8 = require(v_u_6.Modules.Icon)
pcall(function()
	-- upvalues: (copy) v_u_5, (copy) v_u_6
	local v9 = game:GetService("VoiceChatService"):IsVoiceEnabledForUserIdAsync(v_u_5.UserId)
	require(v_u_6.Modules.Icon.IconController).voiceChatEnabled = v9
end)
local _ = v_u_6.Animations
local v_u_10 = v_u_6.Utils
local v_u_11 = v_u_6.Sounds
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "JoinController"
})
v15.lastRecvServer = {}
local function v_u_26(p16)
	local v17 = buffer.readu16(p16, 0) * 256 + buffer.readu8(p16, 2)
	if v17 >= 8388608 then
		v17 = v17 - 16777216
	end
	local v18 = v17 / 100
	local v19 = buffer.readu16(p16, 3) * 256 + buffer.readu8(p16, 5)
	if v19 >= 8388608 then
		v19 = v19 - 16777216
	end
	local v20 = v19 / 100
	local v21 = buffer.readu16(p16, 6) * 256 + buffer.readu8(p16, 8)
	if v21 >= 8388608 then
		v21 = v21 - 16777216
	end
	local v22 = v21 / 100
	local v23 = buffer.readi16(p16, 9) / 1000
	local v24 = buffer.readi16(p16, 11) / 1000
	local v25 = buffer.readi16(p16, 13) / 1000
	return CFrame.new(v18, v20, v22) * CFrame.Angles(v23, v24, v25)
end
local function v_u_47(p27)
	local v28 = buffer.create(15)
	local v29 = p27.X
	local v30 = p27.Y
	local v31 = p27.Z
	local v32, v33, v34 = p27:ToEulerAnglesXYZ()
	local v35 = v29 * 100
	if v35 < 0 then
		v35 = v35 + 16777216
	end
	local v36 = v35 / 256
	buffer.writeu16(v28, 0, v36)
	local v37 = v35 % 256
	buffer.writeu8(v28, 2, v37)
	local v38 = v30 * 100
	if v38 < 0 then
		v38 = v38 + 16777216
	end
	local v39 = v38 / 256
	buffer.writeu16(v28, 3, v39)
	local v40 = v38 % 256
	buffer.writeu8(v28, 5, v40)
	local v41 = v31 * 100
	if v41 < 0 then
		v41 = v41 + 16777216
	end
	local v42 = v41 / 256
	buffer.writeu16(v28, 6, v42)
	local v43 = v41 % 256
	buffer.writeu8(v28, 8, v43)
	local v44 = v32 * 1000
	buffer.writei16(v28, 9, v44)
	local v45 = v33 * 1000
	buffer.writei16(v28, 11, v45)
	local v46 = v34 * 1000
	buffer.writei16(v28, 13, v46)
	return v28
end
function v15.CreateIcon(_, p48, p49, p_u_50)
	-- upvalues: (copy) v_u_8, (ref) v_u_12
	local v51 = v_u_8.new()
	if p49 then
		v51:setImage(p49)
	end
	v51:setLabel(p48)
	v51:bindEvent("selected", function(p52)
		-- upvalues: (ref) v_u_12, (copy) p_u_50
		p52:deselect()
		v_u_12.Change:Fire(p_u_50)
	end)
	return v51
end
function v15.CreateIconBase(_, p53, p54, p_u_55)
	-- upvalues: (copy) v_u_8, (ref) v_u_12
	local v56 = v_u_8.new()
	if p54 then
		v56:setImage(p54)
	end
	v56:setLabel(p53)
	v56:modifyTheme({ "IconLabel", "TextColor3", Color3.fromRGB(152, 152, 152) })
	v56:bindEvent("selected", function(p57)
		-- upvalues: (ref) v_u_12, (copy) p_u_55
		p57:deselect()
		v_u_12.Change:Fire(p_u_55)
	end)
	return v56
end
function v15.KnitStart(p_u_58)
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (ref) v_u_12, (copy) v_u_4, (copy) v_u_6, (ref) v_u_14, (copy) v_u_7, (copy) v_u_2, (copy) v_u_3, (copy) v_u_47, (ref) v_u_13, (copy) v_u_26, (copy) v_u_11, (copy) v_u_10
	script:SetAttribute("KnitLoaded", true)
	local v_u_59 = v_u_8.new()
	v_u_59:setImage("rbxassetid://7992557358")
	v_u_59:setLabel("Characters")
	v_u_59:setEnabled(false)
	v_u_59:setDropdown({
		p_u_58:CreateIcon("Honored One", nil, "Gojo"),
		p_u_58:CreateIcon("Vessel", nil, "Itadori"),
		p_u_58:CreateIcon("Restless Gambler", nil, "Hakari"),
		p_u_58:CreateIcon("Ten Shadows", nil, "Megumi"),
		p_u_58:CreateIcon("Perfection", nil, "Mahito"),
		p_u_58:CreateIcon("Blood Manipulator", nil, "Choso"),
		p_u_58:CreateIcon("Switcher", nil, "Todo"),
		p_u_58:CreateIcon("Defense Attorney", nil, "Hiromi"),
		p_u_58:CreateIcon("Cursed Partners", nil, "Yuta"),
		p_u_58:CreateIcon("Puppet Master", nil, "Mechamaru"),
		p_u_58:CreateIcon("Head of the Hei", nil, "Naoya"),
		p_u_58:CreateIcon("Salaryman", nil, "Nanami"),
		p_u_58:CreateIconBase("Locust Guy", nil, "Locust"),
		p_u_58:CreateIconBase("Star Rage", nil, "Yuki"),
		p_u_58:CreateIconBase("Aspiring Mangaka", nil, "Charles"),
		p_u_58:CreateIconBase("Lucky Coward", nil, "Haruta")
	})
	local v_u_60 = nil
	local v_u_61 = nil
	local v_u_62 = nil
	local v_u_63 = nil
	local function v64()
		-- upvalues: (ref) v_u_60, (ref) v_u_61, (ref) v_u_62, (ref) v_u_63, (copy) p_u_58, (copy) v_u_59, (ref) v_u_5
		if v_u_60 then
			v_u_60:destroy()
			v_u_60 = nil
		end
		if v_u_61 then
			v_u_61:destroy()
			v_u_61 = nil
		end
		if v_u_62 then
			v_u_62:destroy()
			v_u_62 = nil
		end
		if v_u_63 then
			v_u_63:destroy()
			v_u_63 = nil
		end
		if workspace:GetAttribute("AllowOP") then
			v_u_60 = p_u_58:CreateIcon("Strongest Of History", nil, "Heian")
			v_u_60:modifyTheme({ "IconLabel", "TextColor3", Color3.fromRGB(255, 170, 0) })
			v_u_60:joinDropdown(v_u_59)
		end
		if v_u_5:GetAttribute("Mokou") then
			v_u_61 = p_u_58:CreateIcon("Mokou", 129398506853336, "Mokou")
			v_u_61:modifyTheme({ "IconLabel", "TextColor3", Color3.fromRGB(255, 170, 0) })
			v_u_61:joinDropdown(v_u_59)
		end
		if v_u_5:GetAttribute("Goku") or workspace:GetAttribute("AllowOP") then
			v_u_62 = p_u_58:CreateIcon("Monkey Kid", 79537216753706, "Goku")
			v_u_62:modifyTheme({ "IconLabel", "TextColor3", Color3.fromRGB(255, 170, 0) })
			v_u_62:joinDropdown(v_u_59)
		end
		if v_u_5:GetAttribute("Chara") and (workspace:GetAttribute("AllowOP") or workspace:GetAttribute("JSD")) and (workspace:GetAttribute("Match") == nil and not workspace:GetAttribute("Roulette")) then
			v_u_63 = p_u_58:CreateIcon("Cursed Child", 85316557846229, "Chara")
			v_u_63:modifyTheme({ "IconLabel", "TextColor3", Color3.fromRGB(255, 0, 0) })
			v_u_63:joinDropdown(v_u_59)
		end
	end
	v64()
	workspace:GetAttributeChangedSignal("AllowOP"):Connect(v64)
	v_u_5:GetAttributeChangedSignal("Mokou"):Connect(v64)
	v_u_5:GetAttributeChangedSignal("Goku"):Connect(v64)
	v_u_5:GetAttributeChangedSignal("Chara"):Connect(v64)
	task.spawn(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_12, (copy) v_u_59
		local function v_u_76(p65)
			-- upvalues: (ref) v_u_8, (ref) v_u_12, (ref) v_u_59
			local function v74(p_u_66)
				-- upvalues: (ref) v_u_8, (ref) v_u_12, (ref) v_u_59
				if not p_u_66.Value then
					repeat
						task.wait()
					until p_u_66.Value or not p_u_66.Parent
				end
				if p_u_66.Parent then
					if p_u_66.Value then
						local v67 = p_u_66.Value:GetAttribute("MoveNameFt") or "Unnamed"
						local v68 = p_u_66.Value:GetAttribute("IMG")
						if v68 == 0 then
							v68 = nil
						end
						local v_u_69 = v_u_8.new()
						if v68 then
							v_u_69:setImage(v68)
						end
						v_u_69:setLabel(v67)
						v_u_69:bindEvent("selected", function(p70)
							-- upvalues: (ref) v_u_12, (copy) p_u_66
							p70:deselect()
							v_u_12.Change:Fire(p_u_66.Value:GetAttribute("MoveNameFt") or "Unnamed")
						end)
						v_u_69:modifyTheme({ "IconLabel", "TextColor3", Color3.fromRGB(85, 170, 255) })
						v_u_69:joinDropdown(v_u_59)
						p_u_66.Destroying:Connect(function()
							-- upvalues: (copy) v_u_69
							v_u_69:destroy()
						end)
						local function v73()
							-- upvalues: (copy) p_u_66, (copy) v_u_69
							local v71 = p_u_66.Value:GetAttribute("MoveNameFt") or "Unnamed"
							local v72 = p_u_66.Value:GetAttribute("IMG")
							if v72 == 0 then
								v72 = nil
							end
							if v71 then
								v_u_69:setLabel(v71)
							end
							if v72 then
								v_u_69:setImage("rbxassetid://" .. v72)
							end
							if p_u_66.Value:GetAttribute("Flip") == true then
								v_u_69:setEnabled(true)
							else
								v_u_69:setEnabled(false)
							end
						end
						v73()
						p_u_66.Value:GetAttributeChangedSignal("IMG"):Connect(v73)
						p_u_66.Value:GetAttributeChangedSignal("MoveNameFt"):Connect(v73)
						p_u_66.Value:GetAttributeChangedSignal("Flip"):Connect(v73)
						p_u_66.Destroying:Connect(function()
							-- upvalues: (copy) v_u_69
							v_u_69:destroy()
						end)
					end
				else
					return
				end
			end
			for _, v75 in p65:GetChildren() do
				v74(v75)
			end
			p65.ChildAdded:Connect(v74)
		end
		if workspace.LogicData:FindFirstChild("CustomChar") then
			v_u_76(workspace.LogicData.CustomChar)
		else
			workspace.LogicData.ChildAdded:Connect(function(p77)
				-- upvalues: (copy) v_u_76
				if p77.Name == "CustomChar" then
					v_u_76(p77)
				end
			end)
		end
	end)
	v_u_5:WaitForChild("leaderstats")
	local v_u_78 = v_u_5:GetAttribute("Cash") or 0
	local v_u_79 = v_u_5.PlayerGui:WaitForChild("Menus").Group
	local v_u_80 = v_u_5.PlayerGui:WaitForChild("Menus").Fade
	local function v_u_84()
		-- upvalues: (copy) v_u_79, (copy) v_u_80, (ref) v_u_4
		while true do
			local v81 = true
			for _, v82 in v_u_79:GetChildren() do
				if not v82:GetAttribute("Loaded") then
					v81 = false
				end
			end
			if not v81 then
				task.wait(0.1)
			end
			if v81 then
				v_u_79.Parent = v_u_80
				v_u_80.Position = UDim2.new(0, 0, -0.2, 0)
				v_u_80.GroupTransparency = 1
				local v83 = v_u_4:Create(v_u_80, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["Position"] = UDim2.new(0, 0, 0, 0),
					["GroupTransparency"] = 0
				})
				v83:Play()
				v83.Completed:Once(function()
					-- upvalues: (ref) v_u_79, (ref) v_u_80
					v_u_79.Parent = v_u_80.Parent
				end)
				return
			end
		end
	end
	local v_u_85 = v_u_8.new()
	v_u_85:setImage("rbxassetid://9405933217")
	local v86 = v_u_78
	v_u_85:setLabel("$" .. tostring(v86))
	v_u_5:GetAttributeChangedSignal("Cash"):Connect(function()
		-- upvalues: (ref) v_u_78, (ref) v_u_5, (copy) v_u_85
		v_u_78 = v_u_5:GetAttribute("Cash") or 0
		local v87 = v_u_78
		v_u_85:setLabel("$" .. tostring(v87))
	end)
	v_u_85:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_79, (copy) v_u_84
		v_u_79.Shop.Visible = true
		v_u_84()
	end)
	v_u_85:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_79
		v_u_79.Shop.Visible = false
	end)
	v_u_85:setEnabled(workspace:GetAttribute("Match") == nil)
	local v88 = v_u_8.new()
	v88:setImage("rbxassetid://5480743826")
	v88:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_79, (copy) v_u_84
		v_u_79.Settings.Visible = true
		v_u_84()
	end)
	v88:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_79
		v_u_79.Settings.Visible = false
	end)
	local v89 = v_u_8.new()
	v89:setImage("rbxassetid://6870729295")
	v89:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_79, (copy) v_u_84
		v_u_79.Inventory.Visible = true
		v_u_84()
	end)
	v89:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_79
		v_u_79.Inventory.Visible = false
	end)
	v89:setEnabled(workspace:GetAttribute("Match") == nil)
	local v90 = v_u_8.new()
	v90:setImage("rbxassetid://11829454151")
	v90:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_79, (copy) v_u_84
		v_u_79.Achievements.Visible = true
		v_u_84()
	end)
	v90:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_79
		v_u_79.Achievements.Visible = false
	end)
	v90:setName("Achievement")
	local v_u_91 = false
	local v_u_92 = v_u_8.new()
	v_u_92:setImage("rbxassetid://11214451393")
	v_u_92:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_79, (copy) v_u_84, (ref) v_u_91, (ref) v_u_6, (ref) v_u_14
		v_u_79.Logs.Visible = true
		v_u_84()
		if v_u_91 ~= true then
			v_u_91 = true
			v_u_6.Remotes.UpdateLog:FireServer(v_u_14.Ver)
		end
	end)
	v_u_92:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_79
		v_u_79.Logs.Visible = false
	end)
	v_u_92:setRight()
	local v_u_93 = {}
	for v_u_94, v_u_95 in require(v_u_6.Modules.RobloxChatVoice) do
		pcall(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_94, (copy) v_u_95, (ref) v_u_12, (copy) v_u_93
			local v96 = v_u_8.new()
			v96:setImage("rbxassetid://" .. v_u_94)
			v96:setLabel(v_u_95.Name)
			v96:bindEvent("selected", function(p97)
				-- upvalues: (ref) v_u_12, (ref) v_u_94
				p97:deselect()
				v_u_12.Talk:Fire(v_u_94)
			end)
			local v98 = v_u_93
			table.insert(v98, v96)
		end)
	end
	local v99 = v_u_8.new()
	v99:setRight()
	v99:setImage("rbxassetid://14809805905")
	v99:setCaption("this roblox chat update sucks")
	v99:setDropdown(v_u_93)
	task.spawn(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_5, (ref) v_u_8, (copy) v_u_79, (copy) v_u_84
		local v_u_100 = require(v_u_6.Modules.Rules).Version
		local v101 = v_u_5:GetAttribute("LastRulesAccepted")
		if not v101 then
			v_u_5:GetAttributeChangedSignal("LastRulesAccepted"):Wait()
			v101 = v_u_5:GetAttribute("LastRulesAccepted")
		end
		local v_u_102 = v_u_8.new()
		v_u_102:setImage("rbxassetid://71437429504293")
		v_u_102:bindEvent("selected", function(_)
			-- upvalues: (ref) v_u_79, (ref) v_u_84
			v_u_79.Rules.Visible = true
			v_u_84()
		end)
		v_u_102:bindEvent("deselected", function(_)
			-- upvalues: (copy) v_u_100, (ref) v_u_5, (copy) v_u_102, (ref) v_u_79
			if v_u_100 == v_u_5:GetAttribute("LastRulesAccepted") then
				v_u_79.Rules.Visible = false
			else
				v_u_102:select()
			end
		end)
		v_u_102:setRight()
		if v_u_100 ~= v101 then
			v_u_102:select()
		end
		v_u_5:GetAttributeChangedSignal("LastRulesAccepted"):Once(function()
			-- upvalues: (copy) v_u_100, (ref) v_u_5, (copy) v_u_102
			if v_u_100 == v_u_5:GetAttribute("LastRulesAccepted") then
				v_u_102:deselect()
			end
		end)
	end)
	v_u_6.Remotes.UpdateLog:FireServer()
	v_u_6.Remotes.UpdateLog.OnClientEvent:Connect(function(p103)
		-- upvalues: (ref) v_u_14, (copy) v_u_92
		if p103 ~= v_u_14.Ver then
			v_u_92:notify()
		end
	end)
	task.delay(0.05, function()
		-- upvalues: (ref) v_u_8, (copy) v_u_79, (copy) v_u_84, (ref) v_u_5, (ref) v_u_7, (ref) v_u_2
		local v104 = v_u_8.new()
		v104:setImage("rbxassetid://2599458148")
		v104:bindEvent("selected", function(_)
			-- upvalues: (ref) v_u_79, (ref) v_u_84
			v_u_79.Ranked.Visible = true
			v_u_84()
		end)
		v104:bindEvent("deselected", function(_)
			-- upvalues: (ref) v_u_79
			v_u_79.Ranked.Visible = false
		end)
		v104:setEnabled(workspace:GetAttribute("Match") == nil)
		local v_u_105
		if v_u_5:GetAttribute("PS_Owner") then
			v_u_105 = v_u_8.new()
			v_u_105:setImage("rbxassetid://401280105")
			v_u_105:bindEvent("selected", function(_)
				-- upvalues: (ref) v_u_79, (ref) v_u_84
				v_u_79.Private.Visible = true
				v_u_84()
			end)
			v_u_105:bindEvent("deselected", function(_)
				-- upvalues: (ref) v_u_79
				v_u_79.Private.Visible = false
			end)
		else
			v_u_105 = nil
		end
		v_u_5:GetAttributeChangedSignal("PS_Owner"):Connect(function()
			-- upvalues: (ref) v_u_5, (ref) v_u_105, (ref) v_u_8, (ref) v_u_79, (ref) v_u_84
			if v_u_5:GetAttribute("PS_Owner") and not v_u_105 then
				v_u_105 = v_u_8.new()
				v_u_105:setImage("rbxassetid://401280105")
				v_u_105:bindEvent("selected", function(_)
					-- upvalues: (ref) v_u_79, (ref) v_u_84
					v_u_79.Private.Visible = true
					v_u_84()
				end)
				v_u_105:bindEvent("deselected", function(_)
					-- upvalues: (ref) v_u_79
					v_u_79.Private.Visible = false
				end)
			elseif v_u_105 then
				v_u_105:deselect()
				v_u_105:destroy()
				v_u_105 = nil
			end
		end)
		v_u_5:GetAttributeChangedSignal("PS_Perms"):Connect(function()
			-- upvalues: (ref) v_u_5, (ref) v_u_105, (ref) v_u_8, (ref) v_u_79, (ref) v_u_84
			if v_u_5:GetAttribute("PS_Owner") then
				return
			elseif v_u_5:GetAttribute("PS_Perms") and not v_u_105 then
				v_u_105 = v_u_8.new()
				v_u_105:setImage("rbxassetid://401280105")
				v_u_105:bindEvent("selected", function(_)
					-- upvalues: (ref) v_u_79, (ref) v_u_84
					v_u_79.Private.Visible = true
					v_u_84()
				end)
				v_u_105:bindEvent("deselected", function(_)
					-- upvalues: (ref) v_u_79
					v_u_79.Private.Visible = false
				end)
			elseif v_u_105 then
				v_u_105:deselect()
				v_u_105:destroy()
				v_u_105 = nil
			end
		end)
		if v_u_7 then
			local v_u_106 = v_u_8.new()
			v_u_106:setImage("rbxassetid://95498291180289")
			v_u_106:bindEvent("selected", function(p107)
				-- upvalues: (ref) v_u_7, (ref) v_u_84
				v_u_7:Show()
				p107:deselect()
				v_u_84()
			end)
			local function v108()
				-- upvalues: (ref) v_u_5, (copy) v_u_106, (ref) v_u_2
				if v_u_5:GetAttribute("Cmdr") then
					if v_u_2.TouchEnabled then
						v_u_106:setEnabled(true)
					else
						v_u_106:setEnabled(false)
					end
				else
					v_u_106:setEnabled(false)
					return
				end
			end
			v_u_5:GetAttributeChangedSignal("Cmdr"):Connect(v108)
			v_u_2.InputChanged:Connect(v108)
			if v_u_5:GetAttribute("Cmdr") then
				if v_u_2.TouchEnabled then
					v_u_106:setEnabled(true)
				else
					v_u_106:setEnabled(false)
				end
			else
				v_u_106:setEnabled(false)
			end
		end
		local v109 = v_u_8.new()
		v109:setEnabled(false)
		v109:bindEvent("selected", function(_)
			-- upvalues: (ref) v_u_79, (ref) v_u_84
			v_u_79.Tutorial_Info.Visible = true
			v_u_84()
		end)
		v109:bindEvent("deselected", function(_)
			-- upvalues: (ref) v_u_79
			v_u_79.Tutorial_Info.Visible = false
		end)
		_G.TutorialIcon = v109
		local v_u_110 = v_u_8.new()
		v_u_110:setImage("rbxassetid://10626050757")
		v_u_110:bindEvent("selected", function(_)
			-- upvalues: (ref) v_u_79, (ref) v_u_84
			v_u_79.Workshop.Visible = true
			v_u_84()
		end)
		v_u_110:bindEvent("deselected", function(_)
			-- upvalues: (ref) v_u_79
			v_u_79.Workshop.Visible = false
		end)
		_G.WorkshopIcon = v_u_110
		if not workspace:GetAttribute("Workshop") then
			v_u_110:setEnabled(false)
		end
		workspace:GetAttributeChangedSignal("Workshop"):Connect(function()
			-- upvalues: (copy) v_u_110
			if workspace:GetAttribute("Workshop") then
				v_u_110:setEnabled(true)
			else
				v_u_110:setEnabled(false)
			end
		end)
	end)
	local v_u_111 = game:GetService("StarterGui")
	v_u_111:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
	v_u_111:SetCoreGuiEnabled(Enum.CoreGuiType.EmotesMenu, false)
	local v_u_112 = Instance.new("BindableEvent")
	v_u_112.Event:Connect(function()
		-- upvalues: (ref) v_u_12
		v_u_12.Reset:Fire()
	end)
	v_u_12.Reset:Connect(function(p113, p114, _, _)
		game:GetService("StarterGui"):SetCore("SendNotification", {
			["Title"] = p113,
			["Text"] = p114
		})
	end)
	local v115 = game:GetService("TextChatService")
	workspace.Map.Core:FindFirstChild("Leaderboard")
	function v115.OnIncomingMessage(p116)
		local v117 = Instance.new("TextChatMessageProperties")
		if p116.TextSource then
			local v118 = game.Players:GetPlayerByUserId(p116.TextSource.UserId)
			if v118:GetAttribute("Title") then
				v117.PrefixText = "[" .. v118:GetAttribute("Title") .. "] " .. p116.PrefixText
			end
		end
		return v117
	end
	v_u_3.Stepped:Connect(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_47, (ref) v_u_13
		local v119 = v_u_5.Character
		local v120
		if v119 then
			v120 = v119:FindFirstChild("HumanoidRootPart")
		else
			v120 = v119
		end
		local v121 = buffer.create(9)
		local v122 = workspace.CurrentCamera.CFrame.X
		if v122 < 0 then
			v122 = v122 + 16777216
		end
		local v123 = v122 / 256
		buffer.writeu16(v121, 0, v123)
		local v124 = v122 % 256
		buffer.writeu8(v121, 2, v124)
		local v125 = workspace.CurrentCamera.CFrame.Y
		if v125 < 0 then
			v125 = v125 + 16777216
		end
		local v126 = v125 / 256
		buffer.writeu16(v121, 3, v126)
		local v127 = v125 % 256
		buffer.writeu8(v121, 5, v127)
		local v128 = workspace.CurrentCamera.CFrame.Z
		if v128 < 0 then
			v128 = v128 + 16777216
		end
		local v129 = v128 / 256
		buffer.writeu16(v121, 6, v129)
		local v130 = v128 % 256
		buffer.writeu8(v121, 8, v130)
		local v131
		if v120 then
			v131 = v_u_47(v120.CFrame)
		else
			v131 = nil
		end
		v_u_13.Camera:Fire(v121, v131, v119, (0 / 0))
	end)
	local v_u_132 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0)
	v_u_3.RenderStepped:Connect(function(p133)
		-- upvalues: (copy) p_u_58, (ref) v_u_5, (copy) v_u_132
		local v134 = tick()
		for v135, v136 in p_u_58.lastRecvServer do
			if v135 and v135.Parent then
				if v135 ~= v_u_5.Character then
					local v137 = v135.HumanoidRootPart
					if v136 == false or ((v135:GetAttribute("Ragdoll") or 0) > 0 or v135.Humanoid.Sit == true) then
						v137.RootJoint.C0 = v_u_132
						v137:SetAttribute("MO", nil)
					elseif v136[1] and v136[2] then
						local v138
						if (v136[2].Position - v136[1].Position).Magnitude < 15 then
							local v139 = v136[2] or v137.CFrame
							local v140 = v136[1]
							local v141 = (v134 - v136[3]) / 0.05
							v138 = v139:Lerp(v140, (math.clamp(v141, 0, 1)))
						else
							v138 = v136[1]
						end
						local v142 = v137:FindFirstChild("GrabWeld")
						if v142 and (v142.Part0 and v142.Part0.Name ~= "HumanoidRootPart") then
							v137:SetAttribute("MO", (v138:ToObjectSpace(v137.CFrame)))
						else
							local v143 = (v138.Position - v137.Position) / p133
							local v144 = v143.Magnitude > 50 and Vector3.new(0, 0, 0) or v143
							v137.RootJoint.C0 = v_u_132
							v137:SetAttribute("MO", nil)
							v137.Velocity = v144
							v137.CFrame = v138
						end
					else
						v137.RootJoint.C0 = v_u_132
						v137:SetAttribute("MO", nil)
					end
				end
			else
				p_u_58.lastRecvServer[v135] = nil
			end
		end
	end)
	v_u_13.Camera:Connect(function(p145)
		-- upvalues: (copy) p_u_58, (ref) v_u_26
		for v146, v147 in p145 do
			local v148 = game.Players:FindFirstChild(v146)
			if v148 then
				local v149 = v148.Character
				if v149 and v149.Parent then
					if type(v147) == "boolean" then
						p_u_58.lastRecvServer[v149] = false
					else
						local v150 = v149:FindFirstChild("HumanoidRootPart")
						local v151
						if v150 then
							v151 = v150.CFrame * (v150:GetAttribute("MO") or CFrame.new())
						else
							v151 = nil
						end
						p_u_58.lastRecvServer[v149] = { v_u_26(v147), v151 or v_u_26(v147), tick() }
					end
				end
			end
		end
	end)
	v_u_13.Teleport:Connect(function(p152, p153, p154)
		-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_26, (copy) p_u_58
		if v_u_5.Character == p152 then
			v_u_13.Teleport:Fire(p154)
			return
		elseif p152 and p152.Parent then
			p152:PivotTo((v_u_26(p153)))
			p_u_58.lastRecvServer[p152] = false
		end
	end)
	v_u_12.Talk:Connect(function(p155, p156)
		-- upvalues: (ref) v_u_6, (ref) v_u_11, (ref) v_u_10, (ref) v_u_4
		local v157 = p155:FindFirstChild("HumanoidRootPart")
		if v157 then
			local v158 = require(v_u_6.Modules.RobloxChatVoice)[p156]
			local v159 = v158.Sound
			local v_u_160 = v_u_11.Impact.Players.Death:Clone()
			v_u_160.RollOffMaxDistance = 150
			v_u_160.SoundGroup = game.SoundService.Taunt
			v_u_160.SoundId = "rbxassetid://" .. v159
			v_u_160.Volume = v158.Volume or 1
			v_u_160.Parent = v157
			v_u_160:Play()
			v_u_160.Stopped:Connect(function()
				-- upvalues: (copy) v_u_160
				v_u_160:Destroy()
			end)
			local v161 = v_u_10.Voice:Clone()
			v161.ImageLabel.Image = "rbxassetid://" .. p156
			v161.Parent = v157
			v_u_4:Create(v161, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["StudsOffsetWorldSpace"] = Vector3.new(0, 5, 0)
			}):Play()
			v_u_4:Create(v161.ImageLabel, TweenInfo.new(1.5, Enum.EasingStyle.Linear), {
				["ImageTransparency"] = 1
			}):Play()
		end
	end)
	while not pcall(function()
		-- upvalues: (copy) v_u_111, (copy) v_u_112
		v_u_111:SetCore("ResetButtonCallback", v_u_112)
	end) do
		task.wait()
	end
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14
	v_u_12 = v_u_1.GetService("JoinService")
	v_u_13 = v_u_1.GetService("AntiCheatService")
	v_u_14 = v_u_1.GetController("UpdateLogController")
end
return v15