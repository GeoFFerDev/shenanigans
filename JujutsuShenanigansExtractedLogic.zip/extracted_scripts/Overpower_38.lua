-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Name"] = "op",
	["Description"] = "Makes the player extremely strong",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"Mod",
		"Tester",
		"Youtuber"
	},
	["Args"] = {}
}