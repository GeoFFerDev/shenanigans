-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "ReserveBallController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (ref) v_u_10
	local v_u_47 = {
		["Swing"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_8.Itadori.DivergentFist.Swing, v14, game.SoundService.Effect)
			end
		end,
		["Fire"] = function(p15, p16, p17, p18)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8
			local v19 = p15:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = v_u_7.Hakari.Indicators.BallFire:Clone()
				v20.CFrame = p16 * CFrame.new(0, 0, -3)
				v20.Parent = workspace.Effects
				v_u_3:AddItem(v20, 0.7)
				v20.Sparks:Emit(10)
				v20.Wind:Emit(10)
				v20.Ring:Emit(1)
				if p18 then
					p17.Color = p18
					for _, v21 in p17:GetDescendants() do
						if v21:IsA("ParticleEmitter") or v21:IsA("Trail") then
							v21.Color = ColorSequence.new(p18)
						end
					end
					for _, v22 in v20:GetChildren() do
						if v22:IsA("ParticleEmitter") then
							v22.Color = ColorSequence.new(p18)
						end
					end
				end
				v_u_11:PlaySound(v_u_8.Hakari.ReserveBalls.Fire, v19, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p_u_23)
			-- upvalues: (ref) v_u_2
			local v_u_24 = p_u_23.CFrame
			local v_u_25 = tick()
			local v_u_26 = p_u_23:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_24, (copy) p_u_23, (ref) v_u_25
				v_u_24 = p_u_23.CFrame
				v_u_25 = tick()
			end)
			local v_u_27 = nil
			v_u_27 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_23, (ref) v_u_27, (copy) v_u_26, (ref) v_u_24, (ref) v_u_25
				if p_u_23.Parent then
					workspace:BulkMoveTo({ p_u_23 }, { v_u_24 + v_u_24.LookVector * (150 * (tick() - v_u_25)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_27:Disconnect()
					v_u_26:Disconnect()
				end
			end)
		end,
		["Hit"] = function(p28, p29)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_11:Flash(p29, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Hakari.ReserveBalls.Impact, v30, game.SoundService.Effect)
				if v_u_5 == p28 or v_u_5.Character == p29 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end,
		["Another"] = function(p31, p32)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9, (ref) v_u_4, (ref) v_u_2
			local v_u_33 = p31:FindFirstChild("HumanoidRootPart")
			if v_u_33 then
				local v34 = p32:FindFirstChild("HumanoidRootPart")
				if v34 then
					v_u_11:PlaySound(v_u_8.Gojo.Teleport, v_u_33, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_8.Gojo.Teleport, v34, game.SoundService.Effect)
					local v_u_35 = v_u_7.Gojo.Teleport:Clone()
					v_u_35.CFrame = v_u_33.CFrame
					v_u_35.Parent = workspace.Effects
					v_u_3:AddItem(v_u_35, 1.1)
					local v_u_36 = v_u_7.Gojo.Teleport:Clone()
					v_u_36.CFrame = v34.CFrame
					v_u_36.Parent = workspace.Effects
					v_u_3:AddItem(v_u_36, 1.1)
					v_u_35.Center.Flash:Emit(1)
					v_u_36.Center.Flash:Emit(1)
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_35, (copy) v_u_36, (copy) v_u_33
						v_u_35.Floor.Dust:Emit(30)
						v_u_36.Floor.Dust:Emit(30)
						task.wait(0.05)
						v_u_35.CFrame = v_u_33.CFrame
						v_u_35.Lines:Emit(30)
						v_u_35.Floor.Dust:Emit(30)
						v_u_36.CFrame = v_u_33.CFrame
						v_u_36.Lines:Emit(30)
						v_u_36.Floor.Dust:Emit(30)
					end)
					if v_u_5.Character == p31 or v_u_5.Character == p32 then
						local v_u_37 = v_u_7.Gojo.TeleportBreak:Clone()
						v_u_37.Parent = workspace.Effects
						v_u_3:AddItem(v_u_37, 0.8)
						local v38 = Instance.new("Highlight")
						v38.OutlineTransparency = 1
						v38.FillColor = Color3.new(1, 1, 1)
						v38.FillTransparency = 0.8
						v38.Parent = v_u_37
						task.spawn(function()
							-- upvalues: (ref) v_u_9, (ref) v_u_7, (copy) v_u_37, (ref) v_u_4, (ref) v_u_2
							v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
							for _ = 1, 30 do
								local v39 = v_u_7.Gojo.Shard:Clone()
								v39.CFrame = v_u_37.Part.CFrame * CFrame.new(math.random(-40, 40) / 10, math.random(-20, 20) / 10, 0)
								v39.CFrame = v39.CFrame * CFrame.Angles(math.random(0, 360), math.random(0, 360), math.random(0, 360))
								v39.Parent = v_u_37.Shards
								v_u_4:Create(v39, TweenInfo.new(math.random(4, 7) / 10), {
									["Size"] = Vector3.new(0, 0, 0)
								}):Play()
								local v40 = v_u_37.Part.CFrame * CFrame.Angles(math.random(0, 30), math.random(-30, 30), 0)
								local v41 = math.random(-5, 5)
								local v42 = math.random(-5, 5)
								local v43 = math.random
								v39.RotVelocity = Vector3.new(v41, v42, v43(-5, 5))
								local v44 = Instance.new("BodyVelocity")
								v44.Archivable = false
								v44.Parent = v39
								v44.Velocity = v40.LookVector * math.random(1, 80) / 10
							end
							while true do
								v_u_37:SetPrimaryPartCFrame(workspace.CurrentCamera.CFrame * CFrame.new(0, 0, -2))
								for _, v45 in v_u_37.Shards:GetChildren() do
									local v46 = v45.BodyVelocity
									v46.Velocity = v46.Velocity - Vector3.new(0, 0.25, 0)
								end
								v_u_2.RenderStepped:Wait()
								if not v_u_37.Parent then
									return
								end
							end
						end)
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p48, ...)
		-- upvalues: (copy) v_u_47
		local v49 = v_u_47[p48]
		if v49 then
			v49(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("ReserveBallService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12