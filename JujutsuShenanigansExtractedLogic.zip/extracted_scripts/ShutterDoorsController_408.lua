-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
require(v4.Modules.CameraShaker)
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "ShutterDoorController"
})
function v9.KnitStart(_)
	-- upvalues: (copy) v_u_3, (ref) v_u_8, (copy) v_u_6, (copy) v_u_2, (copy) v_u_5, (ref) v_u_7
	local v_u_30 = {
		["Spawn"] = function(p10, p11, p12)
			-- upvalues: (ref) v_u_3, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2
			local v13 = p12 or 1
			local v14 = Instance.new("Highlight")
			v14.FillTransparency = 0
			v14.FillColor = Color3.new(2, 2, 2)
			v14.OutlineColor = Color3.new(2, 2, 2)
			v14.DepthMode = Enum.HighlightDepthMode.Occluded
			v14.Parent = p10.Doors
			if p11 then
				p10.Doors.Door1.Color = p11
				p10.Doors.Door2.Color = p11
				p10.Doors.Door1.Stars.Color = ColorSequence.new(p11)
				p10.Doors.Door2.Stars.Color = ColorSequence.new(p11)
			end
			p10.Weld1.C1 = CFrame.new(0, 0, 4) * CFrame.Angles(1.4835298641951802, -1.5707963267948966, 0)
			p10.Weld2.C1 = CFrame.new(0, 0, 4) * CFrame.Angles(1.4835298641951802, -1.5707963267948966, 3.141592653589793)
			v_u_3:Create(p10.Weld1, TweenInfo.new(0.6 * v13, Enum.EasingStyle.Back), {
				["C1"] = CFrame.new(0, 0, 7) * CFrame.Angles(0, -1.5707963267948966, 0)
			}):Play()
			v_u_3:Create(p10.Weld2, TweenInfo.new(0.6 * v13, Enum.EasingStyle.Back), {
				["C1"] = CFrame.new(0, 0, 7) * CFrame.Angles(0, -1.5707963267948966, 3.141592653589793)
			}):Play()
			v_u_3:Create(v14, TweenInfo.new(0.4 * v13), {
				["FillTransparency"] = 1,
				["OutlineTransparency"] = 1
			}):Play()
			v_u_8:PlaySound(v_u_6.Hakari.ShutterDoors.Spawn, p10, game.SoundService.Effect)
			v_u_8:PlaySound(v_u_6.Hakari.ShutterDoors.Swing, p10, game.SoundService.Effect)
			v_u_2:AddItem(v14, 0.4 * v13)
			task.wait(0.2 * v13)
			p10.Doors.Door1.Stars.Enabled = false
			p10.Doors.Door2.Stars.Enabled = false
		end,
		["Close"] = function(p15, p16)
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_3
			v_u_8:PlaySound(v_u_6.Hakari.ShutterDoors.Slam, p15, game.SoundService.Effect)
			if p16 then
				v_u_3:Create(p15.Weld1, TweenInfo.new(0.1), {
					["C1"] = CFrame.new(0, 0, 3.4) * CFrame.Angles(0, -1.5707963267948966, 0)
				}):Play()
				v_u_3:Create(p15.Weld2, TweenInfo.new(0.1), {
					["C1"] = CFrame.new(0, 0, 3.4) * CFrame.Angles(0, -1.5707963267948966, 3.141592653589793)
				}):Play()
				task.wait(0.1)
				v_u_3:Create(p15.Weld1, TweenInfo.new(0.9, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
					["C1"] = CFrame.new(0, 0, 8) * CFrame.Angles(0, -1.5707963267948966, 0)
				}):Play()
				v_u_3:Create(p15.Weld2, TweenInfo.new(0.9, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
					["C1"] = CFrame.new(0, 0, 8) * CFrame.Angles(0, -1.5707963267948966, 3.141592653589793)
				}):Play()
			else
				v_u_3:Create(p15.Weld1, TweenInfo.new(0.1), {
					["C1"] = CFrame.new(0, 0, 2.4) * CFrame.Angles(0, -1.5707963267948966, 0)
				}):Play()
				v_u_3:Create(p15.Weld2, TweenInfo.new(0.1), {
					["C1"] = CFrame.new(0, 0, 2.4) * CFrame.Angles(0, -1.5707963267948966, 3.141592653589793)
				}):Play()
				if p16 == true then
					task.wait(0.1)
					v_u_3:Create(p15.Weld1, TweenInfo.new(0.9, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
						["C1"] = CFrame.new(0, 0, 7) * CFrame.Angles(0, -1.5707963267948966, 0)
					}):Play()
					v_u_3:Create(p15.Weld2, TweenInfo.new(0.9, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
						["C1"] = CFrame.new(0, 0, 7) * CFrame.Angles(0, -1.5707963267948966, 3.141592653589793)
					}):Play()
				end
			end
		end,
		["Fade"] = function(p17)
			-- upvalues: (ref) v_u_3
			for _, v18 in p17.Doors:GetDescendants() do
				if v18:IsA("BasePart") or v18:IsA("Texture") then
					v_u_3:Create(v18, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
			end
		end,
		["Bound"] = function(p19)
			-- upvalues: (ref) v_u_3, (ref) v_u_8, (ref) v_u_6
			local v20 = p19:GetAttribute("CF")
			if not v20 then
				p19:SetAttribute("CF", p19.CFrame)
				v20 = p19.CFrame
			end
			p19.CFrame = p19.CFrame + Vector3.new(0, 3, 0)
			v_u_3:Create(p19, TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				["CFrame"] = v20
			}):Play()
			v_u_8:PlaySound(v_u_6.Itadori.CraniumSmash.Hit2, p19, game.SoundService.Effect)
			v_u_8:PlaySound(v_u_6.Hakari.ShutterDoors.Slam, p19, game.SoundService.Effect)
		end,
		["Break"] = function(p21)
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_2
			local v22 = p21.Doors:Clone()
			v22.Door1.Color = p21.Doors.Door1.Color
			v22.Door2.Color = p21.Doors.Door2.Color
			v22.Parent = p21
			p21.Doors:Destroy()
			v_u_8:PlaySound(v_u_6.Hakari.Counter.Swing, p21, game.SoundService.Effect)
			v_u_8:PlaySound(v_u_6.Hakari.Counter.Slam, p21, game.SoundService.Effect)
			v22.Door1.CanCollide = true
			v22.Door2.CanCollide = true
			v22.Door1.Velocity = Vector3.new(0, -100, 0)
			v22.Door1.RotVelocity = -p21.CFrame.LookVector * 80
			v22.Door2.Velocity = Vector3.new(0, -100, 0)
			v22.Door2.RotVelocity = p21.CFrame.LookVector * 80
			for _, v23 in v22:GetDescendants() do
				if v23:IsA("BasePart") or v23:IsA("Texture") then
					v_u_3:Create(v23, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Transparency"] = 1
					}):Play()
				end
			end
			local v24 = v_u_5.Locust.Slam:Clone()
			v24.Position = p21.Position
			v24.Parent = workspace.Effects
			for _, v25 in v24.Attachment:GetChildren() do
				v25:Emit(v25:GetAttribute("EmitCount"))
			end
			v_u_2:AddItem(v24, 0.5)
		end,
		["Hit"] = function(p26)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			v_u_8:Flash(p26, Color3.new(1, 1, 1))
			v_u_8:PlaySound(v_u_6.Itadori.CraniumSmash.Hit2, v27, game.SoundService.Effect)
		end,
		["Finisher"] = function(p28)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				v_u_8:PlaySound(v_u_6.Itadori.Dismantle.Explode, v29, game.SoundService.Effect)
				v_u_8:Bleed(p28)
			end
		end
	}
	v_u_7.Effects:Connect(function(p31, ...)
		-- upvalues: (copy) v_u_30
		local v32 = v_u_30[p31]
		if v32 then
			v32(...)
		end
	end)
end
function v9.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("ShutterDoorService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v9