-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 3,
	["SortOrder"] = 2,
	["Val"] = "VolMS",
	["Desc"] = "Change the volume for music",
	["Max"] = 2,
	["Callback"] = function(p1)
		game.SoundService.Music.Volume = p1
	end
}