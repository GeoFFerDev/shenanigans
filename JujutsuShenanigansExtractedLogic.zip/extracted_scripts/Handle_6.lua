-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local function v_u_4(p1, p2)
	if p1 then
		local v3 = script.Parent:FindFirstChild(p2)
		if v3 then
			v3 = script.Parent[p2]:FindFirstChild("Head")
		end
		if v3 then
			p1:WaitForChild("Wire").SourceInstance = script.Parent.Audio.AudioReverb
		end
	else
		return
	end
end
script.Parent.ChildAdded:Connect(v_u_4)
local v5 = next
local v6, v7 = script.Parent:GetChildren()
for _, v_u_8 in v5, v6, v7 do
	if not v_u_8.Name:find("Mic") then
		v_u_8.ChildAdded:Connect(function(p9)
			-- upvalues: (copy) v_u_4, (copy) v_u_8
			if p9.Name == "Head" then
				if script.Parent:FindFirstChild("Speaker1") then
					v_u_4(script.Parent.Speaker1:FindFirstChild(v_u_8.Name), v_u_8.Name)
				end
				if script.Parent:FindFirstChild("Speaker2") then
					v_u_4(script.Parent.Speaker2:FindFirstChild(v_u_8.Name), v_u_8.Name)
				end
				script.Parent.Audio[("%sWire"):format(v_u_8.Name)].SourceInstance = p9:WaitForChild("AudioListener", 1)
			end
		end)
		v_u_4(script.Parent.Speaker1:FindFirstChild(v_u_8.Name), v_u_8.Name)
		v_u_4(script.Parent.Speaker2:FindFirstChild(v_u_8.Name), v_u_8.Name)
	end
end