-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = require(v_u_6.Modules.BloodyZee)
local v11 = RaycastParams.new()
v11.FilterType = Enum.RaycastFilterType.Include
v11.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "AnkleCutterController"
})
function v15.KnitStart(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_8, (copy) v_u_10, (copy) v_u_2, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_9, (ref) v_u_12
	local v_u_37 = {
		["Start"] = function(p16)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_13:PlaySound(v_u_8.Haruta.AnkleCutterWhoosh, v17, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p18)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_10
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_13:Flash(p18, Color3.new(0.745098, 0, 0.0117647))
				v_u_13:PlaySound(v_u_8.Haruta.AnkleCutterHit, v19, game.SoundService.Effect)
				for _ = 1, 5 do
					v_u_10:Blood(p18["Right Leg"].CFrame * CFrame.new(0, 0.5, 0), -math.random(20, 70), 25, 25)
				end
				for _ = 1, 5 do
					v_u_10:Blood(p18["Left Leg"].CFrame * CFrame.new(0, 0.5, 0), -math.random(20, 70), 25, 25)
				end
			end
		end,
		["Interp"] = function(p_u_20)
			-- upvalues: (ref) v_u_2
			local v_u_21 = p_u_20.CFrame
			local v_u_22 = tick()
			local v_u_23 = p_u_20:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_21, (copy) p_u_20, (ref) v_u_22
				v_u_21 = p_u_20.CFrame
				v_u_22 = tick()
			end)
			local v_u_24 = nil
			v_u_24 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_20, (ref) v_u_24, (copy) v_u_23, (ref) v_u_21, (ref) v_u_22
				if p_u_20.Parent then
					workspace:BulkMoveTo({ p_u_20 }, { v_u_21 + v_u_21.LookVector * (150 * (tick() - v_u_22)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_24:Disconnect()
					v_u_23:Disconnect()
				end
			end)
		end,
		["Dash"] = function(p25, p26)
			-- upvalues: (ref) v_u_2, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_6, (ref) v_u_13, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v_u_27 = p25.HumanoidRootPart
			if v_u_27 then
				v_u_2.Stepped:Wait()
				local v_u_28 = CFrame.new(p26, v_u_27.Position) * CFrame.new(0, -2.25, 0)
				local v29 = (p26 - v_u_27.Position).Magnitude
				local v30 = v_u_7.Mahito.Dash:Clone()
				local v31 = Instance.new("Model")
				v30.Parent = v31
				v31:ScaleTo(0.5)
				v_u_3:AddItem(v31, 0.2)
				v30.CFrame = v_u_28 + v_u_28.LookVector * v29 / 2
				v30.Size = Vector3.new(1.5, 1.5, v29)
				v30.Parent = workspace.Effects
				v_u_4:Create(v30, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 0, v29),
					["CFrame"] = v30.CFrame * CFrame.Angles(0, 0, 3.141592653589793)
				}):Play()
				v_u_3:AddItem(v30, 0.2)
				local v32 = Instance.new("Model")
				local v33 = v_u_6.Utils.Itadori.RushWind:Clone()
				v33.CFrame = v_u_27.CFrame * CFrame.new(0, -1, 0) * CFrame.new(0, -2.25, 0)
				v33.Parent = v32
				v32.Parent = workspace.Effects
				v32:ScaleTo(0.4)
				v33.Ring:Emit(7)
				v33.Dash1.Dash:Emit(1)
				v33.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v32, 2)
				local v34 = v_u_7.Itadori.Shock:Clone()
				v34.CFrame = v_u_28 * CFrame.Angles(1.5707963267948966, 0, 0)
				v34.Parent = workspace.Effects
				v_u_4:Create(v34, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(7, 0, 7),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v34, 0.3)
				task.delay(0.075, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_28, (ref) v_u_4, (ref) v_u_3, (copy) v_u_27
					local v35 = v_u_7.Itadori.Shock:Clone()
					v35.CFrame = v_u_28 * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_28.LookVector * 3
					v35.Parent = workspace.Effects
					v_u_4:Create(v35, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(5, 0, 5),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v35, 0.2)
					task.wait(0.075)
					local v36 = v_u_7.Itadori.Shock:Clone()
					v36.CFrame = v_u_27.CFrame * CFrame.new(0, -2.25, 0) * CFrame.Angles(1.5707963267948966, 0, 0)
					v36.Parent = workspace.Effects
					v_u_4:Create(v36, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(5, 0, 5),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v36, 0.2)
				end)
				v_u_13:PlaySound(v_u_8.Nanami.BluntCut.Dash, v_u_27, game.SoundService.Effect)
				if v_u_5.Character == p25 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_12.Effects:Connect(function(p38, ...)
		-- upvalues: (copy) v_u_37
		local v39 = v_u_37[p38]
		if v39 then
			v39(...)
		end
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_14, (ref) v_u_13
	v_u_12 = v_u_1.GetService("AnkleCutterService")
	v_u_14 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v15