-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local v_u_4 = v3.Utils
local v_u_5 = v3.Sounds
local v_u_6 = require(v3.Modules.CameraShaker)
require(v3.Modules.BloodyZee)
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "MaxElephantController"
})
function v10.KnitStart(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_5, (copy) v_u_4, (ref) v_u_9, (copy) v_u_2, (copy) v_u_6, (ref) v_u_7
	local v_u_33 = {
		["Start"] = function(p11)
			-- upvalues: (ref) v_u_8, (ref) v_u_5
			local v12 = p11:FindFirstChild("HumanoidRootPart")
			if v12 then
				v_u_8:PlaySound(v_u_5.Megumi.Rabbit.Start, v12, game.SoundService.Effect)
			end
		end,
		["Hitbox"] = function(p13)
			-- upvalues: (ref) v_u_4, (ref) v_u_9
			local v14 = v_u_4.Megumi.HitArea:Clone()
			v14.Size = Vector3.new(40, 0, 40)
			v14.Parent = workspace.Effects
			while true do
				local v15 = v_u_9:GetMouseTarget(75)
				local v16 = workspace:Raycast(v15 + Vector3.new(0, 1, 0), Vector3.new(0, -300, 0), _G.MapParams)
				if v16 then
					v15 = v16.Position
				end
				v14.Position = v15
				task.wait()
				if not (p13 and p13.Parent) then
					v14:Destroy()
					return
				end
			end
		end,
		["Spawn"] = function(p17, p18)
			-- upvalues: (ref) v_u_4, (ref) v_u_2, (ref) v_u_8, (ref) v_u_5, (ref) v_u_6
			local v19 = v_u_4.Megumi.Smash:Clone()
			v19.Position = p17
			v19.Size = Vector3.new(9, 9, 9)
			v19.Parent = workspace.Effects
			v19.Shadow:Emit(20)
			v19.ShadowSpark:Emit(40)
			v_u_2:AddItem(v19, 2)
			if p18 then
				v_u_8:PlaySound(v_u_5.Megumi.Elephant.Spawn, v19, game.SoundService.Effect)
			else
				v_u_8:PlaySound(v_u_5.Megumi.Elephant.Despawn, v19, game.SoundService.Effect)
			end
			if (workspace.CurrentCamera.CFrame.Position - p17).Magnitude < 50 then
				v_u_6.CurrentShaker:Shake(v_u_6.Presets.LightHit)
			end
		end,
		["Smash"] = function(p20)
			-- upvalues: (ref) v_u_4, (ref) v_u_2, (ref) v_u_6
			local v21 = v_u_4.Megumi.Smash:Clone()
			v21.Position = p20
			v21.Parent = workspace.Effects
			v21.Dust:Emit(10)
			v21.Ring:Emit(10)
			v_u_2:AddItem(v21, 2)
			if (workspace.CurrentCamera.CFrame.Position - p20).Magnitude < 80 then
				v_u_6.CurrentShaker:Shake(v_u_6.Presets.HeavyHit)
			end
		end,
		["Hit"] = function(p22)
			-- upvalues: (ref) v_u_8, (ref) v_u_5
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			if v23 then
				v_u_8:Flash(p22, Color3.new(1, 1, 1))
				v_u_8:PlaySound(v_u_5.Megumi.Elephant.Hit, v23, game.SoundService.Effect)
			end
		end,
		["Finisher"] = function(p24)
			-- upvalues: (ref) v_u_8, (ref) v_u_5, (ref) v_u_4, (ref) v_u_2
			local v25 = p24.HumanoidRootPart
			if v25 then
				v_u_8:Bleed(p24)
				v_u_8:PlaySound(v_u_5.Megumi.Elephant.Explode, v25, game.SoundService.Effect)
				for _ = 1, 20 do
					local v26 = v_u_4.Damage.Chunk:Clone()
					v26.CFrame = v25.CFrame
					local v27 = math.random(-90, 90)
					local v28 = math.random(20, 50)
					local v29 = math.random
					v26.Velocity = Vector3.new(v27, v28, v29(-90, 90))
					local v30 = math.random(-200, 200)
					local v31 = math.random(-200, 200)
					local v32 = math.random
					v26.RotVelocity = Vector3.new(v30, v31, v32(-200, 200))
					v26.Parent = workspace.Effects
					v_u_2:AddItem(v26, 1)
					if _G.Settings.Gore == false then
						v26.Color = Color3.fromRGB(255, 85, 255)
						v26.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
						v26.Blood.Color = v26.Trail.Color
					end
				end
			end
		end
	}
	v_u_7.Effects:Connect(function(p34, ...)
		-- upvalues: (copy) v_u_33
		local v35 = v_u_33[p34]
		if v35 then
			v35(...)
		end
	end)
end
function v10.ToolDeactivate(_)
	-- upvalues: (ref) v_u_9
	return v_u_9:GetMouseTarget(75)
end
function v10.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8, (ref) v_u_9
	v_u_7 = v_u_1.GetService("MaxElephantService")
	v_u_8 = v_u_1.GetController("FXController")
	v_u_9 = v_u_1.GetController("ToolController")
end
return v10