-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "RisingRageController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_5, (copy) v_u_3, (copy) v_u_2, (copy) v_u_6, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10
	local v_u_56 = {
		["Startup"] = function(p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:PlaySound(v_u_7.Yuki.Startup, v15, game.SoundService.Effect)
			end
		end,
		["Trail"] = function(p16)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_5, (ref) v_u_3, (ref) v_u_2
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_11:PlaySound(v_u_7.Yuki.Swing, v17, game.SoundService.Effect)
				local v18 = v_u_5.Utils.Yuki.MassChargeLeg:Clone()
				v18.Parent = workspace.Effects
				v_u_3:Create(v18.PointLight, TweenInfo.new(0.3), {
					["Brightness"] = 5
				}):Play()
				v18.Weld.C1 = CFrame.new(0, 2, 0)
				v18.Weld.Part0 = p16["Left Leg"]
				task.wait(0.2)
				for _, v19 in v18:GetDescendants() do
					if v19:IsA("ParticleEmitter") then
						v19.Enabled = false
					end
				end
				v_u_3:Create(v18.PointLight, TweenInfo.new(0.5), {
					["Brightness"] = 0
				}):Play()
				v_u_2:AddItem(v18, 0.6)
				v18.Trail.Enabled = false
			end
		end,
		["Hit"] = function(p20, p21, p22)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v23 = p21:FindFirstChild("HumanoidRootPart")
			if v23 then
				local v24 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v24.Parent = v23.RootAttachment
				v24:Emit(20)
				v_u_2:AddItem(v24, 0.4)
				if p22 == 1 then
					v_u_11:PlaySound(v_u_7.Yuki.Mass.Hit, v23, game.SoundService.Effect)
				elseif p22 == 2 then
					v_u_11:PlaySound(v_u_7.Yuki.RisingRage.Hit, v23, game.SoundService.Effect)
				elseif p22 == 3 then
					v_u_11:PlaySound(v_u_7.Yuki.RisingRage.Hit2, v23, game.SoundService.Effect)
				end
				v_u_11:Flash(p21, Color3.new(1, 1, 1))
				if v_u_4 == p20 or v_u_4.Character == p21 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Hit2"] = function(p25, p26)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v28 = v_u_6.Yuki.MassHit:Clone()
				v28.CFrame = CFrame.lookAlong(v27.Position, Vector3.new(0, 1, 0))
				v28.Parent = workspace.Effects
				v_u_2:AddItem(v28, 1)
				for _, v29 in v28:GetDescendants() do
					if v29:IsA("ParticleEmitter") then
						v29:Emit(v29:GetAttribute("EmitCount"))
					end
				end
				local v30 = v_u_6.Gojo.LapseBlue.LapseBlue.Grab:Clone()
				v30.Size = Vector3.new(40, 40, 40)
				v30.Weld.Part0 = v27
				v30.Parent = workspace.Effects
				local v31 = Instance.new("Highlight", v30)
				v31.FillTransparency = 1
				v31.OutlineTransparency = 1
				v30.Transparency = 50
				v_u_3:Create(v30, TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(0, 0, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v30, 0.4)
				v_u_11:Flash(p26, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Yuki.Mass.Hit, v27, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Yuki.Mass.Hit2, v27, game.SoundService.Effect)
				if v_u_4 == p25 or v_u_4.Character == p26 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["KneeBuild"] = function(p32)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_5, (ref) v_u_3, (ref) v_u_2
			local v33 = p32:FindFirstChild("HumanoidRootPart")
			if v33 then
				v_u_11:PlaySound(v_u_7.Yuki.RisingRage.Charge, v33, game.SoundService.Effect)
				local v34 = v_u_5.Utils.Yuki.FullRisingRage:Clone()
				v34.Parent = workspace.Effects
				v_u_3:Create(v34.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 10
				}):Play()
				v34.Weld.Part0 = p32["Right Leg"]
				v_u_2:AddItem(v34, 2)
				for _, v35 in v34:GetDescendants() do
					if v35:IsA("ParticleEmitter") then
						v35.TimeScale = 0
						v_u_3:Create(v35, TweenInfo.new(0.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.In), {
							["TimeScale"] = 1
						}):Play()
					end
				end
				task.wait(0.6)
				for _, v36 in v34.Hit:GetChildren() do
					v36.Enabled = false
				end
				v34.impactframeines3.Enabled = true
				v34.Start["Down_Smoke [11]"].Enabled = true
				v34.Start.Hit.Enabled = true
				v34.Smear:Emit(1)
				v34.Start.Flare:Emit(1)
				v34.Start.Wind2:Emit(8)
				task.wait(0.3)
				v_u_3:Create(v34.PointLight, TweenInfo.new(0.4), {
					["Brightness"] = 0
				}):Play()
				for _, v37 in v34:GetDescendants() do
					if v37:IsA("ParticleEmitter") then
						v37.Enabled = false
					end
				end
			end
		end,
		["Dash"] = function(p38)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v_u_39 = p38:FindFirstChild("HumanoidRootPart")
			if v_u_39 then
				for v40 = 1, 4 do
					task.delay(0.05 * v40, function()
						-- upvalues: (ref) v_u_6, (copy) v_u_39, (ref) v_u_3, (ref) v_u_2
						local v41 = v_u_6.Itadori.Shock:Clone()
						v41.CFrame = CFrame.lookAlong(v_u_39.Position, v_u_39.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
						v41.Transparency = 0.3
						v41.Parent = workspace.Effects
						v_u_3:Create(v41, TweenInfo.new(0.15), {
							["Size"] = Vector3.new(20, 0, 20),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v41, 0.15)
					end)
				end
				local v42 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v42.Size = Vector3.new(6, 30, 6)
				v42.CFrame = v_u_39.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v42.Parent = workspace.Effects
				v_u_2:AddItem(v42, 0.2)
				v_u_3:Create(v42, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = v42.Position + v_u_39.CFrame.LookVector * 10
				}):Play()
				local v43 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v43.CFrame = v_u_39.CFrame * CFrame.new(2, 1, -5)
				v43.Parent = workspace.Effects
				v43.Wind:Emit(20)
				v43.PointLight:Destroy()
				v43.Back1.Back:Emit(1)
				v43.Back2.Back:Emit(1)
				v_u_3:Create(v43.Back1, TweenInfo.new(2), {
					["CFrame"] = v43.Back1.CFrame - v43.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_3:Create(v43.Back2, TweenInfo.new(2), {
					["CFrame"] = v43.Back2.CFrame - v43.Back2.CFrame.LookVector * 20
				}):Play()
				v_u_2:AddItem(v43, 3)
				if v_u_4.Character == p38 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["KneeHit"] = function(p44, p45)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v46 = p45:FindFirstChild("HumanoidRootPart")
			if v46 then
				local v47 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v47.Parent = v46.RootAttachment
				v47:Emit(20)
				v_u_2:AddItem(v47, 0.4)
				v_u_11:Flash(p45, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Yuki.RisingRage.Hit3, v46, game.SoundService.Effect)
				if v_u_4 == p44 or v_u_4.Character == p45 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["HeadHit"] = function(p48, p49, p50)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8, (ref) v_u_3
			local v51 = p49:FindFirstChild("HumanoidRootPart")
			if v51 then
				local v52 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v52.Parent = v51.RootAttachment
				v52:Emit(20)
				v_u_2:AddItem(v52, 0.4)
				v_u_11:Flash(p49, Color3.new(1, 1, 1))
				v_u_11:Flash(p49, Color3.new(1, 0, 0), 5)
				v_u_11:PlaySound(v_u_7.Yuki.RisingRage.Hit3, v51, game.SoundService.Effect)
				local v53 = CFrame.lookAlong(p49.Head.Position, p50)
				for _ = 1, 40 do
					v_u_9:Blood(v53, math.random(-150, -5), 25, 25)
				end
				if v_u_4 == p48 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				elseif v_u_4.Character == p49 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
					v_u_8.CurrentShaker:ShakeSustain(v_u_8.Presets.LightHit):StartFadeOut(5)
					v_u_11:PlaySound(v_u_7.Yuki.RisingRage.Ring, workspace, game.SoundService.Effect)
					local v54 = Instance.new("BlurEffect", game.Lighting)
					v_u_2:AddItem(v54, 5)
					v54.Size = 64
					v_u_3:Create(v54, TweenInfo.new(5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Size"] = 0
					}):Play()
					local v55 = Instance.new("ColorCorrectionEffect", game.Lighting)
					v_u_2:AddItem(v55, 5)
					v55.TintColor = Color3.new(1, 0, 0)
					v55.Contrast = 200
					task.wait(0.05)
					v55.Contrast = -200
					v55.TintColor = Color3.new(1, 1, 1)
					task.wait(0.05)
					v55.Contrast = 0
					v55.TintColor = Color3.new(1, 0.3, 0.3)
					v_u_3:Create(v55, TweenInfo.new(2.4, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["TintColor"] = Color3.fromRGB(255, 201, 201)
					}):Play()
					task.wait(2.4)
					v_u_3:Create(v55, TweenInfo.new(2.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["TintColor"] = Color3.fromRGB(255, 255, 255)
					}):Play()
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p57, ...)
		-- upvalues: (copy) v_u_56
		local v58 = v_u_56[p57]
		if v58 then
			v58(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("RisingRageService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("ToolController")
end
return v13