-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("HttpService")
local v_u_2 = require("./Helper")
local v_u_3 = {
	["ttl"] = 2.2,
	["gravity"] = 520,
	["vxMin"] = -120,
	["vxMax"] = 120,
	["vyMin"] = 120,
	["vyMax"] = 180,
	["spinMin"] = -240,
	["spinMax"] = 240
}
local v_u_4 = script.Parent.Assets.Sprites
local v_u_5 = Random.new()
local v_u_6 = {}
v_u_6.__index = v_u_6
v_u_6.Compute = {}
function v_u_6.new(p7, p8, p9, p10, p11, p12)
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_1, (copy) v_u_6, (copy) v_u_5
	local v13 = p12 or {}
	local v14 = v13.ttl or v_u_3.ttl
	local v_u_15 = v13.gravity or v_u_3.gravity
	local v16 = v13.vxMin or v_u_3.vxMin
	local v17 = v13.vxMax or v_u_3.vxMax
	local v18 = v13.vyMin or v_u_3.vyMin
	local v19 = v13.vyMax or v_u_3.vyMax
	local v20 = v13.spinMin or v_u_3.spinMin
	local v21 = v13.spinMax or v_u_3.spinMax
	local v22 = v13.damage
	local v23, v24 = v_u_2.resolveEffectFolders(p8)
	if v13.fromGui then
		p11 = v_u_2.absToCenteredOffset(v_u_2.centerAbs(v13.fromGui), p8) + p11
	end
	local v25 = v_u_4:FindFirstChild("Bits") and v_u_4.Bits:FindFirstChild(p9) or v_u_4:FindFirstChild(p9)
	if not v25 then
		return nil
	end
	local v26 = {
		["State"] = p7,
		["Contents"] = p8,
		["Folder"] = v24,
		["Kind"] = p9,
		["UUID"] = v_u_1:GenerateGUID(false),
		["Alive"] = true,
		["TTL"] = v14,
		["Time"] = 0,
		["Guis"] = {},
		["Pos"] = {},
		["Vel"] = {},
		["Rot"] = {},
		["Spin"] = {},
		["Kill"] = {}
	}
	local v27 = v_u_6
	local v_u_28 = setmetatable(v26, v27)
	for v29 = 1, math.max(1, p10 or 1) do
		local v30 = v_u_2.randomChild(v25)
		if v30 and v30:IsA("ImageLabel") then
			local v_u_31 = v30:Clone()
			v_u_31.AnchorPoint = Vector2.new(0.5, 0.5)
			v_u_31.Parent = v24
			local v32 = v_u_2.unitScale(v_u_28.Contents, v_u_28.State.Arena.BaselineMin)
			local v33 = v_u_5:NextNumber(v16, (math.max(v16, v17))) * v32
			local v34 = -v_u_5:NextNumber(v18, (math.max(v18, v19))) * v32
			local v35 = v_u_5:NextNumber(0, 360)
			local v36 = v_u_5:NextNumber(v20, v21)
			v_u_28.Guis[v29] = v_u_31
			v_u_28.Pos[v29] = p11
			v_u_28.Vel[v29] = Vector2.new(v33, v34)
			v_u_28.Rot[v29] = v35
			v_u_28.Spin[v29] = v36
			v_u_31.Position = UDim2.new(0.5, v_u_2.roundpx(p11.X), 0.5, v_u_2.roundpx(p11.Y))
			v_u_31.Rotation = v35
			if v22 and v22 > 0 then
				v_u_31.Parent = v23
				v_u_28.State.Attacks[v_u_31] = {
					["Kind"] = "Bits",
					["Pos"] = p11,
					["Size"] = v_u_31.AbsoluteSize,
					["Dmg"] = v22,
					["Destroy"] = function()
						-- upvalues: (copy) v_u_28, (copy) v_u_31
						v_u_28.State.Attacks[v_u_31] = nil
						if v_u_31 then
							v_u_31:Destroy()
						end
					end
				}
			else
				v_u_28.State.Visuals[v_u_31] = {
					["Kind"] = p9,
					["Size"] = Vector2.new(v_u_31.AbsoluteSize.X, v_u_31.AbsoluteSize.Y),
					["Pos"] = p11,
					["AbsPos"] = v_u_2.centerAbs(v_u_31),
					["AbsSize"] = v_u_31.AbsoluteSize,
					["Destroy"] = function()
						-- upvalues: (copy) v_u_28, (copy) v_u_31
						v_u_28.State.Visuals[v_u_31] = nil
						if v_u_31 then
							v_u_31:Destroy()
						end
					end
				}
			end
		end
	end
	v_u_6.Compute[v_u_28.UUID] = function(p37)
		-- upvalues: (copy) v_u_28, (ref) v_u_2, (copy) v_u_15
		if not v_u_28.Alive then
			return
		end
		local v38 = v_u_2.toSec(p37)
		local v39 = v_u_2.unitScale(v_u_28.Contents, v_u_28.State.Arena.BaselineMin)
		local v40 = v_u_28
		v40.Time = v40.Time + v38
		local v41, v42, v43 = v_u_2.getDeadzoneRect(v_u_28.Contents)
		local v44 = v_u_2.centerAbs(v_u_28.Contents)
		local v45 = v_u_15 * v39 * v38
		local v46 = v_u_2.roundpx
		local v47 = v_u_28.Guis
		local v48 = v_u_28.Pos
		local v49 = v_u_28.Vel
		local v50 = v_u_28.Rot
		local v51 = v_u_28.Spin
		local v52 = v_u_28.State and v_u_28.State.Visuals or nil
		local v53 = v_u_28.State and v_u_28.State.Attacks or nil
		v_u_28._gSize = v_u_28._gSize or {}
		for v54 = #v47, 1, -1 do
			local v55 = v47[v54]
			if v55 then
				local v56 = v48[v54]
				local v57 = v49[v54]
				local v58 = v57.Y + v45
				local v59 = Vector2.new(v57.X, v58)
				local v60 = Vector2.new(v56.X + v59.X * v38, v56.Y + v58 * v38)
				local v61 = v60 - v41
				local v62 = v61.X
				if v42 < math.abs(v62) then
					::l17::
					local v63 = v_u_28.Kill[v55]
					if v63 then
						v63()
					else
						if v52 and v52[v55] then
							v52[v55] = nil
						end
						if v53 and v53[v55] then
							v53[v55] = nil
						end
						v55:Destroy()
						table.remove(v47, v54)
						table.remove(v48, v54)
						table.remove(v49, v54)
						table.remove(v50, v54)
						table.remove(v51, v54)
					end
				else
					local v64 = v61.Y
					if v43 < math.abs(v64) then
						goto l17
					end
					v48[v54] = v60
					v49[v54] = v59
					local v65 = v51[v54]
					if v65 ~= 0 then
						local v66 = v50[v54] + v65 * v38
						v50[v54] = v66
						v55.Rotation = v66
					end
					v55.Position = UDim2.new(0.5, v46(v60.X), 0.5, v46(v60.Y))
					local v67 = v52 and v52[v55]
					if v67 then
						v67.Pos = v60
						v67.AbsPos = Vector2.new(v44.X + v60.X, v44.Y + v60.Y)
						local v68 = v_u_28._gSize[v55]
						if not v68 then
							v68 = v55.AbsoluteSize
							v_u_28._gSize[v55] = v68
						end
						v67.AbsSize = v68
					end
					if v53 then
						local v69 = v53[v55]
						if v69 then
							v69.Pos = v60
							local v70 = v_u_28._gSize[v55]
							if not v70 then
								v70 = v55.AbsoluteSize
								v_u_28._gSize[v55] = v70
							end
							v69.Size = v70
						end
					end
				end
			else
				table.remove(v47, v54)
				table.remove(v48, v54)
				table.remove(v49, v54)
				table.remove(v50, v54)
				table.remove(v51, v54)
			end
		end
		if v_u_28.Time >= v_u_28.TTL or #v47 == 0 then
			v_u_28:Destroy()
		end
	end
	return v_u_28
end
function v_u_6.Destroy(p71)
	-- upvalues: (copy) v_u_6
	if p71.Alive then
		p71.Alive = false
		if p71.UUID and v_u_6.Compute[p71.UUID] then
			v_u_6.Compute[p71.UUID] = nil
		end
		for v72 = 1, #p71.Guis do
			local v73 = p71.Guis[v72]
			if v73 then
				if p71.State and (p71.State.Visuals and p71.State.Visuals[v73]) then
					p71.State.Visuals[v73] = nil
				end
				if p71.State and (p71.State.Attacks and p71.State.Attacks[v73]) then
					p71.State.Attacks[v73] = nil
				end
				v73:Destroy()
			end
		end
		table.clear(p71)
		setmetatable(p71, nil)
	end
end
function v_u_6.Step(p74)
	-- upvalues: (copy) v_u_6
	for _, v75 in pairs(v_u_6.Compute) do
		v75(p74)
	end
end
return v_u_6