-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("SoundService")
local v_u_296 = {
	["toFrame"] = function(p2, p3, p4)
		return math.clamp(p2, p3 or 0.004166666666666667, p4 or 0.06) * 60
	end,
	["toSec"] = function(p5, p6, p7)
		local v8 = p6 or 0.004166666666666667
		local v9 = p7 or 0.06
		local v10 = p5 / 60
		if v10 < v8 then
			return v8
		elseif v9 < v10 then
			return v9
		else
			return v10
		end
	end,
	["easeInQuad"] = function(p11)
		local v12 = math.clamp(p11, 0, 1)
		return v12 * v12
	end,
	["easeOutQuad"] = function(p13)
		local v14 = math.clamp(p13, 0, 1)
		return 1 - (1 - v14) * (1 - v14)
	end,
	["easeInOutQuad"] = function(p15)
		local v16 = math.clamp(p15, 0, 1)
		if v16 < 0.5 then
			return v16 * 2 * v16
		else
			return 1 - (v16 * -2 + 2) ^ 2 / 2
		end
	end,
	["easeInCubic"] = function(p17)
		local v18 = math.clamp(p17, 0, 1)
		return v18 * v18 * v18
	end,
	["easeOutCubic"] = function(p19)
		return 1 - (1 - math.clamp(p19, 0, 1)) ^ 3
	end,
	["easeInOutCubic"] = function(p20)
		local v21 = math.clamp(p20, 0, 1)
		if v21 < 0.5 then
			return v21 ^ 3 * 4
		else
			return 1 - (v21 * -2 + 2) ^ 3 / 2
		end
	end,
	["easeInQuart"] = function(p22)
		return math.clamp(p22, 0, 1) ^ 4
	end,
	["easeOutQuart"] = function(p23)
		return 1 - (1 - math.clamp(p23, 0, 1)) ^ 4
	end,
	["easeInOutQuart"] = function(p24)
		local v25 = math.clamp(p24, 0, 1)
		if v25 < 0.5 then
			return v25 ^ 4 * 8
		else
			return 1 - (v25 * -2 + 2) ^ 4 / 2
		end
	end,
	["easeInQuint"] = function(p26)
		return math.clamp(p26, 0, 1) ^ 5
	end,
	["easeOutQuint"] = function(p27)
		return 1 - (1 - math.clamp(p27, 0, 1)) ^ 5
	end,
	["easeInOutQuint"] = function(p28)
		local v29 = math.clamp(p28, 0, 1)
		if v29 < 0.5 then
			return v29 ^ 5 * 16
		else
			return 1 - (v29 * -2 + 2) ^ 5 / 2
		end
	end,
	["easeInSine"] = function(p30)
		local v31 = math.clamp(p30, 0, 1) * 3.141592653589793 / 2
		return 1 - math.cos(v31)
	end,
	["easeOutSine"] = function(p32)
		local v33 = math.clamp(p32, 0, 1) * 3.141592653589793 / 2
		return math.sin(v33)
	end,
	["easeInOutSine"] = function(p34)
		local v35 = 3.141592653589793 * math.clamp(p34, 0, 1)
		return -(math.cos(v35) - 1) / 2
	end,
	["easeInExpo"] = function(p36)
		local v37 = math.clamp(p36, 0, 1)
		return v37 == 0 and 0 or 2 ^ (v37 * 10 - 10)
	end,
	["easeOutExpo"] = function(p38)
		local v39 = math.clamp(p38, 0, 1)
		return v39 == 1 and 1 or 1 - 2 ^ (v39 * -10)
	end,
	["easeInOutExpo"] = function(p40)
		local v41 = math.clamp(p40, 0, 1)
		if v41 == 0 then
			return 0
		elseif v41 == 1 then
			return 1
		elseif v41 < 0.5 then
			return 2 ^ (v41 * 20 - 10) / 2
		else
			return (2 - 2 ^ (v41 * -20 + 10)) / 2
		end
	end,
	["easeInCirc"] = function(p42)
		local v43 = math.clamp(p42, 0, 1)
		local v44 = 1 - v43 * v43
		return 1 - math.sqrt(v44)
	end,
	["easeOutCirc"] = function(p45)
		local v46 = 1 - (math.clamp(p45, 0, 1) - 1) ^ 2
		return math.sqrt(v46)
	end,
	["easeInOutCirc"] = function(p47)
		local v48 = math.clamp(p47, 0, 1)
		if v48 < 0.5 then
			local v49 = 1 - (v48 * 2) ^ 2
			return (1 - math.sqrt(v49)) / 2
		else
			local v50 = 1 - (v48 * -2 + 2) ^ 2
			return (math.sqrt(v50) + 1) / 2
		end
	end,
	["easeInBack"] = function(p51, p52)
		local v53 = p52 or 1.70158
		local v54 = math.clamp(p51, 0, 1)
		return (v53 + 1) * v54 ^ 3 - v53 * v54 ^ 2
	end,
	["easeOutBack"] = function(p55, p56)
		local v57 = p56 or 1.70158
		local v58 = math.clamp(p55, 0, 1) - 1
		return 1 + (v57 + 1) * v58 ^ 3 + v57 * v58 ^ 2
	end,
	["easeInOutBack"] = function(p59, p60)
		local v61 = (p60 or 1.70158) * 1.525
		local v62 = math.clamp(p59, 0, 1)
		if v62 < 0.5 then
			return (v62 * 2) ^ 2 * ((v61 + 1) * (v62 * 2) - v61) / 2
		end
		local v63 = v62 * 2 - 2
		return (v63 ^ 2 * ((v61 + 1) * v63 + v61) + 2) / 2
	end,
	["expSmoothing"] = function(p64, p65)
		local v66 = -(p65 or 1) * p64
		return 1 - math.exp(v66)
	end,
	["gridCenters"] = function(p67, p68, p69, p70, p71)
		-- upvalues: (copy) v_u_296
		local v72 = math.floor(p68)
		local v73 = math.max(1, v72)
		local v74 = math.floor(p69)
		local v75 = math.max(1, v74)
		local v76 = math.max(0, p70 or 0)
		local v77 = p67.AbsoluteSize
		local v78 = v77.X - 2 * v76
		local v79 = math.max(0, v78)
		local v80 = v77.Y - 2 * v76
		local v81 = math.max(0, v80)
		local v82 = v79 / v75
		local v83 = v81 / v73
		local v84 = {}
		for v85 = 1, v73 do
			local v86 = -v81 * 0.5 + (v85 - 0.5) * v83
			for v87 = 1, v75 do
				local v88 = -v79 * 0.5 + (v87 - 0.5) * v82
				local v89
				if p71 and p71 > 0 then
					v89 = v_u_296.snapMultiple(v88, p71)
					v86 = v_u_296.snapMultiple(v86, p71)
				else
					v89 = v_u_296.roundpx(v88)
					v86 = v_u_296.roundpx(v86)
				end
				local v90 = Vector2.new
				table.insert(v84, v90(v89, v86))
			end
		end
		return v84
	end,
	["snapMultiple"] = function(p91, p92)
		if p92 <= 0 then
			return p91
		end
		local v93 = p91 / p92
		if v93 >= 0 then
			local v94 = v93 + 0.5
			v96 = math.floor(v94)
			if v96 then
				::l5::
				return v96 * p92
			end
		end
		local v95 = v93 - 0.5
		local v96 = math.ceil(v95)
		goto l5
	end,
	["unitScale"] = function(p97)
		local v98 = p97.AbsoluteSize
		local v99 = v98.X / 500
		local v100 = v98.Y / 200
		return math.max(v99, v100)
	end,
	["dirToRotation"] = function(p101)
		local v102 = p101.Y
		local v103 = p101.X
		local v104 = math.atan2(v102, v103)
		return math.deg(v104) + 90
	end,
	["dirFromAngle"] = function(p105)
		local v106 = math.rad(p105)
		return Vector2.new(math.cos(v106), (math.sin(v106)))
	end,
	["edgeDistanceToRectAlong"] = function(p107, p108, p109, p110)
		local v111 = (1 / 0)
		local v112 = p108.X
		local v113
		if math.abs(v112) > 1e-6 then
			v113 = ((p108.X > 0 and p109 and p109 or -p109) - p107.X) / p108.X
			if v113 >= 0 then
				local v114 = p107.Y + p108.Y * v113
				if math.abs(v114) <= p110 + 0.0001 then
					if v113 >= v111 then
						v113 = v111
					end
				else
					v113 = v111
				end
			else
				v113 = v111
			end
		else
			v113 = v111
		end
		local v115 = p108.Y
		local v116
		if math.abs(v115) > 1e-6 then
			v116 = ((p108.Y > 0 and p110 and p110 or -p110) - p107.Y) / p108.Y
			if v116 >= 0 then
				local v117 = p107.X + p108.X * v116
				if math.abs(v117) <= p109 + 0.0001 then
					if v116 >= v113 then
						v116 = v113
					end
				else
					v116 = v113
				end
			else
				v116 = v113
			end
		else
			v116 = v113
		end
		if v116 == (1 / 0) then
			v116 = math.max(p109, p110)
		end
		return v116
	end,
	["parkAndStartForRay"] = function(p118, p119, p120, p121, p122)
		-- upvalues: (copy) v_u_296
		local v123 = p118.AbsoluteSize.X * 0.5
		local v124 = p118.AbsoluteSize.Y * 0.5
		local v125 = p119 - p120 * (v_u_296.edgeDistanceToRectAlong(p119, -p120, v123, v124) + p121)
		if not p122 then
			local v126 = p118.AbsoluteSize.X
			local v127 = p118.AbsoluteSize.Y
			p122 = math.max(v126, v127) * 0.75 + 200
		end
		return v125, v125 - p120 * p122
	end,
	["sharedIndicatorRadii"] = function(p128, p129, p130, p131)
		-- upvalues: (copy) v_u_296
		local v132 = p128.AbsoluteSize.X * 0.5
		local v133 = p128.AbsoluteSize.Y * 0.5
		local v134 = {
			Vector2.new(-1, -1).Unit,
			Vector2.new(1, -1).Unit,
			Vector2.new(-1, 1).Unit,
			Vector2.new(1, 1).Unit
		}
		local v135 = 0
		for v136 = 1, 4 do
			local v137 = v134[v136]
			local v138 = v_u_296.edgeDistanceToRectAlong(p129, -v137, v132, v133)
			if v135 < v138 then
				v135 = v138
			end
		end
		local v139 = v135 + p130
		return v134, v139, v139 + p131
	end,
	["centerAbs"] = function(p140)
		local v141 = p140.AbsolutePosition
		local v142 = p140.AbsoluteSize
		return Vector2.new(v141.X + v142.X * 0.5, v141.Y + v142.Y * 0.5)
	end,
	["absToCenteredOffset"] = function(p143, p144)
		local v145 = p143 - p144.AbsolutePosition - p144.AbsoluteSize * 0.5
		if v145.X >= 0 then
			local v146 = v145.X + 0.5
			v151 = math.floor(v146)
			if v151 then
				::l3::
				if v145.Y >= 0 then
					local v147 = v145.Y + 0.5
					v149 = math.floor(v147)
					if v149 then
						::l6::
						return Vector2.new(v151, v149)
					end
				end
				local v148 = v145.Y - 0.5
				local v149 = math.ceil(v148)
				goto l6
			end
		end
		local v150 = v145.X - 0.5
		local v151 = math.ceil(v150)
		goto l3
	end,
	["roundpx"] = function(p152)
		if p152 >= 0 then
			local v153 = p152 + 0.5
			v155 = math.floor(v153)
			if v155 then
				::l3::
				return v155
			end
		end
		local v154 = p152 - 0.5
		local v155 = math.ceil(v154)
		goto l3
	end,
	["snapToGrid"] = function(p156, p157, p158)
		local v159 = (not p157 or (p157 == 0 or not p157)) and 1 or p157
		local v160 = p158 or 0
		local v161 = (p156 - v160) / v159
		if v161 >= 0 then
			local v162 = v161 + 0.5
			v164 = math.floor(v162)
			if v164 then
				::l7::
				return v160 + v164 * v159
			end
		end
		local v163 = v161 - 0.5
		local v164 = math.ceil(v163)
		goto l7
	end,
	["snapV2ToGrid"] = function(p165, p166, p167, p168)
		-- upvalues: (copy) v_u_296
		local v169 = p168 or Vector2.zero
		return Vector2.new(v_u_296.snapToGrid(p165.X, p166, v169.X), v_u_296.snapToGrid(p165.Y, p167, v169.Y))
	end,
	["snapUDim2Offset"] = function(p170, p171, p172, p173)
		-- upvalues: (copy) v_u_296
		local v174 = p173 or Vector2.zero
		return UDim2.new(p170.X.Scale, v_u_296.snapToGrid(p170.X.Offset, p171, v174.X), p170.Y.Scale, v_u_296.snapToGrid(p170.Y.Offset, p172, v174.Y))
	end,
	["resolveEffectFolders"] = function(p175)
		return p175:FindFirstChild("Attacks"), p175:FindFirstChild("Visuals")
	end,
	["getDeadzoneRect"] = function(p176)
		-- upvalues: (copy) v_u_296
		local v177 = p176:FindFirstChild("_Deadzone")
		if not (v177 and v177:IsA("GuiObject")) then
			local v178 = p176.AbsoluteSize
			return Vector2.zero, v178.X * 0.5, v178.Y * 0.5
		end
		local v179 = v_u_296.centerAbs(p176)
		local v180 = v_u_296.centerAbs(v177) - v179
		local v181 = v177.AbsoluteSize
		return v180, v181.X * 0.5, v181.Y * 0.5
	end,
	["rayHitRectEdge"] = function(p182, p183, p184, p185, p186)
		local v187 = (1 / 0)
		local v188 = nil
		local v189 = p183.X
		local v190
		if math.abs(v189) > 1e-6 then
			local v191 = p183.X > 0 and p184 and p184 or -p184
			v190 = (v191 - p182.X) / p183.X
			if v190 >= 0 then
				local v192 = p182.Y + p183.Y * v190
				if math.abs(v192) <= p185 + 0.0001 and v190 < v187 then
					v188 = Vector2.new(v191, v192)
				else
					v190 = v187
				end
			else
				v190 = v187
			end
		else
			v190 = v187
		end
		local v193 = p183.Y
		if math.abs(v193) > 1e-6 then
			local v194 = p183.Y > 0 and p185 and p185 or -p185
			local v195 = (v194 - p182.Y) / p183.Y
			if v195 >= 0 then
				local v196 = p182.X + p183.X * v195
				if math.abs(v196) <= p184 + 0.0001 and v195 < v190 then
					v188 = Vector2.new(v196, v194)
				end
			end
		end
		return (v188 or p182 + p183.Unit * math.max(p184, p185)) + p183.Unit * (p186 or 0)
	end,
	["rayHitDeadzoneEdge"] = function(p197, p198, p199, p200)
		-- upvalues: (copy) v_u_296
		local v201, v202, v203 = v_u_296.getDeadzoneRect(p199)
		local v204 = p197 - v201
		return v_u_296.rayHitRectEdge(v204, p198, v202, v203, p200) + v201
	end,
	["setRotAndCacheAabb"] = function(p205, p206)
		-- upvalues: (copy) v_u_296
		p205.Rot = p206
		local v207 = not (p205.AbsSize and p205.AbsSize.X) and p205.Size
		if v207 then
			v207 = p205.Size.X
		end
		local v208 = not (p205.AbsSize and p205.AbsSize.Y) and p205.Size
		if v208 then
			v208 = p205.Size.Y
		end
		if v207 and v208 then
			local v209, v210 = v_u_296.rotAabbHalf(0.5 * v207, 0.5 * v208, p206)
			p205._rHx = v209
			p205._rHy = v210
			local v211 = v209 * v209 + v210 * v210
			p205._broadR = math.sqrt(v211)
		end
	end,
	["rotAabbHalf"] = function(p212, p213, p214)
		local v215 = math.rad(p214)
		local v216 = math.cos(v215)
		local v217 = math.sin(v215)
		return math.abs(v216) * p212 + math.abs(v217) * p213, math.abs(v217) * p212 + math.abs(v216) * p213
	end,
	["axesFromDeg"] = function(p218)
		local v219 = math.rad(p218)
		local v220 = math.cos(v219)
		local v221 = math.sin(v219)
		return v220, v221, -v221, v220
	end,
	["computeBroadRadius"] = function(p222, p223)
		if p222._broadR then
			return p222._broadR
		end
		local v224
		if p222.Radius then
			v224 = p222.Radius
		elseif p222.Size then
			local v225 = p222.Size.X * 0.5
			local v226 = p222.Size.Y * 0.5
			local v227 = v225 * v225 + v226 * v226
			v224 = math.sqrt(v227)
		elseif p222.AbsSize then
			local v228 = p222.AbsSize.X * 0.5
			local v229 = p222.AbsSize.Y * 0.5
			local v230 = v228 * v228 + v229 * v229
			v224 = math.sqrt(v230)
		else
			local v231 = p223 * 2
			local v232 = p222.Minor or 2
			local v233 = math.max(2, v232) * 0.5
			local v234 = (v231 * 0.5) ^ 2 + v233 * v233
			v224 = math.sqrt(v234)
		end
		p222._broadR = v224
		return v224
	end,
	["setAttackRotation"] = function(p235, p236)
		-- upvalues: (copy) v_u_296
		p235.Rot = p236
		local v237, v238, v239, v240 = v_u_296.axesFromDeg(p236)
		p235._ux = v237
		p235._uy = v238
		p235._vx = v239
		p235._vy = v240
	end,
	["touchAttackSize"] = function(p241)
		p241._broadR = nil
	end,
	["intersectsAabbObb"] = function(p242, p243, p244, p245, p246, p247, p248)
		local v249 = math.rad(p248)
		local v250 = math.cos(v249)
		local v251 = math.sin(v249)
		local v252 = -v251
		local v253 = p242.X - p245.X
		local v254 = p242.Y - p245.Y
		local v255 = v253 * 1 + v254 * 0
		local v256 = math.abs(v255)
		local v257 = p243 * 1 + p244 * 0
		local v258 = 1 * v250 + 0 * v251
		local v259 = p246 * math.abs(v258)
		local v260 = 1 * v252 + 0 * v250
		local v261 = v256 <= v257 + (v259 + p247 * math.abs(v260))
		if v261 then
			local v262 = v253 * 0 + v254 * 1
			local v263 = math.abs(v262)
			local v264 = p243 * 0 + p244 * 1
			local v265 = 0 * v250 + 1 * v251
			local v266 = p246 * math.abs(v265)
			local v267 = 0 * v252 + 1 * v250
			v261 = v263 <= v264 + (v266 + p247 * math.abs(v267))
			if v261 then
				local v268 = v253 * v250 + v254 * v251
				local v269 = math.abs(v268)
				local v270 = p243 * math.abs(v250) + p244 * math.abs(v251)
				local v271 = v250 * v250 + v251 * v251
				local v272 = p246 * math.abs(v271)
				local v273 = v250 * v252 + v251 * v250
				v261 = v269 <= v270 + (v272 + p247 * math.abs(v273))
				if v261 then
					local v274 = v253 * v252 + v254 * v250
					local v275 = math.abs(v274)
					local v276 = p243 * math.abs(v252) + p244 * math.abs(v250)
					local v277 = v252 * v250 + v250 * v251
					local v278 = p246 * math.abs(v277)
					local v279 = v252 * v252 + v250 * v250
					v261 = v275 <= v276 + (v278 + p247 * math.abs(v279))
				end
			end
		end
		return v261
	end,
	["intersectsAabbCircle"] = function(p280, p281, p282, p283, p284)
		local v285 = p283.X - p280.X
		local v286 = math.abs(v285)
		local v287 = p283.Y - p280.Y
		local v288 = math.abs(v287)
		if p281 + p284 < v286 or p282 + p284 < v288 then
			return false
		end
		if v286 <= p281 or v288 <= p282 then
			return true
		end
		local v289 = v286 - p281
		local v290 = v288 - p282
		return v289 * v289 + v290 * v290 <= p284 * p284
	end,
	["scaleUDim2"] = function(p291, p292)
		return UDim2.new(p291.X.Scale * p292, p291.X.Offset * p292, p291.Y.Scale * p292, p291.Y.Offset * p292)
	end,
	["randomChild"] = function(p293)
		if p293:IsA("Folder") then
			local v294 = p293:GetChildren()
			local v295 = #v294
			if v295 == 0 then
				return nil
			else
				return v294[math.random(1, v295)]
			end
		else
			return p293
		end
	end
}
local v_u_297 = {}
function v_u_296.playLocalSound(p298, p299)
	-- upvalues: (copy) v_u_1, (copy) v_u_297
	local v300 = p298:FindFirstChild(p299)
	if v300 and v300:IsA("Sound") then
		local v_u_301 = v300:Clone()
		v_u_301.SoundGroup = v_u_1.Effect
		v_u_301.Parent = v_u_1
		v_u_301:Play()
		local v302 = v_u_297
		table.insert(v302, v_u_301)
		local v_u_303 = #v_u_297
		task.delay(v_u_301.PlaybackRegion.Max - v_u_301.PlaybackRegion.Min, function()
			-- upvalues: (ref) v_u_297, (copy) v_u_303, (copy) v_u_301
			table.remove(v_u_297, v_u_303)
			if v_u_301 then
				v_u_301:Destroy()
			end
		end)
	end
end
function v_u_296.stopLocalSounds()
	-- upvalues: (copy) v_u_297
	for _, v304 in ipairs(v_u_297) do
		v304:Destroy()
	end
end
return v_u_296