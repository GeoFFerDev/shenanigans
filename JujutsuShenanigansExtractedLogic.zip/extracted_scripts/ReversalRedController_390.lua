-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "ReversalRedController"
})
function v9.KnitStart(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_2, (ref) v_u_7
	local v_u_20 = {
		["Red"] = function(p10, p11)
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_3
			local v12 = p10:FindFirstChild("HumanoidRootPart")
			if v12 then
				v_u_8:PlaySound(v_u_6.Gojo.ReversalRed.Wind, v12, game.SoundService.Effect)
				v_u_3:Create(p11, TweenInfo.new(0.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
					["Size"] = Vector3.new(0.9, 0.9, 0.9)
				}):Play()
				v_u_3:Create(p11.Center.Light, TweenInfo.new(0.5), {
					["Brightness"] = 40,
					["Range"] = 8
				}):Play()
				v_u_3:Create(p11.Center.Charge, TweenInfo.new(0.3), {
					["Rate"] = 40,
					["TimeScale"] = 1
				}):Play()
				task.wait(0.3)
				p11.Center.Charge.Enabled = false
				v_u_3:Create(p11.Center.Light, TweenInfo.new(0.6, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
					["Range"] = 16
				}):Play()
				task.wait(0.2)
				v_u_8:PlaySound(v_u_6.Gojo.ReversalRed.Throw, v12, game.SoundService.Effect)
			end
		end,
		["Explode"] = function(p13)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_3, (ref) v_u_8, (ref) v_u_6
			local v14 = v_u_5.Gojo.ReversalRed.RedExplode:Clone()
			v14.Position = p13
			v14.Parent = workspace.Effects
			v_u_2:AddItem(v14, 2)
			v14.Burst:Emit(1)
			v14.Sparks:Emit(15)
			v14.Wind:Emit(6)
			v14.Dust:Emit(6)
			v_u_3:Create(v14.Light, TweenInfo.new(0.5), {
				["Brightness"] = 0
			}):Play()
			v_u_8:PlaySound(v_u_6.Gojo.ReversalRed.Explode, v14, game.SoundService.Effect)
		end,
		["Finisher"] = function(p15)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_8
			if p15.HumanoidRootPart then
				if _G.Settings.Gore then
					local v16 = v_u_5.Heian.BloodSpread:Clone()
					v16.Parent = p15.Head
					v16:Emit(20)
					v_u_2:AddItem(v16, 2)
				end
				v_u_8:Bleed(p15)
			end
		end,
		["Flip"] = function(p17, p18)
			-- upvalues: (ref) v_u_3, (ref) v_u_8, (ref) v_u_6
			local v19 = p17.HumanoidRootPart
			if v19 then
				p18.Flip.Sparks1.Enabled = true
				p18.Flip.Sparks2.Enabled = true
				p18.Flip.Charging.Enabled = true
				p18.Flip.Wind.Enabled = true
				p18.Flip.Wind2:Emit(7)
				v_u_3:Create(p18.Flip.Wind2, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["TimeScale"] = 0.05
				}):Play()
				v_u_8:PlaySound(v_u_6.Gojo.RedFlip, v19, game.SoundService.Voice)
			end
		end
	}
	v_u_7.Effects:Connect(function(p21, ...)
		-- upvalues: (copy) v_u_20
		local v22 = v_u_20[p21]
		if v22 then
			v22(...)
		end
	end)
end
function v9.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("ReversalRedService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v9