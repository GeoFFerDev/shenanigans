-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.SraikoVFX)
local _ = v_u_9.Enabled
local v_u_10 = v_u_9.Emit
local v_u_11 = v_u_9.EmitMesh
local v_u_12 = v_u_6.Mechamaru.MiracleCannonVFX
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v16 = v_u_1.CreateController({
	["Name"] = "MiracleCannonController"
})
function v16.KnitStart(_)
	-- upvalues: (copy) v_u_10, (copy) v_u_12, (copy) v_u_9, (ref) v_u_15, (copy) v_u_7, (copy) v_u_3, (copy) v_u_11, (copy) v_u_4, (copy) v_u_8, (copy) v_u_2, (copy) v_u_6, (ref) v_u_13
	local v_u_55 = {
		["Charge"] = function(p17)
			-- upvalues: (ref) v_u_10, (ref) v_u_12, (ref) v_u_9, (ref) v_u_15, (ref) v_u_7
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 and p17:FindFirstChild("Torso") then
				v_u_10(v_u_12.Start.Strike, v18, true, 5, CFrame.new(0, 9, -0.5))
				local v19 = v_u_12.CHARGECVFX:Clone()
				v19.Parent = v18
				v_u_9.Enabled(v19, true, nil, nil, 3)
				task.delay(0.817, v_u_9.Enabled, v19, false)
				v_u_15:PlaySound(v_u_7.Mechamaru.MiracleCannon.AttemptCharge, v18, game.SoundService.Effect)
			end
		end,
		["Charge2"] = function(p20)
			-- upvalues: (ref) v_u_10, (ref) v_u_12, (ref) v_u_9, (ref) v_u_15, (ref) v_u_7, (ref) v_u_3
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 and p20:FindFirstChild("Torso") then
				v_u_10(v_u_12.Start2.Strike, v21, true, 5, CFrame.new(0, 9, -0.5))
				local v22 = v_u_12.CHARGECVFX2:Clone()
				v22.Parent = v21
				v_u_9.Enabled(v22, true, nil, nil, 3)
				task.delay(0.316, v_u_9.Enabled, v22, false)
				v_u_15:PlaySound(v_u_7.Mechamaru.MiracleCannon.AttemptChargePhase, v21, game.SoundService.Effect)
				v_u_3:Create(v_u_15:PlaySound(v_u_7.Mechamaru.MiracleCannon.ChargeBeam, v21, game.SoundService.Effect), TweenInfo.new(1), {
					["Volume"] = 0
				}):Play()
			end
		end,
		["Push"] = function(p23)
			-- upvalues: (ref) v_u_11, (ref) v_u_12
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				v_u_11(v_u_12.Push.Mesh, v24.CFrame * v_u_12.Push.Mesh.Offset.Value)
			end
		end,
		["ShootBeam"] = function(p25)
			-- upvalues: (ref) v_u_10, (ref) v_u_12, (ref) v_u_11
			local v26 = p25:FindFirstChild("HumanoidRootPart")
			if v26 and p25:FindFirstChild("Torso") then
				v_u_10(v_u_12.Shoot.Strike, v26, true, 5, CFrame.new(0, 9, -0.5))
				v_u_11(v_u_12.Shoot.Mesh, v26.CFrame * v_u_12.Shoot.Mesh.Offset.Value)
			end
		end,
		["Explode"] = function(p27, p28)
			-- upvalues: (ref) v_u_10, (ref) v_u_12, (ref) v_u_11, (ref) v_u_4, (ref) v_u_8, (ref) v_u_15, (ref) v_u_7
			if p27:FindFirstChild("HumanoidRootPart") then
				v_u_10(v_u_12.ExplodeVFX.VFX, CFrame.new(p28.Position), false, 5)
				v_u_11(v_u_12.ExplodeVFX.Mesh, CFrame.new(p28.Position))
				if v_u_4.Character == p27 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				v_u_15:PlaySound(v_u_7.Mechamaru.MiracleCannon.Explosion, p28, game.SoundService.Effect)
			end
		end,
		["OneYearCharge"] = function(p29)
			-- upvalues: (ref) v_u_15, (ref) v_u_7
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_15:PlaySound(v_u_7.Mechamaru.MiracleCannon.OneYearCharge, v30, game.SoundService.Effect)
			end
		end,
		["1YearEnabled"] = function(p31)
			-- upvalues: (ref) v_u_12, (ref) v_u_9
			if p31 then
				p31 = p31:FindFirstChild("Right Arm")
			end
			if p31 then
				local v32 = v_u_12.CHARGECVFX2:Clone()
				v32.CFrame = CFrame.new(0.81, -6.351, -0.374)
				v32.Parent = p31
				v_u_9.Enabled(v32, true, nil, nil, 3)
				task.delay(0.297, v_u_9.Enabled, v32, false)
			end
		end,
		["1YearExplode"] = function(p33, p34, _, p35, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_11, (ref) v_u_4, (ref) v_u_8, (ref) v_u_15, (ref) v_u_7
			local v36 = p33:FindFirstChild("HumanoidRootPart")
			if v36 then
				local v37 = v_u_12.BeamForShoot:Clone()
				for _, v38 in v37:GetChildren() do
					local v39 = v38.Size.X
					local v40 = v38.Size.Y
					local v41 = p35 + 7
					v38.Size = vector.create(v39, v40, v41)
					v38.Size = v38.Size * Vector3.new(3, 3, 1)
				end
				v37:PivotTo(p34 + p34.LookVector * (p35 / 2 + 7))
				v37.Parent = workspace.Effects
				v_u_2:AddItem(v37, 1)
				local v42 = next
				local v43, v44 = v37:GetChildren()
				for _, v45 in v42, v43, v44 do
					local v46 = v_u_3
					local v47 = TweenInfo.new(0.35)
					local v48 = {}
					local v49 = v45.Size.Z
					v48.Size = vector.create(0, 0, v49)
					v48.CFrame = v45.CFrame - v45.CFrame.LookVector * 5
					v46:Create(v45, v47, v48):Play()
					v_u_2:AddItem(v45, 0.35)
				end
				v_u_10(v_u_12.OneYear.Shoot.Strike, v36.CFrame * CFrame.new(0, -12, 0), false, 5)
				v_u_11(v_u_12.OneYear.Shoot.Mesh, v36.CFrame * v_u_12.OneYear.Shoot.Mesh.Offset.Value)
				if v_u_4.Character == p33 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				local v50 = Instance.new("Part")
				v50.Anchored = true
				v50.CanCollide = false
				v50.CanCollide = false
				v50.CFrame = p34 + p34.LookVector * (p35 / 2)
				v50.Transparency = 1
				v50.Parent = workspace.Effects
				v_u_2:AddItem(v50, 3)
				v_u_15:PlaySound(v_u_7.Mechamaru.MiracleCannon.OneYearExplosion, v50, game.SoundService.Effect, true)
			end
		end,
		["1YearHit"] = function(p51, p52)
			-- upvalues: (ref) v_u_15, (ref) v_u_6
			if p51:FindFirstChild("HumanoidRootPart") then
				if p52 then
					v_u_15:Burn(p51)
				end
				for _, v53 in p51:GetChildren() do
					if v53:IsA("BasePart") then
						local v_u_54 = v_u_6.Damage.Flames:Clone()
						v_u_54.Parent = v53
						if not p52 then
							task.delay(1.3, function()
								-- upvalues: (copy) v_u_54
								v_u_54.Enabled = false
							end)
						end
					end
				end
			end
		end
	}
	v_u_13.Effects:Connect(function(p56, ...)
		-- upvalues: (copy) v_u_55
		local v57 = v_u_55[p56]
		if v57 then
			v57(...)
		end
	end)
	local v_u_58 = Random.new()
	v_u_13.Debree:Connect(function(p59, p60)
		-- upvalues: (copy) v_u_58, (ref) v_u_15
		if (workspace.CurrentCamera.CFrame.Position - p60:GetAttribute("WorldPosition")).Magnitude > 100 then
			return
		elseif _G.Settings.DesPHY then
			for _, v61 in p59 do
				local v62 = Instance.new("Part")
				v62.CanCollide = false
				v62.Massless = true
				v62.Position = v61[1]
				v62.Orientation = v61[2]
				v62.Color = v61[3]
				v62.Material = v61[4]
				v62.Size = v61[5]
				v62.Velocity = v_u_58:NextUnitVector() * v_u_58:NextInteger(60, 100)
				local v63 = math.random(-40, 40)
				local v64 = math.random(-40, 40)
				local v65 = math.random
				v62.RotVelocity = Vector3.new(v63, v64, v65(-40, 40))
				v62.Parent = p60
				if math.random(1, 10) == 1 then
					v_u_15:DebreeSound(v62)
				end
			end
		end
	end)
end
function v16.KnitInit(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_1, (ref) v_u_14, (ref) v_u_15
	v_u_13 = v_u_1.GetService("MiracleCannonService")
	v_u_14 = v_u_1.GetController("HitboxController")
	v_u_15 = v_u_1.GetController("FXController")
end
return v16