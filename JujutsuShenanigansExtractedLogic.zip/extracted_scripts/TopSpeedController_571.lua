-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "TopSpeedController"
})
local v_u_13 = nil
local v_u_14 = nil
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_9, (copy) v_u_2, (copy) v_u_5, (ref) v_u_13, (ref) v_u_14, (ref) v_u_10
	local v_u_60 = {
		["Start"] = function(p15)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_11:PlaySound(v_u_8.Naoya.TopSpeed.Startup, v16, game.SoundService.Effect)
				local v_u_17 = v_u_7.Naoya.Air:Clone()
				v_u_17.Parent = p15.Torso
				for _, v18 in v_u_17:GetDescendants() do
					if v18:IsA("Beam") then
						v_u_4:Create(v18, TweenInfo.new(0.5), {
							["Width1"] = 8,
							["TextureSpeed"] = -4
						}):Play()
					end
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_17
					while true do
						for _, v19 in v_u_17:GetDescendants() do
							if v19:IsA("Beam") then
								v19.CurveSize1 = math.random(-60, 60) / 10
							end
						end
						task.wait(0.04)
						if not v_u_17.Parent then
							return
						end
					end
				end)
				task.wait(0.5)
				v_u_3:AddItem(v_u_17, 0.2)
				for _, v20 in v_u_17:GetDescendants() do
					if v20:IsA("Beam") then
						v_u_4:Create(v20, TweenInfo.new(0.2), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
					elseif v20:IsA("ParticleEmitter") then
						v20.Enabled = false
					end
				end
			end
		end,
		["Fly"] = function(p21, p_u_22)
			-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9, (ref) v_u_2, (ref) v_u_5
			local v_u_23 = p21:FindFirstChild("HumanoidRootPart")
			if v_u_23 then
				local v24 = p21:FindFirstChild("Humanoid")
				if v24 then
					task.spawn(function()
						-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_8, (copy) v_u_23, (copy) p_u_22, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9, (ref) v_u_2
						local v25 = v_u_7.Naoya.FlyWind:Clone()
						v25.Parent = workspace.Effects
						v_u_11:PlaySound(v_u_8.Naoya.TopSpeed.Fly, v_u_23, game.SoundService.Effect)
						local v26 = false
						while true do
							local v27 = p_u_22:GetAttribute("Speed") or 1
							if v27 >= 3 and v26 == false then
								v26 = true
								local v28 = v_u_7.Megumi.Mahoraga.WorldSlash.mesh:Clone()
								v28.CFrame = v_u_23.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
								v28.Decal.Transparency = 0
								v28.Mesh.Scale = Vector3.new(2, 50, 2)
								v28.Parent = workspace.Effects
								v_u_4:Create(v28, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
									["Size"] = Vector3.new(80, 40, 80),
									["CFrame"] = v28.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
								}):Play()
								v_u_4:Create(v28.Mesh, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
									["Scale"] = Vector3.new(60, 10, 60)
								}):Play()
								v_u_4:Create(v28.Decal, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
									["Transparency"] = 1
								}):Play()
								v_u_3:AddItem(v28, 1)
								v_u_11:PlaySound(v_u_8.Naoya.TopSpeed.SonicBoom, v_u_23, game.SoundService.Effect)
								if (workspace.CurrentCamera.CFrame.Position - v_u_23.Position).Magnitude < 100 then
									v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
								end
							end
							v25.Trail.Lifetime = 0.6 * v27
							v25.CFrame = CFrame.lookAlong(v_u_23.Position, v_u_23.Velocity)
							v_u_2.Stepped:Wait()
							if not (p_u_22:IsDescendantOf(workspace) and v_u_23.Parent) then
								v_u_3:AddItem(v25, v25.Trail.Lifetime + 0.3)
								for _, v29 in v25:GetDescendants() do
									if v29:IsA("Trail") or v29:IsA("ParticleEmitter") then
										v29.Enabled = false
									end
								end
								return
							end
						end
					end)
					if v_u_5.Character == p21 then
						local v30 = Instance.new("BodyGyro", v_u_23)
						v30.P = 40000
						v30.MaxTorque = Vector3.new(40000, 40000, 40000)
						v24.PlatformStand = true
						repeat
							local v31 = p_u_22:GetAttribute("Speed") or 1
							local v32 = workspace.CurrentCamera
							local v33 = workspace.CurrentCamera.FieldOfView
							local v34 = 70 + 30 * (v31 - 1)
							v32.FieldOfView = math.lerp(v33, v34, 0.15)
							local v35 = v_u_23.Position
							local v36 = workspace.CurrentCamera.CFrame.LookVector
							local v37 = 25 * v31 * 0.8
							p_u_22.Position = v35 + v36 * math.clamp(v37, 25, 75)
							v30.CFrame = CFrame.new(v_u_23.Position, p_u_22.Position)
							v_u_2.Stepped:Wait()
						until not (p_u_22:IsDescendantOf(workspace) and v_u_23.Parent)
						v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(0.4, Enum.EasingStyle.Exponential), {
							["FieldOfView"] = 70
						}):Play()
						v24.PlatformStand = false
						v30:Destroy()
					end
				end
			else
				return
			end
		end,
		["Hit"] = function(p38, p39, _)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v40 = p39:FindFirstChild("HumanoidRootPart")
			if v40 then
				v_u_11:Flash(p38, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Hakari.EnergySurge.Hit1, v40, game.SoundService.Effect)
				local v41 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
				v41.Position = p39.HumanoidRootPart.Position
				v41.Parent = workspace.Effects
				v_u_3:AddItem(v41, 1)
				v41.Sparks.Color = ColorSequence.new(Color3.new(0.666667, 0.666667, 1))
				v41.Wind.Color = v41.Sparks.Color
				v41.Wind2.Color = v41.Sparks.Color
				v41.Sparks:Emit(50)
				v41.Wind:Emit(7)
				v41.Wind2:Emit(7)
				if v_u_5.Character == p38 or v_u_5.Character == p39 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Pass"] = function(p42)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8
			local v43 = v_u_7.Naoya.Pass:Clone()
			v43.CFrame = p42
			v43.Parent = workspace.Effects
			v43.Emit:Emit(1)
			v_u_3:AddItem(v43, 1)
			v_u_11:PlaySound(v_u_8.Naoya.Pass, v43, game.SoundService.Effect)
		end,
		["Track"] = function(p44, p45)
			-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_14, (ref) v_u_2
			local v46 = nil
			local v47
			if p44 then
				v46 = p44:FindFirstChild("HumanoidRootPart")
				v47 = p44
			else
				local v48 = 50
				v47 = nil
				for _, v49 in workspace.Characters:GetChildren() do
					if v49.Name == "FrameNPC" then
						local v50 = (v_u_5.Character:GetPivot().Position - v49:GetPivot().Position).Magnitude
						if v50 < v48 then
							v47 = v49
							v48 = v50
						end
					end
				end
				if v47 then
					v46 = v47:FindFirstChild("HumanoidRootPart")
				else
					v47 = p44
				end
			end
			if not v46 then
				return
			end
			v_u_13 = v47
			local v51 = tick()
			v_u_14 = v51
			while true do
				if false then
					return
				end
				local v52 = v_u_2.RenderStepped:Wait()
				if tick() >= v51 + 0.15 then
					if not (v_u_13 and v_u_13.Parent) then
						break
					end
					local v53
					if v_u_13.Name == "FrameNPC" then
						v53 = 1
						::l18::
						local v54 = p45:GetAttribute("Speed")
						local v55 = CFrame.lookAt(workspace.CurrentCamera.CFrame.Position, v46.Position)
						if v54 >= 3 and v53 > 0.5 then
							workspace.CurrentCamera.CFrame = v55
						else
							local v56 = workspace.CurrentCamera
							local v57 = workspace.CurrentCamera.CFrame
							local v58 = v52 * v54 * 4
							v56.CFrame = v57:Lerp(v55, (math.clamp(v58, 0, 1)))
						end
					else
						local v59 = v47.HumanoidRootPart.CFrame
						v53 = (v46.Position - v59.Position).Unit:Dot(v59.LookVector)
						if v53 >= 0.2 then
							goto l18
						end
					end
				end
				if tick() > v51 + 1.15 or (v_u_13 ~= v47 or (v_u_14 ~= v51 or not (p45 and p45.Parent))) then
					break
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p61, ...)
		-- upvalues: (copy) v_u_60
		local v62 = v_u_60[p61]
		if v62 then
			v62(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("TopSpeedService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12