-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return require(script.Parent.Parent["sleitnick_trove@0.4.2"].trove)