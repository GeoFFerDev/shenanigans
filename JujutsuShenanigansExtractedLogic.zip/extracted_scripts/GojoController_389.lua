-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "GojoController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (copy) v_u_2, (ref) v_u_10, (ref) v_u_11
	local v_u_80 = {
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:Flash(p14, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. p15), v16, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p17, p18)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = p18:FindFirstChild("HumanoidRootPart")
				if v20 then
					v_u_12:Flash(p18, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit3"), v20, game.SoundService.Effect)
					local v21 = v_u_7.ChaseHit:Clone()
					local v22 = CFrame.new
					local v23 = v20.Position
					local v24 = v19.Position.X
					local v25 = v20.Position.Y
					local v26 = v19.Position.Z
					v21.CFrame = v22(v23, (Vector3.new(v24, v25, v26))) * CFrame.Angles(0, 3.141592653589793, 0)
					v21.Parent = workspace.Effects
					v21.Ring:Emit(7)
					v21.Sparks:Emit(12)
					v_u_3:AddItem(v21, 0.5)
				end
			else
				return
			end
		end,
		["AerialHit"] = function(p27, p28)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3
			local v29 = p27:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = p28:FindFirstChild("HumanoidRootPart")
				if v30 then
					v_u_12:Flash(p28, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v30, game.SoundService.Effect)
					if v_u_5.Character == p27 or v_u_5.Character == p28 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
					local v31 = CFrame.new(v29.Position, v30.Position - Vector3.new(0, 4, 0))
					local v32 = v_u_7.Gojo.HardHit:Clone()
					v32.CFrame = v31 + v31.LookVector * 4
					v32.Parent = workspace.Effects
					v32.Dust:Emit(5)
					v32.Ring:Emit(5)
					v32.Sparks:Emit(10)
					v_u_3:AddItem(v32, 0.5)
				end
			else
				return
			end
		end,
		["Teleport"] = function(p33)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_4, (ref) v_u_2
			local v_u_34 = p33:FindFirstChild("HumanoidRootPart")
			if v_u_34 then
				local v_u_35 = v_u_7.Gojo.Teleport:Clone()
				v_u_35.CFrame = v_u_34.CFrame
				v_u_35.Parent = workspace.Effects
				v_u_3:AddItem(v_u_35, 1.1)
				v_u_35.Center.Flash:Emit(1)
				v_u_12:PlaySound(v_u_8.Gojo.Teleport2, v_u_34, game.SoundService.Effect)
				task.delay(0.1, function()
					-- upvalues: (copy) v_u_35, (copy) v_u_34
					v_u_35.Floor.Dust:Emit(30)
					task.wait(0.05)
					v_u_35.CFrame = v_u_34.CFrame
					v_u_35.Lines:Emit(30)
					v_u_35.Floor.Dust:Emit(30)
				end)
				if v_u_5.Character == p33 then
					local v_u_36 = v_u_7.Gojo.TeleportBreak:Clone()
					v_u_36.Parent = workspace.Effects
					v_u_3:AddItem(v_u_36, 0.8)
					local v37 = Instance.new("Highlight")
					v37.OutlineTransparency = 1
					v37.FillColor = Color3.new(1, 1, 1)
					v37.FillTransparency = 0.8
					v37.Parent = v_u_36
					task.delay(0.1, function()
						-- upvalues: (ref) v_u_9, (ref) v_u_12, (ref) v_u_8, (copy) v_u_34, (ref) v_u_7, (copy) v_u_36, (ref) v_u_4, (ref) v_u_2
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
						v_u_12:PlaySound(v_u_8.Gojo.Teleport, v_u_34, game.SoundService.Effect)
						for _ = 1, 30 do
							local v38 = v_u_7.Gojo.Shard:Clone()
							v38.CFrame = v_u_36.Part.CFrame * CFrame.new(math.random(-40, 40) / 10, math.random(-20, 20) / 10, 0)
							v38.CFrame = v38.CFrame * CFrame.Angles(math.random(0, 360), math.random(0, 360), math.random(0, 360))
							v38.Parent = v_u_36.Shards
							v_u_4:Create(v38, TweenInfo.new(math.random(4, 7) / 10), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
							local v39 = v_u_36.Part.CFrame * CFrame.Angles(math.random(0, 30), math.random(-30, 30), 0)
							local v40 = math.random(-5, 5)
							local v41 = math.random(-5, 5)
							local v42 = math.random
							v38.RotVelocity = Vector3.new(v40, v41, v42(-5, 5))
							local v43 = Instance.new("BodyVelocity")
							v43.Archivable = false
							v43.Parent = v38
							v43.Velocity = v39.LookVector * math.random(1, 80) / 10
						end
						while true do
							v_u_36:SetPrimaryPartCFrame(workspace.CurrentCamera.CFrame * CFrame.new(0, 0, -2))
							for _, v44 in v_u_36.Shards:GetChildren() do
								local v45 = v44.BodyVelocity
								v45.Velocity = v45.Velocity - Vector3.new(0, 0.25, 0)
							end
							v_u_2.RenderStepped:Wait()
							if not v_u_36.Parent then
								return
							end
						end
					end)
				end
			end
		end,
		["Chase"] = function(p46)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v47 = p46.HumanoidRootPart
			if v47 then
				local v48 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v48.CFrame = v47.CFrame * CFrame.new(0, 1, -4)
				v48.Size = Vector3.new(0, 0, 2)
				v48.Parent = workspace.Effects
				v_u_4:Create(v48, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v48, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v47, game.SoundService.Effect)
				v_u_12:DustTrail(p46, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p49)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v50 = p49:FindFirstChild("HumanoidRootPart")
			if v50 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v50, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p51, p52, p53)
			-- upvalues: (ref) v_u_12
			if p53 == "Down" then
				v_u_12:ArmFlash(p51["Right Leg"], Color3.fromRGB(85, 255, 255), 0.4)
				return
			elseif p52 == 1 or p52 == 4 then
				v_u_12:ArmFlash(p51["Right Arm"], Color3.fromRGB(85, 255, 255), 0.3)
			else
				v_u_12:ArmFlash(p51["Left Arm"], Color3.fromRGB(85, 255, 255), 0.3)
			end
		end,
		["Launch"] = function(p54, p55)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v56 = p54:FindFirstChild("HumanoidRootPart")
			if v56 then
				local v57 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v57.CFrame = CFrame.new(v56.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v57.Size = Vector3.new(0, 0, 5)
				v57.Parent = workspace.Effects
				v_u_4:Create(v57, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v57.Position + Vector3.new(0, p55, 0)
				}):Play()
				v_u_3:AddItem(v57, 0.3)
				if p55 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v56, game.SoundService.Effect)
					v_u_12:DustBreak(v56.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v56.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Chat"] = function(p58)
			-- upvalues: (ref) v_u_7, (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v59 = p58:FindFirstChild("Torso")
			if v59 then
				local v60 = v_u_7.Gojo.Dialogue:Clone()
				v60.Parent = v59
				v_u_12:PlaySound(v_u_8.Gojo.GrabBlinds, v59, game.SoundService.Effect)
				local v61 = v60.Chat1.Position
				v60.Chat1.Position = v61 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v60.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v61
				}):Play()
				v_u_4:Create(v60.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v60.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.5)
				local v62 = v60.Chat2.Position
				v60.Chat2.Position = v62 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v60.Chat2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v62
				}):Play()
				v_u_4:Create(v60.Chat2, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v60.Chat2.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.3)
				v_u_12:PlaySound(v_u_8.Gojo.BlindsOff, v59, game.SoundService.Effect)
				task.wait(1)
				v_u_3:AddItem(v60, 0.6)
				for _, v63 in v60:GetDescendants() do
					if v63:IsA("Frame") then
						v_u_4:Create(v63, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = v63.Position - UDim2.new(0, 0, 0.2, 0),
							["BackgroundTransparency"] = 1
						}):Play()
					elseif v63:IsA("TextLabel") then
						v_u_4:Create(v63, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["FistSlam"] = function(p64)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v65 = p64:FindFirstChild("HumanoidRootPart")
			if v65 then
				v_u_12:PlaySound(v_u_8.Gojo.FistSlam, v65, game.SoundService.Effect)
				if v_u_5.Character == p64 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end,
		["CamFix"] = function(p66, p67)
			local v68 = p66:FindFirstChild("HumanoidRootPart")
			if v68 then
				local v69 = v68.CFrame:ToObjectSpace(workspace.CurrentCamera.CFrame)
				v68.CFrame = p67
				workspace.CurrentCamera.CFrame = p67:ToWorldSpace(v69)
			end
		end,
		["DragStart"] = function(p70, p71, p72)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v73 = p70:FindFirstChild("HumanoidRootPart")
			if v73 then
				local v_u_74 = v_u_12:PlaySound(v_u_8.Gojo.TeleportDrag, v73, game.SoundService.Effect)
				local v_u_75 = nil
				if v_u_5.Character == p71 then
					v_u_75 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
				elseif v_u_5.Character == p70 then
					v_u_75 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.LightHit)
				end
				p72.AncestryChanged:Connect(function()
					-- upvalues: (ref) v_u_75, (copy) v_u_74
					if v_u_75 then
						v_u_75:StartFadeOut(0.5)
					end
					v_u_74:Stop()
				end)
			end
		end,
		["DragThrow"] = function(p76)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			if p76:FindFirstChild("HumanoidRootPart") then
				local v77 = p76.HumanoidRootPart
				if v77 then
					local v78 = v_u_7.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					v78.CFrame = v77.CFrame * CFrame.new(2, 1, -5)
					v78.Parent = workspace.Effects
					v78.PointLight:Destroy()
					v78.Wind:Emit(20)
					v_u_3:AddItem(v78, 3)
					local v79 = v_u_7.Choso.CounterSwing.Shock:Clone()
					v79.Size = Vector3.new(6, 30, 6)
					v79.CFrame = v77.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v79.Parent = workspace.Effects
					v_u_3:AddItem(v79, 0.2)
					v_u_4:Create(v79, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(25, 0, 25),
						["Transparency"] = 1,
						["Position"] = v79.Position + v77.CFrame.LookVector * 10
					}):Play()
					v_u_12:PlaySound(v_u_8.Gojo.DragThrow, v77, game.SoundService.Effect)
					if v_u_5.Character == p76 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p81, ...)
		-- upvalues: (copy) v_u_80
		local v82 = v_u_80[p81]
		if v82 then
			v82(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p83, p84, p85)
		-- upvalues: (ref) v_u_11, (ref) v_u_4
		local v86 = p84.HumanoidRootPart
		if not v86 then
			return
		end
		local v87 = nil
		while true do
			local v88 = v_u_11:SphereHitbox(p84, CFrame.new(0, 0, -4), 8)
			for _, v89 in v88 do
				local v90 = v89:FindFirstChild("Info")
				if v90 then
					local v91 = v90:FindFirstChild("Knockback")
					if not v91 or v91.Value ~= false then
						v87 = v88
						break
					end
				end
			end
			if v87 then
				local v92 = p83:FindFirstChildWhichIsA("NumberValue")
				if v92 then
					v_u_4:Create(v92, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p83.Parent then
				break
			end
		end
		p85:FireServer(v87, v86.CFrame)
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("GojoService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13