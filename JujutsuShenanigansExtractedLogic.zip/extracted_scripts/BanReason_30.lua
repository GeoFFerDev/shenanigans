-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "banreason",
	["Description"] = "Returns the player\'s reason for ban",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"Mod"
	},
	["Args"] = {
		{
			["Type"] = "username",
			["Name"] = "Username"
		}
	}
}
return v1