-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "LuckyVolleyController"
})
function v11.KnitStart(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (ref) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_38 = {
		["Barrage"] = function(p12, p13)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7
			local v14 = p12:FindFirstChild("HumanoidRootPart")
			if not v14 then
				return
			end
			local v15 = p12:FindFirstChildWhichIsA("Shirt")
			local v16 = p12["Left Arm"].Color
			local v17 = p12["Right Arm"].Color
			local v18 = 0
			while true do
				local v19 = v_u_6.Hakari.Barrage:Clone()
				if v15 then
					v15:Clone().Parent = v19
				end
				v19["Left Arm"].Color = v16
				v19["Right Arm"].Color = v17
				for _, v20 in v19:GetChildren() do
					if v20:IsA("BasePart") then
						if v20.Name == "ColorArm" then
							v20.CFrame = v14.CFrame * CFrame.new(math.random(-50, 50) / 10, math.random(-50, 50) / 10, math.random(-20, 20) / 10) * CFrame.Angles(1.5707963267948966, 0, 0)
							v_u_3:Create(v20, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								["Transparency"] = 1,
								["CFrame"] = v20.CFrame + v14.CFrame.LookVector * 16
							}):Play()
							v20.Attachment.Flames:Emit(7)
							v20.Attachment.Wind:Emit(2)
						else
							local v21 = v14.CFrame * CFrame.new(math.random(-25, 25) / 10, math.random(-10, 10) / 10, math.random(-10, 10) / 10)
							local v22 = CFrame.Angles
							local v23 = math.random(70, 110)
							local v24 = math.rad(v23)
							local v25 = math.random(-20, 20)
							local v26 = math.rad(v25)
							local v27 = math.random(-20, 20)
							v20.CFrame = v21 * v22(v24, v26, (math.rad(v27)))
							v_u_3:Create(v20, TweenInfo.new(0.1), {
								["CFrame"] = v20.CFrame + v14.CFrame.LookVector * 7
							}):Play()
							v_u_3:Create(v20, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
								["Transparency"] = 1
							}):Play()
							local v28 = v_u_6.Gojo.LapseBlue.Throw:Clone()
							v28.CFrame = v14.CFrame - v14.Position + v20.Position + v14.CFrame.LookVector * 8
							v28.Size = Vector3.new(0, 0, 1)
							v28.Parent = v19
							v_u_3:Create(v28, TweenInfo.new(0.15), {
								["Size"] = Vector3.new(4, 4, 0),
								["Transparency"] = 1
							}):Play()
							v_u_2:AddItem(v28, 0.15)
						end
					end
				end
				v19.Parent = workspace.Effects
				v_u_2:AddItem(v19, 0.6)
				v18 = v18 + 1
				if v18 == 2 then
					v_u_10:PlaySound(v_u_7.Misc.Swing.Fist, v14, game.SoundService.Effect)
					v18 = 0
				end
				task.wait(0.025)
				if not p13.Parent then
					return
				end
			end
		end,
		["Hit"] = function(p29)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_10:Flash(p29, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 3)), v30, game.SoundService.Effect)
			end
		end,
		["Hit2"] = function(p31, p32)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v33 = p32:FindFirstChild("HumanoidRootPart")
			if v33 then
				v_u_10:Flash(p32, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v33, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Hakari.EnergySurge.Hit2, v33, game.SoundService.Effect)
				local v34 = v_u_6.Hakari.RoughHit:Clone()
				v34.Position = v33.Position
				v34.Parent = workspace.Effects
				v_u_2:AddItem(v34, 1)
				v_u_3:Create(v34.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v34.Glow:Emit(1)
				v34.Sparks:Emit(50)
				v34.Wind:Emit(7)
				v34.Wind2:Emit(7)
				if v_u_4 == p31 or v_u_4.Character == p32 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Swing"] = function(p35)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v36 = p35:FindFirstChild("HumanoidRootPart")
			if v36 then
				local v37 = v_u_6.Hakari.RoughSwing:Clone()
				v37.Weld.Part0 = v36
				v37.Parent = workspace.Effects
				v_u_2:AddItem(v37, 1.1)
				v_u_3:Create(v37.Weld, TweenInfo.new(0.3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["C1"] = v37.Weld.C1 * CFrame.Angles(0, 3.141592653589793, 0)
				}):Play()
				v_u_3:Create(v37.Beam, TweenInfo.new(0.3), {
					["Width0"] = 0
				}):Play()
				v_u_10:PlaySound(v_u_7.Hakari.Counter.Startup, v36, game.SoundService.Effect)
				task.wait(0.1)
				v37.Core.Flames.Enabled = false
			end
		end
	}
	v_u_9.Effects:Connect(function(p39, ...)
		-- upvalues: (copy) v_u_38
		local v40 = v_u_38[p39]
		if v40 then
			v40(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("LuckyVolleyService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11