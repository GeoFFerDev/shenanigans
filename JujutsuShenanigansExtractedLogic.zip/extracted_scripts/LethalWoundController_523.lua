-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v2 = game.ReplicatedStorage
local v3 = v2.Animations
local v4 = v2.Utils
local _ = v2.Sounds
require(v2.Modules.CameraShaker)
local v5 = require(v2.Modules.SraikoVFX)
require(v2.TEMP_CHARA_STUFF.VelocityHandler)
local v_u_6 = require(v2.TEMP_CHARA_STUFF.AnimationRetriever)
local v_u_7 = require(v2.TEMP_CHARA_STUFF.EffectUtility)
local v_u_8 = require(v2.TEMP_CHARA_STUFF.CameraShake)
local v_u_9 = require(v2.TEMP_CHARA_STUFF.Vignette)
local v_u_10 = require(v2.TEMP_CHARA_STUFF.RockHandler)
local v_u_11 = require(v2.TEMP_CHARA_STUFF.Smoke)
local _ = v5.Enabled
local _ = v5.Emit
local _ = v5.EmitMesh
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "LethalWoundController"
})
local v_u_16 = v3.Misc.C.LethalWound
local v_u_17 = game:GetService("Players").LocalPlayer
local function v_u_21(p18, p19, p20)
	-- upvalues: (copy) v_u_7, (copy) v_u_17, (copy) v_u_8, (copy) v_u_9
	v_u_7.CloneAndEmit(script.Assets[p20], p18)
	if v_u_17:DistanceFromCharacter(p18.Position) < 20 then
		v_u_8(2.5, 25, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
		v_u_9(Color3.fromRGB(255, 0, 0), 0.35, 0.35)
	end
	p19:FindFirstChild("Head")
end
local v_u_22 = nil
local _ = v4.Misc.C.Chara
function v15.KnitStart(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_16, (copy) v_u_10, (copy) v_u_11, (copy) v_u_7, (copy) v_u_8, (copy) v_u_21, (copy) v_u_17, (copy) v_u_9, (ref) v_u_22, (ref) v_u_12
	local v_u_23 = nil
	v_u_23 = {
		["Windup"] = function(p_u_24)
			-- upvalues: (ref) v_u_6, (ref) v_u_16, (ref) v_u_10, (ref) v_u_11, (ref) v_u_7, (ref) v_u_8
			local v25 = v_u_6.new(p_u_24, v_u_16.Windup)
			if v25 ~= nil then
				local _ = v25.Humanoid
				local v_u_26 = v25.Torso
				local v_u_27 = v25.RootPart
				local v_u_28 = v25.Job
				local v29 = v25.Animation
				local v_u_33 = coroutine.create(function()
					-- upvalues: (copy) v_u_27, (ref) v_u_10, (ref) v_u_11
					local v30 = 0
					while v_u_27.Parent ~= nil do
						if v30 % 2 == 0 then
							local v31 = v_u_27.Position + v_u_27.CFrame.LookVector * (5 + math.random(-20, 20) / 10)
							local v32 = v_u_27.CFrame.RightVector * (2.5 + math.random(-20, 20) / 10)
							v_u_10.Rocks(v31 + -v32)
							v_u_10.Rocks(v31 + v32)
						end
						v30 = v30 + 1
						v_u_11(v_u_27, 7.5)
						task.wait(0.025)
					end
				end)
				v_u_28:Task(v_u_7.AddSFX(script.SFX.Windup, v_u_26, 0.25))
				v_u_28:Task(v29:GetMarkerReachedSignal("run"):Once(function()
					-- upvalues: (ref) v_u_7, (copy) p_u_24, (ref) v_u_8
					if v_u_7.Distance_Close(p_u_24) then
						v_u_8(0.5, 5, 0.01, 0.25, Vector3.new(0.4, 0.4, 0.4), Vector3.new(0.3, 0.3, 0.3))
					end
				end))
				v_u_28:Task(v29:GetMarkerReachedSignal("slide"):Once(function()
					-- upvalues: (copy) v_u_33, (ref) v_u_7, (copy) p_u_24, (ref) v_u_8
					coroutine.resume(v_u_33)
					if v_u_7.Distance_Close(p_u_24) then
						v_u_8(0.65, 6.5, 0.025, 1, Vector3.new(0.4, 0.4, 0.4), Vector3.new(0.2, 0.2, 0.2))
					end
				end))
				v_u_28:Task(v29:GetMarkerReachedSignal("endcast"):Once(function()
					-- upvalues: (copy) v_u_28, (ref) v_u_7, (copy) v_u_26, (copy) v_u_33
					v_u_28:Task(v_u_7.AddSFX(script.SFX.Getup, v_u_26, 0.3))
					pcall(task.cancel, v_u_33)
				end))
				v_u_28:Task(v29.Stopped:Once(function()
					-- upvalues: (copy) v_u_33
					pcall(task.cancel, v_u_33)
				end))
			end
		end,
		["Hit"] = function(p_u_34, p_u_35)
			-- upvalues: (ref) v_u_6, (ref) v_u_16, (ref) v_u_7, (ref) v_u_21, (ref) v_u_17, (ref) v_u_8, (ref) v_u_11
			local v_u_36 = p_u_34:FindFirstChild("HumanoidRootPart")
			if v_u_36 then
				local v37 = v_u_6.new(p_u_34, v_u_16.Hit)
				if v37 ~= nil then
					script.SFX.Hit.PlaybackSpeed = v37.Animation.Speed
					local v_u_38 = v_u_7.AddSFX(script.SFX.Hit, v_u_36, 5)
					task.spawn(function()
						-- upvalues: (ref) v_u_6, (copy) p_u_34, (ref) v_u_16, (copy) v_u_38
						if v_u_6.new(p_u_34, v_u_16.Finisher, 3.5) ~= nil then
							v_u_38:Destroy()
						end
					end)
					local v39 = v37.Job
					v39:Task(v37.Animation:GetMarkerReachedSignal("stab"):Connect(function(p40)
						-- upvalues: (ref) v_u_21, (copy) v_u_36, (copy) p_u_35
						if p40 ~= "3" then
							v_u_21(v_u_36, p_u_35, p40)
						end
					end))
					local v41 = v_u_17:DistanceFromCharacter(v_u_36.Position)
					if v41 < 20 then
						v_u_8(1, 10, 0.01, 0.4, Vector3.new(0.4, 0.4, 0.4), Vector3.new(0.85, 0.85, 0.85))
					end
					if v41 < 80 then
						local v_u_42 = coroutine.create(function()
							-- upvalues: (copy) v_u_36, (ref) v_u_11
							while v_u_36.Parent ~= nil do
								v_u_11(v_u_36, 7.5, 2.25)
								task.wait(0.03)
							end
						end)
						coroutine.resume(v_u_42)
						task.delay(0.65, function()
							-- upvalues: (copy) v_u_42
							pcall(task.cancel, v_u_42)
						end)
					end
					v_u_7.CloneAndEmit(script.Assets.tackle, v_u_36)
					local v_u_43 = p_u_34.SetAssets:FindFirstChild("RealKnife")
					if v_u_43 then
						v_u_43.Handle.BladeAttachment.Trail.Enabled = true
						v39:Task(function()
							-- upvalues: (copy) v_u_43
							v_u_43.Handle.BladeAttachment.Trail.Enabled = false
						end)
					end
				end
			else
				return
			end
		end,
		["Stab"] = v_u_21,
		["FinisherHit"] = function(p44)
			-- upvalues: (ref) v_u_7
			if p44 then
				v_u_7.AddSFX(script.Finisher.SFX, p44, 5)
			end
		end,
		["FinisherStab"] = function(p45)
			-- upvalues: (ref) v_u_17, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7
			if v_u_17:DistanceFromCharacter(p45.Position) < 20 then
				v_u_8(2.5, 25, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
				v_u_9(Color3.fromRGB(255, 0, 0), 0.35, 0.35)
			end
			v_u_7.CloneAndEmit(script.Finisher.Assets.stab, p45)
		end,
		["FinisherStabToLeft"] = function(p46)
			-- upvalues: (ref) v_u_17, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7
			if v_u_17:DistanceFromCharacter(p46.Position) < 20 then
				v_u_8(2.5, 25, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
				v_u_9(Color3.fromRGB(255, 0, 0), 0.35, 0.35)
			end
			v_u_7.CloneAndEmit(script.Finisher.Assets.stabtoleft, p46)
		end,
		["FinisherThrowBack"] = function(p47)
			-- upvalues: (ref) v_u_7
			v_u_7.CloneAndEmit(script.Finisher.Assets.throwback, p47)
		end,
		["FinisherSlice"] = function(p48)
			-- upvalues: (ref) v_u_7
			v_u_7.CloneAndEmit(script.Finisher.Assets.slice, p48)
		end,
		["FinisherSlicing"] = function(p_u_49, p50)
			-- upvalues: (ref) v_u_7, (ref) v_u_17, (ref) v_u_22, (ref) v_u_8, (ref) v_u_9, (ref) v_u_23
			if p50 then
				local v51 = script.Finisher.Assets.slicing:Clone()
				v51.Parent = p_u_49
				v_u_7.Toggle(v51, true)
				local v_u_52 = v_u_17:DistanceFromCharacter(p_u_49.Position)
				v_u_22 = {
					["VFX"] = v51,
					["Shake"] = v_u_52 <= 25 and v_u_8(1.75, 17.5, 0.01, 0, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.5, 0.5, 0.5)) or nil,
					["Loop"] = coroutine.create(function()
						-- upvalues: (copy) v_u_52, (copy) p_u_49, (ref) v_u_17, (ref) v_u_9
						if v_u_52 <= 50 then
							while p_u_49.Parent ~= nil do
								if v_u_17:DistanceFromCharacter(p_u_49.Position) < 20 then
									v_u_9(Color3.fromRGB(255, 0, 0), 0.75, 0.075)
								end
								task.wait(0.05)
							end
						end
					end)
				}
				coroutine.resume(v_u_22.Loop)
			else
				v_u_23.FinisherStopSlicing(p_u_49)
			end
		end,
		["FinisherStopSlicing"] = function(_)
			-- upvalues: (ref) v_u_22, (ref) v_u_7
			if v_u_22 then
				if coroutine.status(v_u_22.Loop) == "suspended" then
					coroutine.close(v_u_22.Loop)
				end
				if v_u_22.Shake then
					v_u_22.Shake:StartFadeOut(0.1)
				end
				local v53 = v_u_22.VFX
				v_u_7.Toggle(v53, false)
				task.delay(1, v53.Destroy, v53)
				v_u_22 = nil
			end
		end,
		["FinisherSliced"] = function(p54)
			-- upvalues: (ref) v_u_17, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7
			if v_u_17:DistanceFromCharacter(p54.Position) < 20 then
				v_u_8(2.5, 25, 0.01, 0.5, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
				v_u_9(Color3.fromRGB(255, 0, 0), 0.15, 0.35)
			end
			v_u_7.CloneAndEmit(script.Finisher.Assets.sliced, p54)
		end
	}
	v_u_12.Effects:Connect(function(p55, ...)
		-- upvalues: (ref) v_u_23
		local v56 = v_u_23[p55]
		if v56 then
			v56(...)
		end
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14
	v_u_12 = v_u_1.GetService("LethalWoundService")
	v_u_13 = v_u_1.GetController("HitboxController")
	v_u_14 = v_u_1.GetController("FXController")
end
return v15