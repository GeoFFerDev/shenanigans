-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "ClimaxJumpController"
})
function v14.KnitStart(_)
	-- upvalues: (copy) v_u_8, (copy) v_u_3, (ref) v_u_13, (copy) v_u_9, (copy) v_u_5, (copy) v_u_10, (copy) v_u_4, (copy) v_u_2, (copy) v_u_7, (ref) v_u_11
	local v_u_67 = {
		["Grab"] = function(p_u_15, p_u_16)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_4, (ref) v_u_2, (ref) v_u_7
			local v_u_17 = p_u_16:FindFirstChild("HumanoidRootPart")
			if v_u_17 then
				local v18 = v_u_8.Mahito.CrushingRushdown.DrillImpact:Clone()
				v18.Position = v_u_17.Position
				v18.Parent = workspace.Effects
				v_u_3:AddItem(v18, 1)
				v18.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v18.Wind.Color = v18.Sparks.Color
				v18.Wind2.Color = v18.Sparks.Color
				v18.Sparks:Emit(50)
				v18.Wind:Emit(7)
				v18.Wind2:Emit(7)
				v_u_13:Flash(p_u_16, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, v_u_17, game.SoundService.Effect)
				if v_u_5.Character == p_u_16 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
				if v_u_5.Character == p_u_15 and p_u_15:GetAttribute("InUlt") then
					local v_u_19 = v_u_8.Todo.Jump.Flash:Clone()
					local v_u_20 = Instance.new("Camera", v_u_19.Main)
					v_u_19.Main.CurrentCamera = v_u_20
					v_u_19.Parent = v_u_5.PlayerGui
					v_u_4:Create(v_u_19.Fade, TweenInfo.new(0.2), {
						["BackgroundTransparency"] = 1
					}):Play()
					local v21 = CFrame.new(2000, 0, 0)
					local v_u_22 = v_u_8.DomainWarn.Panel.Viewport.Display:Clone()
					v_u_22["Left Arm"].FingersL:Destroy()
					v_u_22["Right Arm"].FingersR:Destroy()
					v_u_22.HumanoidRootPart.CFrame = v21
					v_u_22.Parent = v_u_19.Main
					pcall(function()
						-- upvalues: (ref) v_u_13, (copy) p_u_15, (copy) v_u_22
						v_u_13:ApplyCopyOutfit(p_u_15, v_u_22)
					end)
					v_u_22.Humanoid:LoadAnimation(v_u_19.User):Play(0)
					local v23 = v_u_8.Todo.Awakening.Takada:Clone()
					v23.Parent = v_u_19.Main
					v23.HumanoidRootPart.CFrame = v_u_22.HumanoidRootPart.CFrame
					v23.Humanoid:LoadAnimation(v_u_19.Takada):Play(0)
					local v_u_24 = v_u_8.DomainWarn.Panel.Viewport.Display:Clone()
					v_u_24["Left Arm"].FingersL:Destroy()
					v_u_24["Right Arm"].FingersR:Destroy()
					v_u_24.HumanoidRootPart.CFrame = v_u_22.HumanoidRootPart.CFrame * CFrame.Angles(0, 3.141592653589793, 0) * CFrame.new(0, 0, 5)
					v_u_24.Parent = v_u_19.Main
					pcall(function()
						-- upvalues: (ref) v_u_13, (copy) p_u_16, (copy) v_u_24
						v_u_13:ApplyCopyOutfit(p_u_16, v_u_24)
					end)
					v_u_24.Humanoid:LoadAnimation(v_u_19.Target):Play(0)
					local v_u_25 = workspace.CurrentCamera.CFrame
					local v_u_26 = 0
					local v_u_27 = nil
					local v_u_28 = v_u_8.Todo.Jump.CameraData
					v_u_27 = v_u_2.RenderStepped:Connect(function(p29)
						-- upvalues: (ref) v_u_26, (copy) v_u_28, (copy) v_u_22, (copy) v_u_20, (ref) v_u_27, (copy) v_u_25
						v_u_26 = v_u_26 + p29 * 60
						local v30 = v_u_28.Frames
						local v31 = v_u_26
						local v32 = math.ceil(v31)
						local v33 = v30:FindFirstChild((tonumber(v32)))
						local v34 = v_u_28.FOV
						local v35 = v_u_26
						local v36 = math.ceil(v35)
						local v37 = v34:FindFirstChild((tonumber(v36)))
						if v33 and (v37 and v_u_22.Parent) then
							v_u_20.CFrame = v_u_22.HumanoidRootPart.CFrame * v33.Value
							v_u_20.FieldOfView = v37.Value
							if v_u_26 < 79 then
								workspace.CurrentCamera.CFrame = v_u_20.CFrame
								workspace.CurrentCamera.FieldOfView = v_u_20.FieldOfView
								return
							end
						else
							v_u_27:Disconnect()
							workspace.CurrentCamera.FieldOfView = 70
							workspace.CurrentCamera.CFrame = v_u_25
						end
					end)
					v_u_19.Main.Ambient = Color3.new(0.211765, 0.0509804, 0.0862745)
					v_u_19.Main.LightColor = Color3.new(0.956863, 0.807843, 1)
					v_u_19.Main.LightDirection = Vector3.new(0, 1, -0.5)
					local v_u_38 = v_u_8.Todo.Jump.Stage:Clone()
					v_u_38:PivotTo(CFrame.new(2000, 0, 0))
					v_u_4:Create(v_u_38.BG, TweenInfo.new(1.3, Enum.EasingStyle.Linear), {
						["CFrame"] = v_u_38.BG.CFrame * CFrame.new(3.12413936106985, 0, 0)
					}):Play()
					local v39 = v_u_38.Bloom
					v_u_38.Parent = workspace.Effects
					v39.Parent = game.Lighting
					v_u_3:AddItem(v_u_38, 1.4)
					v_u_3:AddItem(v39, 1.4)
					task.delay(1.3, function()
						-- upvalues: (copy) v_u_19
						v_u_19.BG.Visible = true
						v_u_19.Main.Ambient = Color3.new(1, 1, 1)
						v_u_19.Main.LightColor = Color3.new(1, 1, 1)
						v_u_19.Main.LightDirection = Vector3.new(-1, -1, -1)
						task.wait(0.9)
						v_u_19.BG.Hearts.Position = UDim2.new(-0.5, 0, 0, 0)
						task.wait(0.7)
						v_u_19.BG.Hearts.Visible = false
					end)
					v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, workspace, game.SoundService.Effect)
					task.delay(0.4, function()
						-- upvalues: (copy) v_u_38, (copy) v_u_24, (ref) v_u_13, (ref) v_u_9, (copy) v_u_19, (ref) v_u_3, (ref) v_u_4, (ref) v_u_26
						local v40 = v_u_38.RootPart.Attachment
						v40.WorldPosition = v_u_24.Torso.Position
						v40.Wind2:Emit(10)
						v40.Hearts:Emit(20)
						v40.Ring:Emit(1)
						v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, workspace, game.SoundService.Effect)
						task.wait(0.3)
						v40.Wind2:Emit(10)
						v40.Hearts:Emit(20)
						v40.Ring:Emit(1)
						v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit2, workspace, game.SoundService.Effect)
						task.wait(0.2)
						v40.Wind2:Emit(10)
						v40.Hearts:Emit(20)
						v40.Ring:Emit(1)
						v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, workspace, game.SoundService.Effect)
						task.wait(0.4)
						local v41 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
						repeat
							v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 4)), workspace, game.SoundService.Effect)
							local v42 = v_u_19.BG.Heart:Clone()
							v42.ImageColor3 = Color3.fromHSV(math.random(0, 100) / 100, 1, 1)
							v42.Parent = v_u_19.BG.Hearts
							v_u_3:AddItem(v42, 0.3)
							v42.Visible = true
							v_u_4:Create(v42, v41, {
								["Size"] = UDim2.new(5, 0, 5, 0)
							}):Play()
							task.wait(0.075)
						until v_u_26 > 171
						v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit2, workspace, game.SoundService.Effect)
					end)
					task.delay(1, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_19, (ref) v_u_8, (copy) v_u_17, (copy) p_u_15, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7
						v_u_3:AddItem(v_u_19, 2.2)
						local v43 = v_u_8.Todo.Jump.EndSpotlight:Clone()
						v43.CFrame = v_u_17.CFrame
						v43.Parent = p_u_15.HumanoidRootPart
						v_u_3:AddItem(v43, 3.5)
						task.wait(2)
						v_u_4:Create(v_u_19.Fade, TweenInfo.new(0.2), {
							["BackgroundTransparency"] = 0
						}):Play()
						task.wait(0.2)
						local v44 = v_u_8.Itadori.DivergentFist.BlackFlashCC:Clone()
						v44.TintColor = Color3.fromRGB(255, 170, 0)
						v44.Parent = game.Lighting
						task.wait(0.03)
						v44.Brightness = 200
						v44.Contrast = -1000
						task.wait(0.03)
						v44.TintColor = Color3.new(1, 1, 1)
						v44.Brightness = -200
						v44.Contrast = 1000
						task.wait(0.03)
						v44:Destroy()
						game.Lighting.ExposureCompensation = -6
						v_u_4:Create(game.Lighting, TweenInfo.new(1), {
							["ExposureCompensation"] = 0
						}):Play()
						v_u_4:Create(v43.Attachment.SpotLight, TweenInfo.new(1), {
							["Brightness"] = 0
						}):Play()
						v43.CFrame = v_u_17.CFrame
						v43.Dust:Emit(40)
						v_u_13:PlaySound(v_u_9.Todo.Jump.Bell, p_u_15.HumanoidRootPart, game.SoundService.Effect)
						local v45 = workspace.Effects:FindFirstChild("FollowTakada")
						if v45 and v_u_5.Character == p_u_15 then
							v45:SetAttribute("A", CFrame.new(-6, 0, 0))
							v45.Humanoid:LoadAnimation(v_u_7.Todo.TakadaJoint.JumpEnd):Play(0)
							task.wait(1)
							v45:SetAttribute("A", nil)
						end
					end)
				end
			end
		end,
		["Hit"] = function(p46, p47)
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			if v_u_5 == p46 then
				return
			else
				local v48 = p47:FindFirstChild("HumanoidRootPart")
				if v48 then
					local v49 = v_u_8.Mahito.CrushingRushdown.DrillImpact:Clone()
					v49.Position = v48.Position
					v49.Parent = workspace.Effects
					v_u_3:AddItem(v49, 1)
					v49.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v49.Wind.Color = v49.Sparks.Color
					v49.Wind2.Color = v49.Sparks.Color
					v49.Sparks:Emit(50)
					v49.Wind:Emit(7)
					v49.Wind2:Emit(7)
					v_u_13:Flash(p47, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, v48, game.SoundService.Effect)
					if v_u_5 == p46 or v_u_5.Character == p47 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
					end
				end
			end
		end,
		["Hit2"] = function(p50, p51)
			-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			if v_u_5 == p50 then
				return
			else
				local v52 = p51:FindFirstChild("HumanoidRootPart")
				if v52 then
					v_u_13:Flash(p51, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 4)), v52, game.SoundService.Effect)
					if v_u_5 == p50 or v_u_5.Character == p51 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
				end
			end
		end,
		["Hit3"] = function(p53, p54)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v55 = p54:FindFirstChild("HumanoidRootPart")
			if v55 then
				local v56 = v_u_8.Mahito.CrushingRushdown.DrillImpact:Clone()
				v56.Position = v55.Position
				v56.Parent = workspace.Effects
				v_u_3:AddItem(v56, 1)
				v56.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v56.Wind.Color = v56.Sparks.Color
				v56.Wind2.Color = v56.Sparks.Color
				v56.Sparks:Emit(50)
				v56.Wind:Emit(7)
				v56.Wind2:Emit(7)
				v_u_13:Flash(p54, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, v55, game.SoundService.Effect)
				if v_u_5 == p53 or v_u_5.Character == p54 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
			end
		end,
		["Burst"] = function(p57)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_7
			local v58 = p57:FindFirstChild("HumanoidRootPart")
			if v58 then
				v_u_13:Flash(p57, Color3.new(1, 1, 1), 1)
				v_u_13:PlaySound(v_u_9.Itadori.CursedStrikes.Startup, v58, game.SoundService.Effect)
				if v_u_5.Character == p57 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					local v59 = workspace.Effects:FindFirstChild("FollowTakada")
					if v59 and v_u_5.Character == p57 then
						v59:SetAttribute("A", CFrame.new(4, 0, 0))
						v59.Humanoid:LoadAnimation(v_u_7.Todo.TakadaJoint.JumpStart):Play(0)
						task.wait(1)
						v59:SetAttribute("A", nil)
					end
				end
			end
		end,
		["Dash"] = function(p60)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v61 = p60:FindFirstChild("HumanoidRootPart")
			if v61 then
				v_u_13:PlaySound(v_u_9.Itadori.Rush.RushLaunch, v61, game.SoundService.Effect)
				local v62 = v_u_8.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v62.CFrame = v61.CFrame * CFrame.new(2, 1, -5)
				v62.Parent = workspace.Effects
				v62.Wind:Emit(20)
				v62.PointLight:Destroy()
				v62.Back1.Back:Emit(1)
				v62.Back2.Back:Emit(1)
				v_u_4:Create(v62.Back1, TweenInfo.new(2), {
					["CFrame"] = v62.Back1.CFrame - v62.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_4:Create(v62.Back2, TweenInfo.new(2), {
					["CFrame"] = v62.Back2.CFrame - v62.Back2.CFrame.LookVector * 20
				}):Play()
				v_u_3:AddItem(v62, 3)
				for _ = 1, 10 do
					local v_u_63 = v_u_8.Mahito.BodyRepel["Wind" .. math.random(1, 5)]:Clone()
					local v64 = v61.CFrame
					local v65 = CFrame.Angles
					local v66 = math.random(0, 360)
					v_u_63.CFrame = v64 * v65(1.5707963267948966, math.rad(v66), 0)
					v_u_63.Transparency = 0.5
					v_u_63.Size = Vector3.new(6, 6, 6)
					v_u_4:Create(v_u_63, TweenInfo.new(0.3, Enum.EasingStyle.Quad), {
						["CFrame"] = v_u_63.CFrame + v61.CFrame.LookVector * 3,
						["Size"] = Vector3.new(7, 0, 7)
					}):Play()
					v_u_3:AddItem(v_u_63, 0.3)
					v_u_63.Parent = workspace.Effects
					v_u_4:Create(v_u_63, TweenInfo.new(0.15), {
						["Transparency"] = 0.5
					}):Play()
					task.delay(0.15, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_63
						v_u_4:Create(v_u_63, TweenInfo.new(0.15), {
							["Transparency"] = 1
						}):Play()
					end)
					task.wait(0.03)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p68, ...)
		-- upvalues: (copy) v_u_67
		local v69 = v_u_67[p68]
		if v69 then
			v69(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("ClimaxJumpService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14