-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_9 = require(v6.Modules.SraikoVFX)
local v_u_10 = v_u_9.Enabled
local v_u_11 = v_u_9.Emit
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "BoostOn2Controller"
})
function v15.KnitStart(_)
	-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2, (copy) v_u_10, (ref) v_u_14, (copy) v_u_8, (copy) v_u_11, (copy) v_u_7, (copy) v_u_9, (ref) v_u_12
	local v_u_76 = {
		["BoostEnabled"] = function(p_u_16, p17)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_4, (ref) v_u_2, (ref) v_u_10, (ref) v_u_14, (ref) v_u_8, (ref) v_u_11, (ref) v_u_7, (ref) v_u_9
			local v_u_18 = p_u_16:FindFirstChild("HumanoidRootPart")
			if not v_u_18 then
				return
			end
			local v_u_19 = {}
			if p_u_16 == v_u_5.Character then
				local v_u_20 = Instance.new("BodyVelocity")
				v_u_20.MaxForce = Vector3.new(40000, 1750, 40000)
				v_u_20.P = 40000
				v_u_20.Parent = v_u_18
				v_u_3:AddItem(v_u_20, 1)
				table.insert(v_u_19, v_u_20)
				local v_u_21 = Instance.new("NumberValue", v_u_20)
				v_u_21.Value = 125
				v_u_4:Create(v_u_21, TweenInfo.new(1, Enum.EasingStyle.Linear), {
					["Value"] = 5
				}):Play()
				task.spawn(function()
					-- upvalues: (copy) p_u_16, (copy) v_u_19, (copy) v_u_20, (copy) v_u_21, (ref) v_u_4
					local v_u_22 = p_u_16:FindFirstChild("Info")
					if v_u_22 then
						v_u_22 = p_u_16.Info:WaitForChild("BoostOnHold", 1)
					end
					if v_u_22 then
						local v23 = v_u_19
						local v24 = v_u_22:GetPropertyChangedSignal("Value")
						local function v25()
							-- upvalues: (copy) v_u_22, (ref) v_u_20, (ref) v_u_21, (ref) v_u_4
							if v_u_22.Value and v_u_20.Parent then
								v_u_21.Value = 20
								v_u_4:Create(v_u_21, TweenInfo.new(1, Enum.EasingStyle.Linear), {
									["Value"] = 0
								}):Play()
							end
						end
						table.insert(v23, v24:Connect(v25))
					end
				end)
				task.spawn(function()
					-- upvalues: (copy) v_u_20, (copy) v_u_18, (copy) v_u_21, (ref) v_u_2
					repeat
						v_u_20.Velocity = v_u_18.CFrame.LookVector * v_u_21.Value
						v_u_2.Stepped:Wait()
					until not (v_u_20.Parent and v_u_18.Parent)
				end)
			end
			local v26 = p17.AncestryChanged
			table.insert(v_u_19, v26:Connect(function(_, p27)
				-- upvalues: (copy) v_u_19
				if not p27 then
					for v28, v29 in next, v_u_19 do
						if typeof(v29) == "RBXScriptConnection" then
							v29:Disconnect()
						else
							v29:Destroy()
						end
						v_u_19[v28] = nil
					end
				end
			end))
			local v_u_30 = p_u_16:FindFirstChild("BoosterR")
			local v_u_31 = p_u_16:FindFirstChild("BoosterL")
			if v_u_30 and not v_u_30:GetAttribute("Disabled") then
				v_u_10(v_u_30["Arm BoostterrrrR"].Stage1, false)
				v_u_10(v_u_30["Arm BoostterrrrR"].Stage2, true)
			end
			if v_u_31 and not v_u_31:GetAttribute("Disabled") then
				v_u_10(v_u_31["Arm BoostterrrrL"].Stage1, false)
				v_u_10(v_u_31["Arm BoostterrrrL"].Stage2, true)
			end
			task.delay(0.6, function()
				-- upvalues: (copy) v_u_30, (ref) v_u_10, (copy) v_u_31
				if v_u_30 and v_u_30.Parent then
					v_u_10(v_u_30["Arm BoostterrrrR"].Stage2, false)
				end
				if v_u_31 and v_u_31.Parent then
					v_u_10(v_u_31["Arm BoostterrrrL"].Stage2, false)
				end
			end)
			v_u_14:PlaySound(v_u_8.Mechamaru.BoostOn.Booster, v_u_18, game.SoundService.Effect)
			v_u_11(v_u_7.Mechamaru.BoostOnVFX.BoostDash.Emit.Strike, v_u_18, true, 5)
			local v_u_32 = v_u_7.Mechamaru.BoostOnVFX.BoostEnabled.Strike:Clone()
			v_u_32.Parent = v_u_18
			v_u_10(v_u_32, true, v_u_18, true, 3)
			table.insert(v_u_19, v_u_32)
			local v33 = p17:GetAttributeChangedSignal("End")
			local function v34()
				-- upvalues: (ref) v_u_14, (ref) v_u_8, (copy) v_u_18, (ref) v_u_10, (copy) v_u_32
				v_u_14:PlaySound(v_u_8.Mechamaru.BoostOn.SecondPart, v_u_18, game.SoundService.Effect)
				v_u_10(v_u_32, false)
			end
			table.insert(v_u_19, v33:Once(v34))
			for _ = 1, 4 do
				if not p_u_16.Parent or (not p17.Parent or p17:GetAttribute("End")) then
					break
				end
				local v35 = v_u_7.Mechamaru.BoostOnVFX.BoostRepeat.Meshes.Mesh:Clone()
				local v36 = v_u_9.HandleMesh(v35, v_u_18.CFrame)
				v35.Parent = workspace.Effects
				v_u_3:AddItem(v35, v36)
				local v37 = v_u_7.Mechamaru.BoostOnVFX.BoostRepeat.Meshes.MeshWeld:Clone()
				local v38 = v_u_9.HandleMesh(v37, v_u_18.CFrame, {
					["Weld"] = v_u_18
				})
				v37.Parent = workspace.Effects
				v_u_3:AddItem(v37, v38)
				task.wait(0.2)
			end
		end,
		["BoostLandEnabledTrue"] = function(p39)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v40 = p39:FindFirstChild("HumanoidRootPart")
			if v40 then
				local v_u_41 = v_u_7.Mechamaru.BoostOnVFX.BoostLandEnabled.Dust:Clone()
				v_u_41.Weld.Part1 = v40
				v_u_41.Parent = workspace.Effects
				v_u_3:AddItem(v_u_41, 2)
				task.delay(0.25, function()
					-- upvalues: (copy) v_u_41
					local v42 = next
					local v43, v44 = v_u_41.Attachment:GetChildren()
					for _, v45 in v42, v43, v44 do
						v45.Enabled = false
					end
				end)
			end
		end,
		["DisableBoosters"] = function(p46, p47)
			-- upvalues: (ref) v_u_10
			for _, v48 in next, { p46, p47 } do
				if v48 then
					v48:SetAttribute("Disabled", true)
					v_u_10(v48, false)
				end
			end
		end,
		["Hit"] = function(p49)
			-- upvalues: (ref) v_u_14
			if p49:FindFirstChild("HumanoidRootPart") then
				v_u_14:Flash(p49, Color3.new(1, 1, 1))
			end
		end,
		["DashStart"] = function(p50)
			-- upvalues: (ref) v_u_14, (ref) v_u_8
			local v51 = p50:FindFirstChild("HumanoidRootPart")
			if v51 then
				v_u_14:PlaySound(v_u_8.Mechamaru.BoostOn.Start, v51, game.SoundService.Effect)
			end
		end,
		["DashEnd"] = function(p52)
			-- upvalues: (ref) v_u_14, (ref) v_u_8
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				v_u_14:PlaySound(v_u_8.Mechamaru.BoostOn.PunchWoosh, v53, game.SoundService.Effect)
			end
		end,
		["Punch"] = function(p54)
			-- upvalues: (ref) v_u_7, (ref) v_u_9, (ref) v_u_3, (ref) v_u_11
			local v55 = p54:FindFirstChild("HumanoidRootPart")
			if v55 then
				local v56 = v_u_7.Mechamaru.BoostOnVFX.BoostHit.Meshes.Mesh:Clone()
				local v57 = v_u_9.HandleMesh(v56, v55.CFrame * v56.Offset.Value)
				v56.Parent = workspace.Effects
				v_u_3:AddItem(v56, v57)
				v_u_11(v_u_7.Mechamaru.BoostOnVFX.BoostHit.Emit.Strike, v55, true, 3)
			end
		end,
		["PunchHit"] = function(p58)
			-- upvalues: (ref) v_u_14, (ref) v_u_8
			local v59 = p58:FindFirstChild("HumanoidRootPart")
			if v59 then
				v_u_14:Flash(p58, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_8.Mechamaru.BoostOn.Hit, v59, game.SoundService.Effect)
			end
		end,
		["BoostOnOffload"] = function(p_u_60, _)
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (ref) v_u_9, (ref) v_u_3, (ref) v_u_11
			local v_u_61 = p_u_60:FindFirstChild("HumanoidRootPart")
			if v_u_61 and p_u_60:FindFirstChild("HumanoidRootPart") then
				v_u_14:PlaySound(v_u_8.Mechamaru.BoostOn.DummyThrow, v_u_61, game.SoundService.Effect)
				task.spawn(function()
					-- upvalues: (copy) p_u_60, (ref) v_u_10, (ref) v_u_7, (ref) v_u_9, (copy) v_u_61, (ref) v_u_3, (ref) v_u_11
					local v62 = p_u_60:FindFirstChild("BoosterR")
					local v63 = p_u_60:FindFirstChild("BoosterL")
					for _, v64 in next, { v62, v63 } do
						if v64.PrimaryPart then
							v_u_10(v64.PrimaryPart.Stage1, false)
							v_u_10(v64.PrimaryPart.Stage2, true)
						end
					end
					task.wait(0.283)
					for _, v65 in next, { v62, v63 } do
						if v65.PrimaryPart then
							v_u_10(v65.PrimaryPart.Stage1, true)
							v_u_10(v65.PrimaryPart.Stage2, false)
						end
					end
					task.wait(0.6)
					for v_u_66 = 1, 3 do
						task.spawn(function()
							-- upvalues: (ref) v_u_7, (copy) v_u_66, (ref) v_u_9, (ref) v_u_61, (ref) v_u_3
							for _ = 1, 8 do
								local v67 = v_u_7.Mechamaru.BoostOnVFX.Offload.VFX.BoostRepeat.Meshes[("Loop%d"):format(v_u_66)]:Clone()
								local v68 = {
									["Weld"] = v_u_61
								}
								local v69 = v_u_9.HandleMesh(v67, v_u_61.CFrame * v67.Offset.Value, v68)
								v67.Parent = workspace.Effects
								v_u_3:AddItem(v67, v69)
								task.wait(0.2)
							end
						end)
					end
					local v70 = v_u_7.Mechamaru.BoostOnVFX.Offload.VFX.BoostDash.Meshes.Mesh:Clone()
					local v71 = v_u_9.HandleMesh(v70, v_u_61.CFrame * v70.Offset.Value)
					v70.Parent = workspace.Effects
					v_u_3:AddItem(v70, v71)
					v_u_11(v_u_7.Mechamaru.BoostOnVFX.Offload.VFX.BoostDash.Emit.Strike, v_u_61, true, 4)
					for _, v72 in next, { v62, v63 } do
						if v72.PrimaryPart then
							v_u_10(v72.PrimaryPart.Stage1, false)
							v_u_10(v72.PrimaryPart.Stage2, true)
						end
					end
					task.wait(1.7)
					v_u_11(v_u_7.Mechamaru.BoostOnVFX.Offload.VFX.BoostThrow.Emit.Strike, v_u_61, true, 4)
					local v73 = v_u_7.Mechamaru.BoostOnVFX.Offload.VFX.BoostDash.Meshes.Mesh:Clone()
					local v74 = v_u_9.HandleMesh(v73, v_u_61.CFrame * v73.Offset.Value)
					v73.Parent = workspace.Effects
					v_u_3:AddItem(v73, v74)
					task.wait(0.083)
					for _, v75 in next, { v62, v63 } do
						if v75.PrimaryPart then
							v_u_10(v75.PrimaryPart.Stage1, false)
							v_u_10(v75.PrimaryPart.Stage2, false)
						end
					end
				end)
			end
		end
	}
	v_u_12.Effects:Connect(function(p77, ...)
		-- upvalues: (copy) v_u_76
		local v78 = v_u_76[p77]
		if v78 then
			v78(...)
		end
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14
	v_u_12 = v_u_1.GetService("BoostOn2Service")
	v_u_13 = v_u_1.GetController("HitboxController")
	v_u_14 = v_u_1.GetController("FXController")
end
return v15