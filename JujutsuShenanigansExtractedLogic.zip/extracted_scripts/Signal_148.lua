-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return require(script.Parent.Parent["sleitnick_signal@1.5.0"].signal)