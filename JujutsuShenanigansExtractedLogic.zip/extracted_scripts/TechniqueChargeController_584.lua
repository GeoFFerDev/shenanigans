-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "TechniqueChargeController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_80 = {
		["FingertipLightning"] = function(p13, p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v15 = p13:FindFirstChild("FingersR")
			if v15 then
				local v16 = v15:FindFirstChild("GunEffects", true)
				if v16 then
					v16.Lightning.Enabled = true
					v16.PointLight.Enabled = true
					v_u_11:PlaySound(v_u_7.Mechamaru.Absolute.Special.LightningStart, v16, game.SoundService.Effect)
					local v17 = v_u_11:PlaySound(v_u_7.Mechamaru.Absolute.Special.LightningLoop, v16, game.SoundService.Effect)
					p14.AncestryChanged:Wait()
					v17:Destroy()
					v16.Lightning.Enabled = false
					v16.PointLight.Enabled = false
					for _, v18 in v16:GetChildren() do
						if v18:IsA("ParticleEmitter") and v18.Name ~= "Lightning" then
							v18:Emit(v18:GetAttribute("EmitCount"))
						end
					end
				end
			else
				return
			end
		end,
		["FingerShoot"] = function(p19, p20, p21)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v22 = p19:FindFirstChild("FingersR")
			if v22 then
				local v23 = v22:FindFirstChild("GunEffects", true)
				if v23 then
					local v24 = v23.WorldCFrame
					local v25 = v_u_6.Gojo.LapseBlue.Throw:Clone()
					v25.CFrame = v24 * CFrame.Angles(-1.5707963267948966, 0, 0)
					v25.Size = Vector3.new(0, 0, 24)
					v25.Parent = workspace.Effects
					v_u_3:Create(v25, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(36, 36, 0),
						["Position"] = v25.Position - v25.CFrame.LookVector * 12,
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v25, 0.2)
					v_u_11:PlaySound(v_u_7.Mechamaru.Absolute.Special.Shot, v23, game.SoundService.Effect)
					if p21 then
						v_u_11:Flash(p21, Color3.new(1, 0, 0))
						p20 = CFrame.lookAlong(p21.HumanoidRootPart.Position, p20.LookVector)
					end
					local v26 = v_u_6.Mechamaru.GunBullet:Clone()
					v26.WorldCFrame = p20
					v26.BeamStart.WorldPosition = v24.Position
					v26.Parent = workspace.Effects
					v_u_2:AddItem(v26, 2)
					v_u_3:Create(v26.BeamStart.Beam, TweenInfo.new(0.3), {
						["Width1"] = 0
					}):Play()
					for _, v27 in v26:GetChildren() do
						if v27:IsA("ParticleEmitter") then
							v27:Emit(v27:GetAttribute("EmitCount"))
						end
					end
					if v_u_4:DistanceFromCharacter(p20.Position) < 40 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
					v_u_11:PlaySound(v_u_7.Mahito.Soulfire.Fire, v26, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["SpecialStartSound"] = function(p28)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				v_u_11:PlaySound(v_u_7.Mechamaru.Absolute.Special.Start, v29, game.SoundService.Effect)
			end
		end,
		["SimpleDomainDart"] = function(p_u_30, p31)
			-- upvalues: (ref) v_u_6, (ref) v_u_11, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v_u_32 = p_u_30:FindFirstChild("Torso")
			if v_u_32 then
				local v33 = RaycastParams.new()
				v33.FilterType = Enum.RaycastFilterType.Include
				v33.FilterDescendantsInstances = { v_u_32 }
				local v_u_34 = v_u_6.Mechamaru.SimpleDomainDart:Clone()
				v_u_34.Parent = workspace.Effects
				local v_u_35 = CFrame.new(0, 0, -0.5) * CFrame.Angles(0, 3.141592653589793, 0)
				local v36 = v_u_32.Position - p31
				local v37 = workspace:Raycast(p31, v36, v33)
				if v37 then
					local v38 = v37.Position
					local _ = v37.Normal
					local v39 = CFrame.lookAt(v38, v38 + v36.Unit)
					v_u_35 = v_u_32.CFrame:ToObjectSpace(v39)
				end
				local v40 = Instance.new("Weld", v_u_34)
				v40.Part1 = v_u_34
				v40.C0 = v_u_35
				v40.Part0 = v_u_32
				v_u_11:PlaySound(v_u_7.Mahito.Soulfire.Hit, p_u_30.HumanoidRootPart, game.SoundService.Effect)
				task.wait(1)
				v_u_34.Capsule.Attachment.Sparks.Enabled = true
				local v41 = tick()
				local v42 = v_u_34.CapsuleWeld
				task.delay(0.2, function()
					-- upvalues: (ref) v_u_11, (ref) v_u_7, (copy) p_u_30, (ref) v_u_6, (copy) v_u_32, (ref) v_u_35, (ref) v_u_3, (ref) v_u_2, (copy) v_u_34
					v_u_11:PlaySound(v_u_7.Mahito.Soulfire.Morph, p_u_30.HumanoidRootPart, game.SoundService.Effect)
					local v43 = true
					for _ = 1, 10 do
						for _ = 1, 2 do
							local v44 = v_u_6.Mahito.Morph:Clone()
							v44.Weld.Part0 = v_u_32
							v44.Color = v_u_32.Color
							v44.Weld.C0 = CFrame.new(v_u_35.Position) * CFrame.new(math.random(-30, 30) / 100, math.random(-30, 30) / 100, 0)
							v44.Parent = workspace.Effects
							v44.Size = Vector3.new(1, 1, 1) * (math.random(5, 7) / 10)
							v_u_3:Create(v44, TweenInfo.new(math.random(10, 40) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
							v_u_2:AddItem(v44, 0.4)
						end
						if p_u_30:GetAttribute("Moveset") == "Mahito" and v43 then
							task.spawn(function()
								-- upvalues: (ref) p_u_30, (ref) v_u_34, (ref) v_u_6, (ref) v_u_2, (ref) v_u_7, (ref) v_u_11, (ref) v_u_3
								local v45 = p_u_30:FindFirstChild("HumanoidRootPart")
								local v46 = CFrame.lookAlong(v_u_34.Position, -v_u_34.CFrame.LookVector)
								local v47 = {
									Color3.fromRGB(170, 170, 127),
									Color3.fromRGB(255, 170, 255),
									Color3.fromRGB(85, 170, 127),
									Color3.fromRGB(85, 85, 127),
									Color3.fromRGB(85, 85, 0)
								}
								if (workspace.CurrentCamera.CFrame.Position - v45.Position).Magnitude <= 300 then
									local v48 = v_u_6.Mahito.Worms.Worm:Clone()
									local v49 = CFrame.Angles
									local v50 = math.random(70, 110)
									local v51 = math.rad(v50)
									local v52 = math.random(-20, 20)
									v48:SetPrimaryPartCFrame(v46 * v49(v51, math.rad(v52), 0))
									local v53 = v46.LookVector * math.random(80, 120)
									local v54 = v48["1"]
									local v55 = math.random(-200, 200)
									local v56 = math.random(-200, 200)
									local v57 = math.random
									v54.RotVelocity = Vector3.new(v55, v56, v57(-200, 200))
									local v58 = v47[math.random(1, #v47)]
									for _, v59 in v48:GetChildren() do
										v59.Color = v58
										v59.Velocity = v53
									end
									v48.Parent = workspace.Effects
									v_u_2:AddItem(v48, 3)
									for v60 = 2, 4 do
										local v61 = v48[tostring(v60)]
										local v62 = v60 - 1
										local v63 = v48[tostring(v62)]
										local v64 = Instance.new("Attachment", v61)
										local v65 = Instance.new("Attachment", v63)
										v64.Position = Vector3.new(0, 0, -1.5)
										v65.Position = Vector3.new(0, 0, 1.5)
										local v66 = Instance.new("BallSocketConstraint")
										v66.Attachment0 = v64
										v66.Attachment1 = v65
										v66.LimitsEnabled = true
										v66.Parent = v64
									end
									v48[tostring(5)]:Destroy()
									v48[tostring(6)]:Destroy()
									v48[tostring(7)]:Destroy()
									v48[tostring(8)]:Destroy()
									v48:ScaleTo(0.5)
									v_u_7.Mahito.Worms.Fire.PlaybackSpeed = math.random(140, 200) / 100
									v_u_11:PlaySound(v_u_7.Mahito.Worms.Fire, v48["1"], game.SoundService.Effect)
									local v67 = v48[tostring(1)]
									v67.CanCollide = true
									v67.Anchored = false
									local v68 = v48[tostring(2)]
									v68.CanCollide = true
									v68.Anchored = false
									local v69 = v48[tostring(3)]
									v69.CanCollide = true
									v69.Anchored = false
									local v70 = v48[tostring(4)]
									v70.CanCollide = true
									v70.Anchored = false
									task.wait(1.6)
									local v71 = TweenInfo.new(0.1111111111111111)
									local v72 = {
										["Size"] = Vector3.new(0, 0, 0)
									}
									for v73 = 4, 1, -1 do
										v_u_3:Create(v48[tostring(v73)], v71, v72):Play()
										task.wait(0.1111111111111111)
									end
								end
							end)
							v43 = false
						else
							v43 = true
						end
						task.wait(0.07)
					end
				end)
				local v74 = 0
				local v75 = 1
				repeat
					local v76 = task.wait()
					local v77 = (tick() - v41) / 1
					local v78 = math.clamp(v77, 0, 1)
					v42.C1 = CFrame.new(v78 * 1, 0, 0) * CFrame.Angles(math.rad(v74), 0, 0)
					v74 = v74 + v76 * 720
				until v75 <= tick() - v41
				for _, v79 in v_u_34.Detonate:GetChildren() do
					v79:Emit(v79:GetAttribute("EmitCount"))
				end
				v_u_34.Capsule.Attachment:Destroy()
				v_u_34.Capsule.Transparency = 1
				v_u_11:Flash(p_u_30, Color3.new(1, 0, 0))
				if v_u_4:DistanceFromCharacter(v_u_34.Detonate.WorldPosition) < 40 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
				v_u_11:PlaySound(v_u_7.Mahito.Soulfire.Fire, v_u_34, game.SoundService.Effect)
				v_u_2:AddItem(v_u_34, 2)
			end
		end
	}
	v_u_9.Effects:Connect(function(p81, ...)
		-- upvalues: (copy) v_u_80
		local v82 = v_u_80[p81]
		if v82 then
			v82(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("TechniqueChargeService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12