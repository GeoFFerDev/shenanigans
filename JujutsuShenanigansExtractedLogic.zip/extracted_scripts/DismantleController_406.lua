-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "DismantleController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_2, (copy) v_u_6, (copy) v_u_3, (copy) v_u_9, (copy) v_u_4, (copy) v_u_8, (ref) v_u_12, (ref) v_u_10
	local v_u_63 = {
		["Swing"] = function(p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			v_u_11:PlaySound(v_u_7.Misc.Swing.Fist, v15, game.SoundService.Effect)
		end,
		["Hit"] = function(p16, p17)
			-- upvalues: (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = p17:FindFirstChild("HumanoidRootPart")
				if v19 then
					local v20 = Instance.new("Model", workspace.Effects)
					v_u_2:AddItem(v20, 0.65)
					local v21 = Instance.new("Highlight", v20)
					v21.DepthMode = Enum.HighlightDepthMode.Occluded
					v21.FillTransparency = 0
					v21.FillColor = Color3.new(0, 0, 0)
					for _ = 1, 10 do
						local v22 = CFrame.new(v18.Position, v19.Position) * CFrame.new(math.random(-40, 40) / 10, math.random(-40, 40) / 10, 0)
						local v23 = CFrame.Angles
						local v24 = math.random(0, 360)
						local v_u_25 = v22 * v23(0, 0, (math.rad(v24)))
						local v_u_26 = v_u_6.Itadori.Dismantle.DismantleFly:Clone()
						v_u_26.CFrame = v_u_25
						v_u_26.Parent = v20
						task.delay(0, function()
							-- upvalues: (ref) v_u_3, (copy) v_u_26, (copy) v_u_25
							v_u_3:Create(v_u_26, TweenInfo.new(0.1), {
								["Size"] = Vector3.new(15, 0, 0),
								["CFrame"] = v_u_25 + v_u_25.LookVector * 30
							}):Play()
							task.wait(0.1)
							v_u_26.Transparency = 1
							task.wait(0.05)
							v_u_26:Destroy()
						end)
						task.wait(0.05)
					end
				end
			else
				return
			end
		end,
		["Hit2"] = function(p27)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9
			local v28 = p27:FindFirstChild("HumanoidRootPart")
			if v28 then
				v_u_11:Flash(p27, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Slash, v28, game.SoundService.Effect)
				v_u_9:Blood(p27.Torso.CFrame, 50, 180, 180)
			end
		end,
		["Finisher"] = function(p29)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v31 = v_u_6.Itadori.Dismantle.Dismantle:Clone()
				v31.Anchored = true
				v31.CFrame = v30.CFrame
				v31.Slash1.Enabled = false
				v31.Parent = workspace.Effects
				v_u_2:AddItem(v31, 2)
				v31.SlashFinish2.Glow:Emit(1)
				v31.SlashFinish2.Wind:Emit(2)
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.FinishSlash, v31, game.SoundService.Effect)
				task.wait(0.2)
				v31.SlashFinish1:Emit(4)
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, v31, game.SoundService.Effect)
				v_u_11:Bleed(p29)
			end
		end,
		["Chant"] = function(p32, p33)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7
			local v34 = p32:FindFirstChild("HumanoidRootPart")
			if v34 then
				local v_u_35 = v_u_6.Heian.Chant.Chant:Clone()
				v_u_35.Parent = p32.Head
				v_u_2:AddItem(v_u_35, 1)
				v_u_3:Create(v_u_35, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["StudsOffset"] = Vector3.new(2, 2, 2)
				}):Play()
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_35
					v_u_3:Create(v_u_35.Chat, TweenInfo.new(0.5), {
						["ImageTransparency"] = 1
					}):Play()
					v_u_3:Create(v_u_35.Chat.Sub, TweenInfo.new(0.5), {
						["TextTransparency"] = 1
					}):Play()
				end)
				if p33 == 1 then
					v_u_11:Flash(p32, Color3.fromRGB(255, 255, 255), 2)
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.WorldSlash1, v34, game.SoundService.Effect)
					return
				elseif p33 == 2 then
					v_u_11:Flash(p32, Color3.fromRGB(255, 255, 255), 2)
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.WorldSlash2, v34, game.SoundService.Effect)
					v_u_35.Chat.Sub.Text = "RECOIL..."
				elseif p33 == 3 then
					v_u_11:Flash(p32, Color3.fromRGB(255, 0, 0), 1)
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.WorldSlash3, v34, game.SoundService.Effect)
					v_u_35.Chat.Sub.Text = "TWIN METEORS."
					task.wait(0.5)
					local v36 = v_u_6.Gojo.LapseBlue.LapseBlue.Grab:Clone()
					v36.Weld.Part0 = v36
					v36.Weld.Part1 = v34
					v36.Parent = workspace.Effects
					local v37 = Instance.new("Highlight", v36)
					v37.FillTransparency = 1
					v37.OutlineTransparency = 1
					v_u_3:Create(v36, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(100, 6, 10),
						["Transparency"] = 50
					}):Play()
					v_u_2:AddItem(v36, 0.5)
				end
			else
				return
			end
		end,
		["WorldSlash"] = function(p38, p39)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			if p38:FindFirstChild("HumanoidRootPart") then
				local v40 = v_u_6.Itadori.Dismantle.WorldSlash:Clone()
				v40.CFrame = p39 + p39.LookVector * 30
				v40.Parent = workspace.Effects
				v_u_3:Create(v40.Slash, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(0, 0, 60)
				}):Play()
				v_u_3:Create(v40.Weld, TweenInfo.new(0.1), {
					["C1"] = CFrame.new(0, 0, 30)
				}):Play()
				v_u_2:AddItem(v40.Slash, 0.1)
				local v41 = Instance.new("Highlight", v40.Slash)
				v41.DepthMode = Enum.HighlightDepthMode.Occluded
				v41.FillTransparency = 0
				v41.FillColor = Color3.new(0, 0, 0)
				v_u_2:AddItem(v40, 0.5)
				v40.Smear:Emit(50)
				v40.Stars:Emit(30)
				local v42 = v_u_6.Itadori.Dismantle.WorldSlash.Slash:Clone()
				v42.Material = Enum.Material.Glass
				local v43 = Instance.new("Weld", v42)
				v42.Weld.Part0 = v40
				v42.Weld.Part1 = v42
				v42.Weld.C1 = CFrame.new(0, 0, 30)
				v42.Transparency = 50
				v42.Size = Vector3.new(100, 6, 10)
				v42.Parent = v40
				local v44 = Instance.new("Highlight", v42)
				v44.FillTransparency = 1
				v44.OutlineTransparency = 1
				v_u_3:Create(v42, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(0, 0, 60),
					["Transparency"] = 1
				}):Play()
				v_u_3:Create(v43, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["C1"] = CFrame.new(0, 0, 15)
				}):Play()
				if v_u_4.Character == p38 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["WorldHit"] = function(p45, p46)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6
			local v47 = p45:FindFirstChild("HumanoidRootPart")
			if v47 then
				v_u_11:Flash(p45, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Slash, v47, game.SoundService.Effect)
				if p46 then
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, v47, game.SoundService.Effect)
					v_u_11:Bleed(p45)
					if v_u_4.Character == p45 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						local v48 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v48.TintColor = Color3.new(1, 1, 1)
						v48.Parent = game.Lighting
						task.wait(0.04)
						v48.Brightness = 200
						v48.Contrast = -1000
						task.wait(0.04)
						v48:Destroy()
					end
				end
			end
		end,
		["DismantleFly"] = function(p49, p50)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v51 = p49:FindFirstChild("HumanoidRootPart")
			if v51 then
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.FinishSlash, v51, game.SoundService.Effect)
				local v52 = v_u_6.Itadori.Dismantle.DismatleProj:Clone()
				v52.CFrame = p50 + p50.LookVector * 30
				v52.Parent = workspace.Effects
				v_u_3:Create(v52.Slash, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(0, 0, 60)
				}):Play()
				v_u_3:Create(v52.Weld, TweenInfo.new(0.1), {
					["C1"] = CFrame.new(0, 0, 30)
				}):Play()
				v_u_2:AddItem(v52.Slash, 0.1)
				local v53 = Instance.new("Highlight", v52.Slash)
				v53.DepthMode = Enum.HighlightDepthMode.Occluded
				v53.FillTransparency = 0
				v53.FillColor = Color3.new(0, 0, 0)
				v_u_2:AddItem(v52, 0.5)
				v52.Smear:Emit(50)
				v52.Stars:Emit(30)
				local v54 = v_u_6.Itadori.Dismantle.WorldSlash.Slash:Clone()
				v54.Material = Enum.Material.Glass
				local v55 = Instance.new("Weld", v54)
				v54.Weld.Part0 = v52
				v54.Weld.Part1 = v54
				v54.Weld.C1 = CFrame.new(0, 0, 30)
				v54.Transparency = 50
				v54.Size = Vector3.new(100, 6, 10)
				v54.Parent = v52
				local v56 = Instance.new("Highlight", v54)
				v56.FillTransparency = 1
				v56.OutlineTransparency = 1
				v_u_3:Create(v54, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(0, 0, 60),
					["Transparency"] = 1
				}):Play()
				v_u_3:Create(v55, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["C1"] = CFrame.new(0, 0, 15)
				}):Play()
				if v_u_4.Character == p49 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Aerial"] = function(p57, p58)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_12
			local v59 = p57:FindFirstChild("HumanoidRootPart")
			if v59 then
				local v60 = p57:FindFirstChild("Humanoid")
				if v60 then
					p58.Position = v59.Position + Vector3.new(0, 12, 0)
					v_u_11:PlaySound(v_u_7.Itadori.CursedStrikes.Spin, v59, game.SoundService.Effect)
					local v61 = Instance.new("BodyGyro", v59)
					v61.P = 10000
					v61.MaxTorque = Vector3.new(40000, 40000, 40000)
					v60.PlatformStand = true
					repeat
						local v62 = v_u_12:GetMouseTarget()
						v61.CFrame = CFrame.new(v59.Position, v62)
						task.wait()
					until not p58.Parent
					v61:Destroy()
					v60.PlatformStand = false
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p64, ...)
		-- upvalues: (copy) v_u_63
		local v65 = v_u_63[p64]
		if v65 then
			v65(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("DismantleService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("ToolController")
end
return v13