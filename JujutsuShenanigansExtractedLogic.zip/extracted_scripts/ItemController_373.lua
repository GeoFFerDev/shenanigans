-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game.Players.LocalPlayer
local v7 = game.ReplicatedStorage
local _ = v7.Animations
local v_u_8 = v7.Utils
local v_u_9 = v7.Sounds
local v_u_10 = require(v7.Modules.CameraShaker)
local v_u_11 = require(v7.Modules.BloodyZee)
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "ItemController"
})
function v15.KnitStart(_)
	-- upvalues: (copy) v_u_4, (ref) v_u_13, (copy) v_u_11, (copy) v_u_9, (copy) v_u_8, (copy) v_u_10, (copy) v_u_5, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (ref) v_u_12
	local v_u_164 = {
		["Soda"] = function(p16, p17)
			-- upvalues: (ref) v_u_4
			local v18 = p16.HumanoidRootPart
			if v18 then
				local v19 = p17:Clone()
				v_u_4:AddItem(v19, 2)
				v19.Weld:Destroy()
				v19.CFrame = p17.CFrame
				v19.CollisionGroup = "Effects"
				v19.Part.CollisionGroup = "Effects"
				v19.CanCollide = true
				v19.Part.CanCollide = true
				v19.Parent = workspace.Effects
				if v18 and v18.Parent then
					v19.Velocity = v18.CFrame.RightVector * 20
				end
				p17.Transparency = 1
				for _, v20 in p17:GetDescendants() do
					if v20:IsA("BasePart") then
						v20.Transparency = 1
					end
				end
			end
		end,
		["SodaHit"] = function(p21)
			-- upvalues: (ref) v_u_13, (ref) v_u_11, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_10
			local v22 = p21.HumanoidRootPart
			if v22 then
				v_u_13:Flash(p21, Color3.new(1, 1, 1))
				for _ = 1, 20 do
					v_u_11:Blood(p21.Head.CFrame, math.random(5, 150), 45, 45)
				end
				v_u_13:PlaySound(v_u_9.Misc.Items.SodaHit, v22, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Itadori.DivergentFist.DivergentHit, v22, game.SoundService.Effect)
				local v23 = v_u_8.Gojo.Twofold.Sparks:Clone()
				v23.Parent = p21.Head
				v23:Emit(20)
				v_u_4:AddItem(v23, 0.4)
				if (workspace.CurrentCamera.CFrame.Position - v22.Position).Magnitude < 60 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
			end
		end,
		["Gunfire"] = function(p24)
			-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			p24.Mesh.Attachment.Flash:Emit(2)
			p24.Mesh.Attachment.PointLight.Brightness = 15
			v_u_5:Create(p24.Mesh.Attachment.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v_u_13:PlaySound(v_u_9.Misc.Items.Gunfire, p24, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p24.Position).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			end
		end,
		["Sniperfire"] = function(p25)
			-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			p25.Sniper.Attachment.Flash:Emit(2)
			p25.Sniper.Attachment.PointLight.Brightness = 15
			v_u_5:Create(p25.Sniper.Attachment.PointLight, TweenInfo.new(1), {
				["Brightness"] = 0
			}):Play()
			v_u_13:PlaySound(v_u_9.Misc.Items.Sniperfire, p25, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p25.Position).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			end
		end,
		["SniperBolt"] = function(p26)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			v_u_13:PlaySound(v_u_9.Misc.Items.Bolt, p26, game.SoundService.Effect)
			task.wait(0.1)
			p26.Sniper.Attachment.Bolt.Casing:Emit(1)
			p26.Sniper.Attachment.Bolt.Dust:Emit(6)
		end,
		["SniperAim"] = function(p27, p28)
			-- upvalues: (ref) v_u_6, (ref) v_u_8, (ref) v_u_2, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			if v_u_6 == p27 then
				if p28 == true then
					if v_u_6.PlayerGui:FindFirstChild("Crosshair") then
						return
					end
					local v_u_29 = v_u_8.Misc.Items.Crosshair:Clone()
					v_u_29.Parent = v_u_6.PlayerGui
					v_u_6.CameraMode = Enum.CameraMode.LockFirstPerson
					v_u_2.MouseDeltaSensitivity = 0.1
					local v_u_30 = nil
					v_u_30 = v_u_3.RenderStepped:Connect(function()
						-- upvalues: (copy) v_u_29, (ref) v_u_30, (ref) v_u_6
						if v_u_29.Parent then
							local v31 = v_u_6.Character
							if v31 then
								v31 = v_u_6.Character:FindFirstChild("Humanoid")
							end
							if v31 then
								v31.CameraOffset = Vector3.new(0, 0, 0)
								local v32 = workspace.CurrentCamera
								if v32.CameraType == Enum.CameraType.Custom then
									local v33 = v32.CFrame.LookVector.X
									local v34 = v32.CFrame.LookVector.Z
									local v35 = Vector3.new(v33, 0, v34)
									v32.CFrame = CFrame.lookAlong(v32.CFrame.Position, v35)
									v32.FieldOfView = 10
								end
							else
								return
							end
						else
							v_u_30:Disconnect()
							return
						end
					end)
				else
					v_u_6.CameraMode = Enum.CameraMode.Classic
					local v36 = v_u_6.PlayerGui:FindFirstChild("Crosshair")
					if v36 then
						v36:Destroy()
					end
					v_u_2.MouseDeltaSensitivity = 1
					workspace.CurrentCamera.FieldOfView = 70
					if v_u_6.CameraMinZoomDistance == 0.5 then
						v_u_6.CameraMinZoomDistance = 10
						task.wait(0.1)
						v_u_6.CameraMinZoomDistance = 0.5
					end
				end
			end
			local v37 = p27.Character
			if v37 then
				v37 = p27.Character:FindFirstChild("HumanoidRootPart")
			end
			if v37 then
				if p28 then
					v_u_13:PlaySound(v_u_9.Misc.Items.ScopeIn, v37, game.SoundService.Effect)
				else
					v_u_13:PlaySound(v_u_9.Misc.Items.ScopeOut, v37, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Interp"] = function(p_u_38)
			-- upvalues: (ref) v_u_3
			local v_u_39 = p_u_38.CFrame
			local v_u_40 = tick()
			local v_u_41 = p_u_38:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_39, (copy) p_u_38, (ref) v_u_40
				v_u_39 = p_u_38.CFrame
				v_u_40 = tick()
			end)
			local v_u_42 = nil
			v_u_42 = v_u_3.Stepped:Connect(function()
				-- upvalues: (copy) p_u_38, (ref) v_u_42, (copy) v_u_41, (ref) v_u_39, (ref) v_u_40
				if p_u_38.Parent == workspace.Bullets then
					if p_u_38.Parent then
						workspace:BulkMoveTo({ p_u_38 }, { v_u_39 + v_u_39.LookVector * (p_u_38:GetAttribute("Speed") * (tick() - v_u_40)) }, Enum.BulkMoveMode.FireCFrameChanged)
					else
						v_u_42:Disconnect()
						v_u_41:Disconnect()
					end
				else
					return
				end
			end)
		end,
		["GunBreak"] = function(p43, p44)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_6, (ref) v_u_10
			local v45 = p43:FindFirstChild("HumanoidRootPart")
			if v45 then
				for _ = 1, 10 do
					local v_u_46 = v_u_8.Hiromi.GavelShard:Clone()
					v_u_46.Position = p44
					v_u_46.Size = v_u_46.Size * (math.random(30, 100) / 100)
					v_u_46.Color = Color3.fromRGB(33, 33, 33)
					local v47 = math.random(-50, 50)
					local v48 = math.random(-50, 50)
					local v49 = math.random
					v_u_46.Velocity = Vector3.new(v47, v48, v49(-50, 50))
					local v50 = math.random(-50, 50)
					local v51 = math.random(-50, 50)
					local v52 = math.random
					v_u_46.RotVelocity = Vector3.new(v50, v51, v52(-50, 50))
					v_u_46.Parent = workspace.Effects
					v_u_4:AddItem(v_u_46, 2)
					task.delay(1, function()
						-- upvalues: (ref) v_u_5, (copy) v_u_46
						v_u_5:Create(v_u_46, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
				v_u_13:PlaySound(v_u_9.Misc.Items.Gunbreak, v45, game.SoundService.Effect)
				if v_u_6.Character == p43 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
				end
			end
		end,
		["Breakball"] = function(p53)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_9
			if p53.Parent then
				for _ = 1, 10 do
					local v_u_54 = v_u_8.Hiromi.GavelShard:Clone()
					v_u_54.Position = p53.Position
					v_u_54.Size = v_u_54.Size * (math.random(30, 100) / 100)
					v_u_54.Color = Color3.fromRGB(33, 33, 33)
					local v55 = math.random(-50, 50)
					local v56 = math.random(-50, 50)
					local v57 = math.random
					v_u_54.Velocity = Vector3.new(v55, v56, v57(-50, 50))
					local v58 = math.random(-50, 50)
					local v59 = math.random(-50, 50)
					local v60 = math.random
					v_u_54.RotVelocity = Vector3.new(v58, v59, v60(-50, 50))
					v_u_54.Parent = workspace.Effects
					v_u_4:AddItem(v_u_54, 2)
					task.delay(1, function()
						-- upvalues: (ref) v_u_5, (copy) v_u_54
						v_u_5:Create(v_u_54, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
				v_u_13:PlaySound(v_u_9.Misc.Items.Breakball, p53, game.SoundService.Effect)
			end
		end,
		["BulletHit"] = function(p61)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6, (ref) v_u_10
			local v62 = p61:FindFirstChild("HumanoidRootPart")
			if v62 then
				v_u_13:Flash(p61, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Mahito.Soulfire.Hit, v62, game.SoundService.Effect)
				local v63 = v_u_8.Gojo.Twofold.Sparks:Clone()
				v63.Parent = v62.RootAttachment
				v63:Emit(20)
				v_u_4:AddItem(v63, 0.4)
				if v_u_6.Character == p61 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
				end
			end
		end,
		["Coin"] = function(p64)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			v_u_13:PlaySound(v_u_9.Misc.Items.Coin, p64, game.SoundService.Effect)
			p64.Coin.Shine:Emit(1)
		end,
		["CoinParry"] = function(p65)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			v_u_13:PlaySound(v_u_9.Misc.Items.Parry, p65, game.SoundService.Effect)
			p65.Coin.Sparks:Emit(15)
			p65.Coin.Wind2:Emit(15)
			if (workspace.CurrentCamera.CFrame.Position - p65.Position).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
			end
		end,
		["BananaPeel"] = function(p66)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			v_u_13:PlaySound(v_u_9.Misc.Items.BananaPeel, p66, game.SoundService.Effect)
		end,
		["BananaPeelSlip"] = function(p67)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			v_u_13:PlaySound(v_u_9.Misc.Items.BananaPeelSlip, p67, game.SoundService.Effect)
		end,
		["TNT"] = function(p68)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5
			v_u_13:PlaySound(v_u_9.Misc.Items.TNT, p68, game.SoundService.Effect)
			local v69 = Instance.new("Highlight")
			v69.DepthMode = Enum.HighlightDepthMode.Occluded
			v69.FillColor = Color3.new(1, 1, 1)
			v69.FillTransparency = 1
			v69.OutlineTransparency = 1
			v69.Parent = p68.Part
			task.wait(0.25)
			for v70 = 1, 7 do
				if v70 == 7 and p68.Parent then
					v_u_5:Create(p68.Part, TweenInfo.new(0.65, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(4, 4, 4)
					}):Play()
				end
				v_u_5:Create(v69, TweenInfo.new(0.25), {
					["FillTransparency"] = 0.25
				}):Play()
				task.wait(0.25)
				v_u_5:Create(v69, TweenInfo.new(0.25), {
					["FillTransparency"] = 1
				}):Play()
				task.wait(0.25)
			end
		end,
		["TNTExplode"] = function(p71)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v72 = v_u_8.Misc.Items.TNTExplosion:Clone()
			v_u_4:AddItem(v72, 5)
			v72.Position = p71
			v72.Parent = workspace.Effects
			v72.Effect:Emit(255)
			v_u_13:PlaySound(v_u_9.Misc.Items.TNTExplode, v72, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p71).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			end
		end,
		["JetSwing"] = function(p73)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			v_u_13:PlaySound(v_u_9.Misc.Swing.Sword, p73, game.SoundService.Effect)
		end,
		["JetHit"] = function(p74)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v75 = p74:FindFirstChild("HumanoidRootPart")
			if v75 then
				v_u_13:Flash(p74, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Megumi.Mahoraga.M1:FindFirstChild("Hit1"), v75, game.SoundService.Effect)
			end
		end,
		["Explode"] = function(p76)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v77 = v_u_8.Misc.Items.EyeBomb:Clone()
			v77.Position = p76
			v77.Parent = workspace.Effects
			v_u_4:AddItem(v77, 3)
			for _, v78 in v77:GetChildren() do
				v78:Emit(v78:GetAttribute("EmtiCount"))
			end
			v_u_13:PlaySound(v_u_9.Misc.Items.Eye, v77, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p76).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			end
		end,
		["Voice"] = function(p79, p80)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v81 = v_u_8.Misc.Items.Voice:Clone()
			v81.Position = p79
			v81.Parent = workspace.Effects
			v_u_4:AddItem(v81, 4)
			for _, v82 in v81:GetChildren() do
				v82:Emit(v82:GetAttribute("EmtiCount"))
			end
			v_u_13:PlaySound(v_u_9.Misc.Items.Voice, v81, game.SoundService.Effect)
			if p80 == "Plummet" then
				v_u_13:PlaySound(v_u_9.Yuta.MutualLove.VoiceCrush, v81, game.SoundService.Voice)
			elseif p80 == "Blast" then
				v_u_13:PlaySound(v_u_9.Misc.Items.Voice3, v81, game.SoundService.Voice)
			else
				v_u_13:PlaySound(v_u_9.Misc.Items.Voice2, v81, game.SoundService.Voice)
			end
			if (workspace.CurrentCamera.CFrame.Position - p79).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
			end
		end,
		["VoiceHit"] = function(p83, p84)
			-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_5, (ref) v_u_4, (ref) v_u_8
			local v85 = p83.HumanoidRootPart
			if v85 then
				if v_u_6.Character == p83 then
					v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.Snap):StartFadeOut(1)
					local v_u_86 = Instance.new("ColorCorrectionEffect", game.Lighting)
					v_u_86.Contrast = -2
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_86, (ref) v_u_5, (ref) v_u_4
						v_u_86.Saturation = -2
						task.wait(0.1)
						v_u_86.Contrast = 0
						v_u_5:Create(v_u_86, TweenInfo.new(0.5), {
							["Saturation"] = 0
						}):Play()
						v_u_4:AddItem(v_u_86, 0.5)
					end)
				end
				local v87 = v_u_8.Misc.Items.VoiceHit:Clone()
				v87.Weld.Part0 = v85
				v87.Parent = workspace.Effects
				while true do
					for _ = 1, 2 do
						local v88 = workspace.CurrentCamera.CFrame
						local v89 = v_u_8.Damage.HitGlow:GetChildren()
						local v90 = v89[math.random(1, #v89)]
						if p83:FindFirstChild(v90.Name) then
							local v91 = v90:Clone()
							v91.Anchored = true
							v91.BrickColor = BrickColor.random()
							v91.Parent = workspace.Effects
							v91.CFrame = p83:FindFirstChild(v91.Name).CFrame + v88.LookVector * 0.3 + v88.RightVector * math.random(-70, 70) / 100 + v88.UpVector * math.random(-70, 70) / 100
							v_u_4:AddItem(v91, 0.04)
						end
					end
					task.wait(0.02)
					if not (p83.Parent and p84.Parent) then
						v87.Aura.Enabled = false
						v87.Lines.Enabled = false
						v87.Attachment.Sparks1:Emit(20)
						v87.Attachment.WindCircle:Emit(2)
						v_u_4:AddItem(v87, 1)
						return
					end
				end
			else
				return
			end
		end,
		["VoiceSwitch"] = function(p92)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v93 = { Color3.fromRGB(255, 80, 80), Color3.fromRGB(255, 190, 60), Color3.fromRGB(80, 255, 80) }
			p92.Part.Mode.Glow.Color = ColorSequence.new(v93[p92:GetAttribute("Mode")])
			v_u_13:PlaySound(v_u_9.Misc.Items.VoiceSwitch, p92, game.SoundService.Effect)
		end,
		["Wall"] = function(p_u_94)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_5, (ref) v_u_4
			v_u_13:PlaySound(v_u_9.Misc.Items.Wall, p_u_94, game.SoundService.Effect)
			p_u_94:GetPropertyChangedSignal("Size"):Connect(function()
				-- upvalues: (ref) v_u_8, (copy) p_u_94, (ref) v_u_5, (ref) v_u_4
				for _ = 1, 2 do
					local v95 = v_u_8.Mahito.Morph:Clone()
					v95.Weld.Part0 = p_u_94
					v95.Color = p_u_94.Color
					v95.Material = p_u_94.Material
					v95.Weld.C1 = CFrame.new(math.random(-p_u_94.Size.X / 2, p_u_94.Size.X / 2), math.random(-p_u_94.Size.Y / 2, p_u_94.Size.Y / 2), math.random(-p_u_94.Size.Z / 2, p_u_94.Size.Z / 2))
					v95.Parent = workspace.Effects
					v95.Size = Vector3.new(1, 1, 1) * (math.random(30, 60) / 10)
					v_u_5:Create(v95, TweenInfo.new(math.random(10, 40) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_4:AddItem(v95, 0.4)
				end
			end)
		end,
		["PlayfulSwing"] = function(p96, p97, p98)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v99 = p96.HumanoidRootPart
			if v99 then
				if p98 == "Down" then
					v_u_13:ArmFlash(p96["Right Leg"], Color3.fromRGB(255, 0, 0), 0.4)
					v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v99, game.SoundService.Effect)
					return
				elseif p98 == "Up" then
					v_u_13:ArmFlash(p96["Right Arm"], Color3.fromRGB(255, 0, 0), 0.3)
					v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v99, game.SoundService.Effect)
				else
					v_u_13:PlaySound(v_u_9.Misc.Items.PlayfulSwing["Swing" .. p97], v99, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["PlayfulHit"] = function(p100, p101)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4
			local v102 = p100:FindFirstChild("HumanoidRootPart")
			if v102 then
				v_u_13:Flash(p100, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Itadori.M1:FindFirstChild("Hit" .. p101), v102, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Hiromi.M1:FindFirstChild("Hit" .. p101), v102, game.SoundService.Effect)
				local v103 = v_u_8.Misc.Items.BiteHit:Clone()
				v103.Position = v102.Position
				v103.Parent = workspace.Effects
				v_u_4:AddItem(v103, 0.5)
				for _, v104 in v103:GetChildren() do
					v104:Emit(v104:GetAttribute("EmitCount"))
				end
			end
		end,
		["PlayfulBreak"] = function(p105, p106)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_9
			local v107 = p105:FindFirstChild("HumanoidRootPart")
			if v107 then
				for _ = 1, 10 do
					local v_u_108 = v_u_8.Hiromi.GavelShard:Clone()
					v_u_108.Position = p106.Core.Position
					v_u_108.Size = v_u_108.Size * (math.random(30, 100) / 100)
					v_u_108.Color = Color3.fromRGB(194, 46, 46)
					local v109 = math.random(-50, 50)
					local v110 = math.random(-50, 50)
					local v111 = math.random
					v_u_108.Velocity = Vector3.new(v109, v110, v111(-50, 50))
					local v112 = math.random(-50, 50)
					local v113 = math.random(-50, 50)
					local v114 = math.random
					v_u_108.RotVelocity = Vector3.new(v112, v113, v114(-50, 50))
					v_u_108.Parent = workspace.Effects
					v_u_4:AddItem(v_u_108, 2)
					task.delay(1, function()
						-- upvalues: (ref) v_u_5, (copy) v_u_108
						v_u_5:Create(v_u_108, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
				v_u_13:PlaySound(v_u_9.Misc.Items.Gunbreak, v107, game.SoundService.Effect)
			end
		end,
		["PlayfulStuck"] = function(p115, _)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_10
			local v116 = p115:FindFirstChild("HumanoidRootPart")
			if v116 then
				v_u_13:Flash(p115, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Mahito.Soulfire.Hit, v116, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Hiromi.Execution.Sever, v116, game.SoundService.Effect)
				local v117 = v_u_8.Misc.Items.BiteHit:Clone()
				v117.Position = v116.Position
				v117.Parent = workspace.Effects
				v_u_4:AddItem(v117, 0.5)
				for _, v118 in v117:GetChildren() do
					v118:Emit(v118:GetAttribute("EmitCount"))
				end
				if (workspace.CurrentCamera.CFrame.Position - v116.Position).Magnitude < 50 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
			end
		end,
		["PlayfulImpact"] = function(p119)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v120 = v_u_8.Megumi.Mahoraga.Rock:Clone()
			v120.Transparency = 1
			v120.Anchored = true
			v120.Position = p119
			v120.Parent = workspace.Effects
			v120.Attachment.Dust:Emit(20)
			v120.Attachment.Hit:Emit(20)
			v120.Attachment.Sparks:Emit(20)
			v_u_4:AddItem(v120, 1.5)
			v_u_13:PlaySound(v_u_9.Itadori.CrushingBlow.GroundImpact, v120, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p119).Magnitude < 100 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
			end
		end,
		["TintedGlassesOn"] = function(p121, p_u_122)
			local v_u_123 = {}
			local function v_u_126()
				-- upvalues: (copy) v_u_123
				for v124, v125 in next, v_u_123 do
					if typeof(v125) == "RBXScriptConnection" then
						v125:Disconnect()
					else
						v125:Destroy()
					end
					v_u_123[v124] = nil
				end
			end
			local v127 = p121.AncestryChanged
			table.insert(v_u_123, v127:Connect(function(_, p128)
				-- upvalues: (copy) p_u_122, (copy) v_u_126
				if not (p128 and p128:IsDescendantOf(p_u_122)) then
					v_u_126()
				end
			end))
			local v129 = p_u_122.AncestryChanged
			table.insert(v_u_123, v129:Connect(function(_, p130)
				-- upvalues: (copy) v_u_126
				if not p130 then
					v_u_126()
				end
			end))
			local function v135(p131)
				-- upvalues: (copy) v_u_123
				local v132 = p131:WaitForChild("HumanoidRootPart", 2)
				if v132 then
					if not game.Players:GetPlayerFromCharacter(p131) then
						return
					end
					local v133 = game:GetService("ReplicatedStorage").Utils.Reveal:Clone()
					v133.MaxDistance = 75
					v133.Handle.Enabled = true
					v133.Parent = v132
					local v134 = v_u_123
					table.insert(v134, v133)
				end
			end
			local v136 = workspace.Characters.ChildAdded
			table.insert(v_u_123, v136:Connect(v135))
			local v137 = next
			local v138, v139 = workspace.Characters:GetChildren()
			for _, v140 in v137, v138, v139 do
				if v140 ~= p_u_122 then
					v135(v140)
				end
			end
		end,
		["SnowballHit"] = function(p141)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_6, (ref) v_u_10
			local v142 = p141:FindFirstChild("HumanoidRootPart")
			if v142 then
				v_u_13:Flash(p141, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Misc.Items.Snowball.Hit, v142, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Misc.Items.Snowball.Hit2, v142, game.SoundService.Effect)
				if v_u_6.Character == p141 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
			end
		end,
		["Snowball"] = function(p143, p144)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v145 = p143:FindFirstChild("HumanoidRootPart")
			if v145 then
				if p144 then
					v_u_13:PlaySound(v_u_9.Misc.Items.Snowball.Form, v145, game.SoundService.Effect)
				else
					v_u_13:PlaySound(v_u_9.Misc.Items.Snowball.Startup, v145, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["SnowballSpin"] = function(p146)
			-- upvalues: (ref) v_u_5
			local v_u_147 = p146:FindFirstChild("Handle")
			if not v_u_147 then
				return
			end
			v_u_147.Tween.Value = false
			task.wait()
			v_u_147.Tween.Value = true
			v_u_147.Sound:Play()
			local v_u_148 = false
			v_u_147.Tween:GetPropertyChangedSignal("Value"):Once(function()
				-- upvalues: (copy) v_u_147, (ref) v_u_148
				if not v_u_147.Tween.Value then
					v_u_148 = true
				end
			end)
			local v149 = v_u_148
			for v150 = 1, 3 do
				if v149 then
					break
				end
				for _ = 1, 10 do
					if v149 then
						break
					end
					local _, v151, v152 = v_u_147.CFrame:ToOrientation()
					local v153 = (0.05 + (v150 - 1) * 0.12) / 2
					v_u_5:Create(v_u_147, TweenInfo.new(v153, Enum.EasingStyle.Linear), {
						["CFrame"] = CFrame.new(v_u_147.Position) * CFrame.fromOrientation(0, v151, v152) * CFrame.Angles(0, 0, 36)
					}):Play()
					task.wait(v153)
				end
			end
			local _, v154 = v_u_147.CFrame:ToOrientation()
			v_u_5:Create(v_u_147, TweenInfo.new(0.1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
				["CFrame"] = CFrame.new(v_u_147.Position) * CFrame.Angles(0, v154, 0.05754350543825305)
			}):Play()
			if not v149 then
				v_u_147.Tween.Value = false
			end
		end,
		["Clash"] = function(p155)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_10
			local v156 = p155:FindFirstChild("HumanoidRootPart")
			if v156 then
				v_u_13:Flash(p155, Color3.new(1, 1, 0.498039), 0.6)
				v_u_13:PlaySound(v_u_9.Misc.Items.Clash, v156, game.SoundService.Effect)
				local v157 = v_u_8.Misc.Items.Clash.Attachment:Clone()
				v157.Parent = v156
				v_u_4:AddItem(v157, 0.9)
				for _, v158 in v157:GetChildren() do
					if v158:IsA("PointLight") then
						v_u_5:Create(v158, TweenInfo.new(v158:GetAttribute("Duration")), {
							["Brightness"] = 0
						}):Play()
					else
						v158:Emit(v158:GetAttribute("EmitCount"))
					end
				end
				if (workspace.CurrentCamera.CFrame.Position - v156.Position).Magnitude < 150 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
			end
		end,
		["BowlingHit"] = function(p159)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v160 = p159:FindFirstChild("HumanoidRootPart")
			if v160 then
				v_u_13:Flash(p159, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Misc.Items.Hitball, v160, game.SoundService.Effect)
			end
		end,
		["NaginataVaultHit"] = function(p161)
			-- upvalues: (ref) v_u_11, (ref) v_u_6, (ref) v_u_10
			local v162 = p161:FindFirstChild("HumanoidRootPart")
			if v162 then
				for _ = 1, 13 do
					v_u_11:Blood(v162.CFrame - Vector3.new(0, 2, 0), 50, 30, 90)
				end
				if v_u_6.Character == p161 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.MediumHit)
				end
			end
		end,
		["NaginataVaultSlam"] = function(p163)
			-- upvalues: (ref) v_u_6, (ref) v_u_10
			if v_u_6.Character == p163 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
			end
		end
	}
	v_u_12.Effects:Connect(function(p165, ...)
		-- upvalues: (copy) v_u_164
		local v166 = v_u_164[p165]
		if v166 then
			v166(...)
		end
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14
	v_u_12 = v_u_1.GetService("ItemService")
	v_u_13 = v_u_1.GetController("FXController")
	v_u_14 = v_u_1.GetController("CharlesController")
end
return v15