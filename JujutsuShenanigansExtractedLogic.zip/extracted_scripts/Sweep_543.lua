-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("HttpService")
local v_u_2 = require("./Helper")
local v_u_3 = Color3.fromRGB(255, 234, 0)
local v_u_4 = Color3.fromRGB(255, 64, 64)
local v_u_5 = Color3.new(1, 1, 1)
local v_u_6 = {
	["telegraph"] = 0.9,
	["expand"] = 0.22,
	["shrink"] = 0.3,
	["thickness"] = 12,
	["flashRate"] = 9,
	["damage"] = 6,
	["slash"] = 1
}
local v_u_7 = {
	["maxLines"] = 4,
	["rampDuration"] = 1.4,
	["holdDuration"] = 2.1,
	["rotateSpeedEnd"] = 140,
	["thickness"] = 12,
	["damage"] = 7,
	["flashRate"] = 16,
	["pulseTelegraph"] = 0.4,
	["pulseHit"] = 0.3,
	["expand"] = 0.16,
	["shrink"] = 0.16,
	["minGapDeg"] = 28,
	["gapJitterDeg"] = 6,
	["slash"] = 3
}
local v_u_8 = Random.new()
local v_u_9 = {}
v_u_9.__index = v_u_9
v_u_9.Compute = {}
function v_u_9.newSweep(p10, p_u_11, p_u_12, p13, p14)
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_8, (copy) v_u_1, (copy) v_u_9, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	local v15 = p14 or {}
	local v16 = v15.telegraph or v_u_6.telegraph
	local v17 = v15.expand or v_u_6.expand
	local v18 = v15.shrink or v_u_6.shrink
	local v19 = v15.thickness or v_u_6.thickness
	local v20 = v15.flashRate or v_u_6.flashRate
	local v21 = v15.damage or v_u_6.damage
	local v22 = v15.slash or v_u_6.slash
	local v_u_23 = ("Slash %d"):format((math.clamp(v22, 1, 3)))
	local v_u_24 = v_u_2.resolveEffectFolders(p_u_12)
	local v25
	if v15.targetPos then
		v25 = v15.fromGui and v_u_2.absToCenteredOffset(v_u_2.centerAbs(v15.fromGui), p_u_12) + v15.targetPos or Vector2.new(v_u_2.roundpx(v15.targetPos.X), v_u_2.roundpx(v15.targetPos.Y))
	else
		local v26 = p_u_12.AbsoluteSize
		local v27 = v26.X * 0.5
		local v28 = v26.Y * 0.5
		local v29 = Vector2.new(v_u_2.roundpx(v_u_8:NextNumber(-v27 + 8, v27 - 8)), v_u_2.roundpx(v_u_8:NextNumber(-v28 + 8, v28 - 8)))
		v25 = v_u_2.snapV2ToGrid(v29, 32, 32, v_u_2.centerAbs(v15.fromGui))
	end
	local v30 = v15.fromGui and v_u_2.absToCenteredOffset(v_u_2.centerAbs(v15.fromGui), p_u_12) + v25 or Vector2.new(v_u_2.roundpx(v25.X), v_u_2.roundpx(v25.Y))
	local v31 = p13 == "Horizontal" and true or p13 == "Both"
	local v32 = p13 == "Vertical" and true or p13 == "Both"
	local v33 = {
		["Signals"] = p10,
		["State"] = p_u_11,
		["Contents"] = p_u_12,
		["Tele"] = v16,
		["TExp"] = v17,
		["TShr"] = v18,
		["Thick"] = v19,
		["Rate"] = v20,
		["Damage"] = v21,
		["Center"] = v30,
		["UUID"] = v_u_1:GenerateGUID(false),
		["Alive"] = true,
		["Phase"] = "TELEGRAPH",
		["Time"] = 0,
		["PTime"] = 0,
		["Lines"] = {},
		["Sounded"] = false
	}
	local v34 = v_u_9
	local v_u_35 = setmetatable(v33, v34)
	local v_u_36 = p_u_11.Attacks
	local function v40(p37)
		-- upvalues: (ref) v_u_3, (copy) v_u_24, (copy) v_u_36, (copy) p_u_12, (copy) v_u_35
		local v_u_38 = Instance.new("Frame")
		v_u_38.Name = p37 and "SweepH" or "SweepV"
		v_u_38.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_38.BackgroundColor3 = v_u_3
		v_u_38.BorderSizePixel = 0
		v_u_38.Parent = v_u_24
		v_u_36[v_u_38] = {
			["Kind"] = "Sweep",
			["Size"] = p37 and Vector2.new(p_u_12.AbsoluteSize.X, 2) or Vector2.new(2, p_u_12.AbsoluteSize.Y),
			["Pos"] = v_u_35.Center,
			["Dmg"] = 0,
			["Destroy"] = function()
				-- upvalues: (ref) v_u_36, (copy) v_u_38
				if v_u_36[v_u_38] then
					v_u_36[v_u_38] = nil
				end
				if v_u_38 then
					v_u_38:Destroy()
				end
			end
		}
		local v39 = v_u_35.Lines
		table.insert(v39, {
			["isH"] = p37,
			["gui"] = v_u_38
		})
	end
	if v31 then
		v40(true)
	end
	if v32 then
		v40(false)
	end
	local function v_u_50(p41)
		-- upvalues: (copy) v_u_36, (ref) v_u_2, (copy) p_u_12, (copy) p_u_11
		local v42 = p41.gui
		local v43 = v_u_36[v42]
		if v43 then
			local v44 = v_u_2.unitScale(p_u_12, p_u_11.Arena.BaselineMin)
			local v45 = (p41.isH and v43.Size.Y or v43.Size.X) * v44 + 0.5
			local v46 = math.floor(v45)
			local v47 = math.max(1, v46)
			local v48 = v_u_2.roundpx(v43.Pos.X)
			local v49 = v_u_2.roundpx(v43.Pos.Y)
			if p41.isH then
				v42.Position = UDim2.new(0.5, v48, 0.5, v49)
				v42.Size = UDim2.new(64, 0, 0, v47)
			else
				v42.Position = UDim2.new(0.5, v48, 0.5, v49)
				v42.Size = UDim2.new(0, v47, 64, 0)
			end
		else
			return
		end
	end
	for _, v51 in ipairs(v_u_35.Lines) do
		v_u_50(v51)
	end
	v_u_9.Compute[v_u_35.UUID] = function(p52)
		-- upvalues: (copy) v_u_35, (ref) v_u_2, (copy) p_u_12, (copy) p_u_11, (copy) v_u_23, (copy) v_u_36, (ref) v_u_3, (ref) v_u_4, (copy) v_u_50, (ref) v_u_5
		if v_u_35.Alive then
			local v53 = v_u_2.toSec(p52)
			v_u_2.unitScale(p_u_12, p_u_11.Arena.BaselineMin)
			if not v_u_35.Sounded then
				v_u_35.Signals.spawnSound:Fire(v_u_23)
				v_u_35.Sounded = true
			end
			local v54 = v_u_35
			v54.Time = v54.Time + v53
			local v55 = v_u_35
			v55.PTime = v55.PTime + v53
			if v_u_35.Phase == "TELEGRAPH" then
				local v56 = v_u_35.Time * v_u_35.Rate
				local v57 = math.floor(v56) % 2 == 0
				for _, v58 in ipairs(v_u_35.Lines) do
					local v59 = v58.gui
					local v60 = v_u_36[v59]
					if v60 then
						if v58.isH then
							v60.Size = Vector2.new(p_u_12.AbsoluteSize.X, 2)
						else
							v60.Size = Vector2.new(2, p_u_12.AbsoluteSize.Y)
						end
						v60.Pos = v_u_35.Center
						v60.Dmg = 0
						v59.BackgroundColor3 = v57 and v_u_3 or v_u_4
						v_u_50(v58)
					end
				end
				if v_u_35.PTime >= v_u_35.Tele then
					v_u_35.Phase = "EXPAND"
					v_u_35.PTime = 0
					for _, v61 in ipairs(v_u_35.Lines) do
						v61.gui.BackgroundColor3 = v_u_5
					end
				end
				return
			elseif v_u_35.Phase == "EXPAND" then
				local v62 = v_u_35.PTime
				local v63 = v_u_35.TExp
				local v64 = v62 / math.max(v63, 1e-6)
				local v65 = math.clamp(v64, 0, 1)
				local v66 = v_u_35.Thick
				local v67 = v_u_2.easeOutCubic
				local v68 = math.lerp(2, v66, v67(v65))
				for _, v69 in ipairs(v_u_35.Lines) do
					local v70 = v_u_36[v69.gui]
					if v70 then
						if v69.isH then
							v70.Size = Vector2.new(p_u_12.AbsoluteSize.X, v68)
						else
							v70.Size = Vector2.new(v68, p_u_12.AbsoluteSize.Y)
						end
						v70.Pos = v_u_35.Center
						v70.Dmg = v_u_35.Damage
						v_u_50(v69)
					end
				end
				if v65 >= 1 then
					v_u_35.Phase = "SHRINK"
					v_u_35.PTime = 0
				end
				return
			elseif v_u_35.Phase == "SHRINK" then
				local v71 = v_u_35.PTime
				local v72 = v_u_35.TShr
				local v73 = v71 / math.max(v72, 1e-6)
				local v74 = math.clamp(v73, 0, 1)
				local v75 = v_u_35.Thick
				local v76 = v_u_2.easeInCubic
				local v77 = math.lerp(v75, 0, v76(v74))
				local v78 = math.max(0, v77)
				for _, v79 in ipairs(v_u_35.Lines) do
					local v80 = v_u_36[v79.gui]
					if v80 then
						if v79.isH then
							v80.Size = Vector2.new(p_u_12.AbsoluteSize.X, v78)
						else
							v80.Size = Vector2.new(v78, p_u_12.AbsoluteSize.Y)
						end
						v80.Pos = v_u_35.Center
						v80.Dmg = v78 > 0 and v_u_35.Damage or 0
						v_u_50(v79)
					end
				end
				if v74 >= 1 then
					v_u_35.Phase = "DONE"
				end
				return
			elseif v_u_35.Phase == "DONE" then
				v_u_35:Destroy()
			end
		else
			return
		end
	end
	return v_u_35
end
function v_u_9.newSpin(p81, p_u_82, p_u_83, p84)
	-- upvalues: (copy) v_u_7, (copy) v_u_2, (copy) v_u_1, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	local v85 = p84 or {}
	local v86 = v85.maxLines or v_u_7.maxLines
	local v87 = math.max(1, v86)
	local v88 = v85.rampDuration or v_u_7.rampDuration
	local v89 = math.max(0, v88)
	local v90 = v85.holdDuration or v_u_7.holdDuration
	local v91 = math.max(0, v90)
	local v92 = v85.rotateSpeedEnd or (v85.rotateSpeed or v_u_7.rotateSpeedEnd)
	local v93 = v85.rotateSpeedStart or v92 * 0.4
	local v94 = v85.thickness or v_u_7.thickness
	local v95 = math.max(1, v94)
	local v96 = v85.damage or v_u_7.damage
	local v97 = v85.flashRate or v_u_7.flashRate
	local v98 = v85.pulseTelegraph or v_u_7.pulseTelegraph
	local v99 = math.max(0, v98)
	local v100 = v85.pulseHit or v_u_7.pulseHit
	local v101 = math.max(0.05, v100)
	local v102 = v85.expand or v_u_7.expand
	local v103 = math.max(0, v102)
	local v104 = v85.shrink or v_u_7.shrink
	local v105 = math.max(0, v104)
	local v106 = v85.targetPos or Vector2.zero
	local v107 = v85.minGapDeg or v_u_7.minGapDeg
	local v108 = v85.gapJitterDeg or v_u_7.gapJitterDeg
	local v109 = v85.slash or v_u_7.slash
	local v_u_110 = ("Slash %d"):format((math.clamp(v109, 1, 3)))
	local v111 = v101 * 0.5
	if v111 < v103 then
		v103 = v111
	end
	if v111 >= v105 then
		v111 = v105
	end
	local v_u_112 = v_u_2.resolveEffectFolders(p_u_83)
	local v113 = {
		["Signals"] = p81,
		["State"] = p_u_82,
		["Contents"] = p_u_83,
		["MaxLines"] = v87,
		["RampDur"] = v89,
		["HoldDur"] = v91,
		["RotStart"] = v93,
		["RotEnd"] = v92,
		["Thickness"] = v95,
		["Damage"] = v96,
		["FlashRate"] = v97,
		["PulseTele"] = v99,
		["PulseHit"] = v101,
		["TExp"] = v103,
		["TShr"] = v111,
		["Center"] = v85.fromGui and v_u_2.absToCenteredOffset(v_u_2.centerAbs(v85.fromGui), p_u_83) + v106 or Vector2.new(v_u_2.roundpx(v106.X), v_u_2.roundpx(v106.Y)),
		["MinGapDeg"] = v107,
		["JitDeg"] = v108,
		["UUID"] = v_u_1:GenerateGUID(false),
		["Alive"] = true,
		["Time"] = 0,
		["PhaseT"] = 0,
		["BaseAng"] = 0,
		["Phase"] = "RUN",
		["FinalT"] = 0,
		["Sound"] = false,
		["Lines"] = {},
		["LastHit"] = false
	}
	local v114 = v_u_9
	local v_u_115 = setmetatable(v113, v114)
	local v_u_116 = p_u_82.Attacks
	local v134 = (function(p117, p118, p119)
		-- upvalues: (ref) v_u_8
		if p117 <= 0 then
			return {}
		end
		local v120 = {}
		local v121 = v_u_8
		table.insert(v120, v121:NextNumber(0, 360))
		for _ = 2, p117 do
			table.sort(v120)
			local v122 = -1
			local v123 = 0
			for v124 = 1, #v120 do
				local v125 = v120[v124]
				local v126 = (v124 < #v120 and v120[v124 + 1] or v120[1] + 360) - v125
				if v122 < v126 then
					v123 = v125
					v122 = v126
				end
			end
			local v127 = v122 - p118 * 2
			local v128 = math.max(0, v127)
			local v129 = v123 + p118
			local v130
			if v128 <= 0 then
				v130 = v123 + v122 * 0.5
			else
				local v131 = v129 + v_u_8:NextNumber(0, 1) * v128 + v_u_8:NextNumber(-p119, p119)
				local v132 = v129 + v128
				v130 = math.clamp(v131, v129, v132)
			end
			local v133 = v130 % 360
			if v133 < 0 then
				v133 = v133 + 360
			end
			table.insert(v120, v133)
		end
		return v120
	end)(v_u_115.MaxLines, v_u_115.MinGapDeg, v_u_115.JitDeg)
	local function v138(p135)
		-- upvalues: (ref) v_u_3, (copy) v_u_112, (copy) v_u_116, (copy) v_u_115
		local v_u_136 = Instance.new("Frame")
		v_u_136.Name = "SpinSweepLine"
		v_u_136.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_136.BorderSizePixel = 0
		v_u_136.BackgroundColor3 = v_u_3
		v_u_136.Parent = v_u_112
		v_u_116[v_u_136] = {
			["Kind"] = "SpinSweep",
			["Pos"] = v_u_115.Center,
			["Dmg"] = 0,
			["Rot"] = 0,
			["Minor"] = 4,
			["Destroy"] = function()
				-- upvalues: (ref) v_u_116, (copy) v_u_136
				if v_u_116[v_u_136] then
					v_u_116[v_u_136] = nil
				end
				if v_u_136 then
					v_u_136:Destroy()
				end
			end
		}
		local v137 = v_u_115.Lines
		table.insert(v137, {
			["gui"] = v_u_136,
			["offsetDeg"] = p135
		})
	end
	for v139 = 1, v_u_115.MaxLines do
		v138(v134[v139])
	end
	local function v_u_149(p140, p141, p142)
		-- upvalues: (copy) p_u_83, (copy) v_u_115
		local v143 = p_u_83.AbsoluteSize.X
		local v144 = p_u_83.AbsoluteSize.Y
		local v145 = v143 * v143 + v144 * v144
		local v146 = math.sqrt(v145)
		local v147 = math.ceil(v146) - 2 * v143
		local v148 = math.max(0, v147) + 8
		p140.Size = UDim2.new(50, v148, 0, p142)
		p140.Position = UDim2.new(0.5, v_u_115.Center.X, 0.5, v_u_115.Center.Y)
		p140.Rotation = p141
	end
	v_u_9.Compute[v_u_115.UUID] = function(p150)
		-- upvalues: (copy) v_u_115, (ref) v_u_2, (copy) p_u_83, (copy) p_u_82, (copy) v_u_110, (copy) v_u_116, (ref) v_u_5, (ref) v_u_3, (ref) v_u_4, (copy) v_u_149
		if v_u_115.Alive then
			local v151 = v_u_2.toSec(p150)
			local v152 = v_u_2.unitScale(p_u_83, p_u_82.Arena.BaselineMin)
			local v153 = v_u_115
			v153.Time = v153.Time + v151
			if not v_u_115.Sounded then
				v_u_115.Signals.spawnSound:Fire(v_u_110)
				v_u_115.Sounded = true
			end
			if v_u_115.Phase == "RUN" then
				local v154 = v_u_115
				v154.PhaseT = v154.PhaseT + v151
				local v155 = v_u_115
				local v156 = v_u_115.BaseAng
				local v157 = v_u_115.PhaseT
				local v158 = v_u_115.RampDur + v_u_115.HoldDur
				local v159
				if v158 > 0 then
					local v160 = v157 / v158
					v159 = math.clamp(v160, 0, 1) or 1
				else
					v159 = 1
				end
				local v161 = v_u_115.RotStart
				local v162 = v_u_115.RotEnd
				local v163 = v_u_2.easeInCubic
				v155.BaseAng = (v156 + math.lerp(v161, v162, v163(v159)) * v151) % 360
				local v164 = v_u_115.PhaseT
				local v165
				if v_u_115.RampDur <= 1e-6 then
					v165 = v_u_115.MaxLines
				else
					local v166 = v164 / v_u_115.RampDur
					local v167 = math.clamp(v166, 0, 1)
					local v168 = v_u_115.MaxLines
					local v169 = v_u_115.MaxLines
					local v170 = math.lerp(1, v169, v167) + 0.001
					local v171 = math.floor(v170)
					local v172 = math.min(v168, v171)
					v165 = math.max(1, v172)
				end
				local v173 = v_u_115.Time % (v_u_115.PulseTele + v_u_115.PulseHit)
				local v174 = v_u_115.PulseTele <= v173
				local v175 = v_u_115.Time * v_u_115.FlashRate
				local v176 = math.floor(v175) % 2 == 0
				local v177 = v174 and v173 - v_u_115.PulseTele or 0
				local v178
				if v174 then
					if v177 < v_u_115.TExp then
						local v179 = v_u_115.TExp
						local v180 = v177 / math.max(v179, 1e-6)
						local v181 = v_u_115.Thickness * v152
						local v182 = v_u_2.easeOutCubic
						v178 = math.lerp(2, v181, v182(v180))
					elseif v_u_115.PulseHit - v_u_115.TShr < v177 then
						local v183 = v177 - (v_u_115.PulseHit - v_u_115.TShr)
						local v184 = v_u_115.TShr
						local v185 = v183 / math.max(v184, 1e-6)
						local v186 = v_u_115.Thickness * v152
						local v187 = v_u_2.easeInCubic
						v178 = math.lerp(v186, 2, v187(v185))
					else
						v178 = v_u_115.Thickness * v152
					end
				else
					v178 = 2
				end
				for v188, v189 in ipairs(v_u_115.Lines) do
					local v190 = v189.gui
					local v191 = v_u_116[v190]
					if v191 then
						local v192 = v188 <= v165
						v190.Visible = v192
						if v192 then
							local v193 = (v_u_115.BaseAng + v189.offsetDeg) % 360
							v190.BackgroundColor3 = v174 and v_u_5 or (v176 and v_u_3 or v_u_4)
							v191.Dmg = v174 and v_u_115.Damage or 0
							v191.Pos = v_u_115.Center
							v191.Rot = v193
							v191.Minor = v178
							v_u_149(v190, v193, v178)
						else
							v191.Dmg = 0
							v191.Minor = 2
						end
					end
				end
				if v_u_115.PhaseT >= v_u_115.RampDur + v_u_115.HoldDur then
					v_u_115.Phase = "FINAL"
					v_u_115.FinalT = 0
				end
				return
			elseif v_u_115.Phase == "FINAL" then
				local v194 = v_u_115
				v194.FinalT = v194.FinalT + v151
				local v195 = v_u_115
				local v196 = v_u_115.BaseAng
				local v197 = v_u_115.RampDur + v_u_115.HoldDur
				local v198 = v_u_115.RampDur + v_u_115.HoldDur
				local v199
				if v198 > 0 then
					local v200 = v197 / v198
					v199 = math.clamp(v200, 0, 1) or 1
				else
					v199 = 1
				end
				local v201 = v_u_115.RotStart
				local v202 = v_u_115.RotEnd
				local v203 = v_u_2.easeInCubic
				v195.BaseAng = (v196 + math.lerp(v201, v202, v203(v199)) * v151) % 360
				local v204 = v_u_115.FinalT
				local v205
				if v204 < v_u_115.TExp then
					local v206 = v_u_115.TExp
					local v207 = v204 / math.max(v206, 1e-6)
					local v208 = v_u_115.Thickness * v152
					local v209 = v_u_2.easeOutCubic
					v205 = math.lerp(2, v208, v209(v207))
				elseif v204 < v_u_115.TExp + v_u_115.TShr then
					local v210 = v204 - v_u_115.TExp
					local v211 = v_u_115.TShr
					local v212 = v210 / math.max(v211, 1e-6)
					local v213 = v_u_115.Thickness * v152
					local v214 = v_u_2.easeInCubic
					v205 = math.lerp(v213, 0, v214(v212))
				else
					v_u_115.Phase = "DONE"
					v205 = 0
				end
				for _, v215 in ipairs(v_u_115.Lines) do
					local v216 = v215.gui
					local v217 = v_u_116[v216]
					if v217 then
						local v218 = v205 > 0
						v216.Visible = v218
						if v218 then
							local v219 = (v_u_115.BaseAng + v215.offsetDeg) % 360
							v216.BackgroundColor3 = v_u_5
							v217.Dmg = v_u_115.Damage
							v217.Pos = v_u_115.Center
							v217.Rot = v219
							v217.Minor = v205
							v_u_149(v216, v219, v205)
						else
							v217.Dmg = 0
							v217.Minor = 0
						end
					end
				end
				return
			elseif v_u_115.Phase == "DONE" then
				v_u_115:Destroy()
			end
		else
			return
		end
	end
	return v_u_115
end
function v_u_9.Destroy(p220)
	-- upvalues: (copy) v_u_9
	if p220.Alive then
		p220.Alive = false
		if p220.UUID and v_u_9.Compute[p220.UUID] then
			v_u_9.Compute[p220.UUID] = nil
		end
		if p220.State and p220.State.Attacks then
			for _, v221 in ipairs(p220.Lines or {}) do
				local v222 = v221.gui
				if p220.State.Attacks[v222] then
					p220.State.Attacks[v222] = nil
				end
				if v222 then
					v222:Destroy()
				end
			end
		end
		p220.Lines = {}
		table.clear(p220)
		setmetatable(p220, nil)
	end
end
function v_u_9.Step(p223)
	-- upvalues: (copy) v_u_9
	for _, v224 in pairs(v_u_9.Compute) do
		v224(p223)
	end
end
return v_u_9