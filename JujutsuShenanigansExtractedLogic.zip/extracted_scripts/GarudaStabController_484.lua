-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "GarudaStabController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_9, (copy) v_u_8, (copy) v_u_5, (copy) v_u_3, (copy) v_u_2, (copy) v_u_6, (copy) v_u_4, (ref) v_u_10
	local v_u_53 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_7.Yuki.Startup2, v14, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p15)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_11:PlaySound(v_u_7.Yuki.Stab, v16, game.SoundService.Effect)
			end
		end,
		["Stab"] = function(p_u_17)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8
			local v18 = p_u_17:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_11:Flash(p_u_17, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Hiromi.Stab, v18, game.SoundService.Effect)
				task.delay(0.04, function()
					-- upvalues: (ref) v_u_9, (copy) p_u_17
					for _ = 1, 40 do
						v_u_9:Blood(p_u_17.Torso.CFrame, math.random(-150, -5), 25, 25)
					end
				end)
				if (workspace.CurrentCamera.CFrame.Position - v18.Position).Magnitude < 70 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Trail"] = function(p19)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_2
			if p19:FindFirstChild("HumanoidRootPart") then
				local v20 = v_u_5.Utils.Yuki.MassChargeLeg:Clone()
				v20.Parent = workspace.Effects
				v_u_3:Create(v20.PointLight, TweenInfo.new(0.3), {
					["Brightness"] = 5
				}):Play()
				v20.Weld.C1 = CFrame.new(0, 2, 0)
				v20.Weld.Part0 = p19["Right Leg"]
				task.wait(0.3)
				for _, v21 in v20:GetDescendants() do
					if v21:IsA("ParticleEmitter") then
						v21.Enabled = false
					end
				end
				v_u_3:Create(v20.PointLight, TweenInfo.new(0.5), {
					["Brightness"] = 0
				}):Play()
				v_u_2:AddItem(v20, 0.6)
				v20.Trail.Enabled = false
			end
		end,
		["Hit"] = function(p22, p23)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				local v25 = v_u_6.Yuki.MassHit:Clone()
				v25.CFrame = CFrame.lookAlong(p23.Torso.Position, Vector3.new(0, 1, 0))
				v25.Parent = workspace.Effects
				v_u_2:AddItem(v25, 1)
				for _, v26 in v25:GetDescendants() do
					if v26:IsA("ParticleEmitter") then
						v26:Emit(v26:GetAttribute("EmitCount"))
					end
				end
				local v27 = v_u_6.Gojo.LapseBlue.LapseBlue.Grab:Clone()
				v27.Size = Vector3.new(40, 40, 40)
				v27.Weld.Part0 = v24
				v27.Parent = workspace.Effects
				local v28 = Instance.new("Highlight", v27)
				v28.FillTransparency = 1
				v28.OutlineTransparency = 1
				v27.Transparency = 50
				v_u_3:Create(v27, TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(0, 0, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v27, 0.4)
				v_u_11:Flash(p23, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Yuki.Mass.Hit, v24, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Yuki.Mass.Hit2, v24, game.SoundService.Effect)
				if v_u_4 == p22 or v_u_4.Character == p23 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["GarudaTrail"] = function(p29)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_3
			if p29:FindFirstChild("HumanoidRootPart") then
				local v30 = p29.SetAssets:FindFirstChild("Garuda")
				if v30 then
					local v31 = v30.Garuda["segment finale"].TailHolder
					local v_u_32 = v_u_5.Utils.Yuki.MassCharge:Clone()
					v_u_2:AddItem(v_u_32, 2)
					v_u_32.Parent = workspace.Effects
					v_u_32.Weld.Part0 = v31
					local function v34()
						-- upvalues: (copy) v_u_32, (ref) v_u_3
						for _, v33 in v_u_32:GetDescendants() do
							if v33:IsA("ParticleEmitter") then
								v33.Enabled = true
							end
						end
						v_u_3:Create(v_u_32.PointLight, TweenInfo.new(0.2), {
							["Brightness"] = 5
						}):Play()
						v_u_32.Trail.Enabled = true
					end
					local function v36()
						-- upvalues: (copy) v_u_32, (ref) v_u_3
						for _, v35 in v_u_32:GetDescendants() do
							if v35:IsA("ParticleEmitter") then
								v35.Enabled = false
							end
						end
						v_u_3:Create(v_u_32.PointLight, TweenInfo.new(0.2), {
							["Brightness"] = 0
						}):Play()
						v_u_32.Trail.Enabled = false
					end
					v34()
					task.wait(0.4)
					v36()
					task.wait(0.4)
					v34()
					task.wait(0.4)
					v36()
				end
			else
				return
			end
		end,
		["Whip"] = function(p37)
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			local v38 = p37:FindFirstChild("HumanoidRootPart")
			if v38 then
				local v39 = v_u_6.Yuta.Veilstep.Spin.SpinRing:Clone()
				v39.Parent = v38
				v_u_2:AddItem(v39, 0.5)
				v39.Ring.Size = NumberSequence.new(17.5)
				v39.Ring.LockedToPart = false
				v39.Ring:Emit(5)
			end
		end,
		["Whip1"] = function(p40)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v41 = p40:FindFirstChild("HumanoidRootPart")
			if v41 then
				v_u_11:PlaySound(v_u_7.Yuki.FirstWhip, v41, game.SoundService.Effect)
			end
		end,
		["Whip2"] = function(p42)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v43 = p42:FindFirstChild("HumanoidRootPart")
			if v43 then
				v_u_11:PlaySound(v_u_7.Yuki.SecondWhip, v43, game.SoundService.Effect)
			end
		end,
		["FlyBack"] = function(p44)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v45 = p44:FindFirstChild("HumanoidRootPart")
			if v45 then
				v_u_11:PlaySound(v_u_7.Yuki.WhipFlyBack, v45, game.SoundService.Effect)
			end
		end,
		["WhipHit"] = function(_, p46)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v47 = p46:FindFirstChild("HumanoidRootPart")
			if v47 then
				local v48 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v48.Parent = v47.RootAttachment
				v48:Emit(20)
				v_u_2:AddItem(v48, 0.4)
				v_u_11:Flash(p46, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Yuki.RisingRage.Hit, v47, game.SoundService.Effect)
			end
		end,
		["WhipHitHard"] = function(p49, p50)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v51 = p50:FindFirstChild("HumanoidRootPart")
			if v51 then
				local v52 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v52.Parent = v51.RootAttachment
				v52:Emit(20)
				v_u_2:AddItem(v52, 0.4)
				v_u_11:Flash(p50, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Yuki.RisingRage.Hit3, v51, game.SoundService.Effect)
				if v_u_4 == p49 or v_u_4.Character == p50 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p54, ...)
		-- upvalues: (copy) v_u_53
		local v55 = v_u_53[p54]
		if v55 then
			v55(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("GarudaStabService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12