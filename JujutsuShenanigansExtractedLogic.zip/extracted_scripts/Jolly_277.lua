-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 6,
	["Desc"] = "snow everywhere"
}
local v_u_2 = nil
local v_u_3 = nil
local v_u_4 = game:GetService("RunService")
function v1.Callback(p5)
	-- upvalues: (ref) v_u_2, (copy) v_u_4, (ref) v_u_3
	if p5 == true and _G.LocalSettings.Darkness == true then
		_G.LocalSettings.Darkness = false
		_G.SettingUpdate.Darkness:Fire()
	end
	if p5 == true then
		v_u_2 = game.ReplicatedStorage.Utils.Misc.Rain:Clone()
		v_u_2.Rain.Enabled = false
		v_u_2.Snow.Enabled = true
		v_u_2.Parent = workspace.Effects
		game.Lighting.FogEnd = 500
		local v_u_6 = nil
		v_u_6 = v_u_4.Stepped:Connect(function(_, p7)
			-- upvalues: (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			if v_u_2 then
				local v8 = workspace.CurrentCamera.CFrame.Position - (v_u_3 or workspace.CurrentCamera.CFrame.Position)
				v_u_3 = workspace.CurrentCamera.CFrame.Position
				v_u_2.Position = workspace.CurrentCamera.CFrame.Position + v8 / p7 * 2 + Vector3.new(0, 30, 0)
			else
				v_u_6:Disconnect()
			end
		end)
		return
	elseif v_u_2 then
		v_u_2:Destroy()
		v_u_2 = nil
		v_u_3 = nil
		game.Lighting.FogEnd = 100000
	end
end
return v1