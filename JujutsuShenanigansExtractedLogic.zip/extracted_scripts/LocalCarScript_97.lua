-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game.Players.LocalPlayer.Character
local v2 = v1.HumanoidRootPart
local v_u_3 = script:WaitForChild("Car").Value
local v_u_4 = v_u_3:WaitForChild("Configurations")
local v_u_5 = require(v_u_3.CarScript.RaycastModule)
local v_u_6 = Vector2.new()
v_u_3.DriveSeat.Changed:connect(function(p7)
	-- upvalues: (ref) v_u_6, (copy) v_u_3
	if p7 == "Steer" then
		v_u_6 = Vector2.new(v_u_3.DriveSeat.Steer, v_u_6.Y)
	elseif p7 == "Throttle" then
		v_u_6 = Vector2.new(v_u_6.X, v_u_3.DriveSeat.Throttle)
	end
end)
local v8 = v_u_6
local v9 = 0
for _, v10 in pairs(v_u_3:GetChildren()) do
	if v10:IsA("BasePart") then
		v9 = v9 + v10:GetMass() * 196.2
	end
end
local v_u_11 = v9 * v_u_4.Suspension.Value
local v_u_12 = v_u_11 / v_u_4.Bounce.Value
local v13 = Instance.new("BodyVelocity", v_u_3.Chassis)
v13.velocity = Vector3.new(0, 0, 0)
v13.maxForce = Vector3.new(0, 0, 0)
local v14 = Instance.new("BodyAngularVelocity", v_u_3.Chassis)
v14.angularvelocity = Vector3.new(0, 0, 0)
v14.maxTorque = Vector3.new(0, 0, 0)
local v_u_15 = 0
local function v31(p16)
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (ref) v_u_11, (ref) v_u_12, (copy) v_u_3, (ref) v_u_15
	local v17 = p16:FindFirstChild("BodyThrust") or Instance.new("BodyThrust", p16)
	local v18, v19 = v_u_5.new(p16.Position, p16.CFrame:vectorToWorldSpace(Vector3.new(0, -1, 0)) * v_u_4.Height.Value)
	local v20 = (v19 - p16.Position).magnitude
	if v18 and v18.CanCollide then
		local v21 = (v_u_4.Height.Value - v20) ^ 2 * (v_u_11 / v_u_4.Height.Value ^ 2)
		v17.force = Vector3.new(0, v21, 0)
		local v22 = p16.CFrame:toObjectSpace(CFrame.new(p16.Velocity + p16.Position)).p * v_u_12
		local v23 = v17.force
		local v24 = v22.Y
		v17.force = v23 - Vector3.new(0, v24, 0)
	else
		v17.force = Vector3.new(0, 0, 0)
	end
	local v25 = p16:FindFirstChild("WheelWeld")
	if v25 then
		local v26 = CFrame.new
		local v27 = v_u_4.Height.Value * 0.8
		v25.C0 = v26(0, -math.min(v20, v27) + v25.Part1.Size.Y / 2, 0)
		local v28 = v_u_3.Chassis.CFrame:inverse() * p16.CFrame
		local v29 = v_u_3.Chassis.CFrame:vectorToObjectSpace(v_u_3.Chassis.Velocity)
		if v28.Z < 0 then
			local v30 = v29.Z > 0 and -1 or 1
			v25.C0 = v25.C0 * CFrame.Angles(0, v_u_3.Chassis.RotVelocity.Y / 2 * v30, 0)
		end
		v25.C0 = v25.C0 * CFrame.Angles(v_u_15, 0, 0)
	end
end
local v32 = v_u_15
local function v34()
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	if v_u_3:FindFirstChild("Chassis") then
		local v33, _ = v_u_5.new((v_u_3.Chassis.CFrame * CFrame.new(0, 0, v_u_3.Chassis.Size.Z / 2 - 1)).p, v_u_3.Chassis.CFrame:vectorToWorldSpace(Vector3.new(0, -1, 0)) * (v_u_4.Height.Value + 0.2))
		return v33 and v33.CanCollide and true or false
	end
end
while v_u_3:FindFirstChild("DriveSeat") and v1.Humanoid.SeatPart == v_u_3.DriveSeat do
	local v35 = task.wait()
	if v34() then
		if v8.Y == 0 then
			local v36 = v9 / 2
			local v37 = v9 / 4
			local v38 = v9 / 2
			v13.maxForce = Vector3.new(v36, v37, v38)
		else
			local v39 = v2.CFrame.lookVector * v8.Y * v_u_4.Speed.Value
			v2.Velocity = v2.Velocity:Lerp(v39, 0.1)
			v13.maxForce = Vector3.new(0, 0, 0)
		end
		local v40 = v2.CFrame
		local v41 = v8.Y * v_u_4.Speed.Value / 50
		local v42 = -v2.RotVelocity.Y * 5 * v8.Y
		local v43 = v40:vectorToWorldSpace((Vector3.new(v41, 0, v42)))
		local v44 = -v2.CFrame:vectorToObjectSpace(v2.Velocity).unit.Z
		local v45 = -v_u_4.Speed.Value / 5 * v8.Y
		v_u_15 = v32 + math.rad(v45)
		if math.abs(v44) > 0.1 then
			local v46 = v2.CFrame
			local v47 = -v8.X * v44 * v_u_4.TurnSpeed.Value
			v43 = v43 + v46:vectorToWorldSpace((Vector3.new(0, v47, 0)))
			v14.maxTorque = Vector3.new(0, 0, 0)
		else
			local v48 = v9 / 4
			local v49 = v9 / 2
			local v50 = v9 / 4
			v14.maxTorque = Vector3.new(v48, v49, v50)
		end
		v2.RotVelocity = v2.RotVelocity:Lerp(v43, 6 * v35)
		v32 = v_u_15
	else
		v13.maxForce = Vector3.new(0, 0, 0)
		v14.maxTorque = Vector3.new(0, 0, 0)
	end
	for _, v51 in pairs(v_u_3:GetChildren()) do
		if v51.Name == "Thruster" then
			v31(v51)
		end
	end
end
for _, v52 in pairs(v_u_3:GetChildren()) do
	if v52:FindFirstChild("BodyThrust") then
		v52.BodyThrust:Destroy()
	end
end
v13:Destroy()
v14:Destroy()
script:Destroy()