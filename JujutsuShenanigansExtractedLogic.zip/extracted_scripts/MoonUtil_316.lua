-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = game:GetService("RunService")
function v1.AnimateValueWithMoonFile(p_u_3, p_u_4, p_u_5)
	-- upvalues: (copy) v_u_2
	local v_u_6 = 0
	local v_u_7 = nil
	v_u_7 = v_u_2.RenderStepped:Connect(function(p8)
		-- upvalues: (ref) v_u_6, (copy) p_u_5, (copy) p_u_3, (copy) p_u_4, (ref) v_u_7
		v_u_6 = v_u_6 + p8 * 60
		local v9 = v_u_6
		local v10 = p_u_5:FindFirstChild((math.ceil(v9)))
		if v10 then
			if v10:IsA("NumberValue") then
				p_u_3[p_u_4] = v10.Value
				return
			end
			local v11 = v10:FindFirstChild("0")
			if v11 then
				p_u_3[p_u_4] = v11.Value
				return
			end
		else
			v_u_7:Disconnect()
		end
	end)
	return v_u_7
end
return v1