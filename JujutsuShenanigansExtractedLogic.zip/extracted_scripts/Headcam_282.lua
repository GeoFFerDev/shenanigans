-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 10,
	["Desc"] = "yo clip this chat"
}
local v_u_2 = nil
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
game:GetService("ContextActionService")
game.Players.LocalPlayer:GetMouse()
function v1.Callback(p5)
	-- upvalues: (ref) v_u_2, (copy) v_u_3, (copy) v_u_4
	if p5 == true and not v_u_2 then
		v_u_2 = v_u_3.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_4
			local v6 = game.Players.LocalPlayer.Character
			if v6 and v6:FindFirstChild("Head") then
				workspace.CurrentCamera.CFrame = v6.Head.CFrame
				workspace.CurrentCamera.CameraSubject = v6.Head
				workspace.CurrentCamera.FieldOfView = 90
				for _, v7 in v6:GetDescendants() do
					if v7:IsA("BasePart") then
						if v7.Name == "Head" then
							v7.LocalTransparencyModifier = 1
						elseif v7.Parent.Parent:IsA("Accessory") and (v7:FindFirstChild("HatAttachment") or (v7:FindFirstChild("HairAttachment") or (v7:FindFirstChild("FaceFrontAttachment") or v7:FindFirstChild("NeckAttachment")))) then
							v7.LocalTransparencyModifier = 1
						else
							v7.LocalTransparencyModifier = 0
						end
					elseif v7:IsA("ParticleEmitter") and (v7:IsDescendantOf(v6.Head) or v7.Parent.Name == "Head") then
						v7.Enabled = false
					end
				end
				local v8 = v_u_4:GetMouseDelta()
				if v6:GetAttribute("Ragdoll") <= 0 and (v6.Humanoid.AutoRotate and not (v6:GetAttribute("Stun") or v6:GetAttribute("Emote"))) then
					local v9 = v6.HumanoidRootPart
					local v10 = v6.HumanoidRootPart.CFrame
					local v11 = CFrame.Angles
					local v12 = -v8.X
					v9.CFrame = v10 * v11(0, math.rad(v12), 0)
				end
			end
		end)
	elseif v_u_2 then
		v_u_2:Disconnect()
		v_u_2 = nil
		workspace.CurrentCamera.FieldOfView = 70
		local v13 = game.Players.LocalPlayer.Character
		if v13 then
			workspace.CurrentCamera.CameraSubject = v13.Humanoid
		end
	end
end
return v1