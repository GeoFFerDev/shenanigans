-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 1,
	["SortOrder"] = 3,
	["Val"] = "DesVFX",
	["Desc"] = "Creates smoke effects when parts are destroyed"
}