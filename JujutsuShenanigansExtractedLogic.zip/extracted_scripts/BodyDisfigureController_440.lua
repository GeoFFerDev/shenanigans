-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = require(v6.Modules.BloodyZee)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "BodyDisfigureController"
})
function v14.KnitStart(_)
	-- upvalues: (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (ref) v_u_13, (copy) v_u_8, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (copy) v_u_10, (ref) v_u_11
	local v_u_94 = {
		["Pierce"] = function(p15)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = {
					p15["Left Leg"].LeftFootAttachment,
					p15["Right Leg"].RightFootAttachment,
					p15.Torso.BodyFrontAttachment,
					p15["Left Arm"].LeftGripAttachment,
					p15["Right Arm"].RightGripAttachment
				}
				local v18 = v17[math.random(1, #v17)]
				local v19 = v18.Parent
				if (workspace.CurrentCamera.CFrame.Position - v16.Position).Magnitude < 300 then
					for _ = 1, 2 do
						local v20 = v_u_7.Mahito.Worms.Morph2:Clone()
						v20.Decal:Destroy()
						v20.Weld.Part0 = v19
						v20.Color = v19.Color
						v20.Weld.C1 = CFrame.new(math.random(-50, 50) / 100, math.random(-100, 100) / 100, math.random(-50, 50) / 100)
						v20.Parent = workspace.Effects
						v20.Size = Vector3.new(1, 1, 1) * (math.random(15, 30) / 10)
						v_u_4:Create(v20, TweenInfo.new(math.random(40, 60) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_3:AddItem(v20, 0.6)
					end
				end
				local v21 = v_u_7.Mahito.Pierce:Clone()
				local v22 = v16.Position
				local v23 = math.random(-15, 15)
				local v24 = math.random
				v21.Position = v22 - Vector3.new(v23, 6, v24(-15, 15)) + v16.CFrame.LookVector * 10
				v21.Attachment.WorldPosition = v19.Position
				v21.Pierce.Attachment0 = v18
				v21.Pierce.Color = ColorSequence.new(v19.Color)
				v21.Pierce.CurveSize0 = math.random(-25, 25)
				v21.Parent = workspace.Effects
				v_u_3:AddItem(v21, 0.5)
				local v25 = math.random(1, 3)
				if v25 == 1 then
					v_u_13:PlaySound(v_u_8.Mahito.DrillSplit.Morph, v16, game.SoundService.Effect)
				elseif v25 == 2 then
					v_u_13:PlaySound(v_u_8.Mahito.DrillSplit.Unmorph, v16, game.SoundService.Effect)
				end
				local v26 = v21.Attachment
				v_u_4:Create(v26, TweenInfo.new(0.1), {
					["Position"] = Vector3.new(0, 0, 0)
				}):Play()
				v_u_4:Create(v21.Pierce, TweenInfo.new(0.4, Enum.EasingStyle.Back), {
					["CurveSize0"] = 0
				}):Play()
				task.wait(0.2)
				local v27 = v26.WorldPosition
				v26.Parent = v19
				v26.WorldPosition = v27
				v_u_4:Create(v26, TweenInfo.new(0.3), {
					["Position"] = Vector3.new(0, 0, 0)
				}):Play()
				v_u_3:AddItem(v26, 0.3)
			end
		end,
		["Hit"] = function(p28)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				v_u_13:Flash(p28, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_8.Mahito.Variants.M3:FindFirstChild("Hit" .. math.random(1, 4)), v29, game.SoundService.Effect)
			end
		end,
		["Arm"] = function(p_u_30, p_u_31)
			-- upvalues: (ref) v_u_4, (ref) v_u_13, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_3, (ref) v_u_2, (ref) v_u_7
			local v_u_32 = p_u_30:FindFirstChild("HumanoidRootPart")
			if not v_u_32 then
				return
			end
			local v33 = p_u_31.Hand.Weld.C1
			local v34 = p_u_31.Hand2.Weld.C1
			p_u_31.Hand.Weld.C1 = v33 * CFrame.new(10, 2, 0) * CFrame.Angles(0.3490658503988659, 0.3490658503988659, 0.3490658503988659)
			p_u_31.Hand2.Weld.C1 = v34 * CFrame.new(10, 2, 0) * CFrame.Angles(0.3490658503988659, 0.3490658503988659, 0.3490658503988659)
			v_u_4:Create(p_u_31.Hand.Weld, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
				["C1"] = v33
			}):Play()
			v_u_4:Create(p_u_31.Hand2.Weld, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
				["C1"] = v34
			}):Play()
			v_u_13:PlaySound(v_u_8.Mahito.ForceGrab.Fire, p_u_31, game.SoundService.Effect)
			v_u_13:PlaySound(v_u_8.Itadori.Rush.RushBreak, p_u_31, game.SoundService.Effect)
			p_u_31.Hand.Beam.CurveSize0 = -10
			p_u_31.Hand.Beam.CurveSize1 = -10
			v_u_4:Create(p_u_31.Hand.Beam, TweenInfo.new(0.5, Enum.EasingStyle.Elastic), {
				["CurveSize0"] = 0,
				["CurveSize1"] = 0
			}):Play()
			if v_u_5.Character == p_u_30 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
			p_u_31.Destroying:Connect(function()
				-- upvalues: (copy) p_u_30, (copy) p_u_31, (ref) v_u_5, (ref) v_u_9, (ref) v_u_3, (ref) v_u_4, (ref) v_u_2, (ref) v_u_13, (ref) v_u_8, (copy) v_u_32, (ref) v_u_7
				if p_u_30.Parent then
					local v_u_35 = p_u_31.Velocity * 0.1
					if v_u_5.Character == p_u_30 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
					local v_u_36 = Instance.new("Attachment")
					v_u_36.Position = Vector3.new(0, -0.5, 0)
					v_u_36.Parent = p_u_30["Right Arm"]
					local v_u_37 = p_u_31:Clone()
					v_u_37.Anchored = true
					v_u_37.Hand.Beam.Attachment1 = v_u_36
					v_u_37.Parent = workspace.Effects
					v_u_3:AddItem(v_u_37, 1)
					v_u_3:AddItem(v_u_36, 1)
					local v38 = TweenInfo.new(0.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In)
					v_u_4:Create(v_u_37.Hand, v38, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_4:Create(v_u_37.Hand2, v38, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_4:Create(v_u_37.Hand.Beam, v38, {
						["Width0"] = 0
					}):Play()
					local v_u_39 = v_u_37.CFrame
					local v_u_40 = tick()
					local v_u_41 = nil
					v_u_41 = v_u_2.Stepped:Connect(function()
						-- upvalues: (copy) v_u_40, (ref) p_u_30, (copy) v_u_37, (copy) v_u_36, (ref) v_u_41, (copy) v_u_39, (copy) v_u_35
						local v42 = (tick() - v_u_40) / 0.5
						if v42 > 1 or not p_u_30.Parent then
							v_u_37:Destroy()
							v_u_36:Destroy()
							v_u_41:Disconnect()
						else
							local v43 = v_u_37
							local v44 = v_u_39:Lerp(CFrame.new(p_u_30["Right Arm"].Position, v_u_39.Position), v42)
							local v45 = v_u_35
							local v46 = v42 * 3.141592653589793
							v43.CFrame = v44 + v45 * math.sin(v46)
						end
					end)
					v_u_13:PlaySound(v_u_8.Mahito.ForceGrab.Retract, v_u_32, game.SoundService.Effect)
					v_u_4:Create(v_u_37.Hand.Beam, TweenInfo.new(0.125, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
						["CurveSize0"] = -10,
						["CurveSize1"] = -10
					}):Play()
					task.delay(0.125, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_37
						v_u_4:Create(v_u_37.Hand.Beam, TweenInfo.new(0.125, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
							["CurveSize0"] = 10,
							["CurveSize1"] = 10
						}):Play()
						task.wait(0.125)
						v_u_4:Create(v_u_37.Hand.Beam, TweenInfo.new(0.25, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
							["CurveSize0"] = 0,
							["CurveSize1"] = 0
						}):Play()
					end)
					for _ = 1, 15 do
						local v47 = v_u_7.Mahito.Morph:Clone()
						v47.Weld.Part0 = v_u_37
						v47.Color = v_u_37.Hand.Color
						v47.Weld.C1 = CFrame.new(math.random(-10, 10) / 2, math.random(-10, 10) / 2, math.random(-10, 10) / 2)
						v47.Shape = Enum.PartType.Block
						v47.Parent = workspace.Effects
						v47.Size = Vector3.new(1, 1, 1) * (math.random(10, 20) / 10)
						v_u_4:Create(v47, TweenInfo.new(math.random(40, 60) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_3:AddItem(v47, 0.6)
						v47.Weld:Destroy()
						local v48 = math.random(-40, 40)
						local v49 = math.random(-20, 40)
						local v50 = math.random
						v47.Velocity = Vector3.new(v48, v49, v50(-40, 40))
						task.wait()
					end
				end
			end)
			for _ = 1, 15 do
				if not p_u_31:FindFirstChild("Hand") then
					break
				end
				local v51 = v_u_7.Mahito.Morph:Clone()
				v51.Weld.Part0 = p_u_31
				v51.Color = p_u_31.Hand.Color
				v51.Weld.C1 = CFrame.new(math.random(-10, 10) / 2, math.random(-10, 10) / 2, math.random(-10, 10) / 2)
				v51.Shape = Enum.PartType.Block
				v51.Parent = workspace.Effects
				v51.Size = Vector3.new(1, 1, 1) * (math.random(10, 30) / 10)
				v_u_4:Create(v51, TweenInfo.new(math.random(40, 60) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
					["Size"] = Vector3.new(0, 0, 0)
				}):Play()
				v_u_3:AddItem(v51, 0.6)
				v51.Weld:Destroy()
				local v52 = math.random(-40, 40)
				local v53 = math.random(-20, 40)
				local v54 = math.random
				v51.Velocity = Vector3.new(v52, v53, v54(-40, 40))
				task.wait()
			end
		end,
		["Grab"] = function(p55, p56)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_4
			local v57 = p55:FindFirstChild("HumanoidRootPart")
			if not v57 then
				return
			end
			v_u_13:Flash(p55, Color3.new(1, 1, 1))
			v_u_13:PlaySound(v_u_8.Gojo.LapseBlue.Grab, v57, game.SoundService.Effect)
			if v_u_5.Character == p55 then
				local v58 = p55.Humanoid
				p56.Enabled = true
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				local v59 = tick()
				local v60 = false
				local v61 = 0
				while true do
					if v60 == false and (v58.Jump == true and tick() - v59 > 0.025) then
						local v62 = v61 + 1
						v61 = v62 > 20 and 20 or v62
						v59 = tick()
						p56:FindFirstChildWhichIsA("UnreliableRemoteEvent"):FireServer()
						v_u_13:PlaySound(v_u_8.Misc.UI.Click, workspace, game.SoundService.Effect)
						p56.StudsOffset = Vector3.new(1, 0, 0)
						v_u_4:Create(p56, TweenInfo.new(0.4, Enum.EasingStyle.Elastic), {
							["StudsOffset"] = Vector3.new(0, 0, 0)
						}):Play()
					end
					v60 = v58.Jump
					p56.Bar.Size = UDim2.new(v61 / 20, 0, 0.3, 0)
					task.wait()
					if not p56.Parent then
						goto l4
					end
				end
			else
				::l4::
				return
			end
		end,
		["Swing"] = function(p63)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v64 = p63:FindFirstChild("HumanoidRootPart")
			if v64 then
				v_u_13:PlaySound(v_u_8.Mahito.ForceGrab.Swing, v64, game.SoundService.Effect)
			end
		end,
		["Throw"] = function(p65)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v66 = p65:FindFirstChild("HumanoidRootPart")
			if v66 then
				v_u_13:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Throw, v66, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p_u_67, p68, _)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v_u_69 = p_u_67:FindFirstChild("HumanoidRootPart")
			if v_u_69 then
				v_u_13:PlaySound(v_u_8.Mahito.DrillSplit.Morph, v_u_69, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_8.Mahito.DrillSplit.Leap, v_u_69, game.SoundService.Effect)
				for v70 = 1, 20 do
					local v71 = v_u_7.Mahito.Morph:Clone()
					if v70 > 10 then
						v71.Weld.Part0 = p_u_67["Right Leg"]
						v71.Color = p_u_67["Right Leg"].Color
					else
						v71.Weld.Part0 = p_u_67["Left Leg"]
						v71.Color = p_u_67["Left Leg"].Color
					end
					v71.Weld.C1 = CFrame.new(math.random(-50, 50) / 100, math.random(100, 400) / 100, math.random(-50, 50) / 100)
					v71.Parent = workspace.Effects
					v71.Size = Vector3.new(1, 1, 1) * (math.random(5, 25) / 10)
					v_u_4:Create(v71, TweenInfo.new(math.random(20, 50) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_4:Create(v71.Weld, TweenInfo.new(math.random(30, 50) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["C1"] = CFrame.new(0, 0, 0)
					}):Play()
					v_u_3:AddItem(v71, 0.5)
				end
				p68.Destroying:Connect(function()
					-- upvalues: (copy) p_u_67, (ref) v_u_13, (ref) v_u_8, (copy) v_u_69, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
					if p_u_67.Parent then
						v_u_13:PlaySound(v_u_8.Mahito.DrillSplit.Unmorph, v_u_69, game.SoundService.Effect)
						for v72 = 1, 20 do
							local v73 = v_u_7.Mahito.Morph:Clone()
							if v72 > 10 then
								v73.Weld.Part0 = p_u_67["Right Leg"]
								v73.Color = p_u_67["Right Leg"].Color
							else
								v73.Weld.Part0 = p_u_67["Left Leg"]
								v73.Color = p_u_67["Left Leg"].Color
							end
							v73.Weld.C1 = CFrame.new(math.random(-50, 50) / 100, math.random(100, 400) / 100, math.random(-50, 50) / 100)
							v73.Parent = workspace.Effects
							v73.Size = Vector3.new(1, 1, 1) * (math.random(5, 15) / 10)
							v_u_4:Create(v73, TweenInfo.new(math.random(20, 50) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
							v_u_3:AddItem(v73, 0.5)
						end
					end
				end)
			end
		end,
		["Drill"] = function(p74, p75)
			-- upvalues: (ref) v_u_7, (ref) v_u_13, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v76 = p74:FindFirstChild("HumanoidRootPart")
			if v76 then
				local v_u_77 = v_u_7.Mahito.Drill.DrillArm:Clone()
				v_u_77.Weld.Part0 = p74["Right Arm"]
				for _, v78 in v_u_77:GetChildren() do
					if v78:IsA("BasePart") then
						v78.Color = p74["Right Arm"].Color
					end
				end
				v_u_77.Parent = workspace.Effects
				local v_u_79 = v_u_13:PlaySound(v_u_8.Mahito.DrillSplit.DrillWind, v76, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_8.Mahito.DrillSplit.Morph, v76, game.SoundService.Effect)
				task.delay(1.8, function()
					-- upvalues: (copy) v_u_77, (copy) v_u_79
					v_u_77.Attachment.ParticleEmitter.Enabled = false
					v_u_79.TimePosition = 16
				end)
				for _ = 1, 20 do
					local v80 = v_u_7.Mahito.Morph:Clone()
					v80.Weld.Part0 = p74["Right Arm"]
					v80.Color = p74["Right Arm"].Color
					v80.Weld.C1 = CFrame.new(math.random(-150, 150) / 100, math.random(100, 400) / 100, math.random(-150, 150) / 100)
					v80.Parent = workspace.Effects
					v80.Size = Vector3.new(1, 1, 1) * (math.random(10, 40) / 10)
					v_u_4:Create(v80, TweenInfo.new(math.random(20, 50) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_4:Create(v80.Weld, TweenInfo.new(math.random(30, 50) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["C1"] = CFrame.new(0, 0, 0)
					}):Play()
					v_u_3:AddItem(v80, 0.5)
				end
				repeat
					local v81 = v_u_77.Weld
					v81.C0 = v81.C0 * CFrame.Angles(0, 1.0471975511965976, 0)
					task.wait()
				until not p75.Parent
				v_u_77:Destroy()
				v_u_13:PlaySound(v_u_8.Mahito.DrillSplit.Unmorph, v76, game.SoundService.Effect)
				for _ = 1, 20 do
					local v82 = v_u_7.Mahito.Morph:Clone()
					v82.Weld.Part0 = p74["Right Arm"]
					v82.Color = p74["Right Arm"].Color
					v82.Weld.C1 = CFrame.new(math.random(-150, 150) / 100, math.random(100, 400) / 100, math.random(-150, 150) / 100)
					v82.Parent = workspace.Effects
					v82.Size = Vector3.new(1, 1, 1) * (math.random(10, 40) / 10)
					v_u_4:Create(v82, TweenInfo.new(math.random(20, 50) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_4:Create(v82.Weld, TweenInfo.new(math.random(30, 50) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["C1"] = CFrame.new(0, 0, 0)
					}):Play()
					v_u_3:AddItem(v82, 0.5)
				end
			end
		end,
		["DrillHit"] = function(p83, p_u_84, p_u_85)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_10, (ref) v_u_5, (ref) v_u_9
			local v_u_86 = p_u_84:FindFirstChild("HumanoidRootPart")
			if v_u_86 then
				local v_u_87 = v_u_7.Mahito.Drill.DrillImpact:Clone()
				v_u_87.Position = v_u_86.Position
				v_u_87.Parent = workspace.Effects
				v_u_3:AddItem(v_u_87, 1)
				task.spawn(function()
					-- upvalues: (copy) v_u_87, (ref) v_u_13, (ref) v_u_8, (copy) v_u_86, (copy) p_u_84, (copy) p_u_85
					v_u_87.Wind.Enabled = true
					v_u_13:PlaySound(v_u_8.Mahito.DrillSplit.Drill, v_u_86, game.SoundService.Effect)
					repeat
						v_u_13:Flash(p_u_84, Color3.new(1, 1, 1))
						v_u_13:PlaySound(v_u_8.Mahito.DrillSplit.DrillHit, v_u_86, game.SoundService.Effect)
						v_u_87.Position = v_u_86.Position
						task.wait(0.1)
					until not p_u_85.Parent
					v_u_87.Wind.Enabled = false
				end)
				if _G.Settings.Gore == true then
					v_u_87.Blood.Enabled = true
					v_u_87.Hit.Enabled = true
					task.spawn(function()
						-- upvalues: (ref) v_u_10, (copy) v_u_87, (copy) p_u_85, (copy) p_u_84
						repeat
							v_u_10:Blood(v_u_87.CFrame, 70, 180, 180)
							task.wait()
						until not (p_u_85.Parent and (p_u_84.Parent and p_u_85.Parent.Parent))
						v_u_87.Blood.Enabled = false
						v_u_87.Hit.Enabled = false
					end)
				end
				if v_u_5 == p83 or v_u_5.Character == p_u_84 then
					local v88 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap)
					repeat
						task.wait()
					until not p_u_85.Parent
					v88:StartFadeOut(1)
				end
			end
		end,
		["Jump"] = function(p89, p90)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_5, (ref) v_u_4
			local v91 = p90.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if v91 then
				v_u_13:PlaySound(v_u_8.Mahito.DrillSplit.Leap, v91, game.SoundService.Effect)
				local v92 = v91.CFrame.LookVector * 5 - Vector3.new(0, 2, 0)
				if v_u_5.Character == v91.Parent then
					v_u_4:Create(p90, TweenInfo.new(0.5), {
						["P"] = 70000
					}):Play()
					repeat
						p90.Position = p89.Position - v92
						task.wait()
					until not (p90.Parent and p89)
				else
					repeat
						local v93 = v91.CFrame - v91.Position + p89.Position - v92
						v91.CFrame = v91.CFrame:Lerp(v93, 0.15)
						task.wait()
					until not (p90.Parent and p89)
				end
				v_u_4:Create(p90, TweenInfo.new(0.5), {
					["P"] = 70000
				}):Play()
				repeat
					p90.Position = p89.Position - v92
					task.wait()
				until not (p90.Parent and p89)
			end
		end
	}
	v_u_11.Effects:Connect(function(p95, ...)
		-- upvalues: (copy) v_u_94
		local v96 = v_u_94[p95]
		if v96 then
			v96(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("BodyDisfigureService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14