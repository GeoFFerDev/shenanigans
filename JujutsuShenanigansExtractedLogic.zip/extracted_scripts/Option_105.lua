-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return require(script.Parent._Index["sleitnick_option@1.0.5"].option)