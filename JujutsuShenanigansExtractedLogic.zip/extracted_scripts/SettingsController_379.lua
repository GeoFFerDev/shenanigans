-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
game:GetService("AvatarEditorService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
require(v_u_6.Modules.Icon)
require(v_u_6.Modules.BloodyZee)
_G.Settings = {}
_G.LocalSettings = {}
_G.SettingUpdate = {}
local v13 = v_u_1.CreateController({
	["Name"] = "SettingsController"
})
function v13.KnitStart(_)
	-- upvalues: (copy) v_u_5, (ref) v_u_9, (ref) v_u_12, (copy) v_u_8, (copy) v_u_2, (copy) v_u_6, (ref) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3
	local v_u_14 = v_u_5.PlayerGui:WaitForChild("Menus")
	local v_u_15 = v_u_14.Group.Settings
	v_u_15:SetAttribute("Loaded", true)
	v_u_5:WaitForChild("leaderstats")
	local v_u_16 = v_u_5:WaitForChild("Gamepasses")
	local v_u_17 = v_u_5:GetMouse()
	local function v26(p_u_18, p19)
		-- upvalues: (copy) v_u_14, (ref) v_u_9, (ref) v_u_12, (ref) v_u_8
		local v_u_20 = require(p_u_18)
		local v_u_21 = v_u_14.Preset.Option:Clone()
		v_u_21.Option.Text = p_u_18.Name
		v_u_21.Name = p_u_18.Name
		v_u_21.Description.Text = v_u_20.Desc
		v_u_21.Parent = p19
		v_u_21.LayoutOrder = v_u_20.SortOrder
		local v_u_22 = _G.Settings
		if v_u_20.Val == nil then
			v_u_22 = _G.LocalSettings
			if not v_u_22[p_u_18.Name] then
				v_u_22[p_u_18.Name] = false
			end
		end
		local v_u_23 = Instance.new("BindableEvent")
		_G.SettingUpdate[v_u_20.Val or p_u_18.Name] = v_u_23
		v_u_23.Event:Connect(function()
			-- upvalues: (ref) v_u_22, (copy) v_u_20, (copy) p_u_18, (copy) v_u_21
			local v24 = v_u_22[v_u_20.Val or p_u_18.Name]
			if v24 == true then
				v_u_21.Toggle.BackgroundColor3 = Color3.fromRGB(85, 255, 0)
				v_u_21.Toggle.Side.BackgroundColor3 = Color3.fromRGB(169, 255, 189)
				v_u_21.Toggle.Side.Position = UDim2.new(0, 0, 0, 0)
			elseif v24 == false then
				v_u_21.Toggle.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
				v_u_21.Toggle.Side.BackgroundColor3 = Color3.fromRGB(85, 0, 0)
				v_u_21.Toggle.Side.Position = UDim2.new(0.5, 0, 0, 0)
			end
			if v_u_20.Callback then
				v_u_20.Callback(v24)
			end
		end)
		v_u_21.Toggle.Side.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_22, (copy) v_u_20, (copy) p_u_18, (copy) v_u_23, (ref) v_u_9, (ref) v_u_12, (ref) v_u_8
			local v25 = v_u_22[v_u_20.Val or p_u_18.Name]
			if v_u_20.Val == nil then
				_G.LocalSettings[p_u_18.Name] = not v25
				v_u_23:Fire()
			else
				v_u_9.Setting:Fire(v_u_20.Val, not v25)
			end
			v_u_12:PlaySound(v_u_8.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_12:PlaySound(v_u_8.Misc.UI.Switch, workspace, game.SoundService.Effect)
		end)
		if v_u_20.Val == nil then
			v_u_23:Fire()
		end
		return v_u_21
	end
	local function v35(p27, p28)
		-- upvalues: (copy) v_u_14, (ref) v_u_9, (ref) v_u_12, (ref) v_u_8, (copy) v_u_16
		local v_u_29 = require(p27)
		local v_u_30 = v_u_14.Preset.OptionString:Clone()
		v_u_30.Option.Text = p27.Name
		v_u_30.Name = p27.Name
		v_u_30.Description.Text = v_u_29.Desc
		v_u_30.Parent = p28
		v_u_30.LayoutOrder = v_u_29.SortOrder
		local v31 = Instance.new("BindableEvent")
		_G.SettingUpdate[v_u_29.Val] = v31
		v31.Event:Connect(function()
			-- upvalues: (copy) v_u_29, (copy) v_u_30
			local v32 = _G.Settings[v_u_29.Val]
			v_u_30.TextBox.Text = v32 or ""
		end)
		v_u_30.TextBox.FocusLost:Connect(function()
			-- upvalues: (copy) v_u_30, (ref) v_u_9, (copy) v_u_29, (ref) v_u_12, (ref) v_u_8
			local v33 = v_u_30.TextBox.Text
			if tonumber(v33) or v33 == "" then
				if tonumber(v33) then
					v33 = tonumber(v33)
				end
				v_u_9.Setting:Fire(v_u_29.Val, v33)
				v_u_12:PlaySound(v_u_8.Misc.UI.Click, workspace, game.SoundService.Effect)
			else
				v_u_30.TextBox.Text = "Invalid ID"
			end
		end)
		if v_u_29.Gamepass then
			v_u_30.Visible = v_u_16:GetAttribute(v_u_29.Gamepass)
			if v_u_30.Visible == false then
				local v_u_34 = nil
				v_u_34 = v_u_16:GetAttributeChangedSignal(v_u_29.Gamepass):Connect(function()
					-- upvalues: (ref) v_u_16, (copy) v_u_29, (ref) v_u_34, (copy) v_u_30
					if v_u_16:GetAttribute(v_u_29.Gamepass) == true then
						v_u_34:Disconnect()
						v_u_30.Visible = true
					end
				end)
			end
		end
	end
	local function v63(p36, p37)
		-- upvalues: (copy) v_u_14, (ref) v_u_9, (ref) v_u_12, (ref) v_u_8, (ref) v_u_2, (copy) v_u_17
		local v_u_38 = require(p36)
		local v_u_39 = v_u_14.Preset.OptionValue:Clone()
		v_u_39.Option.Text = p36.Name
		v_u_39.Name = p36.Name
		v_u_39.Description.Text = v_u_38.Desc
		v_u_39.Parent = p37
		v_u_39.LayoutOrder = v_u_38.SortOrder
		local v40 = Instance.new("BindableEvent")
		_G.SettingUpdate[v_u_38.Val] = v40
		v40.Event:Connect(function()
			-- upvalues: (copy) v_u_38, (copy) v_u_39
			local v41 = _G.Settings[v_u_38.Val] or 1
			v_u_39.TextBox.Text = v41
			if v_u_38.Callback then
				v_u_38.Callback(v41)
			end
			v_u_39.Bar.BarClip.Size = UDim2.new(v41 / v_u_38.Max, 0, 1, 0)
			v_u_39.Bar.BarClip.Bar.Size = UDim2.new(v41 > 0 and 1 / (v41 / v_u_38.Max) or 0, 0, 1, 0)
		end)
		v_u_39.TextBox.FocusLost:Connect(function()
			-- upvalues: (copy) v_u_39, (copy) v_u_38, (ref) v_u_9, (ref) v_u_12, (ref) v_u_8
			local v42 = v_u_39.TextBox.Text
			local v43
			if tonumber(v42) then
				local v44 = v_u_39.TextBox.Text
				local v45 = tonumber(v44)
				local v46 = v_u_38.Max
				v43 = math.clamp(v45, 0, v46) or 1
			else
				v43 = 1
			end
			v_u_9.Setting:Fire(v_u_38.Val, (tonumber(v43)))
			v_u_12:PlaySound(v_u_8.Misc.UI.Click, workspace, game.SoundService.Effect)
		end)
		v_u_39.Bar.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_2, (copy) v_u_39, (ref) v_u_17, (copy) v_u_38, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9
			local v_u_54 = v_u_2.Stepped:Connect(function()
				-- upvalues: (ref) v_u_39, (ref) v_u_17, (ref) v_u_38
				local v47 = v_u_39.Bar.AbsolutePosition
				local v48 = v_u_39.Bar.AbsoluteSize
				local v49 = v47.X
				local v50 = v47.X + v48.X
				local v51 = (v_u_17.X - v49) / (v50 - v49)
				local v52 = math.clamp(v51, 0, 1) * v_u_38.Max * 10
				local v53 = math.floor(v52) / 10
				v_u_39.TextBox.Text = v53
				v_u_39.Bar.BarClip.Size = UDim2.new(v53 / 2, 0, 1, 0)
				v_u_39.Bar.BarClip.Bar.Size = UDim2.new(v53 > 0 and (1 / (v53 / 2) or 0) or 0, 0, 1, 0)
				if v_u_38.Callback then
					v_u_38.Callback(v53)
				end
			end)
			local v_u_55 = nil
			v_u_55 = v_u_39.Bar.InputEnded:Connect(function()
				-- upvalues: (ref) v_u_55, (ref) v_u_54, (ref) v_u_12, (ref) v_u_8, (ref) v_u_39, (ref) v_u_17, (ref) v_u_38, (ref) v_u_9
				v_u_55:Disconnect()
				v_u_54:Disconnect()
				v_u_12:PlaySound(v_u_8.Misc.UI.Click, workspace, game.SoundService.Effect)
				local v56 = v_u_39.Bar.AbsolutePosition
				local v57 = v_u_39.Bar.AbsoluteSize
				local v58 = v56.X
				local v59 = v56.X + v57.X
				local v60 = (v_u_17.X - v58) / (v59 - v58)
				local v61 = math.clamp(v60, 0, 1) * v_u_38.Max * 10
				local v62 = math.floor(v61) / 10
				v_u_39.TextBox.Text = v62
				v_u_39.Bar.BarClip.Size = UDim2.new(v62 / 2, 0, 1, 0)
				v_u_39.Bar.BarClip.Bar.Size = UDim2.new(v62 > 0 and (1 / (v62 / 2) or 0) or 0, 0, 1, 0)
				v_u_9.Setting:Fire(v_u_38.Val, v62)
			end)
		end)
	end
	local function v69(p64, p65)
		-- upvalues: (copy) v_u_14, (ref) v_u_12, (ref) v_u_8, (copy) v_u_16
		local v_u_66 = require(p64)
		local v_u_67 = v_u_14.Preset.OptionButton:Clone()
		v_u_67.Option.Text = p64.Name
		v_u_67.Name = p64.Name
		v_u_67.TextButton.Text = v_u_66.BtnText or p64.Name
		v_u_67.Description.Text = v_u_66.Desc
		v_u_67.Parent = p65
		v_u_67.LayoutOrder = v_u_66.SortOrder
		v_u_67.TextButton.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (copy) v_u_66
			v_u_12:PlaySound(v_u_8.Misc.UI.Click, workspace, game.SoundService.Effect)
			if v_u_66.Callback then
				v_u_66.Callback()
			end
		end)
		if v_u_66.Gamepass then
			v_u_67.Visible = v_u_16:GetAttribute(v_u_66.Gamepass)
			if v_u_67.Visible == false then
				local v_u_68 = nil
				v_u_68 = v_u_16:GetAttributeChangedSignal(v_u_66.Gamepass):Connect(function()
					-- upvalues: (ref) v_u_16, (copy) v_u_66, (ref) v_u_68, (copy) v_u_67
					if v_u_16:GetAttribute(v_u_66.Gamepass) == true then
						v_u_68:Disconnect()
						v_u_67.Visible = true
					end
				end)
			end
		end
	end
	for _, v_u_70 in v_u_15.Settings.Categories:GetChildren() do
		if v_u_70:IsA("TextButton") then
			v_u_70.MouseButton1Down:Connect(function()
				-- upvalues: (copy) v_u_15, (copy) v_u_70, (ref) v_u_12, (ref) v_u_8
				for _, v71 in v_u_15.Settings.Categories:GetChildren() do
					if v71:IsA("TextButton") then
						v71.Select.Visible = v71 == v_u_70
					end
				end
				v_u_12:PlaySound(v_u_8.Misc.UI.Click, workspace, game.SoundService.Effect)
				for _, v72 in v_u_15.Settings.Items:GetChildren() do
					v72.Visible = v72.Name == v_u_70.Name
				end
			end)
		end
	end
	for _, v73 in v_u_6.Modules.Settings:GetChildren() do
		local v74 = v_u_15.Settings.Items:FindFirstChild(v73.Name)
		for _, v75 in v73:GetChildren() do
			local v76 = require(v75)
			if v76.Btn == 1 then
				v26(v75, v74)
			elseif v76.Btn == 2 then
				v35(v75, v74)
			elseif v76.Btn == 3 then
				v63(v75, v74)
			elseif v76.Btn == 4 then
				v69(v75, v74)
			end
		end
	end
	v_u_6.Remotes.ForceFun.OnClientEvent:Connect(function(p77, _)
		_G.LocalSettings[p77] = true
		_G.SettingUpdate[p77]:Fire()
	end)
	local v_u_78 = false
	local v_u_79 = nil
	v_u_2.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_78, (ref) v_u_10, (ref) v_u_79, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
		local v80 = workspace.CurrentCamera.CFrame.Y
		if v_u_78 == false then
			if v80 > 15000 then
				v_u_78 = true
				v_u_10.Give:Fire("Space Shenanigans")
				v_u_79 = v_u_7.Misc.Space:Clone()
				v_u_79.Position = workspace.CurrentCamera.CFrame.Position
				v_u_79.Parent = workspace.Effects
				v_u_4:Create(v_u_79, TweenInfo.new(1), {
					["Transparency"] = 0
				}):Play()
				v_u_4:Create(v_u_79.Earth, TweenInfo.new(1), {
					["Transparency"] = 0
				}):Play()
				v_u_4:Create(v_u_79.Earth.Atmo, TweenInfo.new(1), {
					["Transparency"] = 0
				}):Play()
			end
		elseif v_u_78 == true and v80 < 15000 then
			v_u_78 = false
			v_u_4:Create(v_u_79, TweenInfo.new(1), {
				["Transparency"] = 1
			}):Play()
			v_u_4:Create(v_u_79.Earth, TweenInfo.new(1), {
				["Transparency"] = 1
			}):Play()
			v_u_4:Create(v_u_79.Earth.Atmo, TweenInfo.new(1), {
				["Transparency"] = 1
			}):Play()
			v_u_3:AddItem(v_u_79, 1)
			v_u_79 = nil
		end
		if v_u_79 then
			local v81 = (v80 - 15000) / 20000
			v_u_79.Position = workspace.CurrentCamera.CFrame.Position
			local v82 = v_u_79.Earth
			local v83 = v_u_79.Position
			local v84 = v81 * 150
			local v85 = math.clamp(v84, 0, 150) + 250
			v82.Position = v83 - Vector3.new(0, v85, 0)
		end
	end)
	v_u_10.Give:Connect(function()
		-- upvalues: (ref) v_u_10
		if _G.LocalSettings.Gravity and _G.LocalSettings.Invert then
			v_u_10.Give:Fire("Betavision", true)
		end
	end)
	v_u_9.Setting:Connect(function(p86, p87)
		_G.Settings[p86] = p87
		if _G.SettingUpdate[p86] then
			_G.SettingUpdate[p86]:Fire()
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12
	v_u_9 = v_u_1.GetService("JoinService")
	v_u_10 = v_u_1.GetService("AchievementService")
	v_u_11 = v_u_1.GetController("ToolController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13