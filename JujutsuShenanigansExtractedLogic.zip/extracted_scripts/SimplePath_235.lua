-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {
	["TIME_VARIANCE"] = 0.07,
	["COMPARISON_CHECKS"] = 1,
	["JUMP_WHEN_STUCK"] = true
}
local v_u_2 = game:GetService("PathfindingService")
local v_u_3 = game:GetService("Players")
local v_u_7 = {
	["StatusType"] = {
		["Idle"] = "Idle",
		["Active"] = "Active"
	},
	["ErrorType"] = {
		["LimitReached"] = "LimitReached",
		["TargetUnreachable"] = "TargetUnreachable",
		["ComputationError"] = "ComputationError",
		["AgentStuck"] = "AgentStuck"
	},
	["__index"] = function(p4, p5)
		-- upvalues: (copy) v_u_7
		if p5 == "Stopped" and not p4._humanoid then
			local v6 = error
			v6((v6 == error and "SimplePath Error: " or "SimplePath: ") .. "Attempt to use Path.Stopped on a non-humanoid.")
		end
		return p4._events[p5] and p4._events[p5].Event or p5 == "LastError" and p4._lastError or (p5 == "Status" and p4._status or v_u_7[p5])
	end
}
local v_u_8 = Instance.new("Part")
v_u_8.Size = Vector3.new(0.3, 0.3, 0.3)
v_u_8.Anchored = true
v_u_8.CanCollide = false
v_u_8.Material = Enum.Material.Neon
v_u_8.Shape = Enum.PartType.Ball
local function v_u_13(p9)
	-- upvalues: (copy) v_u_8
	local v10 = {}
	for _, v11 in ipairs(p9) do
		local v12 = v_u_8:Clone()
		v12.Position = v11.Position
		v12.Parent = workspace
		v12.Color = v11 == p9[#p9] and Color3.fromRGB(0, 255, 0) or (v11.Action == Enum.PathWaypointAction.Jump and Color3.fromRGB(255, 0, 0) or Color3.fromRGB(255, 139, 0))
		table.insert(v10, v12)
	end
	return v10
end
local function v_u_16(p14)
	for v15 = 2, #p14._waypoints do
		if (p14._waypoints[v15].Position - p14._waypoints[v15 - 1].Position).Magnitude > 0.1 then
			return v15
		end
	end
	return 2
end
local function v_u_33(p_u_17, p18)
	-- upvalues: (copy) v_u_7
	if getmetatable(p_u_17) then
		if p_u_17._humanoid then
			if p18 and p_u_17._currentWaypoint + 1 <= #p_u_17._waypoints then
				if p_u_17._currentWaypoint + 1 < #p_u_17._waypoints then
					local v19 = p_u_17._waypoints[p_u_17._currentWaypoint - 1]
					local v20 = p_u_17._waypoints[p_u_17._currentWaypoint]
					p_u_17._events.WaypointReached:Fire(p_u_17._agent, v19, v20)
				end
				p_u_17._currentWaypoint = p_u_17._currentWaypoint + 1
				if p_u_17._waypoints[p_u_17._currentWaypoint].Action == Enum.PathWaypointAction.Jump then
					pcall(function()
						-- upvalues: (copy) p_u_17
						if p_u_17._humanoid:GetState() ~= Enum.HumanoidStateType.Jumping and p_u_17._humanoid:GetState() ~= Enum.HumanoidStateType.Freefall then
							p_u_17._humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
						end
					end)
				end
				p_u_17._humanoid:MoveTo(p_u_17._waypoints[p_u_17._currentWaypoint].Position)
				return
			elseif p18 then
				p_u_17._moveConnection:Disconnect()
				p_u_17._moveConnection = nil
				p_u_17._status = v_u_7.StatusType.Idle
				local v21 = p_u_17._visualWaypoints
				if v21 then
					for _, v22 in ipairs(v21) do
						v22:Destroy()
					end
				end
				p_u_17._visualWaypoints = nil
				p_u_17._events.Reached:Fire(p_u_17._agent, p_u_17._waypoints[p_u_17._currentWaypoint])
			else
				p_u_17._moveConnection:Disconnect()
				p_u_17._moveConnection = nil
				p_u_17._status = v_u_7.StatusType.Idle
				local v23 = p_u_17._visualWaypoints
				if v23 then
					for _, v24 in ipairs(v23) do
						v24:Destroy()
					end
				end
				p_u_17._visualWaypoints = nil
				local v25 = p_u_17.ErrorType.TargetUnreachable
				p_u_17._lastError = v25
				p_u_17._events.Error:Fire(v25)
			end
		elseif p18 and p_u_17._currentWaypoint + 1 <= #p_u_17._waypoints then
			local v26 = p_u_17._waypoints[p_u_17._currentWaypoint - 1]
			local v27 = p_u_17._waypoints[p_u_17._currentWaypoint]
			p_u_17._events.WaypointReached:Fire(p_u_17._agent, v26, v27)
			p_u_17._currentWaypoint = p_u_17._currentWaypoint + 1
			return
		elseif p18 then
			local v28 = p_u_17._visualWaypoints
			if v28 then
				for _, v29 in ipairs(v28) do
					v29:Destroy()
				end
			end
			p_u_17._visualWaypoints = nil
			p_u_17._target = nil
			p_u_17._events.Reached:Fire(p_u_17._agent, p_u_17._waypoints[p_u_17._currentWaypoint])
		else
			local v30 = p_u_17._visualWaypoints
			if v30 then
				for _, v31 in ipairs(v30) do
					v31:Destroy()
				end
			end
			p_u_17._visualWaypoints = nil
			p_u_17._target = nil
			local v32 = p_u_17.ErrorType.TargetUnreachable
			p_u_17._lastError = v32
			p_u_17._events.Error:Fire(v32)
		end
	else
		return
	end
end
local function v_u_36(p_u_34)
	if p_u_34._currentWaypoint ~= #p_u_34._waypoints then
		p_u_34._position._count = (p_u_34._agent.PrimaryPart.Position - p_u_34._position._last).Magnitude <= 0.07 and (p_u_34._position._count + 1 or 0) or 0
		p_u_34._position._last = p_u_34._agent.PrimaryPart.Position
		if p_u_34._position._count >= p_u_34._settings.COMPARISON_CHECKS then
			if p_u_34._settings.JUMP_WHEN_STUCK then
				pcall(function()
					-- upvalues: (copy) p_u_34
					if p_u_34._humanoid:GetState() ~= Enum.HumanoidStateType.Jumping and p_u_34._humanoid:GetState() ~= Enum.HumanoidStateType.Freefall then
						p_u_34._humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
					end
				end)
			end
			local v35 = p_u_34.ErrorType.AgentStuck
			p_u_34._lastError = v35
			p_u_34._events.Error:Fire(v35)
		end
	end
end
function v_u_7.GetNearestCharacter(p37)
	-- upvalues: (copy) v_u_3
	local v38 = (1 / 0)
	local v39 = nil
	for _, v40 in ipairs(v_u_3:GetPlayers()) do
		if v40.Character and (v40.Character.PrimaryPart.Position - p37).Magnitude < v38 then
			v39 = v40.Character
			v38 = (v40.Character.PrimaryPart.Position - p37).Magnitude
		end
	end
	return v39
end
function v_u_7.new(p41, p42, p43)
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_7
	if not (p41 and (p41:IsA("Model") and p41.PrimaryPart)) then
		local v44 = error
		v44((v44 == error and "SimplePath Error: " or "SimplePath: ") .. "Pathfinding agent must be a valid Model Instance with a set PrimaryPart.")
	end
	local v45 = {
		["_settings"] = p43 or v_u_1,
		["_events"] = {
			["Reached"] = Instance.new("BindableEvent"),
			["WaypointReached"] = Instance.new("BindableEvent"),
			["Blocked"] = Instance.new("BindableEvent"),
			["Error"] = Instance.new("BindableEvent"),
			["Stopped"] = Instance.new("BindableEvent")
		},
		["_agent"] = p41,
		["_humanoid"] = p41:FindFirstChildOfClass("Humanoid"),
		["_path"] = v_u_2:CreatePath(p42),
		["_status"] = "Idle",
		["_t"] = 0,
		["_position"] = {
			["_last"] = Vector3.new(),
			["_count"] = 0
		}
	}
	local v46 = v_u_7
	local v_u_47 = setmetatable(v45, v46)
	for v48, v49 in pairs(v_u_1) do
		v_u_47._settings[v48] = v_u_47._settings[v48] == nil and v49 and v49 or v_u_47._settings[v48]
	end
	v_u_47._path.Blocked:Connect(function(...)
		-- upvalues: (copy) v_u_47
		if v_u_47._currentWaypoint <= ... and (... <= v_u_47._currentWaypoint + 1 and v_u_47._humanoid) then
			local v_u_50 = v_u_47
			pcall(function()
				-- upvalues: (copy) v_u_50
				if v_u_50._humanoid:GetState() ~= Enum.HumanoidStateType.Jumping and v_u_50._humanoid:GetState() ~= Enum.HumanoidStateType.Freefall then
					v_u_50._humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
				end
			end)
			v_u_47._events.Blocked:Fire(v_u_47._agent, v_u_47._waypoints[...])
		end
	end)
	return v_u_47
end
function v_u_7.Destroy(p51)
	for _, v52 in ipairs(p51._events) do
		v52:Destroy()
	end
	p51._events = nil
	if rawget(p51, "_visualWaypoints") then
		local v53 = p51._visualWaypoints
		if v53 then
			for _, v54 in ipairs(v53) do
				v54:Destroy()
			end
		end
		p51._visualWaypoints = nil
	end
	p51._path:Destroy()
	setmetatable(p51, nil)
	for v55, _ in pairs(p51) do
		p51[v55] = nil
	end
end
function v_u_7.Stop(p56)
	-- upvalues: (copy) v_u_7
	if p56._humanoid then
		if p56._status == v_u_7.StatusType.Idle then
			local v58 = (function(p57)
				warn(debug.traceback(p57))
			end == error and "SimplePath Error: " or "SimplePath: ") .. "Attempt to run Path:Stop() in idle state"
			warn(debug.traceback(v58))
		else
			p56._moveConnection:Disconnect()
			p56._moveConnection = nil
			p56._status = v_u_7.StatusType.Idle
			local v59 = p56._visualWaypoints
			if v59 then
				for _, v60 in ipairs(v59) do
					v60:Destroy()
				end
			end
			p56._visualWaypoints = nil
			p56._events.Stopped:Fire(p56._model)
		end
	else
		local v61 = error
		v61((v61 == error and "SimplePath Error: " or "SimplePath: ") .. "Attempt to call Path:Stop() on a non-humanoid.")
		return
	end
end
function v_u_7.Run(p_u_62, p_u_63)
	-- upvalues: (copy) v_u_33, (copy) v_u_7, (copy) v_u_36, (copy) v_u_13, (copy) v_u_16
	if p_u_63 or (p_u_62._humanoid or not p_u_62._target) then
		if not p_u_63 or typeof(p_u_63) ~= "Vector3" and not p_u_63:IsA("BasePart") then
			local v64 = error
			v64((v64 == error and "SimplePath Error: " or "SimplePath: ") .. "Pathfinding target must be a valid Vector3 or BasePart.")
		end
		if os.clock() - p_u_62._t <= p_u_62._settings.TIME_VARIANCE and p_u_62._humanoid then
			task.wait(os.clock() - p_u_62._t)
			local v65 = p_u_62.ErrorType.LimitReached
			p_u_62._lastError = v65
			p_u_62._events.Error:Fire(v65)
			return false
		end
		if p_u_62._humanoid then
			p_u_62._t = os.clock()
		end
		local v67, _ = pcall(function()
			-- upvalues: (copy) p_u_62, (copy) p_u_63
			local v66 = p_u_63
			p_u_62._path:ComputeAsync(p_u_62._agent.PrimaryPart.Position, typeof(v66) == "Vector3" and p_u_63 or p_u_63.Position)
		end)
		if not v67 or (p_u_62._path.Status == Enum.PathStatus.NoPath or (#p_u_62._path:GetWaypoints() < 2 or p_u_62._humanoid and p_u_62._humanoid:GetState() == Enum.HumanoidStateType.Freefall)) then
			local v68 = p_u_62._visualWaypoints
			if v68 then
				for _, v69 in ipairs(v68) do
					v69:Destroy()
				end
			end
			p_u_62._visualWaypoints = nil
			task.wait()
			local v70 = p_u_62.ErrorType.ComputationError
			p_u_62._lastError = v70
			p_u_62._events.Error:Fire(v70)
			return false
		end
		p_u_62._status = p_u_62._humanoid and v_u_7.StatusType.Active or v_u_7.StatusType.Idle
		p_u_62._target = p_u_63
		p_u_62._waypoints = p_u_62._path:GetWaypoints()
		p_u_62._currentWaypoint = 2
		if p_u_62._humanoid then
			v_u_36(p_u_62)
		end
		local v71 = p_u_62._visualWaypoints
		if v71 then
			for _, v72 in ipairs(v71) do
				v72:Destroy()
			end
		end
		local v73 = p_u_62.Visualize
		if v73 then
			v73 = v_u_13(p_u_62._waypoints)
		end
		p_u_62._visualWaypoints = v73
		local v74 = p_u_62._humanoid
		if v74 then
			v74 = p_u_62._moveConnection or p_u_62._humanoid.MoveToFinished:Connect(function(...)
				-- upvalues: (ref) v_u_33, (copy) p_u_62
				v_u_33(p_u_62, ...)
			end)
		end
		p_u_62._moveConnection = v74
		if p_u_62._humanoid then
			p_u_62._humanoid:MoveTo(p_u_62._waypoints[p_u_62._currentWaypoint].Position)
		elseif #p_u_62._waypoints == 2 then
			p_u_62._target = nil
			local v75 = p_u_62._visualWaypoints
			if v75 then
				for _, v76 in ipairs(v75) do
					v76:Destroy()
				end
			end
			p_u_62._visualWaypoints = nil
			p_u_62._events.Reached:Fire(p_u_62._agent, p_u_62._waypoints[2])
		else
			p_u_62._currentWaypoint = v_u_16(p_u_62)
			v_u_33(p_u_62, true)
		end
		return true
	end
	v_u_33(p_u_62, true)
end
return v_u_7