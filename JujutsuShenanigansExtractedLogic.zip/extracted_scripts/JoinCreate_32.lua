-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "joincreate",
	["Description"] = "Joins a server made with the ingame creator\nA player will be forcefully kicked if the server is full",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"Mod"
	},
	["Args"] = {
		{
			["Type"] = "string",
			["Name"] = "Username"
		}
	}
}
return v1