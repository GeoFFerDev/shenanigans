-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("ReplicatedStorage")
local v_u_1 = game:GetService("TweenService")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("Players").LocalPlayer
local function v_u_15(p4, p5)
	-- upvalues: (copy) v_u_15
	if typeof(p4) ~= "table" then
		error((("%* is not a suported type of function Utility.copy"):format((typeof(p4)))))
	end
	local v6 = {}
	if p5 then
		for v11, v12 in p4 do
			local v9 = typeof(v11) == "table"
			local v10 = typeof(v12) == "table"
			if v9 then
				local v11 = v_u_15(v11, true)
			end
			if v10 then
				local v12 = v_u_15(v12, true)
			end
			v6[v11] = v12
		end
		return v6
	else
		for v13, v14 in p4 do
			v6[v13] = v14
		end
		return v6
	end
end
local function v_u_22(p16, p17)
	-- upvalues: (copy) v_u_15, (copy) v_u_22
	local v18 = v_u_15(p16, true)
	for v19, v20 in p17 do
		if v18[v19] == nil then
			if typeof(v20) == "table" then
				v18[v19] = v_u_15(v20, true)
			else
				v18[v19] = v20
			end
		else
			local v21 = v18[v19]
			if typeof(v21) == "table" and typeof(v20) == "table" then
				v18[v19] = v_u_22(v18[v19], v20)
			end
		end
	end
	return v18
end
return function(p23)
	-- upvalues: (copy) v_u_22, (copy) v_u_1, (copy) v_u_3, (copy) v_u_2
	local v_u_24 = v_u_22(p23 or {}, {
		["TweenIn"] = { 0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.In },
		["TweenOut"] = { 0.25, Enum.EasingStyle.Cubic, Enum.EasingDirection.InOut },
		["LifeTime"] = 0.3,
		["Color"] = Color3.new(1, 1, 1),
		["Contrast"] = 0,
		["Brightness"] = 0,
		["Saturation"] = 0
	})
	local v_u_25 = Instance.new("ColorCorrectionEffect")
	local v26 = v_u_1
	local v27 = TweenInfo.new
	local v28 = v_u_24.TweenIn
	v26:Create(v_u_25, v27(unpack(v28)), {
		["TintColor"] = v_u_24.Color,
		["Contrast"] = v_u_24.Contrast,
		["Brightness"] = v_u_24.Brightness,
		["Saturation"] = v_u_24.Saturation
	}):Play()
	local v29
	if v_u_3:GetAttribute("Epileptic_Mode") then
		v29 = nil
	else
		v29 = v_u_2
	end
	v_u_25.Parent = v29
	task.delay(v_u_24.LifeTime, function()
		-- upvalues: (copy) v_u_25, (ref) v_u_1, (ref) v_u_24
		if v_u_25 then
			local v30 = v_u_1
			local v31 = v_u_25
			local v32 = TweenInfo.new
			local v33 = v_u_24.TweenOut
			v30:Create(v31, v32(unpack(v33)), {
				["Contrast"] = 0,
				["Brightness"] = 0,
				["Saturation"] = 0,
				["TintColor"] = Color3.new(1, 1, 1)
			}):Play()
			task.delay(v_u_24.TweenOut[1] + 0.1, v_u_25.Destroy, v_u_25)
		end
	end)
	return v_u_25
end