-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Version"] = 1,
	["List"] = {
		"Exploiting",
		"Selling/buying maps for real life currency",
		"Inappropriate server/build",
		"Inappropriate kill sounds/inappropriate sound id on \'boombox\' emote",
		"Inappropriate avatars",
		"Abuse of gamebreaking bug",
		"Abuse of tab glitching/X holding",
		"Bypassing roblox chat with the \'message\' emote",
		"Following and targeting players across servers",
		"Harassment through chat. Toxicity is not considered harassment",
		"Inserting inappropriate content on the billboards",
		"Gaining kills in an illegitimate way will result in your kills being reset to 0",
		"Making inappropriate content in JJS on tiktok, youtube, or any similar social media",
		"Participating in exploiting/black market servers",
		"Inappropriate usernames/display names"
	}
}