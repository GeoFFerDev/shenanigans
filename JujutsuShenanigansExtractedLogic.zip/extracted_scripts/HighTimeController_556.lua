-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local v_u_4 = v3.Utils
local v_u_5 = v3.Sounds
require(v3.Modules.CameraShaker)
local v_u_6 = require(v3.Modules.BloodyZee)
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "HighTimeController"
})
function v10.KnitStart(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_5, (copy) v_u_6, (copy) v_u_4, (copy) v_u_2, (ref) v_u_7
	local v_u_17 = {
		["Hit"] = function(p11)
			-- upvalues: (ref) v_u_8, (ref) v_u_5, (ref) v_u_6
			local v12 = p11:FindFirstChild("HumanoidRootPart")
			if v12 then
				v_u_8:Flash(p11, Color3.new(0.745098, 0, 0.0117647))
				v_u_8:PlaySound(v_u_5.Choso.BloodEdge.StabHit, v12, game.SoundService.Effect)
				for _ = 1, 5 do
					v_u_6:Blood(p11["Right Leg"].CFrame * CFrame.new(0, 0.5, 0), -math.random(20, 70), 25, 25)
				end
				for _ = 1, 5 do
					v_u_6:Blood(p11["Left Leg"].CFrame * CFrame.new(0, 0.5, 0), -math.random(20, 70), 25, 25)
				end
			end
		end,
		["Swing"] = function(p13)
			-- upvalues: (ref) v_u_8, (ref) v_u_5, (ref) v_u_4, (ref) v_u_2
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_8:PlaySound(v_u_5.Haruta.Hightime, v14, game.SoundService.Effect)
				local v15 = v_u_4.Haruta.SlashEmit:Clone()
				v15.Weld.Part0 = v14
				v15.Parent = workspace.Effects
				for _, v16 in pairs(v15:GetDescendants()) do
					if v16:IsA("ParticleEmitter") then
						v16:Emit(v16:GetAttribute("EmitCount"))
					end
				end
				v_u_2:AddItem(v15, 1.5)
			end
		end
	}
	v_u_7.Effects:Connect(function(p18, ...)
		-- upvalues: (copy) v_u_17
		local v19 = v_u_17[p18]
		if v19 then
			v19(...)
		end
	end)
end
function v10.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_9, (ref) v_u_8
	v_u_7 = v_u_1.GetService("HighTimeService")
	v_u_9 = v_u_1.GetController("HitboxController")
	v_u_8 = v_u_1.GetController("FXController")
end
return v10