-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.LightningBeams)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "GrappleController"
})
function v13.KnitStart(_)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (ref) v_u_12, (copy) v_u_2, (ref) v_u_11, (copy) v_u_7, (copy) v_u_9, (copy) v_u_6, (copy) v_u_8, (ref) v_u_10
	local v_u_43 = {
		["Jump"] = function(p14, p15, p16)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_12
			local v17 = p15.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if not v17 then
				return
			end
			local v18 = p16 * 5
			if v_u_4.Character == v17.Parent then
				v_u_3:Create(p15, TweenInfo.new(0.3), {
					["P"] = 50000
				}):Play()
				repeat
					p15.Position = p14.Position - v18
					v17.CFrame = CFrame.lookAlong(v17.Position, v18)
					task.wait()
				until not (p15.Parent and p14)
				::l6::
				return
			else
				while true do
					if v_u_12.lastRecvServer[v17.Parent] ~= nil then
						v_u_12.lastRecvServer[v17.Parent] = false
					end
					local v19 = CFrame.lookAlong(p14.Position, v18) - v18
					v17.CFrame = v17.CFrame:Lerp(v19, 0.075)
					task.wait()
					if not (p15.Parent and p14) then
						goto l6
					end
				end
			end
		end,
		["Grapple"] = function(p20, p21, p22)
			-- upvalues: (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3
			local v23 = p20:FindFirstChild("HumanoidRootPart")
			if not v23 then
				return
			end
			local v24 = p20.SetAssets:FindFirstChild("Gavel")
			if not v24 then
				return
			end
			local v25 = Instance.new("Model", v24.Extensions)
			v_u_2:AddItem(v25, 3)
			for _, v26 in v24:GetChildren() do
				if v26:IsA("BasePart") then
					v26.Transparency = 1
				end
			end
			v_u_11:PlaySound(v_u_7.Hiromi.Grapple.Fire, v23, game.SoundService.Effect)
			local v27 = v_u_9.new(v24.A, p22.RootAttachment, 5, v25)
			v27.Color = Color3.fromRGB(90, 76, 66)
			v27.Material = Enum.Material.Wood
			v27.FadeLength = 0.01
			v27.PulseSpeed = 100
			v27.MaxRadius = 0
			v27.MinRadius = 0
			v27.AnimationSpeed = 10
			v27.MinThicknessMultiplier = 0.4
			v27.MaxThicknessMultiplier = 0.4
			local v28 = false
			while true do
				if p21.Value == 2 and v28 == false then
					v27.MaxRadius = 0.5
					task.wait(0.05)
					v27.MaxRadius = 1
					task.wait(0.05)
					v27.MaxRadius = 3
					task.wait(0.05)
					v27.MaxRadius = 5
					task.wait(0.05)
					v27.MaxRadius = 6.5
					task.wait(0.05)
					v27.MaxRadius = 6.75
					task.wait(0.05)
					v27.MaxRadius = 5.5
					task.wait(0.05)
					v27.MaxRadius = 3
					task.wait(0.05)
					v27.MaxRadius = 1
					task.wait(0.05)
					v27.MaxRadius = 0
					v28 = true
				end
				task.wait()
				if not (p21 and p21.Parent) then
					local v29 = v_u_6.Hiromi.GavelFire:Clone()
					v29.Position = p22.Position
					v29.Parent = workspace.Effects
					v_u_2:AddItem(v29, 0.1)
					v27.Attachment1 = v29.Attachment
					v_u_3:Create(v29, TweenInfo.new(0.1), {
						["Position"] = v24.Position
					}):Play()
					task.wait(0.1)
					v27:Destroy()
					for _, v30 in v24:GetChildren() do
						if v30:IsA("BasePart") then
							v30.Transparency = 0
						end
					end
					return
				end
			end
		end,
		["Grab"] = function(p31, p32)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v33 = p31:FindFirstChild("HumanoidRootPart")
			if v33 then
				local v34 = p32:FindFirstChild("HumanoidRootPart")
				if v34 then
					v_u_11:PlaySound(v_u_7.Hiromi.Grapple.Start, v33, game.SoundService.Effect)
					local v35 = v_u_6.Itadori.CounterHit.Feint:Clone()
					for _, v36 in v35:GetChildren() do
						v36.Color = ColorSequence.new(Color3.fromRGB(255, 195, 134))
						v36.TimeScale = 0.75
					end
					v35.Parent = v34
					v35.Sparks:Emit(30)
					v35.Ring:Emit(6)
					v_u_2:AddItem(v35, 1)
				end
			else
				return
			end
		end,
		["GrabHit"] = function(p37)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v38 = p37:FindFirstChild("HumanoidRootPart")
			if v38 then
				v_u_11:Flash(p37, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v38, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p39, p40)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v41 = p40:FindFirstChild("HumanoidRootPart")
			if v41 then
				local v42 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v42.Position = v41.Position
				v42.Parent = workspace.Effects
				v_u_2:AddItem(v42, 1)
				v42.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v42.Wind.Color = v42.Sparks.Color
				v42.Wind2.Color = v42.Sparks.Color
				v42.Sparks:Emit(50)
				v42.Wind:Emit(7)
				v42.Wind2:Emit(7)
				v_u_11:Flash(p40, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Hakari.EnergySurge.Hit1, v41, game.SoundService.Effect)
				if v_u_4 == p39 or v_u_4.Character == p40 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p44, ...)
		-- upvalues: (copy) v_u_43
		local v45 = v_u_43[p44]
		if v45 then
			v45(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("GrappleService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("JoinController")
end
return v13