-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "data",
	["Description"] = "Display all data of a player",
	["Group"] = {
		"Owner",
		"HeadMod",
		"Developer",
		"Mod"
	},
	["Args"] = {
		{
			["Type"] = "username",
			["Name"] = "Username"
		},
		{
			["Type"] = "number",
			["Name"] = "Version",
			["Optional"] = true
		}
	}
}
return v1