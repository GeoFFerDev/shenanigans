-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_3 = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
local v7 = v_u_1.CreateController({
	["Name"] = "KiSpamController"
})
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = workspace.CurrentCamera
function v7.KnitStart(_)
	-- upvalues: (copy) v_u_3, (copy) v_u_10, (copy) v_u_5, (copy) v_u_2, (ref) v_u_8, (copy) v_u_6, (ref) v_u_9
	local v_u_31 = {
		["AutoRotate"] = function(p11, p12)
			-- upvalues: (ref) v_u_3, (ref) v_u_10
			local v13 = p11:FindFirstChild("HumanoidRootPart")
			if v13 then
				if p11 == v_u_3.Character then
					repeat
						task.wait()
						p12.CFrame = CFrame.lookAlong(v13.Position, v_u_10.CFrame.LookVector, v_u_10.CFrame.UpVector)
					until not p12.Parent
				end
			end
		end,
		["ProjectileExplode"] = function(p14)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_8, (ref) v_u_6
			local v15 = v_u_5.Goku.Explode:Clone()
			v15.CFrame = p14
			v15.Parent = workspace.Effects
			v_u_2:AddItem(v15, 1)
			local v16 = next
			local v17, v18 = v15.Attachment:GetChildren()
			for _, v19 in v16, v17, v18 do
				v19:Emit(v19:GetAttribute("EmitCount"))
			end
			v_u_8:PlaySound(v_u_6.Goku.ExplodeKi, v15, game.SoundService.Effect)
		end,
		["Hit"] = function(p20)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_8, (ref) v_u_6
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				local v22 = v_u_5.Goku.Explode.Attachment:Clone()
				v22.CFrame = v21.CFrame
				v22.Parent = workspace.Effects
				v_u_2:AddItem(v22, 1)
				local v23 = next
				local v24, v25 = v22:GetChildren()
				for _, v26 in v23, v24, v25 do
					v26:Emit(v26:GetAttribute("EmitCount"))
				end
				v_u_8:Flash(p20, Color3.new(1, 1, 1))
				v_u_8:PlaySound(v_u_6.Goku.HitKi, v21, game.SoundService.Effect)
			end
		end,
		["Shoot"] = function(p27, p28, p29)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v30 = p27:FindFirstChild("HumanoidRootPart")
			if v30 and p28 then
				p28.Attachment.Impact15:Emit(2)
				v_u_8:PlaySound(v_u_6.Goku.ShootKi, v30, game.SoundService.Effect).PlaybackSpeed = p29 == "Left" and 1.2 or 1
			end
		end
	}
	v_u_9.Effects:Connect(function(p32, ...)
		-- upvalues: (copy) v_u_31
		local v33 = v_u_31[p32]
		if v33 then
			v33(...)
		end
	end)
end
function v7.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_8
	v_u_9 = v_u_1.GetService("KiSpamService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v7