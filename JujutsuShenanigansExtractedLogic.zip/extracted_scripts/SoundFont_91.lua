-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = require(script.SoundCache)
local v_u_3 = require(script.Tween)
local v_u_4 = game:GetService("RunService")
v1._keyDownLookup = {}
v1._soundQueue = {}
function v1._startSoundQueue(p_u_5)
	-- upvalues: (copy) v_u_4
	if not p_u_5._queueConnection then
		p_u_5._queueConnection = v_u_4.Heartbeat:Connect(function(p6)
			-- upvalues: (copy) p_u_5
			local v7 = #p_u_5._soundQueue
			if v7 == 0 then
				p_u_5:_stopSoundQueue()
			else
				local v8 = v7 - 35
				local v9 = 1
				for v10, v11 in ipairs(p_u_5._soundQueue) do
					if v8 > 0 then
						p_u_5._soundQueue[v10] = nil
						v11:Destroy()
						v8 = v8 - 1
					elseif v11.State == "Destroying" then
						p_u_5._soundQueue[v10] = nil
					else
						if v11.State == "Active" then
							if v11.Sustained or p_u_5._keyDownLookup[v11.Note] then
								v11.Lifetime = v11.Lifetime + p6
								if v11.Lifetime >= v11.MaxLifetime then
									v11:Fade()
								end
							else
								v11:Fade()
							end
						end
						if v9 ~= v10 then
							p_u_5._soundQueue[v9] = v11
							p_u_5._soundQueue[v10] = nil
						end
						v9 = v9 + 1
					end
				end
			end
		end)
	end
end
function v1._stopSoundQueue(p12)
	if p12._activeQueue then
		p12._activeQueue:Disconnect()
		p12._activeQueue = nil
	end
	for _, v13 in p12._soundQueue do
		v13:Destroy()
	end
	table.clear(p12._soundQueue)
end
local v_u_14 = { require(script.Fonts.PianoFont), require(script.Fonts.TrumpetFont), require(script.Fonts.DrumFont) }
local v_u_15 = {}
v_u_15.__index = v_u_15
function v_u_15.new(p16, p17, p18)
	-- upvalues: (copy) v_u_14, (copy) v_u_2, (copy) v_u_15, (copy) v_u_3
	local v19 = v_u_14[p17]
	local v20 = v19.CustomFunction(p16)
	local v21 = v_u_2:GetSound()
	v21.SoundGroup = game.SoundService.Effect
	v21.Volume = 5 * v19.VolumeModifier
	v21.SoundId = "rbxassetid://" .. v19.AssetIds[v20.asset]
	v21.TimePosition = v20.timePosition + (v19.Offset or 0.04)
	v21.Pitch = v20.pitch
	v21.Parent = script.Parent
	local v22 = {}
	local v23 = v_u_15
	setmetatable(v22, v23)
	v22.Source = script.Parent
	v22.Sustained = p18
	v22.Sound = v21
	v22.Note = p16
	v22.State = "Inactive"
	v22.Lifetime = 0
	v22.MaxLifetime = v19.MaxLifetime
	v22.Tween = v_u_3.new(v21, TweenInfo.new(v19.Fadeout), {
		["Volume"] = 0
	})
	return v22
end
function v_u_15.Play(p24)
	if p24.State == "Inactive" then
		p24.State = "Active"
		p24.Sound:Play()
	end
end
function v_u_15.Fade(p_u_25)
	if p_u_25.State == "Active" then
		p_u_25.State = "Fading"
		task.spawn(function()
			-- upvalues: (copy) p_u_25
			p_u_25.Tween:Play()
			p_u_25.Tween.Completed:Wait()
			if p_u_25.State ~= "Destroying" then
				p_u_25:Destroy()
			end
		end)
	end
end
function v_u_15.Destroy(p26)
	-- upvalues: (copy) v_u_2
	if p26.State ~= "Destroying" then
		p26.State = "Destroying"
		p26.Sound:Stop()
		p26.Tween:Cancel()
		p26.Tween:Destroy()
		v_u_2:ReturnSound(p26.Sound)
	end
end
function v1.PlayNote(p27, p28, p29, p30)
	-- upvalues: (copy) v_u_15
	local v31 = p30 == nil and true or p30
	local v32 = v_u_15.new(p28, p29, v31)
	v32:Play()
	p27._keyDownLookup[p28] = true
	local v33 = p27._soundQueue
	table.insert(v33, v32)
	if not p27._activeQueue then
		p27:_startSoundQueue()
	end
	return v32
end
function v1.StopNote(p34, p35)
	p34._keyDownLookup[p35] = nil
end
return v1