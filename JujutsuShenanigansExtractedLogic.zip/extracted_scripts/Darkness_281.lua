-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 10,
	["Desc"] = "OLED"
}
local v_u_2 = game:GetService("TweenService")
function v1.Callback(p3)
	-- upvalues: (copy) v_u_2
	if p3 == true and _G.LocalSettings.Goodnight == true then
		_G.LocalSettings.Goodnight = false
		_G.SettingUpdate.Goodnight:Fire()
	end
	if p3 == true and _G.LocalSettings.Sunset == true then
		_G.LocalSettings.Sunset = false
		_G.SettingUpdate.Sunset:Fire()
	end
	if p3 == true and _G.LocalSettings.Jolly == true then
		_G.LocalSettings.Jolly = false
		_G.SettingUpdate.Jolly:Fire()
	end
	if p3 == true then
		v_u_2:Create(game.Lighting, TweenInfo.new(0.5), {
			["ClockTime"] = 0,
			["Ambient"] = Color3.fromRGB(0, 0, 0),
			["OutdoorAmbient"] = Color3.fromRGB(0, 0, 0),
			["FogColor"] = Color3.fromRGB(0, 0, 0),
			["EnvironmentDiffuseScale"] = 0,
			["FogEnd"] = 50,
			["Brightness"] = 0
		}):Play()
	else
		v_u_2:Create(game.Lighting, TweenInfo.new(0.5), {
			["ClockTime"] = 14.5,
			["Ambient"] = Color3.new(1, 1, 1),
			["OutdoorAmbient"] = Color3.new(1, 1, 1),
			["FogColor"] = Color3.new(1, 1, 1),
			["Brightness"] = 1,
			["FogEnd"] = 100000
		}):Play()
	end
end
return v1