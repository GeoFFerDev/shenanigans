-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "SupernovaController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (ref) v_u_9
	local v_u_38 = {
		["Start"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_7.Itadori.ManjiKick.Dodge, v14, game.SoundService.Effect)
			end
		end,
		["Throw"] = function(p15)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_11:PlaySound(v_u_7.Itadori.DivergentFist.Swing, v16, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p17, p18)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			p17:FindFirstChild("HumanoidRootPart")
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			v_u_11:Flash(p18, Color3.new(1, 0, 0))
			v_u_11:PlaySound(v_u_7.Itadori.CursedStrikes.Hit, v19, game.SoundService.Effect)
			if v_u_4.Character == p17 or v_u_4.Character == p18 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Burst"] = function(p20)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			v_u_11:PlaySound(v_u_7.Choso.BloodBurst2, p20, game.SoundService.Effect)
			local v21 = v_u_6.Choso.BloodExplode:Clone()
			v21.Position = p20.Position
			v21.Parent = workspace.Effects
			v21.Blood:Emit(30)
			v21.Burst:Emit(1)
			v21.Wind:Emit(6)
			v_u_2:AddItem(v21, 2)
		end,
		["CounterHit"] = function(p22, p23)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v24 = p22:FindFirstChild("HumanoidRootPart")
			if v24 then
				v_u_11:PlaySound(v_u_7.Choso.Counter, v24, game.SoundService.Effect)
				v_u_11:ArmFlash(p22["Right Arm"], Color3.fromRGB(170, 0, 0), 0.9)
				local v25 = v_u_6.Choso.CounterHit:Clone()
				v25.Parent = v24.RootAttachment
				v25:Emit(1)
				v_u_2:AddItem(v25, 0.2)
				local v26 = v_u_6.Itadori.DivergentFist.BlackFlashHit.Wind2:Clone()
				v26.Parent = v24.RootAttachment
				v26:Emit(7)
				v_u_2:AddItem(v26, 0.1)
				if v_u_4.Character == p22 or v_u_4.Character == p23 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["Hit1"] = function(p27, p28)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			p27:FindFirstChild("HumanoidRootPart")
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			v_u_11:Flash(p28, Color3.new(1, 0, 0))
			v_u_11:PlaySound(v_u_7.Mahito.Chainwhip.Hit, v29, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, v29, game.SoundService.Effect)
			task.wait(0.2)
			v_u_11:PlaySound(v_u_7.Mahito.Stockpile.Swing, v29, game.SoundService.Effect)
		end,
		["Hit2"] = function(p30, p31)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v32 = p30:FindFirstChild("HumanoidRootPart")
			local v_u_33 = p31:FindFirstChild("HumanoidRootPart")
			v_u_11:Flash(p31, Color3.new(1, 1, 1))
			v_u_11:PlaySound(v_u_7.Hakari.EnergySurge.Hit2, v_u_33, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_7.Choso.BloodBurst, v_u_33, game.SoundService.Effect)
			if v_u_4.Character == p30 or v_u_4.Character == p31 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
			for v34 = 1, 4 do
				task.delay(0.1 * v34, function()
					-- upvalues: (ref) v_u_6, (copy) v_u_33, (ref) v_u_3, (ref) v_u_2
					local v35 = v_u_6.Itadori.Shock:Clone()
					v35.CFrame = CFrame.lookAlong(v_u_33.Position, v_u_33.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
					v35.Parent = workspace.Effects
					v_u_3:Create(v35, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(10, 0, 10),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v35, 0.15)
				end)
			end
			local v36 = v_u_6.Choso.CounterSwing:Clone()
			v36:PivotTo(v32.CFrame * CFrame.new(2, 1, -4))
			v36.Parent = workspace.Effects
			v_u_2:AddItem(v36, 0.3)
			v_u_3:Create(v36.Shock, TweenInfo.new(0.15), {
				["Size"] = Vector3.new(0, 25, 0),
				["Transparency"] = 1
			}):Play()
			v_u_3:Create(v36.Shock2, TweenInfo.new(0.1), {
				["Size"] = Vector3.new(8, 0, 8),
				["Transparency"] = 1,
				["Position"] = v36.Shock2.Position + v32.CFrame.LookVector * 3
			}):Play()
			v_u_3:Create(v36.Shockwave, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(0, 30, 0),
				["Transparency"] = 1,
				["CFrame"] = v36.Shockwave.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
			}):Play()
		end,
		["Finisher"] = function(p37)
			-- upvalues: (ref) v_u_11
			if p37:FindFirstChild("HumanoidRootPart") then
				v_u_11:Bleed(p37)
			end
		end
	}
	v_u_9.Effects:Connect(function(p39, ...)
		-- upvalues: (copy) v_u_38
		local v40 = v_u_38[p39]
		if v40 then
			v40(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("SupernovaService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12