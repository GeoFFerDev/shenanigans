-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("TweenService")
local v3 = require(game.ReplicatedStorage.Modules.FastCastRedux)
local v_u_4 = Random.new()
local v_u_5 = TweenInfo.new(0.3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
local _ = game.Players.LocalPlayer
local v_u_6 = v3.newBehavior()
v_u_6.MaxDistance = 150
local v7 = -workspace.Gravity
v_u_6.Acceleration = Vector3.new(0, v7, 0)
v_u_6.CosmeticBulletTemplate = script.BloodFly
v_u_6.CosmeticBulletContainer = workspace.Effects.Blood.Particle
v_u_6.AutoIgnoreContainer = false
v_u_6.RaycastParams = RaycastParams.new()
v_u_6.RaycastParams.FilterType = Enum.RaycastFilterType.Include
v_u_6.RaycastParams.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_8 = CFrame.Angles(-1.5707963267948966, 0, 0)
local v_u_9 = {}
local v10 = script.PoolActor
table.insert(v_u_9, v10)
local v11 = script.PoolActor:Clone()
table.insert(v_u_9, v11)
local v12 = script.PoolActor:Clone()
table.insert(v_u_9, v12)
local v_u_13 = {}
for _, v14 in v_u_9 do
	v14.Parent = workspace.Effects.Blood
end
v_u_13.PermBlood = false
v_u_6.HighFidelityBehavior = 3
game:GetService("RunService").RenderStepped:Connect(function()
	-- upvalues: (copy) v_u_9
	for _, v15 in workspace.Effects.Blood:GetChildren() do
		if v15:IsA("BasePart") and v15.Locked ~= true then
			local v16 = v15.Ref.Value
			if v16 and (v16.Parent and (v16.Position - v15.Position).Magnitude <= 100000) then
				v15.CFrame = v16.CFrame:ToWorldSpace(v15:GetAttribute("CF"))
			else
				v15.Locked = true
				v_u_9[math.random(1, #v_u_9)]:SendMessage("Ray", v15)
			end
		end
	end
end)
local v_u_17 = v3.new()
v_u_17.RayHit:Connect(function(_, p18, _, _)
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_2, (copy) v_u_5, (copy) v_u_13, (copy) v_u_1
	local v19 = p18.Instance
	local v20 = v_u_4:NextInteger(5, 20) / 10
	local v21 = math.random(0, 3.141592653589793)
	local v22 = CFrame.lookAlong(p18.Position + p18.Normal * 0.1, p18.Normal) * v_u_8 * CFrame.Angles(0, v21, 0)
	local v23 = script.Pool:Clone()
	v23.CFrame = v22
	v23:SetAttribute("CF", v19.CFrame:ToObjectSpace(v22))
	v23:SetAttribute("RT", v21)
	v23.Ref.Value = v19
	v23.Parent = workspace.Effects.Blood
	v_u_2:Create(v23, v_u_5, {
		["Size"] = Vector3.new(v20, 0, v20)
	}):Play()
	if not v_u_13.PermBlood then
		v_u_1:AddItem(v23, 8)
	end
end)
v_u_17.LengthChanged:Connect(function(_, p24, p25, p26, _, p27)
	if p27 then
		p27.Position = p24 + p25 * p26
	end
end)
v_u_17.CastTerminating:Connect(function(p28)
	-- upvalues: (copy) v_u_1
	local v29 = p28.RayInfo.CosmeticBulletObject
	if v29 then
		v29.Trail.Enabled = false
		v_u_1:AddItem(v29, 0.15)
	end
end)
function v_u_13.Blood(_, p30, p31, p32, p33)
	-- upvalues: (copy) v_u_13, (copy) v_u_4, (copy) v_u_17, (copy) v_u_6
	if _G.Settings.Gore == true and (v_u_13.PermBlood or (workspace.CurrentCamera.CFrame.Position - p30.Position).Magnitude <= 150) then
		local v34 = v_u_4:NextInteger(-p32, p32)
		local v35 = math.rad(v34)
		local v36 = v_u_4:NextInteger(-p33, p33)
		local v37 = math.rad(v36)
		local v38 = (p30 * CFrame.Angles(v35, v37, 0)).LookVector
		v_u_17:Fire(p30.Position, v38, p31, v_u_6)
	end
end
return v_u_13