-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 3,
	["Desc"] = "When you just need that little nap"
}
local v_u_2 = game:GetService("TweenService")
function v1.Callback(p3)
	-- upvalues: (copy) v_u_2
	if p3 == true and _G.LocalSettings.Sunset == true then
		_G.LocalSettings.Sunset = false
		_G.SettingUpdate.Sunset:Fire()
	end
	if p3 == true and _G.LocalSettings.Darkness == true then
		_G.LocalSettings.Darkness = false
		_G.SettingUpdate.Darkness:Fire()
	end
	if p3 == true then
		v_u_2:Create(game.Lighting, TweenInfo.new(0.5), {
			["ClockTime"] = 0,
			["Ambient"] = Color3.new(0, 0, 0),
			["OutdoorAmbient"] = Color3.fromRGB(40, 50, 75),
			["FogColor"] = Color3.new(0, 0, 0),
			["EnvironmentDiffuseScale"] = 0
		}):Play()
	else
		v_u_2:Create(game.Lighting, TweenInfo.new(0.5), {
			["ClockTime"] = 14.5,
			["Ambient"] = Color3.new(1, 1, 1),
			["OutdoorAmbient"] = Color3.new(1, 1, 1),
			["FogColor"] = Color3.new(1, 1, 1),
			["EnvironmentDiffuseScale"] = 1
		}):Play()
	end
end
return v1