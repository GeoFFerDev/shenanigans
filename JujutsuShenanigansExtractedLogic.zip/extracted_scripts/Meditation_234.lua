-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_3 = game.Players.LocalPlayer
function v1.Start(_, p_u_4, p5)
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	if p_u_4.Character then
		local v_u_6 = script.Scene:Clone()
		v_u_6.Parent = workspace.Effects
		table.insert(p5, v_u_6)
		task.spawn(function()
			-- upvalues: (copy) p_u_4, (copy) v_u_6
			local v7
			if p_u_4.Character then
				v7 = p_u_4.Character.Humanoid:GetAppliedDescription()
			else
				v7 = game.Players:GetHumanoidDescriptionFromUserId(p_u_4.UserId)
			end
			v_u_6.Rig.Humanoid:ApplyDescriptionReset(v7)
		end)
		local v8 = script["birds-chirping"]:Clone()
		v8.SoundGroup = game.SoundService.Effect
		v8.Parent = workspace
		table.insert(p5, v8)
		local v9 = script.waterfall3_looped:Clone()
		v9.SoundGroup = game.SoundService.Effect
		v9.Parent = workspace
		table.insert(p5, v9)
		local v10 = script["Clap Todo"]:Clone()
		v10.SoundGroup = game.SoundService.Effect
		v10.Parent = workspace
		table.insert(p5, v10)
		local v11 = {}
		for _, v12 in pairs(v_u_6:GetChildren()) do
			local v13 = v12.Name
			if string.sub(v13, 1, 9) == "Butterfly" then
				local v_u_14 = v12.AnimationController:LoadAnimation(v12.Animation)
				v_u_14.Looped = false
				v_u_14:Play(0, nil, 0)
				v_u_14.Stopped:Connect(function()
					-- upvalues: (copy) v_u_14
					v_u_14:Play(0, nil, 0)
					v_u_14.TimePosition = v_u_14.Length
				end)
				table.insert(v11, v_u_14)
			end
		end
		local v15 = v_u_6.Rig.Humanoid:LoadAnimation(script.Character)
		local v16 = v_u_6.Camera.AnimationController.Animator:LoadAnimation(script.Camera)
		v15:Play(0, nil, 0)
		table.insert(p5, v15)
		v16:Play(0, nil, 0)
		table.insert(p5, v16)
		v15.Looped = false
		v16.Looped = false
		task.wait(2.5)
		local v17 = Instance.new("DepthOfFieldEffect", game.Lighting)
		v17.FarIntensity = 0.5
		v17.InFocusRadius = 20
		v17.NearIntensity = 0.75
		v17.FocusDistance = 0.05
		table.insert(p5, v17)
		game.Lighting.ColorShift_Bottom = Color3.fromRGB(0, 48, 255)
		game.Lighting.ColorShift_Top = Color3.fromRGB(253, 255, 159)
		game.Lighting.Ambient = Color3.fromRGB(20, 192, 255)
		game.Lighting.Brightness = 5
		table.insert(p5, function()
			game.Lighting.ColorShift_Bottom = Color3.fromRGB(0, 0, 0)
			game.Lighting.ColorShift_Top = Color3.fromRGB(0, 0, 0)
			game.Lighting.Ambient = Color3.fromRGB(255, 255, 255)
			game.Lighting.Brightness = 1
		end)
		v_u_3.PlayerGui.Main.Enabled = false
		local v_u_18 = workspace.CurrentCamera
		v_u_18.FieldOfView = 30
		v_u_18.CameraType = Enum.CameraType.Scriptable
		local v19 = v_u_2.RenderStepped
		table.insert(p5, v19:Connect(function()
			-- upvalues: (copy) v_u_18, (copy) v_u_6
			v_u_18.CFrame = v_u_6.Camera.camera.CFrame
		end))
		local v20 = tick() + 0.25
		repeat
			task.wait()
		until v15.Length > 0 and (v16.Length > 0 and (v8.IsLoaded and (v9.IsLoaded and v10.IsLoaded))) or v20 < tick()
		v15:AdjustSpeed(1)
		v16:AdjustSpeed(1)
		for _, v21 in pairs(v11) do
			v21:AdjustSpeed(1)
		end
		v8:Play()
		v9:Play()
		task.wait(2.15)
		v10:Play()
		task.wait(0.25)
		v15:AdjustSpeed(0)
		task.wait(2)
		v16:AdjustSpeed(0)
		task.wait(1.6)
		for _, v22 in pairs(v11) do
			v22:AdjustSpeed(0)
		end
		for _, v23 in v_u_6:GetDescendants() do
			if v23:IsA("Beam") then
				v23.TextureSpeed = 0
			elseif v23:IsA("ParticleEmitter") then
				v23.TimeScale = 0
			end
		end
	end
end
return v1