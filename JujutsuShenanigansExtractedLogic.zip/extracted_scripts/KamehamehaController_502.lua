-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v9 = v_u_1.CreateController({
	["Name"] = "KamehamehaController"
})
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = workspace.CurrentCamera
function v9.KnitStart(_)
	-- upvalues: (copy) v_u_4, (copy) v_u_12, (copy) v_u_6, (copy) v_u_3, (ref) v_u_10, (copy) v_u_7, (copy) v_u_8, (copy) v_u_2, (ref) v_u_11
	local v_u_59 = {
		["AutoRotate"] = function(p13, p14)
			-- upvalues: (ref) v_u_4, (ref) v_u_12
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				if p13 == v_u_4.Character then
					repeat
						task.wait()
						p14.CFrame = p14:GetAttribute("FinalPos") or CFrame.lookAlong(v15.Position, v_u_12.CFrame.LookVector, v_u_12.CFrame.UpVector)
					until not p14.Parent
				end
			end
		end,
		["StartCharge"] = function(p16)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				local v18 = v_u_6.Goku.Ball:Clone()
				v18.Parent = p16
				v18.Ball.Part0 = p16["Left Arm"]
				v18.Size = Vector3.new(0, 0, 0)
				v18.Attachment.Glow:Emit(1)
				v_u_3:Create(v18, TweenInfo.new(0.5), {
					["Size"] = Vector3.new(1, 1, 1)
				}):Play()
				v_u_10:PlaySound(v_u_7.Goku.Kamehameha.Use, v17, game.SoundService.Effect)
			end
		end,
		["ChargeStronger"] = function(p19)
			-- upvalues: (ref) v_u_3
			local v20 = p19:FindFirstChild("Ball")
			if v20 then
				v20.Attachment.Charge.Enabled = true
				v_u_3:Create(v20, TweenInfo.new(0.5), {
					["Size"] = Vector3.new(2, 2, 2)
				}):Play()
			end
		end,
		["Shoot"] = function(p21, p22)
			-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_8, (ref) v_u_3
			local v23 = p21:FindFirstChild("Ball")
			if not v23 then
				return
			end
			local v24 = p21:FindFirstChild("HumanoidRootPart")
			if not v24 then
				return
			end
			v23:Destroy()
			local v25 = v_u_6.Goku.Kamehameha:Clone()
			v25.Parent = workspace.Effects
			v25.Ball1.CFrame = p22
			v25.Ball2.CFrame = p22
			v25.Shaft.Size = Vector3.new(0, 2, 2)
			local v26 = RaycastParams.new()
			v26.FilterType = Enum.RaycastFilterType.Exclude
			v26.FilterDescendantsInstances = { workspace.Characters, workspace.Map.Data }
			local v27 = tick()
			while true do
				task.wait()
				local v28 = (v24.CFrame * CFrame.new(0, 0, -5)).Position
				v25.Ball1.Position = v28
				local v29 = workspace:Raycast(v28, p22.LookVector * 50, v26)
				local v30 = p22 * CFrame.new(0, 0, -50).Position
				if v29 then
					v30 = v29.Position
				end
				local v31 = 1 + math.random() / 2
				local v32 = Vector3.new(1, 1, 1) * v31 * 1.5
				local v33 = Vector3.new(1, v31, v31)
				v25.Ball1.Position = v28
				v25.Ball2.Position = v25.Ball2.Position:Lerp(v30, 0.3)
				v25.Ball1.Size = Vector3.new(4, 4, 4) * v32
				v25.Ball2.Size = Vector3.new(3, 3, 3) * v32
				local v34 = v25.Shaft
				local v35 = v25.Shaft.Size
				local v36 = (v28 - v30).Magnitude
				v34.Size = v35:Lerp(Vector3.new(v36, 2, 2), 0.3) * v33
				v25.Shaft.CFrame = CFrame.lookAt((v28 + v25.Ball2.Position) / 2, v30) * CFrame.Angles(0, 1.5707963267948966, 0)
				if p21 == v_u_4.Character then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightLoop)
				end
				if tick() - v27 > 0.5 then
					local v37 = v_u_3
					local v38 = v25.Shaft
					local v39 = TweenInfo.new(0.3)
					local v40 = {}
					local v41 = v25.Shaft.Size.X
					v40.Size = Vector3.new(v41, 0, 0)
					v37:Create(v38, v39, v40):Play()
					v_u_3:Create(v25.Ball1, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_3:Create(v25.Ball2, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					task.wait(0.3)
					v25:Destroy()
					return
				end
			end
		end,
		["RemoveCharges"] = function(p42)
			local v43 = p42:FindFirstChild("HumanoidRootPart")
			if v43 then
				local v44 = p42:FindFirstChild("Ball")
				if v44 then
					if v43:FindFirstChild("Kamehameha") then
						v43:FindFirstChild("Kamehameha"):Destroy()
					end
					v44:Destroy()
				end
			else
				return
			end
		end,
		["Hit"] = function(p45)
			-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			if p45:GetAttribute("KamehamehaFinished") then
				return
			else
				local v46 = p45:FindFirstChild("HumanoidRootPart")
				if v46 then
					if p45:GetAttribute("Dead") then
						p45:SetAttribute("KamehamehaFinished", true)
						for _, v47 in p45:GetDescendants() do
							if v47:IsA("BasePart") or v47:IsA("Decal") then
								v47.Transparency = 1
							end
						end
						for _ = 1, 10 do
							local v48 = Instance.new("Part")
							v48.Color = Color3.fromRGB(13, 105, 172)
							v48.Material = Enum.Material.Neon
							v48.Anchored = true
							v48.CanCollide = false
							v48.Position = v46.Position
							v48.Parent = workspace.Effects
							v_u_2:AddItem(v48, 2)
							local v49 = v_u_3
							local v50 = TweenInfo.new(math.random(0.5, 2), Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
							local v51 = {}
							local v52 = v48.Position
							local v53 = math.random(-5, 5)
							local v54 = math.random(1, 6)
							local v55 = math.random
							v51.Position = v52 + Vector3.new(v53, v54, v55(-5, 5))
							local v56 = math.random(-180, 180)
							local v57 = math.random(-180, 180)
							local v58 = math.random
							v51.Orientation = Vector3.new(v56, v57, v58(-180, 180))
							v51.Size = Vector3.new(0, 0, 0)
							v49:Create(v48, v50, v51):Play()
							v_u_10:PlaySound(v_u_7.Goku.Kamehameha.Finisher, v46, game.SoundService.Effect)
						end
					else
						v_u_10:Flash(p45, Color3.fromRGB(13, 105, 172))
					end
				else
					return
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p60, ...)
		-- upvalues: (copy) v_u_59
		local v61 = v_u_59[p60]
		if v61 then
			v61(...)
		end
	end)
end
function v9.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_10
	v_u_11 = v_u_1.GetService("KamehamehaService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v9