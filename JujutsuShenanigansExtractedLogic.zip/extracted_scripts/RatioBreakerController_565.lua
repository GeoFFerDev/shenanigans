-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
require(v_u_6.Modules.BloodyZee)
local v_u_10 = require(v_u_6.Modules.SraikoVFX)
local v_u_11 = require(v_u_6.Modules.LightningBeams)
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Include
v_u_12.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_13 = Random.new()
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v17 = v_u_1.CreateController({
	["Name"] = "RatioBreakerController"
})
local v_u_18 = {
	"rbxassetid://74285508054294",
	"rbxassetid://99132465087026",
	"rbxassetid://114891301322696",
	"rbxassetid://85813887517647",
	"rbxassetid://76321503224643",
	"rbxassetid://78626248888940",
	"rbxassetid://115760318978716",
	"rbxassetid://103659957620708",
	"rbxassetid://129941782677974",
	"rbxassetid://72590467800262",
	"rbxassetid://115486948939199",
	"rbxassetid://120088088651914",
	"rbxassetid://76659571940765",
	"rbxassetid://135487679567493",
	"rbxassetid://105922249024859",
	"rbxassetid://127194758766478"
}
function v17.KnitStart(_)
	-- upvalues: (copy) v_u_18, (ref) v_u_15, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_12, (copy) v_u_10, (copy) v_u_13, (copy) v_u_11, (copy) v_u_5, (copy) v_u_9, (copy) v_u_6, (copy) v_u_2, (ref) v_u_14
	local v19 = {}
	for _, v20 in pairs(v_u_18) do
		table.insert(v19, v20)
	end
	game.ContentProvider:PreloadAsync(v19)
	local v_u_198 = {
		["Start"] = function(p21, p22, p23)
			-- upvalues: (ref) v_u_15, (ref) v_u_8
			local v24 = p21:FindFirstChild("HumanoidRootPart")
			if v24 then
				local v_u_25
				if p23 == 1 then
					v_u_25 = v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB1.Whoosh, v24, game.SoundService.Effect)
				else
					if p23 == 2 then
						v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB2.Whoosh, v24, game.SoundService.Effect)
						return
					end
					if p23 ~= 4 then
						return
					end
					v_u_25 = v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB4.Start, v24, game.SoundService.Effect)
				end
				p22.AncestryChanged:Once(function()
					-- upvalues: (ref) v_u_25
					if v_u_25 then
						v_u_25:Destroy()
					end
				end)
			end
		end,
		["Slash"] = function(p26)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v28 = v_u_7.Nanami.RatioBreaker.Attack1.SlashEmit:Clone()
				v28.Weld.Part0 = v27
				v28.Parent = workspace.Effects
				for _, v29 in pairs(v28:GetDescendants()) do
					if v29:IsA("ParticleEmitter") then
						v29:Emit(v29:GetAttribute("EmitCount"))
					end
				end
				v_u_3:AddItem(v28, 1.5)
				local v30 = v_u_7.Nanami.RatioBreaker.Attack1.SlashBeam:Clone()
				v30.Weld.Part0 = v27
				v30.Parent = workspace.Effects
				v_u_3:AddItem(v30, 1.5)
				for _, v31 in pairs(v30:GetDescendants()) do
					if v31:IsA("Beam") then
						v31.Enabled = true
					end
				end
				for _, v_u_32 in pairs(v30:GetDescendants()) do
					if v_u_32:IsA("Beam") then
						v_u_4:Create(v_u_32, TweenInfo.new(0.19), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
						task.delay(0.29000000000000004, function()
							-- upvalues: (copy) v_u_32
							v_u_32.Enabled = false
							v_u_32.Width0 = 17
							v_u_32.Width1 = 17
						end)
					end
				end
			end
		end,
		["SlashHit"] = function(p33, p34)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_15, (ref) v_u_8
			local v35 = p33:FindFirstChild("HumanoidRootPart")
			if v35 then
				local v36 = p34:FindFirstChild("HumanoidRootPart")
				if v36 then
					local v37 = v_u_7.Nanami.RatioBreaker.Attack1.SlashHit:Clone()
					v37.Parent = v36
					local v38 = CFrame.lookAt
					local v39 = v36.Position
					local v40 = v35.Position.X
					local v41 = v36.Position.Y
					local v42 = v35.Position.Z
					v37.WorldCFrame = v38(v39, (Vector3.new(v40, v41, v42)))
					for _, v43 in pairs(v37:GetDescendants()) do
						if v43:IsA("ParticleEmitter") then
							v43:Emit(v43:GetAttribute("EmitCount"))
						end
					end
					v_u_3:AddItem(v37, 1)
					v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB1.SlashHit, v35, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["WindCharge"] = function(p44)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_10, (ref) v_u_3
			local v45 = p44:FindFirstChild("HumanoidRootPart")
			if v45 then
				local v46 = workspace:Raycast(v45.Position, Vector3.new(-0, -7.5, -0), v_u_12)
				if v46 then
					for _, v47 in pairs(v_u_7.Nanami.BluntCut.Charge:GetChildren()) do
						if v47:IsA("Model") then
							local v48 = v47:Clone()
							local v49 = v_u_10.HandleMesh(v48, CFrame.new(v46.Position, v46.Position + v46.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
							v48.Parent = workspace.Effects
							v_u_3:AddItem(v48, v49)
						end
					end
				end
			end
		end,
		["ArmEmit"] = function(p50)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_15, (ref) v_u_8
			local v51 = p50:FindFirstChild("HumanoidRootPart")
			if v51 then
				v_u_10.Emit(v_u_7.Nanami.RatioBreaker.Attack1.ArmEmit, v51.CFrame)
				v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB1.Charge, v51, game.SoundService.Effect)
			end
		end,
		["Whoosh1"] = function(p52)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_10
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				local v54 = v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.BlackFlash:Clone()
				v54.CFrame = v53.CFrame * CFrame.new(0, 0, -8)
				v54.Parent = workspace.Effects
				v_u_3:AddItem(v54, 4)
				for _, v55 in pairs(v54.Black:GetDescendants()) do
					if v55:IsA("ParticleEmitter") and v55:GetAttribute("Whiff") then
						v55:Emit(v55:GetAttribute("EmitCount"))
					end
				end
				for _, v56 in pairs(v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.Meshes:GetChildren()) do
					if v56:IsA("Model") then
						local v57 = v56:Clone()
						local v58 = v_u_10.HandleMesh(v57, v53.CFrame * CFrame.new(0, 0, -6) * CFrame.Angles(0.2617993877991494, 0, 0))
						v57.Parent = workspace.Effects
						v_u_3:AddItem(v57, v58)
					end
				end
			end
		end,
		["BlackFlashHit"] = function(p59, p_u_60, p61)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_3, (ref) v_u_15, (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_11, (ref) v_u_5, (ref) v_u_9
			local v62 = p59:FindFirstChild("HumanoidRootPart")
			if v62 then
				local v_u_63 = p_u_60:FindFirstChild("HumanoidRootPart")
				if v_u_63 then
					local v64 = workspace:Raycast(v62.Position, CFrame.lookAt(v62.Position, v_u_63.Position).LookVector * 11, v_u_12)
					local v65 = v64 and v64.Distance or 11
					local v66 = v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.BlackFlash:Clone()
					v66.Position = (CFrame.lookAt(v62.Position, v_u_63.Position) * CFrame.new(0, 0, -v65)).Position
					v66.Parent = workspace.Effects
					v_u_3:AddItem(v66, 2)
					for _, v67 in pairs(v66:GetDescendants()) do
						if v67:IsA("ParticleEmitter") and not v67:GetAttribute("Whiff") then
							v67:Emit(v67:GetAttribute("EmitCount"))
						end
					end
					local v_u_68 = v_u_7.Itadori.DivergentFist.BlackFlashHit:Clone()
					v_u_68.Position = (CFrame.lookAt(v62.Position, v_u_63.Position) * CFrame.new(0, 0, -v65)).Position
					v_u_68.Parent = workspace.Effects
					v_u_3:AddItem(v_u_68, 2)
					v_u_15:Flash(p_u_60, Color3.new(1, 0, 0))
					v_u_15:PlaySound(p61 == 1 and v_u_8.Nanami.RatioBreaker.RB1.Hit or v_u_8.Nanami.RatioBreaker.RB2.Hit, v62, game.SoundService.Effect)
					v_u_4:Create(v_u_68.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_68
						v_u_68.Blast:Emit(8)
						v_u_68.Sparks:Emit(15)
						v_u_68.Lightning:Emit(6)
						v_u_68.Wind:Emit(7)
					end)
					task.spawn(function()
						-- upvalues: (copy) p_u_60, (copy) v_u_63, (ref) v_u_13, (ref) v_u_12, (ref) v_u_11
						local v69 = Instance.new("Model", workspace.Effects)
						local v70 = Instance.new("Highlight", v69)
						v70.DepthMode = Enum.HighlightDepthMode.Occluded
						v70.OutlineColor = Color3.new(1, 0, 0)
						v70.FillColor = Color3.new(0, 0, 0)
						v70.FillTransparency = 0
						local v71 = p_u_60.Torso.BodyBackAttachment
						local v72 = tick()
						while true do
							local v73 = Instance.new("Attachment", v_u_63)
							local v74 = workspace:Raycast(v_u_63.Position, v_u_13:NextUnitVector() * 30, v_u_12)
							if v74 then
								v73.Position = v74.Position
							else
								v73.Position = v_u_13:NextUnitVector() * 30
							end
							local v_u_75 = v_u_11.new(v71, v73, nil, v69)
							v_u_75.Color = Color3.new(1, 0, 0)
							v_u_75.PulseSpeed = 300
							v_u_75.FadeLength = 0.35
							v_u_75.MaxRadius = 20
							v_u_75.MinRadius = 0
							v_u_75.AnimationSpeed = 75
							v_u_75.MinThicknessMultiplier = 0.1
							v_u_75.MaxThicknessMultiplier = 3
							task.delay(0.15, function()
								-- upvalues: (copy) v_u_75
								v_u_75:Destroy()
							end)
							task.wait(0.02)
							if tick() - v72 > 0.15 then
								return
							end
						end
					end)
					if v_u_5.Character == p59 or v_u_5.Character == p_u_60 then
						v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1.5)
						local v76 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v76.Parent = game.Lighting
						task.wait(0.04)
						v76.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v76.Brightness = 200
						v76.Contrast = -1000
						task.wait(0.04)
						v76:Destroy()
					end
				end
			else
				return
			end
		end,
		["ArmCharge"] = function(p77)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_10, (ref) v_u_3
			local v78 = p77:FindFirstChild("HumanoidRootPart")
			if v78 then
				local v79 = workspace:Raycast(v78.Position, Vector3.new(-0, -7.5, -0), v_u_12)
				if v79 then
					local v80 = v_u_7.Nanami.RatioBreaker.Attack2.NewSlash:Clone()
					local v81 = v_u_10.HandleMesh(v80, CFrame.new(v79.Position, v79.Position + v79.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
					v80.Parent = workspace.Effects
					v_u_3:AddItem(v80, v81)
				end
				v_u_10.Emit(v_u_7.Nanami.RatioBreaker.Attack2.ArmEmit, v78.CFrame)
			end
		end,
		["Whoosh2"] = function(p82)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_10, (ref) v_u_9
			local v83 = p82:FindFirstChild("HumanoidRootPart")
			if v83 then
				local v84 = v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.BlackFlash:Clone()
				v84.CFrame = v83.CFrame * CFrame.new(0, 0, -1.5)
				v84.Parent = workspace.Effects
				v_u_3:AddItem(v84, 4)
				for _, v85 in pairs(v84.Black:GetDescendants()) do
					if v85:IsA("ParticleEmitter") and v85:GetAttribute("Whiff") then
						v85:Emit(v85:GetAttribute("EmitCount"))
					end
				end
				for _, v86 in pairs(v_u_7.Nanami.RatioBreaker.Attack1.BlackFlash.Meshes:GetChildren()) do
					if v86:IsA("Model") then
						local v87 = v86:Clone()
						local v88 = v_u_10.HandleMesh(v87, v83.CFrame * CFrame.new(0, 0, -1) * CFrame.Angles(0.2617993877991494, 0, 0))
						v87.Parent = workspace.Effects
						v_u_3:AddItem(v87, v88)
					end
				end
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.MediumHit)
			end
		end,
		["Jump"] = function(p89)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_10, (ref) v_u_3, (ref) v_u_15, (ref) v_u_8, (ref) v_u_9
			local v90 = p89:FindFirstChild("HumanoidRootPart")
			if v90 then
				local v91 = workspace:Raycast(v90.Position, Vector3.new(-0, -7.5, -0), v_u_12)
				if v91 then
					for _, v92 in pairs(v_u_7.Nanami.RatioBreaker.Attack3.Jump.Meshes:GetChildren()) do
						local v93 = v92:Clone()
						local v94 = v_u_10.HandleMesh(v93, CFrame.new(v91.Position, v91.Position + v91.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
						v93.Parent = workspace.Effects
						v_u_3:AddItem(v93, v94)
					end
					v_u_10.Emit(v_u_7.Nanami.RatioBreaker.Attack3.Jump.Whoosh, v90.CFrame)
				end
				v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB3.Jump, v90, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v90.Position).Magnitude < 80 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["JumpHitbox"] = function(p95, p96, p97)
			-- upvalues: (ref) v_u_5, (ref) v_u_12
			local v98 = p95:FindFirstChild("HumanoidRootPart")
			if not v98 then
				return
			end
			if p95 == v_u_5.Character then
				while true do
					local v99 = workspace
					local v100 = (v98.CFrame * CFrame.new(0, 0, -2)).Position
					local v101 = p96.Velocity.Unit
					local v102 = p96.Velocity.Magnitude
					local v103 = v99:Raycast(v100, v101 * math.clamp(v102, 3, 10), v_u_12)
					if v103 then
						p97:FireServer(v103.Position, v103.Normal)
						p96:Destroy()
					end
					task.wait(0.025)
					if not p96.Parent then
						goto l4
					end
				end
			else
				::l4::
				return
			end
		end,
		["Slam"] = function(p104, p105, p106)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_15, (ref) v_u_8, (ref) v_u_10, (ref) v_u_9, (ref) v_u_5, (ref) v_u_13, (ref) v_u_12, (ref) v_u_11
			local v107 = p104:FindFirstChild("HumanoidRootPart")
			if not v107 then
				return
			end
			local v108 = v_u_7.Nanami.RatioBreaker.Attack3.Slam.Slam:Clone()
			local v109 = Instance.new("Model")
			v108.Parent = v109
			v109:ScaleTo(1.5)
			v_u_3:AddItem(v109, 0.1)
			v108:PivotTo(p105 * CFrame.Angles(-1.5707963267948966, 0, 0))
			v108.Parent = workspace.Effects
			v_u_3:AddItem(v108, 4)
			for _, v110 in pairs(v108.Black:GetDescendants()) do
				if v110:IsA("ParticleEmitter") and v110:GetAttribute("Whiff") then
					v110:Emit(v110:GetAttribute("EmitCount"))
				end
			end
			local v111 = v_u_7.Megumi.Mahoraga.Earthquake:Clone()
			v111.CFrame = p105 * CFrame.Angles(-1.5707963267948966, 0, 0)
			v111.Parent = workspace.Effects
			v111.Air:Destroy()
			v_u_4:Create(v111.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v_u_4:Create(v111.Floor.Ring2, TweenInfo.new(0.4), {
				["TimeScale"] = 0.5
			}):Play()
			v111.Floor.Ring2:Emit(10)
			v111.Floor.Wind2:Emit(15)
			v111.Floor.Dust:Emit(100)
			v_u_3:AddItem(v111, 3)
			local v112 = v_u_7.Megumi.Mahoraga.WorldSlash.mesh:Clone()
			v112.CFrame = p105 * CFrame.Angles(-1.5707963267948966, 0, 0)
			v112.Decal.Transparency = 0
			v112.Mesh.Scale = Vector3.new(2, 50, 2)
			v112.Parent = v111
			v_u_4:Create(v112, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Size"] = Vector3.new(80, 40, 80),
				["CFrame"] = v112.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
			}):Play()
			v_u_4:Create(v112.Mesh, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(60, 10, 60)
			}):Play()
			v_u_4:Create(v112.Decal, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v_u_3:AddItem(v112, 1)
			v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB3.Slam, v107, game.SoundService.Effect)
			for _, v113 in pairs(v_u_7.Nanami.RatioBreaker.Attack3.Slam.Meshes:GetChildren()) do
				local v114 = v113:Clone()
				local v115 = v_u_10.HandleMesh(v114, p105 * CFrame.Angles(-1.5707963267948966, 0, 0))
				v114.Parent = workspace.Effects
				v_u_3:AddItem(v114, v115)
			end
			if #p106 > 0 then
				if (workspace.CurrentCamera.CFrame.Position - p105.Position).Magnitude < 150 then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1.5)
				end
				v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB3.Hit, v107, game.SoundService.Effect)
				if v_u_5.Character == p104 then
					local v116 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
					v116.Parent = game.Lighting
					task.wait(0.04)
					v116.TintColor = Color3.new(1, 1, 1)
					task.wait(0.04)
					v116.Brightness = 200
					v116.Contrast = -1000
					task.wait(0.04)
					v116:Destroy()
				end
				for _, v117 in pairs(v108.Black:GetDescendants()) do
					if v117:IsA("ParticleEmitter") and not v117:GetAttribute("Whiff") then
						v117:Emit(v117:GetAttribute("EmitCount"))
					end
				end
				for _, v118 in pairs(p106) do
					if v118 == v_u_5.Character then
						v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1.5)
						local v119 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v119.Parent = game.Lighting
						task.wait(0.04)
						v119.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v119.Brightness = 200
						v119.Contrast = -1000
						task.wait(0.04)
						v119:Destroy()
					end
					local v120 = v118:FindFirstChild("HumanoidRootPart")
					local v_u_121 = v_u_7.Itadori.DivergentFist.BlackFlashHit:Clone()
					v_u_121.Position = v120.Position
					v_u_121.Parent = workspace.Effects
					v_u_3:AddItem(v_u_121, 2)
					v_u_15:Flash(v118, Color3.new(1, 0, 0))
					v_u_4:Create(v_u_121.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_121
						v_u_121.Blast:Emit(8)
						v_u_121.Sparks:Emit(15)
						v_u_121.Lightning:Emit(6)
						v_u_121.Wind:Emit(7)
					end)
				end
				local v122 = Instance.new("Model", workspace.Effects)
				local v123 = Instance.new("Highlight", v122)
				v123.DepthMode = Enum.HighlightDepthMode.Occluded
				v123.OutlineColor = Color3.new(1, 0, 0)
				v123.FillColor = Color3.new(0, 0, 0)
				v123.FillTransparency = 0
				local v124 = p104["Right Arm"].RightGripAttachment
				local v125 = tick()
				while true do
					if true then
						local v126 = Instance.new("Attachment", v107)
						local v127 = workspace:Raycast(v107.Position, (v_u_13:NextUnitVector() * Vector3.new(1, 0, 1)).Unit * 50, v_u_12)
						if v127 then
							v126.Position = v127.Position
						else
							v126.Position = (v_u_13:NextUnitVector() * Vector3.new(1, 0, 1)).Unit * 50
						end
					end
					local v_u_128 = v_u_11.new(v124, v126, nil, v122)
					v_u_128.Color = Color3.new(1, 0, 0)
					v_u_128.PulseSpeed = 300
					v_u_128.FadeLength = 0.35
					v_u_128.MaxRadius = 10
					v_u_128.MinRadius = 0
					v_u_128.AnimationSpeed = 75
					v_u_128.MinThicknessMultiplier = 0.1
					v_u_128.MaxThicknessMultiplier = 3
					task.delay(0.125, function()
						-- upvalues: (copy) v_u_128
						v_u_128:Destroy()
					end)
					task.wait(0.01)
					if tick() - v125 > 0.2 then
						::l31::
						return
					end
				end
			else
				if (workspace.CurrentCamera.CFrame.Position - p105.Position).Magnitude < 150 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
				goto l31
			end
		end,
		["ArmCharge2"] = function(p129)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_15, (ref) v_u_8
			local v130 = p129:FindFirstChild("HumanoidRootPart")
			if v130 then
				v_u_10.Emit(v_u_7.Nanami.RatioBreaker.Attack3.ArmEmit, v130, true)
				v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB3.Charge, v130, game.SoundService.Effect)
			end
		end,
		["RatioBreakerBlackFlash"] = function(p131, p_u_132, p133)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9, (ref) v_u_13, (ref) v_u_12, (ref) v_u_11
			local v_u_134 = p_u_132:FindFirstChild("HumanoidRootPart")
			if v_u_134 then
				local v135 = v_u_7.Nanami.RatioBreaker.Attack4.BlackFlash:Clone()
				local v136 = Instance.new("Model")
				v135.Parent = v136
				v136:ScaleTo(1.6)
				v_u_3:AddItem(v136, 0.1)
				v135.CFrame = CFrame.new(p133)
				v135.Parent = workspace.Effects
				v_u_3:AddItem(v135, 10)
				for _, v137 in pairs(v135:GetDescendants()) do
					if v137:IsA("ParticleEmitter") and not v137:GetAttribute("Whiff") then
						v137:Emit(v137:GetAttribute("EmitCount"))
					end
				end
				if v_u_5.Character == p131 or p_u_132 == v_u_5.Character then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
				task.spawn(function()
					-- upvalues: (copy) p_u_132, (copy) v_u_134, (ref) v_u_13, (ref) v_u_12, (ref) v_u_11
					local v138 = Instance.new("Model", workspace.Effects)
					local v139 = Instance.new("Highlight", v138)
					v139.DepthMode = Enum.HighlightDepthMode.Occluded
					v139.OutlineColor = Color3.new(1, 0, 0)
					v139.FillColor = Color3.new(0, 0, 0)
					v139.FillTransparency = 0
					local v140 = p_u_132.Torso.BodyBackAttachment
					local v141 = tick()
					while true do
						local v142 = Instance.new("Attachment", v_u_134)
						local v143 = workspace:Raycast(v_u_134.Position, v_u_13:NextUnitVector() * 30, v_u_12)
						if v143 then
							v142.Position = v143.Position
						else
							v142.Position = v_u_13:NextUnitVector() * 30
						end
						local v_u_144 = v_u_11.new(v140, v142, nil, v138)
						v_u_144.Color = Color3.new(1, 0, 0)
						v_u_144.PulseSpeed = 10
						v_u_144.FadeLength = 0.35
						v_u_144.MaxRadius = 20
						v_u_144.MinRadius = 0
						v_u_144.AnimationSpeed = 5
						v_u_144.MinThicknessMultiplier = 0.1
						v_u_144.MaxThicknessMultiplier = 2
						task.delay(0.1, function()
							-- upvalues: (copy) v_u_144
							v_u_144.AnimationSpeed = 0.5
							v_u_144.PulseSpeed = 5
						end)
						task.delay(1.4500000000000002, function()
							-- upvalues: (copy) v_u_144
							v_u_144.AnimationSpeed = 75
							v_u_144.PulseSpeed = 300
							task.delay(0.125, function()
								-- upvalues: (ref) v_u_144
								v_u_144:Destroy()
							end)
						end)
						task.wait(0.025)
						if tick() - v141 > 0.15 then
							return
						end
					end
				end)
				task.wait(0.1)
				for _, v145 in pairs(v135:GetDescendants()) do
					if v145:IsA("ParticleEmitter") then
						v145.TimeScale = 0.01
					end
				end
				task.wait(1.35)
				if (workspace.CurrentCamera.CFrame.Position - v_u_134.Position).Magnitude < 80 then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1.5)
				end
				for _, v146 in pairs(v135:GetDescendants()) do
					if v146:IsA("ParticleEmitter") then
						v146.TimeScale = 0.7
					end
				end
			end
		end,
		["Dash"] = function(p147, p_u_148, p_u_149, _)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_6, (ref) v_u_13, (ref) v_u_11, (ref) v_u_5, (ref) v_u_9, (ref) v_u_15, (ref) v_u_8
			local v_u_150 = p147:FindFirstChild("HumanoidRootPart")
			if v_u_150 then
				local v_u_151 = CFrame.new(p_u_148, p_u_149)
				local v152 = (p_u_148 - p_u_149).Magnitude
				local v153 = v_u_7.Mahito.Dash:Clone()
				v153.CFrame = v_u_151 + v_u_151.LookVector * v152 / 2
				v153.Size = Vector3.new(5, 5, v152)
				v153.Color = Color3.fromRGB(255, 0, 0)
				v153.Parent = workspace.Effects
				v_u_4:Create(v153, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 0, v152),
					["CFrame"] = v153.CFrame * CFrame.Angles(0, 0, 3.141592653589793)
				}):Play()
				v_u_3:AddItem(v153, 0.2)
				local v154 = Instance.new("Highlight", v153)
				v154.DepthMode = Enum.HighlightDepthMode.Occluded
				v154.OutlineColor = Color3.new(1, 0, 0)
				v154.FillColor = Color3.new(0, 0, 0)
				v154.FillTransparency = 0
				local v155 = Instance.new("Model")
				local v156 = v_u_6.Utils.Itadori.RushWind:Clone()
				v156.CFrame = v_u_150.CFrame * CFrame.new(0, -1, 0)
				v156.Parent = v155
				v155.Parent = workspace.Effects
				v155:ScaleTo(0.6)
				v156.Ring:Emit(7)
				v156.Dash1.Dash:Emit(1)
				v156.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v155, 2)
				local v157 = v_u_7.Itadori.Shock:Clone()
				v157.CFrame = v_u_151 * CFrame.Angles(1.5707963267948966, 0, 0)
				v157.Parent = workspace.Effects
				v_u_4:Create(v157, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(10, 0, 10),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v157, 0.3)
				task.delay(0.075, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_151, (ref) v_u_4, (ref) v_u_3, (copy) v_u_150
					local v158 = v_u_7.Itadori.Shock:Clone()
					v158.CFrame = v_u_151 * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_151.LookVector * 3
					v158.Parent = workspace.Effects
					v_u_4:Create(v158, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v158, 0.2)
					task.wait(0.075)
					local v159 = v_u_7.Itadori.Shock:Clone()
					v159.CFrame = v_u_150.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v159.Parent = workspace.Effects
					v_u_4:Create(v159, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v159, 0.2)
				end)
				local v_u_160 = Instance.new("Model", workspace.Effects)
				v_u_3:AddItem(v_u_160, 5)
				local v161 = Instance.new("Highlight", v_u_160)
				v161.DepthMode = Enum.HighlightDepthMode.Occluded
				v161.OutlineColor = Color3.new(1, 0, 0)
				v161.FillColor = Color3.new(0, 0, 0)
				v161.FillTransparency = 0
				tick()
				for _ = 1, 5 do
					task.spawn(function()
						-- upvalues: (copy) p_u_148, (ref) v_u_13, (copy) p_u_149, (ref) v_u_3, (ref) v_u_11, (copy) v_u_160
						local v162 = Instance.new("Attachment", workspace.Terrain)
						v162.WorldPosition = p_u_148 + v_u_13:NextUnitVector() * 5
						local v163 = Instance.new("Attachment", workspace.Terrain)
						v163.WorldPosition = p_u_149 + v_u_13:NextUnitVector() * 5
						v_u_3:AddItem(v162, 5)
						v_u_3:AddItem(v163, 5)
						local v164 = v_u_11.new(v163, v162, nil, v_u_160)
						v164.Color = Color3.new(1, 0, 0)
						v164.PulseSpeed = 5
						v164.FadeLength = 0.35
						v164.MaxRadius = 10
						v164.MinRadius = 0
						v164.AnimationSpeed = 1
						v164.MinThicknessMultiplier = 0.1
						v164.MaxThicknessMultiplier = 1.5
						task.wait(0.1)
						v164.PulseSpeed = 25
						v164.AnimationSpeed = 5
						for _ = 1, 12 do
							v164.Thickness = v164.Thickness * 0.85
							v164.PulseSpeed = v164.PulseSpeed * 0.85
							v164.MaxRadius = v164.MaxRadius * 0.85
							task.wait(0.020833333333333332)
						end
						v164:Destroy()
					end)
				end
				if p147 == v_u_5.Character then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1)
				end
				v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB4.Dash, v_u_150, game.SoundService.Effect)
			end
		end,
		["RatioBreakerHit"] = function(p_u_165, p166, _)
			-- upvalues: (ref) v_u_5, (ref) v_u_15, (ref) v_u_8, (ref) v_u_4, (ref) v_u_18, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2
			local v_u_167 = p_u_165:FindFirstChild("HumanoidRootPart")
			if v_u_167 then
				local v_u_168 = p166:FindFirstChild("HumanoidRootPart")
				if v_u_168 then
					if p_u_165 == v_u_5.Character or p166 == v_u_5.Character then
						v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB4.Hit, workspace, game.SoundService.Effect)
						local v_u_169 = workspace.CurrentCamera
						task.spawn(function()
							-- upvalues: (ref) v_u_5, (ref) v_u_4, (ref) v_u_18, (ref) v_u_9, (ref) v_u_7, (copy) v_u_168, (ref) v_u_3
							local v170 = Instance.new("ScreenGui")
							v170.IgnoreGuiInset = true
							v170.Parent = v_u_5.PlayerGui
							local v171 = Instance.new("Frame")
							v171.BackgroundTransparency = 0
							v171.BackgroundColor3 = Color3.new(0, 0, 0)
							v171.AnchorPoint = Vector2.new(0.5, 0.5)
							v171.Size = UDim2.fromScale(1, 1)
							v171.Position = UDim2.fromScale(0.5, 0.5)
							v171.Parent = v170
							local v172 = game.ReplicatedStorage.Utils.Nanami.Ratio.Bar:Clone()
							v172.Parent = v171
							local _ = v172.Cursor
							v172.Rotation = -140
							v172.Size = UDim2.fromScale(0.24, 3.5999999999999996)
							v_u_4:Create(v172, TweenInfo.new(0.35, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["Rotation"] = 80,
								["Size"] = UDim2.fromScale(0.16, 2.4),
								["Position"] = UDim2.fromScale(0.6, 0.45)
							}):Play()
							task.wait(0.2)
							v171.BackgroundColor3 = Color3.new(1, 1, 1)
							v172.Bar.ImageColor3 = Color3.new(0, 0, 0)
							v172.Cursor.Visible = false
							v172.Hit2.Visible = true
							task.wait(0.15)
							local v173 = tick()
							local v174 = Instance.new("ScreenGui")
							v174.ResetOnSpawn = false
							v174.IgnoreGuiInset = true
							for v175 = 1, #v_u_18, 2 do
								local v176 = Instance.new("ImageLabel")
								v176.Name = tostring(v175)
								v176.Image = v_u_18[v175]
								v176.Size = UDim2.new(0, 1, 0, 1)
								v176.BackgroundColor3 = Color3.new(0, 0, 0)
								v176.Parent = v174
							end
							v174.Parent = v_u_5.PlayerGui
							for v177 = 1, #v_u_18, 2 do
								v174[tostring(v177)].Size = UDim2.new(1, 0, 1, 0)
								if v177 ~= 1 then
									local v178 = v177 - 2
									v174[tostring(v178)]:Destroy()
								end
								repeat
									task.wait()
								until tick() - v173 >= 0.041666666666666664
								v173 = tick()
							end
							v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit):StartFadeOut(3)
							v174:Destroy()
							v170:Destroy()
							local v179 = v_u_7.Nanami.RatioBreaker.Attack4.HitEnd:Clone()
							v179.CFrame = v_u_168.CFrame
							v179.Parent = workspace.Effects
							v179.BloodParticle:Emit(70)
							v_u_3:AddItem(v179, 2)
							local v180 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
							v180.Parent = game.Lighting
							task.wait(0.04)
							v180.TintColor = Color3.new(1, 1, 1)
							task.wait(0.04)
							v180.Brightness = 200
							v180.Contrast = -1000
							task.wait(0.04)
							v180:Destroy()
							v179.BloodParticle.TimeScale = 0.075
							local v181 = TweenInfo.new(1.6, Enum.EasingStyle.Circular, Enum.EasingDirection.In)
							for _, v182 in v179:GetDescendants() do
								if v182:IsA("ParticleEmitter") then
									v_u_4:Create(v182, v181, {
										["TimeScale"] = 1
									}):Play()
								elseif v182:IsA("Beam") then
									v_u_4:Create(v182, v181, {
										["Width0"] = 0,
										["Width1"] = 0,
										["TextureSpeed"] = v182.TextureSpeed * 5
									}):Play()
								end
							end
						end)
						if v_u_5.Character == p166 then
							local v_u_183 = v_u_7.Nanami.OvertimeAura.Music:Clone()
							v_u_183.Parent = v_u_167
							v_u_183.SoundGroup = game.SoundService.Music
							v_u_183.TimePosition = 38.3
							v_u_183:Play()
							task.delay(2, function()
								-- upvalues: (ref) v_u_4, (copy) v_u_183
								v_u_4:Create(v_u_183, TweenInfo.new(1), {
									["Volume"] = 0
								}):Play()
							end)
						end
						task.wait(0.6)
						local v_u_184 = 0
						local v_u_185 = nil
						tick()
						local v_u_186 = v_u_7.Nanami.RatioBreaker.Attack4.CutsceneFrames
						v_u_185 = v_u_2.RenderStepped:Connect(function(p187)
							-- upvalues: (ref) v_u_184, (copy) v_u_186, (copy) p_u_165, (copy) v_u_167, (copy) v_u_169, (ref) v_u_185, (ref) v_u_5, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7
							v_u_184 = v_u_184 + p187 * 60
							local v188 = v_u_186.Frames
							local v189 = v_u_184
							local v190 = math.ceil(v189)
							local v191 = v188:FindFirstChild((tonumber(v190)))
							local v192 = v_u_186.FOV
							local v193 = v_u_184
							local v194 = math.ceil(v193)
							local v195 = v192:FindFirstChild((tonumber(v194)))
							if v191 and (v195 and (p_u_165.Parent and v_u_167)) then
								v_u_169.CFrame = v_u_167.CFrame * v191.Value
								v_u_169.FieldOfView = v195.Value
								v_u_169.CameraType = Enum.CameraType.Scriptable
							else
								v_u_185:Disconnect()
								v_u_169.CameraType = Enum.CameraType.Custom
								v_u_169.FieldOfView = 70
								v_u_169.CameraSubject = (v_u_5.Character or v_u_5.CharacterAdded:Wait()):WaitForChild("Humanoid")
								v_u_169.FieldOfView = 70
								game.Lighting.ExposureCompensation = 2
								v_u_4:Create(game.Lighting, TweenInfo.new(1), {
									["ExposureCompensation"] = 0
								}):Play()
								v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
								local v196 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
								v196.Parent = game.Lighting
								task.wait(0.04)
								v196.TintColor = Color3.new(1, 1, 1)
								task.wait(0.04)
								v196.Brightness = 200
								v196.Contrast = -1000
								task.wait(0.04)
								v196:Destroy()
							end
						end)
					else
						v_u_15:PlaySound(v_u_8.Nanami.RatioBreaker.RB4.Hit, v_u_168, game.SoundService.Effect)
					end
				else
					return
				end
			else
				return
			end
		end,
		["RatioBreakerFinisher"] = function(p197)
			-- upvalues: (ref) v_u_15
			if p197:FindFirstChild("HumanoidRootPart") then
				v_u_15:Bleed(p197)
			end
		end
	}
	v_u_14.Effects:Connect(function(p199, ...)
		-- upvalues: (copy) v_u_198
		local v200 = v_u_198[p199]
		if v200 then
			v200(...)
		end
	end)
end
function v17.KnitInit(_)
	-- upvalues: (ref) v_u_14, (copy) v_u_1, (ref) v_u_16, (ref) v_u_15
	v_u_14 = v_u_1.GetService("RatioBreakerService")
	v_u_16 = v_u_1.GetController("HitboxController")
	v_u_15 = v_u_1.GetController("FXController")
end
return v17