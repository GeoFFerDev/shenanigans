-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("MarketplaceService")
local v_u_2 = game:GetService("UserInputService")
game:GetService("CollectionService")
game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = require(v5.Modules.Icon)
local _ = v5.Animations
local _ = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = v_u_1.CreateController({
	["Name"] = "EmoteController"
})
v_u_10.EmoteCache = {}
v_u_10.Page = 1
function v_u_10.KnitStart(_)
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (ref) v_u_8, (copy) v_u_10, (ref) v_u_9, (copy) v_u_7
	local v_u_11 = v_u_4.PlayerGui:WaitForChild("Emotes")
	local v_u_12 = v_u_11.Emote
	local v_u_13 = v_u_4.PlayerGui:WaitForChild("Menus").Group.Inventory
	local v_u_14 = v_u_4:WaitForChild("Gamepasses")
	task.wait()
	local v_u_15 = v_u_6.new()
	v_u_15:setImage("rbxassetid://11713358131")
	v_u_15:bindEvent("selected", function(_)
		-- upvalues: (copy) v_u_12
		v_u_12.Visible = true
	end)
	v_u_15:bindEvent("deselected", function(_)
		-- upvalues: (copy) v_u_12
		v_u_12.Visible = false
	end)
	v_u_2.InputBegan:Connect(function(p16, p17)
		-- upvalues: (ref) v_u_4, (copy) v_u_12, (copy) v_u_15
		if not p17 then
			if p16.KeyCode == Enum.KeyCode.B then
				if v_u_4.Character and _G.UsingPiano == 2 then
					return
				end
				if v_u_12.Visible == false then
					v_u_15:select()
					return
				end
				if v_u_12.Visible == true then
					v_u_15:deselect()
				end
			end
		end
	end)
	v_u_12:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_12, (ref) v_u_3
		if v_u_12.Visible ~= false then
			v_u_12.Size = UDim2.new(0.1, 150, 0.1, 150)
			v_u_12.TextBox.Text = ""
			v_u_3:Create(v_u_12, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Size"] = UDim2.new(0.2, 150, 0.2, 150)
			}):Play()
			for _, v18 in v_u_12:GetDescendants() do
				if v18:IsA("Humanoid") then
					for _, v19 in v18:GetPlayingAnimationTracks() do
						v19.TimePosition = 0
					end
				end
			end
		end
	end)
	local v20 = Instance.new("Camera")
	v20.Parent = v_u_12
	v20.CFrame = v_u_11.Preset.Rig.HumanoidRootPart.CFrame * CFrame.new(0, 0, -30) * CFrame.Angles(0, 3.141592653589793, 0)
	v20.FieldOfView = 17
	v_u_4:WaitForChild("leaderstats")
	v_u_2.JumpRequest:Connect(function(_, _)
		-- upvalues: (ref) v_u_4, (ref) v_u_8
		local v21 = v_u_4.Character
		if v21 then
			if not v21.Info:FindFirstChild("EmoteCanJump") then
				if v21.Info:FindFirstChild("Emote") then
					v_u_8.EmoteEnd:Fire()
				end
			end
		else
			return
		end
	end)
	v_u_8.Equip:Connect(function(p22, p23, p24, p25)
		-- upvalues: (copy) v_u_12, (ref) v_u_10, (copy) v_u_13, (copy) v_u_11
		local v26 = v_u_12:FindFirstChild(p22, true)
		if v26:FindFirstChild("Rig") then
			v26.Rig:Destroy()
		end
		local v27 = p23 or "None"
		v26.EmoteName.Text = v27
		v26.EmoteName.Tip.Visible = p25 ~= nil
		if p25 then
			v26.EmoteName.Tip.Text = p25
		end
		v_u_10.EmoteCache[p22] = v27
		if p22 <= 8 and v_u_10.Page == 1 then
			v_u_13.Items.Emotes.Equipped[tostring(p22)].Text = v27
		elseif p22 > 8 and v_u_10.Page == 2 then
			local v28 = v_u_13.Items.Emotes.Equipped
			local v29 = p22 - 8
			v28[tostring(v29)].Text = v27
		end
		local v30 = v_u_11.Preset.Rig:Clone()
		v30.Parent = v26
		if p24 then
			local v31 = Instance.new("Animation", v30)
			v31.AnimationId = p24
			if p24 ~= "0" then
				local v_u_32 = v30.Humanoid:LoadAnimation(v31)
				v_u_32.Looped = true
				v_u_32:Play()
				v_u_32:GetMarkerReachedSignal("Loop"):Connect(function(p33)
					-- upvalues: (copy) v_u_32
					v_u_32.TimePosition = p33
				end)
			end
		end
	end)
	v_u_12.Switch.MouseButton1Down:Connect(function()
		-- upvalues: (copy) v_u_12, (ref) v_u_9, (ref) v_u_7
		v_u_12.Page1.Visible = not v_u_12.Page1.Visible
		v_u_12.Page2.Visible = not v_u_12.Page2.Visible
		v_u_9:PlaySound(v_u_7.Misc.UI.Switch, workspace, game.SoundService.Effect)
	end)
	for _, v_u_34 in v_u_12:GetDescendants() do
		if v_u_34:IsA("ViewportFrame") then
			v_u_34.CurrentCamera = v20
			v_u_34.MouseEnter:Connect(function()
				-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_3, (copy) v_u_34
				v_u_9:PlaySound(v_u_7.Misc.UI.Hover, workspace, game.SoundService.Effect)
				v_u_3:Create(v_u_34, TweenInfo.new(0.25), {
					["Size"] = UDim2.new(0.35, 10, 0.5, 10)
				}):Play()
			end)
			v_u_34.MouseLeave:Connect(function()
				-- upvalues: (ref) v_u_3, (copy) v_u_34
				v_u_3:Create(v_u_34, TweenInfo.new(0.25), {
					["Size"] = UDim2.new(0.35, 0, 0.5, 0)
				}):Play()
			end)
			v_u_34.Clickable.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_9, (ref) v_u_7, (copy) v_u_15, (ref) v_u_8, (copy) v_u_34
				v_u_9:PlaySound(v_u_7.Misc.UI.Click, workspace, game.SoundService.Effect)
				v_u_15:deselect()
				local v35 = v_u_8.Emote
				local v36 = v_u_34.Name
				v35:Fire((tonumber(v36)))
			end)
		end
	end
	local function v38()
		-- upvalues: (copy) v_u_14, (copy) v_u_12, (copy) v_u_13
		if v_u_14:GetAttribute("742180133") then
			for v37 = 5, 8 do
				v_u_12:FindFirstChild(v37, true).Visible = true
				v_u_13.Items.Emotes.Equipped:FindFirstChild(v37).Visible = true
			end
			v_u_12:FindFirstChild(13, true).Visible = true
			v_u_12:FindFirstChild(14, true).Visible = true
			v_u_12:FindFirstChild(15, true).Visible = true
			v_u_12:FindFirstChild(16, true).Visible = true
		end
		if v_u_14:GetAttribute("1151174294") then
			v_u_12.Switch.Visible = true
			v_u_13.Items.Emotes.Equipped.Switch.Visible = true
			v_u_12.TextBox.Visible = true
		end
	end
	v38()
	v_u_14:GetAttributeChangedSignal("742180133"):Connect(v38)
	v_u_14:GetAttributeChangedSignal("1151174294"):Connect(v38)
	local v_u_39 = require(script:WaitForChild("Effects"))
	v_u_8.Effects:Connect(function(p_u_40, ...)
		-- upvalues: (copy) v_u_39
		local v_u_41 = { ... }
		xpcall(function()
			-- upvalues: (ref) v_u_39, (copy) p_u_40, (copy) v_u_41
			local v42 = v_u_41
			v_u_39[p_u_40](unpack(v42))
		end, function(p43)
			-- upvalues: (copy) p_u_40
			print(("err with EmoteController [%s]: %s"):format(p_u_40, p43))
		end)
	end)
	v_u_12.TextBox:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_12, (copy) v_u_14, (copy) v_u_13, (ref) v_u_9, (ref) v_u_7, (copy) v_u_15, (ref) v_u_8
		if v_u_12.TextBox.Text == "" then
			if v_u_14:GetAttribute("1151174294") then
				v_u_12.TextBox.Visible = true
				v_u_12.Switch.Visible = true
			end
			v_u_12.Page1.Visible = true
			v_u_12.Page2.Visible = false
			v_u_12.Search.Visible = false
		else
			v_u_12.Page1.Visible = false
			v_u_12.Page2.Visible = false
			v_u_12.Switch.Visible = false
			v_u_12.Search.Visible = true
			for _, v44 in v_u_12.Search:GetChildren() do
				if v44:IsA("Frame") then
					v44:Destroy()
				end
			end
			for _, v45 in v_u_13.Items.Emotes.List:GetChildren() do
				if v45:IsA("Frame") and v45.Name:lower():find(v_u_12.TextBox.Text:lower()) then
					local v_u_46 = v45:Clone()
					v_u_46.Parent = v_u_12.Search
					v_u_46.Visible = true
					v_u_46.MouseEnter:Connect(function()
						-- upvalues: (ref) v_u_9, (ref) v_u_7
						v_u_9:PlaySound(v_u_7.Misc.UI.Hover, workspace, game.SoundService.Effect)
					end)
					v_u_46.EmoteName.MouseButton1Down:Connect(function()
						-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_15, (ref) v_u_8, (copy) v_u_46
						v_u_9:PlaySound(v_u_7.Misc.UI.Click, workspace, game.SoundService.Effect)
						v_u_15:deselect()
						v_u_8.Emote:Fire(v_u_46.Name)
					end)
				end
			end
		end
	end)
end
function v_u_10.KnitInit(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9
	v_u_8 = v_u_1.GetService("EmoteService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v_u_10