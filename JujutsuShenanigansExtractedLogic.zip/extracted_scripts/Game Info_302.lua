-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 4,
	["SortOrder"] = 6,
	["Desc"] = "Read about Jujutsu Shenanigan\'s mechanics",
	["BtnText"] = "Info",
	["Callback"] = function(_)
		_G.TutorialIcon:select()
	end
}