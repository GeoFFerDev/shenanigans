-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("HttpService")
local v_u_2 = require("./Helper")
local v_u_3 = {
	["amp"] = 10,
	["freq"] = 12,
	["duration"] = 0.4,
	["randomness"] = 0.35,
	["axis"] = Vector2.new(1, 1),
	["falloff"] = "cubic"
}
local v_u_4 = Random.new()
local v_u_11 = {
	["linear"] = function(p5)
		return 1 - p5
	end,
	["cubic"] = function(p6)
		-- upvalues: (copy) v_u_2
		return 1 - v_u_2.easeOutCubic(p6)
	end,
	["sine"] = function(p7)
		-- upvalues: (copy) v_u_2
		return 1 - v_u_2.easeOutSine(p7)
	end,
	["expo"] = function(p8)
		-- upvalues: (copy) v_u_2
		return 1 - v_u_2.easeOutExpo(p8)
	end,
	["circ"] = function(p9)
		-- upvalues: (copy) v_u_2
		return 1 - v_u_2.easeOutCirc(p9)
	end,
	["back"] = function(p10)
		-- upvalues: (copy) v_u_2
		return 1 - v_u_2.easeOutBack(p10, 1.4)
	end
}
local v_u_12 = {}
v_u_12.__index = v_u_12
function v_u_12.Shake(p13, p14)
	-- upvalues: (copy) v_u_3, (copy) v_u_11, (copy) v_u_1, (copy) v_u_4
	local v15 = p14 or {}
	local v16 = v15.amp
	local v17 = tonumber(v16) or v_u_3.amp
	local v18 = v15.freq
	local v19 = tonumber(v18) or v_u_3.freq
	local v20 = v15.duration
	local v21 = tonumber(v20) or v_u_3.duration
	local v22 = v15.randomness
	local v23 = tonumber(v22) or v_u_3.randomness
	local v24 = v15.axis or v_u_3.axis
	local v25 = math.max(0, v17)
	local v26 = math.max(0, v19)
	local v27 = math.max(0.0001, v21)
	local v28 = math.clamp(v23, 0, 1)
	local v29 = Vector2.new(v24.X, v24.Y)
	local v30 = v15.falloff
	if type(v30) == "string" then
		v30 = v_u_11[v30] or v_u_11[v_u_3.falloff]
	elseif type(v30) ~= "function" then
		v30 = v_u_11[v_u_3.falloff]
	end
	local v31 = v_u_1:GenerateGUID(false)
	local v32 = v_u_4:NextInteger(1, 1000000)
	local v33 = v_u_4:NextNumber(0, 6.283185307179586)
	p13._List[#p13._List + 1] = {
		["id"] = v31,
		["amp"] = v25,
		["freq"] = v26,
		["dur"] = v27,
		["time"] = 0,
		["randomness"] = v28,
		["axis"] = v29,
		["phase"] = v33,
		["fall"] = v30,
		["rng"] = Random.new(v32)
	}
	return v31
end
function v_u_12.Reset(p34)
	p34._List = {}
	if p34.Contents and p34._BaseC then
		p34.Contents.Position = p34._BaseC
	end
	if p34.Decorations and p34._BaseD then
		p34.Decorations.Position = p34._BaseD
	end
end
function v_u_12.new(p35, p36, p37)
	-- upvalues: (copy) v_u_12
	local v38 = {
		["Trove"] = p35,
		["State"] = p36,
		["Arena"] = p37,
		["Contents"] = p37:FindFirstChild("Contents"),
		["Decorations"] = p37:FindFirstChild("Decorations"),
		["_BaseC"] = nil,
		["_BaseD"] = nil,
		["_List"] = {}
	}
	local v39 = v_u_12
	local v40 = setmetatable(v38, v39)
	if v40.Contents then
		v40._BaseC = v40.Contents.Position
	end
	if v40.Decorations then
		v40._BaseD = v40.Decorations.Position
	end
	return v40
end
function v_u_12.Step(p41, p42)
	-- upvalues: (copy) v_u_2
	if p41.Contents or p41.Decorations then
		local v43 = v_u_2.toSec(p42)
		local v44 = Vector2.zero
		local v45 = 0
		for v46 = #p41._List, 1, -1 do
			local v47 = p41._List[v46]
			v47.time = v47.time + v43
			local v48 = v47.time / v47.dur
			local v49 = math.clamp(v48, 0, 1)
			if v49 >= 1 then
				table.remove(p41._List, v46)
			else
				v45 = v45 + 1
				v47.phase = v47.phase + 6.283185307179586 * v47.freq * v43
				local v50 = v47.phase
				local v51 = math.cos(v50)
				local v52 = v47.phase
				local v53 = math.sin(v52)
				local v54 = v47.rng:NextNumber(-1, 1)
				local v55 = v47.rng:NextNumber(-1, 1)
				local v56 = v47.amp * v47.fall(v49)
				local v57 = v47.randomness
				local v58 = (v51 * (1 - v57) + v54 * v57) * v56 * v47.axis.X
				local v59 = (v53 * (1 - v57) + v55 * v57) * v56 * v47.axis.Y
				if v58 ~= 0 or v59 ~= 0 then
					v44 = v44 + Vector2.new(v58, v59)
				end
			end
		end
		local v60 = v_u_2.roundpx(v44.X)
		local v61 = v_u_2.roundpx(v44.Y)
		if p41.Contents and p41._BaseC then
			p41.Contents.Position = UDim2.new(p41._BaseC.X.Scale, p41._BaseC.X.Offset + v60, p41._BaseC.Y.Scale, p41._BaseC.Y.Offset + v61)
		end
		if p41.Decorations and p41._BaseD then
			p41.Decorations.Position = UDim2.new(p41._BaseD.X.Scale, p41._BaseD.X.Offset + v60, p41._BaseD.Y.Scale, p41._BaseD.Y.Offset + v61)
		end
		if v45 == 0 then
			if p41.Contents and p41._BaseC then
				p41.Contents.Position = p41._BaseC
			end
			if p41.Decorations and p41._BaseD then
				p41.Decorations.Position = p41._BaseD
			end
		end
	end
end
function v_u_12.Destroy(p62)
	p62:Reset()
	table.clear(p62)
	setmetatable(p62, nil)
end
return v_u_12