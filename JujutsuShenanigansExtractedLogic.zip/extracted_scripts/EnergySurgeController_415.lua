-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "EnergySurgeController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_35 = {
		["Dash"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_7.Hakari.EnergySurge.Dash, v14, game.SoundService.Effect)
			end
		end,
		["HeavySwing"] = function(p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = v_u_6.Itadori.CrushingBlow:Clone()
				v17.Air.Position = Vector3.new(0, 40, 0)
				v17.CFrame = v16.CFrame * CFrame.new(1.5, 0, 0) * CFrame.Angles(1.5707963267948966, 0, 0)
				v17.Parent = workspace.Effects
				v_u_2:AddItem(v17, 1)
				v17.PointLight.Color = Color3.fromRGB(85, 255, 127)
				v_u_3:Create(v17.PointLight, TweenInfo.new(1), {
					["Brightness"] = 0
				}):Play()
				v17.Beam.Color = ColorSequence.new(Color3.fromRGB(85, 255, 127))
				v17.Floor.Sparks.Color = ColorSequence.new(Color3.fromRGB(85, 255, 127))
				v17.Floor.Ring:Emit(20)
				v17.Floor.Sparks:Emit(20)
				v_u_3:Create(v17.Air, TweenInfo.new(0.15), {
					["Position"] = Vector3.new(0, 0, 0)
				}):Play()
				v_u_3:Create(v17, TweenInfo.new(0.4), {
					["CFrame"] = v17.CFrame + v16.CFrame.LookVector * 30
				}):Play()
				v_u_11:PlaySound(v_u_7.Hakari.EnergySurge.Swing, v16, game.SoundService.Effect)
				if v_u_4.Character == p15 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["Flash"] = function(p18)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_11:PlaySound(v_u_7.Hakari.EnergySurge.Swag, v19, game.SoundService.Effect)
			end
		end,
		["Flash2"] = function(p20)
			-- upvalues: (ref) v_u_4, (ref) v_u_8
			if p20:FindFirstChild("HumanoidRootPart") then
				if v_u_4.Character == p20 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Teleport"] = function(p21, p22, _)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v23 = p21:FindFirstChild("HumanoidRootPart")
			if v23 then
				local v24 = v_u_6.Gojo.Teleport:Clone()
				v24.CFrame = p22
				v24.Parent = workspace.Effects
				v_u_2:AddItem(v24, 1.1)
				v_u_11:PlaySound(v_u_7.Hakari.EnergySurge.Teleport, v23, game.SoundService.Effect)
				v24.Floor.Dust:Emit(30)
				v24.CFrame = v23.CFrame
				v24.Lines:Emit(30)
				v24.Floor.Dust:Emit(30)
			end
		end,
		["Jump"] = function(p25, p26)
			-- upvalues: (ref) v_u_4, (ref) v_u_3
			local v27 = p26.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v28 = v27.CFrame.LookVector * 5
				if v_u_4.Character == v27.Parent then
					v_u_3:Create(p26, TweenInfo.new(0.5), {
						["P"] = 100000
					}):Play()
					repeat
						p26.Position = p25.Position - v28
						task.wait()
					until not (p26.Parent and p25)
				else
					repeat
						local v29 = v27.CFrame - v27.Position + p25.Position - v28
						v27.CFrame = v27.CFrame:Lerp(v29, 0.15)
						task.wait()
					until not (p26.Parent and p25)
				end
				v_u_3:Create(p26, TweenInfo.new(0.5), {
					["P"] = 100000
				}):Play()
				repeat
					p26.Position = p25.Position - v28
					task.wait()
				until not (p26.Parent and p25)
			end
		end,
		["Hit"] = function(p30, p31, p32)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v33 = p31:FindFirstChild("HumanoidRootPart")
			if v33 then
				v_u_11:Flash(p31, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Hakari.OverLuck.Hit1, v33, game.SoundService.Effect)
				local v34 = v_u_6.Hakari.RoughHit:Clone()
				v34.Position = v33.Position
				v34.Parent = workspace.Effects
				v_u_2:AddItem(v34, 1)
				v_u_3:Create(v34.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v34.Glow:Emit(1)
				v34.Sparks:Emit(50)
				v34.Wind:Emit(7)
				v34.Wind2:Emit(7)
				if p32 then
					v_u_11:PlaySound(v_u_7.Hakari.EnergySurge.Hit2, v33, game.SoundService.Effect)
				else
					v_u_11:PlaySound(v_u_7.Hakari.EnergySurge.Hit1, v33, game.SoundService.Effect)
				end
				if v_u_4 == p30 or v_u_4.Character == p31 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p36, ...)
		-- upvalues: (copy) v_u_35
		local v37 = v_u_35[p36]
		if v37 then
			v37(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("EnergySurgeService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12