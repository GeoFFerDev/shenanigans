-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("TweenService")
local v_u_2 = game:GetService("RunService")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = v3.LocalPlayer.PlayerGui
local v_u_6 = false
local v7 = {}
function getScreenGui()
	-- upvalues: (copy) v_u_5
	local v8 = v_u_5:FindFirstChild("ThumbstickGui")
	if not v8 then
		v8 = Instance.new("ScreenGui", v_u_5)
		v8.Name = "ThumbstickGui"
		v8.ResetOnSpawn = false
		v8.DisplayOrder = 10000
		v8.ClipToDeviceSafeArea = false
	end
	return v8
end
function v7.new(p9)
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_1, (copy) v_u_2, (ref) v_u_6
	local v_u_10 = false
	local v_u_11 = p9 or {}
	if v_u_11.Position then
		local v12 = v_u_11.Position
		if typeof(v12) == "UDim2" then
			::l5::
			if v_u_11.Size then
				local v13 = v_u_11.Size
				if typeof(v13) == "UDim2" then
					::l8::
					if not v_u_11.UiType or v_u_11.UiType ~= 1 then
						v_u_11.UiType = 0
					end
					if v_u_11.Theme then
						local v14 = v_u_11.Theme
						if tostring(v14) and script:FindFirstChild(v_u_11.Theme) then
							::l15::
							if v_u_11.ImageId then
								local v15 = v_u_11.ImageId
								if tonumber(v15) then
									::l18::
									if v_u_11.Deadzone then
										local v16 = v_u_11.Deadzone
										if tonumber(v16) then
											::l21::
											local v17 = v_u_11.ImageId
											v_u_11.ImageId = "rbxassetid://" .. tostring(v17)
											if v_u_11.UiType == 0 and not v_u_11.TouchZone then
												v_u_11.TouchZone = {}
												v_u_11.TouchZone.Size = UDim2.new(0.35, 100, 0.4, 100)
												v_u_11.TouchZone.Position = UDim2.new(0.65, 0, 0, -100)
											end
											local v_u_18 = {}
											local v_u_19 = script:FindFirstChild(v_u_11.Theme):Clone()
											v_u_19.Parent = getScreenGui()
											v_u_19.TouchStart.ImageLabel.Image = v_u_11.ImageId
											v_u_19.TouchEnd.ImageLabel.Image = v_u_11.ImageId
											local v_u_20 = Instance.new("Folder", v_u_19)
											v_u_20.Name = "PointDisplay"
											local v_u_21 = Instance.new("Frame", v_u_19)
											v_u_21.Name = "DynamicThumbstickFrame"
											v_u_21.Transparency = 1
											v_u_21.Active = true
											v_u_21.Interactable = true
											v_u_19.TouchStart.Size = v_u_11.Size + UDim2.new(0, 10, 0, 10)
											v_u_19.TouchEnd.Size = v_u_11.Size
											local v_u_22 = v_u_19.Point
											v_u_22.Size = UDim2.new(0, v_u_19.TouchEnd.AbsoluteSize.X / 6, 0, v_u_19.TouchEnd.AbsoluteSize.Y / 6)
											v_u_22.Position = UDim2.new(2, 0, 2, 0)
											local v_u_23 = v_u_19.TouchStart.BackgroundTransparency
											local v_u_24 = v_u_19.TouchEnd.BackgroundTransparency
											local v_u_25 = v_u_19.TouchStart.Outline.UIStroke1.Transparency
											local v_u_26 = v_u_19.TouchEnd.Outline.UIStroke1.Transparency
											local v_u_27 = v_u_19.TouchStart.Outline.UIStroke2.Transparency
											local v_u_28 = v_u_19.TouchEnd.Outline.UIStroke2.Transparency
											local v_u_29 = v_u_19.TouchStart.ImageLabel.ImageTransparency
											local v_u_30 = v_u_19.TouchEnd.ImageLabel.ImageTransparency
											v_u_19.TouchStart.BackgroundTransparency = 1
											v_u_19.TouchEnd.BackgroundTransparency = 1
											v_u_19.TouchStart.Outline.UIStroke1.Transparency = 1
											v_u_19.TouchStart.Outline.UIStroke2.Transparency = 1
											v_u_19.TouchEnd.Outline.UIStroke1.Transparency = 1
											v_u_19.TouchEnd.Outline.UIStroke2.Transparency = 1
											v_u_19.TouchStart.ImageLabel.ImageTransparency = 1
											v_u_19.TouchEnd.ImageLabel.ImageTransparency = 1
											if v_u_11.UiType == 0 then
												v_u_21.Size = v_u_11.TouchZone.Size
												v_u_21.Position = v_u_11.TouchZone.Position
												v_u_21.BackgroundColor3 = Color3.new(0, 0, 0)
												v_u_21.BackgroundTransparency = 0.8
											else
												v_u_21.Size = v_u_19.TouchStart.Size
												v_u_21.Position = v_u_11.Position
												v_u_21.AnchorPoint = Vector2.new(0.5, 0.5)
												v_u_19.TouchStart.Position = v_u_11.Position
												local v31 = v_u_19.TouchStart
												local v32 = v_u_23 - 0.5
												v31.BackgroundTransparency = math.clamp(v32, 0, 1)
												local v33 = v_u_19.TouchStart.Outline.UIStroke1
												local v34 = v_u_25 - 0.5
												v33.Transparency = math.clamp(v34, 0, 1)
												local v35 = v_u_19.TouchStart.Outline.UIStroke2
												local v36 = v_u_27 - 0.5
												v35.Transparency = math.clamp(v36, 0, 1)
												v_u_19.TouchStart.ImageLabel.ImageTransparency = v_u_29
												v_u_19.TouchStart.ImageLabel.Visible = true
												v_u_10 = true
											end
											v_u_19.TouchStart.Visible = true
											v_u_19.TouchEnd.Visible = true
											local v_u_37 = Instance.new("BindableEvent")
											v_u_18.Began = v_u_37.Event
											local v_u_38 = Instance.new("BindableEvent")
											v_u_18.Changed = v_u_38.Event
											local v_u_39 = Instance.new("BindableEvent")
											v_u_18.Ended = v_u_39.Event
											local v40
											if v_u_11.UiType == 1 then
												v40 = v_u_11.Position or nil
											else
												v40 = nil
											end
											v_u_18.StartPosition = v40
											v_u_18.IsDisabled = false
											v_u_18.InputObject = nil
											v_u_18.Type = v_u_11.UiType == 0 and "Hidden" or "Visible"
											local v_u_52 = v_u_4.InputBegan:Connect(function(p41, _)
												-- upvalues: (ref) v_u_4, (copy) v_u_18, (ref) v_u_5, (copy) v_u_21, (copy) v_u_19, (ref) v_u_11, (ref) v_u_1, (copy) v_u_23, (copy) v_u_24, (copy) v_u_25, (copy) v_u_27, (copy) v_u_26, (copy) v_u_28, (copy) v_u_30, (copy) v_u_37, (ref) v_u_10
												if v_u_4.KeyboardEnabled or v_u_18.IsDisabled then
													return
												elseif v_u_18.InputObject or p41.UserInputType ~= Enum.UserInputType.Touch then
													return
												else
													local v42 = p41.Position.X
													local v43 = p41.Position.Y
													local v44 = v_u_5:GetGuiObjectsAtPosition(v42, v43)[1]
													if v44 then
														if v44 == v_u_21 or v44:IsDescendantOf(v_u_19) then
															v_u_18.StartPosition = v_u_11.UiType == 1 and v_u_11.Position or UDim2.new(0, v42, 0, v43)
															v_u_19.TouchStart.Position = v_u_18.StartPosition
															if (Vector2.new(v_u_19.TouchStart.AbsolutePosition.X + v_u_19.TouchStart.AbsoluteSize.X * 0.5, v_u_19.TouchStart.AbsolutePosition.Y + v_u_19.TouchStart.AbsoluteSize.Y * 0.5) - Vector2.new(v42, v43)).Magnitude <= 15 then
																v42 = v_u_19.TouchStart.AbsolutePosition.X + v_u_19.TouchStart.AbsoluteSize.X * 0.5
																v43 = v_u_19.TouchStart.AbsolutePosition.Y + v_u_19.TouchStart.AbsoluteSize.Y * 0.5
															end
															v_u_19.TouchEnd.Position = UDim2.new(0, v42, 0, v43)
															local v45 = {
																["BackgroundTransparency"] = v_u_23
															}
															v_u_1:Create(v_u_19.TouchStart, TweenInfo.new(0.1), v45):Play()
															local v46 = {
																["BackgroundTransparency"] = v_u_24
															}
															v_u_1:Create(v_u_19.TouchEnd, TweenInfo.new(0.1), v46):Play()
															local v47 = {
																["Transparency"] = v_u_25
															}
															v_u_1:Create(v_u_19.TouchStart.Outline.UIStroke1, TweenInfo.new(0.1), v47):Play()
															local v48 = {
																["Transparency"] = v_u_27
															}
															v_u_1:Create(v_u_19.TouchStart.Outline.UIStroke2, TweenInfo.new(0.1), v48):Play()
															local v49 = {
																["Transparency"] = v_u_26
															}
															v_u_1:Create(v_u_19.TouchEnd.Outline.UIStroke1, TweenInfo.new(0.1), v49):Play()
															local v50 = {
																["Transparency"] = v_u_28
															}
															v_u_1:Create(v_u_19.TouchEnd.Outline.UIStroke2, TweenInfo.new(0.1), v50):Play()
															v_u_1:Create(v_u_19.TouchStart.ImageLabel, TweenInfo.new(0.1), {
																["ImageTransparency"] = 1
															}):Play()
															local v51 = {
																["ImageTransparency"] = v_u_30
															}
															v_u_1:Create(v_u_19.TouchEnd.ImageLabel, TweenInfo.new(0.1), v51):Play()
															v_u_18.InputObject = p41
															v_u_37:Fire()
															if not v_u_10 then
																v_u_10 = true
																v_u_21.BackgroundTransparency = 1
																task.wait()
																v_u_1:Create(v_u_21, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.InOut), {
																	["BackgroundTransparency"] = 0.7
																}):Play()
																task.wait(0.4)
																v_u_1:Create(v_u_21, TweenInfo.new(0.4), {
																	["BackgroundTransparency"] = 1
																}):Play()
															end
														end
													else
														return
													end
												end
											end)
											local v_u_98 = v_u_4.InputChanged:Connect(function(p53, _)
												-- upvalues: (ref) v_u_4, (copy) v_u_18, (copy) v_u_19, (ref) v_u_11, (copy) v_u_22, (copy) v_u_20, (copy) v_u_38
												if v_u_4.KeyboardEnabled or v_u_18.IsDisabled then
													return
												elseif v_u_18.InputObject and v_u_18.InputObject == p53 then
													local v54 = p53.Position.X
													local v55 = p53.Position.Y
													local v56 = v_u_19.TouchStart.AbsolutePosition.X + v_u_19.TouchStart.AbsoluteSize.X * 0.5 - v54
													if math.abs(v56) >= 1 then
														local v57 = v_u_19.TouchStart.AbsolutePosition.Y + v_u_19.TouchStart.AbsoluteSize.Y * 0.5 - v55
														if math.abs(v57) >= 1 then
															local v58 = UDim2.new(0, v_u_19.TouchStart.AbsolutePosition.X + v_u_19.TouchStart.AbsoluteSize.X * 0.5, 0, v_u_19.TouchStart.AbsolutePosition.Y + v_u_19.TouchStart.AbsoluteSize.Y * 0.5) - UDim2.new(0, v54, 0, v55)
															local v59 = UDim2.new(0, -v58.X.Offset, 0, v58.Y.Offset)
															if (Vector2.new(v_u_19.TouchStart.AbsolutePosition.X + v_u_19.TouchStart.AbsoluteSize.X * 0.5, v_u_19.TouchStart.AbsolutePosition.Y + v_u_19.TouchStart.AbsoluteSize.Y * 0.5) - Vector2.new(v54, v55)).Magnitude <= 15 then
																v54 = v_u_19.TouchStart.AbsolutePosition.X + v_u_19.TouchStart.AbsoluteSize.X * 0.5
																v55 = v_u_19.TouchStart.AbsolutePosition.Y + v_u_19.TouchStart.AbsoluteSize.Y * 0.5
															end
															local v60 = v59.X.Offset
															local v61 = math.abs(v60)
															local v62 = v59.Y.Offset
															local v63 = v61 / math.abs(v62)
															local v64 = math.atan(v63)
															local v65 = v_u_19.TouchStart.AbsoluteSize.X
															local v66 = v_u_19.TouchStart.AbsoluteSize.Y
															local v67 = math.max(v65, v66) * v_u_11.Deadzone * 0.5
															local v68 = v59.X.Offset < 0 and v59.Y.Offset > 0 and 1 or (v59.X.Offset > 0 and v59.Y.Offset > 0 and 2 or (v59.X.Offset < 0 and v59.Y.Offset < 0 and 3 or 4))
															local v69
															if v68 == 2 then
																v69 = v64 + 4.71238898038469
															elseif v68 == 1 then
																v69 = 1.5707963267948966 - (v64 + 3.141592653589793)
															elseif v68 == 3 then
																v69 = v64 + 1.5707963267948966
															else
																v69 = 1.5707963267948966 - v64
															end
															local v70 = v_u_19.TouchStart.AbsolutePosition.X + v_u_19.TouchStart.AbsoluteSize.X * 0.5 + v67 * math.cos(v69)
															local v71 = v_u_19.TouchStart.AbsolutePosition.Y + v_u_19.TouchStart.AbsoluteSize.Y * 0.5 + v67 * math.sin(v69)
															if v68 == 1 then
																if v54 < v70 then
																	v54 = v70
																end
																if v55 < v71 then
																	v55 = v71
																end
															elseif v68 == 2 then
																if v70 < v54 then
																	v54 = v70
																end
																if v55 < v71 then
																	v55 = v71
																end
															elseif v68 == 3 then
																if v54 < v70 then
																	v54 = v70
																end
																if v71 < v55 then
																	v55 = v71
																end
															else
																if v70 < v54 then
																	v54 = v70
																end
																if v71 < v55 then
																	v55 = v71
																end
															end
															local _ = v70 - v_u_19.TouchEnd.AbsoluteSize.X * 0.5
															local _ = v71 - v_u_19.TouchEnd.AbsoluteSize.Y * 0.5
															v_u_19.TouchEnd.Position = UDim2.new(0, v54, 0, v55)
															local v72 = UDim2.new(0, v_u_19.TouchStart.AbsolutePosition.X + v_u_19.TouchStart.AbsoluteSize.X * 0.5, 0, v_u_19.TouchStart.AbsolutePosition.Y + v_u_19.TouchStart.AbsoluteSize.Y * 0.5) - UDim2.new(0, v_u_19.TouchEnd.AbsolutePosition.X + v_u_19.TouchEnd.AbsoluteSize.X * 0.5, 0, v_u_19.TouchEnd.AbsolutePosition.Y + v_u_19.TouchEnd.AbsoluteSize.Y * 0.5)
															local v73 = Vector2.new(-v72.X.Offset, v72.Y.Offset)
															local v74 = v73.X
															local v75 = math.abs(v74) ^ 2
															local v76 = v73.Y
															local v77 = v75 + math.abs(v76) ^ 2
															local v78 = math.sqrt(v77)
															local v79 = v_u_22.AbsoluteSize.X
															local v80 = v_u_22.AbsoluteSize.Y
															local v81 = math.max(v79, v80)
															local v82 = v81 * 1.8
															local v83 = v78 / v82
															local v84 = math.floor(v83)
															for _, v85 in pairs(v_u_20:GetChildren()) do
																local v86 = v85.Name
																if v84 < tonumber(v86) then
																	v85:Destroy()
																end
															end
															for v87 = 1, v84 do
																if v_u_20:FindFirstChild((tostring(v87))) then
																	local v88 = v_u_20:FindFirstChild((tostring(v87)))
																	local v89 = v82 * v87
																	local v90 = v_u_19.TouchStart.AbsolutePosition.X + v_u_19.TouchStart.AbsoluteSize.X * 0.5 + v89 * math.cos(v69)
																	local v91 = v_u_19.TouchStart.AbsolutePosition.Y + v_u_19.TouchStart.AbsoluteSize.Y * 0.5 + v89 * math.sin(v69)
																	v88.Position = UDim2.new(0, v90, 0, v91)
																	local v92 = 1 - v89 / v78
																	v88.Transparency = math.clamp(v92, 0, 1)
																	local v93 = (Vector2.new(v_u_19.TouchStart.AbsolutePosition.X + v_u_19.TouchStart.AbsoluteSize.X * 0.5, v_u_19.TouchStart.AbsolutePosition.Y + v_u_19.TouchStart.AbsoluteSize.Y * 0.5) - Vector2.new(v90, v91)).Magnitude / v82 * v81
																	local v94 = v81 * 0.05
																	local v95 = v81 * 4
																	local v96 = math.clamp(v93, v94, v95) * 0.25
																	v88.Size = UDim2.new(0, v96, 0, v96)
																else
																	local v97 = v_u_22:Clone()
																	v97.Name = tostring(v87)
																	v97.Parent = v_u_20
																end
															end
															v_u_38:Fire(v73)
															return
														end
													end
												end
											end)
											local v_u_118 = v_u_4.InputEnded:Connect(function(p99, _)
												-- upvalues: (ref) v_u_4, (copy) v_u_18, (copy) v_u_19, (copy) v_u_20, (ref) v_u_1, (ref) v_u_11, (copy) v_u_23, (copy) v_u_25, (copy) v_u_27, (copy) v_u_29, (copy) v_u_39
												if v_u_4.KeyboardEnabled or v_u_18.IsDisabled then
													return
												elseif v_u_18.InputObject and v_u_18.InputObject == p99 then
													v_u_19.TouchEnd.Position = v_u_18.StartPosition
													v_u_20:ClearAllChildren()
													local v100 = v_u_1
													local v101 = v_u_19.TouchStart
													local v102 = TweenInfo.new(0.1)
													local v103 = {}
													local v104
													if v_u_11.UiType == 0 then
														v104 = 1
													else
														local v105 = v_u_23 - 0.5
														v104 = math.clamp(v105, 0, 1)
													end
													v103.BackgroundTransparency = v104
													v100:Create(v101, v102, v103):Play()
													v_u_1:Create(v_u_19.TouchEnd, TweenInfo.new(0.1), {
														["BackgroundTransparency"] = 1
													}):Play()
													local v106 = v_u_1
													local v107 = v_u_19.TouchStart.Outline.UIStroke1
													local v108 = TweenInfo.new(0.1)
													local v109 = {}
													local v110
													if v_u_11.UiType == 0 then
														v110 = 1
													else
														local v111 = v_u_25 - 0.5
														v110 = math.clamp(v111, 0, 1)
													end
													v109.Transparency = v110
													v106:Create(v107, v108, v109):Play()
													local v112 = v_u_1
													local v113 = v_u_19.TouchStart.Outline.UIStroke2
													local v114 = TweenInfo.new(0.1)
													local v115 = {}
													local v116
													if v_u_11.UiType == 0 then
														v116 = 1
													else
														local v117 = v_u_27 - 0.5
														v116 = math.clamp(v117, 0, 1)
													end
													v115.Transparency = v116
													v112:Create(v113, v114, v115):Play()
													v_u_1:Create(v_u_19.TouchEnd.Outline.UIStroke1, TweenInfo.new(0.1), {
														["Transparency"] = 1
													}):Play()
													v_u_1:Create(v_u_19.TouchEnd.Outline.UIStroke2, TweenInfo.new(0.1), {
														["Transparency"] = 1
													}):Play()
													v_u_1:Create(v_u_19.TouchStart.ImageLabel, TweenInfo.new(0.1), {
														["ImageTransparency"] = v_u_11.UiType == 0 and 1 or v_u_29
													}):Play()
													v_u_1:Create(v_u_19.TouchEnd.ImageLabel, TweenInfo.new(0.1), {
														["ImageTransparency"] = 1
													}):Play()
													v_u_18.InputObject = nil
													v_u_39:Fire()
												end
											end)
											function v_u_18.Enable(p119)
												-- upvalues: (ref) v_u_1, (copy) v_u_19, (ref) v_u_11, (copy) v_u_23, (copy) v_u_25, (copy) v_u_27, (copy) v_u_29
												p119.IsDisabled = false
												task.wait()
												local v120 = v_u_1
												local v121 = v_u_19.TouchStart
												local v122 = TweenInfo.new(0.1)
												local v123 = {}
												local v124
												if v_u_11.UiType == 0 then
													v124 = 1
												else
													local v125 = v_u_23 - 0.5
													v124 = math.clamp(v125, 0, 1)
												end
												v123.BackgroundTransparency = v124
												v120:Create(v121, v122, v123):Play()
												v_u_1:Create(v_u_19.TouchEnd, TweenInfo.new(0.1), {
													["BackgroundTransparency"] = 1
												}):Play()
												local v126 = v_u_1
												local v127 = v_u_19.TouchStart.Outline.UIStroke1
												local v128 = TweenInfo.new(0.1)
												local v129 = {}
												local v130
												if v_u_11.UiType == 0 then
													v130 = 1
												else
													local v131 = v_u_25 - 0.5
													v130 = math.clamp(v131, 0, 1)
												end
												v129.Transparency = v130
												v126:Create(v127, v128, v129):Play()
												local v132 = v_u_1
												local v133 = v_u_19.TouchStart.Outline.UIStroke2
												local v134 = TweenInfo.new(0.1)
												local v135 = {}
												local v136
												if v_u_11.UiType == 0 then
													v136 = 1
												else
													local v137 = v_u_27 - 0.5
													v136 = math.clamp(v137, 0, 1)
												end
												v135.Transparency = v136
												v132:Create(v133, v134, v135):Play()
												v_u_1:Create(v_u_19.TouchEnd.Outline.UIStroke1, TweenInfo.new(0.1), {
													["Transparency"] = 1
												}):Play()
												v_u_1:Create(v_u_19.TouchEnd.Outline.UIStroke2, TweenInfo.new(0.1), {
													["Transparency"] = 1
												}):Play()
												v_u_1:Create(v_u_19.TouchStart.ImageLabel, TweenInfo.new(0.1), {
													["ImageTransparency"] = v_u_11.UiType == 0 and 1 or v_u_29
												}):Play()
												v_u_1:Create(v_u_19.TouchEnd.ImageLabel, TweenInfo.new(0.1), {
													["ImageTransparency"] = 1
												}):Play()
											end
											function v_u_18.Disable(p138)
												-- upvalues: (ref) v_u_1, (copy) v_u_19, (copy) v_u_39
												p138.IsDisabled = true
												task.wait()
												v_u_1:Create(v_u_19.TouchStart, TweenInfo.new(0.1), {
													["BackgroundTransparency"] = 1
												}):Play()
												v_u_1:Create(v_u_19.TouchEnd, TweenInfo.new(0.1), {
													["BackgroundTransparency"] = 1
												}):Play()
												v_u_1:Create(v_u_19.TouchStart.Outline.UIStroke1, TweenInfo.new(0.1), {
													["Transparency"] = 1
												}):Play()
												v_u_1:Create(v_u_19.TouchStart.Outline.UIStroke2, TweenInfo.new(0.1), {
													["Transparency"] = 1
												}):Play()
												v_u_1:Create(v_u_19.TouchEnd.Outline.UIStroke1, TweenInfo.new(0.1), {
													["Transparency"] = 1
												}):Play()
												v_u_1:Create(v_u_19.TouchEnd.Outline.UIStroke2, TweenInfo.new(0.1), {
													["Transparency"] = 1
												}):Play()
												v_u_1:Create(v_u_19.TouchStart.ImageLabel, TweenInfo.new(0.1), {
													["ImageTransparency"] = 1
												}):Play()
												v_u_1:Create(v_u_19.TouchEnd.ImageLabel, TweenInfo.new(0.1), {
													["ImageTransparency"] = 1
												}):Play()
												if p138.InputObject then
													v_u_39:Fire()
												end
												p138.InputObject = nil
											end
											local v_u_139 = nil
											v_u_139 = v_u_2.RenderStepped:Connect(function()
												-- upvalues: (ref) v_u_4, (ref) v_u_6, (copy) v_u_18, (copy) v_u_20, (ref) v_u_139
												local v141, _ = pcall(function()
													-- upvalues: (ref) v_u_4, (ref) v_u_6, (ref) v_u_18, (ref) v_u_20
													if v_u_4.KeyboardEnabled and not v_u_6 then
														v_u_18:Disable()
													elseif not v_u_4.KeyboardEnabled and v_u_6 then
														v_u_18:Enable()
													end
													v_u_6 = v_u_4.KeyboardEnabled
													for _, v140 in pairs(v_u_20:GetChildren()) do
														if v_u_18.InputObject then
															v140.Visible = true
														else
															v140.Visible = false
														end
													end
												end)
												if not v141 then
													v_u_139:Disconnect()
												end
											end)
											local v_u_142 = nil
											v_u_142 = v_u_19.Destroying:Connect(function()
												-- upvalues: (copy) v_u_52, (copy) v_u_98, (copy) v_u_118, (ref) v_u_139, (ref) v_u_142
												v_u_52:Disconnect()
												v_u_98:Disconnect()
												v_u_118:Disconnect()
												v_u_139:Disconnect()
												v_u_142:Disconnect()
											end)
											return v_u_18
										end
									end
									v_u_11.Deadzone = 3.6
									goto l21
								end
							end
							v_u_11.ImageId = 109486912260101
							goto l18
						end
					end
					v_u_11.Theme = "Modern"
					goto l15
				end
			end
			v_u_11.Size = UDim2.new(0, 55, 0, 55)
			goto l8
		end
	end
	v_u_11.Position = UDim2.new(0.5, 0, 0.5, 0)
	goto l5
end
function v7.ClearUis(_)
	getScreenGui():ClearAllChildren()
end
return v7