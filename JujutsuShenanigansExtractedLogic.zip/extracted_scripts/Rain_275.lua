-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 4,
	["Desc"] = "rain everywhere"
}
local v_u_2 = nil
local v_u_3 = RaycastParams.new()
v_u_3.FilterType = Enum.RaycastFilterType.Include
v_u_3.FilterDescendantsInstances = { workspace.Map }
local v_u_4 = game:GetService("RunService")
game:GetService("TweenService")
function v1.Callback(p5)
	-- upvalues: (ref) v_u_2, (copy) v_u_4, (copy) v_u_3
	if p5 == true then
		v_u_2 = game.ReplicatedStorage.Utils.Misc.Rain:Clone()
		v_u_2.Parent = workspace.Effects
		v_u_2.RainSFX.SoundGroup = game.SoundService.Effect
		v_u_2.RainSFX:Play()
		local v_u_6 = nil
		v_u_6 = v_u_4.Stepped:Connect(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			if v_u_2 then
				local v7 = workspace.CurrentCamera.CFrame
				v_u_2.Position = v7.Position + Vector3.new(0, 10, 0)
				local v8 = workspace:Raycast(v7.Position, Vector3.new(0, 40, 0), v_u_3)
				workspace:Raycast(v7.Position - v7.LookVector * 5, Vector3.new(0, 40, 0), v_u_3)
				workspace:Raycast(v7.Position + v7.LookVector * 5, Vector3.new(0, 40, 0), v_u_3)
				if v8 then
					v_u_2.Rain.Enabled = false
					v_u_2.RainSFX.Muffle.Enabled = true
				else
					v_u_2.Rain.Enabled = true
					v_u_2.RainSFX.Muffle.Enabled = false
					local v9 = workspace
					local v10 = v_u_2.Position
					local v11 = math.random(-50, 50)
					local v12 = math.random
					local v13 = v9:Raycast(v10 + Vector3.new(v11, 0, v12(-50, 50)), Vector3.new(0, -50, 0), v_u_3)
					if v13 then
						v_u_2.Attachment.WorldCFrame = CFrame.new(v13.Position, v13.Position + v13.Normal) * CFrame.Angles(0, 1.5707963267948966, 0)
						v_u_2.Attachment.Splash:Emit(1)
					end
				end
			else
				v_u_6:Disconnect()
				return
			end
		end)
	elseif v_u_2 then
		v_u_2:Destroy()
		v_u_2 = nil
	end
end
return v1