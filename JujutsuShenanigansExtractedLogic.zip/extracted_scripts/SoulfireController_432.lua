-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
require(v5.Modules.CameraShaker)
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "SoulfireController"
})
function v10.KnitStart(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (ref) v_u_8
	local v_u_28 = {
		["Morph"] = function(p_u_11, p12)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_6, (ref) v_u_4, (ref) v_u_3
			local v13 = p_u_11:FindFirstChild("HumanoidRootPart")
			if v13 then
				if p12 then
					v_u_9:PlaySound(v_u_7.Mahito.Soulfire.Morph, v13, game.SoundService.Effect)
					for _ = 1, 20 do
						local v14 = v_u_6.Mahito.Morph:Clone()
						v14.Weld.Part0 = p_u_11["Right Arm"]
						v14.Color = p_u_11["Right Arm"].Color
						v14.Weld.C1 = CFrame.new(math.random(-50, 50) / 100, math.random(-100, 100) / 100, math.random(-50, 50) / 100)
						v14.Parent = workspace.Effects
						v14.Size = Vector3.new(1, 1, 1) * (math.random(5, 25) / 10)
						v_u_4:Create(v14, TweenInfo.new(math.random(10, 40) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_3:AddItem(v14, 0.4)
					end
					p12.Destroying:Connect(function()
						-- upvalues: (copy) p_u_11, (ref) v_u_6, (ref) v_u_4, (ref) v_u_3
						if p_u_11.Parent then
							for _ = 1, 20 do
								local v15 = v_u_6.Mahito.Morph:Clone()
								v15.Weld.Part0 = p_u_11["Right Arm"]
								v15.Color = p_u_11["Right Arm"].Color
								v15.Weld.C1 = CFrame.new(math.random(-50, 50) / 100, math.random(-100, 100) / 100, math.random(-50, 50) / 100)
								v15.Parent = workspace.Effects
								v15.Size = Vector3.new(1, 1, 1) * (math.random(5, 15) / 10)
								v_u_4:Create(v15, TweenInfo.new(math.random(10, 30) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
									["Size"] = Vector3.new(0, 0, 0)
								}):Play()
								v_u_3:AddItem(v15, 0.3)
							end
						end
					end)
				end
			else
				return
			end
		end,
		["Fire"] = function(p16, p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9, (ref) v_u_7
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v19.CFrame = v18.CFrame * CFrame.new(0, 1, -6)
				v19.Size = Vector3.new(0, 0, 6)
				v19.Parent = workspace.Effects
				v_u_4:Create(v19, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(9, 9, 0),
					["Position"] = v19.Position - v18.CFrame.LookVector * 4,
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v19, 0.2)
				v_u_9:PlaySound(v_u_7.Mahito.Soulfire.Fire, v18, game.SoundService.Effect)
				if p17 then
					p17.Attachment.Flash:Emit(1)
					p17.Attachment.PointLight.Brightness = 10
					v_u_4:Create(p17.Attachment.PointLight, TweenInfo.new(0.3), {
						["Brightness"] = 0
					}):Play()
				end
			else
				return
			end
		end,
		["Interp"] = function(p_u_20)
			-- upvalues: (ref) v_u_2
			local v_u_21 = p_u_20.CFrame
			local v_u_22 = tick()
			local v_u_23 = p_u_20:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_21, (copy) p_u_20, (ref) v_u_22
				v_u_21 = p_u_20.CFrame
				v_u_22 = tick()
			end)
			local v_u_24 = nil
			v_u_24 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_20, (ref) v_u_24, (copy) v_u_23, (ref) v_u_21, (ref) v_u_22
				if p_u_20.Parent then
					workspace:BulkMoveTo({ p_u_20 }, { v_u_21 + v_u_21.LookVector * (200 * (tick() - v_u_22)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_24:Disconnect()
					v_u_23:Disconnect()
				end
			end)
		end,
		["Hit"] = function(p25)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3
			local v26 = p25:FindFirstChild("HumanoidRootPart")
			if v26 then
				v_u_9:Flash(p25, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_7.Mahito.Soulfire.Hit, v26, game.SoundService.Effect)
				local v27 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v27.Parent = v26.RootAttachment
				v27:Emit(20)
				v_u_3:AddItem(v27, 0.4)
			end
		end
	}
	v_u_8.Effects:Connect(function(p29, ...)
		-- upvalues: (copy) v_u_28
		local v30 = v_u_28[p29]
		if v30 then
			v30(...)
		end
	end)
end
function v10.KnitInit(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9
	v_u_8 = v_u_1.GetService("SoulfireService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10