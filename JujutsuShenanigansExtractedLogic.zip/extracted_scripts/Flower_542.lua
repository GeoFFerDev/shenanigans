-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("HttpService")
local v_u_2 = require("./Helper")
local v_u_3 = require("./Bits")
local v_u_4 = {
	["damage"] = 10,
	["spawnTime"] = 0.55,
	["telegraphTime"] = 0.18,
	["backOffset"] = 64,
	["throwSpeed"] = 760,
	["backRotDeg"] = 50,
	["margin"] = 6,
	["spinSpeed"] = 360,
	["bitsCount"] = 6,
	["impactOffset"] = 2
}
local v_u_5 = script.Parent.Assets.Sprites.Other.Flower
Random.new()
local v_u_6 = {}
v_u_6.__index = v_u_6
v_u_6.Compute = {}
function v_u_6.new(p7, p_u_8, p9, p10)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_5, (copy) v_u_1, (copy) v_u_6, (copy) v_u_3
	local v11 = p10 or {}
	local v12 = v11.damage or v_u_4.damage
	local v13 = v11.spawnTime or v_u_4.spawnTime
	local v14 = v11.telegraphTime or v_u_4.telegraphTime
	local v15 = v11.backOffset or v_u_4.backOffset
	local v16 = v11.throwSpeed or v_u_4.throwSpeed
	local v17 = v11.backRotDeg or v_u_4.backRotDeg
	local v18 = v11.margin or v_u_4.margin
	local v19 = v11.spawnSide
	local v20 = v11.spinSpeed or v_u_4.spinSpeed
	local v21 = v11.bitsCount or v_u_4.bitsCount
	local v22 = v11.impactOffset or v_u_4.impactOffset
	local v23 = v_u_2.resolveEffectFolders(p9)
	local v24
	if v11.fromGui and v11.targetPos then
		v24 = v_u_2.absToCenteredOffset(v_u_2.centerAbs(v11.fromGui), p9) + v11.targetPos
	elseif v11.targetPos then
		v24 = Vector2.new(v_u_2.roundpx(v11.targetPos.X), v_u_2.roundpx(v11.targetPos.Y))
	else
		v24 = p_u_8.Player and p_u_8.Player.Pos or Vector2.zero
	end
	local v25
	if v19 == "Left" then
		v25 = Vector2.new(1, 0)
	elseif v19 == "Right" then
		v25 = Vector2.new(-1, 0)
	elseif v19 == "Top" then
		v25 = Vector2.new(0, 1)
	elseif v19 == "Bottom" then
		v25 = Vector2.new(0, -1)
	else
		v25 = v24.Magnitude > 1e-6 and -v24.Unit or Vector2.new(1, 0)
	end
	local v26 = v_u_2.dirToRotation(v25)
	local v27 = v26 - v17
	local v28, v29 = v_u_2.parkAndStartForRay(p9, v24, v25, v18)
	local v30 = v28 - v25 * v22
	local v_u_31 = v_u_5:Clone()
	v_u_31.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_31.Parent = v23
	v_u_31.Position = UDim2.new(0.5, v29.X, 0.5, v29.Y)
	v_u_31.Rotation = v27
	p_u_8.Attacks[v_u_31] = {
		["Kind"] = "Flower",
		["Pos"] = v29,
		["Dmg"] = 0,
		["Rot"] = v27,
		["AbsSize"] = v_u_31.AbsoluteSize,
		["Destroy"] = function()
			-- upvalues: (copy) p_u_8, (copy) v_u_31
			if p_u_8.Attacks[v_u_31] then
				p_u_8.Attacks[v_u_31] = nil
			end
			if v_u_31 then
				v_u_31:Destroy()
			end
		end
	}
	local v32 = {
		["Signals"] = p7,
		["State"] = p_u_8,
		["Contents"] = p9,
		["Damage"] = v12,
		["SpawnTime"] = v13,
		["TeleTime"] = v14,
		["BackOffset"] = v15,
		["ThrowSpeed"] = v16,
		["BackRot"] = v17,
		["Margin"] = v18,
		["SpinSpeed"] = v20,
		["BitsCount"] = v21,
		["BitsParams"] = v11.bitsParams,
		["Target"] = v24,
		["DirIn"] = v25,
		["ParkPos"] = v28,
		["ImpactPos"] = v30,
		["StartPos"] = v29,
		["FaceRot"] = v26,
		["StartRot"] = v27,
		["GUI"] = v_u_31,
		["Atk"] = p_u_8.Attacks[v_u_31],
		["TimeSec"] = 0,
		["PhaseSec"] = 0,
		["SpinAcc"] = 0,
		["Phase"] = "SPAWN",
		["UUID"] = v_u_1:GenerateGUID(false)
	}
	local v33 = v_u_6
	local v_u_34 = setmetatable(v32, v33)
	v_u_6.Compute[v_u_34.UUID] = function(p35)
		-- upvalues: (ref) v_u_2, (copy) v_u_34, (ref) v_u_3
		local v36 = v_u_2.toSec(p35)
		local v37 = v_u_34
		v37.TimeSec = v37.TimeSec + v36
		local v38 = v_u_34
		v38.PhaseSec = v38.PhaseSec + v36
		if v_u_34.Phase == "SPAWN" then
			local v39 = v_u_34.PhaseSec / v_u_34.SpawnTime
			local v40 = math.clamp(v39, 0, 1)
			local v41 = v_u_2.easeOutCubic(v40)
			local v42 = v_u_34.StartPos.X
			local v43 = v_u_34.ImpactPos.X
			local v44 = math.lerp(v42, v43, v41)
			local v45 = v_u_34.StartPos.Y
			local v46 = v_u_34.ImpactPos.Y
			local v47 = math.lerp(v45, v46, v41)
			local v48 = v_u_34.StartRot
			local v49 = v_u_34.FaceRot
			local v50 = math.lerp(v48, v49, v41)
			v_u_34.GUI.Position = UDim2.new(0.5, v_u_2.roundpx(v44), 0.5, v_u_2.roundpx(v47))
			v_u_34.GUI.Rotation = v50
			local v51 = v_u_34.Atk
			local v52 = v_u_34.Atk
			local v53 = v_u_34.Atk
			v51.Pos = Vector2.new(v44, v47)
			v52.Rot = v50
			v53.Dmg = 0
			if v40 >= 1 then
				v_u_34.Phase = "TELEGRAPH"
				v_u_34.PhaseSec = 0
			end
			return
		elseif v_u_34.Phase == "TELEGRAPH" then
			local v54 = v_u_34.PhaseSec / v_u_34.TeleTime
			local v55 = math.clamp(v54, 0, 1)
			local v56 = v_u_34.BackOffset
			local v57 = v_u_2.easeOutCubic
			local v58 = math.lerp(0, v56, v57(v55))
			local v59 = v_u_34.ImpactPos - v_u_34.DirIn * v58
			v_u_34.GUI.Position = UDim2.new(0.5, v_u_2.roundpx(v59.X), 0.5, v_u_2.roundpx(v59.Y))
			v_u_34.GUI.Rotation = v_u_34.FaceRot
			local v60 = v_u_34.Atk
			local v61 = v_u_34.Atk
			local v62 = v_u_34.Atk
			local v63 = v_u_34.FaceRot
			v60.Pos = v59
			v61.Rot = v63
			v62.Dmg = 0
			if v55 >= 1 then
				v_u_34.Phase = "THROW"
				v_u_34.PhaseSec = 0
				v_u_34.FromPos = v59
				v_u_34.SpinAcc = 0
			end
			return
		elseif v_u_34.Phase == "THROW" then
			if not v_u_34.Sounded then
				v_u_34.Signals.spawnSound:Fire("Explosion 1")
				v_u_34.Sounded = true
			end
			v_u_34.SpinAcc = (v_u_34.SpinAcc + v_u_34.SpinSpeed * v36) % 360
			local v64 = v_u_34.PhaseSec / v_u_34.TeleTime
			local v65 = math.clamp(v64, 0, 1)
			local v66 = v_u_2.easeOutCubic(v65)
			local v67 = v_u_34.FromPos.X
			local v68 = v_u_34.ImpactPos.X
			local v69 = math.lerp(v67, v68, v66)
			local v70 = v_u_34.FromPos.Y
			local v71 = v_u_34.ImpactPos.Y
			local v72 = math.lerp(v70, v71, v66)
			local v73 = v_u_34.FaceRot + v_u_34.SpinAcc
			v_u_34.GUI.Position = UDim2.new(0.5, v_u_2.roundpx(v69), 0.5, v_u_2.roundpx(v72))
			v_u_34.GUI.Rotation = v73
			local v74 = v_u_34.Atk
			local v75 = v_u_34.Atk
			local v76 = v_u_34.Atk
			v74.Pos = Vector2.new(v69, v72)
			v75.Rot = v73
			v76.Dmg = 0
			if v65 >= 1 then
				if not v_u_34.Shaked then
					v_u_34.Signals.onShake:Fire({
						["amp"] = 12,
						["freq"] = 10,
						["duration"] = 0.2,
						["falloff"] = "cubic"
					})
					v_u_34.Shaked = true
				end
				v_u_3.new(v_u_34.State, v_u_34.Contents, "Yellow", v_u_34.BitsCount, Vector2.zero, {
					["fromGui"] = v_u_34.GUI,
					["damage"] = v_u_34.Damage,
					["ttl"] = v_u_34.BitsParams and v_u_34.BitsParams.ttl or nil,
					["gravity"] = v_u_34.BitsParams and v_u_34.BitsParams.gravity or nil,
					["vxMin"] = v_u_34.BitsParams and v_u_34.BitsParams.vxMin or nil,
					["vxMax"] = v_u_34.BitsParams and v_u_34.BitsParams.vxMax or nil,
					["vyMin"] = v_u_34.BitsParams and v_u_34.BitsParams.vyMin or nil,
					["vyMax"] = v_u_34.BitsParams and v_u_34.BitsParams.vyMax or nil,
					["spinMin"] = v_u_34.BitsParams and v_u_34.BitsParams.spinMin or nil,
					["spinMax"] = v_u_34.BitsParams and v_u_34.BitsParams.spinMax or nil
				})
				v_u_34.Phase = "DONE"
			end
			return
		elseif v_u_34.Phase == "DONE" then
			v_u_34:Destroy()
		end
	end
	return v_u_34
end
function v_u_6.Destroy(p77)
	-- upvalues: (copy) v_u_6
	if p77.UUID and v_u_6.Compute[p77.UUID] then
		v_u_6.Compute[p77.UUID] = nil
	end
	if p77.State and (p77.State.Attacks and p77.Atk) then
		p77.State.Attacks[p77.GUI] = nil
	end
	if p77.GUI then
		p77.GUI:Destroy()
	end
	table.clear(p77)
	setmetatable(p77, nil)
end
function v_u_6.Step(p78)
	-- upvalues: (copy) v_u_6
	for _, v79 in pairs(v_u_6.Compute) do
		v79(p78)
	end
end
return v_u_6