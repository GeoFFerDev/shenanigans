-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = v_u_6.Animations
local v_u_8 = v_u_6.Utils
local v_u_9 = v_u_6.Sounds
local v_u_10 = require(v_u_6.Modules.CameraShaker)
local v_u_11 = require(v_u_6.Modules.StaticLightning)
local v_u_12 = workspace.CurrentCamera
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "MutualLoveController"
})
function v15.KnitStart(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_9, (copy) v_u_5, (copy) v_u_7, (copy) v_u_8, (copy) v_u_4, (copy) v_u_3, (copy) v_u_10, (copy) v_u_2, (copy) v_u_6, (copy) v_u_11, (copy) v_u_12, (ref) v_u_14
	local v_u_16 = Random.new()
	local v_u_263 = {
		["Startup"] = function(p_u_17)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7, (ref) v_u_8, (ref) v_u_4
			local v18 = p_u_17:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_13:PlaySound(v_u_9.Yuta.MutualLove.Voice, v18, game.SoundService.Voice)
				v_u_13:DomainBurst(v18)
				local v19 = v_u_5.Character
				if v19 and v19:FindFirstChild("HumanoidRootPart") then
					local v20 = v19:FindFirstChild("HumanoidRootPart")
					if (v18.Position - v20.Position).Magnitude <= 37.5 then
						v_u_13:Domain(p_u_17, function(p21, p22)
							-- upvalues: (copy) p_u_17, (ref) v_u_7, (ref) v_u_8, (ref) v_u_4
							local v23 = p_u_17.SetAssets:FindFirstChild("YutaSword")
							local v24
							if v23 and v23.Sword.Weld.Enabled then
								v24 = p22.Humanoid:LoadAnimation(v_u_7.Yuta.DomainWarn2)
								local v25 = v_u_8.Yuta.MutualLove.LSword:Clone()
								v25.Weld.Part0 = p22["Left Arm"]
								v25.Name = "Sword"
								v25.Parent = p22
							else
								v24 = p22.Humanoid:LoadAnimation(v_u_7.Yuta.DomainWarn1)
							end
							v24:Play(0)
							p21.Panel.ImageLabel.Image = "rbxassetid://80698598530653"
							p21.Panel.ImageLabel.Size = UDim2.new(0.8, 0, 0.25, 0)
							p21.Panel.Viewport.LightColor = Color3.fromRGB(255, 255, 255)
							p21.Panel.Viewport.Ambient = Color3.fromRGB(255, 224, 254)
							p21.Panel.Viewport.LightDirection = Vector3.new(0, -1, 0)
							v_u_4:Create(p21.Panel.Viewport, TweenInfo.new(1.5), {
								["LightColor"] = Color3.fromRGB(255, 192, 250),
								["Ambient"] = Color3.fromRGB(255, 181, 254)
							}):Play()
							local v26 = v_u_8.Yuta.MutualLove.YutaRing:Clone()
							for _, v27 in p22["Left Arm"].FingersL:GetChildren() do
								if v27:IsA("BasePart") and v27.Name == "Ring" then
									v26.Weld.Part0 = v27
									break
								end
							end
							v26.Parent = p22
						end)
					end
				end
			end
		end,
		["Opening"] = function(p28, p29, p_u_30, p_u_31)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_10, (copy) v_u_16
			local v_u_32 = v_u_13:PlaySound(v_u_9.Yuta.MutualLove.Start, workspace, game.SoundService.Effect)
			local v_u_33 = v_u_13:PlaySound(v_u_9.Yuta.MutualLove.OST, workspace, game.SoundService.Music)
			local v_u_34 = v_u_13:PlaySound(v_u_9.Yuta.MutualLove.AmbianceLoop, workspace, game.SoundService.Effect, true)
			local v_u_35 = v_u_8.Yuta.MutualLove.YutaDomain:Clone()
			v_u_35:PivotTo(p28.CFrame * CFrame.new(0, 14, 0) * CFrame.Angles(0, 0, 1.5707963267948966))
			task.spawn(function()
				-- upvalues: (copy) p_u_30, (copy) v_u_35, (copy) v_u_32, (copy) v_u_33, (copy) v_u_34
				repeat
					task.wait()
				until not (p_u_30.Parent and (p_u_30.Parent.Parent and p_u_30.Parent.Parent.Parent))
				v_u_35:Destroy()
				if v_u_32.Parent then
					v_u_32:Destroy()
				end
				if v_u_33.Parent then
					v_u_33:Destroy()
				end
				if v_u_34.Parent then
					v_u_34:Destroy()
				end
			end)
			local v_u_36 = v_u_35.DomainBG
			local v_u_37 = v_u_36.Color
			v_u_36.Color = Color3.new()
			local v38 = {}
			if not p_u_31 then
				for _, v39 in v_u_36.Props:GetDescendants() do
					if v39:IsA("BasePart") then
						v38[v39] = v39.CFrame
						v39.Transparency = 1
						v39.CFrame = v39.CFrame * CFrame.new(0, -20, 0)
					end
				end
			end
			local v40 = v_u_36.Base
			local v41 = v40.Size
			if p_u_31 then
				v_u_35.Parent = p28
			else
				v40.Size = Vector3.new(2, 0, 0)
				for _, v42 in v_u_36.AllBows:GetDescendants() do
					if v42:IsA("BasePart") then
						v42.Transparency = 1
					end
				end
				v_u_35.Parent = p28
				local v_u_43 = p29.DomainGround
				v_u_43.Surround.Enabled = true
				v_u_4:Create(v_u_43.Surround, TweenInfo.new(0.8), {
					["ShapePartial"] = 1
				}):Play()
				v_u_3:AddItem(v_u_43, 2)
				task.delay(0.8, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_43, (ref) v_u_13
					v_u_4:Create(v_u_43, TweenInfo.new(0.4), {
						["Transparency"] = 0
					}):Play()
					v_u_13:DomainMapFade(Color3.fromRGB(0, 0, 0), 0.4, 1.6)
				end)
				task.wait(1.5)
				for _, v44 in v_u_36.AllBows:GetChildren() do
					if v44.Name == "Bow" then
						for _, v45 in v44:GetChildren() do
							if v45.Name == "Bow1" or v45.Name == "Bow2" then
								local v46 = v45.Name == "Bow2" and 1 or -1
								local v_u_47 = {}
								for _, v48 in v45:GetChildren() do
									if v48:IsA("BasePart") then
										local v49 = v48.CFrame:VectorToObjectSpace(v48.CFrame.RightVector * (v48.Size.X / 2 * v46))
										local v50 = v48.Name
										v_u_47[tonumber(v50)] = {
											["Part"] = v48,
											["Original"] = {
												["CFrame"] = v48.CFrame,
												["Size"] = v48.Size
											},
											["Offset"] = v49
										}
										local v51 = v48.Size.Y
										local v52 = v48.Size.Z
										v48.Size = Vector3.new(0, v51, v52)
										v48.Transparency = 1
									end
								end
								task.spawn(function()
									-- upvalues: (copy) v_u_47, (ref) v_u_4
									local v53 = #v_u_47
									for v54 = 1, #v_u_47 do
										if v_u_47[v54] then
											local v55 = v_u_47[v54].Part
											local v56 = v_u_47[v54].Original
											local v57 = v_u_47[v54].Offset
											local v58 = v56.CFrame * CFrame.new(-v57)
											local v59 = CFrame.Angles
											local v60 = math.random(-15, 15)
											v55.CFrame = v58 * v59(-1.5707963267948966, math.rad(v60), 0)
											v55.Transparency = 0
											local _ = v54 / v53
											local v61 = v_u_4:Create(v55, TweenInfo.new(0.015), {
												["Size"] = v56.Size,
												["CFrame"] = v56.CFrame
											})
											v61:Play()
											v61.Completed:Wait()
										end
									end
								end)
							end
						end
					end
				end
			end
			task.delay(0.285, function()
				-- upvalues: (copy) p_u_31, (copy) v_u_36, (ref) v_u_4, (ref) v_u_10, (copy) v_u_37, (ref) v_u_16, (ref) v_u_8, (ref) v_u_13, (ref) v_u_9
				local v_u_62 = {}
				if not p_u_31 then
					local v63 = TweenInfo.new(0.3)
					for _, v64 in v_u_36.AllBows:GetDescendants() do
						if v64:IsA("BasePart") then
							local v65 = v64:Clone()
							v65.Parent = v64.Parent
							v65.Material = Enum.Material.Plastic
							v65.Color = Color3.new(1, 1, 1)
							v65.CFrame = v64.CFrame
							v65.Size = v64.Size
							v_u_4:Create(v65, v63, {
								["Size"] = v65.Size * Vector3.new(2, 5, 5),
								["Transparency"] = 1
							}):Play()
							table.insert(v_u_62, v65)
						end
					end
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
				task.delay(0.5, function()
					-- upvalues: (copy) v_u_62, (ref) v_u_4, (ref) v_u_36, (ref) v_u_37, (ref) v_u_16, (ref) v_u_8, (ref) v_u_13, (ref) v_u_9
					for _, v66 in v_u_62 do
						v66:Destroy()
					end
					local v67 = {
						["Color"] = v_u_37
					}
					v_u_4:Create(v_u_36, TweenInfo.new(1), v67):Play()
					v_u_36.Stars.Enabled = true
					task.wait(1.2)
					for v_u_68 = 1, v_u_16:NextInteger(30, 40) do
						task.delay(v_u_16:NextNumber(0, 1.5), function()
							-- upvalues: (ref) v_u_8, (ref) v_u_36, (ref) v_u_16, (ref) v_u_13, (ref) v_u_9, (ref) v_u_4, (copy) v_u_68
							local v69 = v_u_8.Yuta.MutualLove.Sword:Clone()
							local v70 = CFrame.lookAlong(v_u_36.Position + Vector3.new(0, 50, 0), Vector3.new(-0, -1, -0))
							local v71 = CFrame.Angles
							local v72 = v_u_16:NextInteger(0, 360)
							v69.CFrame = v70 * v71(0, 0, (math.rad(v72)))
							v69.CFrame = v69.CFrame * CFrame.new(0, v_u_16:NextNumber(40, 120), 0)
							v69.Parent = v_u_36
							v_u_13:PlaySound(v_u_9.Yuta.MutualLove.SwordFall, v69, game.SoundService.Effect).PlaybackSpeed = v_u_16:NextNumber(2, 3)
							v_u_4:Create(v69, TweenInfo.new(0.2), {
								["CFrame"] = v69.CFrame * CFrame.new(0, 0, -(46 + v_u_16:NextNumber(0, 0.7)))
							}):Play()
							task.wait(0.2)
							v69.Blade.Sparks:Emit(10)
							v_u_13:PlaySound(v_u_9.Yuta.MutualLove[("SwordGround%*"):format(v_u_68 % 3 + 1)], v69, game.SoundService.Effect)
							local v73 = v_u_4
							local v74 = TweenInfo.new(0.1)
							local v75 = {}
							local v76 = v69.CFrame
							local v77 = CFrame.Angles
							local v78 = v_u_16:NextNumber(-45, 45)
							v75.CFrame = v76 * v77(math.rad(v78), 0, v_u_16:NextNumber(-45, 45))
							v73:Create(v69, v74, v75):Play()
						end)
					end
				end)
				while v_u_36.Parent do
					local v79 = task.wait()
					if not v_u_36.Parent then
						break
					end
					local v80 = v_u_36.AllBows
					local v81 = v_u_36.AllBows:GetPivot()
					local v82 = CFrame.Angles
					local v83 = 15 * v79
					v80:PivotTo(v81 * v82(0, math.rad(v83), 0))
				end
			end)
			task.wait(1)
			if not p_u_31 then
				v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.HeavyHit):StartFadeOut(3)
				v_u_4:Create(v40, TweenInfo.new(2, Enum.EasingStyle.Linear), {
					["Size"] = v41
				}):Play()
				while v40.Size ~= v41 do
					local v84 = (v40.Size * Vector3.new(0, 1, 1)).Magnitude / 2
					for v85, v86 in v38 do
						if v85.Transparency ~= 0 and (v85.Position - v40.Position).Magnitude <= v84 then
							v85.Transparency = 0
							v_u_4:Create(v85, TweenInfo.new(0.3, Enum.EasingStyle.Circular, Enum.EasingDirection.InOut), {
								["CFrame"] = v86
							}):Play()
						end
					end
					local v87 = Instance.fromExisting(v40)
					v87.Size = Vector3.new(2, 0, 0)
					v87.Position = v87.Position + (v_u_16:NextUnitVector() * Vector3.new(1, 0, 1)).Unit * v84
					v87.Parent = v40
					v_u_4:Create(v87, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, true), {
						["Size"] = Vector3.new(2, 50, 50)
					}):Play()
					v_u_3:AddItem(v87, 0.4)
					task.wait(0.05)
				end
			end
		end,
		["DropSwords"] = function(p88, p89)
			-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (copy) v_u_16, (ref) v_u_4
			for v90, v91 in p88 do
				if v_u_5 == p89 then
					v91.Handle.Color = Color3.fromRGB(117, 0, 0)
				end
				v_u_13:PlaySound(v_u_9.Yuta.MutualLove.SwordFall, v91, game.SoundService.Effect).PlaybackSpeed = v_u_16:NextNumber(2, 3)
				v_u_4:Create(v91, TweenInfo.new(0.2), {
					["CFrame"] = v91.CFrame * CFrame.new(0, 0, -(46 + v_u_16:NextNumber(0, 0.7)))
				}):Play()
				task.wait(0.2)
				if not v91.Parent then
					return
				end
				v91.Blade.Sparks:Emit(10)
				v_u_13:PlaySound(v_u_9.Yuta.MutualLove[("SwordGround%*"):format(v90 % 3 + 1)], v91, game.SoundService.Effect)
				local v92 = v_u_4
				local v93 = TweenInfo.new(0.1)
				local v94 = {}
				local v95 = v91.CFrame
				local v96 = CFrame.Angles
				local v97 = v_u_16:NextNumber(-45, 45)
				v94.CFrame = v95 * v96(math.rad(v97), 0, v_u_16:NextNumber(-45, 45))
				v92:Create(v91, v93, v94):Play()
			end
		end,
		["Pickup"] = function(p98)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v99 = p98:FindFirstChild("HumanoidRootPart")
			if v99 then
				v_u_13:PlaySound(v_u_9.Yuta.MutualLove.PickupSword, v99, game.SoundService.Effect)
			end
		end,
		["RunSwing"] = function(p100)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v101 = p100:FindFirstChild("HumanoidRootPart")
			if v101 then
				v_u_13:PlaySound(v_u_9.Yuta.MutualLove.RunSlash, v101, game.SoundService.Effect)
			end
		end,
		["Run"] = function(p102, p103, p_u_104)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_4, (ref) v_u_2
			local v105 = p102:FindFirstChild("HumanoidRootPart")
			if v105 then
				v_u_13:PlaySound(v_u_9.Hiromi.Sprint, v105, game.SoundService.Effect)
				if v_u_5.Character == p102 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					local v_u_106 = Instance.new("NumberValue", p103)
					v_u_106.Value = 100
					v_u_4:Create(v_u_106, TweenInfo.new(1.5, Enum.EasingStyle.Sine), {
						["Value"] = 0
					}):Play()
					p_u_104.AncestryChanged:Once(function()
						-- upvalues: (copy) p_u_104, (ref) v_u_4, (copy) v_u_106
						if not p_u_104.Parent then
							v_u_4:Create(v_u_106, TweenInfo.new(0.5), {
								["Value"] = 0
							}):Play()
						end
					end)
					repeat
						p103.Velocity = v105.CFrame.LookVector * v_u_106.Value
						v_u_2.Stepped:Wait()
					until not (p103.Parent and v105.Parent)
				end
			end
		end,
		["SwordHit"] = function(p107, p108)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v109 = p107:FindFirstChild("HumanoidRootPart")
			if v109 then
				local v110 = p108:FindFirstChild("HumanoidRootPart")
				if v110 then
					v_u_13:Flash(p108, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_9.Yuta.M1.Hit1, v110, game.SoundService.Effect)
					local v111 = v_u_8.Yuta.SlashHit:Clone()
					v111.CFrame = CFrame.lookAlong(v110.Position, v109.CFrame.LookVector) * CFrame.Angles(0, 0, 1.3089969389957472)
					v111.Parent = workspace.Effects
					v_u_3:AddItem(v111, 0.5)
					v111.Slash:Emit(5)
				end
			else
				return
			end
		end,
		["CleaveHit"] = function(p112)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v113 = p112:FindFirstChild("HumanoidRootPart")
			if v113 then
				v_u_13:Flash(p112, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Yuta.MutualLove.CleaveSlash, v113, game.SoundService.Effect)
				local v114 = v_u_8.Itadori.MalevolantShrine.Hit:Clone()
				v114.Anchored = true
				v114.CFrame = v113.CFrame
				v114.Parent = workspace.Effects
				v_u_3:AddItem(v114, 1)
				v114.Slash1.Enabled = false
				v114.Slash2.Enabled = false
				v114.Slash1:Emit(3)
				v114.Slash2:Emit(3)
			end
		end,
		["DismantleHit"] = function(p115)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v116 = p115:FindFirstChild("HumanoidRootPart")
			if v116 then
				v_u_13:Flash(p115, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Heian.Dismantle.Hit, v116, game.SoundService.Effect).Volume = 0.5
				local v117 = v_u_8.Itadori.MalevolantShrine.Hit:Clone()
				v117.Weld.Part1 = v116
				v117.Parent = workspace.Effects
				v117.Slash1.Enabled = false
				v117.Slash2.Enabled = false
				v117.Slash1:Emit(3)
				v117.Slash2:Emit(3)
				v_u_3:AddItem(v117, 1)
			end
		end,
		["Dismantle"] = function(p118, p119)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_5, (ref) v_u_10
			local v120 = p118:FindFirstChild("HumanoidRootPart")
			if v120 then
				v_u_13:PlaySound(v_u_9.Itadori.Dismantle.FinishSlash, v120, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Yuta.MutualLove.DismantleSwing, v120, game.SoundService.Effect)
				local v121 = v_u_8.Itadori.Dismantle.DismatleProj:Clone()
				v121.Size = v121.Size * Vector3.new(0.5, 0.5, 0.5)
				v121.CFrame = p119 + p119.LookVector * 15
				v121.Parent = workspace.Effects
				v_u_4:Create(v121.Slash, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(0, 0, 30)
				}):Play()
				v_u_4:Create(v121.Weld, TweenInfo.new(0.1), {
					["C1"] = CFrame.new(0, 0, 15)
				}):Play()
				v_u_3:AddItem(v121.Slash, 0.1)
				v_u_3:AddItem(v121, 0.5)
				v121.Smear:Emit(25)
				v121.Stars:Emit(15)
				if v_u_5.Character == p118 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
			end
		end,
		["BigVoice"] = function(p122)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			if (workspace.CurrentCamera.CFrame.Position - p122).Magnitude < 200 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				local v123 = v_u_8.Yuta.MutualLove.BigVoice:Clone()
				v123.Position = p122
				v123.Parent = workspace.Effects
				v_u_3:AddItem(v123, 4)
				for _, v124 in v123:GetChildren() do
					v124:Emit(v124:GetAttribute("EmitCount"))
				end
				local v125 = v_u_13:PlaySound(v_u_9.Misc.Items.Voice, workspace, game.SoundService.Effect)
				v125.Volume = v125.Volume * 2
				local v126 = v_u_13:PlaySound(v_u_9.Misc.Items.Voice2, workspace, game.SoundService.Voice)
				v126.Volume = v126.Volume * 2
			end
		end,
		["Plummet"] = function(p127)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			if (workspace.CurrentCamera.CFrame.Position - p127).Magnitude < 200 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				local v128 = v_u_8.Misc.Items.Voice:Clone()
				v128.Position = p127
				v128.Parent = workspace.Effects
				v_u_3:AddItem(v128, 4)
				for _, v129 in v128:GetChildren() do
					v129:Emit(v129:GetAttribute("EmitCount"))
				end
				v_u_13:PlaySound(v_u_9.Misc.Items.Voice, workspace, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Yuta.MutualLove.VoiceCrush, workspace, game.SoundService.Voice)
			end
		end,
		["Die"] = function(p130)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			if (workspace.CurrentCamera.CFrame.Position - p130).Magnitude < 200 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				local v131 = v_u_8.Misc.Items.Voice:Clone()
				v131.Position = p130
				v131.Parent = workspace.Effects
				v_u_3:AddItem(v131, 4)
				for _, v132 in v131:GetChildren() do
					v132:Emit(v132:GetAttribute("EmitCount"))
				end
				v_u_13:PlaySound(v_u_9.Misc.Items.Voice, workspace, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Yuta.MutualLove.VoiceDie, workspace, game.SoundService.Voice)
			end
		end,
		["Shikigami"] = function(p133, p134, p135, p_u_136)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_6, (ref) v_u_4, (copy) v_u_16, (ref) v_u_3
			local v137 = p133:FindFirstChild("HumanoidRootPart")
			if v137 then
				local v_u_138 = p134:FindFirstChild("HumanoidRootPart")
				if v_u_138 then
					local v139 = v137.CFrame
					local v140 = {
						v139.RightVector,
						-v139.RightVector,
						v139.UpVector / 2 + v139.RightVector / 2,
						v139.UpVector / 2 - v139.RightVector / 2
					}
					v_u_13:PlaySound(v_u_9.Yuta.MutualLove.MiniRikaToggle, v137, game.SoundService.Effect)
					local v141 = {}
					for v142 = 1, 4 do
						local v143 = v_u_8.Yuta.MutualLove["Mini Rika"]:Clone()
						v143.Head.CFrame = CFrame.lookAlong(v139.Position + v140[v142] * 4, v139.LookVector)
						v143.Parent = workspace.Effects
						v143.AnimationController.Animator:LoadAnimation(v_u_6.Animations.Yuta.Rika.MiniRikaFly):Play()
						v143.Head.Start.Sparks:Emit(15)
						v143.Head.Start.Sparks2:Emit(10)
						v_u_13:PlaySound(v_u_9.Yuta.MutualLove.MiniRikaFly, v143.Head, game.SoundService.Effect)
						local v144 = { v143.Head, v143.Head.Position }
						table.insert(v141, v144)
					end
					local v145 = tick()
					while true do
						task.wait()
						local v146 = (tick() - v145) / p135
						local v147 = v_u_4:GetValue(math.clamp(v146, 0, 1), Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
						local v148 = v_u_138.Position
						for v149, v150 in v141 do
							local v151 = v150[2]
							local v152 = v150[1]
							local v153 = (v151 + v148) / 2 + v140[v149] * 20
							local v154 = v151:Lerp(v153, v147):Lerp(v153:Lerp(v148, v147), v147)
							local v155
							if v152.Position:FuzzyEq(v154) then
								v155 = v139.LookVector
							else
								v155 = CFrame.new(v152.Position, v154).LookVector
							end
							v152.CFrame = CFrame.lookAlong(v154, v155)
						end
						if v147 == 1 then
							local v_u_156 = v_u_13:PlaySound(v_u_9.Yuta.MutualLove.MiniRikaSwarm, v_u_138, game.SoundService.Effect)
							for _, v_u_157 in v141 do
								task.spawn(function()
									-- upvalues: (ref) v_u_157, (ref) v_u_16, (copy) v_u_138, (copy) p_u_136, (ref) v_u_3
									v_u_157 = v_u_157[1]
									local v158 = v_u_16:NextNumber(0.33, 0.66)
									local v159 = v_u_16:NextNumber(5, 8)
									local v160 = tick()
									local v161 = CFrame.Angles
									local v162 = v_u_16:NextInteger(-45, 45)
									local v163 = math.rad(v162)
									local v164 = v_u_16:NextInteger(-45, 45)
									local v165 = v161(v163, 0, (math.rad(v164)))
									while true do
										local v166 = task.wait()
										local v167 = v_u_138.Position
										local v168 = CFrame.Angles
										local v169 = 1 / v158 * v166 * 360
										v165 = v165 * v168(0, math.rad(v169), 0)
										v_u_157.CFrame = CFrame.new(v167) * v165 * CFrame.new(0, 0, -v159)
										if v158 <= tick() - v160 then
											local v170 = CFrame.Angles
											local v171 = v_u_16:NextInteger(-45, 45)
											local v172 = math.rad(v171)
											local v173 = v_u_16:NextInteger(-45, 45)
											v165 = v170(v172, 0, (math.rad(v173)))
											v160 = tick()
											v158 = v_u_16:NextNumber(0.33, 0.66)
											v159 = v_u_16:NextNumber(5, 7)
										end
										if not (p_u_136.Parent and v_u_138.Parent) then
											v_u_157.Start.Sparks:Emit(5)
											v_u_157.Start.Sparks2:Emit(3)
											for _, v174 in v_u_157.Parent:GetDescendants() do
												if v174:IsA("BasePart") then
													v174.Transparency = 1
												elseif v174:IsA("Beam") or v174:IsA("PointLight") then
													v174.Enabled = false
												end
											end
											v_u_3:AddItem(v_u_157, 0.1)
											return
										end
									end
								end)
							end
							p_u_136.AncestryChanged:Once(function()
								-- upvalues: (copy) v_u_156, (ref) v_u_13, (ref) v_u_9, (copy) v_u_138
								v_u_156:Destroy()
								v_u_13:PlaySound(v_u_9.Yuta.MutualLove.MiniRikaToggle, v_u_138, game.SoundService.Effect)
							end)
							return
						end
					end
				else
					return
				end
			else
				return
			end
		end,
		["ShikigamiHit"] = function(p175)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v176 = p175:FindFirstChild("HumanoidRootPart")
			if v176 then
				v_u_13:Flash(p175, Color3.new(1, 1, 1))
				local v177 = v_u_13:PlaySound(v_u_9.Yuta.MutualLove.CleaveSlash, v176, game.SoundService.Effect)
				v177.PlaybackSpeed = 1.8
				v177.Volume = 1
			end
		end,
		["Dodge"] = function(p178)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_9
			local v179 = p178:FindFirstChild("HumanoidRootPart")
			if v179 then
				local v180 = p178:FindFirstChild("Humanoid")
				if v180 then
					local v181 = v_u_6.Animations.Yuta.Dodges:GetChildren()
					local v182 = v_u_6.Utils.Yuta.MutualLove.Shadow:Clone()
					v182.Parent = workspace.Effects
					v_u_3:AddItem(v182, 1)
					local v183 = next
					local v184, v185 = v182:GetDescendants()
					for _, v186 in v183, v184, v185 do
						if v186:IsA("BasePart") then
							v186.CollisionGroup = "Effects"
							v_u_4:Create(v186, TweenInfo.new(0.4), {
								["Transparency"] = 1
							}):Play()
							if p178:FindFirstChild(v186.Name) then
								v186.CFrame = p178:FindFirstChild(v186.Name).CFrame
								v186.Anchored = true
							end
						end
					end
					local v187 = next
					local v188, v189 = v180:GetPlayingAnimationTracks()
					for _, v190 in v187, v188, v189 do
						local v191 = v190.Name
						if string.sub(v191, 1, 5) == "Dodge" then
							v190:Stop(0)
						end
					end
					if v_u_5.Character == p178 then
						local v192 = v180:LoadAnimation(v181[math.random(1, #v181)])
						v192.Priority = Enum.AnimationPriority.Action2
						v192:Play(0)
					end
					v_u_13:PlaySound(v_u_9.Yuta.M1.Swing4, v179, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["JLFinisher"] = function(p193)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5
			local v194 = p193:FindFirstChild("HumanoidRootPart")
			if v194 then
				if p193:FindFirstChild("Humanoid") then
					local v_u_195 = v_u_6.Utils.Yuta.MutualLove.Shadow:Clone()
					v_u_195.Parent = workspace.Effects
					v_u_195.HumanoidRootPart.Anchored = true
					v_u_3:AddItem(v_u_195, 2)
					local v196 = next
					local v197, v198 = v_u_195:GetDescendants()
					for _, v199 in v196, v197, v198 do
						if v199:IsA("BasePart") and v199.Name ~= "HumanoidRootPart" then
							v199.CollisionGroup = "Effects"
							v199.Color = Color3.new(1, 1, 1)
							v199.Transparency = 0.5
						end
					end
					task.delay(1, function()
						-- upvalues: (copy) v_u_195, (ref) v_u_4
						local v200 = next
						local v201, v202 = v_u_195:GetDescendants()
						for _, v203 in v200, v201, v202 do
							if v203:IsA("BasePart") and v203.Name ~= "HumanoidRootPart" then
								v_u_4:Create(v203, TweenInfo.new(1), {
									["Transparency"] = 1
								}):Play()
							end
						end
					end)
					v_u_195.HumanoidRootPart.CFrame = v194.CFrame
					local v204 = v_u_195.Humanoid:LoadAnimation(v_u_6.Animations.Yuta.JacobLadderTarget)
					v204.Priority = Enum.AnimationPriority.Action2
					v204:Play(0)
					v_u_4:Create(v_u_195.HumanoidRootPart, TweenInfo.new(2), {
						["CFrame"] = v194.CFrame * CFrame.new(0, 15, 0)
					}):Play()
					if v_u_5.Character == p193 then
						workspace.CurrentCamera.CameraSubject = v_u_195.HumanoidRootPart
					end
				end
			else
				return
			end
		end,
		["Dodge2"] = function(p205)
			-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
			if v_u_5.Character == p205 then
				local v206 = p205:FindFirstChild("HumanoidRootPart")
				if v206 then
					local v207 = v_u_6.Animations.Yuta.Dodges:GetChildren()
					local v208 = v_u_8.Charles.Afterimage:Clone()
					v208.HumanoidRootPart.CFrame = v206.CFrame
					v208.Parent = workspace.Effects
					v_u_3:AddItem(v208, 0.6)
					local v209 = v208.Control:LoadAnimation(v207[math.random(1, #v207)])
					v209.Priority = Enum.AnimationPriority.Action2
					v209:Play(0, nil, 0.6)
					local v210 = Instance.new("Highlight", v208)
					v210.DepthMode = Enum.HighlightDepthMode.Occluded
					v210.FillColor = Color3.new(1, 1, 1)
					v210.FillTransparency = 0.9
					v210.OutlineTransparency = 0.6
					v_u_4:Create(v210, TweenInfo.new(0.4), {
						["OutlineTransparency"] = 1,
						["FillTransparency"] = 1
					}):Play()
					local v211 = next
					local v212, v213 = v208:GetDescendants()
					for _, v214 in v211, v212, v213 do
						if v214:IsA("BasePart") then
							v214.CollisionGroup = "Effects"
							v_u_4:Create(v214, TweenInfo.new(0.4), {
								["Transparency"] = 1
							}):Play()
						end
					end
				end
			else
				return
			end
		end,
		["TIB"] = function(p215)
			-- upvalues: (ref) v_u_8, (ref) v_u_11, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10, (copy) v_u_16, (ref) v_u_4
			local v_u_216 = v_u_8.Yuta.MutualLove.TIB:Clone()
			v_u_216.CFrame = p215
			v_u_216.Parent = workspace.Effects
			local v217 = p215.Position
			local v218 = v_u_11.ThicknessFade(0.3, 1)
			v_u_13:PlaySound(v_u_9.Yuta.MutualLove.Glass1, v_u_216, game.SoundService.Effect)
			v_u_216.Attachment.Glow:Emit(1)
			v_u_216.Attachment.Wind:Emit(15)
			v_u_216.Attachment.Air:Emit(25)
			if (workspace.CurrentCamera.CFrame.Position - p215.Position).Magnitude < 200 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
			end
			for v219 = 1, 8 do
				local v220 = v_u_16:NextNumber(20, 30)
				local v221 = CFrame.Angles
				local v222 = 45 * v219
				local v223 = (p215 * v221(0, 0, (math.rad(v222))) * CFrame.new(0, v220, 0)).Position
				local v_u_224 = v_u_11.CreateBolt({
					["Position1"] = v217,
					["Position2"] = v223,
					["PartCount"] = 6,
					["Thickness"] = v218,
					["Color"] = Color3.new(0.66, 1, 1),
					["Parent"] = v_u_216.Glass
				})
				for _, v225 in v_u_224 do
					v225.Transparency = 1
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_224, (ref) v_u_4, (copy) v_u_216, (ref) v_u_13, (ref) v_u_9, (ref) v_u_16
					for _, v226 in v_u_224 do
						task.wait()
						v226.Transparency = 0
						v_u_4:Create(v226, TweenInfo.new(0.12), {
							["Size"] = v226.Size * Vector3.new(0.3, 0.3, 1)
						}):Play()
					end
					task.wait(0.3)
					for v227, v228 in v_u_224 do
						local v229 = v_u_216.Shatter:Clone()
						v229.Parent = v228
						v228.Transparency = 1
						if v227 % 2 == 0 then
							v229:Emit(1)
						end
						v_u_13:PlaySound(v_u_9.Yuta.MutualLove.Glass2, v228, game.SoundService.Effect).PlaybackSpeed = v_u_16:NextNumber(1, 1.5)
						task.wait(0.05)
					end
				end)
			end
			task.wait(3)
			v_u_216:Destroy()
		end,
		["TIBHit"] = function(p230)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v231 = p230:FindFirstChild("HumanoidRootPart")
			if v231 then
				v_u_13:Flash(p230, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Itadori.CraniumSmash.Hit2, v231, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Todo.BruteForce.Hit, v231, game.SoundService.Effect)
			end
		end,
		["Shatter"] = function(p232)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_4
			local v233 = v_u_8.Domain:Clone()
			v233.Transparency = 1
			v233.CanCollide = false
			v233.Position = p232
			v233.Shatter.Color = ColorSequence.new(Color3.new(0, 0, 0))
			v233.Parent = workspace.Effects
			v_u_3:AddItem(v233, 3)
			for _, v234 in v233:GetChildren() do
				if v234.Name == "Shatter" then
					v234:Emit(100)
				else
					v234:Destroy()
				end
			end
			v_u_13:PlaySound(v_u_9.Itadori.MalevolantShrine.Shatter, v233, game.SoundService.Effect)
			v233.Transparency = 0
			v233.Color = Color3.new(0, 0, 0)
			v_u_4:Create(v233, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v233.Position).Magnitude > 150 then
					return
				end
				local v235 = Random.new()
				local v236 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v237 = v_u_8.Gojo.Shard:Clone()
					local v238 = v235:NextUnitVector().Unit
					local v239 = math.random(1, 8)
					local v240 = math.random
					v237.Size = Vector3.new(0.1, v239, v240(1, 8))
					v237.CFrame = CFrame.lookAlong(p232, v238) * CFrame.Angles(1.5707963267948966, 0, 0) + v238 * 37.5
					v237.CFrame = v237.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v237.Color = Color3.new(0, 0, 0)
					v237.CanCollide = true
					v237.CollisionGroup = "Effects"
					v237.Parent = workspace.Effects
					local v241 = math.random(-50, 50)
					local v242 = math.random(-50, 50)
					local v243 = math.random
					v237.RotVelocity = Vector3.new(v241, v242, v243(-50, 50))
					v237.Transparency = 0
					v237.Material = Enum.Material.Neon
					v_u_4:Create(v237, v236, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_3:AddItem(v237, 4)
				end
			end
		end,
		["JacobLadder"] = function(p244)
			-- upvalues: (ref) v_u_8, (ref) v_u_13, (ref) v_u_9, (ref) v_u_4, (ref) v_u_12, (ref) v_u_10, (copy) v_u_16
			local v_u_245 = p244:FindFirstChild("HumanoidRootPart")
			if not v_u_245 then
				return
			end
			local v_u_246 = v_u_8.Yuta.MutualLove.JLSky:Clone()
			local v247 = v_u_8.Yuta.MutualLove.JLBeam:Clone()
			local v_u_248 = v_u_246:FindFirstChild("SurfaceGui")
			v_u_13:PlaySound(v_u_9.Yuta.JacobLadder, v_u_245, game.SoundService.Effect)
			task.spawn(function()
				-- upvalues: (copy) v_u_248, (ref) v_u_4, (copy) v_u_246, (copy) v_u_245
				for _, v_u_249 in v_u_248:GetChildren() do
					local v_u_250 = v_u_249.Size
					local v_u_251 = TweenInfo.new(0.6)
					v_u_249.Size = UDim2.fromScale(0, 0)
					task.delay(v_u_249:GetAttribute("Delay"), function()
						-- upvalues: (ref) v_u_4, (copy) v_u_249, (copy) v_u_251, (copy) v_u_250
						v_u_4:Create(v_u_249, v_u_251, {
							["Size"] = v_u_250
						}):Play()
					end)
				end
				v_u_246.Parent = workspace.Effects
				v_u_246.Position = v_u_245.Position + Vector3.new(0, 50, 0)
				task.delay(0.6, function()
					-- upvalues: (ref) v_u_246
					v_u_246.Glow.Enabled = true
				end)
				v_u_248.Star.Rotation = 0
				v_u_4:Create(v_u_248.Star, TweenInfo.new(4.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
					["Rotation"] = 485.99999999999994
				}):Play()
				v_u_248.Crosses.Rotation = 0
				v_u_4:Create(v_u_248.Crosses, TweenInfo.new(4.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
					["Rotation"] = -162
				}):Play()
				task.wait(4.5)
				v_u_246.Glow.Enabled = false
				for _, v_u_252 in v_u_248:GetChildren() do
					local v_u_253 = TweenInfo.new(0.4)
					task.delay(0.7 - v_u_252:GetAttribute("Delay"), function()
						-- upvalues: (ref) v_u_4, (copy) v_u_252, (copy) v_u_253
						v_u_4:Create(v_u_252, v_u_253, {
							["Size"] = UDim2.fromScale(0, 0)
						}):Play()
					end)
				end
				task.wait(0.7)
				for _, v254 in v_u_248.Crosses:GetChildren() do
					if v254:IsA("Frame") then
						v_u_4:Create(v254, TweenInfo.new(0.2), {
							["Size"] = UDim2.fromScale(0, 0)
						}):Play()
					end
				end
				task.wait(0.2)
				v_u_246:Destroy()
			end)
			for _, v255 in v247:GetDescendants() do
				if v255:IsA("ParticleEmitter") or v255:IsA("Beam") then
					v255.Enabled = false
				end
			end
			task.wait(2.25)
			v247.Parent = workspace.Effects
			for _, v256 in v247:GetDescendants() do
				if v256:IsA("ParticleEmitter") or v256:IsA("Beam") then
					if v256:IsA("Beam") then
						local v257 = v256.Width0
						local v258 = v256.Width1
						v256.Width0 = 0
						v256.Width1 = 0
						v_u_4:Create(v256, TweenInfo.new(1), {
							["Width0"] = v257,
							["Width1"] = v258
						}):Play()
					end
					v256.Enabled = true
				end
			end
			v247.Body.Size = Vector3.new(100, 0, 0)
			v_u_4:Create(v247.Body, TweenInfo.new(1), {
				["Size"] = Vector3.new(100, 15, 15)
			}):Play()
			local v259
			if (v_u_12.CFrame.Position - v_u_245.Position).Magnitude < 180 then
				v259 = v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.HeavyHit)
			else
				v259 = nil
			end
			local v260 = Instance.new("Highlight")
			v260.FillColor = Color3.new()
			v260.FillTransparency = 0.4
			v260.OutlineTransparency = 1
			v260.Parent = p244
			local v261 = tick()
			while true do
				task.wait()
				v_u_246.Position = v_u_245.Position + Vector3.new(0, 50, 0)
				v247.Position = v_u_245.Position + Vector3.new(0, 47, 0)
				v247.Body.Position = v_u_245.Position
				if tick() - v261 >= 1 then
					v247.Body.Size = Vector3.new(100, 15, 15) + v_u_16:NextUnitVector() * Vector3.new(0, 3, 3)
				end
				if tick() - v261 >= 3 then
					if v259 then
						v259:StartFadeOut(0.5)
					end
					v_u_4:Create(v247.Body, TweenInfo.new(0.5), {
						["Size"] = Vector3.new(100, 0, 0)
					}):Play()
					for _, v262 in v247:GetDescendants() do
						if v262:IsA("ParticleEmitter") or v262:IsA("Beam") then
							if v262:IsA("Beam") then
								v_u_4:Create(v262, TweenInfo.new(0.5), {
									["Width0"] = 0,
									["Width1"] = 0
								}):Play()
							else
								v262.Enabled = false
							end
						elseif v262:IsA("PointLight") or v262:IsA("SpotLight") then
							v_u_4:Create(v262, TweenInfo.new(0.5), {
								["Brightness"] = 0
							}):Play()
						end
					end
					v260:Destroy()
					task.wait(0.5)
					v247:Destroy()
					return
				end
			end
		end
	}
	v_u_14.Effects:Connect(function(p264, ...)
		-- upvalues: (copy) v_u_263
		local v265 = v_u_263[p264]
		if v265 then
			v265(...)
		end
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_14, (copy) v_u_1, (ref) v_u_13
	v_u_14 = v_u_1.GetService("MutualLoveService")
	v_u_13 = v_u_1.GetController("FXController")
end
return v15