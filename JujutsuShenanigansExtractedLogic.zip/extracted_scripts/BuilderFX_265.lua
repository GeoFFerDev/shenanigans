-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game.ReplicatedStorage.Utils.BuilderFX
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v4 = game:GetService("Debris")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = require(v6.Modules.CameraShaker)
local v_u_8 = v_u_2:IsClient()
if v_u_8 then
	v_u_8 = require(v6.Modules.BloodyZee)
end
local v_u_11 = v_u_2:IsServer() and {
	["AddItem"] = function(_, p_u_9, p10)
		task.delay(p10, function()
			-- upvalues: (copy) p_u_9
			if p_u_9 then
				p_u_9:Destroy()
			end
		end)
	end
} or v4
local function v_u_26(p12, p13, p14)
	local v15 = p13.POSITION
	local v16
	if v15 then
		local v17 = string.split
		local v18 = unpack
		v16 = Vector3.new(v18(v17(v15)))
	else
		v16 = Vector3.new(0, 0, 0)
	end
	local v19 = CFrame.new(-v16.X, v16.Y, -v16.Z)
	local v20 = p12 and p12.CFrame or CFrame.new()
	if not p14 then
		return v20 * v19
	end
	local v21 = p13["ALT POSITION"]
	local v22
	if v21 then
		local v23 = string.split
		local v24 = unpack
		v22 = Vector3.new(v24(v23(v21)))
	else
		v22 = Vector3.new(0, 0, 0)
	end
	local v25 = CFrame.new(-v22.X, v22.Y, -v22.Z)
	return v20 * v19 * v25
end
local function v_u_31(p27)
	local v28 = Color3.fromRGB
	local v29 = string.split
	local v30 = p27["ALT COLOR"]
	return v28(unpack(v29(v30)))
end
local function v_u_51(p32, p33)
	local v34 = p33.SIZE
	local v35 = tonumber(v34)
	if workspace:GetAttribute("Creator") then
		v35 = math.clamp(v35, 0, 40)
	end
	local v36 = v35 or 1
	local v37 = p33.SIZE
	local v38 = tonumber(v37)
	if workspace:GetAttribute("Creator") then
		v38 = math.clamp(v38, 0, 40)
	end
	local v39 = p33["ALT SIZE"] or 1
	local v40 = v38 * tonumber(v39)
	if workspace:GetAttribute("Creator") then
		v40 = math.clamp(v40, 0, 40)
	end
	local v41 = v40 or v36
	local v42 = {}
	for _, v43 in p32 do
		local v44 = v43.Time
		local v45 = math.clamp(v44, 0, 1)
		local v46 = v36 + (v41 - v36) * v45
		local v47 = NumberSequenceKeypoint.new
		local v48 = v43.Time
		local v49 = v43.Value * v46
		local v50 = v43.Envelope * v46
		table.insert(v42, v47(v48, v49, v50))
	end
	return NumberSequence.new(v42)
end
local function v_u_55(p_u_52)
	-- upvalues: (copy) v_u_55
	if p_u_52 then
		for v53 = #p_u_52, 1, -1 do
			local v54 = p_u_52[v53]
			if v54 then
				table.remove(p_u_52, v53)
				if typeof(v54) == "RBXScriptConnection" then
					v54:Disconnect()
				elseif type(v54) == "function" then
					pcall(v54)
				elseif v54:IsA("AnimationTrack") then
					v54:Stop()
				else
					v54:Destroy()
				end
			end
		end
		task.defer(function()
			-- upvalues: (ref) p_u_52, (ref) v_u_55
			if #p_u_52 <= 0 then
				p_u_52 = nil
			else
				v_u_55(p_u_52)
			end
		end)
	end
end
local v_u_56 = {}
local function v_u_70(p_u_57, p58)
	-- upvalues: (copy) v_u_55, (copy) v_u_56
	local v_u_59 = {}
	local v60 = p_u_57.Destroying
	local function v61()
		-- upvalues: (ref) v_u_55, (copy) v_u_59, (ref) v_u_56, (copy) p_u_57
		v_u_55(v_u_59, true)
		v_u_56[p_u_57] = nil
	end
	table.insert(v_u_59, v60:Once(v61))
	if p58["VISUAL TAG"] then
		local v_u_62 = p58["VISUAL TAG"]
		v_u_56[p_u_57] = v_u_56[p_u_57] or {}
		v_u_56[p_u_57][v_u_62] = v_u_56[p_u_57][v_u_62] or {}
		local function v_u_63()
			-- upvalues: (ref) v_u_55, (copy) v_u_59
			v_u_55(v_u_59)
		end
		local v64 = v_u_56[p_u_57][v_u_62]
		table.insert(v64, v_u_63)
		local function v66()
			-- upvalues: (ref) v_u_56, (copy) p_u_57, (copy) v_u_62, (copy) v_u_63
			for v65 = #v_u_56[p_u_57][v_u_62], 1, -1 do
				if v_u_56[p_u_57][v_u_62][v65] == v_u_63 then
					table.remove(v_u_56[p_u_57][v_u_62], v65)
					break
				end
			end
			if #v_u_56[p_u_57][v_u_62] <= 0 then
				v_u_56[p_u_57][v_u_62] = nil
			end
		end
		table.insert(v_u_59, v66)
	end
	local v67 = task.delay
	local v68 = p58.TIME
	local v69 = tonumber(v68)
	if workspace:GetAttribute("Creator") then
		v69 = math.clamp(v69, 0, 10)
	end
	v67(v69 + 4, function()
		-- upvalues: (copy) p_u_57, (ref) v_u_55, (copy) v_u_59
		if p_u_57 then
			v_u_55(v_u_59)
		end
	end)
	return v_u_59
end
return {
	["Cancel"] = function(p71, p72)
		-- upvalues: (copy) v_u_56
		local v73 = p71:FindFirstChild("HumanoidRootPart")
		if v73 then
			if p72.RELATIVE ~= nil then
				p71 = p72.RELATIVE
			end
			if not p71:IsA("BasePart") then
				if p71:FindFirstChild(p72["BODY PART"]) then
					p71 = p71[p72["BODY PART"]]
				else
					p71 = nil
				end
			end
			local v74 = p71 or v73
			local v75 = p72["VISUAL TAG"]
			if v75 then
				if v_u_56[v74] and v_u_56[v74][v75] then
					for v76 = #v_u_56[v74][v75], 1, -1 do
						v_u_56[v74][v75][v76]()
					end
				end
			else
				return
			end
		else
			return
		end
	end,
	["Slash"] = function(p77, p78)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (copy) v_u_3, (ref) v_u_11
		local v79 = p77:FindFirstChild("HumanoidRootPart")
		if v79 then
			if p78.RELATIVE ~= nil then
				p77 = p78.RELATIVE
			end
			if not p77:IsA("BasePart") then
				if p77:FindFirstChild(p78["BODY PART"]) then
					p77 = p77[p78["BODY PART"]]
				else
					p77 = nil
				end
			end
			local v80 = p77 or v79
			local v81 = v_u_70(v80, p78)
			local v82 = v_u_1.Slash:Clone()
			v82.Weld.Part0 = v80
			local v83 = v82.Weld
			local v84 = CFrame.new
			local v85 = p78.POSITION
			local v86
			if v85 then
				local v87 = string.split
				local v88 = unpack
				v86 = Vector3.new(v88(v87(v85)))
			else
				v86 = Vector3.new(0, 0, 0)
			end
			v83.C0 = v84(v86)
			local v89 = v82.Weld
			local v90 = p78.ROTATION
			local v91
			if v90 then
				local v92 = string.split
				local v93 = unpack
				v91 = Vector3.new(v93(v92(v90)))
			else
				v91 = Vector3.new(0, 0, 0)
			end
			local v94 = CFrame.fromOrientation
			local v95 = v91.X
			local v96 = math.rad(v95)
			local v97 = v91.Y
			local v98 = math.rad(v97)
			local v99 = v91.Z
			v89.C1 = v94(v96, v98, (math.rad(v99))) * CFrame.Angles(0, 3.141592653589793, 0)
			local v100 = v82.Part1.Mesh
			local v101 = v100.Scale
			local v102 = p78.SIZE
			local v103 = tonumber(v102)
			if workspace:GetAttribute("Creator") then
				v103 = math.clamp(v103, 0, 40)
			end
			v100.Scale = v101 * v103
			local v104 = v82.Part2.Mesh
			local v105 = v104.Scale
			local v106 = p78.SIZE
			local v107 = tonumber(v106)
			if workspace:GetAttribute("Creator") then
				v107 = math.clamp(v107, 0, 40)
			end
			v104.Scale = v105 * v107
			for _, v108 in pairs(v82.Part1:GetChildren()) do
				if v108:IsA("Decal") then
					local v109 = Color3.fromRGB
					local v110 = string.split
					local v111 = p78.COLOR
					v108.Color3 = v109(unpack(v110(v111)))
					local v112 = p78.OPACITY
					v108.Transparency = tonumber(v112)
					local v113 = v_u_3
					local v114 = TweenInfo.new
					local v115 = p78.TIME
					local v116 = tonumber(v115)
					if workspace:GetAttribute("Creator") then
						v116 = math.clamp(v116, 0, 10)
					end
					local v117
					if p78["EASING STYLE"] then
						v117 = Enum.EasingStyle[p78["EASING STYLE"]]
					else
						v117 = Enum.EasingStyle.Linear
					end
					local v118
					if p78["EASING DIRECTION"] then
						v118 = Enum.EasingDirection[p78["EASING DIRECTION"]]
					else
						v118 = Enum.EasingDirection.In
					end
					local v119 = v114(v116, v117, v118)
					local v120 = {}
					local v121 = p78["ALT OPACITY"]
					v120.Transparency = tonumber(v121)
					v113:Create(v108, v119, v120):Play()
				end
			end
			for _, v122 in pairs(v82.Part2:GetChildren()) do
				if v122:IsA("Decal") then
					local v123 = Color3.fromRGB
					local v124 = string.split
					local v125 = p78["ALT COLOR"]
					v122.Color3 = v123(unpack(v124(v125)))
					local v126 = p78.OPACITY
					v122.Transparency = tonumber(v126)
					local v127 = v_u_3
					local v128 = TweenInfo.new
					local v129 = p78.TIME
					local v130 = tonumber(v129)
					if workspace:GetAttribute("Creator") then
						v130 = math.clamp(v130, 0, 10)
					end
					local v131
					if p78["EASING STYLE"] then
						v131 = Enum.EasingStyle[p78["EASING STYLE"]]
					else
						v131 = Enum.EasingStyle.Linear
					end
					local v132
					if p78["EASING DIRECTION"] then
						v132 = Enum.EasingDirection[p78["EASING DIRECTION"]]
					else
						v132 = Enum.EasingDirection.In
					end
					local v133 = v128(v130, v131, v132)
					local v134 = {}
					local v135 = p78["ALT OPACITY"]
					v134.Transparency = tonumber(v135)
					v127:Create(v122, v133, v134):Play()
				end
			end
			v82.Parent = workspace.Effects
			local v136 = v_u_3
			local v137 = v82.Part1.Mesh
			local v138 = TweenInfo.new
			local v139 = p78.TIME
			local v140 = tonumber(v139)
			if workspace:GetAttribute("Creator") then
				v140 = math.clamp(v140, 0, 10)
			end
			local v141
			if p78["EASING STYLE"] then
				v141 = Enum.EasingStyle[p78["EASING STYLE"]]
			else
				v141 = Enum.EasingStyle.Linear
			end
			local v142
			if p78["EASING DIRECTION"] then
				v142 = Enum.EasingDirection[p78["EASING DIRECTION"]]
			else
				v142 = Enum.EasingDirection.In
			end
			local v143 = v138(v140, v141, v142)
			local v144 = {}
			local v145 = v82.Part1.Mesh.Scale
			local v146 = p78.SIZE
			local v147 = tonumber(v146)
			if workspace:GetAttribute("Creator") then
				v147 = math.clamp(v147, 0, 40)
			end
			local v148 = p78["ALT SIZE"] or 1
			local v149 = v147 * tonumber(v148)
			if workspace:GetAttribute("Creator") then
				v149 = math.clamp(v149, 0, 40)
			end
			v144.Scale = v145 * v149
			v136:Create(v137, v143, v144):Play()
			local v150 = v_u_3
			local v151 = v82.Part2.Mesh
			local v152 = TweenInfo.new
			local v153 = p78.TIME
			local v154 = tonumber(v153)
			if workspace:GetAttribute("Creator") then
				v154 = math.clamp(v154, 0, 10)
			end
			local v155
			if p78["EASING STYLE"] then
				v155 = Enum.EasingStyle[p78["EASING STYLE"]]
			else
				v155 = Enum.EasingStyle.Linear
			end
			local v156
			if p78["EASING DIRECTION"] then
				v156 = Enum.EasingDirection[p78["EASING DIRECTION"]]
			else
				v156 = Enum.EasingDirection.In
			end
			local v157 = v152(v154, v155, v156)
			local v158 = {}
			local v159 = v82.Part2.Mesh.Scale
			local v160 = p78.SIZE
			local v161 = tonumber(v160)
			if workspace:GetAttribute("Creator") then
				v161 = math.clamp(v161, 0, 40)
			end
			local v162 = p78["ALT SIZE"] or 1
			local v163 = v161 * tonumber(v162)
			if workspace:GetAttribute("Creator") then
				v163 = math.clamp(v163, 0, 40)
			end
			v158.Scale = v159 * v163
			v150:Create(v151, v157, v158):Play()
			local v164 = v_u_11
			local v165 = p78.TIME
			local v166 = tonumber(v165)
			if workspace:GetAttribute("Creator") then
				v166 = math.clamp(v166, 0, 10)
			end
			v164:AddItem(v82, v166)
			local v167 = v_u_3
			local v168 = v82.Weld
			local v169 = TweenInfo.new
			local v170 = p78.TIME
			local v171 = tonumber(v170)
			if workspace:GetAttribute("Creator") then
				v171 = math.clamp(v171, 0, 10)
			end
			local v172
			if p78["EASING STYLE"] then
				v172 = Enum.EasingStyle[p78["EASING STYLE"]]
			else
				v172 = Enum.EasingStyle.Linear
			end
			local v173
			if p78["EASING DIRECTION"] then
				v173 = Enum.EasingDirection[p78["EASING DIRECTION"]]
			else
				v173 = Enum.EasingDirection.In
			end
			local v174 = v169(v171, v172, v173)
			local v175 = {}
			local v176 = CFrame.new
			local v177 = p78["ALT POSITION"]
			local v178
			if v177 then
				local v179 = string.split
				local v180 = unpack
				v178 = Vector3.new(v180(v179(v177)))
			else
				v178 = Vector3.new(0, 0, 0)
			end
			v175.C0 = v176(v178)
			local v181 = p78["ALT ROTATION"] or p78.ROTATION
			local v182
			if v181 then
				local v183 = string.split
				local v184 = unpack
				v182 = Vector3.new(v184(v183(v181)))
			else
				v182 = Vector3.new(0, 0, 0)
			end
			local v185 = CFrame.fromOrientation
			local v186 = v182.X
			local v187 = math.rad(v186)
			local v188 = v182.Y
			local v189 = math.rad(v188)
			local v190 = v182.Z
			v175.C1 = v185(v187, v189, (math.rad(v190))) * CFrame.Angles(0, 3.141592653589793, 0)
			v167:Create(v168, v174, v175):Play()
			local v191 = p78["ALT POSITION"]
			local v192
			if v191 then
				local v193 = string.split
				local v194 = unpack
				v192 = Vector3.new(v194(v193(v191)))
			else
				v192 = Vector3.new(0, 0, 0)
			end
			if v192 ~= Vector3.new(0, 0, 0) then
				local v195 = Instance.new("Part")
				v195.Transparency = 1
				v195.CanCollide = false
				v195.Anchored = true
				v195.Size = Vector3.new(0, 0, 0)
				v195.CFrame = v80.CFrame
				v195.Parent = v82
				v82.Weld.Part0 = v195
			end
			table.insert(v81, v82)
		end
	end,
	["Sphere"] = function(p196, p197)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26
		local v198 = p196:FindFirstChild("HumanoidRootPart")
		if v198 then
			if p197.RELATIVE ~= nil then
				p196 = p197.RELATIVE
			end
			if not p196:IsA("BasePart") then
				if p196:FindFirstChild(p197["BODY PART"]) then
					p196 = p196[p197["BODY PART"]]
				else
					p196 = nil
				end
			end
			local v199 = p196 or v198
			local v200 = v_u_70(v199, p197)
			local v201 = v_u_1.Ball:Clone()
			local v202 = p197.POSITION
			local v203
			if v202 then
				local v204 = string.split
				local v205 = unpack
				v203 = Vector3.new(v205(v204(v202)))
			else
				v203 = Vector3.new(0, 0, 0)
			end
			local v206 = CFrame.new(-v203.X, v203.Y, -v203.Z)
			local v207 = (v199 and v199.CFrame or CFrame.new()) * v206
			local v208 = p197.ROTATION
			local v209
			if v208 then
				local v210 = string.split
				local v211 = unpack
				v209 = Vector3.new(v211(v210(v208)))
			else
				v209 = Vector3.new(0, 0, 0)
			end
			local v212 = CFrame.fromOrientation
			local v213 = v209.X
			local v214 = math.rad(v213)
			local v215 = v209.Y
			local v216 = math.rad(v215)
			local v217 = v209.Z
			v201.CFrame = v207 * v212(v214, v216, (math.rad(v217)))
			local v218 = Vector3.new(1, 1, 1)
			local v219 = p197.SIZE
			local v220 = tonumber(v219)
			if workspace:GetAttribute("Creator") then
				v220 = math.clamp(v220, 0, 40)
			end
			v201.Size = v218 * v220
			local v221 = Color3.fromRGB
			local v222 = string.split
			local v223 = p197.COLOR
			v201.Color = v221(unpack(v222(v223)))
			local v224 = p197.OPACITY
			v201.Transparency = tonumber(v224)
			v201.Parent = workspace.Effects
			local v225 = p197["ALT POSITION"]
			local v226
			if v225 then
				local v227 = string.split
				local v228 = unpack
				v226 = Vector3.new(v228(v227(v225)))
			else
				v226 = Vector3.new(0, 0, 0)
			end
			local v229 = v226 == Vector3.new(0, 0, 0)
			if v229 then
				v201.Massless = true
				v201.Anchored = false
				local v230 = Instance.new("Weld")
				v230.Part0 = v199
				v230.Part1 = v201
				local v231 = p197.POSITION
				local v232
				if v231 then
					local v233 = string.split
					local v234 = unpack
					v232 = Vector3.new(v234(v233(v231)))
				else
					v232 = Vector3.new(0, 0, 0)
				end
				local v235 = CFrame.new(-v232.X, v232.Y, -v232.Z)
				local v236 = CFrame.new() * v235
				local v237 = p197.ROTATION
				local v238
				if v237 then
					local v239 = string.split
					local v240 = unpack
					v238 = Vector3.new(v240(v239(v237)))
				else
					v238 = Vector3.new(0, 0, 0)
				end
				local v241 = CFrame.fromOrientation
				local v242 = v238.X
				local v243 = math.rad(v242)
				local v244 = v238.Y
				local v245 = math.rad(v244)
				local v246 = v238.Z
				v230.C0 = v236 * v241(v243, v245, (math.rad(v246)))
				v230.Parent = v201
			end
			local v247 = v_u_11
			local v248 = p197.TIME
			local v249 = tonumber(v248)
			if workspace:GetAttribute("Creator") then
				v249 = math.clamp(v249, 0, 10)
			end
			v247:AddItem(v201, v249)
			local v250 = v_u_3
			local v251 = TweenInfo.new
			local v252 = p197.TIME
			local v253 = tonumber(v252)
			if workspace:GetAttribute("Creator") then
				v253 = math.clamp(v253, 0, 10)
			end
			local v254
			if p197["EASING STYLE"] then
				v254 = Enum.EasingStyle[p197["EASING STYLE"]]
			else
				v254 = Enum.EasingStyle.Linear
			end
			local v255
			if p197["EASING DIRECTION"] then
				v255 = Enum.EasingDirection[p197["EASING DIRECTION"]]
			else
				v255 = Enum.EasingDirection.In
			end
			local v256 = v251(v253, v254, v255)
			local v257 = {}
			local v258 = Vector3.new(1, 1, 1)
			local v259 = p197.SIZE
			local v260 = tonumber(v259)
			if workspace:GetAttribute("Creator") then
				v260 = math.clamp(v260, 0, 40)
			end
			local v261 = p197["ALT SIZE"] or 1
			local v262 = v260 * tonumber(v261)
			if workspace:GetAttribute("Creator") then
				v262 = math.clamp(v262, 0, 40)
			end
			v257.Size = v258 * v262
			local v263 = Color3.fromRGB
			local v264 = string.split
			local v265 = p197["ALT COLOR"]
			v257.Color = v263(unpack(v264(v265)))
			local v266 = p197["ALT OPACITY"]
			v257.Transparency = tonumber(v266)
			local v267
			if v229 then
				v267 = nil
			else
				local v268 = v_u_26(v201, p197, true)
				local v269 = p197["ALT ROTATION"] or p197.ROTATION
				local v270
				if v269 then
					local v271 = string.split
					local v272 = unpack
					v270 = Vector3.new(v272(v271(v269)))
				else
					v270 = Vector3.new(0, 0, 0)
				end
				local v273 = CFrame.fromOrientation
				local v274 = v270.X
				local v275 = math.rad(v274)
				local v276 = v270.Y
				local v277 = math.rad(v276)
				local v278 = v270.Z
				v267 = v268 * v273(v275, v277, (math.rad(v278))) or nil
			end
			v257.CFrame = v267
			v250:Create(v201, v256, v257):Play()
			table.insert(v200, v201)
		end
	end,
	["Mesh"] = function(p279, p_u_280)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (copy) v_u_3, (copy) v_u_26
		local v281 = p279:FindFirstChild("HumanoidRootPart")
		if v281 then
			if p_u_280.RELATIVE ~= nil then
				p279 = p_u_280.RELATIVE
			end
			if not p279:IsA("BasePart") then
				if p279:FindFirstChild(p_u_280["BODY PART"]) then
					p279 = p279[p_u_280["BODY PART"]]
				else
					p279 = nil
				end
			end
			local v_u_282 = p279 or v281
			local v283 = v_u_70(v_u_282, p_u_280)
			local v_u_284 = v_u_1.Ball:Clone()
			local v285 = v_u_282
			local v286 = p_u_280.POSITION
			local v287
			if v286 then
				local v288 = string.split
				local v289 = unpack
				v287 = Vector3.new(v289(v288(v286)))
			else
				v287 = Vector3.new(0, 0, 0)
			end
			local v290 = CFrame.new(-v287.X, v287.Y, -v287.Z)
			local v291 = (v285 and v285.CFrame or CFrame.new()) * v290
			local v292 = p_u_280.ROTATION
			local v293
			if v292 then
				local v294 = string.split
				local v295 = unpack
				v293 = Vector3.new(v295(v294(v292)))
			else
				v293 = Vector3.new(0, 0, 0)
			end
			local v296 = CFrame.fromOrientation
			local v297 = v293.X
			local v298 = math.rad(v297)
			local v299 = v293.Y
			local v300 = math.rad(v299)
			local v301 = v293.Z
			v_u_284.CFrame = v291 * v296(v298, v300, (math.rad(v301)))
			local v302 = Vector3.new(1, 1, 1)
			local v303 = p_u_280.SIZE
			local v304 = tonumber(v303)
			if workspace:GetAttribute("Creator") then
				v304 = math.clamp(v304, 0, 40)
			end
			v_u_284.Size = v302 * v304
			local v305 = Color3.fromRGB
			local v306 = string.split
			local v307 = p_u_280.COLOR
			v_u_284.Color = v305(unpack(v306(v307)))
			local v308 = p_u_280.OPACITY
			v_u_284.Transparency = tonumber(v308)
			v_u_284.Shape = Enum.PartType.Block
			local v309 = Instance.new("SpecialMesh")
			local v310 = p_u_280.AMOUNT
			v309.MeshId = "rbxassetid://" .. tonumber(v310)
			local v311 = p_u_280.TEXTURE or 0
			if tonumber(v311) ~= 0 then
				local v312 = p_u_280.TEXTURE or 0
				v309.TextureId = "rbxassetid://" .. tonumber(v312)
			end
			local v313 = Vector3.new(1, 1, 1)
			local v314 = p_u_280.SIZE
			local v315 = tonumber(v314)
			if workspace:GetAttribute("Creator") then
				v315 = math.clamp(v315, 0, 40)
			end
			v309.Scale = v313 * v315
			v309.Parent = v_u_284
			local v316 = v_u_3
			local v317 = TweenInfo.new
			local v318 = p_u_280.TIME
			local v319 = tonumber(v318)
			local v320
			if p_u_280["EASING STYLE"] then
				v320 = Enum.EasingStyle[p_u_280["EASING STYLE"]]
			else
				v320 = Enum.EasingStyle.Linear
			end
			local v321
			if p_u_280["EASING DIRECTION"] then
				v321 = Enum.EasingDirection[p_u_280["EASING DIRECTION"]]
			else
				v321 = Enum.EasingDirection.In
			end
			local v322 = v317(v319, v320, v321)
			local v323 = {}
			local v324 = Vector3.new(1, 1, 1)
			local v325 = p_u_280.SIZE
			local v326 = tonumber(v325)
			if workspace:GetAttribute("Creator") then
				v326 = math.clamp(v326, 0, 40)
			end
			local v327 = p_u_280["ALT SIZE"] or 1
			local v328 = v326 * tonumber(v327)
			if workspace:GetAttribute("Creator") then
				v328 = math.clamp(v328, 0, 40)
			end
			v323.Scale = v324 * v328
			v316:Create(v309, v322, v323):Play()
			v_u_284.Parent = workspace.Effects
			local v329 = p_u_280["ALT POSITION"]
			local v330
			if v329 then
				local v331 = string.split
				local v332 = unpack
				v330 = Vector3.new(v332(v331(v329)))
			else
				v330 = Vector3.new(0, 0, 0)
			end
			local v333 = v330 == Vector3.new(0, 0, 0)
			if v333 then
				v_u_284.Massless = true
				v_u_284.Anchored = false
				local v334 = Instance.new("Weld")
				v334.Part0 = v_u_282
				v334.Part1 = v_u_284
				local v335 = p_u_280.POSITION
				local v336
				if v335 then
					local v337 = string.split
					local v338 = unpack
					v336 = Vector3.new(v338(v337(v335)))
				else
					v336 = Vector3.new(0, 0, 0)
				end
				local v339 = CFrame.new(-v336.X, v336.Y, -v336.Z)
				local v340 = CFrame.new() * v339
				local v341 = p_u_280.ROTATION
				local v342
				if v341 then
					local v343 = string.split
					local v344 = unpack
					v342 = Vector3.new(v344(v343(v341)))
				else
					v342 = Vector3.new(0, 0, 0)
				end
				local v345 = CFrame.fromOrientation
				local v346 = v342.X
				local v347 = math.rad(v346)
				local v348 = v342.Y
				local v349 = math.rad(v348)
				local v350 = v342.Z
				v334.C0 = v340 * v345(v347, v349, (math.rad(v350)))
				v334.Parent = v_u_284
			end
			local v351 = v_u_3
			local v352 = TweenInfo.new
			local v353 = p_u_280.TIME
			local v354 = tonumber(v353)
			local v355
			if p_u_280["EASING STYLE"] then
				v355 = Enum.EasingStyle[p_u_280["EASING STYLE"]]
			else
				v355 = Enum.EasingStyle.Linear
			end
			local v356
			if p_u_280["EASING DIRECTION"] then
				v356 = Enum.EasingDirection[p_u_280["EASING DIRECTION"]]
			else
				v356 = Enum.EasingDirection.In
			end
			local v357 = v352(v354, v355, v356)
			local v358 = {}
			local v359 = Vector3.new(1, 1, 1)
			local v360 = p_u_280.SIZE
			local v361 = tonumber(v360)
			if workspace:GetAttribute("Creator") then
				v361 = math.clamp(v361, 0, 40)
			end
			local v362 = p_u_280["ALT SIZE"] or 1
			local v363 = v361 * tonumber(v362)
			if workspace:GetAttribute("Creator") then
				v363 = math.clamp(v363, 0, 40)
			end
			v358.Size = v359 * v363
			local v364 = Color3.fromRGB
			local v365 = string.split
			local v366 = p_u_280["ALT COLOR"]
			v358.Color = v364(unpack(v365(v366)))
			local v367 = p_u_280["ALT OPACITY"]
			v358.Transparency = tonumber(v367)
			local v368
			if v333 then
				v368 = nil
			else
				local v369 = v_u_26(v_u_284, p_u_280, true)
				local v370 = p_u_280["ALT ROTATION"] or p_u_280.ROTATION
				local v371
				if v370 then
					local v372 = string.split
					local v373 = unpack
					v371 = Vector3.new(v373(v372(v370)))
				else
					v371 = Vector3.new(0, 0, 0)
				end
				local v374 = CFrame.fromOrientation
				local v375 = v371.X
				local v376 = math.rad(v375)
				local v377 = v371.Y
				local v378 = math.rad(v377)
				local v379 = v371.Z
				v368 = v369 * v374(v376, v378, (math.rad(v379))) or nil
			end
			v358.CFrame = v368
			v351:Create(v_u_284, v357, v358):Play()
			table.insert(v283, v_u_284)
			task.spawn(function()
				-- upvalues: (copy) p_u_280, (copy) v_u_284, (ref) v_u_282
				local v380 = tick()
				local v381 = p_u_280.TIME
				local v382 = v380 + tonumber(v381)
				repeat
					task.wait()
				until v382 < tick() or not (v_u_284.Parent and v_u_282.Parent)
				v_u_284:Destroy()
			end)
		end
	end,
	["Block"] = function(p383, p384)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26
		local v385 = p383:FindFirstChild("HumanoidRootPart")
		if v385 then
			if p384.RELATIVE ~= nil then
				p383 = p384.RELATIVE
			end
			if not p383:IsA("BasePart") then
				if p383:FindFirstChild(p384["BODY PART"]) then
					p383 = p383[p384["BODY PART"]]
				else
					p383 = nil
				end
			end
			local v386 = p383 or v385
			local v387 = v_u_70(v386, p384)
			local v388 = v_u_1.Ball:Clone()
			local v389 = p384.POSITION
			local v390
			if v389 then
				local v391 = string.split
				local v392 = unpack
				v390 = Vector3.new(v392(v391(v389)))
			else
				v390 = Vector3.new(0, 0, 0)
			end
			local v393 = CFrame.new(-v390.X, v390.Y, -v390.Z)
			local v394 = (v386 and v386.CFrame or CFrame.new()) * v393
			local v395 = p384.ROTATION
			local v396
			if v395 then
				local v397 = string.split
				local v398 = unpack
				v396 = Vector3.new(v398(v397(v395)))
			else
				v396 = Vector3.new(0, 0, 0)
			end
			local v399 = CFrame.fromOrientation
			local v400 = v396.X
			local v401 = math.rad(v400)
			local v402 = v396.Y
			local v403 = math.rad(v402)
			local v404 = v396.Z
			v388.CFrame = v394 * v399(v401, v403, (math.rad(v404)))
			local v405 = Vector3.new(1, 1, 1)
			local v406 = p384.SIZE
			local v407 = tonumber(v406)
			if workspace:GetAttribute("Creator") then
				v407 = math.clamp(v407, 0, 40)
			end
			v388.Size = v405 * v407
			local v408 = Color3.fromRGB
			local v409 = string.split
			local v410 = p384.COLOR
			v388.Color = v408(unpack(v409(v410)))
			local v411 = p384.OPACITY
			v388.Transparency = tonumber(v411)
			v388.Shape = Enum.PartType.Block
			v388.Parent = workspace.Effects
			local v412 = p384["ALT POSITION"]
			local v413
			if v412 then
				local v414 = string.split
				local v415 = unpack
				v413 = Vector3.new(v415(v414(v412)))
			else
				v413 = Vector3.new(0, 0, 0)
			end
			local v416 = v413 == Vector3.new(0, 0, 0)
			if v416 then
				v388.Massless = true
				v388.Anchored = false
				local v417 = Instance.new("Weld")
				v417.Part0 = v386
				v417.Part1 = v388
				local v418 = p384.POSITION
				local v419
				if v418 then
					local v420 = string.split
					local v421 = unpack
					v419 = Vector3.new(v421(v420(v418)))
				else
					v419 = Vector3.new(0, 0, 0)
				end
				local v422 = CFrame.new(-v419.X, v419.Y, -v419.Z)
				local v423 = CFrame.new() * v422
				local v424 = p384.ROTATION
				local v425
				if v424 then
					local v426 = string.split
					local v427 = unpack
					v425 = Vector3.new(v427(v426(v424)))
				else
					v425 = Vector3.new(0, 0, 0)
				end
				local v428 = CFrame.fromOrientation
				local v429 = v425.X
				local v430 = math.rad(v429)
				local v431 = v425.Y
				local v432 = math.rad(v431)
				local v433 = v425.Z
				v417.C0 = v423 * v428(v430, v432, (math.rad(v433)))
				v417.Parent = v388
			end
			local v434 = v_u_11
			local v435 = p384.TIME
			local v436 = tonumber(v435)
			if workspace:GetAttribute("Creator") then
				v436 = math.clamp(v436, 0, 10)
			end
			v434:AddItem(v388, v436)
			local v437 = v_u_3
			local v438 = TweenInfo.new
			local v439 = p384.TIME
			local v440 = tonumber(v439)
			if workspace:GetAttribute("Creator") then
				v440 = math.clamp(v440, 0, 10)
			end
			local v441
			if p384["EASING STYLE"] then
				v441 = Enum.EasingStyle[p384["EASING STYLE"]]
			else
				v441 = Enum.EasingStyle.Linear
			end
			local v442
			if p384["EASING DIRECTION"] then
				v442 = Enum.EasingDirection[p384["EASING DIRECTION"]]
			else
				v442 = Enum.EasingDirection.In
			end
			local v443 = v438(v440, v441, v442)
			local v444 = {}
			local v445 = Vector3.new(1, 1, 1)
			local v446 = p384.SIZE
			local v447 = tonumber(v446)
			if workspace:GetAttribute("Creator") then
				v447 = math.clamp(v447, 0, 40)
			end
			local v448 = p384["ALT SIZE"] or 1
			local v449 = v447 * tonumber(v448)
			if workspace:GetAttribute("Creator") then
				v449 = math.clamp(v449, 0, 40)
			end
			v444.Size = v445 * v449
			local v450 = Color3.fromRGB
			local v451 = string.split
			local v452 = p384["ALT COLOR"]
			v444.Color = v450(unpack(v451(v452)))
			local v453 = p384["ALT OPACITY"]
			v444.Transparency = tonumber(v453)
			local v454
			if v416 then
				v454 = nil
			else
				local v455 = v_u_26(v388, p384, true)
				local v456 = p384["ALT ROTATION"] or p384.ROTATION
				local v457
				if v456 then
					local v458 = string.split
					local v459 = unpack
					v457 = Vector3.new(v459(v458(v456)))
				else
					v457 = Vector3.new(0, 0, 0)
				end
				local v460 = CFrame.fromOrientation
				local v461 = v457.X
				local v462 = math.rad(v461)
				local v463 = v457.Y
				local v464 = math.rad(v463)
				local v465 = v457.Z
				v454 = v455 * v460(v462, v464, (math.rad(v465))) or nil
			end
			v444.CFrame = v454
			v437:Create(v388, v443, v444):Play()
			table.insert(v387, v388)
		end
	end,
	["Wedge"] = function(p466, p467)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26
		local v468 = p466:FindFirstChild("HumanoidRootPart")
		if v468 then
			if p467.RELATIVE ~= nil then
				p466 = p467.RELATIVE
			end
			if not p466:IsA("BasePart") then
				if p466:FindFirstChild(p467["BODY PART"]) then
					p466 = p466[p467["BODY PART"]]
				else
					p466 = nil
				end
			end
			local v469 = p466 or v468
			local v470 = v_u_70(v469, p467)
			local v471 = v_u_1.Ball:Clone()
			local v472 = p467.POSITION
			local v473
			if v472 then
				local v474 = string.split
				local v475 = unpack
				v473 = Vector3.new(v475(v474(v472)))
			else
				v473 = Vector3.new(0, 0, 0)
			end
			local v476 = CFrame.new(-v473.X, v473.Y, -v473.Z)
			local v477 = (v469 and v469.CFrame or CFrame.new()) * v476
			local v478 = p467.ROTATION
			local v479
			if v478 then
				local v480 = string.split
				local v481 = unpack
				v479 = Vector3.new(v481(v480(v478)))
			else
				v479 = Vector3.new(0, 0, 0)
			end
			local v482 = CFrame.fromOrientation
			local v483 = v479.X
			local v484 = math.rad(v483)
			local v485 = v479.Y
			local v486 = math.rad(v485)
			local v487 = v479.Z
			v471.CFrame = v477 * v482(v484, v486, (math.rad(v487)))
			local v488 = Vector3.new(1, 1, 1)
			local v489 = p467.SIZE
			local v490 = tonumber(v489)
			if workspace:GetAttribute("Creator") then
				v490 = math.clamp(v490, 0, 40)
			end
			v471.Size = v488 * v490
			local v491 = Color3.fromRGB
			local v492 = string.split
			local v493 = p467.COLOR
			v471.Color = v491(unpack(v492(v493)))
			local v494 = p467.OPACITY
			v471.Transparency = tonumber(v494)
			v471.Shape = Enum.PartType.Wedge
			v471.Parent = workspace.Effects
			local v495 = p467["ALT POSITION"]
			local v496
			if v495 then
				local v497 = string.split
				local v498 = unpack
				v496 = Vector3.new(v498(v497(v495)))
			else
				v496 = Vector3.new(0, 0, 0)
			end
			local v499 = v496 == Vector3.new(0, 0, 0)
			if v499 then
				v471.Massless = true
				v471.Anchored = false
				local v500 = Instance.new("Weld")
				v500.Part0 = v469
				v500.Part1 = v471
				local v501 = p467.POSITION
				local v502
				if v501 then
					local v503 = string.split
					local v504 = unpack
					v502 = Vector3.new(v504(v503(v501)))
				else
					v502 = Vector3.new(0, 0, 0)
				end
				local v505 = CFrame.new(-v502.X, v502.Y, -v502.Z)
				local v506 = CFrame.new() * v505
				local v507 = p467.ROTATION
				local v508
				if v507 then
					local v509 = string.split
					local v510 = unpack
					v508 = Vector3.new(v510(v509(v507)))
				else
					v508 = Vector3.new(0, 0, 0)
				end
				local v511 = CFrame.fromOrientation
				local v512 = v508.X
				local v513 = math.rad(v512)
				local v514 = v508.Y
				local v515 = math.rad(v514)
				local v516 = v508.Z
				v500.C0 = v506 * v511(v513, v515, (math.rad(v516)))
				v500.Parent = v471
			end
			local v517 = v_u_11
			local v518 = p467.TIME
			local v519 = tonumber(v518)
			if workspace:GetAttribute("Creator") then
				v519 = math.clamp(v519, 0, 10)
			end
			v517:AddItem(v471, v519)
			local v520 = v_u_3
			local v521 = TweenInfo.new
			local v522 = p467.TIME
			local v523 = tonumber(v522)
			if workspace:GetAttribute("Creator") then
				v523 = math.clamp(v523, 0, 10)
			end
			local v524
			if p467["EASING STYLE"] then
				v524 = Enum.EasingStyle[p467["EASING STYLE"]]
			else
				v524 = Enum.EasingStyle.Linear
			end
			local v525
			if p467["EASING DIRECTION"] then
				v525 = Enum.EasingDirection[p467["EASING DIRECTION"]]
			else
				v525 = Enum.EasingDirection.In
			end
			local v526 = v521(v523, v524, v525)
			local v527 = {}
			local v528 = Vector3.new(1, 1, 1)
			local v529 = p467.SIZE
			local v530 = tonumber(v529)
			if workspace:GetAttribute("Creator") then
				v530 = math.clamp(v530, 0, 40)
			end
			local v531 = p467["ALT SIZE"] or 1
			local v532 = v530 * tonumber(v531)
			if workspace:GetAttribute("Creator") then
				v532 = math.clamp(v532, 0, 40)
			end
			v527.Size = v528 * v532
			local v533 = Color3.fromRGB
			local v534 = string.split
			local v535 = p467["ALT COLOR"]
			v527.Color = v533(unpack(v534(v535)))
			local v536 = p467["ALT OPACITY"]
			v527.Transparency = tonumber(v536)
			local v537
			if v499 then
				v537 = nil
			else
				local v538 = v_u_26(v471, p467, true)
				local v539 = p467["ALT ROTATION"] or p467.ROTATION
				local v540
				if v539 then
					local v541 = string.split
					local v542 = unpack
					v540 = Vector3.new(v542(v541(v539)))
				else
					v540 = Vector3.new(0, 0, 0)
				end
				local v543 = CFrame.fromOrientation
				local v544 = v540.X
				local v545 = math.rad(v544)
				local v546 = v540.Y
				local v547 = math.rad(v546)
				local v548 = v540.Z
				v537 = v538 * v543(v545, v547, (math.rad(v548))) or nil
			end
			v527.CFrame = v537
			v520:Create(v471, v526, v527):Play()
			table.insert(v470, v471)
		end
	end,
	["Cylinder"] = function(p549, p550)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26
		local v551 = p549:FindFirstChild("HumanoidRootPart")
		if v551 then
			if p550.RELATIVE ~= nil then
				p549 = p550.RELATIVE
			end
			if not p549:IsA("BasePart") then
				if p549:FindFirstChild(p550["BODY PART"]) then
					p549 = p549[p550["BODY PART"]]
				else
					p549 = nil
				end
			end
			local v552 = p549 or v551
			local v553 = v_u_70(v552, p550)
			local v554 = v_u_1.Cylinder:Clone()
			local v555 = p550.POSITION
			local v556
			if v555 then
				local v557 = string.split
				local v558 = unpack
				v556 = Vector3.new(v558(v557(v555)))
			else
				v556 = Vector3.new(0, 0, 0)
			end
			local v559 = CFrame.new(-v556.X, v556.Y, -v556.Z)
			local v560 = (v552 and v552.CFrame or CFrame.new()) * v559
			local v561 = p550.ROTATION
			local v562
			if v561 then
				local v563 = string.split
				local v564 = unpack
				v562 = Vector3.new(v564(v563(v561)))
			else
				v562 = Vector3.new(0, 0, 0)
			end
			local v565 = CFrame.fromOrientation
			local v566 = v562.X
			local v567 = math.rad(v566)
			local v568 = v562.Y
			local v569 = math.rad(v568)
			local v570 = v562.Z
			v554.CFrame = v560 * v565(v567, v569, (math.rad(v570)))
			local v571 = Vector3.new(1, 1, 1)
			local v572 = p550.SIZE
			local v573 = tonumber(v572)
			if workspace:GetAttribute("Creator") then
				v573 = math.clamp(v573, 0, 40)
			end
			v554.Size = v571 * v573
			local v574 = Color3.fromRGB
			local v575 = string.split
			local v576 = p550.COLOR
			v554.Color = v574(unpack(v575(v576)))
			local v577 = p550.OPACITY
			v554.Transparency = tonumber(v577)
			v554.Parent = workspace.Effects
			local v578 = p550["ALT POSITION"]
			local v579
			if v578 then
				local v580 = string.split
				local v581 = unpack
				v579 = Vector3.new(v581(v580(v578)))
			else
				v579 = Vector3.new(0, 0, 0)
			end
			local v582 = v579 == Vector3.new(0, 0, 0)
			if v582 then
				v554.Massless = true
				v554.Anchored = false
				local v583 = Instance.new("Weld")
				v583.Part0 = v552
				v583.Part1 = v554
				local v584 = p550.POSITION
				local v585
				if v584 then
					local v586 = string.split
					local v587 = unpack
					v585 = Vector3.new(v587(v586(v584)))
				else
					v585 = Vector3.new(0, 0, 0)
				end
				local v588 = CFrame.new(-v585.X, v585.Y, -v585.Z)
				local v589 = CFrame.new() * v588
				local v590 = p550.ROTATION
				local v591
				if v590 then
					local v592 = string.split
					local v593 = unpack
					v591 = Vector3.new(v593(v592(v590)))
				else
					v591 = Vector3.new(0, 0, 0)
				end
				local v594 = CFrame.fromOrientation
				local v595 = v591.X
				local v596 = math.rad(v595)
				local v597 = v591.Y
				local v598 = math.rad(v597)
				local v599 = v591.Z
				v583.C0 = v589 * v594(v596, v598, (math.rad(v599)))
				v583.Parent = v554
			end
			local v600 = v_u_11
			local v601 = p550.TIME
			local v602 = tonumber(v601)
			if workspace:GetAttribute("Creator") then
				v602 = math.clamp(v602, 0, 10)
			end
			v600:AddItem(v554, v602)
			local v603 = v_u_3
			local v604 = TweenInfo.new
			local v605 = p550.TIME
			local v606 = tonumber(v605)
			if workspace:GetAttribute("Creator") then
				v606 = math.clamp(v606, 0, 10)
			end
			local v607
			if p550["EASING STYLE"] then
				v607 = Enum.EasingStyle[p550["EASING STYLE"]]
			else
				v607 = Enum.EasingStyle.Linear
			end
			local v608
			if p550["EASING DIRECTION"] then
				v608 = Enum.EasingDirection[p550["EASING DIRECTION"]]
			else
				v608 = Enum.EasingDirection.In
			end
			local v609 = v604(v606, v607, v608)
			local v610 = {}
			local v611 = Vector3.new(1, 1, 1)
			local v612 = p550.SIZE
			local v613 = tonumber(v612)
			if workspace:GetAttribute("Creator") then
				v613 = math.clamp(v613, 0, 40)
			end
			local v614 = p550["ALT SIZE"] or 1
			local v615 = v613 * tonumber(v614)
			if workspace:GetAttribute("Creator") then
				v615 = math.clamp(v615, 0, 40)
			end
			v610.Size = v611 * v615
			local v616 = Color3.fromRGB
			local v617 = string.split
			local v618 = p550["ALT COLOR"]
			v610.Color = v616(unpack(v617(v618)))
			local v619 = p550["ALT OPACITY"]
			v610.Transparency = tonumber(v619)
			local v620
			if v582 then
				v620 = nil
			else
				local v621 = v_u_26(v554, p550, true)
				local v622 = p550["ALT ROTATION"] or p550.ROTATION
				local v623
				if v622 then
					local v624 = string.split
					local v625 = unpack
					v623 = Vector3.new(v625(v624(v622)))
				else
					v623 = Vector3.new(0, 0, 0)
				end
				local v626 = CFrame.fromOrientation
				local v627 = v623.X
				local v628 = math.rad(v627)
				local v629 = v623.Y
				local v630 = math.rad(v629)
				local v631 = v623.Z
				v620 = v621 * v626(v628, v630, (math.rad(v631))) or nil
			end
			v610.CFrame = v620
			v603:Create(v554, v609, v610):Play()
			table.insert(v553, v554)
		end
	end,
	["Glow"] = function(p632, p633)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26
		local v634 = p632:FindFirstChild("HumanoidRootPart")
		if v634 then
			local v635
			if p633.RELATIVE == nil then
				v635 = p632
			else
				v635 = p633.RELATIVE
			end
			if not v635:IsA("BasePart") then
				if v635:FindFirstChild(p633["BODY PART"]) then
					v635 = v635[p633["BODY PART"]]
				else
					v635 = nil
				end
			end
			local v636 = v635 or v634
			local v637 = v_u_70(v636, p633)
			local v_u_638 = v_u_1.Parent.Damage.HitGlow:Clone()
			local v639 = 1.1
			local v640 = p633.SIZE
			local v641 = tonumber(v640)
			if workspace:GetAttribute("Creator") then
				v641 = math.clamp(v641, 0, 40)
			end
			v_u_638:ScaleTo(v639 * v641)
			v_u_638.Parent = workspace.Effects
			local v642 = v_u_11
			local v643 = p633.TIME
			local v644 = tonumber(v643)
			if workspace:GetAttribute("Creator") then
				v644 = math.clamp(v644, 0, 10)
			end
			v642:AddItem(v_u_638, v644)
			for _, v645 in v_u_638:GetChildren() do
				local v646 = p632:FindFirstChild(v645.Name)
				if v646 then
					local v647 = p633["ALT POSITION"]
					local v648
					if v647 then
						local v649 = string.split
						local v650 = unpack
						v648 = Vector3.new(v650(v649(v647)))
					else
						v648 = Vector3.new(0, 0, 0)
					end
					if v648 == Vector3.new(0, 0, 0) then
						local v651 = Instance.new("Weld", v645)
						v651.Part0 = v645
						v651.Part1 = v646
					else
						v645.Anchored = true
						local v652 = v646.CFrame
						local v653 = CFrame.new
						local v654 = p633["ALT POSITION"]
						local v655
						if v654 then
							local v656 = string.split
							local v657 = unpack
							v655 = Vector3.new(v657(v656(v654)))
						else
							v655 = Vector3.new(0, 0, 0)
						end
						v645.CFrame = v652 * v653(v655)
					end
				end
				if v636.Name == "HumanoidRootPart" or v645.Name == v636.Name then
					local v658 = Color3.fromRGB
					local v659 = string.split
					local v660 = p633.COLOR
					v645.Color = v658(unpack(v659(v660)))
					local v661 = p633.OPACITY
					v645.Transparency = tonumber(v661)
					local v662 = v_u_3
					local v663 = TweenInfo.new
					local v664 = p633.TIME
					local v665 = tonumber(v664)
					if workspace:GetAttribute("Creator") then
						v665 = math.clamp(v665, 0, 10)
					end
					local v666
					if p633["EASING STYLE"] then
						v666 = Enum.EasingStyle[p633["EASING STYLE"]]
					else
						v666 = Enum.EasingStyle.Linear
					end
					local v667
					if p633["EASING DIRECTION"] then
						v667 = Enum.EasingDirection[p633["EASING DIRECTION"]]
					else
						v667 = Enum.EasingDirection.In
					end
					local v668 = v663(v665, v666, v667)
					local v669 = {}
					local v670 = Color3.fromRGB
					local v671 = string.split
					local v672 = p633["ALT COLOR"]
					v669.Color = v670(unpack(v671(v672)))
					local v673 = p633["ALT OPACITY"]
					v669.Transparency = tonumber(v673)
					v662:Create(v645, v668, v669):Play()
				else
					v645.Transparency = 1
				end
				table.insert(v637, v645)
			end
			local v674 = p633["ALT POSITION"]
			local v675
			if v674 then
				local v676 = string.split
				local v677 = unpack
				v675 = Vector3.new(v677(v676(v674)))
			else
				v675 = Vector3.new(0, 0, 0)
			end
			if v675 ~= Vector3.new(0, 0, 0) then
				local v_u_678 = Instance.new("CFrameValue", v_u_638)
				v_u_678.Value = v_u_638.PrimaryPart.CFrame
				local v679 = v_u_3
				local v680 = TweenInfo.new
				local v681 = p633.TIME
				local v682 = tonumber(v681)
				if workspace:GetAttribute("Creator") then
					v682 = math.clamp(v682, 0, 10)
				end
				local v683
				if p633["EASING STYLE"] then
					v683 = Enum.EasingStyle[p633["EASING STYLE"]]
				else
					v683 = Enum.EasingStyle.Linear
				end
				local v684
				if p633["EASING DIRECTION"] then
					v684 = Enum.EasingDirection[p633["EASING DIRECTION"]]
				else
					v684 = Enum.EasingDirection.In
				end
				local v685 = v680(v682, v683, v684)
				local v686 = {}
				local v687 = v_u_26(p632.HumanoidRootPart, p633, true)
				local v688 = p633["ALT ROTATION"] or p633.ROTATION
				local v689
				if v688 then
					local v690 = string.split
					local v691 = unpack
					v689 = Vector3.new(v691(v690(v688)))
				else
					v689 = Vector3.new(0, 0, 0)
				end
				local v692 = CFrame.fromOrientation
				local v693 = v689.X
				local v694 = math.rad(v693)
				local v695 = v689.Y
				local v696 = math.rad(v695)
				local v697 = v689.Z
				v686.Value = v687 * v692(v694, v696, (math.rad(v697)))
				v679:Create(v_u_678, v685, v686):Play()
				v_u_678.Changed:Connect(function()
					-- upvalues: (copy) v_u_638, (copy) v_u_678
					v_u_638:PivotTo(v_u_678.Value)
				end)
			end
			local v698 = p633.SIZE
			local v699 = tonumber(v698)
			if workspace:GetAttribute("Creator") then
				v699 = math.clamp(v699, 0, 40)
			end
			local v700 = p633["ALT SIZE"] or 1
			local v701 = v699 * tonumber(v700)
			if workspace:GetAttribute("Creator") then
				v701 = math.clamp(v701, 0, 40)
			end
			local v702 = p633.SIZE
			local v703 = tonumber(v702)
			if workspace:GetAttribute("Creator") then
				v703 = math.clamp(v703, 0, 40)
			end
			if v701 ~= v703 then
				local v_u_704 = Instance.new("NumberValue", v_u_638)
				local v705 = p633.SIZE
				local v706 = tonumber(v705)
				if workspace:GetAttribute("Creator") then
					v706 = math.clamp(v706, 0, 40)
				end
				v_u_704.Value = v706
				local v707 = v_u_3
				local v708 = TweenInfo.new
				local v709 = p633.TIME
				local v710 = tonumber(v709)
				if workspace:GetAttribute("Creator") then
					v710 = math.clamp(v710, 0, 10)
				end
				local v711
				if p633["EASING STYLE"] then
					v711 = Enum.EasingStyle[p633["EASING STYLE"]]
				else
					v711 = Enum.EasingStyle.Linear
				end
				local v712
				if p633["EASING DIRECTION"] then
					v712 = Enum.EasingDirection[p633["EASING DIRECTION"]]
				else
					v712 = Enum.EasingDirection.In
				end
				local v713 = v708(v710, v711, v712)
				local v714 = {}
				local v715 = p633.SIZE
				local v716 = tonumber(v715)
				if workspace:GetAttribute("Creator") then
					v716 = math.clamp(v716, 0, 40)
				end
				local v717 = p633["ALT SIZE"] or 1
				local v718 = v716 * tonumber(v717)
				if workspace:GetAttribute("Creator") then
					v718 = math.clamp(v718, 0, 40)
				end
				v714.Value = v718
				v707:Create(v_u_704, v713, v714):Play()
				v_u_704.Changed:Connect(function()
					-- upvalues: (copy) v_u_638, (copy) v_u_704
					v_u_638:ScaleTo(v_u_704.Value)
				end)
			end
		end
	end,
	["Melee Trail"] = function(p719, p720)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51, (copy) v_u_3, (copy) v_u_26, (ref) v_u_11
		local v721 = p719:FindFirstChild("HumanoidRootPart")
		if v721 then
			if p720.RELATIVE ~= nil then
				p719 = p720.RELATIVE
			end
			if not p719:IsA("BasePart") then
				if p719:FindFirstChild(p720["BODY PART"]) then
					p719 = p719[p720["BODY PART"]]
				else
					p719 = nil
				end
			end
			local v722 = p719 or v721
			local v723 = v_u_70(v722, p720)
			local v_u_724 = v_u_1.Parent.Damage.CombatTrail:Clone()
			local v725 = v722.Size * 1.1
			local v726 = p720.SIZE
			local v727 = tonumber(v726)
			if workspace:GetAttribute("Creator") then
				v727 = math.clamp(v727, 0, 40)
			end
			v_u_724.Size = v725 * v727
			local v728 = v_u_724.Weld
			local v729 = p720.POSITION
			local v730
			if v729 then
				local v731 = string.split
				local v732 = unpack
				v730 = Vector3.new(v732(v731(v729)))
			else
				v730 = Vector3.new(0, 0, 0)
			end
			local v733 = CFrame.new(-v730.X, v730.Y, -v730.Z)
			local v734 = CFrame.new() * v733
			local v735 = p720.ROTATION
			local v736
			if v735 then
				local v737 = string.split
				local v738 = unpack
				v736 = Vector3.new(v738(v737(v735)))
			else
				v736 = Vector3.new(0, 0, 0)
			end
			local v739 = CFrame.fromOrientation
			local v740 = v736.X
			local v741 = math.rad(v740)
			local v742 = v736.Y
			local v743 = math.rad(v742)
			local v744 = v736.Z
			v728.C0 = v734 * v739(v741, v743, (math.rad(v744)))
			local v745 = Color3.fromRGB
			local v746 = string.split
			local v747 = p720.COLOR
			v_u_724.Color = v745(unpack(v746(v747)))
			local v748 = v_u_724.Trail
			local v749 = ColorSequence.new
			local v750 = Color3.fromRGB
			local v751 = string.split
			local v752 = p720.COLOR
			v748.Color = v749(v750(unpack(v751(v752))), v_u_31(p720))
			local v753 = v_u_724.Trail
			local v754 = NumberSequence.new
			local v755 = p720.OPACITY
			local v756 = tonumber(v755)
			local v757 = p720["ALT OPACITY"]
			v753.Transparency = v754(v756, (tonumber(v757)))
			v_u_724.Trail.WidthScale = v_u_51(v_u_724.Trail.WidthScale.Keypoints, p720)
			v_u_724.Weld.Part0 = v722
			v_u_724.Parent = workspace.Effects
			table.insert(v723, v_u_724)
			local v758 = p720["ALT POSITION"]
			local v759
			if v758 then
				local v760 = string.split
				local v761 = unpack
				v759 = Vector3.new(v761(v760(v758)))
			else
				v759 = Vector3.new(0, 0, 0)
			end
			if v759 ~= Vector3.new(0, 0, 0) then
				local v762 = Instance.new("Part")
				v762.Transparency = 1
				v762.CanCollide = false
				v762.Anchored = true
				v762.Size = Vector3.new(0, 0, 0)
				v762.CFrame = v722.CFrame
				v762.Parent = v_u_724
				v_u_724.Weld.Part0 = v762
			end
			local v763 = v_u_3
			local v764 = TweenInfo.new
			local v765 = p720.TIME
			local v766 = tonumber(v765)
			if workspace:GetAttribute("Creator") then
				v766 = math.clamp(v766, 0, 10)
			end
			local v767
			if p720["EASING STYLE"] then
				v767 = Enum.EasingStyle[p720["EASING STYLE"]]
			else
				v767 = Enum.EasingStyle.Linear
			end
			local v768
			if p720["EASING DIRECTION"] then
				v768 = Enum.EasingDirection[p720["EASING DIRECTION"]]
			else
				v768 = Enum.EasingDirection.In
			end
			local v769 = v764(v766, v767, v768)
			local v770 = {}
			local v771 = v722.Size * 1.1
			local v772 = p720.SIZE
			local v773 = tonumber(v772)
			if workspace:GetAttribute("Creator") then
				v773 = math.clamp(v773, 0, 40)
			end
			local v774 = p720["ALT SIZE"] or 1
			local v775 = v773 * tonumber(v774)
			if workspace:GetAttribute("Creator") then
				v775 = math.clamp(v775, 0, 40)
			end
			v770.Size = v771 * v775
			local v776 = p720["ALT OPACITY"]
			v770.Transparency = tonumber(v776)
			local v777 = Color3.fromRGB
			local v778 = string.split
			local v779 = p720["ALT COLOR"]
			v770.Color = v777(unpack(v778(v779)))
			v763:Create(v_u_724, v769, v770):Play()
			local v780 = v_u_3
			local v781 = v_u_724.Weld
			local v782 = TweenInfo.new
			local v783 = p720.TIME
			local v784 = tonumber(v783)
			if workspace:GetAttribute("Creator") then
				v784 = math.clamp(v784, 0, 10)
			end
			local v785
			if p720["EASING STYLE"] then
				v785 = Enum.EasingStyle[p720["EASING STYLE"]]
			else
				v785 = Enum.EasingStyle.Linear
			end
			local v786
			if p720["EASING DIRECTION"] then
				v786 = Enum.EasingDirection[p720["EASING DIRECTION"]]
			else
				v786 = Enum.EasingDirection.In
			end
			local v787 = v782(v784, v785, v786)
			local v788 = {}
			local v789 = v_u_26(nil, p720, true)
			local v790 = p720["ALT ROTATION"] or p720.ROTATION
			local v791
			if v790 then
				local v792 = string.split
				local v793 = unpack
				v791 = Vector3.new(v793(v792(v790)))
			else
				v791 = Vector3.new(0, 0, 0)
			end
			local v794 = CFrame.fromOrientation
			local v795 = v791.X
			local v796 = math.rad(v795)
			local v797 = v791.Y
			local v798 = math.rad(v797)
			local v799 = v791.Z
			v788.C0 = v789 * v794(v796, v798, (math.rad(v799)))
			v780:Create(v781, v787, v788):Play()
			local v800 = task.delay
			local v801 = p720.TIME
			local v802 = tonumber(v801)
			if workspace:GetAttribute("Creator") then
				v802 = math.clamp(v802, 0, 10)
			end
			v800(v802 or 0.2, function()
				-- upvalues: (copy) v_u_724, (ref) v_u_3, (ref) v_u_11
				v_u_724.Trail.Enabled = false
				v_u_3:Create(v_u_724, TweenInfo.new(0.1), {
					["Transparency"] = 1
				}):Play()
				v_u_11:AddItem(v_u_724, 0.2)
			end)
		end
	end,
	["Flames"] = function(p803, p804)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (copy) v_u_31, (ref) v_u_11
		local v805 = p803:FindFirstChild("HumanoidRootPart")
		if v805 then
			local v806
			if p804.RELATIVE == nil then
				v806 = p803
			else
				v806 = p804.RELATIVE
			end
			if not v806:IsA("BasePart") then
				if v806:FindFirstChild(p804["BODY PART"]) then
					v806 = v806[p804["BODY PART"]]
				else
					v806 = nil
				end
			end
			local v_u_807 = v806 or v805
			local v808 = v_u_70(v_u_807, p804)
			if v_u_807.Name == "HumanoidRootPart" then
				for _, v809 in p803:GetChildren() do
					if v809:IsA("BasePart") then
						local v_u_810 = v_u_1.Parent.Damage.Flames:Clone()
						local v811 = NumberSequence.new
						local v812 = p804.OPACITY
						local v813 = tonumber(v812)
						local v814 = p804["ALT OPACITY"]
						v_u_810.Transparency = v811(v813, (tonumber(v814)))
						local v815 = ColorSequence.new
						local v816 = Color3.fromRGB
						local v817 = string.split
						local v818 = p804.COLOR
						v_u_810.Color = v815(v816(unpack(v817(v818))), v_u_31(p804))
						local v819 = NumberSequence.new
						local v820 = p804.SIZE
						local v821 = tonumber(v820)
						if workspace:GetAttribute("Creator") then
							v821 = math.clamp(v821, 0, 40)
						end
						v_u_810.Size = v819(v821)
						local v822 = v_u_810.Rate
						local v823 = p804.AMOUNT
						local v824 = tonumber(v823)
						if workspace:GetAttribute("Creator") then
							v824 = math.clamp(v824, 1, 20)
						end
						v_u_810.Rate = v822 * v824
						v_u_810.Parent = v809
						table.insert(v808, v_u_810)
						local v825 = v_u_11
						local v826 = p804.TIME
						local v827 = tonumber(v826)
						if workspace:GetAttribute("Creator") then
							v827 = math.clamp(v827, 0, 10)
						end
						v825:AddItem(v_u_810, v827 + 2)
						local v828 = task.delay
						local v829 = p804.TIME
						local v830 = tonumber(v829)
						if workspace:GetAttribute("Creator") then
							v830 = math.clamp(v830, 0, 10)
						end
						v828(v830, function()
							-- upvalues: (copy) v_u_810
							if v_u_810.Parent then
								v_u_810.Enabled = false
							end
						end)
					end
				end
			else
				local v_u_831 = v_u_1.Parent.Damage.Flames:Clone()
				local v832 = NumberSequence.new
				local v833 = p804.OPACITY
				local v834 = tonumber(v833)
				local v835 = p804["ALT OPACITY"]
				v_u_831.Transparency = v832(v834, (tonumber(v835)))
				local v836 = ColorSequence.new
				local v837 = Color3.fromRGB
				local v838 = string.split
				local v839 = p804.COLOR
				v_u_831.Color = v836(v837(unpack(v838(v839))), v_u_31(p804))
				local v840 = NumberSequence.new
				local v841 = p804.SIZE
				local v842 = tonumber(v841)
				if workspace:GetAttribute("Creator") then
					v842 = math.clamp(v842, 0, 40)
				end
				v_u_831.Size = v840(v842)
				local v843 = v_u_831.Rate
				local v844 = p804.AMOUNT
				local v845 = tonumber(v844)
				if workspace:GetAttribute("Creator") then
					v845 = math.clamp(v845, 1, 20)
				end
				v_u_831.Rate = v843 * v845
				v_u_831.Parent = v_u_807
				table.insert(v808, v_u_831)
				v_u_807.Destroying:Once(function()
					-- upvalues: (copy) v_u_831, (ref) v_u_807, (ref) v_u_11
					if v_u_831.Enabled ~= false then
						local v846 = Instance.new("Part")
						v846.Anchored = true
						v846.CanCollide = false
						v846.Transparency = 1
						v846.Size = Vector3.new(1, 1, 1)
						v846.CFrame = v_u_807.CFrame
						v846.Parent = workspace.Effects
						v_u_831.Parent = v846
						v_u_831.Enabled = false
						v_u_11:AddItem(v846, 2)
					end
				end)
				local v847 = v_u_11
				local v848 = p804.TIME
				local v849 = tonumber(v848)
				if workspace:GetAttribute("Creator") then
					v849 = math.clamp(v849, 0, 10)
				end
				v847:AddItem(v_u_831, v849 + 2)
				local v850 = task.delay
				local v851 = p804.TIME
				local v852 = tonumber(v851)
				if workspace:GetAttribute("Creator") then
					v852 = math.clamp(v852, 0, 10)
				end
				v850(v852, function()
					-- upvalues: (copy) v_u_831
					if v_u_831.Parent then
						v_u_831.Enabled = false
					end
				end)
			end
		else
			return
		end
	end,
	["Visibility"] = function(p853, p854)
		-- upvalues: (copy) v_u_3
		local v855 = p853:FindFirstChild("HumanoidRootPart")
		if not v855 then
			return
		end
		local v856
		if p854.RELATIVE == nil then
			v856 = p853
		else
			v856 = p854.RELATIVE
		end
		if not v856:IsA("BasePart") then
			if v856:FindFirstChild(p854["BODY PART"]) then
				v856 = v856[p854["BODY PART"]]
			else
				v856 = nil
			end
		end
		local v857 = v856 or v855
		local v858 = true
		for _, v859 in ipairs(p853:GetDescendants()) do
			if v859:GetAttribute("NoTransp") then
				v858 = false
				break
			end
		end
		local v860 = {
			["HatAttachment"] = "Head",
			["FaceCenterAttachment"] = "Head",
			["FaceFrontAttachment"] = "Head",
			["HairAttachment"] = "Head",
			["NeckAttachment"] = "Torso",
			["BodyFrontAttachment"] = "Torso",
			["BodyBackAttachment"] = "Torso",
			["BodyLeftAttachment"] = "Torso",
			["BodyRightAttachment"] = "Torso",
			["WaistFrontAttachment"] = "Torso",
			["WaistBackAttachment"] = "Torso",
			["LeftShoulderAttachment"] = "Left Arm",
			["RightShoulderAttachment"] = "Right Arm"
		}
		if v857.Name == "HumanoidRootPart" then
			for _, v861 in p853:GetDescendants() do
				if v861:IsA("BasePart") or v861:IsA("Decal") then
					if v858 and v861.Transparency == 1 then
						v861:SetAttribute("NoTransp", true)
					end
					if not v861:GetAttribute("NoTransp") then
						local v862 = p854.OPACITY
						v861.Transparency = tonumber(v862)
						local v863 = v_u_3
						local v864 = TweenInfo.new
						local v865 = p854.TIME
						local v866 = tonumber(v865)
						if workspace:GetAttribute("Creator") then
							v866 = math.clamp(v866, 0, 10)
						end
						local v867
						if p854["EASING STYLE"] then
							v867 = Enum.EasingStyle[p854["EASING STYLE"]]
						else
							v867 = Enum.EasingStyle.Linear
						end
						local v868
						if p854["EASING DIRECTION"] then
							v868 = Enum.EasingDirection[p854["EASING DIRECTION"]]
						else
							v868 = Enum.EasingDirection.In
						end
						local v869 = v864(v866, v867, v868)
						local v870 = {}
						local v871 = p854["ALT OPACITY"]
						v870.Transparency = tonumber(v871)
						v863:Create(v861, v869, v870):Play()
					end
				end
			end
		else
			local v872 = p854.OPACITY
			v857.Transparency = tonumber(v872)
			for _, v873 in pairs(p853:GetDescendants()) do
				if v860[v873] == v857.Name or v873:IsA("Decal") and v873.Parent == v857 then
					local v874 = v873.Parent
					local v875 = p854.OPACITY
					v874.Transparency = tonumber(v875)
				end
			end
			local v876 = v_u_3
			local v877 = TweenInfo.new
			local v878 = p854.TIME
			local v879 = tonumber(v878)
			if workspace:GetAttribute("Creator") then
				v879 = math.clamp(v879, 0, 10)
			end
			local v880
			if p854["EASING STYLE"] then
				v880 = Enum.EasingStyle[p854["EASING STYLE"]]
			else
				v880 = Enum.EasingStyle.Linear
			end
			local v881
			if p854["EASING DIRECTION"] then
				v881 = Enum.EasingDirection[p854["EASING DIRECTION"]]
			else
				v881 = Enum.EasingDirection.In
			end
			local v882 = v877(v879, v880, v881)
			local v883 = {}
			local v884 = p854["ALT OPACITY"]
			v883.Transparency = tonumber(v884)
			v876:Create(v857, v882, v883):Play()
			for _, v885 in pairs(p853:GetDescendants()) do
				if v860[v885.Name] and v860[v885.Name] == v857.Name or v885:IsA("Decal") and v885.Parent == v857 then
					local v886 = v_u_3
					local v887 = v885.Parent
					local v888 = TweenInfo.new
					local v889 = p854.TIME
					local v890 = tonumber(v889)
					if workspace:GetAttribute("Creator") then
						v890 = math.clamp(v890, 0, 10)
					end
					local v891
					if p854["EASING STYLE"] then
						v891 = Enum.EasingStyle[p854["EASING STYLE"]]
					else
						v891 = Enum.EasingStyle.Linear
					end
					local v892
					if p854["EASING DIRECTION"] then
						v892 = Enum.EasingDirection[p854["EASING DIRECTION"]]
					else
						v892 = Enum.EasingDirection.In
					end
					local v893 = v888(v890, v891, v892)
					local v894 = {}
					local v895 = p854["ALT OPACITY"]
					v894.Transparency = tonumber(v895)
					v886:Create(v887, v893, v894):Play()
				end
			end
		end
	end,
	["Distortion"] = function(p896, p897)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26
		local v898 = p896:FindFirstChild("HumanoidRootPart")
		if v898 then
			if p897.RELATIVE ~= nil then
				p896 = p897.RELATIVE
			end
			if not p896:IsA("BasePart") then
				if p896:FindFirstChild(p897["BODY PART"]) then
					p896 = p896[p897["BODY PART"]]
				else
					p896 = nil
				end
			end
			local v899 = p896 or v898
			local v900 = v_u_70(v899, p897)
			local v901 = v_u_1.Distortion:Clone()
			local v902 = p897.POSITION
			local v903
			if v902 then
				local v904 = string.split
				local v905 = unpack
				v903 = Vector3.new(v905(v904(v902)))
			else
				v903 = Vector3.new(0, 0, 0)
			end
			local v906 = CFrame.new(-v903.X, v903.Y, -v903.Z)
			local v907 = (v899 and v899.CFrame or CFrame.new()) * v906
			local v908 = p897.ROTATION
			local v909
			if v908 then
				local v910 = string.split
				local v911 = unpack
				v909 = Vector3.new(v911(v910(v908)))
			else
				v909 = Vector3.new(0, 0, 0)
			end
			local v912 = CFrame.fromOrientation
			local v913 = v909.X
			local v914 = math.rad(v913)
			local v915 = v909.Y
			local v916 = math.rad(v915)
			local v917 = v909.Z
			v901.CFrame = v907 * v912(v914, v916, (math.rad(v917)))
			local v918 = Vector3.new(1, 1, 1)
			local v919 = p897.SIZE
			local v920 = tonumber(v919)
			if workspace:GetAttribute("Creator") then
				v920 = math.clamp(v920, 0, 40)
			end
			v901.Size = v918 * v920
			local v921 = Color3.fromRGB
			local v922 = string.split
			local v923 = p897.COLOR
			v901.Color = v921(unpack(v922(v923)))
			local v924 = v901.Transparency
			local v925 = p897.OPACITY
			v901.Transparency = v924 + tonumber(v925)
			local v926 = Instance.new("Highlight")
			v926.Enabled = false
			v926.Parent = v901
			v901.Parent = workspace.Effects
			local v927 = v_u_11
			local v928 = p897.TIME
			local v929 = tonumber(v928)
			if workspace:GetAttribute("Creator") then
				v929 = math.clamp(v929, 0, 10)
			end
			v927:AddItem(v901, v929)
			local v930 = v_u_3
			local v931 = TweenInfo.new
			local v932 = p897.TIME
			local v933 = tonumber(v932)
			if workspace:GetAttribute("Creator") then
				v933 = math.clamp(v933, 0, 10)
			end
			local v934
			if p897["EASING STYLE"] then
				v934 = Enum.EasingStyle[p897["EASING STYLE"]]
			else
				v934 = Enum.EasingStyle.Linear
			end
			local v935
			if p897["EASING DIRECTION"] then
				v935 = Enum.EasingDirection[p897["EASING DIRECTION"]]
			else
				v935 = Enum.EasingDirection.In
			end
			local v936 = v931(v933, v934, v935)
			local v937 = {}
			local v938 = Vector3.new(1, 1, 1)
			local v939 = p897.SIZE
			local v940 = tonumber(v939)
			if workspace:GetAttribute("Creator") then
				v940 = math.clamp(v940, 0, 40)
			end
			local v941 = p897["ALT SIZE"] or 1
			local v942 = v940 * tonumber(v941)
			if workspace:GetAttribute("Creator") then
				v942 = math.clamp(v942, 0, 40)
			end
			v937.Size = v938 * v942
			local v943 = Color3.fromRGB
			local v944 = string.split
			local v945 = p897["ALT COLOR"]
			v937.Color = v943(unpack(v944(v945)))
			local v946 = p897["ALT OPACITY"]
			v937.Transparency = 1 + tonumber(v946)
			v937.CFrame = v_u_26(v899, p897, true)
			v930:Create(v901, v936, v937):Play()
			table.insert(v900, v901)
		end
	end,
	["Ring"] = function(p947, p948)
		-- upvalues: (copy) v_u_70, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51
		local v949 = p947:FindFirstChild("HumanoidRootPart")
		if v949 then
			if p948.RELATIVE ~= nil then
				p947 = p948.RELATIVE
			end
			if not p947:IsA("BasePart") then
				if p947:FindFirstChild(p948["BODY PART"]) then
					p947 = p947[p948["BODY PART"]]
				else
					p947 = nil
				end
			end
			local v950 = p947 or v949
			local v951 = v_u_70(v950, p948)
			local v952 = Instance.new("Attachment")
			v952.Parent = v950
			local v953 = p948.POSITION
			local v954
			if v953 then
				local v955 = string.split
				local v956 = unpack
				v954 = Vector3.new(v956(v955(v953)))
			else
				v954 = Vector3.new(0, 0, 0)
			end
			local v957 = CFrame.new(-v954.X, v954.Y, -v954.Z)
			local v958 = (v950 and v950.CFrame or CFrame.new()) * v957
			local v959 = p948.ROTATION
			local v960
			if v959 then
				local v961 = string.split
				local v962 = unpack
				v960 = Vector3.new(v962(v961(v959)))
			else
				v960 = Vector3.new(0, 0, 0)
			end
			local v963 = CFrame.fromOrientation
			local v964 = v960.X
			local v965 = math.rad(v964)
			local v966 = v960.Y
			local v967 = math.rad(v966)
			local v968 = v960.Z
			v952.WorldCFrame = v958 * v963(v965, v967, (math.rad(v968)))
			local v969 = v_u_11
			local v970 = p948.TIME
			local v971 = tonumber(v970)
			if workspace:GetAttribute("Creator") then
				v971 = math.clamp(v971, 0, 10)
			end
			v969:AddItem(v952, v971)
			local v972 = p948["ALT POSITION"]
			local v973
			if v972 then
				local v974 = string.split
				local v975 = unpack
				v973 = Vector3.new(v975(v974(v972)))
			else
				v973 = Vector3.new(0, 0, 0)
			end
			if v973 ~= Vector3.new(0, 0, 0) then
				local v976 = v_u_3
				local v977 = TweenInfo.new
				local v978 = p948.TIME
				local v979 = tonumber(v978)
				if workspace:GetAttribute("Creator") then
					v979 = math.clamp(v979, 0, 10)
				end
				local v980
				if p948["EASING STYLE"] then
					v980 = Enum.EasingStyle[p948["EASING STYLE"]]
				else
					v980 = Enum.EasingStyle.Linear
				end
				local v981
				if p948["EASING DIRECTION"] then
					v981 = Enum.EasingDirection[p948["EASING DIRECTION"]]
				else
					v981 = Enum.EasingDirection.In
				end
				local v982 = v977(v979, v980, v981)
				local v983 = {}
				local v984 = v_u_26(v950, p948, true)
				local v985 = p948["ALT ROTATION"] or p948.ROTATION
				local v986
				if v985 then
					local v987 = string.split
					local v988 = unpack
					v986 = Vector3.new(v988(v987(v985)))
				else
					v986 = Vector3.new(0, 0, 0)
				end
				local v989 = CFrame.fromOrientation
				local v990 = v986.X
				local v991 = math.rad(v990)
				local v992 = v986.Y
				local v993 = math.rad(v992)
				local v994 = v986.Z
				v983.WorldCFrame = v984 * v989(v991, v993, (math.rad(v994)))
				v976:Create(v952, v982, v983):Play()
			end
			local v995 = v_u_1.Parent.Itadori.CounterHit.Feint.Ring:Clone()
			local v996 = ColorSequence.new
			local v997 = Color3.fromRGB
			local v998 = string.split
			local v999 = p948.COLOR
			v995.Color = v996(v997(unpack(v998(v999))), v_u_31(p948))
			local v1000 = NumberRange.new
			local v1001 = p948.TIME
			local v1002 = tonumber(v1001)
			if workspace:GetAttribute("Creator") then
				v1002 = math.clamp(v1002, 0, 10)
			end
			v995.Lifetime = v1000(v1002)
			local v1003 = NumberSequence.new
			local v1004 = p948.OPACITY
			local v1005 = tonumber(v1004)
			local v1006 = p948["ALT OPACITY"]
			v995.Transparency = v1003(v1005, (tonumber(v1006)))
			v995.LightEmission = 0
			v995.LightInfluence = 0
			v995.Brightness = 4
			v995.Size = v_u_51(v995.Size.Keypoints, p948)
			v995.Parent = v952
			local v1007 = p948.AMOUNT
			local v1008 = tonumber(v1007)
			if workspace:GetAttribute("Creator") then
				v1008 = math.clamp(v1008, 1, 20)
			end
			v995:Emit(v1008)
			table.insert(v951, v995)
		end
	end,
	["Sparks"] = function(p1009, p1010)
		-- upvalues: (copy) v_u_70, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51
		local v1011 = p1009:FindFirstChild("HumanoidRootPart")
		if v1011 then
			if p1010.RELATIVE ~= nil then
				p1009 = p1010.RELATIVE
			end
			if not p1009:IsA("BasePart") then
				if p1009:FindFirstChild(p1010["BODY PART"]) then
					p1009 = p1009[p1010["BODY PART"]]
				else
					p1009 = nil
				end
			end
			local v1012 = p1009 or v1011
			local v1013 = v_u_70(v1012, p1010)
			local v1014 = Instance.new("Attachment")
			v1014.Parent = v1012
			local v1015 = p1010.POSITION
			local v1016
			if v1015 then
				local v1017 = string.split
				local v1018 = unpack
				v1016 = Vector3.new(v1018(v1017(v1015)))
			else
				v1016 = Vector3.new(0, 0, 0)
			end
			local v1019 = CFrame.new(-v1016.X, v1016.Y, -v1016.Z)
			local v1020 = (v1012 and v1012.CFrame or CFrame.new()) * v1019
			local v1021 = p1010.ROTATION
			local v1022
			if v1021 then
				local v1023 = string.split
				local v1024 = unpack
				v1022 = Vector3.new(v1024(v1023(v1021)))
			else
				v1022 = Vector3.new(0, 0, 0)
			end
			local v1025 = CFrame.fromOrientation
			local v1026 = v1022.X
			local v1027 = math.rad(v1026)
			local v1028 = v1022.Y
			local v1029 = math.rad(v1028)
			local v1030 = v1022.Z
			v1014.WorldCFrame = v1020 * v1025(v1027, v1029, (math.rad(v1030)))
			local v1031 = v_u_11
			local v1032 = p1010.TIME
			local v1033 = tonumber(v1032)
			if workspace:GetAttribute("Creator") then
				v1033 = math.clamp(v1033, 0, 10)
			end
			v1031:AddItem(v1014, v1033)
			local v1034 = p1010["ALT POSITION"]
			local v1035
			if v1034 then
				local v1036 = string.split
				local v1037 = unpack
				v1035 = Vector3.new(v1037(v1036(v1034)))
			else
				v1035 = Vector3.new(0, 0, 0)
			end
			if v1035 ~= Vector3.new(0, 0, 0) then
				local v1038 = v_u_3
				local v1039 = TweenInfo.new
				local v1040 = p1010.TIME
				local v1041 = tonumber(v1040)
				if workspace:GetAttribute("Creator") then
					v1041 = math.clamp(v1041, 0, 10)
				end
				local v1042
				if p1010["EASING STYLE"] then
					v1042 = Enum.EasingStyle[p1010["EASING STYLE"]]
				else
					v1042 = Enum.EasingStyle.Linear
				end
				local v1043
				if p1010["EASING DIRECTION"] then
					v1043 = Enum.EasingDirection[p1010["EASING DIRECTION"]]
				else
					v1043 = Enum.EasingDirection.In
				end
				local v1044 = v1039(v1041, v1042, v1043)
				local v1045 = {}
				local v1046 = v_u_26(v1012, p1010, true)
				local v1047 = p1010["ALT ROTATION"] or p1010.ROTATION
				local v1048
				if v1047 then
					local v1049 = string.split
					local v1050 = unpack
					v1048 = Vector3.new(v1050(v1049(v1047)))
				else
					v1048 = Vector3.new(0, 0, 0)
				end
				local v1051 = CFrame.fromOrientation
				local v1052 = v1048.X
				local v1053 = math.rad(v1052)
				local v1054 = v1048.Y
				local v1055 = math.rad(v1054)
				local v1056 = v1048.Z
				v1045.WorldCFrame = v1046 * v1051(v1053, v1055, (math.rad(v1056)))
				v1038:Create(v1014, v1044, v1045):Play()
			end
			local v1057 = v_u_1.Parent.Itadori.CounterHit.Feint.Sparks:Clone()
			local v1058 = ColorSequence.new
			local v1059 = Color3.fromRGB
			local v1060 = string.split
			local v1061 = p1010.COLOR
			v1057.Color = v1058(v1059(unpack(v1060(v1061))), v_u_31(p1010))
			local v1062 = NumberRange.new
			local v1063 = p1010.TIME
			local v1064 = tonumber(v1063)
			if workspace:GetAttribute("Creator") then
				v1064 = math.clamp(v1064, 0, 10)
			end
			v1057.Lifetime = v1062(v1064)
			local v1065 = NumberSequence.new
			local v1066 = p1010.OPACITY
			local v1067 = tonumber(v1066)
			local v1068 = p1010["ALT OPACITY"]
			v1057.Transparency = v1065(v1067, (tonumber(v1068)))
			v1057.LightEmission = 0
			v1057.LightInfluence = 0
			v1057.Brightness = 4
			local v1069 = NumberRange.new
			local v1070 = v1057.Speed.Min
			local v1071 = p1010.SIZE
			local v1072 = tonumber(v1071)
			if workspace:GetAttribute("Creator") then
				v1072 = math.clamp(v1072, 0, 40)
			end
			local v1073 = v1070 * v1072
			local v1074 = v1057.Speed.Max
			local v1075 = p1010.SIZE
			local v1076 = tonumber(v1075)
			if workspace:GetAttribute("Creator") then
				v1076 = math.clamp(v1076, 0, 40)
			end
			v1057.Speed = v1069(v1073, v1074 * v1076)
			v1057.Size = v_u_51(v1057.Size.Keypoints, p1010)
			v1057.Parent = v1014
			local v1077 = p1010.AMOUNT
			local v1078 = tonumber(v1077)
			if workspace:GetAttribute("Creator") then
				v1078 = math.clamp(v1078, 1, 20)
			end
			v1057:Emit(v1078)
			table.insert(v1013, v1057)
		end
	end,
	["Star"] = function(p1079, p1080)
		-- upvalues: (copy) v_u_70, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51
		local v1081 = p1079:FindFirstChild("HumanoidRootPart")
		if v1081 then
			if p1080.RELATIVE ~= nil then
				p1079 = p1080.RELATIVE
			end
			if not p1079:IsA("BasePart") then
				if p1079:FindFirstChild(p1080["BODY PART"]) then
					p1079 = p1079[p1080["BODY PART"]]
				else
					p1079 = nil
				end
			end
			local v1082 = p1079 or v1081
			local v1083 = v_u_70(v1082, p1080)
			local v1084 = Instance.new("Attachment")
			v1084.Parent = v1082
			local v1085 = p1080.POSITION
			local v1086
			if v1085 then
				local v1087 = string.split
				local v1088 = unpack
				v1086 = Vector3.new(v1088(v1087(v1085)))
			else
				v1086 = Vector3.new(0, 0, 0)
			end
			local v1089 = CFrame.new(-v1086.X, v1086.Y, -v1086.Z)
			local v1090 = (v1082 and v1082.CFrame or CFrame.new()) * v1089
			local v1091 = p1080.ROTATION
			local v1092
			if v1091 then
				local v1093 = string.split
				local v1094 = unpack
				v1092 = Vector3.new(v1094(v1093(v1091)))
			else
				v1092 = Vector3.new(0, 0, 0)
			end
			local v1095 = CFrame.fromOrientation
			local v1096 = v1092.X
			local v1097 = math.rad(v1096)
			local v1098 = v1092.Y
			local v1099 = math.rad(v1098)
			local v1100 = v1092.Z
			v1084.WorldCFrame = v1090 * v1095(v1097, v1099, (math.rad(v1100)))
			local v1101 = v_u_11
			local v1102 = p1080.TIME
			local v1103 = tonumber(v1102)
			if workspace:GetAttribute("Creator") then
				v1103 = math.clamp(v1103, 0, 10)
			end
			v1101:AddItem(v1084, v1103)
			local v1104 = p1080["ALT POSITION"]
			local v1105
			if v1104 then
				local v1106 = string.split
				local v1107 = unpack
				v1105 = Vector3.new(v1107(v1106(v1104)))
			else
				v1105 = Vector3.new(0, 0, 0)
			end
			if v1105 ~= Vector3.new(0, 0, 0) then
				local v1108 = v_u_3
				local v1109 = TweenInfo.new
				local v1110 = p1080.TIME
				local v1111 = tonumber(v1110)
				if workspace:GetAttribute("Creator") then
					v1111 = math.clamp(v1111, 0, 10)
				end
				local v1112
				if p1080["EASING STYLE"] then
					v1112 = Enum.EasingStyle[p1080["EASING STYLE"]]
				else
					v1112 = Enum.EasingStyle.Linear
				end
				local v1113
				if p1080["EASING DIRECTION"] then
					v1113 = Enum.EasingDirection[p1080["EASING DIRECTION"]]
				else
					v1113 = Enum.EasingDirection.In
				end
				local v1114 = v1109(v1111, v1112, v1113)
				local v1115 = {}
				local v1116 = v_u_26(v1082, p1080, true)
				local v1117 = p1080["ALT ROTATION"] or p1080.ROTATION
				local v1118
				if v1117 then
					local v1119 = string.split
					local v1120 = unpack
					v1118 = Vector3.new(v1120(v1119(v1117)))
				else
					v1118 = Vector3.new(0, 0, 0)
				end
				local v1121 = CFrame.fromOrientation
				local v1122 = v1118.X
				local v1123 = math.rad(v1122)
				local v1124 = v1118.Y
				local v1125 = math.rad(v1124)
				local v1126 = v1118.Z
				v1115.WorldCFrame = v1116 * v1121(v1123, v1125, (math.rad(v1126)))
				v1108:Create(v1084, v1114, v1115):Play()
			end
			local v1127 = v_u_1.Parent.Itadori.CounterHit.Feint.Star:Clone()
			local v1128 = ColorSequence.new
			local v1129 = Color3.fromRGB
			local v1130 = string.split
			local v1131 = p1080.COLOR
			v1127.Color = v1128(v1129(unpack(v1130(v1131))), v_u_31(p1080))
			local v1132 = NumberRange.new
			local v1133 = p1080.TIME
			local v1134 = tonumber(v1133)
			if workspace:GetAttribute("Creator") then
				v1134 = math.clamp(v1134, 0, 10)
			end
			v1127.Lifetime = v1132(v1134)
			local v1135 = NumberSequence.new
			local v1136 = p1080.OPACITY
			local v1137 = tonumber(v1136)
			local v1138 = p1080["ALT OPACITY"]
			v1127.Transparency = v1135(v1137, (tonumber(v1138)))
			v1127.LightEmission = 0
			v1127.LightInfluence = 0
			v1127.Brightness = 4
			v1127.Size = v_u_51(v1127.Size.Keypoints, p1080)
			v1127.Parent = v1084
			local v1139 = p1080.AMOUNT
			local v1140 = tonumber(v1139)
			if workspace:GetAttribute("Creator") then
				v1140 = math.clamp(v1140, 1, 20)
			end
			v1127:Emit(v1140)
			table.insert(v1083, v1127)
		end
	end,
	["Energy Sparks"] = function(p1141, p1142)
		-- upvalues: (copy) v_u_70, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51
		local v1143 = p1141:FindFirstChild("HumanoidRootPart")
		if v1143 then
			if p1142.RELATIVE ~= nil then
				p1141 = p1142.RELATIVE
			end
			if not p1141:IsA("BasePart") then
				if p1141:FindFirstChild(p1142["BODY PART"]) then
					p1141 = p1141[p1142["BODY PART"]]
				else
					p1141 = nil
				end
			end
			local v1144 = p1141 or v1143
			local v1145 = v_u_70(v1144, p1142)
			local v1146 = Instance.new("Attachment")
			v1146.Parent = v1144
			local v1147 = p1142.POSITION
			local v1148
			if v1147 then
				local v1149 = string.split
				local v1150 = unpack
				v1148 = Vector3.new(v1150(v1149(v1147)))
			else
				v1148 = Vector3.new(0, 0, 0)
			end
			local v1151 = CFrame.new(-v1148.X, v1148.Y, -v1148.Z)
			local v1152 = (v1144 and v1144.CFrame or CFrame.new()) * v1151
			local v1153 = p1142.ROTATION
			local v1154
			if v1153 then
				local v1155 = string.split
				local v1156 = unpack
				v1154 = Vector3.new(v1156(v1155(v1153)))
			else
				v1154 = Vector3.new(0, 0, 0)
			end
			local v1157 = CFrame.fromOrientation
			local v1158 = v1154.X
			local v1159 = math.rad(v1158)
			local v1160 = v1154.Y
			local v1161 = math.rad(v1160)
			local v1162 = v1154.Z
			v1146.WorldCFrame = v1152 * v1157(v1159, v1161, (math.rad(v1162)))
			local v1163 = v_u_11
			local v1164 = p1142.TIME
			local v1165 = tonumber(v1164)
			if workspace:GetAttribute("Creator") then
				v1165 = math.clamp(v1165, 0, 10)
			end
			v1163:AddItem(v1146, v1165)
			local v1166 = p1142["ALT POSITION"]
			local v1167
			if v1166 then
				local v1168 = string.split
				local v1169 = unpack
				v1167 = Vector3.new(v1169(v1168(v1166)))
			else
				v1167 = Vector3.new(0, 0, 0)
			end
			if v1167 ~= Vector3.new(0, 0, 0) then
				local v1170 = v_u_3
				local v1171 = TweenInfo.new
				local v1172 = p1142.TIME
				local v1173 = tonumber(v1172)
				if workspace:GetAttribute("Creator") then
					v1173 = math.clamp(v1173, 0, 10)
				end
				local v1174
				if p1142["EASING STYLE"] then
					v1174 = Enum.EasingStyle[p1142["EASING STYLE"]]
				else
					v1174 = Enum.EasingStyle.Linear
				end
				local v1175
				if p1142["EASING DIRECTION"] then
					v1175 = Enum.EasingDirection[p1142["EASING DIRECTION"]]
				else
					v1175 = Enum.EasingDirection.In
				end
				local v1176 = v1171(v1173, v1174, v1175)
				local v1177 = {}
				local v1178 = v_u_26(v1144, p1142, true)
				local v1179 = p1142["ALT ROTATION"] or p1142.ROTATION
				local v1180
				if v1179 then
					local v1181 = string.split
					local v1182 = unpack
					v1180 = Vector3.new(v1182(v1181(v1179)))
				else
					v1180 = Vector3.new(0, 0, 0)
				end
				local v1183 = CFrame.fromOrientation
				local v1184 = v1180.X
				local v1185 = math.rad(v1184)
				local v1186 = v1180.Y
				local v1187 = math.rad(v1186)
				local v1188 = v1180.Z
				v1177.WorldCFrame = v1178 * v1183(v1185, v1187, (math.rad(v1188)))
				v1170:Create(v1146, v1176, v1177):Play()
			end
			local v1189 = v_u_1.Parent.Hakari.RoughHit.Sparks:Clone()
			local v1190 = ColorSequence.new
			local v1191 = Color3.fromRGB
			local v1192 = string.split
			local v1193 = p1142.COLOR
			v1189.Color = v1190(v1191(unpack(v1192(v1193))), v_u_31(p1142))
			local v1194 = NumberRange.new
			local v1195 = p1142.TIME
			local v1196 = tonumber(v1195)
			if workspace:GetAttribute("Creator") then
				v1196 = math.clamp(v1196, 0, 10)
			end
			v1189.Lifetime = v1194(v1196)
			local v1197 = NumberSequence.new
			local v1198 = p1142.OPACITY
			local v1199 = tonumber(v1198)
			local v1200 = p1142["ALT OPACITY"]
			v1189.Transparency = v1197(v1199, (tonumber(v1200)))
			local v1201 = NumberRange.new
			local v1202 = v1189.Speed.Min
			local v1203 = p1142.SIZE
			local v1204 = tonumber(v1203)
			if workspace:GetAttribute("Creator") then
				v1204 = math.clamp(v1204, 0, 40)
			end
			local v1205 = v1202 * v1204
			local v1206 = v1189.Speed.Max
			local v1207 = p1142.SIZE
			local v1208 = tonumber(v1207)
			if workspace:GetAttribute("Creator") then
				v1208 = math.clamp(v1208, 0, 40)
			end
			v1189.Speed = v1201(v1205, v1206 * v1208)
			v1189.Size = v_u_51(v1189.Size.Keypoints, p1142)
			v1189.Parent = v1146
			local v1209 = p1142.AMOUNT
			local v1210 = tonumber(v1209)
			if workspace:GetAttribute("Creator") then
				v1210 = math.clamp(v1210, 1, 20)
			end
			v1189:Emit(v1210)
			table.insert(v1145, v1189)
		end
	end,
	["Light"] = function(p1211, p1212)
		-- upvalues: (copy) v_u_70, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26
		local v1213 = p1211:FindFirstChild("HumanoidRootPart")
		if v1213 then
			if p1212.RELATIVE ~= nil then
				p1211 = p1212.RELATIVE
			end
			if not p1211:IsA("BasePart") then
				if p1211:FindFirstChild(p1212["BODY PART"]) then
					p1211 = p1211[p1212["BODY PART"]]
				else
					p1211 = nil
				end
			end
			local v1214 = p1211 or v1213
			local v1215 = v_u_70(v1214, p1212)
			local v1216 = Instance.new("Attachment")
			v1216.Parent = v1214
			local v1217 = p1212.POSITION
			local v1218
			if v1217 then
				local v1219 = string.split
				local v1220 = unpack
				v1218 = Vector3.new(v1220(v1219(v1217)))
			else
				v1218 = Vector3.new(0, 0, 0)
			end
			local v1221 = CFrame.new(-v1218.X, v1218.Y, -v1218.Z)
			local v1222 = (v1214 and v1214.CFrame or CFrame.new()) * v1221
			local v1223 = p1212.ROTATION
			local v1224
			if v1223 then
				local v1225 = string.split
				local v1226 = unpack
				v1224 = Vector3.new(v1226(v1225(v1223)))
			else
				v1224 = Vector3.new(0, 0, 0)
			end
			local v1227 = CFrame.fromOrientation
			local v1228 = v1224.X
			local v1229 = math.rad(v1228)
			local v1230 = v1224.Y
			local v1231 = math.rad(v1230)
			local v1232 = v1224.Z
			v1216.WorldCFrame = v1222 * v1227(v1229, v1231, (math.rad(v1232)))
			local v1233 = v_u_11
			local v1234 = p1212.TIME
			local v1235 = tonumber(v1234)
			if workspace:GetAttribute("Creator") then
				v1235 = math.clamp(v1235, 0, 10)
			end
			v1233:AddItem(v1216, v1235)
			local v1236 = p1212["ALT POSITION"]
			local v1237
			if v1236 then
				local v1238 = string.split
				local v1239 = unpack
				v1237 = Vector3.new(v1239(v1238(v1236)))
			else
				v1237 = Vector3.new(0, 0, 0)
			end
			if v1237 ~= Vector3.new(0, 0, 0) then
				local v1240 = v_u_3
				local v1241 = TweenInfo.new
				local v1242 = p1212.TIME
				local v1243 = tonumber(v1242)
				if workspace:GetAttribute("Creator") then
					v1243 = math.clamp(v1243, 0, 10)
				end
				local v1244
				if p1212["EASING STYLE"] then
					v1244 = Enum.EasingStyle[p1212["EASING STYLE"]]
				else
					v1244 = Enum.EasingStyle.Linear
				end
				local v1245
				if p1212["EASING DIRECTION"] then
					v1245 = Enum.EasingDirection[p1212["EASING DIRECTION"]]
				else
					v1245 = Enum.EasingDirection.In
				end
				local v1246 = v1241(v1243, v1244, v1245)
				local v1247 = {}
				local v1248 = v_u_26(v1214, p1212, true)
				local v1249 = p1212["ALT ROTATION"] or p1212.ROTATION
				local v1250
				if v1249 then
					local v1251 = string.split
					local v1252 = unpack
					v1250 = Vector3.new(v1252(v1251(v1249)))
				else
					v1250 = Vector3.new(0, 0, 0)
				end
				local v1253 = CFrame.fromOrientation
				local v1254 = v1250.X
				local v1255 = math.rad(v1254)
				local v1256 = v1250.Y
				local v1257 = math.rad(v1256)
				local v1258 = v1250.Z
				v1247.WorldCFrame = v1248 * v1253(v1255, v1257, (math.rad(v1258)))
				v1240:Create(v1216, v1246, v1247):Play()
			end
			local v1259 = Instance.new("PointLight")
			local v1260 = p1212.OPACITY
			v1259.Brightness = tonumber(v1260)
			local v1261 = Color3.fromRGB
			local v1262 = string.split
			local v1263 = p1212.COLOR
			v1259.Color = v1261(unpack(v1262(v1263)))
			local v1264 = p1212.SIZE
			local v1265 = tonumber(v1264)
			if workspace:GetAttribute("Creator") then
				v1265 = math.clamp(v1265, 0, 40)
			end
			v1259.Range = v1265
			v1259.Parent = v1216
			local v1266 = v_u_3
			local v1267 = TweenInfo.new
			local v1268 = p1212.TIME
			local v1269 = tonumber(v1268)
			if workspace:GetAttribute("Creator") then
				v1269 = math.clamp(v1269, 0, 10)
			end
			local v1270
			if p1212["EASING STYLE"] then
				v1270 = Enum.EasingStyle[p1212["EASING STYLE"]]
			else
				v1270 = Enum.EasingStyle.Linear
			end
			local v1271
			if p1212["EASING DIRECTION"] then
				v1271 = Enum.EasingDirection[p1212["EASING DIRECTION"]]
			else
				v1271 = Enum.EasingDirection.In
			end
			local v1272 = v1267(v1269, v1270, v1271)
			local v1273 = {}
			local v1274 = p1212["ALT OPACITY"]
			v1273.Brightness = tonumber(v1274)
			local v1275 = Color3.fromRGB
			local v1276 = string.split
			local v1277 = p1212["ALT COLOR"]
			v1273.Color = v1275(unpack(v1276(v1277)))
			v1266:Create(v1259, v1272, v1273):Play()
			table.insert(v1215, v1216)
		end
	end,
	["360 Wind"] = function(p1278, p1279)
		-- upvalues: (copy) v_u_70, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51
		local v1280 = p1278:FindFirstChild("HumanoidRootPart")
		if v1280 then
			if p1279.RELATIVE ~= nil then
				p1278 = p1279.RELATIVE
			end
			if not p1278:IsA("BasePart") then
				if p1278:FindFirstChild(p1279["BODY PART"]) then
					p1278 = p1278[p1279["BODY PART"]]
				else
					p1278 = nil
				end
			end
			local v1281 = p1278 or v1280
			local v1282 = v_u_70(v1281, p1279)
			local v1283 = Instance.new("Attachment")
			v1283.Parent = v1281
			local v1284 = p1279.POSITION
			local v1285
			if v1284 then
				local v1286 = string.split
				local v1287 = unpack
				v1285 = Vector3.new(v1287(v1286(v1284)))
			else
				v1285 = Vector3.new(0, 0, 0)
			end
			local v1288 = CFrame.new(-v1285.X, v1285.Y, -v1285.Z)
			local v1289 = (v1281 and v1281.CFrame or CFrame.new()) * v1288
			local v1290 = p1279.ROTATION
			local v1291
			if v1290 then
				local v1292 = string.split
				local v1293 = unpack
				v1291 = Vector3.new(v1293(v1292(v1290)))
			else
				v1291 = Vector3.new(0, 0, 0)
			end
			local v1294 = CFrame.fromOrientation
			local v1295 = v1291.X
			local v1296 = math.rad(v1295)
			local v1297 = v1291.Y
			local v1298 = math.rad(v1297)
			local v1299 = v1291.Z
			v1283.WorldCFrame = v1289 * v1294(v1296, v1298, (math.rad(v1299)))
			local v1300 = v_u_11
			local v1301 = p1279.TIME
			local v1302 = tonumber(v1301)
			if workspace:GetAttribute("Creator") then
				v1302 = math.clamp(v1302, 0, 10)
			end
			v1300:AddItem(v1283, v1302)
			local v1303 = p1279["ALT POSITION"]
			local v1304
			if v1303 then
				local v1305 = string.split
				local v1306 = unpack
				v1304 = Vector3.new(v1306(v1305(v1303)))
			else
				v1304 = Vector3.new(0, 0, 0)
			end
			if v1304 ~= Vector3.new(0, 0, 0) then
				local v1307 = v_u_3
				local v1308 = TweenInfo.new
				local v1309 = p1279.TIME
				local v1310 = tonumber(v1309)
				if workspace:GetAttribute("Creator") then
					v1310 = math.clamp(v1310, 0, 10)
				end
				local v1311
				if p1279["EASING STYLE"] then
					v1311 = Enum.EasingStyle[p1279["EASING STYLE"]]
				else
					v1311 = Enum.EasingStyle.Linear
				end
				local v1312
				if p1279["EASING DIRECTION"] then
					v1312 = Enum.EasingDirection[p1279["EASING DIRECTION"]]
				else
					v1312 = Enum.EasingDirection.In
				end
				local v1313 = v1308(v1310, v1311, v1312)
				local v1314 = {}
				local v1315 = v_u_26(v1281, p1279, true)
				local v1316 = p1279["ALT ROTATION"] or p1279.ROTATION
				local v1317
				if v1316 then
					local v1318 = string.split
					local v1319 = unpack
					v1317 = Vector3.new(v1319(v1318(v1316)))
				else
					v1317 = Vector3.new(0, 0, 0)
				end
				local v1320 = CFrame.fromOrientation
				local v1321 = v1317.X
				local v1322 = math.rad(v1321)
				local v1323 = v1317.Y
				local v1324 = math.rad(v1323)
				local v1325 = v1317.Z
				v1314.WorldCFrame = v1315 * v1320(v1322, v1324, (math.rad(v1325)))
				v1307:Create(v1283, v1313, v1314):Play()
			end
			local v1326 = v_u_1.Parent.Hakari.RoughHit.Wind:Clone()
			local v1327 = ColorSequence.new
			local v1328 = Color3.fromRGB
			local v1329 = string.split
			local v1330 = p1279.COLOR
			v1326.Color = v1327(v1328(unpack(v1329(v1330))), v_u_31(p1279))
			local v1331 = NumberRange.new
			local v1332 = p1279.TIME
			local v1333 = tonumber(v1332)
			if workspace:GetAttribute("Creator") then
				v1333 = math.clamp(v1333, 0, 10)
			end
			v1326.Lifetime = v1331(v1333)
			local v1334 = NumberSequence.new
			local v1335 = p1279.OPACITY
			local v1336 = tonumber(v1335)
			local v1337 = p1279["ALT OPACITY"]
			v1326.Transparency = v1334(v1336, (tonumber(v1337)))
			v1326.Size = v_u_51(v1326.Size.Keypoints, p1279)
			v1326.Parent = v1283
			local v1338 = p1279.AMOUNT
			local v1339 = tonumber(v1338)
			if workspace:GetAttribute("Creator") then
				v1339 = math.clamp(v1339, 1, 20)
			end
			v1326:Emit(v1339)
			table.insert(v1282, v1326)
		end
	end,
	["Circle Glow"] = function(p1340, p1341)
		-- upvalues: (copy) v_u_70, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51
		local v1342 = p1340:FindFirstChild("HumanoidRootPart")
		if v1342 then
			if p1341.RELATIVE ~= nil then
				p1340 = p1341.RELATIVE
			end
			if not p1340:IsA("BasePart") then
				if p1340:FindFirstChild(p1341["BODY PART"]) then
					p1340 = p1340[p1341["BODY PART"]]
				else
					p1340 = nil
				end
			end
			local v1343 = p1340 or v1342
			local v1344 = v_u_70(v1343, p1341)
			local v1345 = Instance.new("Attachment")
			v1345.Parent = v1343
			local v1346 = p1341.POSITION
			local v1347
			if v1346 then
				local v1348 = string.split
				local v1349 = unpack
				v1347 = Vector3.new(v1349(v1348(v1346)))
			else
				v1347 = Vector3.new(0, 0, 0)
			end
			local v1350 = CFrame.new(-v1347.X, v1347.Y, -v1347.Z)
			local v1351 = (v1343 and v1343.CFrame or CFrame.new()) * v1350
			local v1352 = p1341.ROTATION
			local v1353
			if v1352 then
				local v1354 = string.split
				local v1355 = unpack
				v1353 = Vector3.new(v1355(v1354(v1352)))
			else
				v1353 = Vector3.new(0, 0, 0)
			end
			local v1356 = CFrame.fromOrientation
			local v1357 = v1353.X
			local v1358 = math.rad(v1357)
			local v1359 = v1353.Y
			local v1360 = math.rad(v1359)
			local v1361 = v1353.Z
			v1345.WorldCFrame = v1351 * v1356(v1358, v1360, (math.rad(v1361)))
			local v1362 = v_u_11
			local v1363 = p1341.TIME
			local v1364 = tonumber(v1363)
			if workspace:GetAttribute("Creator") then
				v1364 = math.clamp(v1364, 0, 10)
			end
			v1362:AddItem(v1345, v1364)
			local v1365 = p1341["ALT POSITION"]
			local v1366
			if v1365 then
				local v1367 = string.split
				local v1368 = unpack
				v1366 = Vector3.new(v1368(v1367(v1365)))
			else
				v1366 = Vector3.new(0, 0, 0)
			end
			if v1366 ~= Vector3.new(0, 0, 0) then
				local v1369 = v_u_3
				local v1370 = TweenInfo.new
				local v1371 = p1341.TIME
				local v1372 = tonumber(v1371)
				if workspace:GetAttribute("Creator") then
					v1372 = math.clamp(v1372, 0, 10)
				end
				local v1373
				if p1341["EASING STYLE"] then
					v1373 = Enum.EasingStyle[p1341["EASING STYLE"]]
				else
					v1373 = Enum.EasingStyle.Linear
				end
				local v1374
				if p1341["EASING DIRECTION"] then
					v1374 = Enum.EasingDirection[p1341["EASING DIRECTION"]]
				else
					v1374 = Enum.EasingDirection.In
				end
				local v1375 = v1370(v1372, v1373, v1374)
				local v1376 = {}
				local v1377 = v_u_26(v1343, p1341, true)
				local v1378 = p1341["ALT ROTATION"] or p1341.ROTATION
				local v1379
				if v1378 then
					local v1380 = string.split
					local v1381 = unpack
					v1379 = Vector3.new(v1381(v1380(v1378)))
				else
					v1379 = Vector3.new(0, 0, 0)
				end
				local v1382 = CFrame.fromOrientation
				local v1383 = v1379.X
				local v1384 = math.rad(v1383)
				local v1385 = v1379.Y
				local v1386 = math.rad(v1385)
				local v1387 = v1379.Z
				v1376.WorldCFrame = v1377 * v1382(v1384, v1386, (math.rad(v1387)))
				v1369:Create(v1345, v1375, v1376):Play()
			end
			local v1388 = v_u_1.Parent.Hakari.RoughHit.Glow:Clone()
			local v1389 = ColorSequence.new
			local v1390 = Color3.fromRGB
			local v1391 = string.split
			local v1392 = p1341.COLOR
			v1388.Color = v1389(v1390(unpack(v1391(v1392))), v_u_31(p1341))
			local v1393 = NumberRange.new
			local v1394 = p1341.TIME
			local v1395 = tonumber(v1394)
			if workspace:GetAttribute("Creator") then
				v1395 = math.clamp(v1395, 0, 10)
			end
			v1388.Lifetime = v1393(v1395)
			local v1396 = NumberSequence.new
			local v1397 = p1341.OPACITY
			local v1398 = tonumber(v1397)
			local v1399 = p1341["ALT OPACITY"]
			v1388.Transparency = v1396(v1398, (tonumber(v1399)))
			v1388.Size = v_u_51(v1388.Size.Keypoints, p1341)
			v1388.Parent = v1345
			local v1400 = p1341.AMOUNT
			local v1401 = tonumber(v1400)
			if workspace:GetAttribute("Creator") then
				v1401 = math.clamp(v1401, 1, 20)
			end
			v1388:Emit(v1401)
			table.insert(v1344, v1388)
		end
	end,
	["Beams"] = function(p1402, p1403)
		-- upvalues: (copy) v_u_70, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51
		local v1404 = p1402:FindFirstChild("HumanoidRootPart")
		if v1404 then
			if p1403.RELATIVE ~= nil then
				p1402 = p1403.RELATIVE
			end
			if not p1402:IsA("BasePart") then
				if p1402:FindFirstChild(p1403["BODY PART"]) then
					p1402 = p1402[p1403["BODY PART"]]
				else
					p1402 = nil
				end
			end
			local v1405 = p1402 or v1404
			local v1406 = v_u_70(v1405, p1403)
			local v1407 = Instance.new("Attachment")
			v1407.Parent = v1405
			local v1408 = p1403.POSITION
			local v1409
			if v1408 then
				local v1410 = string.split
				local v1411 = unpack
				v1409 = Vector3.new(v1411(v1410(v1408)))
			else
				v1409 = Vector3.new(0, 0, 0)
			end
			local v1412 = CFrame.new(-v1409.X, v1409.Y, -v1409.Z)
			local v1413 = (v1405 and v1405.CFrame or CFrame.new()) * v1412
			local v1414 = p1403.ROTATION
			local v1415
			if v1414 then
				local v1416 = string.split
				local v1417 = unpack
				v1415 = Vector3.new(v1417(v1416(v1414)))
			else
				v1415 = Vector3.new(0, 0, 0)
			end
			local v1418 = CFrame.fromOrientation
			local v1419 = v1415.X
			local v1420 = math.rad(v1419)
			local v1421 = v1415.Y
			local v1422 = math.rad(v1421)
			local v1423 = v1415.Z
			v1407.WorldCFrame = v1413 * v1418(v1420, v1422, (math.rad(v1423)))
			local v1424 = v_u_11
			local v1425 = p1403.TIME
			local v1426 = tonumber(v1425)
			if workspace:GetAttribute("Creator") then
				v1426 = math.clamp(v1426, 0, 10)
			end
			v1424:AddItem(v1407, v1426)
			local v1427 = p1403["ALT POSITION"]
			local v1428
			if v1427 then
				local v1429 = string.split
				local v1430 = unpack
				v1428 = Vector3.new(v1430(v1429(v1427)))
			else
				v1428 = Vector3.new(0, 0, 0)
			end
			if v1428 ~= Vector3.new(0, 0, 0) then
				local v1431 = v_u_3
				local v1432 = TweenInfo.new
				local v1433 = p1403.TIME
				local v1434 = tonumber(v1433)
				if workspace:GetAttribute("Creator") then
					v1434 = math.clamp(v1434, 0, 10)
				end
				local v1435
				if p1403["EASING STYLE"] then
					v1435 = Enum.EasingStyle[p1403["EASING STYLE"]]
				else
					v1435 = Enum.EasingStyle.Linear
				end
				local v1436
				if p1403["EASING DIRECTION"] then
					v1436 = Enum.EasingDirection[p1403["EASING DIRECTION"]]
				else
					v1436 = Enum.EasingDirection.In
				end
				local v1437 = v1432(v1434, v1435, v1436)
				local v1438 = {}
				local v1439 = v_u_26(v1405, p1403, true)
				local v1440 = p1403["ALT ROTATION"] or p1403.ROTATION
				local v1441
				if v1440 then
					local v1442 = string.split
					local v1443 = unpack
					v1441 = Vector3.new(v1443(v1442(v1440)))
				else
					v1441 = Vector3.new(0, 0, 0)
				end
				local v1444 = CFrame.fromOrientation
				local v1445 = v1441.X
				local v1446 = math.rad(v1445)
				local v1447 = v1441.Y
				local v1448 = math.rad(v1447)
				local v1449 = v1441.Z
				v1438.WorldCFrame = v1439 * v1444(v1446, v1448, (math.rad(v1449)))
				v1431:Create(v1407, v1437, v1438):Play()
			end
			local v1450 = v_u_1.Parent.Hakari.RoughHit.Wind2:Clone()
			local v1451 = ColorSequence.new
			local v1452 = Color3.fromRGB
			local v1453 = string.split
			local v1454 = p1403.COLOR
			v1450.Color = v1451(v1452(unpack(v1453(v1454))), v_u_31(p1403))
			local v1455 = NumberRange.new
			local v1456 = p1403.TIME
			local v1457 = tonumber(v1456)
			if workspace:GetAttribute("Creator") then
				v1457 = math.clamp(v1457, 0, 10)
			end
			v1450.Lifetime = v1455(v1457)
			local v1458 = NumberSequence.new
			local v1459 = p1403.OPACITY
			local v1460 = tonumber(v1459)
			local v1461 = p1403["ALT OPACITY"]
			v1450.Transparency = v1458(v1460, (tonumber(v1461)))
			v1450.Size = v_u_51(v1450.Size.Keypoints, p1403)
			v1450.LockedToPart = true
			v1450.Parent = v1407
			local v1462 = p1403.AMOUNT
			local v1463 = tonumber(v1462)
			if workspace:GetAttribute("Creator") then
				v1463 = math.clamp(v1463, 1, 20)
			end
			v1450:Emit(v1463)
			table.insert(v1406, v1450)
		end
	end,
	["Star Outline"] = function(p1464, p1465)
		-- upvalues: (copy) v_u_70, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51
		local v1466 = p1464:FindFirstChild("HumanoidRootPart")
		if v1466 then
			if p1465.RELATIVE ~= nil then
				p1464 = p1465.RELATIVE
			end
			if not p1464:IsA("BasePart") then
				if p1464:FindFirstChild(p1465["BODY PART"]) then
					p1464 = p1464[p1465["BODY PART"]]
				else
					p1464 = nil
				end
			end
			local v1467 = p1464 or v1466
			local v1468 = v_u_70(v1467, p1465)
			local v1469 = Instance.new("Attachment")
			v1469.Parent = v1467
			local v1470 = p1465.POSITION
			local v1471
			if v1470 then
				local v1472 = string.split
				local v1473 = unpack
				v1471 = Vector3.new(v1473(v1472(v1470)))
			else
				v1471 = Vector3.new(0, 0, 0)
			end
			local v1474 = CFrame.new(-v1471.X, v1471.Y, -v1471.Z)
			local v1475 = (v1467 and v1467.CFrame or CFrame.new()) * v1474
			local v1476 = p1465.ROTATION
			local v1477
			if v1476 then
				local v1478 = string.split
				local v1479 = unpack
				v1477 = Vector3.new(v1479(v1478(v1476)))
			else
				v1477 = Vector3.new(0, 0, 0)
			end
			local v1480 = CFrame.fromOrientation
			local v1481 = v1477.X
			local v1482 = math.rad(v1481)
			local v1483 = v1477.Y
			local v1484 = math.rad(v1483)
			local v1485 = v1477.Z
			v1469.WorldCFrame = v1475 * v1480(v1482, v1484, (math.rad(v1485)))
			local v1486 = v_u_11
			local v1487 = p1465.TIME
			local v1488 = tonumber(v1487)
			if workspace:GetAttribute("Creator") then
				v1488 = math.clamp(v1488, 0, 10)
			end
			v1486:AddItem(v1469, v1488)
			local v1489 = p1465["ALT POSITION"]
			local v1490
			if v1489 then
				local v1491 = string.split
				local v1492 = unpack
				v1490 = Vector3.new(v1492(v1491(v1489)))
			else
				v1490 = Vector3.new(0, 0, 0)
			end
			if v1490 ~= Vector3.new(0, 0, 0) then
				local v1493 = v_u_3
				local v1494 = TweenInfo.new
				local v1495 = p1465.TIME
				local v1496 = tonumber(v1495)
				if workspace:GetAttribute("Creator") then
					v1496 = math.clamp(v1496, 0, 10)
				end
				local v1497
				if p1465["EASING STYLE"] then
					v1497 = Enum.EasingStyle[p1465["EASING STYLE"]]
				else
					v1497 = Enum.EasingStyle.Linear
				end
				local v1498
				if p1465["EASING DIRECTION"] then
					v1498 = Enum.EasingDirection[p1465["EASING DIRECTION"]]
				else
					v1498 = Enum.EasingDirection.In
				end
				local v1499 = v1494(v1496, v1497, v1498)
				local v1500 = {}
				local v1501 = v_u_26(v1467, p1465, true)
				local v1502 = p1465["ALT ROTATION"] or p1465.ROTATION
				local v1503
				if v1502 then
					local v1504 = string.split
					local v1505 = unpack
					v1503 = Vector3.new(v1505(v1504(v1502)))
				else
					v1503 = Vector3.new(0, 0, 0)
				end
				local v1506 = CFrame.fromOrientation
				local v1507 = v1503.X
				local v1508 = math.rad(v1507)
				local v1509 = v1503.Y
				local v1510 = math.rad(v1509)
				local v1511 = v1503.Z
				v1500.WorldCFrame = v1501 * v1506(v1508, v1510, (math.rad(v1511)))
				v1493:Create(v1469, v1499, v1500):Play()
			end
			local v1512 = v_u_1.Parent.Hakari.Indicators.BallFire.Ring:Clone()
			local v1513 = ColorSequence.new
			local v1514 = Color3.fromRGB
			local v1515 = string.split
			local v1516 = p1465.COLOR
			v1512.Color = v1513(v1514(unpack(v1515(v1516))), v_u_31(p1465))
			local v1517 = NumberRange.new
			local v1518 = p1465.TIME
			local v1519 = tonumber(v1518)
			if workspace:GetAttribute("Creator") then
				v1519 = math.clamp(v1519, 0, 10)
			end
			v1512.Lifetime = v1517(v1519)
			local v1520 = NumberSequence.new
			local v1521 = p1465.OPACITY
			local v1522 = tonumber(v1521)
			local v1523 = p1465["ALT OPACITY"]
			v1512.Transparency = v1520(v1522, (tonumber(v1523)))
			v1512.Size = v_u_51(v1512.Size.Keypoints, p1465)
			v1512.LockedToPart = true
			v1512.Parent = v1469
			local v1524 = p1465.AMOUNT
			local v1525 = tonumber(v1524)
			if workspace:GetAttribute("Creator") then
				v1525 = math.clamp(v1525, 1, 20)
			end
			v1512:Emit(v1525)
			table.insert(v1468, v1512)
		end
	end,
	["Wind Ring"] = function(p1526, p1527)
		-- upvalues: (copy) v_u_70, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51
		local v1528 = p1526:FindFirstChild("HumanoidRootPart")
		if v1528 then
			if p1527.RELATIVE ~= nil then
				p1526 = p1527.RELATIVE
			end
			if not p1526:IsA("BasePart") then
				if p1526:FindFirstChild(p1527["BODY PART"]) then
					p1526 = p1526[p1527["BODY PART"]]
				else
					p1526 = nil
				end
			end
			local v1529 = p1526 or v1528
			local v1530 = v_u_70(v1529, p1527)
			local v1531 = Instance.new("Attachment")
			v1531.Parent = v1529
			local v1532 = p1527.POSITION
			local v1533
			if v1532 then
				local v1534 = string.split
				local v1535 = unpack
				v1533 = Vector3.new(v1535(v1534(v1532)))
			else
				v1533 = Vector3.new(0, 0, 0)
			end
			local v1536 = CFrame.new(-v1533.X, v1533.Y, -v1533.Z)
			local v1537 = (v1529 and v1529.CFrame or CFrame.new()) * v1536
			local v1538 = p1527.ROTATION
			local v1539
			if v1538 then
				local v1540 = string.split
				local v1541 = unpack
				v1539 = Vector3.new(v1541(v1540(v1538)))
			else
				v1539 = Vector3.new(0, 0, 0)
			end
			local v1542 = CFrame.fromOrientation
			local v1543 = v1539.X
			local v1544 = math.rad(v1543)
			local v1545 = v1539.Y
			local v1546 = math.rad(v1545)
			local v1547 = v1539.Z
			v1531.WorldCFrame = v1537 * v1542(v1544, v1546, (math.rad(v1547)))
			local v1548 = v_u_11
			local v1549 = p1527.TIME
			local v1550 = tonumber(v1549)
			if workspace:GetAttribute("Creator") then
				v1550 = math.clamp(v1550, 0, 10)
			end
			v1548:AddItem(v1531, v1550)
			local v1551 = p1527["ALT POSITION"]
			local v1552
			if v1551 then
				local v1553 = string.split
				local v1554 = unpack
				v1552 = Vector3.new(v1554(v1553(v1551)))
			else
				v1552 = Vector3.new(0, 0, 0)
			end
			if v1552 ~= Vector3.new(0, 0, 0) then
				local v1555 = v_u_3
				local v1556 = TweenInfo.new
				local v1557 = p1527.TIME
				local v1558 = tonumber(v1557)
				if workspace:GetAttribute("Creator") then
					v1558 = math.clamp(v1558, 0, 10)
				end
				local v1559
				if p1527["EASING STYLE"] then
					v1559 = Enum.EasingStyle[p1527["EASING STYLE"]]
				else
					v1559 = Enum.EasingStyle.Linear
				end
				local v1560
				if p1527["EASING DIRECTION"] then
					v1560 = Enum.EasingDirection[p1527["EASING DIRECTION"]]
				else
					v1560 = Enum.EasingDirection.In
				end
				local v1561 = v1556(v1558, v1559, v1560)
				local v1562 = {}
				local v1563 = v_u_26(v1529, p1527, true)
				local v1564 = p1527["ALT ROTATION"] or p1527.ROTATION
				local v1565
				if v1564 then
					local v1566 = string.split
					local v1567 = unpack
					v1565 = Vector3.new(v1567(v1566(v1564)))
				else
					v1565 = Vector3.new(0, 0, 0)
				end
				local v1568 = CFrame.fromOrientation
				local v1569 = v1565.X
				local v1570 = math.rad(v1569)
				local v1571 = v1565.Y
				local v1572 = math.rad(v1571)
				local v1573 = v1565.Z
				v1562.WorldCFrame = v1563 * v1568(v1570, v1572, (math.rad(v1573)))
				v1555:Create(v1531, v1561, v1562):Play()
			end
			local v1574 = v_u_1.Parent.Hakari.Indicators.BallFire.Wind:Clone()
			local v1575 = ColorSequence.new
			local v1576 = Color3.fromRGB
			local v1577 = string.split
			local v1578 = p1527.COLOR
			v1574.Color = v1575(v1576(unpack(v1577(v1578))), v_u_31(p1527))
			local v1579 = NumberRange.new
			local v1580 = p1527.TIME
			local v1581 = tonumber(v1580)
			if workspace:GetAttribute("Creator") then
				v1581 = math.clamp(v1581, 0, 10)
			end
			v1574.Lifetime = v1579(v1581)
			local v1582 = NumberSequence.new
			local v1583 = p1527.OPACITY
			local v1584 = tonumber(v1583)
			local v1585 = p1527["ALT OPACITY"]
			v1574.Transparency = v1582(v1584, (tonumber(v1585)))
			v1574.Size = v_u_51(v1574.Size.Keypoints, p1527)
			v1574.LockedToPart = true
			v1574.Speed = NumberRange.new(0.01)
			v1574.Parent = v1531
			local v1586 = p1527.AMOUNT
			local v1587 = tonumber(v1586)
			if workspace:GetAttribute("Creator") then
				v1587 = math.clamp(v1587, 1, 20)
			end
			v1574:Emit(v1587)
			table.insert(v1530, v1574)
		end
	end,
	["Wind Streak"] = function(p1588, p1589)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_31, (copy) v_u_51
		local v1590 = p1588:FindFirstChild("HumanoidRootPart")
		if v1590 then
			if p1589.RELATIVE ~= nil then
				p1588 = p1589.RELATIVE
			end
			if not p1588:IsA("BasePart") then
				if p1588:FindFirstChild(p1589["BODY PART"]) then
					p1588 = p1588[p1589["BODY PART"]]
				else
					p1588 = nil
				end
			end
			local v1591 = p1588 or v1590
			local v1592 = v_u_70(v1591, p1589)
			local v1593 = v_u_1.Parent.Itadori.RushWind.Dash1:Clone()
			v1593.Parent = v1591
			local v1594 = p1589.POSITION
			local v1595
			if v1594 then
				local v1596 = string.split
				local v1597 = unpack
				v1595 = Vector3.new(v1597(v1596(v1594)))
			else
				v1595 = Vector3.new(0, 0, 0)
			end
			local v1598 = CFrame.new(-v1595.X, v1595.Y, -v1595.Z)
			local v1599 = (v1591 and v1591.CFrame or CFrame.new()) * v1598
			local v1600 = p1589.ROTATION
			local v1601
			if v1600 then
				local v1602 = string.split
				local v1603 = unpack
				v1601 = Vector3.new(v1603(v1602(v1600)))
			else
				v1601 = Vector3.new(0, 0, 0)
			end
			local v1604 = CFrame.fromOrientation
			local v1605 = v1601.X
			local v1606 = math.rad(v1605)
			local v1607 = v1601.Y
			local v1608 = math.rad(v1607)
			local v1609 = v1601.Z
			v1593.WorldCFrame = v1599 * v1604(v1606, v1608, (math.rad(v1609)))
			local v1610 = v_u_11
			local v1611 = p1589.TIME
			local v1612 = tonumber(v1611)
			if workspace:GetAttribute("Creator") then
				v1612 = math.clamp(v1612, 0, 10)
			end
			v1610:AddItem(v1593, v1612)
			local v1613 = p1589["ALT POSITION"]
			local v1614
			if v1613 then
				local v1615 = string.split
				local v1616 = unpack
				v1614 = Vector3.new(v1616(v1615(v1613)))
			else
				v1614 = Vector3.new(0, 0, 0)
			end
			if v1614 ~= Vector3.new(0, 0, 0) then
				local v1617 = v_u_3
				local v1618 = TweenInfo.new
				local v1619 = p1589.TIME
				local v1620 = tonumber(v1619)
				if workspace:GetAttribute("Creator") then
					v1620 = math.clamp(v1620, 0, 10)
				end
				local v1621
				if p1589["EASING STYLE"] then
					v1621 = Enum.EasingStyle[p1589["EASING STYLE"]]
				else
					v1621 = Enum.EasingStyle.Linear
				end
				local v1622
				if p1589["EASING DIRECTION"] then
					v1622 = Enum.EasingDirection[p1589["EASING DIRECTION"]]
				else
					v1622 = Enum.EasingDirection.In
				end
				local v1623 = v1618(v1620, v1621, v1622)
				local v1624 = {}
				local v1625 = v_u_26(v1591, p1589, true)
				local v1626 = p1589["ALT ROTATION"] or p1589.ROTATION
				local v1627
				if v1626 then
					local v1628 = string.split
					local v1629 = unpack
					v1627 = Vector3.new(v1629(v1628(v1626)))
				else
					v1627 = Vector3.new(0, 0, 0)
				end
				local v1630 = CFrame.fromOrientation
				local v1631 = v1627.X
				local v1632 = math.rad(v1631)
				local v1633 = v1627.Y
				local v1634 = math.rad(v1633)
				local v1635 = v1627.Z
				v1624.WorldCFrame = v1625 * v1630(v1632, v1634, (math.rad(v1635)))
				v1617:Create(v1593, v1623, v1624):Play()
			end
			local v1636 = v1593.Dash
			local v1637 = ColorSequence.new
			local v1638 = Color3.fromRGB
			local v1639 = string.split
			local v1640 = p1589.COLOR
			v1636.Color = v1637(v1638(unpack(v1639(v1640))), v_u_31(p1589))
			local v1641 = NumberRange.new
			local v1642 = p1589.TIME
			local v1643 = tonumber(v1642)
			if workspace:GetAttribute("Creator") then
				v1643 = math.clamp(v1643, 0, 10)
			end
			v1636.Lifetime = v1641(v1643)
			local v1644 = NumberSequence.new
			local v1645 = p1589.OPACITY
			local v1646 = tonumber(v1645)
			local v1647 = p1589["ALT OPACITY"]
			v1636.Transparency = v1644(v1646, (tonumber(v1647)))
			v1636.Size = v_u_51(v1636.Size.Keypoints, p1589)
			v1636.Parent = v1593
			local v1648 = p1589.AMOUNT
			local v1649 = tonumber(v1648)
			if workspace:GetAttribute("Creator") then
				v1649 = math.clamp(v1649, 1, 20)
			end
			v1636:Emit(v1649)
			table.insert(v1592, v1636)
		end
	end,
	["Black Flash"] = function(p1650, p1651)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_31, (copy) v_u_51
		local v1652 = p1650:FindFirstChild("HumanoidRootPart")
		if v1652 then
			if p1651.RELATIVE ~= nil then
				p1650 = p1651.RELATIVE
			end
			if not p1650:IsA("BasePart") then
				if p1650:FindFirstChild(p1651["BODY PART"]) then
					p1650 = p1650[p1651["BODY PART"]]
				else
					p1650 = nil
				end
			end
			local v1653 = p1650 or v1652
			local v1654 = v_u_70(v1653, p1651)
			local v1655 = v_u_1.Parent.Itadori.DivergentFist.BlackFlashHit:Clone()
			local v1656 = p1651.POSITION
			local v1657
			if v1656 then
				local v1658 = string.split
				local v1659 = unpack
				v1657 = Vector3.new(v1659(v1658(v1656)))
			else
				v1657 = Vector3.new(0, 0, 0)
			end
			local v1660 = CFrame.new(-v1657.X, v1657.Y, -v1657.Z)
			local v1661 = (v1653 and v1653.CFrame or CFrame.new()) * v1660
			local v1662 = p1651.ROTATION
			local v1663
			if v1662 then
				local v1664 = string.split
				local v1665 = unpack
				v1663 = Vector3.new(v1665(v1664(v1662)))
			else
				v1663 = Vector3.new(0, 0, 0)
			end
			local v1666 = CFrame.fromOrientation
			local v1667 = v1663.X
			local v1668 = math.rad(v1667)
			local v1669 = v1663.Y
			local v1670 = math.rad(v1669)
			local v1671 = v1663.Z
			v1655.CFrame = v1661 * v1666(v1668, v1670, (math.rad(v1671)))
			v1655.Parent = workspace.Effects
			local v1672 = v_u_11
			local v1673 = 0.8
			local v1674 = p1651.TIME
			local v1675 = tonumber(v1674)
			if workspace:GetAttribute("Creator") then
				v1675 = math.clamp(v1675, 0, 10)
			end
			v1672:AddItem(v1655, v1673 * v1675)
			local v1676 = p1651["ALT POSITION"]
			local v1677
			if v1676 then
				local v1678 = string.split
				local v1679 = unpack
				v1677 = Vector3.new(v1679(v1678(v1676)))
			else
				v1677 = Vector3.new(0, 0, 0)
			end
			if v1677 ~= Vector3.new(0, 0, 0) then
				local v1680 = v_u_3
				local v1681 = TweenInfo.new
				local v1682 = p1651.TIME
				local v1683 = tonumber(v1682)
				if workspace:GetAttribute("Creator") then
					v1683 = math.clamp(v1683, 0, 10)
				end
				local v1684
				if p1651["EASING STYLE"] then
					v1684 = Enum.EasingStyle[p1651["EASING STYLE"]]
				else
					v1684 = Enum.EasingStyle.Linear
				end
				local v1685
				if p1651["EASING DIRECTION"] then
					v1685 = Enum.EasingDirection[p1651["EASING DIRECTION"]]
				else
					v1685 = Enum.EasingDirection.In
				end
				local v1686 = v1681(v1683, v1684, v1685)
				local v1687 = {}
				local v1688 = v_u_26(v1653, p1651, true)
				local v1689 = p1651["ALT ROTATION"] or p1651.ROTATION
				local v1690
				if v1689 then
					local v1691 = string.split
					local v1692 = unpack
					v1690 = Vector3.new(v1692(v1691(v1689)))
				else
					v1690 = Vector3.new(0, 0, 0)
				end
				local v1693 = CFrame.fromOrientation
				local v1694 = v1690.X
				local v1695 = math.rad(v1694)
				local v1696 = v1690.Y
				local v1697 = math.rad(v1696)
				local v1698 = v1690.Z
				v1687.CFrame = v1688 * v1693(v1695, v1697, (math.rad(v1698)))
				v1680:Create(v1655, v1686, v1687):Play()
			end
			for _, v1699 in v1655:GetChildren() do
				if v1699:IsA("ParticleEmitter") then
					if v1699.Name ~= "Wind" then
						local v1700 = ColorSequence.new
						local v1701 = Color3.fromRGB
						local v1702 = string.split
						local v1703 = p1651.COLOR
						v1699.Color = v1700(v1701(unpack(v1702(v1703))), v_u_31(p1651))
						local v1704 = NumberSequence.new
						local v1705 = p1651.OPACITY
						local v1706 = tonumber(v1705)
						local v1707 = p1651["ALT OPACITY"]
						v1699.Transparency = v1704(v1706, (tonumber(v1707)))
					end
					local v1708 = NumberRange.new
					local v1709 = v1699.Lifetime.Min
					local v1710 = p1651.TIME
					local v1711 = tonumber(v1710)
					if workspace:GetAttribute("Creator") then
						v1711 = math.clamp(v1711, 0, 10)
					end
					local v1712 = v1709 * v1711
					local v1713 = v1699.Lifetime.Max
					local v1714 = p1651.TIME
					local v1715 = tonumber(v1714)
					if workspace:GetAttribute("Creator") then
						v1715 = math.clamp(v1715, 0, 10)
					end
					v1699.Lifetime = v1708(v1712, v1713 * v1715)
					v1699.Size = v_u_51(v1699.Size.Keypoints, p1651)
				else
					local v1716 = Color3.fromRGB
					local v1717 = string.split
					local v1718 = p1651.COLOR
					v1699.Color = v1716(unpack(v1717(v1718)))
					local v1719 = v1699.Range
					local v1720 = p1651.SIZE
					local v1721 = tonumber(v1720)
					if workspace:GetAttribute("Creator") then
						v1721 = math.clamp(v1721, 0, 40)
					end
					v1699.Range = v1719 * v1721
				end
			end
			local v1722 = v_u_3
			local v1723 = v1655.PointLight
			local v1724 = TweenInfo.new
			local v1725 = 1
			local v1726
			if p1651["EASING STYLE"] then
				v1726 = Enum.EasingStyle[p1651["EASING STYLE"]]
			else
				v1726 = Enum.EasingStyle.Linear
			end
			local v1727
			if p1651["EASING DIRECTION"] then
				v1727 = Enum.EasingDirection[p1651["EASING DIRECTION"]]
			else
				v1727 = Enum.EasingDirection.In
			end
			local v1728 = v1724(v1725, v1726, v1727)
			local v1729 = {
				["Brightness"] = 0
			}
			local v1730 = Color3.fromRGB
			local v1731 = string.split
			local v1732 = p1651["ALT COLOR"]
			v1729.Color = v1730(unpack(v1731(v1732)))
			local v1733 = v1655.PointLight.Range
			local v1734 = p1651.SIZE
			local v1735 = tonumber(v1734)
			if workspace:GetAttribute("Creator") then
				v1735 = math.clamp(v1735, 0, 40)
			end
			local v1736 = p1651["ALT SIZE"] or 1
			local v1737 = v1735 * tonumber(v1736)
			if workspace:GetAttribute("Creator") then
				v1737 = math.clamp(v1737, 0, 40)
			end
			v1729.Range = v1733 * v1737
			v1722:Create(v1723, v1728, v1729):Play()
			local v1738 = v1655.Blast
			local v1739 = 8
			local v1740 = p1651.AMOUNT
			local v1741 = tonumber(v1740)
			if workspace:GetAttribute("Creator") then
				v1741 = math.clamp(v1741, 1, 20)
			end
			v1738:Emit(v1739 * v1741)
			local v1742 = v1655.Sparks
			local v1743 = 15
			local v1744 = p1651.AMOUNT
			local v1745 = tonumber(v1744)
			if workspace:GetAttribute("Creator") then
				v1745 = math.clamp(v1745, 1, 20)
			end
			v1742:Emit(v1743 * v1745)
			local v1746 = v1655.Lightning
			local v1747 = 6
			local v1748 = p1651.AMOUNT
			local v1749 = tonumber(v1748)
			if workspace:GetAttribute("Creator") then
				v1749 = math.clamp(v1749, 1, 20)
			end
			v1746:Emit(v1747 * v1749)
			local v1750 = v1655.Wind
			local v1751 = 7
			local v1752 = p1651.AMOUNT
			local v1753 = tonumber(v1752)
			if workspace:GetAttribute("Creator") then
				v1753 = math.clamp(v1753, 1, 20)
			end
			v1750:Emit(v1751 * v1753)
			table.insert(v1654, v1655)
		end
	end,
	["Wind Expand"] = function(p1754, p1755)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_31, (copy) v_u_51
		local v1756 = p1754:FindFirstChild("HumanoidRootPart")
		if v1756 then
			if p1755.RELATIVE ~= nil then
				p1754 = p1755.RELATIVE
			end
			if not p1754:IsA("BasePart") then
				if p1754:FindFirstChild(p1755["BODY PART"]) then
					p1754 = p1754[p1755["BODY PART"]]
				else
					p1754 = nil
				end
			end
			local v1757 = p1754 or v1756
			local v1758 = v_u_70(v1757, p1755)
			local v1759 = v_u_1.Parent.Megumi.Mahoraga.RitualStart.Attachment:Clone()
			v1759.Parent = v1757
			local v1760 = p1755.POSITION
			local v1761
			if v1760 then
				local v1762 = string.split
				local v1763 = unpack
				v1761 = Vector3.new(v1763(v1762(v1760)))
			else
				v1761 = Vector3.new(0, 0, 0)
			end
			local v1764 = CFrame.new(-v1761.X, v1761.Y, -v1761.Z)
			local v1765 = (v1757 and v1757.CFrame or CFrame.new()) * v1764
			local v1766 = p1755.ROTATION
			local v1767
			if v1766 then
				local v1768 = string.split
				local v1769 = unpack
				v1767 = Vector3.new(v1769(v1768(v1766)))
			else
				v1767 = Vector3.new(0, 0, 0)
			end
			local v1770 = CFrame.fromOrientation
			local v1771 = v1767.X
			local v1772 = math.rad(v1771)
			local v1773 = v1767.Y
			local v1774 = math.rad(v1773)
			local v1775 = v1767.Z
			v1759.WorldCFrame = v1765 * v1770(v1772, v1774, (math.rad(v1775))) * CFrame.fromOrientation(0, 0, 1.5707963267948966)
			local v1776 = v_u_11
			local v1777 = p1755.TIME
			local v1778 = tonumber(v1777)
			if workspace:GetAttribute("Creator") then
				v1778 = math.clamp(v1778, 0, 10)
			end
			v1776:AddItem(v1759, v1778)
			local v1779 = p1755["ALT POSITION"]
			local v1780
			if v1779 then
				local v1781 = string.split
				local v1782 = unpack
				v1780 = Vector3.new(v1782(v1781(v1779)))
			else
				v1780 = Vector3.new(0, 0, 0)
			end
			if v1780 ~= Vector3.new(0, 0, 0) then
				local v1783 = v_u_3
				local v1784 = TweenInfo.new
				local v1785 = p1755.TIME
				local v1786 = tonumber(v1785)
				if workspace:GetAttribute("Creator") then
					v1786 = math.clamp(v1786, 0, 10)
				end
				local v1787
				if p1755["EASING STYLE"] then
					v1787 = Enum.EasingStyle[p1755["EASING STYLE"]]
				else
					v1787 = Enum.EasingStyle.Linear
				end
				local v1788
				if p1755["EASING DIRECTION"] then
					v1788 = Enum.EasingDirection[p1755["EASING DIRECTION"]]
				else
					v1788 = Enum.EasingDirection.In
				end
				local v1789 = v1784(v1786, v1787, v1788)
				local v1790 = {}
				local v1791 = v_u_26(v1757, p1755, true)
				local v1792 = p1755["ALT ROTATION"] or p1755.ROTATION
				local v1793
				if v1792 then
					local v1794 = string.split
					local v1795 = unpack
					v1793 = Vector3.new(v1795(v1794(v1792)))
				else
					v1793 = Vector3.new(0, 0, 0)
				end
				local v1796 = CFrame.fromOrientation
				local v1797 = v1793.X
				local v1798 = math.rad(v1797)
				local v1799 = v1793.Y
				local v1800 = math.rad(v1799)
				local v1801 = v1793.Z
				v1790.WorldCFrame = v1791 * v1796(v1798, v1800, (math.rad(v1801)))
				v1783:Create(v1759, v1789, v1790):Play()
			end
			for _, v1802 in v1759:GetChildren() do
				local v1803 = ColorSequence.new
				local v1804 = Color3.fromRGB
				local v1805 = string.split
				local v1806 = p1755.COLOR
				v1802.Color = v1803(v1804(unpack(v1805(v1806))), v_u_31(p1755))
				local v1807 = NumberRange.new
				local v1808 = p1755.TIME
				local v1809 = tonumber(v1808)
				if workspace:GetAttribute("Creator") then
					v1809 = math.clamp(v1809, 0, 10)
				end
				v1802.Lifetime = v1807(v1809)
				local v1810 = NumberSequence.new
				local v1811 = p1755.OPACITY
				local v1812 = tonumber(v1811)
				local v1813 = p1755["ALT OPACITY"]
				v1802.Transparency = v1810(v1812, (tonumber(v1813)))
				v1802.Size = v_u_51(v1802.Size.Keypoints, p1755)
			end
			local v1814 = v1759.Ring
			local v1815 = p1755.AMOUNT
			local v1816 = tonumber(v1815)
			if workspace:GetAttribute("Creator") then
				v1816 = math.clamp(v1816, 1, 20)
			end
			v1814:Emit(v1816)
			local v1817 = v1759.Dust
			local v1818 = p1755.AMOUNT
			local v1819 = tonumber(v1818)
			if workspace:GetAttribute("Creator") then
				v1819 = math.clamp(v1819, 1, 20)
			end
			v1817:Emit(v1819)
			table.insert(v1758, v1759)
		end
	end,
	["Shine"] = function(p1820, p1821)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_31, (copy) v_u_51
		local v1822 = p1820:FindFirstChild("HumanoidRootPart")
		if v1822 then
			if p1821.RELATIVE ~= nil then
				p1820 = p1821.RELATIVE
			end
			if not p1820:IsA("BasePart") then
				if p1820:FindFirstChild(p1821["BODY PART"]) then
					p1820 = p1820[p1821["BODY PART"]]
				else
					p1820 = nil
				end
			end
			local v1823 = p1820 or v1822
			local v1824 = v_u_70(v1823, p1821)
			local v1825 = v_u_1.Parent.Megumi.Mahoraga.Cursed.Shine:Clone()
			v1825.Parent = v1823
			local v1826 = p1821.POSITION
			local v1827
			if v1826 then
				local v1828 = string.split
				local v1829 = unpack
				v1827 = Vector3.new(v1829(v1828(v1826)))
			else
				v1827 = Vector3.new(0, 0, 0)
			end
			local v1830 = CFrame.new(-v1827.X, v1827.Y, -v1827.Z)
			local v1831 = (v1823 and v1823.CFrame or CFrame.new()) * v1830
			local v1832 = p1821.ROTATION
			local v1833
			if v1832 then
				local v1834 = string.split
				local v1835 = unpack
				v1833 = Vector3.new(v1835(v1834(v1832)))
			else
				v1833 = Vector3.new(0, 0, 0)
			end
			local v1836 = CFrame.fromOrientation
			local v1837 = v1833.X
			local v1838 = math.rad(v1837)
			local v1839 = v1833.Y
			local v1840 = math.rad(v1839)
			local v1841 = v1833.Z
			v1825.WorldCFrame = v1831 * v1836(v1838, v1840, (math.rad(v1841))) * CFrame.new(0, -2, 0)
			local v1842 = v_u_11
			local v1843 = p1821.TIME
			local v1844 = tonumber(v1843)
			if workspace:GetAttribute("Creator") then
				v1844 = math.clamp(v1844, 0, 10)
			end
			v1842:AddItem(v1825, v1844)
			local v1845 = p1821["ALT POSITION"]
			local v1846
			if v1845 then
				local v1847 = string.split
				local v1848 = unpack
				v1846 = Vector3.new(v1848(v1847(v1845)))
			else
				v1846 = Vector3.new(0, 0, 0)
			end
			if v1846 ~= Vector3.new(0, 0, 0) then
				local v1849 = v_u_3
				local v1850 = TweenInfo.new
				local v1851 = p1821.TIME
				local v1852 = tonumber(v1851)
				if workspace:GetAttribute("Creator") then
					v1852 = math.clamp(v1852, 0, 10)
				end
				local v1853
				if p1821["EASING STYLE"] then
					v1853 = Enum.EasingStyle[p1821["EASING STYLE"]]
				else
					v1853 = Enum.EasingStyle.Linear
				end
				local v1854
				if p1821["EASING DIRECTION"] then
					v1854 = Enum.EasingDirection[p1821["EASING DIRECTION"]]
				else
					v1854 = Enum.EasingDirection.In
				end
				local v1855 = v1850(v1852, v1853, v1854)
				local v1856 = {}
				local v1857 = v_u_26(v1823, p1821, true)
				local v1858 = p1821["ALT ROTATION"] or p1821.ROTATION
				local v1859
				if v1858 then
					local v1860 = string.split
					local v1861 = unpack
					v1859 = Vector3.new(v1861(v1860(v1858)))
				else
					v1859 = Vector3.new(0, 0, 0)
				end
				local v1862 = CFrame.fromOrientation
				local v1863 = v1859.X
				local v1864 = math.rad(v1863)
				local v1865 = v1859.Y
				local v1866 = math.rad(v1865)
				local v1867 = v1859.Z
				v1856.WorldCFrame = v1857 * v1862(v1864, v1866, (math.rad(v1867)))
				v1849:Create(v1825, v1855, v1856):Play()
			end
			local v1868 = v1825.Shine
			local v1869 = ColorSequence.new
			local v1870 = Color3.fromRGB
			local v1871 = string.split
			local v1872 = p1821.COLOR
			v1868.Color = v1869(v1870(unpack(v1871(v1872))), v_u_31(p1821))
			local v1873 = v1825.Shine
			local v1874 = NumberRange.new
			local v1875 = p1821.TIME
			local v1876 = tonumber(v1875)
			if workspace:GetAttribute("Creator") then
				v1876 = math.clamp(v1876, 0, 10)
			end
			v1873.Lifetime = v1874(v1876)
			local v1877 = v1825.Shine
			local v1878 = NumberSequence.new
			local v1879 = p1821.OPACITY
			local v1880 = tonumber(v1879)
			local v1881 = p1821["ALT OPACITY"]
			v1877.Transparency = v1878(v1880, (tonumber(v1881)))
			v1825.Shine.Size = v_u_51(v1825.Shine.Size.Keypoints, p1821)
			local v1882 = v1825.Shine
			local v1883 = p1821.AMOUNT
			local v1884 = tonumber(v1883)
			if workspace:GetAttribute("Creator") then
				v1884 = math.clamp(v1884, 1, 20)
			end
			v1882:Emit(v1884)
			table.insert(v1824, v1825)
		end
	end,
	["Clash"] = function(p1885, p1886)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_31, (copy) v_u_51, (copy) v_u_3, (copy) v_u_26
		local v1887 = p1885:FindFirstChild("HumanoidRootPart")
		if v1887 then
			if p1886.RELATIVE ~= nil then
				p1885 = p1886.RELATIVE
			end
			if not p1885:IsA("BasePart") then
				if p1885:FindFirstChild(p1886["BODY PART"]) then
					p1885 = p1885[p1886["BODY PART"]]
				else
					p1885 = nil
				end
			end
			local v1888 = p1885 or v1887
			local v1889 = v_u_70(v1888, p1886)
			local v1890 = v_u_1.Parent.Misc.Items.Clash.Attachment:Clone()
			v1890.Parent = v1888
			local v1891 = p1886.POSITION
			local v1892
			if v1891 then
				local v1893 = string.split
				local v1894 = unpack
				v1892 = Vector3.new(v1894(v1893(v1891)))
			else
				v1892 = Vector3.new(0, 0, 0)
			end
			local v1895 = CFrame.new(-v1892.X, v1892.Y, -v1892.Z)
			local v1896 = (v1888 and v1888.CFrame or CFrame.new()) * v1895
			local v1897 = p1886.ROTATION
			local v1898
			if v1897 then
				local v1899 = string.split
				local v1900 = unpack
				v1898 = Vector3.new(v1900(v1899(v1897)))
			else
				v1898 = Vector3.new(0, 0, 0)
			end
			local v1901 = CFrame.fromOrientation
			local v1902 = v1898.X
			local v1903 = math.rad(v1902)
			local v1904 = v1898.Y
			local v1905 = math.rad(v1904)
			local v1906 = v1898.Z
			v1890.WorldCFrame = v1896 * v1901(v1903, v1905, (math.rad(v1906)))
			v1890.PointLight.Enabled = false
			local v1907 = v_u_11
			local v1908 = p1886.TIME
			local v1909 = tonumber(v1908)
			if workspace:GetAttribute("Creator") then
				v1909 = math.clamp(v1909, 0, 10)
			end
			v1907:AddItem(v1890, v1909)
			for _, v1910 in pairs(v1890:GetChildren()) do
				if v1910:IsA("ParticleEmitter") then
					local v1911 = ColorSequence.new
					local v1912 = Color3.fromRGB
					local v1913 = string.split
					local v1914 = p1886.COLOR
					v1910.Color = v1911(v1912(unpack(v1913(v1914))), v_u_31(p1886))
					local v1915 = NumberRange.new
					local v1916 = p1886.TIME
					local v1917 = tonumber(v1916)
					if workspace:GetAttribute("Creator") then
						v1917 = math.clamp(v1917, 0, 10)
					end
					v1910.Lifetime = v1915(v1917)
					local v1918 = NumberSequence.new
					local v1919 = p1886.OPACITY
					local v1920 = tonumber(v1919)
					local v1921 = p1886["ALT OPACITY"]
					v1910.Transparency = v1918(v1920, (tonumber(v1921)))
					v1910.Size = v_u_51(v1910.Size.Keypoints, p1886)
				end
			end
			local v1922 = p1886["ALT POSITION"]
			local v1923
			if v1922 then
				local v1924 = string.split
				local v1925 = unpack
				v1923 = Vector3.new(v1925(v1924(v1922)))
			else
				v1923 = Vector3.new(0, 0, 0)
			end
			if v1923 ~= Vector3.new(0, 0, 0) then
				local v1926 = v_u_3
				local v1927 = TweenInfo.new
				local v1928 = p1886.TIME
				local v1929 = tonumber(v1928)
				if workspace:GetAttribute("Creator") then
					v1929 = math.clamp(v1929, 0, 10)
				end
				local v1930
				if p1886["EASING STYLE"] then
					v1930 = Enum.EasingStyle[p1886["EASING STYLE"]]
				else
					v1930 = Enum.EasingStyle.Linear
				end
				local v1931
				if p1886["EASING DIRECTION"] then
					v1931 = Enum.EasingDirection[p1886["EASING DIRECTION"]]
				else
					v1931 = Enum.EasingDirection.In
				end
				local v1932 = v1927(v1929, v1930, v1931)
				local v1933 = {}
				local v1934 = v_u_26(v1888, p1886, true)
				local v1935 = p1886["ALT ROTATION"] or p1886.ROTATION
				local v1936
				if v1935 then
					local v1937 = string.split
					local v1938 = unpack
					v1936 = Vector3.new(v1938(v1937(v1935)))
				else
					v1936 = Vector3.new(0, 0, 0)
				end
				local v1939 = CFrame.fromOrientation
				local v1940 = v1936.X
				local v1941 = math.rad(v1940)
				local v1942 = v1936.Y
				local v1943 = math.rad(v1942)
				local v1944 = v1936.Z
				v1933.WorldCFrame = v1934 * v1939(v1941, v1943, (math.rad(v1944)))
				v1926:Create(v1890, v1932, v1933):Play()
			end
			for _, v1945 in v1890:GetChildren() do
				if v1945:IsA("PointLight") then
					v_u_3:Create(v1945, TweenInfo.new(v1945:GetAttribute("Duration")), {
						["Brightness"] = 0
					}):Play()
				else
					local v1946 = v1945:GetAttribute("EmitCount")
					local v1947 = p1886.AMOUNT
					local v1948 = tonumber(v1947)
					if workspace:GetAttribute("Creator") then
						v1948 = math.clamp(v1948, 1, 20)
					end
					v1945:Emit(v1946 * v1948)
				end
			end
			table.insert(v1889, v1890)
		end
	end,
	["Weak Lightning"] = function(p1949, p1950)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_31, (copy) v_u_51, (copy) v_u_3, (copy) v_u_26
		local v1951 = p1949:FindFirstChild("HumanoidRootPart")
		if v1951 then
			if p1950.RELATIVE ~= nil then
				p1949 = p1950.RELATIVE
			end
			if not p1949:IsA("BasePart") then
				if p1949:FindFirstChild(p1950["BODY PART"]) then
					p1949 = p1949[p1950["BODY PART"]]
				else
					p1949 = nil
				end
			end
			local v1952 = p1949 or v1951
			local v1953 = v_u_70(v1952, p1950)
			local v1954 = v_u_1.Parent.Megumi.NueShock:Clone()
			v1954.Parent = workspace.Effects
			local v1955 = v_u_11
			local v1956 = p1950.TIME
			local v1957 = tonumber(v1956)
			if workspace:GetAttribute("Creator") then
				v1957 = math.clamp(v1957, 0, 10)
			end
			v1955:AddItem(v1954, v1957)
			local v1958 = p1950.POSITION
			local v1959
			if v1958 then
				local v1960 = string.split
				local v1961 = unpack
				v1959 = Vector3.new(v1961(v1960(v1958)))
			else
				v1959 = Vector3.new(0, 0, 0)
			end
			local v1962 = CFrame.new(-v1959.X, v1959.Y, -v1959.Z)
			local v1963 = (v1952 and v1952.CFrame or CFrame.new()) * v1962
			local v1964 = p1950.ROTATION
			local v1965
			if v1964 then
				local v1966 = string.split
				local v1967 = unpack
				v1965 = Vector3.new(v1967(v1966(v1964)))
			else
				v1965 = Vector3.new(0, 0, 0)
			end
			local v1968 = CFrame.fromOrientation
			local v1969 = v1965.X
			local v1970 = math.rad(v1969)
			local v1971 = v1965.Y
			local v1972 = math.rad(v1971)
			local v1973 = v1965.Z
			v1954.CFrame = v1963 * v1968(v1970, v1972, (math.rad(v1973)))
			local v1974 = v1954.Hit
			local v1975 = ColorSequence.new
			local v1976 = Color3.fromRGB
			local v1977 = string.split
			local v1978 = p1950.COLOR
			v1974.Color = v1975(v1976(unpack(v1977(v1978))), v_u_31(p1950))
			local v1979 = v1954.Hit
			local v1980 = NumberRange.new
			local v1981 = p1950.TIME
			local v1982 = tonumber(v1981)
			if workspace:GetAttribute("Creator") then
				v1982 = math.clamp(v1982, 0, 10)
			end
			v1979.Lifetime = v1980(v1982)
			local v1983 = v1954.Hit
			local v1984 = NumberSequence.new
			local v1985 = p1950.OPACITY
			local v1986 = tonumber(v1985)
			local v1987 = p1950["ALT OPACITY"]
			v1983.Transparency = v1984(v1986, (tonumber(v1987)))
			v1954.Hit.Size = v_u_51(v1954.Hit.Size.Keypoints, p1950)
			local v1988 = v1954.Electric
			local v1989 = ColorSequence.new
			local v1990 = Color3.fromRGB
			local v1991 = string.split
			local v1992 = p1950.COLOR
			v1988.Color = v1989(v1990(unpack(v1991(v1992))), v_u_31(p1950))
			local v1993 = v1954.Electric
			local v1994 = NumberRange.new
			local v1995 = p1950.TIME
			local v1996 = tonumber(v1995)
			if workspace:GetAttribute("Creator") then
				v1996 = math.clamp(v1996, 0, 10)
			end
			v1993.Lifetime = v1994(v1996)
			local v1997 = v1954.Electric
			local v1998 = NumberSequence.new
			local v1999 = p1950.OPACITY
			local v2000 = tonumber(v1999)
			local v2001 = p1950["ALT OPACITY"]
			v1997.Transparency = v1998(v2000, (tonumber(v2001)))
			v1954.Electric.Size = v_u_51(v1954.Electric.Size.Keypoints, p1950)
			local v2002 = v1954.Electric
			local v2003 = 20
			local v2004 = p1950.AMOUNT
			local v2005 = tonumber(v2004)
			if workspace:GetAttribute("Creator") then
				v2005 = math.clamp(v2005, 1, 20)
			end
			v2002.Rate = v2003 * v2005
			local v2006 = p1950["ALT POSITION"]
			local v2007
			if v2006 then
				local v2008 = string.split
				local v2009 = unpack
				v2007 = Vector3.new(v2009(v2008(v2006)))
			else
				v2007 = Vector3.new(0, 0, 0)
			end
			if v2007 == Vector3.new(0, 0, 0) then
				v1954.Anchored = false
				local v2010 = Instance.new("WeldConstraint", v1954)
				v2010.Part0 = v1952
				v2010.Part1 = v1954
			else
				local v2011 = v_u_3
				local v2012 = TweenInfo.new
				local v2013 = p1950.TIME
				local v2014 = tonumber(v2013)
				if workspace:GetAttribute("Creator") then
					v2014 = math.clamp(v2014, 0, 10)
				end
				local v2015
				if p1950["EASING STYLE"] then
					v2015 = Enum.EasingStyle[p1950["EASING STYLE"]]
				else
					v2015 = Enum.EasingStyle.Linear
				end
				local v2016
				if p1950["EASING DIRECTION"] then
					v2016 = Enum.EasingDirection[p1950["EASING DIRECTION"]]
				else
					v2016 = Enum.EasingDirection.In
				end
				local v2017 = v2012(v2014, v2015, v2016)
				local v2018 = {}
				local v2019 = v_u_26(v1952, p1950, true)
				local v2020 = p1950["ALT ROTATION"] or p1950.ROTATION
				local v2021
				if v2020 then
					local v2022 = string.split
					local v2023 = unpack
					v2021 = Vector3.new(v2023(v2022(v2020)))
				else
					v2021 = Vector3.new(0, 0, 0)
				end
				local v2024 = CFrame.fromOrientation
				local v2025 = v2021.X
				local v2026 = math.rad(v2025)
				local v2027 = v2021.Y
				local v2028 = math.rad(v2027)
				local v2029 = v2021.Z
				v2018.CFrame = v2019 * v2024(v2026, v2028, (math.rad(v2029)))
				v2011:Create(v1954, v2017, v2018):Play()
			end
			local v2030 = v_u_3
			local v2031 = v1954.Electric
			local v2032 = TweenInfo.new
			local v2033 = p1950.TIME
			local v2034 = tonumber(v2033)
			if workspace:GetAttribute("Creator") then
				v2034 = math.clamp(v2034, 0, 10)
			end
			local v2035
			if p1950["EASING STYLE"] then
				v2035 = Enum.EasingStyle[p1950["EASING STYLE"]]
			else
				v2035 = Enum.EasingStyle.Linear
			end
			local v2036
			if p1950["EASING DIRECTION"] then
				v2036 = Enum.EasingDirection[p1950["EASING DIRECTION"]]
			else
				v2036 = Enum.EasingDirection.In
			end
			v2030:Create(v2031, v2032(v2034, v2035, v2036), {
				["Rate"] = 0
			}):Play()
			table.insert(v1953, v1954)
		end
	end,
	["Cleave"] = function(p2037, p2038)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_31, (copy) v_u_51, (copy) v_u_3, (copy) v_u_26
		local v2039 = p2037:FindFirstChild("HumanoidRootPart")
		if v2039 then
			if p2038.RELATIVE ~= nil then
				p2037 = p2038.RELATIVE
			end
			if not p2037:IsA("BasePart") then
				if p2037:FindFirstChild(p2038["BODY PART"]) then
					p2037 = p2037[p2038["BODY PART"]]
				else
					p2037 = nil
				end
			end
			local v2040 = p2037 or v2039
			local v2041 = v_u_70(v2040, p2038)
			local v2042 = v_u_1.Parent.Itadori.MalevolantShrine.Hit:Clone()
			v2042.Anchored = true
			local v2043 = p2038.POSITION
			local v2044
			if v2043 then
				local v2045 = string.split
				local v2046 = unpack
				v2044 = Vector3.new(v2046(v2045(v2043)))
			else
				v2044 = Vector3.new(0, 0, 0)
			end
			local v2047 = CFrame.new(-v2044.X, v2044.Y, -v2044.Z)
			local v2048 = (v2040 and v2040.CFrame or CFrame.new()) * v2047
			local v2049 = p2038.ROTATION
			local v2050
			if v2049 then
				local v2051 = string.split
				local v2052 = unpack
				v2050 = Vector3.new(v2052(v2051(v2049)))
			else
				v2050 = Vector3.new(0, 0, 0)
			end
			local v2053 = CFrame.fromOrientation
			local v2054 = v2050.X
			local v2055 = math.rad(v2054)
			local v2056 = v2050.Y
			local v2057 = math.rad(v2056)
			local v2058 = v2050.Z
			v2042.CFrame = v2048 * v2053(v2055, v2057, (math.rad(v2058)))
			v2042.Parent = workspace.Effects
			local v2059 = v_u_11
			local v2060 = p2038.TIME
			local v2061 = tonumber(v2060)
			if workspace:GetAttribute("Creator") then
				v2061 = math.clamp(v2061, 0, 10)
			end
			v2059:AddItem(v2042, v2061)
			v2042.Slash1.Enabled = false
			v2042.Slash2.Enabled = false
			local v2062 = v2042.Slash1
			local v2063 = ColorSequence.new
			local v2064 = Color3.fromRGB
			local v2065 = string.split
			local v2066 = p2038.COLOR
			v2062.Color = v2063(v2064(unpack(v2065(v2066))), v_u_31(p2038))
			local v2067 = v2042.Slash1
			local v2068 = NumberRange.new
			local v2069 = p2038.TIME
			local v2070 = tonumber(v2069)
			if workspace:GetAttribute("Creator") then
				v2070 = math.clamp(v2070, 0, 10)
			end
			v2067.Lifetime = v2068(v2070)
			local v2071 = v2042.Slash1
			local v2072 = NumberSequence.new
			local v2073 = p2038.OPACITY
			local v2074 = tonumber(v2073)
			local v2075 = p2038["ALT OPACITY"]
			v2071.Transparency = v2072(v2074, (tonumber(v2075)))
			v2042.Slash1.Size = v_u_51(v2042.Slash1.Size.Keypoints, p2038)
			local v2076 = v2042.Slash2
			local v2077 = ColorSequence.new
			local v2078 = Color3.fromRGB
			local v2079 = string.split
			local v2080 = p2038.COLOR
			v2076.Color = v2077(v2078(unpack(v2079(v2080))), v_u_31(p2038))
			local v2081 = v2042.Slash2
			local v2082 = NumberRange.new
			local v2083 = p2038.TIME
			local v2084 = tonumber(v2083)
			if workspace:GetAttribute("Creator") then
				v2084 = math.clamp(v2084, 0, 10)
			end
			v2081.Lifetime = v2082(v2084)
			local v2085 = v2042.Slash2
			local v2086 = NumberSequence.new
			local v2087 = p2038.OPACITY
			local v2088 = tonumber(v2087)
			local v2089 = p2038["ALT OPACITY"]
			v2085.Transparency = v2086(v2088, (tonumber(v2089)))
			v2042.Slash2.Size = v_u_51(v2042.Slash2.Size.Keypoints, p2038)
			local v2090 = p2038["ALT POSITION"]
			local v2091
			if v2090 then
				local v2092 = string.split
				local v2093 = unpack
				v2091 = Vector3.new(v2093(v2092(v2090)))
			else
				v2091 = Vector3.new(0, 0, 0)
			end
			if v2091 ~= Vector3.new(0, 0, 0) then
				v2042.Slash1.LockedToPart = true
				v2042.Slash2.LockedToPart = true
				local v2094 = v_u_3
				local v2095 = TweenInfo.new
				local v2096 = p2038.TIME
				local v2097 = tonumber(v2096)
				if workspace:GetAttribute("Creator") then
					v2097 = math.clamp(v2097, 0, 10)
				end
				local v2098
				if p2038["EASING STYLE"] then
					v2098 = Enum.EasingStyle[p2038["EASING STYLE"]]
				else
					v2098 = Enum.EasingStyle.Linear
				end
				local v2099
				if p2038["EASING DIRECTION"] then
					v2099 = Enum.EasingDirection[p2038["EASING DIRECTION"]]
				else
					v2099 = Enum.EasingDirection.In
				end
				local v2100 = v2095(v2097, v2098, v2099)
				local v2101 = {}
				local v2102 = v_u_26(v2040, p2038, true)
				local v2103 = p2038["ALT ROTATION"] or p2038.ROTATION
				local v2104
				if v2103 then
					local v2105 = string.split
					local v2106 = unpack
					v2104 = Vector3.new(v2106(v2105(v2103)))
				else
					v2104 = Vector3.new(0, 0, 0)
				end
				local v2107 = CFrame.fromOrientation
				local v2108 = v2104.X
				local v2109 = math.rad(v2108)
				local v2110 = v2104.Y
				local v2111 = math.rad(v2110)
				local v2112 = v2104.Z
				v2101.CFrame = v2102 * v2107(v2109, v2111, (math.rad(v2112)))
				v2094:Create(v2042, v2100, v2101):Play()
			end
			local v2113 = v2042.Slash1
			local v2114 = p2038.AMOUNT
			local v2115 = tonumber(v2114)
			if workspace:GetAttribute("Creator") then
				v2115 = math.clamp(v2115, 1, 20)
			end
			v2113:Emit(v2115)
			local v2116 = v2042.Slash2
			local v2117 = p2038.AMOUNT
			local v2118 = tonumber(v2117)
			if workspace:GetAttribute("Creator") then
				v2118 = math.clamp(v2118, 1, 20)
			end
			v2116:Emit(v2118)
			table.insert(v2041, v2042)
		end
	end,
	["Dismantle"] = function(p2119, p_u_2120)
		-- upvalues: (copy) v_u_70, (copy) v_u_26, (copy) v_u_1, (copy) v_u_31, (copy) v_u_3
		local v2121 = p2119:FindFirstChild("HumanoidRootPart")
		if v2121 then
			if p_u_2120.RELATIVE ~= nil then
				p2119 = p_u_2120.RELATIVE
			end
			if not p2119:IsA("BasePart") then
				if p2119:FindFirstChild(p_u_2120["BODY PART"]) then
					p2119 = p2119[p_u_2120["BODY PART"]]
				else
					p2119 = nil
				end
			end
			local v2122 = p2119 or v2121
			local v2123 = v_u_70(v2122, p_u_2120)
			local v2124 = CFrame.new
			local v2125 = p_u_2120.POSITION
			local v2126
			if v2125 then
				local v2127 = string.split
				local v2128 = unpack
				v2126 = Vector3.new(v2128(v2127(v2125)))
			else
				v2126 = Vector3.new(0, 0, 0)
			end
			local v2129 = CFrame.new(-v2126.X, v2126.Y, -v2126.Z)
			local v2130 = (v2122 and v2122.CFrame or CFrame.new()) * v2129
			local v2131 = p_u_2120.ROTATION
			local v2132
			if v2131 then
				local v2133 = string.split
				local v2134 = unpack
				v2132 = Vector3.new(v2134(v2133(v2131)))
			else
				v2132 = Vector3.new(0, 0, 0)
			end
			local v2135 = CFrame.fromOrientation
			local v2136 = v2132.X
			local v2137 = math.rad(v2136)
			local v2138 = v2132.Y
			local v2139 = math.rad(v2138)
			local v2140 = v2132.Z
			local v2141 = (v2130 * v2135(v2137, v2139, (math.rad(v2140)))).Position
			local v2142 = v_u_26(v2122, p_u_2120, true)
			local v2143 = p_u_2120["ALT ROTATION"] or p_u_2120.ROTATION
			local v2144
			if v2143 then
				local v2145 = string.split
				local v2146 = unpack
				v2144 = Vector3.new(v2146(v2145(v2143)))
			else
				v2144 = Vector3.new(0, 0, 0)
			end
			local v2147 = CFrame.fromOrientation
			local v2148 = v2144.X
			local v2149 = math.rad(v2148)
			local v2150 = v2144.Y
			local v2151 = math.rad(v2150)
			local v2152 = v2144.Z
			local v2153 = v2124(v2141, (v2142 * v2147(v2149, v2151, (math.rad(v2152)))).Position)
			local v2154 = p_u_2120.ROTATION
			local v2155
			if v2154 then
				local v2156 = string.split
				local v2157 = unpack
				v2155 = Vector3.new(v2157(v2156(v2154)))
			else
				v2155 = Vector3.new(0, 0, 0)
			end
			local v2158 = CFrame.fromOrientation
			local v2159 = v2155.X
			local v2160 = math.rad(v2159)
			local v2161 = v2155.Y
			local v2162 = math.rad(v2161)
			local v2163 = v2155.Z
			local v_u_2164 = v2153 * v2158(v2160, v2162, (math.rad(v2163)))
			local v2165 = v_u_26(v2122, p_u_2120, true)
			local v2166 = p_u_2120["ALT ROTATION"] or p_u_2120.ROTATION
			local v2167
			if v2166 then
				local v2168 = string.split
				local v2169 = unpack
				v2167 = Vector3.new(v2169(v2168(v2166)))
			else
				v2167 = Vector3.new(0, 0, 0)
			end
			local v2170 = CFrame.fromOrientation
			local v2171 = v2167.X
			local v2172 = math.rad(v2171)
			local v2173 = v2167.Y
			local v2174 = math.rad(v2173)
			local v2175 = v2167.Z
			local v_u_2176 = v2165 * v2170(v2172, v2174, (math.rad(v2175)))
			local v_u_2177 = v_u_1.Parent.Itadori.Dismantle.DismantleFly:Clone()
			v_u_2177.CFrame = v_u_2164
			v_u_2177.Parent = workspace.Effects
			local v2178 = v_u_2177.Size
			local v2179 = p_u_2120.SIZE
			local v2180 = tonumber(v2179)
			if workspace:GetAttribute("Creator") then
				v2180 = math.clamp(v2180, 0, 40)
			end
			v_u_2177.Size = v2178 * v2180
			local v2181 = v_u_2177.A1
			local v2182 = CFrame.new
			local v2183 = 7.5
			local v2184 = p_u_2120.SIZE
			local v2185 = tonumber(v2184)
			if workspace:GetAttribute("Creator") then
				v2185 = math.clamp(v2185, 0, 40)
			end
			v2181.CFrame = v2182(v2183 * v2185, 0, 1)
			local v2186 = v_u_2177.A2
			local v2187 = CFrame.new
			local v2188 = -7.5
			local v2189 = p_u_2120.SIZE
			local v2190 = tonumber(v2189)
			if workspace:GetAttribute("Creator") then
				v2190 = math.clamp(v2190, 0, 40)
			end
			v2186.CFrame = v2187(v2188 * v2190, 0, 1)
			local v_u_2191 = Instance.new("Highlight", v_u_2177)
			v_u_2191.DepthMode = Enum.HighlightDepthMode.Occluded
			v_u_2191.FillTransparency = 0
			local v2192 = Color3.fromRGB
			local v2193 = string.split
			local v2194 = p_u_2120.COLOR
			v_u_2191.FillColor = v2192(unpack(v2193(v2194)))
			local v2195 = Color3.fromRGB
			local v2196 = string.split
			local v2197 = p_u_2120["ALT COLOR"]
			v_u_2191.OutlineColor = v2195(unpack(v2196(v2197)))
			local v2198 = v_u_2177.Trail1
			local v2199 = ColorSequence.new
			local v2200 = Color3.fromRGB
			local v2201 = string.split
			local v2202 = p_u_2120["ALT COLOR"]
			v2198.Color = v2199(v2200(unpack(v2201(v2202))), v_u_31(p_u_2120))
			local v2203 = v_u_2177.Trail2
			local v2204 = ColorSequence.new
			local v2205 = Color3.fromRGB
			local v2206 = string.split
			local v2207 = p_u_2120["ALT COLOR"]
			v2203.Color = v2204(v2205(unpack(v2206(v2207))), v_u_31(p_u_2120))
			local v2208 = Color3.fromRGB
			local v2209 = string.split
			local v2210 = p_u_2120["ALT COLOR"]
			v_u_2177.Color = v2208(unpack(v2209(v2210)))
			task.delay(0, function()
				-- upvalues: (ref) v_u_3, (copy) v_u_2177, (copy) p_u_2120, (copy) v_u_2164, (copy) v_u_2176, (copy) v_u_2191
				local v2211 = v_u_3
				local v2212 = v_u_2177
				local v2213 = TweenInfo.new
				local v2214 = p_u_2120.TIME
				local v2215 = tonumber(v2214)
				if workspace:GetAttribute("Creator") then
					v2215 = math.clamp(v2215, 0, 10)
				end
				local v2216 = p_u_2120
				local v2217
				if v2216["EASING STYLE"] then
					v2217 = Enum.EasingStyle[v2216["EASING STYLE"]]
				else
					v2217 = Enum.EasingStyle.Linear
				end
				local v2218 = p_u_2120
				local v2219
				if v2218["EASING DIRECTION"] then
					v2219 = Enum.EasingDirection[v2218["EASING DIRECTION"]]
				else
					v2219 = Enum.EasingDirection.In
				end
				local v2220 = v2213(v2215, v2217, v2219)
				local v2221 = {}
				local v2222 = Vector3.new(15, 0, 0)
				local v2223 = p_u_2120
				local v2224 = v2223.SIZE
				local v2225 = tonumber(v2224)
				if workspace:GetAttribute("Creator") then
					v2225 = math.clamp(v2225, 0, 40)
				end
				local v2226 = v2223["ALT SIZE"] or 1
				local v2227 = v2225 * tonumber(v2226)
				if workspace:GetAttribute("Creator") then
					v2227 = math.clamp(v2227, 0, 40)
				end
				v2221.Size = v2222 * v2227
				v2221.CFrame = v_u_2164 + (v_u_2176.Position - v_u_2164.Position)
				v2211:Create(v2212, v2220, v2221):Play()
				local v2228 = v_u_3
				local v2229 = v_u_2177
				local v2230 = TweenInfo.new
				local v2231 = p_u_2120.TIME
				local v2232 = tonumber(v2231)
				if workspace:GetAttribute("Creator") then
					v2232 = math.clamp(v2232, 0, 10)
				end
				local v2233 = p_u_2120
				local v2234
				if v2233["EASING STYLE"] then
					v2234 = Enum.EasingStyle[v2233["EASING STYLE"]]
				else
					v2234 = Enum.EasingStyle.Linear
				end
				local v2235 = p_u_2120
				local v2236
				if v2235["EASING DIRECTION"] then
					v2236 = Enum.EasingDirection[v2235["EASING DIRECTION"]]
				else
					v2236 = Enum.EasingDirection.In
				end
				local v2237 = v2230(v2232, v2234, v2236)
				local v2238 = {}
				local v2239 = p_u_2120["ALT OPACITY"]
				v2238.Transparency = tonumber(v2239)
				v2228:Create(v2229, v2237, v2238):Play()
				local v2240 = v_u_3
				local v2241 = v_u_2177.A1
				local v2242 = TweenInfo.new
				local v2243 = p_u_2120.TIME
				local v2244 = tonumber(v2243)
				if workspace:GetAttribute("Creator") then
					v2244 = math.clamp(v2244, 0, 10)
				end
				local v2245 = p_u_2120
				local v2246
				if v2245["EASING STYLE"] then
					v2246 = Enum.EasingStyle[v2245["EASING STYLE"]]
				else
					v2246 = Enum.EasingStyle.Linear
				end
				local v2247 = p_u_2120
				local v2248
				if v2247["EASING DIRECTION"] then
					v2248 = Enum.EasingDirection[v2247["EASING DIRECTION"]]
				else
					v2248 = Enum.EasingDirection.In
				end
				local v2249 = v2242(v2244, v2246, v2248)
				local v2250 = {}
				local v2251 = CFrame.new
				local v2252 = 7.5
				local v2253 = p_u_2120
				local v2254 = v2253.SIZE
				local v2255 = tonumber(v2254)
				if workspace:GetAttribute("Creator") then
					v2255 = math.clamp(v2255, 0, 40)
				end
				local v2256 = v2253["ALT SIZE"] or 1
				local v2257 = v2255 * tonumber(v2256)
				if workspace:GetAttribute("Creator") then
					v2257 = math.clamp(v2257, 0, 40)
				end
				v2250.CFrame = v2251(v2252 * v2257, 0, 1)
				v2240:Create(v2241, v2249, v2250):Play()
				local v2258 = v_u_3
				local v2259 = v_u_2177.A2
				local v2260 = TweenInfo.new
				local v2261 = p_u_2120.TIME
				local v2262 = tonumber(v2261)
				if workspace:GetAttribute("Creator") then
					v2262 = math.clamp(v2262, 0, 10)
				end
				local v2263 = p_u_2120
				local v2264
				if v2263["EASING STYLE"] then
					v2264 = Enum.EasingStyle[v2263["EASING STYLE"]]
				else
					v2264 = Enum.EasingStyle.Linear
				end
				local v2265 = p_u_2120
				local v2266
				if v2265["EASING DIRECTION"] then
					v2266 = Enum.EasingDirection[v2265["EASING DIRECTION"]]
				else
					v2266 = Enum.EasingDirection.In
				end
				local v2267 = v2260(v2262, v2264, v2266)
				local v2268 = {}
				local v2269 = CFrame.new
				local v2270 = -7.5
				local v2271 = p_u_2120
				local v2272 = v2271.SIZE
				local v2273 = tonumber(v2272)
				if workspace:GetAttribute("Creator") then
					v2273 = math.clamp(v2273, 0, 40)
				end
				local v2274 = v2271["ALT SIZE"] or 1
				local v2275 = v2273 * tonumber(v2274)
				if workspace:GetAttribute("Creator") then
					v2275 = math.clamp(v2275, 0, 40)
				end
				v2268.CFrame = v2269(v2270 * v2275, 0, 1)
				v2258:Create(v2259, v2267, v2268):Play()
				local v2276 = task.wait
				local v2277 = p_u_2120.TIME
				local v2278 = tonumber(v2277)
				if workspace:GetAttribute("Creator") then
					v2278 = math.clamp(v2278, 0, 10)
				end
				v2276(v2278)
				v_u_2191:Destroy()
				v_u_2177.Transparency = 1
				task.wait(0.05)
				v_u_2177:Destroy()
			end)
			table.insert(v2123, v_u_2177)
		end
	end,
	["Rough Energy"] = function(p2279, p2280)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51, (ref) v_u_11, (copy) v_u_3
		local v2281 = p2279:FindFirstChild("HumanoidRootPart")
		if v2281 then
			if p2280.RELATIVE ~= nil then
				p2279 = p2280.RELATIVE
			end
			if not p2279:IsA("BasePart") then
				if p2279:FindFirstChild(p2280["BODY PART"]) then
					p2279 = p2279[p2280["BODY PART"]]
				else
					p2279 = nil
				end
			end
			local v2282 = p2279 or v2281
			local v2283 = v_u_70(v2282, p2280)
			local v_u_2284 = v_u_1.Parent.Hakari.RoughEnergy:Clone()
			table.insert(v2283, v_u_2284)
			v_u_2284.Weld.Part0 = v2282
			local v2285 = v_u_2284.Weld
			local v2286 = CFrame.new
			local v2287 = p2280.POSITION
			local v2288
			if v2287 then
				local v2289 = string.split
				local v2290 = unpack
				v2288 = Vector3.new(v2290(v2289(v2287)))
			else
				v2288 = Vector3.new(0, 0, 0)
			end
			v2285.C0 = v2286(v2288)
			local v2291 = v_u_2284.Core.Aura
			local v2292 = ColorSequence.new
			local v2293 = Color3.fromRGB
			local v2294 = string.split
			local v2295 = p2280.COLOR
			v2291.Color = v2292(v2293(unpack(v2294(v2295))), v_u_31(p2280))
			local v2296 = v_u_2284.Core.Aura
			local v2297 = NumberSequence.new
			local v2298 = p2280.OPACITY
			local v2299 = tonumber(v2298)
			local v2300 = p2280["ALT OPACITY"]
			v2296.Transparency = v2297(v2299, (tonumber(v2300)))
			v_u_2284.Core.Aura.Size = v_u_51(v_u_2284.Core.Aura.Size.Keypoints, p2280)
			local v2301 = v_u_2284.Core.Sparks
			local v2302 = ColorSequence.new
			local v2303 = Color3.fromRGB
			local v2304 = string.split
			local v2305 = p2280.COLOR
			v2301.Color = v2302(v2303(unpack(v2304(v2305))), v_u_31(p2280))
			local v2306 = v_u_2284.Core.Sparks
			local v2307 = NumberSequence.new
			local v2308 = p2280.OPACITY
			local v2309 = tonumber(v2308)
			local v2310 = p2280["ALT OPACITY"]
			v2306.Transparency = v2307(v2309, (tonumber(v2310)))
			v_u_2284.Core.Sparks.Size = v_u_51(v_u_2284.Core.Sparks.Size.Keypoints, p2280)
			local v2311 = v_u_2284.Trail
			local v2312 = ColorSequence.new
			local v2313 = Color3.fromRGB
			local v2314 = string.split
			local v2315 = p2280.COLOR
			v2311.Color = v2312(v2313(unpack(v2314(v2315))), v_u_31(p2280))
			local v2316 = v_u_2284.Trail
			local v2317 = NumberSequence.new
			local v2318 = p2280.OPACITY
			local v2319 = tonumber(v2318)
			local v2320 = p2280["ALT OPACITY"]
			v2316.Transparency = v2317(v2319, (tonumber(v2320)))
			v_u_2284.Trail.WidthScale = v_u_51(v_u_2284.Trail.WidthScale.Keypoints, p2280)
			local v2321 = v_u_2284.PointLight
			local v2322 = Color3.fromRGB
			local v2323 = string.split
			local v2324 = p2280.COLOR
			v2321.Color = v2322(unpack(v2323(v2324)))
			local v2325 = v_u_2284.PointLight
			local v2326 = v2325.Range
			local v2327 = p2280.SIZE
			local v2328 = tonumber(v2327)
			if workspace:GetAttribute("Creator") then
				v2328 = math.clamp(v2328, 0, 40)
			end
			v2325.Range = v2326 * v2328
			v_u_2284.Parent = workspace.Effects
			local v2329 = v_u_11
			local v2330 = p2280.TIME
			local v2331 = tonumber(v2330)
			if workspace:GetAttribute("Creator") then
				v2331 = math.clamp(v2331, 0, 10)
			end
			v2329:AddItem(v_u_2284, v2331 + 2)
			local v2332 = v_u_3
			local v2333 = v_u_2284.PointLight
			local v2334 = TweenInfo.new
			local v2335 = p2280.TIME
			local v2336 = tonumber(v2335)
			if workspace:GetAttribute("Creator") then
				v2336 = math.clamp(v2336, 0, 10)
			end
			v2332:Create(v2333, v2334(v2336 * 0.2), {
				["Brightness"] = 5
			}):Play()
			local v2337 = task.wait
			local v2338 = p2280.TIME
			local v2339 = tonumber(v2338)
			if workspace:GetAttribute("Creator") then
				v2339 = math.clamp(v2339, 0, 10)
			end
			v2337(v2339 * 0.8)
			v_u_2284.Core.Aura.Enabled = false
			v_u_2284.Core.Sparks.Enabled = false
			local v2340 = task.delay
			local v2341 = p2280.TIME
			local v2342 = tonumber(v2341)
			if workspace:GetAttribute("Creator") then
				v2342 = math.clamp(v2342, 0, 10)
			end
			v2340(v2342 * 0.05, function()
				-- upvalues: (copy) v_u_2284
				v_u_2284.Trail.Enabled = false
			end)
			local v2343 = v_u_3
			local v2344 = v_u_2284.PointLight
			local v2345 = TweenInfo.new
			local v2346 = p2280.TIME
			local v2347 = tonumber(v2346)
			if workspace:GetAttribute("Creator") then
				v2347 = math.clamp(v2347, 0, 10)
			end
			v2343:Create(v2344, v2345(v2347 * 0.2), {
				["Brightness"] = 0
			}):Play()
		end
	end,
	["Cursed Energy"] = function(p2348, p2349)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (copy) v_u_31, (copy) v_u_51, (ref) v_u_11, (copy) v_u_3
		local v2350 = p2348:FindFirstChild("HumanoidRootPart")
		if v2350 then
			if p2349.RELATIVE ~= nil then
				p2348 = p2349.RELATIVE
			end
			if not p2348:IsA("BasePart") then
				if p2348:FindFirstChild(p2349["BODY PART"]) then
					p2348 = p2348[p2349["BODY PART"]]
				else
					p2348 = nil
				end
			end
			local v2351 = p2348 or v2350
			local v2352 = v_u_70(v2351, p2349)
			local v_u_2353 = v_u_1.Parent.Itadori.DivergentFist.DivergentFist:Clone()
			table.insert(v2352, v_u_2353)
			v_u_2353.Weld.Part0 = v2351
			local v2354 = v_u_2353.Weld
			local v2355 = CFrame.new
			local v2356 = p2349.POSITION
			local v2357
			if v2356 then
				local v2358 = string.split
				local v2359 = unpack
				v2357 = Vector3.new(v2359(v2358(v2356)))
			else
				v2357 = Vector3.new(0, 0, 0)
			end
			v2354.C0 = v2355(v2357)
			local v2360 = v_u_2353.Core.Aura
			local v2361 = ColorSequence.new
			local v2362 = Color3.fromRGB
			local v2363 = string.split
			local v2364 = p2349.COLOR
			v2360.Color = v2361(v2362(unpack(v2363(v2364))), v_u_31(p2349))
			local v2365 = v_u_2353.Core.Aura
			local v2366 = NumberSequence.new
			local v2367 = p2349.OPACITY
			local v2368 = tonumber(v2367)
			local v2369 = p2349["ALT OPACITY"]
			v2365.Transparency = v2366(v2368, (tonumber(v2369)))
			v_u_2353.Core.Aura.Size = v_u_51(v_u_2353.Core.Aura.Size.Keypoints, p2349)
			local v2370 = v_u_2353.Core.Sparks
			local v2371 = ColorSequence.new
			local v2372 = Color3.fromRGB
			local v2373 = string.split
			local v2374 = p2349.COLOR
			v2370.Color = v2371(v2372(unpack(v2373(v2374))), v_u_31(p2349))
			local v2375 = v_u_2353.Core.Sparks
			local v2376 = NumberSequence.new
			local v2377 = p2349.OPACITY
			local v2378 = tonumber(v2377)
			local v2379 = p2349["ALT OPACITY"]
			v2375.Transparency = v2376(v2378, (tonumber(v2379)))
			v_u_2353.Core.Sparks.Size = v_u_51(v_u_2353.Core.Sparks.Size.Keypoints, p2349)
			local v2380 = v_u_2353.Trail
			local v2381 = ColorSequence.new
			local v2382 = Color3.fromRGB
			local v2383 = string.split
			local v2384 = p2349.COLOR
			v2380.Color = v2381(v2382(unpack(v2383(v2384))), v_u_31(p2349))
			local v2385 = v_u_2353.Trail
			local v2386 = NumberSequence.new
			local v2387 = p2349.OPACITY
			local v2388 = tonumber(v2387)
			local v2389 = p2349["ALT OPACITY"]
			v2385.Transparency = v2386(v2388, (tonumber(v2389)))
			v_u_2353.Trail.WidthScale = v_u_51(v_u_2353.Trail.WidthScale.Keypoints, p2349)
			local v2390 = v_u_2353.PointLight
			local v2391 = Color3.fromRGB
			local v2392 = string.split
			local v2393 = p2349.COLOR
			v2390.Color = v2391(unpack(v2392(v2393)))
			local v2394 = v_u_2353.PointLight
			local v2395 = v2394.Range
			local v2396 = p2349.SIZE
			local v2397 = tonumber(v2396)
			if workspace:GetAttribute("Creator") then
				v2397 = math.clamp(v2397, 0, 40)
			end
			v2394.Range = v2395 * v2397
			v_u_2353.Parent = workspace.Effects
			local v2398 = v_u_11
			local v2399 = p2349.TIME
			local v2400 = tonumber(v2399)
			if workspace:GetAttribute("Creator") then
				v2400 = math.clamp(v2400, 0, 10)
			end
			v2398:AddItem(v_u_2353, v2400 + 2)
			local v2401 = v_u_3
			local v2402 = v_u_2353.PointLight
			local v2403 = TweenInfo.new
			local v2404 = p2349.TIME
			local v2405 = tonumber(v2404)
			if workspace:GetAttribute("Creator") then
				v2405 = math.clamp(v2405, 0, 10)
			end
			v2401:Create(v2402, v2403(v2405 * 0.2), {
				["Brightness"] = 5
			}):Play()
			local v2406 = task.wait
			local v2407 = p2349.TIME
			local v2408 = tonumber(v2407)
			if workspace:GetAttribute("Creator") then
				v2408 = math.clamp(v2408, 0, 10)
			end
			v2406(v2408 * 0.8)
			v_u_2353.Core.Aura.Enabled = false
			v_u_2353.Core.Sparks.Enabled = false
			local v2409 = task.delay
			local v2410 = p2349.TIME
			local v2411 = tonumber(v2410)
			if workspace:GetAttribute("Creator") then
				v2411 = math.clamp(v2411, 0, 10)
			end
			v2409(v2411 * 0.05, function()
				-- upvalues: (copy) v_u_2353
				v_u_2353.Trail.Enabled = false
			end)
			local v2412 = v_u_3
			local v2413 = v_u_2353.PointLight
			local v2414 = TweenInfo.new
			local v2415 = p2349.TIME
			local v2416 = tonumber(v2415)
			if workspace:GetAttribute("Creator") then
				v2416 = math.clamp(v2416, 0, 10)
			end
			v2412:Create(v2413, v2414(v2416 * 0.2), {
				["Brightness"] = 0
			}):Play()
		end
	end,
	["Burst"] = function(p2417, p2418)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26, (copy) v_u_31, (copy) v_u_51
		local v2419 = p2417:FindFirstChild("HumanoidRootPart")
		if v2419 then
			if p2418.RELATIVE ~= nil then
				p2417 = p2418.RELATIVE
			end
			if not p2417:IsA("BasePart") then
				if p2417:FindFirstChild(p2418["BODY PART"]) then
					p2417 = p2417[p2418["BODY PART"]]
				else
					p2417 = nil
				end
			end
			local v2420 = p2417 or v2419
			local v2421 = v_u_70(v2420, p2418)
			local v2422 = v_u_1.Parent.DashCancel:Clone()
			local v2423 = Instance.new("Model")
			v2422.Parent = v2423
			local v2424 = p2418.SIZE
			local v2425 = tonumber(v2424)
			if workspace:GetAttribute("Creator") then
				v2425 = math.clamp(v2425, 0, 40)
			end
			v2423:ScaleTo(v2425)
			v_u_11:AddItem(v2423, 0.1)
			local v2426 = p2418.POSITION
			local v2427
			if v2426 then
				local v2428 = string.split
				local v2429 = unpack
				v2427 = Vector3.new(v2429(v2428(v2426)))
			else
				v2427 = Vector3.new(0, 0, 0)
			end
			local v2430 = CFrame.new(-v2427.X, v2427.Y, -v2427.Z)
			local v2431 = (v2420 and v2420.CFrame or CFrame.new()) * v2430
			local v2432 = p2418.ROTATION
			local v2433
			if v2432 then
				local v2434 = string.split
				local v2435 = unpack
				v2433 = Vector3.new(v2435(v2434(v2432)))
			else
				v2433 = Vector3.new(0, 0, 0)
			end
			local v2436 = CFrame.fromOrientation
			local v2437 = v2433.X
			local v2438 = math.rad(v2437)
			local v2439 = v2433.Y
			local v2440 = math.rad(v2439)
			local v2441 = v2433.Z
			v2422.CFrame = v2431 * v2436(v2438, v2440, (math.rad(v2441)))
			v2422.Parent = workspace.Effects
			local v2442 = p2418["ALT POSITION"]
			local v2443
			if v2442 then
				local v2444 = string.split
				local v2445 = unpack
				v2443 = Vector3.new(v2445(v2444(v2442)))
			else
				v2443 = Vector3.new(0, 0, 0)
			end
			if v2443 == Vector3.new(0, 0, 0) then
				v2422.Anchored = false
				local v2446 = Instance.new("Motor6D", v2422)
				v2446.Part0 = v2420
				v2446.Part1 = v2422
				local v2447 = p2418.POSITION
				local v2448
				if v2447 then
					local v2449 = string.split
					local v2450 = unpack
					v2448 = Vector3.new(v2450(v2449(v2447)))
				else
					v2448 = Vector3.new(0, 0, 0)
				end
				local v2451 = CFrame.new(-v2448.X, v2448.Y, -v2448.Z)
				v2446.C0 = CFrame.new() * v2451
				local v2452 = p2418.ROTATION
				local v2453
				if v2452 then
					local v2454 = string.split
					local v2455 = unpack
					v2453 = Vector3.new(v2455(v2454(v2452)))
				else
					v2453 = Vector3.new(0, 0, 0)
				end
				local v2456 = CFrame.fromOrientation
				local v2457 = v2453.X
				local v2458 = math.rad(v2457)
				local v2459 = v2453.Y
				local v2460 = math.rad(v2459)
				local v2461 = v2453.Z
				v2446.C1 = v2456(v2458, v2460, (math.rad(v2461)))
				v2446.Parent = v2422
				local v2462 = v_u_3
				local v2463 = TweenInfo.new
				local v2464 = p2418.TIME
				local v2465 = tonumber(v2464)
				if workspace:GetAttribute("Creator") then
					v2465 = math.clamp(v2465, 0, 10)
				end
				local v2466
				if p2418["EASING STYLE"] then
					v2466 = Enum.EasingStyle[p2418["EASING STYLE"]]
				else
					v2466 = Enum.EasingStyle.Linear
				end
				local v2467
				if p2418["EASING DIRECTION"] then
					v2467 = Enum.EasingDirection[p2418["EASING DIRECTION"]]
				else
					v2467 = Enum.EasingDirection.In
				end
				local v2468 = v2463(v2465, v2466, v2467)
				local v2469 = {
					["C0"] = v_u_26(nil, p2418, true)
				}
				local v2470 = p2418["ALT ROTATION"] or p2418.ROTATION
				local v2471
				if v2470 then
					local v2472 = string.split
					local v2473 = unpack
					v2471 = Vector3.new(v2473(v2472(v2470)))
				else
					v2471 = Vector3.new(0, 0, 0)
				end
				local v2474 = CFrame.fromOrientation
				local v2475 = v2471.X
				local v2476 = math.rad(v2475)
				local v2477 = v2471.Y
				local v2478 = math.rad(v2477)
				local v2479 = v2471.Z
				v2469.C1 = v2474(v2476, v2478, (math.rad(v2479)))
				v2462:Create(v2446, v2468, v2469):Play()
			else
				local v2480 = v_u_3
				local v2481 = TweenInfo.new
				local v2482 = p2418.TIME
				local v2483 = tonumber(v2482)
				if workspace:GetAttribute("Creator") then
					v2483 = math.clamp(v2483, 0, 10)
				end
				local v2484
				if p2418["EASING STYLE"] then
					v2484 = Enum.EasingStyle[p2418["EASING STYLE"]]
				else
					v2484 = Enum.EasingStyle.Linear
				end
				local v2485
				if p2418["EASING DIRECTION"] then
					v2485 = Enum.EasingDirection[p2418["EASING DIRECTION"]]
				else
					v2485 = Enum.EasingDirection.In
				end
				local v2486 = v2481(v2483, v2484, v2485)
				local v2487 = {}
				local v2488 = v_u_26(v2420, p2418, true)
				local v2489 = p2418["ALT ROTATION"] or p2418.ROTATION
				local v2490
				if v2489 then
					local v2491 = string.split
					local v2492 = unpack
					v2490 = Vector3.new(v2492(v2491(v2489)))
				else
					v2490 = Vector3.new(0, 0, 0)
				end
				local v2493 = CFrame.fromOrientation
				local v2494 = v2490.X
				local v2495 = math.rad(v2494)
				local v2496 = v2490.Y
				local v2497 = math.rad(v2496)
				local v2498 = v2490.Z
				v2487.CFrame = v2488 * v2493(v2495, v2497, (math.rad(v2498)))
				v2480:Create(v2422, v2486, v2487):Play()
			end
			for _, v2499 in pairs(v2422:GetChildren()) do
				if v2499:IsA("ParticleEmitter") then
					local v2500 = ColorSequence.new
					local v2501 = Color3.fromRGB
					local v2502 = string.split
					local v2503 = p2418.COLOR
					v2499.Color = v2500(v2501(unpack(v2502(v2503))), v_u_31(p2418))
					local v2504 = NumberRange.new
					local v2505 = p2418.TIME
					local v2506 = tonumber(v2505)
					if workspace:GetAttribute("Creator") then
						v2506 = math.clamp(v2506, 0, 10)
					end
					v2499.Lifetime = v2504(v2506)
					local v2507 = NumberSequence.new
					local v2508 = p2418.OPACITY
					local v2509 = tonumber(v2508)
					local v2510 = p2418["ALT OPACITY"]
					v2499.Transparency = v2507(v2509, (tonumber(v2510)))
					v2499.Size = v_u_51(v2499.Size.Keypoints, p2418)
					v2499.LockedToPart = true
				end
			end
			table.insert(v2421, v2422)
			local v2511 = v2422.Burst
			local v2512 = 8
			local v2513 = p2418.AMOUNT
			local v2514 = tonumber(v2513)
			if workspace:GetAttribute("Creator") then
				v2514 = math.clamp(v2514, 1, 20)
			end
			v2511:Emit(v2512 * v2514)
			local v2515 = v2422.Sparks
			local v2516 = 20
			local v2517 = p2418.AMOUNT
			local v2518 = tonumber(v2517)
			if workspace:GetAttribute("Creator") then
				v2518 = math.clamp(v2518, 1, 20)
			end
			v2515:Emit(v2516 * v2518)
			local v2519 = v_u_11
			local v2520 = p2418.TIME
			local v2521 = tonumber(v2520)
			if workspace:GetAttribute("Creator") then
				v2521 = math.clamp(v2521, 0, 10)
			end
			v2519:AddItem(v2422, v2521)
		end
	end,
	["Mass Hit"] = function(p2522, p2523)
		-- upvalues: (copy) v_u_1, (copy) v_u_26, (copy) v_u_31, (copy) v_u_51, (ref) v_u_11
		local v2524 = p2522:FindFirstChild("HumanoidRootPart")
		if v2524 then
			if p2523.RELATIVE ~= nil then
				p2522 = p2523.RELATIVE
			end
			if not p2522:IsA("BasePart") then
				if p2522:FindFirstChild(p2523["BODY PART"]) then
					p2522 = p2522[p2523["BODY PART"]]
				else
					p2522 = nil
				end
			end
			local v2525 = p2522 or v2524
			local v2526 = v_u_1.Parent.Yuki.MassHit:Clone()
			local v2527 = CFrame.lookAt
			local v2528 = p2523.POSITION
			local v2529
			if v2528 then
				local v2530 = string.split
				local v2531 = unpack
				v2529 = Vector3.new(v2531(v2530(v2528)))
			else
				v2529 = Vector3.new(0, 0, 0)
			end
			local v2532 = CFrame.new(-v2529.X, v2529.Y, -v2529.Z)
			local v2533 = v2527(((v2525 and v2525.CFrame or CFrame.new()) * v2532).Position, v_u_26(v2525, p2523, true).Position)
			if v_u_26(nil, p2523, true) == Vector3.new(0, 0, 0) then
				v2533 = v2525.CFrame or v2533
			end
			v2526.CFrame = v2533
			for _, v2534 in pairs(v2526:GetDescendants()) do
				if v2534:IsA("ParticleEmitter") then
					local v2535 = ColorSequence.new
					local v2536 = Color3.fromRGB
					local v2537 = string.split
					local v2538 = p2523.COLOR
					v2534.Color = v2535(v2536(unpack(v2537(v2538))), v_u_31(p2523))
					local v2539 = NumberRange.new
					local v2540 = p2523.TIME
					local v2541 = tonumber(v2540)
					if workspace:GetAttribute("Creator") then
						v2541 = math.clamp(v2541, 0, 10)
					end
					v2534.Lifetime = v2539(v2541)
					local v2542 = NumberSequence.new
					local v2543 = p2523.OPACITY
					local v2544 = tonumber(v2543)
					local v2545 = p2523["ALT OPACITY"]
					v2534.Transparency = v2542(v2544, (tonumber(v2545)))
					v2534.Size = v_u_51(v2534.Size.Keypoints, p2523)
				end
			end
			v2526.Parent = workspace.Effects
			local v2546 = v_u_11
			local v2547 = p2523.TIME
			local v2548 = tonumber(v2547)
			if workspace:GetAttribute("Creator") then
				v2548 = math.clamp(v2548, 0, 10)
			end
			v2546:AddItem(v2526, v2548)
			for _, v2549 in v2526:GetDescendants() do
				if v2549:IsA("ParticleEmitter") then
					local v2550 = v2549:GetAttribute("EmitCount")
					local v2551 = p2523.AMOUNT
					local v2552 = tonumber(v2551)
					if workspace:GetAttribute("Creator") then
						v2552 = math.clamp(v2552, 1, 20)
					end
					v2549:Emit(v2550 * v2552)
				end
			end
		end
	end,
	["Beam"] = function(p2553, p2554)
		-- upvalues: (copy) v_u_1, (copy) v_u_26, (ref) v_u_11, (copy) v_u_3
		local v2555 = p2553:FindFirstChild("HumanoidRootPart")
		if v2555 then
			if p2554.RELATIVE ~= nil then
				p2553 = p2554.RELATIVE
			end
			if not p2553:IsA("BasePart") then
				if p2553:FindFirstChild(p2554["BODY PART"]) then
					p2553 = p2553[p2554["BODY PART"]]
				else
					p2553 = nil
				end
			end
			local v2556 = p2553 or v2555
			local v2557 = v_u_1.Beam:Clone()
			local v2558 = p2554.POSITION
			local v2559
			if v2558 then
				local v2560 = string.split
				local v2561 = unpack
				v2559 = Vector3.new(v2561(v2560(v2558)))
			else
				v2559 = Vector3.new(0, 0, 0)
			end
			local v2562 = CFrame.new(-v2559.X, v2559.Y, -v2559.Z)
			local v2563 = (v2556 and v2556.CFrame or CFrame.new()) * v2562
			local v2564 = p2554.ROTATION
			local v2565
			if v2564 then
				local v2566 = string.split
				local v2567 = unpack
				v2565 = Vector3.new(v2567(v2566(v2564)))
			else
				v2565 = Vector3.new(0, 0, 0)
			end
			local v2568 = CFrame.fromOrientation
			local v2569 = v2565.X
			local v2570 = math.rad(v2569)
			local v2571 = v2565.Y
			local v2572 = math.rad(v2571)
			local v2573 = v2565.Z
			local v2574 = (v2563 * v2568(v2570, v2572, (math.rad(v2573)))).Position
			local v2575 = v_u_26(v2556, p2554, true)
			local v2576 = p2554["ALT ROTATION"] or p2554.ROTATION
			local v2577
			if v2576 then
				local v2578 = string.split
				local v2579 = unpack
				v2577 = Vector3.new(v2579(v2578(v2576)))
			else
				v2577 = Vector3.new(0, 0, 0)
			end
			local v2580 = CFrame.fromOrientation
			local v2581 = v2577.X
			local v2582 = math.rad(v2581)
			local v2583 = v2577.Y
			local v2584 = math.rad(v2583)
			local v2585 = v2577.Z
			local v2586 = (v2574 - (v2575 * v2580(v2582, v2584, (math.rad(v2585)))).Position).Magnitude
			local v2587 = CFrame.lookAt
			local v2588 = p2554.POSITION
			local v2589
			if v2588 then
				local v2590 = string.split
				local v2591 = unpack
				v2589 = Vector3.new(v2591(v2590(v2588)))
			else
				v2589 = Vector3.new(0, 0, 0)
			end
			local v2592 = CFrame.new(-v2589.X, v2589.Y, -v2589.Z)
			local v2593 = (v2556 and v2556.CFrame or CFrame.new()) * v2592
			local v2594 = p2554.ROTATION
			local v2595
			if v2594 then
				local v2596 = string.split
				local v2597 = unpack
				v2595 = Vector3.new(v2597(v2596(v2594)))
			else
				v2595 = Vector3.new(0, 0, 0)
			end
			local v2598 = CFrame.fromOrientation
			local v2599 = v2595.X
			local v2600 = math.rad(v2599)
			local v2601 = v2595.Y
			local v2602 = math.rad(v2601)
			local v2603 = v2595.Z
			local v2604 = (v2593 * v2598(v2600, v2602, (math.rad(v2603)))).Position
			local v2605 = v_u_26(v2556, p2554, true)
			local v2606 = p2554["ALT ROTATION"] or p2554.ROTATION
			local v2607
			if v2606 then
				local v2608 = string.split
				local v2609 = unpack
				v2607 = Vector3.new(v2609(v2608(v2606)))
			else
				v2607 = Vector3.new(0, 0, 0)
			end
			local v2610 = CFrame.fromOrientation
			local v2611 = v2607.X
			local v2612 = math.rad(v2611)
			local v2613 = v2607.Y
			local v2614 = math.rad(v2613)
			local v2615 = v2607.Z
			v2557.CFrame = v2587(v2604, (v2605 * v2610(v2612, v2614, (math.rad(v2615)))).Position) * CFrame.new(0, 0, -v2586 / 2)
			local v2616 = p2554.SIZE
			local v2617 = tonumber(v2616)
			if workspace:GetAttribute("Creator") then
				v2617 = math.clamp(v2617, 0, 40)
			end
			local v2618 = p2554.SIZE
			local v2619 = tonumber(v2618)
			if workspace:GetAttribute("Creator") then
				v2619 = math.clamp(v2619, 0, 40)
			end
			v2557.Size = Vector3.new(v2617, v2619, v2586)
			local v2620 = Color3.fromRGB
			local v2621 = string.split
			local v2622 = p2554.COLOR
			v2557.Color = v2620(unpack(v2621(v2622)))
			local v2623 = p2554.OPACITY
			v2557.Transparency = tonumber(v2623)
			v2557.Parent = workspace
			local v2624 = v_u_11
			local v2625 = p2554.TIME
			local v2626 = tonumber(v2625)
			if workspace:GetAttribute("Creator") then
				v2626 = math.clamp(v2626, 0, 10)
			end
			v2624:AddItem(v2557, v2626)
			local v2627 = p2554["ALT POSITION"]
			local v2628
			if v2627 then
				local v2629 = string.split
				local v2630 = unpack
				v2628 = Vector3.new(v2630(v2629(v2627)))
			else
				v2628 = Vector3.new(0, 0, 0)
			end
			if v2628 == Vector3.new(0, 0, 0) then
				v2557.Massless = true
				v2557.Anchored = false
				local v2631 = Instance.new("Weld")
				v2631.Part0 = v2556
				v2631.Part1 = v2557
				local v2632 = p2554.POSITION
				local v2633
				if v2632 then
					local v2634 = string.split
					local v2635 = unpack
					v2633 = Vector3.new(v2635(v2634(v2632)))
				else
					v2633 = Vector3.new(0, 0, 0)
				end
				local v2636 = CFrame.new(-v2633.X, v2633.Y, -v2633.Z)
				local v2637 = CFrame.new() * v2636
				local v2638 = p2554.ROTATION
				local v2639
				if v2638 then
					local v2640 = string.split
					local v2641 = unpack
					v2639 = Vector3.new(v2641(v2640(v2638)))
				else
					v2639 = Vector3.new(0, 0, 0)
				end
				local v2642 = CFrame.fromOrientation
				local v2643 = v2639.X
				local v2644 = math.rad(v2643)
				local v2645 = v2639.Y
				local v2646 = math.rad(v2645)
				local v2647 = v2639.Z
				v2631.C0 = v2637 * v2642(v2644, v2646, (math.rad(v2647)))
				v2631.Parent = v2557
			end
			local v2648 = v_u_3
			local v2649 = TweenInfo.new
			local v2650 = p2554.TIME
			local v2651 = tonumber(v2650)
			if workspace:GetAttribute("Creator") then
				v2651 = math.clamp(v2651, 0, 10)
			end
			local v2652
			if p2554["EASING STYLE"] then
				v2652 = Enum.EasingStyle[p2554["EASING STYLE"]]
			else
				v2652 = Enum.EasingStyle.Linear
			end
			local v2653
			if p2554["EASING DIRECTION"] then
				v2653 = Enum.EasingDirection[p2554["EASING DIRECTION"]]
			else
				v2653 = Enum.EasingDirection.In
			end
			local v2654 = v2649(v2651, v2652, v2653)
			local v2655 = {}
			local v2656 = p2554.SIZE
			local v2657 = tonumber(v2656)
			if workspace:GetAttribute("Creator") then
				v2657 = math.clamp(v2657, 0, 40)
			end
			local v2658 = p2554["ALT SIZE"] or 1
			local v2659 = v2657 * tonumber(v2658)
			if workspace:GetAttribute("Creator") then
				v2659 = math.clamp(v2659, 0, 40)
			end
			local v2660 = p2554.SIZE
			local v2661 = tonumber(v2660)
			if workspace:GetAttribute("Creator") then
				v2661 = math.clamp(v2661, 0, 40)
			end
			local v2662 = p2554["ALT SIZE"] or 1
			local v2663 = v2661 * tonumber(v2662)
			if workspace:GetAttribute("Creator") then
				v2663 = math.clamp(v2663, 0, 40)
			end
			v2655.Size = Vector3.new(v2659, v2663, v2586)
			local v2664 = Color3.fromRGB
			local v2665 = string.split
			local v2666 = p2554["ALT COLOR"]
			v2655.Color = v2664(unpack(v2665(v2666)))
			local v2667 = p2554["ALT OPACITY"]
			v2655.Transparency = tonumber(v2667)
			v2648:Create(v2557, v2654, v2655):Play()
		end
	end,
	["Shake Light"] = function(p2668, p2669)
		-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_7
		if not v_u_2:IsServer() then
			if v_u_5.Character == p2668 then
				local v2670 = p2669.AMOUNT
				local v2671 = tonumber(v2670)
				if workspace:GetAttribute("Creator") then
					v2671 = math.clamp(v2671, 1, 20)
				end
				for _ = 1, math.clamp(v2671, 0, 10000) do
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.LightHit)
				end
			end
		end
	end,
	["Shake Medium"] = function(p2672, p2673)
		-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_7
		if not v_u_2:IsServer() then
			if v_u_5.Character == p2672 then
				local v2674 = p2673.AMOUNT
				local v2675 = tonumber(v2674)
				if workspace:GetAttribute("Creator") then
					v2675 = math.clamp(v2675, 1, 20)
				end
				for _ = 1, math.clamp(v2675, 0, 10000) do
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.MediumHit)
				end
			end
		end
	end,
	["Shake Heavy"] = function(p2676, p2677)
		-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_7
		if not v_u_2:IsServer() then
			if v_u_5.Character == p2676 then
				local v2678 = p2677.AMOUNT
				local v2679 = tonumber(v2678)
				if workspace:GetAttribute("Creator") then
					v2679 = math.clamp(v2679, 1, 20)
				end
				for _ = 1, math.clamp(v2679, 0, 10000) do
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.HeavyHit)
				end
			end
		end
	end,
	["Blood"] = function(p2680, p2681)
		-- upvalues: (copy) v_u_2, (copy) v_u_8
		if v_u_2:IsServer() then
			return
		else
			local v2682 = p2680:FindFirstChild("HumanoidRootPart")
			if v2682 then
				if p2681.RELATIVE ~= nil then
					p2680 = p2681.RELATIVE
				end
				if not p2680:IsA("BasePart") then
					if p2680:FindFirstChild(p2681["BODY PART"]) then
						p2680 = p2680[p2681["BODY PART"]]
					else
						p2680 = nil
					end
				end
				local v2683 = p2680 or v2682
				local v2684 = 1
				local v2685 = p2681.AMOUNT
				local v2686 = tonumber(v2685)
				if workspace:GetAttribute("Creator") then
					v2686 = math.clamp(v2686, 1, 20)
				end
				for _ = v2684, v2686 do
					local v2687 = v_u_8
					local v2688 = v2683.CFrame
					local v2689 = math.random
					local v2690 = p2681.SIZE
					local v2691 = tonumber(v2690)
					if workspace:GetAttribute("Creator") then
						v2691 = math.clamp(v2691, 0, 40)
					end
					local v2692 = v2691 / 2
					local v2693 = p2681.SIZE
					local v2694 = tonumber(v2693)
					if workspace:GetAttribute("Creator") then
						v2694 = math.clamp(v2694, 0, 40)
					end
					v2687:Blood(v2688, v2689(v2692, v2694), 360, 360)
				end
			end
		end
	end,
	["Camera"] = function(p2695, p_u_2696)
		-- upvalues: (copy) v_u_2, (copy) v_u_70, (copy) v_u_5, (copy) v_u_26, (copy) v_u_3
		if v_u_2:IsServer() then
			return
		else
			local v2697 = p2695:FindFirstChild("HumanoidRootPart")
			if v2697 then
				local v2698
				if p_u_2696.RELATIVE == nil then
					v2698 = p2695
				else
					v2698 = p_u_2696.RELATIVE
				end
				if not v2698:IsA("BasePart") then
					if v2698:FindFirstChild(p_u_2696["BODY PART"]) then
						v2698 = v2698[p_u_2696["BODY PART"]]
					else
						v2698 = nil
					end
				end
				local v_u_2699 = v2698 or v2697
				local v2700 = v_u_70(v_u_2699, p_u_2696)
				if v_u_5.Character == p2695 then
					local v_u_2701 = workspace.CurrentCamera
					local _ = v_u_2701.CFrame
					local v2702 = p_u_2696.POSITION
					local v2703
					if v2702 then
						local v2704 = string.split
						local v2705 = unpack
						v2703 = Vector3.new(v2705(v2704(v2702)))
					else
						v2703 = Vector3.new(0, 0, 0)
					end
					local v2706 = CFrame.new(-v2703.X, v2703.Y, -v2703.Z)
					local v2707 = CFrame.new() * v2706
					local v2708 = p_u_2696.ROTATION
					local v2709
					if v2708 then
						local v2710 = string.split
						local v2711 = unpack
						v2709 = Vector3.new(v2711(v2710(v2708)))
					else
						v2709 = Vector3.new(0, 0, 0)
					end
					local v2712 = CFrame.fromOrientation
					local v2713 = v2709.X
					local v2714 = math.rad(v2713)
					local v2715 = v2709.Y
					local v2716 = math.rad(v2715)
					local v2717 = v2709.Z
					local v_u_2718 = v2707 * v2712(v2714, v2716, (math.rad(v2717)))
					local v2719 = p_u_2696["ALT POSITION"]
					local v2720
					if v2719 then
						local v2721 = string.split
						local v2722 = unpack
						v2720 = Vector3.new(v2722(v2721(v2719)))
					else
						v2720 = Vector3.new(0, 0, 0)
					end
					local v_u_2723
					if v2720 == Vector3.new(0, 0, 0) then
						v_u_2723 = nil
					else
						local v2724 = v_u_26(nil, p_u_2696, true)
						local v2725 = p_u_2696["ALT ROTATION"] or p_u_2696.ROTATION
						local v2726
						if v2725 then
							local v2727 = string.split
							local v2728 = unpack
							v2726 = Vector3.new(v2728(v2727(v2725)))
						else
							v2726 = Vector3.new(0, 0, 0)
						end
						local v2729 = CFrame.fromOrientation
						local v2730 = v2726.X
						local v2731 = math.rad(v2730)
						local v2732 = v2726.Y
						local v2733 = math.rad(v2732)
						local v2734 = v2726.Z
						v_u_2723 = v2724 * v2729(v2731, v2733, (math.rad(v2734))) or nil
					end
					local v2735 = p_u_2696.TIME
					local v_u_2736 = tonumber(v2735)
					if workspace:GetAttribute("Creator") then
						v_u_2736 = math.clamp(v_u_2736, 0, 10)
					end
					if workspace:GetAttribute("Creator") then
						v_u_2736 = math.clamp(v_u_2736, 0, 10)
					end
					local v_u_2737 = tick()
					v_u_2701:SetAttribute("CameraStart", v_u_2737)
					local v_u_2738 = Instance.new("NumberValue")
					v_u_2738.Name = "Cutscene"
					v_u_2738.Parent = v_u_2701
					table.insert(v2700, v_u_2738)
					local v_u_2739 = nil
					v_u_2739 = v_u_2.RenderStepped:Connect(function(_)
						-- upvalues: (ref) v_u_2699, (copy) v_u_2737, (copy) p_u_2696, (copy) v_u_2738, (ref) v_u_2739, (copy) v_u_2701, (ref) v_u_5, (copy) v_u_2718, (copy) v_u_2723, (ref) v_u_3, (ref) v_u_2736
						if v_u_2699.Parent ~= nil then
							local v2740 = tick() - v_u_2737
							local v2741 = p_u_2696.TIME
							local v2742 = tonumber(v2741)
							if workspace:GetAttribute("Creator") then
								v2742 = math.clamp(v2742, 0, 10)
							end
							if v2742 >= v2740 and v_u_2738.Parent ~= nil then
								if v_u_2701:GetAttribute("CameraStart") == v_u_2737 then
									local v2743 = v_u_2718
									if v_u_2723 then
										local v2744 = v_u_3
										local v2745 = (tick() - v_u_2737) / v_u_2736
										local v2746 = p_u_2696
										local v2747
										if v2746["EASING STYLE"] then
											v2747 = Enum.EasingStyle[v2746["EASING STYLE"]]
										else
											v2747 = Enum.EasingStyle.Linear
										end
										local v2748 = p_u_2696
										local v2749
										if v2748["EASING DIRECTION"] then
											v2749 = Enum.EasingDirection[v2748["EASING DIRECTION"]]
										else
											v2749 = Enum.EasingDirection.In
										end
										v2743 = v_u_2718:Lerp(v_u_2723, (v2744:GetValue(v2745, v2747, v2749)))
									end
									v_u_2701.CFrame = v_u_2699.CFrame * v2743
									v_u_2701.CameraType = Enum.CameraType.Scriptable
								end
							end
						end
						v_u_2739:Disconnect()
						v_u_2701.CameraType = Enum.CameraType.Custom
						v_u_2701.CameraSubject = (v_u_5.Character or v_u_5.CharacterAdded:Wait()):WaitForChild("Humanoid")
						v_u_2738:Destroy()
					end)
					v_u_2738.AncestryChanged:Connect(function()
						-- upvalues: (ref) v_u_2739, (copy) v_u_2738, (copy) v_u_2701, (ref) v_u_5
						v_u_2739:Disconnect()
						if v_u_2738.Parent == nil then
							v_u_2701.CameraType = Enum.CameraType.Custom
							v_u_2701.CameraSubject = (v_u_5.Character or v_u_5.CharacterAdded:Wait()):WaitForChild("Humanoid")
						end
					end)
				end
			end
		end
	end,
	["Billboard"] = function(p2750, p2751)
		-- upvalues: (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3, (copy) v_u_26
		local v2752 = p2750:FindFirstChild("HumanoidRootPart")
		if v2752 then
			local v2753 = v_u_70(v2752, p2751)
			local v2754 = p2751.TEXTURE or 0
			local v2755 = tonumber(v2754)
			local v2756 = v2755 == 0 and 14978581240 or v2755
			local v2757 = v_u_1.Parent.Gojo.Dialogue:Clone()
			v2757:ClearAllChildren()
			v2757.Parent = v2752
			local v2758 = UDim2.fromScale
			local v2759 = 15
			local v2760 = p2751.AMOUNT
			local v2761 = tonumber(v2760)
			if workspace:GetAttribute("Creator") then
				v2761 = math.clamp(v2761, 1, 20)
			end
			local v2762 = v2759 * v2761
			local v2763 = 15
			local v2764 = p2751.AMOUNT
			local v2765 = tonumber(v2764)
			if workspace:GetAttribute("Creator") then
				v2765 = math.clamp(v2765, 1, 20)
			end
			v2757.Size = v2758(v2762, v2763 * v2765)
			local v2766 = 0
			local v2767 = 0
			local v2768 = p2751.POSITION
			local v2769
			if v2768 then
				local v2770 = string.split
				local v2771 = unpack
				v2769 = Vector3.new(v2771(v2770(v2768)))
			else
				v2769 = Vector3.new(0, 0, 0)
			end
			local v2772 = CFrame.new(-v2769.X, v2769.Y, -v2769.Z)
			local v2773 = (CFrame.new() * v2772).Z
			v2757.StudsOffset = Vector3.new(v2766, v2767, v2773)
			local v2774 = v_u_11
			local v2775 = p2751.TIME
			local v2776 = tonumber(v2775)
			if workspace:GetAttribute("Creator") then
				v2776 = math.clamp(v2776, 0, 10)
			end
			v2774:AddItem(v2757, v2776)
			local v2777 = Instance.new("ImageLabel")
			v2777.AnchorPoint = Vector2.new(0.5, 0.5)
			v2777.BackgroundTransparency = 1
			v2777.Image = "rbxassetid://" .. v2756
			local v2778 = Color3.fromRGB
			local v2779 = string.split
			local v2780 = p2751.COLOR
			v2777.ImageColor3 = v2778(unpack(v2779(v2780)))
			local v2781 = p2751.OPACITY
			v2777.ImageTransparency = tonumber(v2781)
			local v2782 = UDim2.fromScale
			local v2783 = 0.15
			local v2784 = p2751.SIZE
			local v2785 = tonumber(v2784)
			if workspace:GetAttribute("Creator") then
				v2785 = math.clamp(v2785, 0, 40)
			end
			local v2786 = v2783 * v2785
			local v2787 = 0.15
			local v2788 = p2751.SIZE
			local v2789 = tonumber(v2788)
			if workspace:GetAttribute("Creator") then
				v2789 = math.clamp(v2789, 0, 40)
			end
			v2777.Size = v2782(v2786, v2787 * v2789)
			local v2790 = UDim2.fromScale
			local v2791 = p2751.POSITION
			local v2792
			if v2791 then
				local v2793 = string.split
				local v2794 = unpack
				v2792 = Vector3.new(v2794(v2793(v2791)))
			else
				v2792 = Vector3.new(0, 0, 0)
			end
			local v2795 = CFrame.new(-v2792.X, v2792.Y, -v2792.Z)
			local v2796 = (CFrame.new() * v2795).X / 10 + 0.5
			local v2797 = p2751.POSITION
			local v2798
			if v2797 then
				local v2799 = string.split
				local v2800 = unpack
				v2798 = Vector3.new(v2800(v2799(v2797)))
			else
				v2798 = Vector3.new(0, 0, 0)
			end
			local v2801 = CFrame.new(-v2798.X, v2798.Y, -v2798.Z)
			v2777.Position = v2790(v2796, -(CFrame.new() * v2801).Y / 10 + 0.5)
			v2777.Parent = v2757
			local v2802 = v_u_3
			local v2803 = TweenInfo.new
			local v2804 = p2751.TIME
			local v2805 = tonumber(v2804)
			if workspace:GetAttribute("Creator") then
				v2805 = math.clamp(v2805, 0, 10)
			end
			local v2806
			if p2751["EASING STYLE"] then
				v2806 = Enum.EasingStyle[p2751["EASING STYLE"]]
			else
				v2806 = Enum.EasingStyle.Linear
			end
			local v2807
			if p2751["EASING DIRECTION"] then
				v2807 = Enum.EasingDirection[p2751["EASING DIRECTION"]]
			else
				v2807 = Enum.EasingDirection.In
			end
			local v2808 = v2803(v2805, v2806, v2807)
			local v2809 = {}
			local v2810 = p2751["ALT OPACITY"]
			v2809.ImageTransparency = tonumber(v2810)
			local v2811 = UDim2.fromScale
			local v2812 = 0.15
			local v2813 = p2751.SIZE
			local v2814 = tonumber(v2813)
			if workspace:GetAttribute("Creator") then
				v2814 = math.clamp(v2814, 0, 40)
			end
			local v2815 = p2751["ALT SIZE"] or 1
			local v2816 = v2814 * tonumber(v2815)
			if workspace:GetAttribute("Creator") then
				v2816 = math.clamp(v2816, 0, 40)
			end
			local v2817 = v2812 * v2816
			local v2818 = 0.15
			local v2819 = p2751.SIZE
			local v2820 = tonumber(v2819)
			if workspace:GetAttribute("Creator") then
				v2820 = math.clamp(v2820, 0, 40)
			end
			local v2821 = p2751["ALT SIZE"] or 1
			local v2822 = v2820 * tonumber(v2821)
			if workspace:GetAttribute("Creator") then
				v2822 = math.clamp(v2822, 0, 40)
			end
			v2809.Size = v2811(v2817, v2818 * v2822)
			v2809.Position = UDim2.fromScale(v_u_26(nil, p2751, true).X / 10 + 0.5, v_u_26(nil, p2751, true).Y / 10 + 0.5)
			local v2823 = Color3.fromRGB
			local v2824 = string.split
			local v2825 = p2751["ALT COLOR"]
			v2809.ImageColor3 = v2823(unpack(v2824(v2825)))
			v2802:Create(v2777, v2808, v2809):Play()
			local v2826 = v_u_3
			local v2827 = TweenInfo.new
			local v2828 = p2751.TIME
			local v2829 = tonumber(v2828)
			if workspace:GetAttribute("Creator") then
				v2829 = math.clamp(v2829, 0, 10)
			end
			local v2830
			if p2751["EASING STYLE"] then
				v2830 = Enum.EasingStyle[p2751["EASING STYLE"]]
			else
				v2830 = Enum.EasingStyle.Linear
			end
			local v2831
			if p2751["EASING DIRECTION"] then
				v2831 = Enum.EasingDirection[p2751["EASING DIRECTION"]]
			else
				v2831 = Enum.EasingDirection.In
			end
			local v2832 = v2827(v2829, v2830, v2831)
			local v2833 = {}
			local v2834 = v_u_26(nil, p2751, true).Z
			v2833.StudsOffset = Vector3.new(0, 0, v2834)
			v2826:Create(v2757, v2832, v2833):Play()
			table.insert(v2753, v2757)
		end
	end,
	["Screen Color"] = function(p2835, p2836)
		-- upvalues: (copy) v_u_5, (copy) v_u_70, (copy) v_u_3, (ref) v_u_11
		local v2837 = p2835:FindFirstChild("HumanoidRootPart")
		if v2837 then
			if v_u_5.Character == p2835 then
				local v2838 = v_u_70(v2837, p2836)
				local v2839 = p2836.AMOUNT
				local v2840 = tonumber(v2839)
				if workspace:GetAttribute("Creator") then
					v2840 = math.clamp(v2840, 1, 20)
				end
				local v2841 = p2836.OPACITY
				local v2842 = tonumber(v2841)
				local v2843 = p2836.SIZE
				local v2844 = tonumber(v2843)
				if workspace:GetAttribute("Creator") then
					v2844 = math.clamp(v2844, 0, 40)
				end
				local v2845 = Color3.fromRGB
				local v2846 = string.split
				local v2847 = p2836.COLOR
				local v2848 = v2845(unpack(v2846(v2847)))
				local v2849 = Color3.fromRGB
				local v2850 = string.split
				local v2851 = p2836["ALT COLOR"]
				local v2852 = v2849(unpack(v2850(v2851)))
				local v2853 = p2836.TIME
				local v2854 = tonumber(v2853)
				if workspace:GetAttribute("Creator") then
					v2854 = math.clamp(v2854, 0, 10)
				end
				if workspace:GetAttribute("Creator") then
					v2854 = math.clamp(v2854, 0, 10)
				end
				local v2855 = Instance.new("ColorCorrectionEffect")
				v2855.Parent = game.Lighting
				v2855.Brightness = v2840
				v2855.Saturation = v2842
				v2855.Contrast = v2844
				v2855.TintColor = v2848
				local v2856 = v_u_3
				local v2857 = TweenInfo.new(v2854)
				local v2858 = {}
				local v2859 = p2836["ALT OPACITY"]
				v2858.Saturation = tonumber(v2859)
				local v2860 = p2836.SIZE
				local v2861 = tonumber(v2860)
				if workspace:GetAttribute("Creator") then
					v2861 = math.clamp(v2861, 0, 40)
				end
				local v2862 = p2836["ALT SIZE"] or 1
				local v2863 = v2861 * tonumber(v2862)
				if workspace:GetAttribute("Creator") then
					v2863 = math.clamp(v2863, 0, 40)
				end
				v2858.Contrast = v2863
				v2858.TintColor = v2852
				v2856:Create(v2855, v2857, v2858):Play()
				v_u_11:AddItem(v2855, v2854)
				table.insert(v2838, v2855)
			end
		end
	end,
	["Overlay"] = function(p2864, p2865)
		-- upvalues: (copy) v_u_5, (copy) v_u_70, (copy) v_u_1, (ref) v_u_11, (copy) v_u_3
		local v2866 = p2864:FindFirstChild("HumanoidRootPart")
		if v2866 then
			if v_u_5.Character == p2864 then
				v_u_70(v2866, p2865)
				local v2867 = p2865.TEXTURE or 0
				local v2868 = tonumber(v2867)
				if v2868 == 0 then
					return
				end
				local v2869 = p2865.TIME
				local v2870 = tonumber(v2869)
				if workspace:GetAttribute("Creator") then
					v2870 = math.clamp(v2870, 0, 10)
				end
				if workspace:GetAttribute("Creator") then
					v2870 = math.clamp(v2870, 0, 10)
				end
				local v2871 = v_u_1.Parent.Todo.Woah:Clone()
				v2871.ImageLabel.Image = "rbxassetid://" .. v2868
				v2871.ImageLabel.AnchorPoint = Vector2.new(0.5, 0.5)
				v2871.ImageLabel.Position = UDim2.fromScale(0.5, 0.5)
				local v2872 = v2871.ImageLabel
				local v2873 = UDim2.fromScale
				local v2874 = p2865.SIZE
				local v2875 = tonumber(v2874)
				if workspace:GetAttribute("Creator") then
					v2875 = math.clamp(v2875, 0, 40)
				end
				local v2876 = p2865.SIZE
				local v2877 = tonumber(v2876)
				if workspace:GetAttribute("Creator") then
					v2877 = math.clamp(v2877, 0, 40)
				end
				v2872.Size = v2873(v2875, v2877)
				local v2878 = v2871.ImageLabel
				local v2879 = p2865.OPACITY
				v2878.ImageTransparency = tonumber(v2879)
				local v2880 = v2871.ImageLabel
				local v2881 = Color3.fromRGB
				local v2882 = string.split
				local v2883 = p2865.COLOR
				v2880.ImageColor3 = v2881(unpack(v2882(v2883)))
				v2871.Parent = v_u_5.PlayerGui
				v_u_11:AddItem(v2871, v2870)
				local v2884 = v_u_3
				local v2885 = v2871.ImageLabel
				local v2886 = TweenInfo.new(v2870)
				local v2887 = {}
				local v2888 = Color3.fromRGB
				local v2889 = string.split
				local v2890 = p2865["ALT COLOR"]
				v2887.ImageColor3 = v2888(unpack(v2889(v2890)))
				local v2891 = p2865["ALT OPACITY"]
				v2887.ImageTransparency = tonumber(v2891)
				local v2892 = UDim2.fromScale
				local v2893 = p2865.SIZE
				local v2894 = tonumber(v2893)
				if workspace:GetAttribute("Creator") then
					v2894 = math.clamp(v2894, 0, 40)
				end
				local v2895 = p2865["ALT SIZE"] or 1
				local v2896 = v2894 * tonumber(v2895)
				if workspace:GetAttribute("Creator") then
					v2896 = math.clamp(v2896, 0, 40)
				end
				local v2897 = p2865.SIZE
				local v2898 = tonumber(v2897)
				if workspace:GetAttribute("Creator") then
					v2898 = math.clamp(v2898, 0, 40)
				end
				local v2899 = p2865["ALT SIZE"] or 1
				local v2900 = v2898 * tonumber(v2899)
				if workspace:GetAttribute("Creator") then
					v2900 = math.clamp(v2900, 0, 40)
				end
				v2887.Size = v2892(v2896, v2900)
				v2884:Create(v2885, v2886, v2887):Play()
			end
		end
	end,
	["Field of View"] = function(p2901, p2902)
		-- upvalues: (copy) v_u_5, (copy) v_u_3
		if v_u_5.Character == p2901 then
			local v2903 = p2902.AMOUNT
			local v2904 = 69 + tonumber(v2903)
			if workspace:GetAttribute("Creator") then
				v2904 = math.clamp(v2904, 50, 120)
			end
			local v2905 = v_u_3
			local v2906 = workspace.CurrentCamera
			local v2907 = TweenInfo.new
			local v2908 = p2902.TIME
			local v2909 = tonumber(v2908)
			if workspace:GetAttribute("Creator") then
				v2909 = math.clamp(v2909, 0, 10)
			end
			local v2910
			if p2902["EASING STYLE"] then
				v2910 = Enum.EasingStyle[p2902["EASING STYLE"]]
			else
				v2910 = Enum.EasingStyle.Linear
			end
			local v2911
			if p2902["EASING DIRECTION"] then
				v2911 = Enum.EasingDirection[p2902["EASING DIRECTION"]]
			else
				v2911 = Enum.EasingDirection.In
			end
			v2905:Create(v2906, v2907(v2909, v2910, v2911), {
				["FieldOfView"] = v2904
			}):Play()
		end
	end
}