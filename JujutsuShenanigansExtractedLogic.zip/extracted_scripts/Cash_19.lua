-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "cash",
	["Description"] = "Sets the player\'s cash to the value specified",
	["Group"] = { "Owner", "Developer", "HeadMod" },
	["Args"] = {
		{
			["Type"] = "player",
			["Name"] = "Player"
		},
		{
			["Type"] = "number",
			["Name"] = "Value"
		}
	}
}
return v1