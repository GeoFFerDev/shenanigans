-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Lighting")
local _ = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v6 = v5.Animations
local v7 = v5.Utils
local _ = v5.Sounds
require(v5.Modules.CameraShaker)
local v8 = require(v5.Modules.SraikoVFX)
require(v5.TEMP_CHARA_STUFF.VelocityHandler)
local v_u_9 = require(v5.TEMP_CHARA_STUFF.AnimationRetriever)
local v_u_10 = require(v5.TEMP_CHARA_STUFF.EffectUtility)
local v_u_11 = require(v5.TEMP_CHARA_STUFF.CameraShake)
local v_u_12 = require(v5.TEMP_CHARA_STUFF.Vignette)
require(v5.TEMP_CHARA_STUFF.RockHandler)
require(v5.TEMP_CHARA_STUFF.Smoke)
local v_u_13 = require(v5.TEMP_CHARA_STUFF.Afterimage)
local v_u_14 = require(v5.TEMP_CHARA_STUFF.MoonUtil)
local v_u_15 = require(v5.TEMP_CHARA_STUFF.RunCameraRig)
local v_u_16 = require(v5.TEMP_CHARA_STUFF.Create_Clone)
local _ = v8.Enabled
local _ = v8.Emit
local v_u_17 = v8.EmitMesh
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v21 = v_u_1.CreateController({
	["Name"] = "BloodyMaryController"
})
local v_u_22 = v6.Misc.C.BloodyMary
local v_u_23 = game:GetService("Players").LocalPlayer
local _ = v7.Misc.C.Chara
local v_u_24 = script.StartupVFX
local v_u_25 = script.HitVFX
local v_u_26 = v_u_10.Distance_Close
local v_u_27 = script.Assets
function v21.KnitStart(_)
	-- upvalues: (copy) v_u_9, (copy) v_u_22, (copy) v_u_10, (copy) v_u_25, (copy) v_u_3, (copy) v_u_26, (copy) v_u_11, (copy) v_u_13, (copy) v_u_12, (copy) v_u_2, (copy) v_u_24, (copy) v_u_23, (copy) v_u_16, (copy) v_u_27, (copy) v_u_15, (copy) v_u_4, (copy) v_u_14, (copy) v_u_17, (ref) v_u_18
	local v_u_165 = {
		["Hit"] = function(p_u_28, p_u_29)
			-- upvalues: (ref) v_u_9, (ref) v_u_22, (ref) v_u_10, (ref) v_u_25, (ref) v_u_3, (ref) v_u_26, (ref) v_u_11, (ref) v_u_13, (ref) v_u_12
			local v30 = v_u_9.new(p_u_28, v_u_22.Hit)
			if v30 ~= nil then
				local v31 = v30.Torso
				local v_u_32 = v30.RootPart
				local v33 = v30.Animation
				local v_u_34 = v30.Job
				local v_u_35 = p_u_28.SetAssets:FindFirstChild("RealKnife")
				script.ConnectSFX.PlaybackSpeed = v33.Speed
				v_u_34:Task(v_u_10.AddSFX(script.ConnectSFX, v31, 0.6))
				v_u_34:Task(function()
					-- upvalues: (copy) v_u_35
					if v_u_35 then
						v_u_35.Handle.BladeAttachment.Trail.Enabled = false
					end
				end)
				local function v_u_37(p36)
					-- upvalues: (copy) v_u_35
					if v_u_35 then
						v_u_35.Handle.BladeAttachment.Trail.Enabled = p36
					end
				end
				local v_u_38 = v_u_25.spin:Clone()
				v_u_10.Weld(v_u_38, p_u_28.Torso)
				v_u_38.Parent = workspace.Effects
				local v_u_39 = v_u_25.flick:Clone()
				if v_u_35 then
					v_u_10.Weld(v_u_39, v_u_35.BladeInner)
					v_u_39.Parent = workspace.Effects
				end
				v_u_34:Task(v_u_38)
				v_u_34:Task(v_u_39)
				v_u_34:Task(v33:GetMarkerReachedSignal("spin"):Connect(function(p40)
					-- upvalues: (ref) v_u_10, (copy) v_u_38
					v_u_10.Toggle(v_u_38, p40 == "true")
				end))
				v_u_34:Task(v33:GetMarkerReachedSignal("flick"):Connect(function()
					-- upvalues: (copy) v_u_35, (copy) v_u_37, (ref) v_u_3, (ref) v_u_26, (copy) p_u_28, (ref) v_u_11, (ref) v_u_13, (ref) v_u_10, (copy) v_u_39
					if v_u_35 then
						v_u_35.Handle.BladeAttachment.Trail.Enabled = true
					end
					task.delay(1, v_u_37, false)
					local v_u_41 = { 0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out }
					local v_u_42 = { 0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.Out }
					local function v_u_47(p43)
						-- upvalues: (ref) v_u_3, (copy) v_u_41, (ref) v_u_26, (ref) p_u_28, (ref) v_u_11
						local v_u_44 = Instance.new("Highlight")
						v_u_44.FillColor = Color3.fromRGB(161, 45, 16)
						v_u_44.OutlineColor = Color3.new(0, 0, 0)
						v_u_44.FillTransparency = -10
						v_u_44.OutlineTransparency = 1
						v_u_44.Parent = p43
						local v45 = v_u_41
						local v46 = v_u_3:Create(v_u_44, TweenInfo.new(table.unpack(v45)), {
							["FillTransparency"] = 1,
							["OutlineTransparency"] = 1
						})
						v46:Play()
						v46.Completed:Once(function()
							-- upvalues: (copy) v_u_44
							v_u_44:Destroy()
						end)
						if v_u_26(p_u_28) then
							v_u_11(0.75, 20, 0.01, 0.2, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
						end
					end
					task.spawn(function()
						-- upvalues: (ref) v_u_13, (ref) p_u_28, (copy) v_u_41, (copy) v_u_42, (copy) v_u_47
						for _ = 1, 5 do
							v_u_13(p_u_28, v_u_41, v_u_42, 2, v_u_47)
							task.wait(0.13)
						end
					end)
					v_u_10.Emit(v_u_39, true)
				end))
				local v_u_48 = v_u_25.kneehit:Clone()
				v_u_34:Task(v_u_48)
				local v_u_49 = nil
				v_u_34:Task(v33:GetMarkerReachedSignal("knee"):Connect(function(p50)
					-- upvalues: (copy) v_u_48, (copy) v_u_32, (ref) v_u_10, (ref) v_u_3, (ref) v_u_26, (copy) p_u_28, (ref) v_u_49, (copy) v_u_34, (ref) v_u_11, (ref) v_u_12, (ref) v_u_25
					if p50 == "true" then
						v_u_48:PivotTo(v_u_32.CFrame * v_u_48.CFrame - Vector3.new(0, 3, 0))
						v_u_48.Parent = workspace.Effects
						v_u_10.Emit(v_u_48, true)
						for _, v51 in pairs(v_u_48.slow:QueryDescendants("ParticleEmitter")) do
							local v_u_52 = v_u_3:Create(v51, TweenInfo.new(0.1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
								["TimeScale"] = 0
							})
							v_u_52:Play()
							task.spawn(function()
								-- upvalues: (copy) v_u_52
								v_u_52.Completed:Wait()
								v_u_52:Destroy()
							end)
						end
						if v_u_26(p_u_28) then
							v_u_49 = v_u_34:Task(v_u_11(1.5, 25, 0.025, 0, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.1, 0.1, 0.1)))
							v_u_12(Color3.fromRGB(255, 0, 0), 0.5, 0.6)
							return
						end
					elseif p50 == "false" then
						for _, v53 in pairs(v_u_48.slow:QueryDescendants("ParticleEmitter")) do
							local v_u_54 = v_u_3:Create(v53, TweenInfo.new(0.1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
								["TimeScale"] = 1
							})
							v_u_54:Play()
							task.spawn(function()
								-- upvalues: (copy) v_u_54, (ref) v_u_48
								v_u_54.Completed:Wait()
								v_u_54:Destroy()
								v_u_48:Destroy()
							end)
						end
						local v55 = v_u_25.kneehit_end
						local v56 = v_u_32.CFrame * (v55.CFrame - Vector3.new(0, 3, 0))
						local v57 = v55:Clone()
						v57:PivotTo(v56)
						v57.Parent = workspace.Effects
						v_u_10.Emit(v57)
						if v_u_49 then
							v_u_49:StartFadeOut(0.05)
						end
						if v_u_26(p_u_28) then
							v_u_11(2, 20, 0.01, 0.3, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
							v_u_12(Color3.fromRGB(255, 0, 0), 0.35, 0.35)
						end
					end
				end))
				local v_u_58 = v_u_25.finalhit:Clone()
				v_u_34:Task(v_u_58)
				local v_u_59 = nil
				v_u_34:Task(v33:GetMarkerReachedSignal("finalhit"):Connect(function(p60)
					-- upvalues: (copy) v_u_58, (copy) v_u_32, (ref) v_u_10, (ref) v_u_3, (ref) v_u_26, (copy) p_u_28, (ref) v_u_59, (copy) v_u_34, (ref) v_u_11, (ref) v_u_12, (ref) v_u_25, (copy) v_u_35
					if p60 == "true" then
						v_u_58:PivotTo(v_u_32.CFrame * v_u_58.CFrame - Vector3.new(0, 3, 0))
						v_u_58.Parent = workspace.Effects
						v_u_10.Emit(v_u_58, true)
						for _, v61 in pairs(v_u_58.slow:QueryDescendants("ParticleEmitter")) do
							local v_u_62 = v_u_3:Create(v61, TweenInfo.new(0.1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
								["TimeScale"] = 0.005
							})
							v_u_62:Play()
							task.spawn(function()
								-- upvalues: (copy) v_u_62
								v_u_62.Completed:Wait()
								v_u_62:Destroy()
							end)
						end
						if v_u_26(p_u_28) then
							v_u_59 = v_u_34:Task(v_u_11(1, 22.5, 0.01, 0, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.1, 0.1, 0.1)))
							v_u_12(Color3.fromRGB(255, 0, 0), 0.5, 0.6)
							return
						end
					elseif p60 == "false" then
						if v_u_59 then
							v_u_59:StartFadeOut(0.05)
						end
						if v_u_26(p_u_28) then
							v_u_11(3, 25, 0.01, 0.4, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
							v_u_12(Color3.fromRGB(255, 0, 0), 0.35, 0.35)
						end
						for _, v63 in pairs(v_u_58.slow:QueryDescendants("ParticleEmitter")) do
							local v_u_64 = v_u_3:Create(v63, TweenInfo.new(0.1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
								["TimeScale"] = 1
							})
							v_u_64:Play()
							task.spawn(function()
								-- upvalues: (copy) v_u_64, (ref) v_u_58
								v_u_64.Completed:Wait()
								v_u_64:Destroy()
								v_u_58:Destroy()
							end)
						end
						local v65 = v_u_25.finalhit_end
						local v66 = v_u_32.CFrame * (v65.CFrame - Vector3.new(0, 3, 0))
						local v67 = v65:Clone()
						v67:PivotTo(v66)
						v67.Parent = workspace.Effects
						v_u_10.Emit(v67)
						if v_u_35 then
							v_u_35.Handle.BladeAttachment.Trail.Enabled = true
						end
					end
				end))
				v_u_34:Task(v33:GetMarkerReachedSignal("slash"):Once(function()
					-- upvalues: (ref) v_u_25, (copy) v_u_32, (ref) v_u_10, (ref) v_u_26, (copy) p_u_28, (ref) v_u_11
					local v68 = v_u_25.slash
					local v69 = v_u_32.CFrame * (v68.CFrame - Vector3.new(0, 3, 0))
					local v70 = v68:Clone()
					v70:PivotTo(v69)
					v70.Parent = workspace.Effects
					v_u_10.Emit(v70)
					local v71 = v_u_25.slash_hit
					local v72 = v_u_32.CFrame * (v71.CFrame - Vector3.new(0, 3, 0))
					local v73 = v71:Clone()
					v73:PivotTo(v72)
					v73.Parent = workspace.Effects
					v_u_10.Emit(v73)
					if v_u_26(p_u_28) then
						v_u_11(1.75, 25, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
					end
				end))
				v_u_34:Task(v33:GetMarkerReachedSignal("kick"):Once(function()
					-- upvalues: (ref) v_u_25, (copy) v_u_32, (ref) v_u_10, (ref) v_u_26, (copy) p_u_28, (ref) v_u_11
					local v74 = v_u_25.kick
					local v75 = v_u_32.CFrame * (v74.CFrame - Vector3.new(0, 3, 0))
					local v76 = v74:Clone()
					v76:PivotTo(v75)
					v76.Parent = workspace.Effects
					v_u_10.Emit(v76)
					if v_u_26(p_u_28) then
						v_u_11(1.75, 25, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
					end
				end))
				v_u_34:Task(v33:GetMarkerReachedSignal("teleport"):Once(function()
					-- upvalues: (ref) v_u_25, (copy) v_u_32, (ref) v_u_10
					local v77 = v_u_25.teleport
					local v78 = v_u_32.CFrame * (v77.CFrame - Vector3.new(0, 3, 0))
					local v79 = v77:Clone()
					v79:PivotTo(v78)
					v79.Parent = workspace.Effects
					v_u_10.Emit(v79)
				end))
				v_u_34:Task(v33:GetMarkerReachedSignal("stab"):Once(function()
					-- upvalues: (ref) v_u_25, (copy) v_u_32, (ref) v_u_10, (ref) v_u_26, (copy) p_u_28, (ref) v_u_11, (ref) v_u_12
					local v80 = v_u_25.stab
					local v81 = v_u_32.CFrame * (v80.CFrame - Vector3.new(0, 3, 0))
					local v82 = v80:Clone()
					v82:PivotTo(v81)
					v82.Parent = workspace.Effects
					v_u_10.Emit(v82)
					local _ = v81.Position
					if v_u_26(p_u_28) then
						v_u_11(2.5, 25, 0.01, 0.5, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
						v_u_12(Color3.fromRGB(255, 0, 0), 0.35, 0.35)
					end
				end))
				task.spawn(function()
					-- upvalues: (copy) p_u_29, (ref) v_u_9, (ref) v_u_22, (ref) v_u_25, (copy) v_u_32, (ref) v_u_10
					if p_u_29 and p_u_29.Parent then
						local v83 = v_u_9.new(p_u_29, v_u_22.Victim)
						if v83 ~= nil then
							local v84 = v83.Animation
							v83.Job:Task(v84:GetMarkerReachedSignal("land"):Connect(function(p85)
								-- upvalues: (ref) v_u_25, (ref) v_u_32, (ref) v_u_10
								local v86 = v_u_25.Lands[p85]
								local v87 = v_u_32.CFrame * (v86.CFrame - Vector3.new(0, 3, 0))
								local v88 = v86:Clone()
								v88:PivotTo(v87)
								v88.Parent = workspace.Effects
								v_u_10.Emit(v88)
							end))
						end
					end
				end)
			end
		end,
		["Dropkick"] = function(p89)
			-- upvalues: (ref) v_u_10
			if p89 and p89.Parent then
				v_u_10.AddSFX(script.DropkickSFX, p89.PrimaryPart)
			end
		end,
		["Start"] = function(p90)
			-- upvalues: (ref) v_u_9, (ref) v_u_22, (ref) v_u_10, (ref) v_u_2, (ref) v_u_24
			local v91 = v_u_9.new(p90, v_u_22.Windup)
			if v91 ~= nil then
				local v92 = v91.Torso
				local v_u_93 = v91.RootPart
				local v94 = v91.Animation
				local v_u_95 = v91.Job
				local v_u_96 = p90.SetAssets:FindFirstChild("RealKnife")
				local function v_u_98(p97)
					-- upvalues: (copy) v_u_96
					if v_u_96 and v_u_96.Parent then
						v_u_96.Handle.BladeAttachment.Trail.Enabled = p97
					end
				end
				if v_u_96 then
					v_u_95:Task(function()
						-- upvalues: (copy) v_u_96
						if v_u_96 and v_u_96.Parent then
							v_u_96.Handle.BladeAttachment.Trail.Enabled = false
						end
					end)
				end
				script.StartupSFX.PlaybackSpeed = v94.Speed
				v_u_95:Task(v_u_10.AddSFX(script.StartupSFX, v92, 0.3))
				local v_u_99 = 0
				local v100 = v_u_93:FindFirstChildOfClass("BodyVelocity")
				if v100 then
					v100:Destroy()
				end
				local v_u_101 = Instance.new("BodyVelocity")
				v_u_101.MaxForce = Vector3.new(80000, 0, 80000)
				v_u_101.Parent = v_u_93
				local v_u_102 = nil
				v_u_102 = v_u_2.PostSimulation:Connect(function()
					-- upvalues: (copy) v_u_101, (ref) v_u_102, (copy) v_u_93, (ref) v_u_99
					if v_u_101.Parent then
						v_u_101.Velocity = v_u_93.CFrame.LookVector * v_u_99
					else
						v_u_102:Disconnect()
					end
				end)
				local v_u_103 = nil
				v_u_103 = v_u_2.PreSimulation:Connect(function(p104)
					-- upvalues: (copy) v_u_101, (ref) v_u_103, (ref) v_u_99
					if v_u_101.Parent then
						if v_u_99 <= -25 then
							v_u_103:Disconnect()
						else
							v_u_99 = v_u_99 - p104 * 60 * 2
						end
					else
						v_u_103:Disconnect()
						return
					end
				end)
				v_u_95:Task(v_u_101)
				v_u_95:Task(v94:GetMarkerReachedSignal("kick"):Connect(function()
					-- upvalues: (ref) v_u_99, (copy) v_u_95, (ref) v_u_2, (copy) v_u_101, (ref) v_u_24, (copy) v_u_93, (ref) v_u_10
					v_u_99 = v_u_99 * 1.75
					v_u_95:Task(task.delay(0.4, function()
						-- upvalues: (ref) v_u_2, (ref) v_u_101, (ref) v_u_99
						local v_u_105 = nil
						v_u_105 = v_u_2.PreSimulation:Connect(function(p106)
							-- upvalues: (ref) v_u_101, (ref) v_u_105, (ref) v_u_99
							if v_u_101.Parent then
								if v_u_99 < 0 then
									local v107 = v_u_99 + p106 * 60 * 1.3
									v_u_99 = math.clamp(v107, -52.5, 0)
								else
									v_u_105:Disconnect()
								end
							else
								v_u_105:Disconnect()
								return
							end
						end)
					end))
					local v108 = v_u_24.dropkick
					local v109 = v108.CFrame - Vector3.new(0, 3, 0)
					local v110 = v108:Clone()
					v110.CFrame = v_u_93.CFrame * v109
					v110.Parent = workspace.Effects
					v_u_10.Emit(v110)
				end))
				v_u_95:Task(v94:GetMarkerReachedSignal("land"):Connect(function()
					-- upvalues: (ref) v_u_24, (copy) v_u_93, (ref) v_u_10, (copy) v_u_96
					local v111 = v_u_24.land
					local v112 = v111.CFrame - Vector3.new(0, 3, 0)
					local v113 = v111:Clone()
					v113.CFrame = v_u_93.CFrame * v112
					v113.Parent = workspace.Effects
					v_u_10.Emit(v113)
					if v_u_96 and v_u_96.Parent then
						v_u_96.Handle.BladeAttachment.Trail.Enabled = true
					end
				end))
				v_u_95:Task(v94:GetMarkerReachedSignal("dash"):Connect(function()
					-- upvalues: (ref) v_u_24, (copy) v_u_93, (ref) v_u_10, (ref) v_u_99, (ref) v_u_2, (copy) v_u_101
					local v114 = v_u_24.dash
					local v115 = v114.CFrame - Vector3.new(0, 3, 0)
					local v116 = v114:Clone()
					v116.CFrame = v_u_93.CFrame * v115
					v116.Parent = workspace.Effects
					v_u_10.Emit(v116)
					v_u_99 = 100
					local v_u_117 = nil
					v_u_117 = v_u_2.PreSimulation:Connect(function(p118)
						-- upvalues: (ref) v_u_101, (ref) v_u_117, (ref) v_u_99
						if v_u_101.Parent then
							local v119 = v_u_99 - p118 * 60 * 0.85
							v_u_99 = math.clamp(v119, 0, 52.5)
						else
							v_u_117:Disconnect()
						end
					end)
				end))
				v_u_95:Task(v94:GetMarkerReachedSignal("hit"):Connect(function()
					-- upvalues: (ref) v_u_24, (copy) v_u_93, (ref) v_u_10, (copy) v_u_98
					local v120 = v_u_24.slash
					local v121 = v120.CFrame - Vector3.new(0, 3, 0)
					local v122 = v120:Clone()
					v122.CFrame = v_u_93.CFrame * v121
					v_u_10.Weld(v122, v_u_93, v121)
					v122.Parent = workspace.Effects
					v_u_10.Emit(v122)
					task.delay(0.4, v_u_98, false)
				end))
				local v_u_123 = v_u_24.spin:Clone()
				v_u_10.Weld(v_u_123, p90.Torso)
				v_u_123.Parent = workspace.Effects
				local v_u_124 = v_u_24.head:Clone()
				v_u_10.Weld(v_u_124, p90.Head)
				v_u_124.Parent = workspace.Effects
				local v_u_125 = v_u_24.flick:Clone()
				if v_u_96 then
					v_u_10.Weld(v_u_125, v_u_96.BladeInner)
					v_u_125.Parent = workspace.Effects
				end
				v_u_95:Task(v_u_123)
				v_u_95:Task(v_u_124)
				v_u_95:Task(v_u_125)
				v_u_95:Task(v94:GetMarkerReachedSignal("spin"):Connect(function(p126)
					-- upvalues: (ref) v_u_10, (copy) v_u_123, (copy) v_u_96
					v_u_10.Toggle(v_u_123, p126 == "true")
					local v127 = p126 == "true"
					if v_u_96 and v_u_96.Parent then
						v_u_96.Handle.BladeAttachment.Trail.Enabled = v127
					end
				end))
				v_u_95:Task(v94:GetMarkerReachedSignal("eye"):Connect(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_124
					v_u_10.Emit(v_u_124, true)
				end))
				v_u_95:Task(v94:GetMarkerReachedSignal("flick"):Connect(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_125
					v_u_10.Emit(v_u_125, true)
				end))
			end
		end,
		["FinisherStart"] = function(p_u_128, p_u_129)
			-- upvalues: (ref) v_u_9, (ref) v_u_22, (ref) v_u_23, (ref) v_u_16, (ref) v_u_27, (ref) v_u_10, (ref) v_u_15, (ref) v_u_4, (ref) v_u_14, (ref) v_u_17
			local v130 = v_u_9.new(p_u_128, v_u_22.Finisher)
			if v130 ~= nil then
				local v_u_131 = v130.Animation
				local v_u_132 = v130.Job
				local v_u_133 = v130.RootPart
				local v134 = v130.Torso
				local v135 = table.find({ p_u_128, p_u_129 }, v_u_23.Character) ~= nil
				local v_u_136, v137, _ = v_u_16(p_u_128, true)
				v_u_132:Task(v_u_136)
				for _, v138 in ipairs(v_u_136:GetDescendants()) do
					if v138:IsA("BasePart") or v138:IsA("Decal") then
						v138.Transparency = 1
					end
				end
				for _, v139 in ipairs(v_u_27.Clone_VFX.Aura:GetChildren()) do
					for _, v140 in ipairs(v139:GetChildren()) do
						v140:Clone().Parent = v_u_136[v139.Name]
					end
				end
				local v141 = v_u_132:Task(Instance.new("Highlight"))
				v141.DepthMode = Enum.HighlightDepthMode.Occluded
				v141.FillColor = Color3.fromRGB(38, 82, 98)
				v141.FillTransparency = 5
				v141.OutlineColor = Color3.fromRGB(234, 0, 0)
				v141.OutlineTransparency = 0
				v141.Parent = v_u_136
				v_u_136.Parent = workspace.Effects
				local v142 = v137.Animator:LoadAnimation(v_u_22.FinisherClone)
				v142:Play(0, nil, v_u_131.Speed)
				v142.Stopped:Once(function()
					-- upvalues: (copy) v_u_136
					v_u_136:Destroy()
				end)
				v_u_132:Task(v_u_131:GetMarkerReachedSignal("clone"):Connect(function()
					-- upvalues: (copy) v_u_136
					for _, v143 in ipairs(v_u_136:GetDescendants()) do
						if v143:IsA("BasePart") and v143.Name ~= "HumanoidRootPart" or v143:IsA("Decal") and v143.Name ~= "Face" then
							v143.Transparency = 0
						elseif v143:IsA("ParticleEmitter") then
							v143.Enabled = true
							v143:Emit(1)
						end
					end
				end))
				v_u_132:Task(v_u_131:GetMarkerReachedSignal("clone_eye"):Connect(function(_)
					-- upvalues: (ref) v_u_10, (ref) v_u_27, (copy) v_u_136
					v_u_10.Arc.CloneAndEmit(v_u_27.Clone_VFX.eye, v_u_136.Head)
				end))
				if v135 then
					local v144 = v_u_132:Task(v_u_27.FinisherSFX:Clone())
					v144.Parent = workspace
					v144.PlaybackSpeed = v_u_131.Speed
					v144:Play()
					v_u_132:Task(v_u_131:GetMarkerReachedSignal("camera"):Connect(function()
						-- upvalues: (copy) v_u_132, (ref) v_u_27, (ref) v_u_23, (copy) v_u_131, (ref) v_u_10, (copy) v_u_133, (ref) v_u_22, (ref) v_u_15, (ref) v_u_4, (ref) v_u_14
						local v_u_145 = v_u_132
						local v_u_146 = v_u_145:Task(v_u_27.ScreenCover:Clone())
						v_u_146.Enabled = true
						v_u_146.Parent = v_u_23.PlayerGui
						v_u_145:Task(v_u_131:GetMarkerReachedSignal("camera_cover"):Connect(function(p147)
							-- upvalues: (copy) v_u_146
							v_u_146.Frame.BackgroundTransparency = p147 == "true" and 0 or 1
						end))
						local v_u_148 = v_u_27.Camera:Clone()
						v_u_10.Weld(v_u_148.PrimaryPart, v_u_133)
						v_u_148.Parent = workspace.Effects
						local v149 = v_u_148.Humanoid.Animator:LoadAnimation(v_u_22.FinisherCamera)
						v149.Stopped:Once(function()
							-- upvalues: (copy) v_u_145
							v_u_145:Destroy()
						end)
						v149:Play(0, nil, v_u_131.Speed)
						v_u_145:Task(v_u_15(v_u_133, v_u_148))
						local v_u_150 = v_u_4.ExposureCompensation
						v_u_145:Task(function()
							-- upvalues: (ref) v_u_4, (copy) v_u_150
							task.defer(function()
								-- upvalues: (ref) v_u_4, (ref) v_u_150
								workspace.CurrentCamera.FieldOfView = 70
								v_u_4.ExposureCompensation = v_u_150
							end)
						end)
						v_u_145:Task(v_u_14.AnimateValueWithMoonFile(v_u_4, "ExposureCompensation", v_u_27.ExposureCompensation))
						v_u_145:Task(v_u_131:GetMarkerReachedSignal("camera_light"):Once(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_148
							v_u_10.Arc.EmitAndToggle(v_u_148.camera:FindFirstChild("1a"), v_u_148.camera, 0)
						end))
						v_u_145:Task(v_u_146)
						v_u_145:Task(v_u_148)
					end))
					v_u_132:Task(v_u_131:GetMarkerReachedSignal("bg"):Once(function()
						-- upvalues: (copy) v_u_132, (ref) v_u_27, (copy) v_u_133, (ref) v_u_10
						local v151 = v_u_132:Task(v_u_27.BackGround:Clone())
						v151.Join.Part0 = v_u_133
						v151.Parent = workspace.Effects
						v_u_10.Arc.EmitAttachment(v151)
						v_u_10.Arc.ToggleAttachment(v151, true, 3)
						v_u_132:Task(task.delay(3, v151.Destroy, v151))
					end))
				else
					local v152 = v_u_132:Task(v_u_27.FinisherSFX:Clone())
					v152.Parent = v134
					v152.PlaybackSpeed = v_u_131.Speed
					v152:Play()
				end
				v_u_132:Task(v_u_131:GetMarkerReachedSignal("eye"):Connect(function(_)
					-- upvalues: (ref) v_u_10, (ref) v_u_27, (copy) p_u_128
					v_u_10.Arc.CloneAndEmit(v_u_27.VFX.eye, p_u_128.Head)
				end))
				v_u_132:Task(v_u_131:GetMarkerReachedSignal("vfx"):Connect(function(p153)
					-- upvalues: (ref) v_u_27, (ref) v_u_10, (copy) v_u_133
					local v154 = v_u_27.VFX:FindFirstChild(p153)
					if v154 then
						v_u_10.Arc.CloneAndEmit(v154, v_u_133)
					end
				end))
				v_u_132:Task(v_u_131:GetMarkerReachedSignal("zapping"):Once(function()
					-- upvalues: (ref) v_u_10, (ref) v_u_27, (copy) p_u_128
					v_u_10.Arc.EmitAndToggle(v_u_27.VFX.zapping, p_u_128.Torso, 0.5)
				end))
				v_u_132:Task(v_u_131:GetMarkerReachedSignal("knife_vfx"):Connect(function(p155)
					-- upvalues: (copy) v_u_133, (ref) v_u_27, (ref) v_u_10
					local v156 = v_u_133.Parent:FindFirstChild("Knife")
					local v157 = v_u_27.KnifeVFX:FindFirstChild(p155)
					if v156 and v157 then
						v_u_10.Arc.CloneAndEmit(v157, v156:FindFirstChild("BladeInner"))
					end
				end))
				v_u_132:Task(v_u_131:GetMarkerReachedSignal("cut_neck"):Once(function()
					-- upvalues: (copy) p_u_129, (ref) v_u_10, (ref) v_u_27
					if p_u_129 and p_u_129:FindFirstChild("Torso") then
						v_u_10.Arc.EmitAndToggle(v_u_27.VictimVFX["1"], p_u_129.Torso, 0.5)
					end
				end))
				local v_u_158 = {}
				for _, v159 in v_u_27.Beams:GetChildren() do
					local v160 = v_u_132:Task(v159:Clone())
					v160.Join.Part0 = v_u_133
					v160.Parent = workspace.Effects
					v_u_158[("%*"):format(v160.Name)] = v160
				end
				v_u_132:Task(v_u_131:GetMarkerReachedSignal("beam"):Connect(function(p161)
					-- upvalues: (copy) v_u_158, (ref) v_u_10
					local v162 = v_u_158[("%*"):format(p161)]
					if v162 then
						v_u_10.Arc.TweenBeamTransparency(v162, {
							["transparency"] = 1,
							["duration"] = 1.5,
							["speed"] = 0,
							["beamEasingStyle"] = Enum.EasingStyle.Sine,
							["beamEasingDirection"] = Enum.EasingDirection.Out
						})
					end
				end))
				v_u_132:Task(v_u_131:GetMarkerReachedSignal("mesh"):Connect(function(p163)
					-- upvalues: (ref) v_u_27, (ref) v_u_17, (copy) v_u_133
					local v164 = v_u_27.Meshes:FindFirstChild(p163)
					if v164 then
						v_u_17(v164, v_u_133)
					end
				end))
			end
		end
	}
	v_u_18.Effects:Connect(function(p166, ...)
		-- upvalues: (ref) v_u_165
		local v167 = v_u_165[p166]
		if v167 then
			v167(...)
		end
	end)
end
function v21.KnitInit(_)
	-- upvalues: (ref) v_u_18, (copy) v_u_1, (ref) v_u_19, (ref) v_u_20
	v_u_18 = v_u_1.GetService("BloodyMaryService")
	v_u_19 = v_u_1.GetController("HitboxController")
	v_u_20 = v_u_1.GetController("FXController")
end
return v21