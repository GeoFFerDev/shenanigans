-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_3 = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = require(v4.Modules.CameraShaker)
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "DivinePummelController"
})
local v_u_11 = RaycastParams.new()
v_u_11.FilterType = Enum.RaycastFilterType.Include
v_u_11.FilterDescendantsInstances = { workspace.Map, workspace.Spawns, workspace.Domains }
function v10.KnitStart(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_6, (copy) v_u_11, (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_7, (ref) v_u_8
	local v_u_25 = {
		["Swing"] = function(p12)
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_9:PlaySound(v_u_6.Misc.Swing.Fist3, v13, game.SoundService.Effect)
			end
		end,
		["Grab"] = function(p14)
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_9:Flash(p14, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_6.Gojo.LapseBlue.Grab, v15, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p16, p17)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_11, (ref) v_u_5, (ref) v_u_2, (ref) v_u_3, (ref) v_u_7
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_9:Flash(p17, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_6.Gojo.M1:FindFirstChild("Hit3"), v18, game.SoundService.Effect)
				local v19 = p16.Character["Right Arm"]
				local v20 = workspace:Raycast(v19.Position - v19.CFrame.UpVector * 2, Vector3.new(0, -10, 0), v_u_11)
				if v20 then
					local v21 = v_u_5.Itadori.CrushingBlow:Clone()
					v21.Position = v20.Position
					v21.PointLight:Destroy()
					v21.Air:Destroy()
					v21.Parent = workspace.Effects
					v21.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v21.Floor.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v21.Floor.Ring:Emit(10)
					v21.Floor.Sparks:Emit(10)
					v21.Floor.Wind2:Emit(8)
					v_u_2:AddItem(v21, 1.5)
					v_u_9:PlaySound(v_u_6.Itadori.CrushingBlow.GroundImpact, v21, game.SoundService.Effect)
				end
				if v_u_3.Character == p17 or v_u_3 == p16 then
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.HeavyHit)
				end
			end
		end,
		["FinalHit"] = function(p22, p23)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				v_u_9:Flash(p23, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_6.Gojo.M1:FindFirstChild("Hit4"), v24, game.SoundService.Effect)
				if v_u_3.Character == p23 or v_u_3 == p22 then
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_8.Effects:Connect(function(p26, ...)
		-- upvalues: (copy) v_u_25
		local v27 = v_u_25[p26]
		if v27 then
			v27(...)
		end
	end)
end
function v10.KnitInit(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9
	v_u_8 = v_u_1.GetService("DivinePummelService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10