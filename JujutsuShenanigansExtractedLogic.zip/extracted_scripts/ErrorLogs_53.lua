-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Name"] = "ErrorLogs",
	["Description"] = "Get server\'s error logs",
	["Group"] = {
		"Owner",
		"Developer",
		"Tester",
		"TesterPublic"
	},
	["Args"] = {}
}