-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = RaycastParams.new()
v_u_9.FilterType = Enum.RaycastFilterType.Include
v_u_9.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "Mokou2Controller"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (ref) v_u_10, (copy) v_u_9, (ref) v_u_12
	local v_u_34 = {
		["Startup"] = function(p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:PlaySound(v_u_7.Misc.M.Kick, v15, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Misc.M.Mokou2Voice, v15, game.SoundService.Voice)
			end
		end,
		["Dive"] = function(p_u_16, p_u_17)
			-- upvalues: (ref) v_u_6
			local v_u_18 = p_u_16:FindFirstChild("HumanoidRootPart")
			if v_u_18 then
				task.spawn(function()
					-- upvalues: (ref) v_u_6, (copy) p_u_16, (copy) v_u_18, (copy) p_u_17
					local v19 = Instance.new("Model")
					local v20 = v_u_6.Misc.S.Boost:Clone()
					v20.Parent = v19
					v19:ScaleTo(0.5)
					v20.Parent = p_u_16
					v19:Destroy()
					repeat
						v20.CFrame = CFrame.lookAlong(v_u_18.Position, -v_u_18.CFrame.LookVector + v_u_18.CFrame.UpVector) * CFrame.Angles(0, 0, math.random(0, 3.141592653589793))
						task.wait()
					until not p_u_17.Parent and p_u_16.Parent
					v20:Destroy()
				end)
			end
		end,
		["Hit"] = function(p21, p22)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			if v23 then
				v_u_11:Flash(p22, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Mahito.Soulfire.Hit, v23, game.SoundService.Effect)
				local v24 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v24.Parent = v23.RootAttachment
				v24:Emit(20)
				v_u_2:AddItem(v24, 0.4)
				if v_u_4.Character == p22 or v_u_4 == p21 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Crush"] = function(p25, p26)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v27 = v_u_6.Hiromi.Shockwave:Clone()
			v27.Position = p26
			v27.Parent = workspace.Effects
			local v28 = v_u_6.Misc.M.DashHit:Clone()
			v28.Position = p26
			v28.Parent = workspace.Effects
			for _, v29 in v28:GetDescendants() do
				if v29:IsA("ParticleEmitter") then
					v29:Emit(v29:GetAttribute("EmitCount"))
				end
			end
			v_u_2:AddItem(v28, 1)
			local v30 = v_u_6.Misc.M.Slash.PointLight:Clone()
			v30.Parent = v28
			v_u_3:Create(v30, TweenInfo.new(0.6), {
				["Brightness"] = 0,
				["Color"] = Color3.new(1, 0, 0)
			}):Play()
			local v31 = v27.CFrame
			local v32 = CFrame.Angles
			local v33 = math.random(-179, 179)
			v27.CFrame = v31 * v32(0, math.rad(v33), 0)
			v_u_3:Create(v27.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(15, 0, 15)
			}):Play()
			v_u_3:Create(v27.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v27.Floor.Glow:Emit(1)
			v27.Floor.Ring:Emit(10)
			v_u_2:AddItem(v27, 1.5)
			v_u_11:PlaySound(v_u_7.Misc.M.KickHit, v27, game.SoundService.Effect)
			if v_u_4 == p25 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end
	}
	v_u_10.Effects:Connect(function(p35, ...)
		-- upvalues: (copy) v_u_34
		local v36 = v_u_34[p35]
		if v36 then
			v36(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p37, p38, p39)
		-- upvalues: (ref) v_u_9, (ref) v_u_12
		local v40 = p38.HumanoidRootPart
		if not v40 then
			return
		end
		while true do
			local v41 = workspace:Raycast(v40.Position, v40.CFrame.LookVector * 8 - v40.CFrame.UpVector * 8, v_u_9)
			local v42 = v_u_12:SphereHitbox(p38, CFrame.new(0, -5, -5), 8)
			if #v42 > 0 or v41 then
				if #v42 <= 0 then
					v42 = false
				end
				local v43
				if v41 then
					v43 = v41.Position
				else
					v43 = v41
				end
				p39:FireServer(v42, v43)
				if v41 then
					p37:Destroy()
					return
				end
			end
			task.wait(0.025)
			if not p37.Parent then
				return
			end
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("Mokou2Service")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("HitboxController")
end
return v13