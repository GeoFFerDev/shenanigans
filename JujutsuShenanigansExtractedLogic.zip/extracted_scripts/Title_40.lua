-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "title",
	["Description"] = "Adds / Remove a title from a player\'s inventory",
	["Group"] = { "Owner" },
	["Args"] = {
		{
			["Type"] = "username",
			["Name"] = "Username"
		},
		{
			["Type"] = "string",
			["Name"] = "Title"
		},
		{
			["Type"] = "boolean",
			["Name"] = "Clear"
		}
	}
}
return v1