-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

_G.GroupId = 16357742
local v_u_11 = {
	["Owner"] = function(p1)
		return p1.UserId < 0 and true or p1:GetRoleInGroup(_G.GroupId) == "Owner"
	end,
	["Developer"] = function(p2)
		return p2:GetRoleInGroup(_G.GroupId) == "Developers"
	end,
	["HeadMod"] = function(p3)
		return p3:GetRoleInGroup(_G.GroupId) == "Head Moderators"
	end,
	["Mod"] = function(p4)
		return p4:GetRoleInGroup(_G.GroupId) == "Moderators"
	end,
	["Contrib"] = function(p5)
		return p5:GetRoleInGroup(_G.GroupId) == "Contributors"
	end,
	["Tester"] = function(p6)
		local v7
		if p6:GetRoleInGroup(_G.GroupId) == "Testers" then
			v7 = game.PlaceId == 9164905432
		else
			v7 = false
		end
		return v7
	end,
	["TesterPublic"] = function(p8)
		return p8:GetRoleInGroup(_G.GroupId) == "Testers"
	end,
	["Youtuber"] = function(p9)
		return p9:GetAttribute("Youtuber")
	end,
	["CustomMoveset"] = function(p10)
		return p10:GetAttribute("AllowCustomMoveset")
	end
}
return function(p12)
	-- upvalues: (copy) v_u_11
	p12:RegisterHook("BeforeRun", function(p13)
		-- upvalues: (ref) v_u_11
		local v14 = p13.Group
		if not v14 then
			return "A group isn\'t linked to this command!"
		end
		local v15 = false
		for _, v16 in v14 do
			if v_u_11[v16](p13.Executor) then
				v15 = true
				break
			end
		end
		if not v15 then
			return "You don\'t have permission to run this command"
		end
	end)
end