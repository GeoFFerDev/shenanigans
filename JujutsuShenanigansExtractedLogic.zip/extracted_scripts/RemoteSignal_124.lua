-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("Players")
local v_u_2 = require(script.Parent.Parent.Parent.Signal)
require(script.Parent.Parent.Types)
local v_u_3 = {}
v_u_3.__index = v_u_3
function v_u_3.new(p4, p5, p6, p_u_7, p8)
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	local v9 = v_u_3
	local v_u_10 = setmetatable({}, v9)
	local v11
	if p6 == true then
		v11 = Instance.new("UnreliableRemoteEvent")
	else
		v11 = Instance.new("RemoteEvent")
	end
	v_u_10._re = v11
	v_u_10._re.Name = p5
	v_u_10._re.Parent = p4
	if p8 and #p8 > 0 then
		v_u_10._hasOutbound = true
		v_u_10._outbound = p8
	else
		v_u_10._hasOutbound = false
	end
	if not p_u_7 or #p_u_7 <= 0 then
		v_u_10._directConnect = true
		return v_u_10
	end
	v_u_10._directConnect = false
	v_u_10._signal = v_u_2.new()
	v_u_10._re.OnServerEvent:Connect(function(p12, ...)
		-- upvalues: (copy) p_u_7, (copy) v_u_10
		local v13 = table.pack(...)
		for _, v14 in p_u_7 do
			if not table.pack(v14(p12, v13))[1] then
				return
			end
			v13.n = #v13
		end
		local v15 = v_u_10._signal
		local v16 = v13.n
		v15:Fire(p12, table.unpack(v13, 1, v16))
	end)
	return v_u_10
end
function v_u_3.IsUnreliable(p17)
	return p17._re:IsA("UnreliableRemoteEvent")
end
function v_u_3.Connect(p18, p19)
	if p18._directConnect then
		return p18._re.OnServerEvent:Connect(p19)
	else
		return p18._signal:Connect(p19)
	end
end
function v_u_3._processOutboundMiddleware(p20, p21, ...)
	if not p20._hasOutbound then
		return ...
	end
	local v22 = table.pack(...)
	for _, v23 in p20._outbound do
		local v24 = table.pack(v23(p21, v22))
		if not v24[1] then
			local v25 = v24.n
			return table.unpack(v24, 2, v25)
		end
		v22.n = #v22
	end
	local v26 = v22.n
	return table.unpack(v22, 1, v26)
end
function v_u_3.Fire(p27, p28, ...)
	p27._re:FireClient(p28, p27:_processOutboundMiddleware(p28, ...))
end
function v_u_3.FireAll(p29, ...)
	p29._re:FireAllClients(p29:_processOutboundMiddleware(nil, ...))
end
function v_u_3.FireExcept(p30, p_u_31, ...)
	p30:FireFilter(function(p32)
		-- upvalues: (copy) p_u_31
		return p32 ~= p_u_31
	end, ...)
end
function v_u_3.FireFilter(p33, p34, ...)
	-- upvalues: (copy) v_u_1
	for _, v35 in v_u_1:GetPlayers() do
		if p34(v35, ...) then
			p33._re:FireClient(v35, p33:_processOutboundMiddleware(nil, ...))
		end
	end
end
function v_u_3.FireFor(p36, p37, ...)
	for _, v38 in p37 do
		p36._re:FireClient(v38, p36:_processOutboundMiddleware(nil, ...))
	end
end
function v_u_3.Destroy(p39)
	p39._re:Destroy()
	if p39._signal then
		p39._signal:Destroy()
	end
end
return v_u_3