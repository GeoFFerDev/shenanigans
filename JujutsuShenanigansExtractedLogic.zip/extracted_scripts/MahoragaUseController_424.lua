-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "MahoragaUseController"
})
function v13.KnitStart(_)
	-- upvalues: (copy) v_u_5, (copy) v_u_10, (ref) v_u_12, (copy) v_u_9, (copy) v_u_8, (copy) v_u_4, (copy) v_u_3, (copy) v_u_7, (copy) v_u_2, (ref) v_u_11
	local v_u_79 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_12, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				if v_u_5.Character == p14 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
				v_u_12:PlaySound(v_u_9.Megumi.Rabbit.Start, v15, game.SoundService.Effect)
				local v16 = v_u_8.Megumi.Mahoraga.RitualStart:Clone()
				v16.Position = v15.Position
				v16.Parent = workspace.Effects
				v_u_4:Create(v16, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(75, 75, 75),
					["Transparency"] = 1
				}):Play()
				v16.Attachment.Ring:Emit(20)
				v16.Attachment.Dust:Emit(20)
				v_u_3:AddItem(v16, 2)
			end
		end,
		["Timer"] = function(p17, p18, p19)
			-- upvalues: (ref) v_u_12, (ref) v_u_5, (ref) v_u_10, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
			v_u_12:Flash(p17, Color3.fromRGB(255, 255, 255), 1.5)
			if v_u_5.Character == p17 or v_u_5.Character == p18 then
				local v20 = p17:FindFirstChild("HumanoidRootPart")
				if v20 then
					v_u_12:DomainMapFade(Color3.new(0, 0, 0), 0.1, 0.1)
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					v_u_12:PlaySound(v_u_9.Megumi.Mahoraga.Ritual.Timer, v20, game.SoundService.Effect)
					local v_u_21 = v_u_8.Heian.Chant.Chant:Clone()
					v_u_21.Parent = p17.Head
					v_u_3:AddItem(v_u_21, 1)
					v_u_4:Create(v_u_21, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
						["StudsOffset"] = Vector3.new(2, 2, 2)
					}):Play()
					task.delay(0.5, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_21
						v_u_4:Create(v_u_21.Chat, TweenInfo.new(0.5), {
							["ImageTransparency"] = 1
						}):Play()
						v_u_4:Create(v_u_21.Chat.Sub, TweenInfo.new(0.5), {
							["TextTransparency"] = 1
						}):Play()
					end)
					if p19 then
						v_u_21.Chat.Sub.Text = "WITH THIS TREASURE"
					else
						v_u_21.Chat.Sub.Text = "I SUMMON"
					end
				else
					return
				end
			else
				return
			end
		end,
		["Goodbye"] = function(p_u_22, p_u_23, p_u_24)
			-- upvalues: (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_5, (ref) v_u_12, (ref) v_u_9, (ref) v_u_10, (ref) v_u_3, (ref) v_u_2
			local v_u_25 = p_u_22:FindFirstChild("HumanoidRootPart")
			if v_u_25 then
				local v26 = p_u_23:FindFirstChild("HumanoidRootPart")
				if v26 then
					task.spawn(function()
						-- upvalues: (ref) v_u_8, (ref) v_u_7, (copy) p_u_24, (ref) v_u_4, (ref) v_u_5, (copy) p_u_22, (copy) p_u_23, (ref) v_u_12, (ref) v_u_9, (copy) v_u_25, (ref) v_u_10, (ref) v_u_3
						local v_u_27 = v_u_8.Megumi.Mahoraga.Mahoraga:Clone()
						v_u_27.Outfit.Head.Beard:Destroy()
						v_u_27.Outfit.Head.Hat:Destroy()
						v_u_27.Outfit.Head.Mouth.Decal.Transparency = 0
						v_u_27.Outfit.Head.Mouth.Pumpkin:Destroy()
						v_u_27.HumanoidRootPart.CFrame = CFrame.new(0, 1000000, 0)
						v_u_27.Parent = workspace.Effects
						local v28 = v_u_27.Humanoid:LoadAnimation(v_u_7.Megumi.MahoragaSummon)
						v28:Play(0, nil, 0)
						task.wait(3)
						v_u_27.HumanoidRootPart.CFrame = p_u_24 - Vector3.new(0, 8, 0)
						local v29 = {
							["CFrame"] = p_u_24
						}
						v_u_4:Create(v_u_27.HumanoidRootPart, TweenInfo.new(2, Enum.EasingStyle.Exponential), v29):Play()
						v28:AdjustSpeed(1)
						if v_u_5.Character == p_u_22 or v_u_5.Character == p_u_23 then
							task.delay(1.75, function()
								-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_25, (ref) v_u_4, (ref) v_u_3
								local v_u_30 = v_u_12:PlaySound(v_u_9.Itadori.MalevolantShrine.Music, v_u_25, game.SoundService.Music)
								task.delay(8, function()
									-- upvalues: (copy) v_u_30, (ref) v_u_4, (ref) v_u_3
									if v_u_30.Parent then
										v_u_4:Create(v_u_30, TweenInfo.new(4), {
											["Volume"] = 0
										}):Play()
										v_u_3:AddItem(v_u_30, 4)
									end
								end)
							end)
						else
							v_u_12:PlaySound(v_u_9.Megumi.Mahoraga.Ritual.Spawn, v_u_27.HumanoidRootPart, game.SoundService.Effect)
							task.delay(1, function()
								-- upvalues: (ref) v_u_12, (ref) v_u_9, (copy) v_u_27
								v_u_12:PlaySound(v_u_9.Megumi.Mahoraga.Ritual.Moving, v_u_27.HumanoidRootPart, game.SoundService.Effect)
							end)
							if (workspace.CurrentCamera.CFrame.Position - v_u_25.Position).Magnitude < 70 then
								v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
							end
						end
						task.wait(4.8)
						v_u_27:Destroy()
					end)
					if v_u_5.Character == p_u_22 or v_u_5.Character == p_u_23 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
						v_u_12:PlaySound(v_u_9.Megumi.Mahoraga.Ritual.Timer, v_u_25, game.SoundService.Effect)
						v_u_12:PlaySound(v_u_9.Megumi.Mahoraga.Ritual.Summon, workspace, game.SoundService.Effect)
						local v_u_31 = v_u_8.Megumi.Mahoraga.Ritual:Clone()
						v_u_31.Viewport.CurrentCamera = workspace.CurrentCamera
						v_u_31.Parent = v_u_5.PlayerGui
						local v_u_32 = {}
						v_u_12:WorldModelChar(p_u_22, v_u_31.Viewport)
						v_u_12:WorldModelChar(p_u_23, v_u_31.Viewport)
						local v_u_33 = nil
						v_u_33 = v_u_2.Stepped:Connect(function()
							-- upvalues: (copy) p_u_22, (copy) p_u_23, (ref) v_u_33, (ref) v_u_4, (copy) v_u_31, (ref) v_u_3, (copy) v_u_32
							if p_u_22.Parent and p_u_23.Parent then
								for v34, v35 in v_u_32 do
									v34.CFrame = CFrame.new(v35[2].Position + v35[1], v35[2].Position)
								end
							else
								v_u_33:Disconnect()
								v_u_4:Create(v_u_31.Viewport, TweenInfo.new(1), {
									["BackgroundTransparency"] = 1,
									["ImageTransparency"] = 1
								}):Play()
								v_u_3:AddItem(v_u_31, 1)
							end
						end)
						local v36 = CFrame.new
						local v37 = v_u_25.Position
						local v38 = v26.Position.X
						local v39 = v_u_25.Position.Y
						local v40 = v26.Position.Z
						local v41 = v36(v37, (Vector3.new(v38, v39, v40)))
						local v_u_42 = TweenInfo.new(0.25)
						local v_u_43 = v_u_8.Megumi.Mahoraga.Mahoraga:Clone()
						v_u_43.Outfit.Head.Beard:Destroy()
						v_u_43.Outfit.Head.Hat:Destroy()
						v_u_43.Outfit.Head.Mouth.Decal.Transparency = 0
						v_u_43.Outfit.Head.Mouth.Pumpkin:Destroy()
						v_u_43.HumanoidRootPart.CFrame = CFrame.new(0, 1000000, 0)
						v_u_43.Humanoid.DisplayName = p_u_22.Humanoid.DisplayName or p_u_22.Name
						v_u_43.Parent = v_u_31.Viewport.Mahoraga
						local v_u_44 = v_u_43.Humanoid:LoadAnimation(v_u_7.Megumi.MahoragaSummon)
						v_u_44:Play(0, nil, 0)
						local v_u_45 = v_u_33
						local v46 = 10
						for v47 = 1, 6 do
							for v48 = 1, 2 do
								local v_u_49 = v_u_31.Toad:Clone()
								v_u_49.Parent = v_u_31.Viewport
								local v50 = CFrame.Angles
								local v51 = v48 == 1 and 45 or -45
								v_u_49.CFrame = v41 * v50(0, math.rad(v51), 0) + v41.LookVector * (10 * (v47 - 1)) + v41.RightVector * (v48 == 1 and v46 and v46 or -v46)
								local v_u_52 = v_u_31.Wolf:Clone()
								v_u_52.Parent = v_u_31.Viewport
								local v53 = v46 + (50 - v46) * 0.15 + 2
								local v54 = CFrame.Angles
								local v55 = v48 == 1 and -135 or 135
								v_u_52.CFrame = v41 * v54(0, math.rad(v55), 0) + v41.LookVector * (10 * (v47 - 1) + 5) + v41.RightVector * (v48 == 1 and v53 and v53 or -v53) + v41.UpVector
								task.delay(0.35 + 0.25 * v47, function()
									-- upvalues: (copy) v_u_49, (ref) v_u_4, (copy) v_u_42, (copy) v_u_52
									if v_u_49.Parent then
										v_u_4:Create(v_u_49, v_u_42, {
											["Transparency"] = 0
										}):Play()
										for _, v56 in v_u_49:GetChildren() do
											v_u_4:Create(v56, v_u_42, {
												["Transparency"] = 0
											}):Play()
										end
										task.wait(0.125)
										if v_u_52.Parent then
											v_u_4:Create(v_u_52, v_u_42, {
												["Transparency"] = 0
											}):Play()
											for _, v57 in v_u_52:GetChildren() do
												v_u_4:Create(v57, v_u_42, {
													["Transparency"] = 0
												}):Play()
											end
										end
									else
										return
									end
								end)
							end
							v46 = v46 + (50 - v46) * 0.3
						end
						v_u_4:Create(v_u_31.Viewport, TweenInfo.new(0.6), {
							["BackgroundTransparency"] = 0,
							["ImageTransparency"] = 0
						}):Play()
						task.delay(3, function()
							-- upvalues: (copy) v_u_31, (copy) v_u_43, (copy) p_u_24, (copy) v_u_44, (ref) v_u_10, (ref) v_u_12, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8, (copy) v_u_32, (ref) v_u_3, (ref) v_u_45
							for _, v58 in v_u_31.Viewport:GetChildren() do
								if v58.Name == "Toad" or v58.Name == "Wolf" then
									v58:Destroy()
								end
							end
							v_u_43.HumanoidRootPart.CFrame = p_u_24
							v_u_44:AdjustSpeed(1)
							v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
							v_u_12:PlaySound(v_u_9.Megumi.Mahoraga.Ritual.Spawn, workspace, game.SoundService.Effect)
							task.delay(1, function()
								-- upvalues: (ref) v_u_12, (ref) v_u_9
								v_u_12:PlaySound(v_u_9.Megumi.Mahoraga.Ritual.Moving, workspace, game.SoundService.Effect)
							end)
							v_u_31.Viewport.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_31.Viewport.Ambient = Color3.fromRGB(0, 0, 0)
							v_u_31.Viewport.LightColor = Color3.fromRGB(255, 255, 255)
							v_u_4:Create(v_u_31.Viewport, TweenInfo.new(0.3), {
								["BackgroundColor3"] = Color3.fromRGB(0, 0, 0)
							}):Play()
							local v59 = {
								v_u_43.Torso,
								v_u_43.Head,
								v_u_43["Left Arm"],
								v_u_43["Right Arm"]
							}
							local v60 = Random.new()
							for v61 = 1, 20 do
								local v_u_62 = v59[math.random(1, #v59)]
								local v_u_63 = v60:NextUnitVector() * 60
								local v_u_64 = v_u_8.Megumi.Mahoraga.String:Clone()
								v_u_64.CFrame = CFrame.new(v_u_62.Position + v_u_63, v_u_62.Position)
								v_u_64.Parent = v_u_31.Viewport.Mahoraga
								v_u_32[v_u_64] = { v_u_63, v_u_62 }
								task.delay(v61 < 5 and 2 or (v61 < 10 and 3 or 3.55), function()
									-- upvalues: (ref) v_u_32, (copy) v_u_64, (ref) v_u_4, (copy) v_u_62, (copy) v_u_63, (ref) v_u_3
									v_u_32[v_u_64] = nil
									local v65 = v_u_4
									local v66 = v_u_64
									local v67 = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
									local v68 = {}
									local v69 = CFrame.new
									local v70 = v_u_62.Position + v_u_63
									local v71 = v_u_62.Position
									local v72 = math.random(-40, 40)
									local v73 = math.random(-40, 40)
									local v74 = math.random
									v68.CFrame = v69(v70, v71 + Vector3.new(v72, v73, v74(-40, 40)))
									v68.Transparency = 1
									v65:Create(v66, v67, v68):Play()
									v_u_3:AddItem(v_u_64, 1)
								end)
							end
							task.wait(3.8)
							v_u_4:Create(v_u_31.Viewport, TweenInfo.new(1), {
								["BackgroundTransparency"] = 1,
								["ImageTransparency"] = 1
							}):Play()
							v_u_3:AddItem(v_u_31, 1)
							v_u_45:Disconnect()
						end)
					end
				end
			else
				return
			end
		end,
		["Hit"] = function(p75, p76)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_5, (ref) v_u_8, (ref) v_u_10
			local v77 = p75:FindFirstChild("HumanoidRootPart")
			if v77 then
				v_u_12:PlaySound(v_u_9.Megumi.Mahoraga.Ritual.Hit, workspace, game.SoundService.Effect)
				if v_u_5.Character == p75 then
					local v78 = v_u_8.Itadori.DivergentFist.BlackFlashCC:Clone()
					v78.Parent = game.Lighting
					v78.TintColor = Color3.new(1, 1, 1)
					task.wait(0.04)
					v78.Brightness = 200
					v78.Contrast = -1000
					task.wait(0.04)
					v78:Destroy()
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				elseif (workspace.CurrentCamera.CFrame.Position - v77.Position).Magnitude < 70 or v_u_5.Character == p76 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p80, ...)
		-- upvalues: (copy) v_u_79
		local v81 = v_u_79[p80]
		if v81 then
			v81(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("MahoragaUseService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13