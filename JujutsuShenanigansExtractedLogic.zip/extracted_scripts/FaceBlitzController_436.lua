-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "FaceBlitzController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_8, (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (ref) v_u_9
	local v_u_43 = {
		["Grab"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_8
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:Flash(p13, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v14, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v14.Position).Magnitude < 150 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Leap"] = function(p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v16 = p15:FindFirstChild("Torso")
			if v16 then
				local v17 = workspace:Raycast(v16.Position, Vector3.new(0, -12, 0), _G.MapParams)
				if v17 then
					local v18 = v_u_6.Itadori.CrushingBlow:Clone()
					v18.Position = v17.Position
					v18.PointLight:Destroy()
					v18.Air:Destroy()
					v18.Parent = workspace.Effects
					v18.Floor.Wind2.Color = ColorSequence.new(Color3.new(0.666667, 0.333333, 1))
					v18.Floor.Sparks.Color = ColorSequence.new(Color3.new(0.666667, 0.333333, 1))
					v18.Floor.Ring:Emit(10)
					v18.Floor.Sparks:Emit(10)
					v18.Floor.Wind2:Emit(8)
					v_u_2:AddItem(v18, 1.5)
					v_u_11:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v18, game.SoundService.Effect)
					if v_u_4.Character == p15 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			end
		end,
		["Leap2"] = function(p19)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_3
			local v_u_20 = p19:FindFirstChild("HumanoidRootPart")
			if v_u_20 then
				local v21 = p19:FindFirstChild("Torso")
				if v21 then
					local v22 = workspace:Raycast(v21.Position, Vector3.new(0, -12, 0), _G.MapParams)
					if v22 then
						local v23 = v_u_6.Itadori.CrushingBlow:Clone()
						v23.Position = v22.Position
						v23.PointLight:Destroy()
						v23.Air:Destroy()
						v23.Parent = workspace.Effects
						v23.Floor.Wind2.Color = ColorSequence.new(Color3.new(0.666667, 0.333333, 1))
						v23.Floor.Sparks.Color = ColorSequence.new(Color3.new(0.666667, 0.333333, 1))
						v23.Floor.Ring:Emit(10)
						v23.Floor.Sparks:Emit(10)
						v23.Floor.Wind2:Emit(8)
						v_u_2:AddItem(v23, 1.5)
						v_u_11:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v23, game.SoundService.Effect)
						if v_u_4.Character == p19 then
							v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
						end
					end
					local v24 = v_u_6.Itadori.Shock:Clone()
					v24.CFrame = CFrame.new(v_u_20.Position, v_u_20.Position + v_u_20.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
					v24.Parent = workspace.Effects
					v_u_3:Create(v24, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(10, 0, 10),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v24, 0.3)
					task.delay(0.075, function()
						-- upvalues: (ref) v_u_6, (copy) v_u_20, (ref) v_u_3, (ref) v_u_2
						local v25 = v_u_6.Itadori.Shock:Clone()
						v25.CFrame = CFrame.new(v_u_20.Position, v_u_20.Position + v_u_20.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_20.CFrame.LookVector * 3
						v25.Parent = workspace.Effects
						v_u_3:Create(v25, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v25, 0.2)
						task.wait(0.075)
						local v26 = v_u_6.Itadori.Shock:Clone()
						v26.CFrame = CFrame.new(v_u_20.Position, v_u_20.Position + v_u_20.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
						v26.Parent = workspace.Effects
						v_u_3:Create(v26, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v26, 0.2)
						task.wait(0.075)
						local v27 = v_u_6.Itadori.Shock:Clone()
						v27.CFrame = CFrame.new(v_u_20.Position, v_u_20.Position + v_u_20.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
						v27.Parent = workspace.Effects
						v_u_3:Create(v27, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v27, 0.2)
					end)
					v_u_11:PlaySound(v_u_7.Itadori.Rush.RushLaunch, v_u_20, game.SoundService.Effect)
					local v_u_28 = v_u_6.Mahito.Worms.WormLaunch.groundwaveing.groundwaveing1:Clone()
					v_u_28.EmissionDirection = Enum.NormalId.Front
					v_u_28.Parent = v_u_20
					v_u_2:AddItem(v_u_28, 1)
					task.delay(0.5, function()
						-- upvalues: (copy) v_u_28
						v_u_28.Enabled = false
					end)
					local v_u_29 = v_u_6.Mahito.Worms.WormLaunch.groundwaveing.groundwaveing3:Clone()
					v_u_29.EmissionDirection = Enum.NormalId.Front
					v_u_29.Parent = v_u_20
					v_u_2:AddItem(v_u_29, 1)
					task.delay(0.5, function()
						-- upvalues: (copy) v_u_29
						v_u_29.Enabled = false
					end)
				end
			else
				return
			end
		end,
		["Teleport"] = function(p_u_30)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v_u_31 = p_u_30:FindFirstChild("HumanoidRootPart")
			if v_u_31 then
				local v32 = Instance.new("Model")
				local v_u_33 = v_u_6.Gojo.Teleport:Clone()
				v_u_33.CFrame = v_u_31.CFrame + Vector3.new(0, 2, 0)
				v_u_33.Parent = v32
				v32:ScaleTo(2)
				v_u_33.Parent = workspace.Effects
				v32:Destroy()
				v_u_2:AddItem(v_u_33, 1.1)
				v_u_33.Floor.Dust:Emit(30)
				v_u_33.Lines:Emit(30)
				v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Takedown.Teleport, v_u_31, game.SoundService.Effect)
				task.delay(0.02, function()
					-- upvalues: (copy) v_u_33, (copy) v_u_31, (ref) v_u_3, (copy) p_u_30
					v_u_33.CFrame = v_u_31.CFrame
					v_u_33.Lines:Emit(30)
					v_u_33.Floor.Dust:Emit(30)
					local v34 = v_u_31:FindFirstChild("RootJoint")
					if v34 then
						local v35 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0)
						v34.C0 = v35 * CFrame.new(7, 0, 0)
						v_u_3:Create(v34, TweenInfo.new(0.5, Enum.EasingStyle.Elastic), {
							["C0"] = v35
						}):Play()
					end
					local v36 = p_u_30:FindFirstChild("Outfit")
					if v36 then
						local v37 = TweenInfo.new(0.15, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
						for _, v38 in v36:GetDescendants() do
							if v38:IsA("BasePart") then
								local v39 = v38.Transparency
								v38.Transparency = 1
								v_u_3:Create(v38, v37, {
									["Transparency"] = v39
								}):Play()
							end
						end
					end
				end)
				if v_u_4.Character == p_u_30 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["Crush"] = function(p40)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_8
			local v41 = v_u_6.Megumi.Mahoraga.Earthquake:Clone()
			v41.Position = p40
			v41.Parent = workspace.Effects
			v41.Air:Destroy()
			v_u_3:Create(v41.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v_u_3:Create(v41.Floor.Ring2, TweenInfo.new(0.4), {
				["TimeScale"] = 0.5
			}):Play()
			v41.Floor.Ring2:Emit(10)
			v41.Floor.Wind2:Emit(15)
			v41.Floor.Dust:Emit(100)
			v_u_2:AddItem(v41, 3)
			local v42 = v_u_6.Megumi.Mahoraga.WorldSlash.mesh:Clone()
			v42.Position = p40
			v42.Decal.Transparency = 0
			v42.Mesh.Scale = Vector3.new(2, 50, 2)
			v42.Parent = v41
			v_u_3:Create(v42, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Size"] = Vector3.new(80, 40, 80),
				["CFrame"] = v42.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
			}):Play()
			v_u_3:Create(v42.Mesh, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(60, 10, 60)
			}):Play()
			v_u_3:Create(v42.Decal, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v_u_2:AddItem(v42, 1)
			v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v41, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_7.Mahito.WideSPStrike.Crush, v41, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_7.Mahito.WideSPStrike.Crush2, v41, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p40).Magnitude < 180 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end
	}
	v_u_9.Effects:Connect(function(p44, ...)
		-- upvalues: (copy) v_u_43
		local v45 = v_u_43[p44]
		if v45 then
			v45(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("FaceBlitzService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12