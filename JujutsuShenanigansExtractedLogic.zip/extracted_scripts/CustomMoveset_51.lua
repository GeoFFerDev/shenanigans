-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "customMoveset",
	["Description"] = "exports/imports current moveset",
	["Group"] = { "Owner", "CustomMoveset" },
	["Args"] = {
		{
			["Type"] = "string",
			["Name"] = "moveset data",
			["Description"] = "paste exported data here (must be wrapped in quotes \"\")"
		},
		{
			["Type"] = "player",
			["Name"] = "player to load for",
			["Description"] = "head mod+",
			["Optional"] = true
		}
	}
}
return v1