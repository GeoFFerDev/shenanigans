-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = require(v4.Modules.CameraShaker)
local v_u_8 = require(v4.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "DespairController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_6, (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_8, (copy) v_u_7, (ref) v_u_9
	local v_u_46 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_6
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_6.Charles.Despair.Startup, v13, game.SoundService.Effect)
			end
		end,
		["Spin"] = function(p14)
			-- upvalues: (ref) v_u_10, (ref) v_u_6
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_10:PlaySound(v_u_6.Charles.Despair.Spin, v15, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p16)
			-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (ref) v_u_2, (ref) v_u_3
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_10:PlaySound(v_u_6.Charles.Despair.Swing, v17, game.SoundService.Effect)
				local v18 = v_u_5.Choso.CounterSwing:Clone()
				v18:PivotTo(v17.CFrame * CFrame.new(1, 0, -4) * CFrame.Angles(0, 0.2617993877991494, 0))
				v18.Parent = workspace.Effects
				v_u_2:AddItem(v18, 0.3)
				v_u_3:Create(v18.Shock, TweenInfo.new(0.15), {
					["Size"] = Vector3.new(0, 25, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:Create(v18.Shock2, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1,
					["Position"] = v18.Shock2.Position + v17.CFrame.LookVector * 3
				}):Play()
				v_u_3:Create(v18.Shockwave, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(0, 30, 0),
					["Transparency"] = 1,
					["CFrame"] = v18.Shockwave.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
				}):Play()
			end
		end,
		["Swing2"] = function(p19)
			-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (ref) v_u_2, (ref) v_u_3
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_10:PlaySound(v_u_6.Charles.Despair.Swing, v20, game.SoundService.Effect)
				local v21 = Instance.new("Model")
				local v22 = v_u_5.Todo.Swing:Clone()
				v22.Weld.C0 = v22.Weld.C0 * CFrame.Angles(0, 0, 1.7453292519943295)
				v22.Weld.Part0 = v20
				v22.Parent = v21
				v21.Parent = workspace.Effects
				v21:ScaleTo(1.4)
				v22.Parent = workspace.Effects
				v21:Destroy()
				v_u_2:AddItem(v22, 0.6)
				v22.Core.Wind:Emit(12)
				v_u_3:Create(v22.Weld, TweenInfo.new(0.4), {
					["C1"] = v22.Weld.C1 * CFrame.Angles(0, -3.141592653589793, 0)
				}):Play()
				v_u_3:Create(v22.Beam, TweenInfo.new(0.4), {
					["Width0"] = 0
				}):Play()
			end
		end,
		["Barrage"] = function(p23, p24)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_2
			local v25 = p23:FindFirstChild("HumanoidRootPart")
			if not v25 then
				return
			end
			local v26 = p23:FindFirstChildWhichIsA("Shirt")
			local v27 = p23["Left Arm"].Color
			local _ = p23["Right Arm"].Color
			while true do
				local v28 = v_u_5.Charles.Barrage:Clone()
				if v26 then
					v26:Clone().Parent = v28
				end
				v28["Left Arm"].Color = v27
				for _, v29 in v28:GetChildren() do
					if v29:IsA("BasePart") then
						local v30 = v25.CFrame * CFrame.new(math.random(-20, -10) / 10, math.random(-10, 10) / 10, math.random(30, 50) / 10)
						local v31 = CFrame.Angles
						local v32 = math.random(70, 110)
						local v33 = math.rad(v32)
						local v34 = math.random(0, 40)
						local v35 = math.rad(v34)
						local v36 = math.random(-20, 20)
						v29.CFrame = v30 * v31(v33, v35, (math.rad(v36)))
						v_u_3:Create(v29, TweenInfo.new(0.1), {
							["CFrame"] = v29.CFrame + v25.CFrame.LookVector * 7
						}):Play()
						v_u_3:Create(v29, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
							["Transparency"] = 1
						}):Play()
						v_u_3:Create(v29.GWarstaff, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
							["Transparency"] = 1
						}):Play()
						local v37 = v_u_5.Gojo.LapseBlue.Throw:Clone()
						v37.CFrame = v25.CFrame - v25.Position + v29.Position + v25.CFrame.LookVector * 11
						v37.Size = Vector3.new(0, 0, 1)
						v37.Parent = v28
						v_u_3:Create(v37, TweenInfo.new(0.15), {
							["Size"] = Vector3.new(4, 4, 0),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v37, 0.15)
					end
				end
				v28.Parent = workspace.Effects
				v_u_2:AddItem(v28, 0.6)
				task.wait(0.025)
				if not p24.Parent then
					return
				end
			end
		end,
		["Hit"] = function(p38)
			-- upvalues: (ref) v_u_10, (ref) v_u_6
			local v39 = p38:FindFirstChild("HumanoidRootPart")
			if v39 then
				v_u_10:Flash(p38, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_6.Charles.Despair:FindFirstChild("Hit" .. math.random(1, 3)), v39, game.SoundService.Effect)
			end
		end,
		["Hit2"] = function(p40)
			-- upvalues: (ref) v_u_10, (ref) v_u_6
			local v41 = p40:FindFirstChild("HumanoidRootPart")
			if v41 then
				v_u_10:Flash(p40, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_6.Charles.Despair.Hit3, v41, game.SoundService.Effect)
			end
		end,
		["Die"] = function(p42)
			-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (ref) v_u_2, (ref) v_u_8, (ref) v_u_7
			local v43 = p42:FindFirstChild("HumanoidRootPart")
			if v43 then
				v_u_10:Flash(p42, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_6.Hiromi.Verdict.Hit2, v43, game.SoundService.Effect)
				local v44 = v_u_5.Locust.Slam:Clone()
				v44.Position = p42.Torso.Position
				v44.Parent = workspace.Effects
				for _, v45 in v44.Attachment:GetChildren() do
					v45:Emit(v45:GetAttribute("EmitCount"))
				end
				v_u_2:AddItem(v44, 0.5)
				for _ = 1, 20 do
					v_u_8:Blood(p42.Head.CFrame, math.random(5, 150), 45, 45)
				end
				if (workspace.CurrentCamera.CFrame.Position - v43.Position).Magnitude < 100 then
					v_u_7.CurrentShaker:Shake(v_u_7.Presets.SnapOh)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p47, ...)
		-- upvalues: (copy) v_u_46
		local v48 = v_u_46[p47]
		if v48 then
			v48(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("DespairService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11