-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "ExecutionController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (ref) v_u_12, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (copy) v_u_9, (ref) v_u_10
	local v_u_68 = {
		["Charge"] = function(p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = p14.SetAssets:FindFirstChild("ExecSword")
				if v16 then
					v_u_11:PlaySound(v_u_7.Hiromi.Execution.Charge, v15, game.SoundService.Effect)
					local v17 = v_u_6.Hiromi.SwordBuild.Charge:Clone()
					v_u_2:AddItem(v17, 2)
					v17.Parent = v16
					task.wait(0.7)
					for _, v18 in v17:GetChildren() do
						v18.Enabled = false
					end
				end
			else
				return
			end
		end,
		["Charged"] = function(p19)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = p19.SetAssets:FindFirstChild("ExecSword")
				if v21 then
					v_u_11:PlaySound(v_u_7.Hiromi.Execution.Flash, v20, game.SoundService.Effect)
					local v22 = v_u_6.Hiromi.SwordBuild.ChargeEmit:Clone()
					v_u_2:AddItem(v22, 1)
					v22.Parent = v21
					for _, v23 in v22:GetChildren() do
						v23:Emit(v23:GetAttribute("EmitCount"))
					end
				end
			else
				return
			end
		end,
		["Aerial"] = function(p24, p25)
			-- upvalues: (ref) v_u_12
			local v26 = p24:FindFirstChild("HumanoidRootPart")
			if v26 then
				local v27 = p24:FindFirstChild("Humanoid")
				if v27 then
					local v28 = Instance.new("BodyGyro", v26)
					v28.P = 10000
					v28.MaxTorque = Vector3.new(40000, 40000, 40000)
					p25.Position = v26.Position + Vector3.new(0, 6, 0)
					v27.PlatformStand = true
					repeat
						local v29 = v_u_12:GetMouseTarget()
						v28.CFrame = p25:GetAttribute("Aim") or CFrame.new(v26.Position, v29)
						task.wait()
					until not p25.Parent
					v28:Destroy()
					v27.PlatformStand = false
				end
			else
				return
			end
		end,
		["Woosh"] = function(p30)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				v_u_11:PlaySound(v_u_7.Hiromi.Execution.Dash, v31, game.SoundService.Effect)
				local v32 = v_u_6.Hiromi.Thrust:Clone()
				v32.CFrame = v31.CFrame * CFrame.new(0, 0, -11) * CFrame.Angles(-1.5707963267948966, 0, 0)
				v_u_2:AddItem(v32, 2)
				v32.Parent = workspace.Effects
				for _, v33 in v32.Attachment:GetChildren() do
					v33:Emit(v33:GetAttribute("EmitCount"))
				end
				if v_u_4.Character == p30 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Fly"] = function(p34)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v35 = p34:FindFirstChild("HumanoidRootPart")
			if v35 then
				local v36 = v_u_6.Mahito.BodyRepel["Wind" .. math.random(1, 5)]:Clone()
				local v37 = CFrame.lookAlong(v35.Position, v35.Velocity)
				local v38 = CFrame.Angles
				local v39 = math.random(0, 360)
				v36.CFrame = v37 * v38(1.5707963267948966, math.rad(v39), 0)
				v36.Transparency = 0.5
				v36.Size = Vector3.new(3, 6, 3)
				v_u_3:Create(v36, TweenInfo.new(0.3, Enum.EasingStyle.Quad), {
					["CFrame"] = v36.CFrame + v35.CFrame.LookVector * 3,
					["Size"] = Vector3.new(15, 0, 15)
				}):Play()
				v_u_2:AddItem(v36, 0.2)
				v36.Parent = workspace.Effects
				v_u_3:Create(v36, TweenInfo.new(0.2), {
					["Transparency"] = 1
				}):Play()
			end
		end,
		["Hit"] = function(p40, p41)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v42 = p40:FindFirstChild("HumanoidRootPart")
			if v42 then
				v_u_11:Flash(p40, Color3.fromRGB(255, 85, 255), 0.5)
				v_u_11:PlaySound(v_u_7.Hiromi.Execution.Stab, v42, game.SoundService.Effect)
				if p41 then
					v_u_11:PlaySound(v_u_7.Hiromi.Fall, v42, game.SoundService.Effect)
				end
			end
		end,
		["Whack"] = function(p43, p44)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v45 = p44:FindFirstChild("HumanoidRootPart")
			if v45 then
				local v46 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v46.Position = v45.Position
				v46.Parent = workspace.Effects
				v_u_2:AddItem(v46, 1)
				v46.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v46.Wind.Color = v46.Sparks.Color
				v46.Wind2.Color = v46.Sparks.Color
				v46.Sparks:Emit(50)
				v46.Wind:Emit(7)
				v46.Wind2:Emit(7)
				v_u_11:Flash(p44, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Hakari.EnergySurge.Hit1, v45, game.SoundService.Effect)
				if v_u_4 == p43 or v_u_4.Character == p44 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
				end
			end
		end,
		["Arm"] = function(p47, p_u_48)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v49 = p47:FindFirstChild("HumanoidRootPart")
			if v49 then
				if p_u_48:FindFirstChild("HumanoidRootPart") then
					v_u_11:PlaySound(v_u_7.Hiromi.Execution.Sever, v49, game.SoundService.Effect)
					for _ = 1, 30 do
						v_u_9:Blood(p_u_48["Left Arm"].CFrame, math.random(5, 150), 25, 25)
					end
					local v_u_50 = p47.SetAssets:FindFirstChild("ExecSword")
					if v_u_50 then
						task.spawn(function()
							-- upvalues: (ref) v_u_6, (copy) p_u_48, (ref) v_u_2, (copy) v_u_50
							local v51 = v_u_6.Hiromi.Limb:Clone()
							local v52 = p_u_48["Left Arm"]
							v51["Left Arm"].Size = v52.Size
							v51["Left Arm"].Color = v52.Color
							if p_u_48:FindFirstChildWhichIsA("Shirt") then
								p_u_48:FindFirstChildWhichIsA("Shirt"):Clone().Parent = v51
							end
							v_u_2:AddItem(v51, 6)
							v51.Parent = workspace.Effects
							repeat
								v51:PivotTo(v_u_50.CFrame * CFrame.new(0, 0, 5))
								task.wait()
							until not (v51.Parent and v_u_50.Parent)
						end)
					end
					if v_u_4.Character == p47 or v_u_4.Character == p_u_48 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Leg"] = function(p53, p_u_54)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v55 = p53:FindFirstChild("HumanoidRootPart")
			if v55 then
				if p_u_54:FindFirstChild("HumanoidRootPart") then
					v_u_11:PlaySound(v_u_7.Hiromi.Execution.Sever2, v55, game.SoundService.Effect)
					for _ = 1, 30 do
						v_u_9:Blood(p_u_54["Right Leg"].CFrame, math.random(5, 150), 25, 25)
					end
					if _G.Settings.Gore then
						local v56 = v_u_6.Heian.BloodSpread:Clone()
						v56.Parent = p53["Right Leg"]
						v56:Emit(20)
						v_u_2:AddItem(v56, 2)
					end
					local v_u_57 = p53.SetAssets:FindFirstChild("ExecSword")
					if v_u_57 then
						task.spawn(function()
							-- upvalues: (ref) v_u_6, (copy) p_u_54, (ref) v_u_2, (copy) v_u_57
							local v58 = v_u_6.Hiromi.Limb:Clone()
							v58["Left Arm"].Transparency = 1
							v58["Right Leg"].Transparency = 0
							local v59 = p_u_54["Right Leg"]
							v58["Right Leg"].Size = v59.Size
							v58["Right Leg"].Color = v59.Color
							if p_u_54:FindFirstChildWhichIsA("Pants") then
								p_u_54:FindFirstChildWhichIsA("Pants"):Clone().Parent = v58
							end
							v_u_2:AddItem(v58, 6)
							v58.Parent = workspace.Effects
							repeat
								v58:PivotTo(v_u_57.CFrame * CFrame.new(0, 0, 5))
								task.wait()
							until not (v58.Parent and v_u_57.Parent)
						end)
					end
					if v_u_4.Character == p53 or v_u_4.Character == p_u_54 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Head"] = function(p60, p61)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			local v62 = p60:FindFirstChild("HumanoidRootPart")
			if v62 then
				if p61:FindFirstChild("HumanoidRootPart") then
					v_u_11:PlaySound(v_u_7.Hiromi.Stab, v62, game.SoundService.Effect)
					for _ = 1, 20 do
						v_u_9:Blood(p61.Head.CFrame, math.random(5, 150), 45, 45)
					end
					if v_u_4.Character == p60 or v_u_4.Character == p61 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Curb"] = function(p63, p64)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v65 = p63:FindFirstChild("HumanoidRootPart")
			if v65 then
				if p64:FindFirstChild("HumanoidRootPart") then
					v_u_11:Flash(p63, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Hiromi.Execution.Curb, v65, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_7.Hiromi.Execution.Step, v65, game.SoundService.Effect)
					local v66 = v_u_6.Locust.Slam:Clone()
					v66.Position = p64.Torso.Position
					v66.Parent = workspace.Effects
					for _, v67 in v66.Attachment:GetChildren() do
						v67:Emit(v67:GetAttribute("EmitCount"))
					end
					v_u_2:AddItem(v66, 0.5)
					if v_u_4.Character == p63 or v_u_4.Character == p64 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p69, ...)
		-- upvalues: (copy) v_u_68
		local v70 = v_u_68[p69]
		if v70 then
			v70(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("ExecutionService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("ToolController")
end
return v13