-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {
	["ServicePromises"] = true,
	["Middleware"] = nil,
	["PerServiceMiddleware"] = {}
}
local v_u_2 = nil
local v3 = {
	["Player"] = game:GetService("Players").LocalPlayer,
	["Util"] = script.Parent.Parent
}
local v_u_4 = require(v3.Util.Promise)
local v_u_5 = require(v3.Util.Comm).ClientComm
local v_u_6 = {}
local v_u_7 = {}
local v_u_8 = nil
local v_u_9 = false
local v_u_10 = false
local v_u_11 = Instance.new("BindableEvent")
function v3.CreateController(p12)
	-- upvalues: (copy) v_u_6
	local v13 = type(p12) == "table"
	local v14 = ("Controller must be a table; got %*"):format((type(p12)))
	assert(v13, v14)
	local v15 = p12.Name
	local v16 = type(v15) == "string"
	local v17 = p12.Name
	local v18 = ("Controller.Name must be a string; got %*"):format((type(v17)))
	assert(v16, v18)
	local v19 = #p12.Name > 0
	assert(v19, "Controller.Name must be a non-empty string")
	local v20 = v_u_6[p12.Name] ~= nil
	local v21 = ("Controller %* already exists"):format(p12.Name)
	assert(not v20, v21)
	v_u_6[p12.Name] = p12
	return p12
end
function v3.AddControllers(p22)
	local v23 = {}
	for _, v24 in p22:GetChildren() do
		if v24:IsA("ModuleScript") then
			local v25 = require
			table.insert(v23, v25(v24))
		end
	end
	return v23
end
function v3.AddControllersDeep(p26)
	local v27 = {}
	for _, v28 in p26:GetDescendants() do
		if v28:IsA("ModuleScript") then
			local v29 = require
			table.insert(v27, v29(v28))
		end
	end
	return v27
end
function v3.GetService(p30)
	-- upvalues: (copy) v_u_7, (ref) v_u_9, (ref) v_u_8, (ref) v_u_2, (copy) v_u_5
	local v31 = v_u_7[p30]
	if v31 then
		return v31
	end
	local v32 = v_u_9
	assert(v32, "Cannot call GetService until Knit has been started")
	local v33 = type(p30) == "string"
	local v34 = ("ServiceName must be a string; got %*"):format((type(p30)))
	assert(v33, v34)
	if not v_u_8 then
		v_u_8 = script.Parent:WaitForChild("Services")
	end
	local v35 = v_u_8
	local v36 = v_u_2.Middleware == nil and {} or v_u_2.Middleware
	local v37 = v_u_2.PerServiceMiddleware[p30]
	if v37 == nil then
		v37 = v36
	end
	local v38 = v_u_5.new(v35, v_u_2.ServicePromises, p30):BuildObject(v37.Inbound, v37.Outbound)
	v_u_7[p30] = v38
	return v38
end
function v3.GetController(p39)
	-- upvalues: (copy) v_u_6, (ref) v_u_9
	local v40 = v_u_6[p39]
	if v40 then
		return v40
	end
	local v41 = v_u_9
	assert(v41, "Cannot call GetController until Knit has been started")
	local v42 = type(p39) == "string"
	local v43 = ("ControllerName must be a string; got %*"):format((type(p39)))
	assert(v42, v43)
	error(("Could not find controller \"%*\". Check to verify a controller with this name exists."):format(p39), 2)
end
function v3.Start(p44)
	-- upvalues: (ref) v_u_9, (copy) v_u_4, (ref) v_u_2, (copy) v_u_1, (copy) v_u_6, (ref) v_u_10, (copy) v_u_11
	if v_u_9 then
		return v_u_4.reject("Knit already started")
	end
	v_u_9 = true
	if p44 == nil then
		v_u_2 = v_u_1
	else
		local v45 = typeof(p44) == "table"
		local v46 = ("KnitOptions should be a table or nil; got %*"):format((typeof(p44)))
		assert(v45, v46)
		v_u_2 = p44
		for v47, v48 in v_u_1 do
			if v_u_2[v47] == nil then
				v_u_2[v47] = v48
			end
		end
	end
	local v49 = v_u_2.PerServiceMiddleware
	if type(v49) ~= "table" then
		v_u_2.PerServiceMiddleware = {}
	end
	return v_u_4.new(function(p50)
		-- upvalues: (ref) v_u_6, (ref) v_u_4
		local v51 = {}
		for _, v_u_52 in v_u_6 do
			local v53 = v_u_52.KnitInit
			if type(v53) == "function" then
				local v54 = v_u_4.new
				table.insert(v51, v54(function(p55)
					-- upvalues: (copy) v_u_52
					debug.setmemorycategory(v_u_52.Name)
					v_u_52:KnitInit()
					p55()
				end))
			end
		end
		p50(v_u_4.all(v51))
	end):andThen(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_11
		for _, v_u_56 in v_u_6 do
			local v57 = v_u_56.KnitStart
			if type(v57) == "function" then
				task.spawn(function()
					-- upvalues: (copy) v_u_56
					debug.setmemorycategory(v_u_56.Name)
					v_u_56:KnitStart()
				end)
			end
		end
		v_u_10 = true
		v_u_11:Fire()
		task.defer(function()
			-- upvalues: (ref) v_u_11
			v_u_11:Destroy()
		end)
	end)
end
function v3.OnStart()
	-- upvalues: (ref) v_u_10, (copy) v_u_4, (copy) v_u_11
	if v_u_10 then
		return v_u_4.resolve()
	else
		return v_u_4.fromEvent(v_u_11.Event)
	end
end
return v3