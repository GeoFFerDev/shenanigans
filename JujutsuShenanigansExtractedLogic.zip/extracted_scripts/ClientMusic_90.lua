-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game.Players.LocalPlayer.Character
if not (v1 and script.Parent:IsDescendantOf(v1)) then
	script.Parent.RollOffMinDistance = 0
	script.Parent.RollOffMaxDistance = 0
end