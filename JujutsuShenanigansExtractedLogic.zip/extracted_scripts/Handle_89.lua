-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("TweenService")
local v_u_2 = script.Parent.Parent.Parent
local v_u_3 = game.Players:GetPlayerFromCharacter(v_u_2)
if v_u_3 then
	local v_u_4 = {}
	local v_u_5 = script.Parent:WaitForChild("Moveset", 1)
	local function v_u_13(p_u_6, p_u_7)
		-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_1
		if p_u_6:IsA("NumberValue") then
			if v_u_5:FindFirstChild(p_u_6.Name) then
				return
			elseif not v_u_4[p_u_6] then
				local v_u_8 = script:WaitForChild("Item"):Clone()
				v_u_8.Name = p_u_6.Name
				v_u_8.Parent = v_u_5
				v_u_4[p_u_6] = {}
				if p_u_6:GetAttribute("Key") then
					v_u_8.LayoutOrder = p_u_6:GetAttribute("Key")
				end
				local v_u_9 = nil
				v_u_9 = p_u_6.AncestryChanged:Connect(function()
					-- upvalues: (copy) p_u_6, (copy) p_u_7, (copy) v_u_8, (ref) v_u_4, (ref) v_u_9
					if p_u_6.Parent == p_u_7 then
						v_u_8.Parent = script.Parent.Moveset
						return
					elseif p_u_6.Parent then
						v_u_8.Parent = p_u_6
					else
						v_u_8:Destroy()
						v_u_4[p_u_6] = nil
						v_u_9:Disconnect()
					end
				end)
				if p_u_6:GetAttribute("LastUse") then
					p_u_6:GetAttributeChangedSignal("LastUse"):Connect(function()
						-- upvalues: (ref) v_u_4, (copy) p_u_6, (copy) v_u_8, (ref) v_u_1
						v_u_4[p_u_6][1] = tick()
						repeat
							local v10 = p_u_6.Value - (tick() - v_u_4[p_u_6][1])
							local v11 = v10 / p_u_6.Value
							local v12 = math.clamp(v11, 0, 1)
							v_u_8.Cooldown.Size = UDim2.new(1, 0, v12, 0)
							task.wait()
						until v10 <= 0 or not (p_u_6.Parent and (v_u_8.Parent and v_u_4[p_u_6]))
						if v_u_8.Parent and (v_u_4[p_u_6] and v_u_4[p_u_6][1]) then
							if v10 <= 0 then
								v_u_4[p_u_6][1] = nil
							end
							v_u_8.Cooldown.Size = UDim2.new(1, 0, 0, 0)
							v_u_8.BackgroundColor3 = Color3.new(1, 1, 1)
							v_u_1:Create(v_u_8, TweenInfo.new(1), {
								["BackgroundColor3"] = Color3.fromRGB(31, 31, 31)
							}):Play()
						end
					end)
					if v_u_4[p_u_6] and v_u_4[p_u_6][1] then
						p_u_6:SetAttribute("LastUse", tick())
					end
				end
			end
		else
			return
		end
	end
	local v_u_14 = v_u_2:WaitForChild("Moveset")
	if #v_u_14:GetChildren() > 0 then
		for _, v15 in v_u_14:GetChildren() do
			v_u_13(v15, v_u_14)
		end
	end
	v_u_14.ChildAdded:Connect(function(p16)
		-- upvalues: (copy) v_u_13, (copy) v_u_14
		v_u_13(p16, v_u_14)
	end)
	local v_u_17 = script.Parent:WaitForChild("Ult", 1):WaitForChild("Fill", 1)
	local v_u_18 = script.Parent:WaitForChild("Evasive", 1):WaitForChild("Fill", 1)
	v_u_17.Size = UDim2.new(1, 0, v_u_3:GetAttribute("Ultimate") / 100, 0)
	v_u_18.Size = UDim2.new(1, 0, v_u_2:GetAttribute("Evade") / 50, 0)
	v_u_3:GetAttributeChangedSignal("Ultimate"):Connect(function()
		-- upvalues: (copy) v_u_17, (copy) v_u_3
		v_u_17.Size = UDim2.new(1, 0, v_u_3:GetAttribute("Ultimate") / 100, 0)
	end)
	v_u_2:GetAttributeChangedSignal("Evade"):Connect(function()
		-- upvalues: (copy) v_u_18, (copy) v_u_2
		v_u_18.Size = UDim2.new(1, 0, v_u_2:GetAttribute("Evade") / 50, 0)
	end)
end