-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "ExtendSwingController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10
	local v_u_41 = {
		["Swing"] = function(p13, _)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_7.Misc.Swing.Fist, v14, game.SoundService.Effect)
			end
		end,
		["SwingDown"] = function(p15)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_11:PlaySound(v_u_7.Misc.Swing.Fist2, v16, game.SoundService.Effect)
			end
		end,
		["Crush"] = function(p17, p18)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v19 = v_u_6.Itadori.CrushingBlow:Clone()
			v19.Position = p18
			v19.Parent = workspace.Effects
			v_u_3:Create(v19.Air, TweenInfo.new(0.2), {
				["Position"] = Vector3.new(0, 0, 0)
			}):Play()
			v_u_3:Create(v19.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v19.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
			v19.Floor.Glow.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
			v19.Beam.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
			v19.PointLight.Color = Color3.new(1, 1, 0.498039)
			v19.Floor.Glow:Emit(1)
			v19.Floor.Ring:Emit(10)
			v19.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v19, 1.5)
			v_u_11:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v19, game.SoundService.Effect)
			if v_u_4 == p17 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Sweep"] = function(p20)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_11:PlaySound(v_u_7.Misc.Swing.Fist3, v21, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p22)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			if v23 then
				v_u_11:Flash(p22, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit1"), v23, game.SoundService.Effect)
			end
		end,
		["Hit2"] = function(p24)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				local v26 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v26.Parent = v25.RootAttachment
				v26:Emit(20)
				v_u_2:AddItem(v26, 0.4)
				v_u_11:Flash(p24, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit1"), v25, game.SoundService.Effect)
			end
		end,
		["Hit3"] = function(p27, p28)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				v_u_11:Flash(p28, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Megumi.Elephant.Hit, v29, game.SoundService.Effect)
				if v_u_4 == p27 or v_u_4.Character == p28 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["SweepMiss"] = function(p30)
			-- upvalues: (ref) v_u_11
			if p30:FindFirstChild("HumanoidRootPart") then
				v_u_11:Flash(p30, Color3.new(0.3, 1, 0), 0.2)
			end
		end,
		["SweepHit"] = function(p31, p32)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v33 = p32:FindFirstChild("HumanoidRootPart")
			if v33 then
				v_u_11:Flash(p32, Color3.new(1, 0, 0))
				v_u_11:PlaySound(v_u_7.Hiromi.Sweep, v33, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Gojo.Teleport, v33, game.SoundService.Effect)
				local v34 = v_u_6.Hiromi.BlockBreak:Clone()
				v34.Parent = v33
				v34:Emit(20)
				v_u_2:AddItem(v34, 0.6)
				if v_u_4 == p31 or v_u_4.Character == p32 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Finisher"] = function(p35)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v36 = p35:FindFirstChild("HumanoidRootPart")
			if v36 then
				if p35.Parent then
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, p35, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_7.Megumi.Elephant.Explode, v36, game.SoundService.Effect)
					p35.Head.Transparency = 1
					local v37 = p35.Head:FindFirstChildWhichIsA("Decal")
					if v37 then
						v37.Transparency = 1
					end
					for _, v38 in p35:GetChildren() do
						if v38:IsA("Accessory") then
							local v39 = v38:FindFirstChild("Handle", true)
							if v39:FindFirstChild("HairAttachment") or (v39:FindFirstChild("HatAttachment") or (v39:FindFirstChild("FaceCenterAttachment") or v39:FindFirstChild("FaceFrontAttachment"))) then
								v38:Destroy()
							end
						end
					end
					v_u_11:Bleed(p35)
					for _ = 1, 40 do
						v_u_9:Blood(p35.Head.CFrame, 50, 360, 360)
					end
					if _G.Settings.Gore then
						local v40 = v_u_6.Heian.BloodSpread:Clone()
						v40.Parent = p35.Head
						v40:Emit(20)
						v_u_2:AddItem(v40, 2)
					end
					if v_u_4:DistanceFromCharacter(v36.Position) < 40 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p42, ...)
		-- upvalues: (copy) v_u_41
		local v43 = v_u_41[p42]
		if v43 then
			v43(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("ExtendSwingService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12