-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "IdleTransfigurationController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_6, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10
	local v_u_78 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_12:Flash(p14, Color3.fromRGB(170, 85, 255), 1)
				v_u_12:PlaySound(v_u_8.Mahito.Transfig.Start, v15, game.SoundService.Effect)
			end
		end,
		["Flash"] = function(p16)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_12:PlaySound(v_u_8.Mahito.Transfig.Eyes, v17, game.SoundService.Effect)
				local v18 = v_u_7.Mahito.EyeGlow:Clone()
				v18.Weld.Part0 = p16.Head
				v18.Parent = workspace.Effects
				v_u_3:AddItem(v18, 1)
				v18.Eye1.Glow:Emit(1)
				v18.Eye2.Glow:Emit(1)
				v18.Glow:Emit(1)
				task.wait(0.8)
				v18.Trail1.Trail.Enabled = false
				v18.Trail2.Trail.Enabled = false
			end
		end,
		["Dash"] = function(p19, p_u_20)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9, (ref) v_u_2
			local v_u_21 = p19:FindFirstChild("HumanoidRootPart")
			if v_u_21 then
				v_u_12:PlaySound(v_u_8.Itadori.Rush.Rush, v_u_21, game.SoundService.Effect)
				local v22 = v_u_6.Utils.Itadori.RushWind:Clone()
				v22.CFrame = v_u_21.CFrame
				v22.Parent = workspace.Effects
				v22.Dust:Emit(7)
				v22.Ring:Emit(7)
				v22.Dash1.Dash:Emit(1)
				v22.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v22, 2)
				local v23 = v_u_7.Itadori.Shock:Clone()
				v23.CFrame = v_u_21.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v23.Parent = workspace.Effects
				v_u_4:Create(v23, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v23, 0.2)
				task.delay(0.1, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_21, (ref) v_u_4, (ref) v_u_3, (copy) p_u_20
					local v24 = v_u_7.Itadori.Shock:Clone()
					v24.CFrame = v_u_21.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v24.Parent = workspace.Effects
					v_u_4:Create(v24, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v24, 0.2)
					local v25 = tick()
					while true do
						if v25 < tick() then
							v25 = tick() + math.random(8, 14) / 100
							local v_u_26 = v_u_7.Mahito.BodyRepel["Wind" .. math.random(1, 5)]:Clone()
							local v27 = v_u_21.CFrame
							local v28 = CFrame.Angles
							local v29 = math.random(0, 360)
							v_u_26.CFrame = v27 * v28(1.5707963267948966, math.rad(v29), 0)
							v_u_26.Size = Vector3.new(6, 6, 6)
							v_u_4:Create(v_u_26, TweenInfo.new(0.3, Enum.EasingStyle.Quad), {
								["CFrame"] = v_u_26.CFrame + v_u_21.CFrame.LookVector * 3,
								["Size"] = Vector3.new(7, 0, 7)
							}):Play()
							v_u_3:AddItem(v_u_26, 0.3)
							v_u_26.Parent = workspace.Effects
							v_u_4:Create(v_u_26, TweenInfo.new(0.15), {
								["Transparency"] = 0.5
							}):Play()
							task.delay(0.15, function()
								-- upvalues: (ref) v_u_4, (copy) v_u_26
								v_u_4:Create(v_u_26, TweenInfo.new(0.15), {
									["Transparency"] = 1
								}):Play()
							end)
						end
						task.wait()
						if not (p_u_20.Parent and v_u_21.Parent) then
							return
						end
					end
				end)
				if v_u_5.Character == p19 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v30 = Instance.new("NumberValue", p_u_20)
					v30.Value = 200
					v_u_4:Create(v30, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["Value"] = 50
					}):Play()
					repeat
						p_u_20.Velocity = v_u_21.CFrame.LookVector * v30.Value
						v_u_2.Stepped:Wait()
					until not (p_u_20.Parent and v_u_21.Parent)
				end
			end
		end,
		["Hit"] = function(p31, p32)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9, (ref) v_u_4
			local v33 = p32:FindFirstChild("HumanoidRootPart")
			if v33 then
				v_u_12:Flash(p32, Color3.fromRGB(170, 85, 255), 3)
				v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Hit1, v33, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Mahito.Soulfire.Morph, v33, game.SoundService.Effect)
				local v34 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
				v34.Position = v33.Position
				v34.Parent = workspace.Effects
				v_u_3:AddItem(v34, 1)
				v34.Sparks:Emit(50)
				v34.Wind:Emit(7)
				v34.Wind2:Emit(7)
				if v_u_5 == p31 or v_u_5.Character == p32 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					local v35 = v_u_7.Hakari.IdleDeath.AudioVis:Clone()
					v35.Beat.ImageTransparency = 0
					v35.Beat.ImageColor3 = Color3.fromRGB(170, 85, 255)
					v35.Parent = v_u_5.PlayerGui
					v_u_3:AddItem(v35, 0.6)
					local v36 = Instance.new("PointLight")
					v36.Brightness = 20
					v36.Range = 15
					v36.Color = Color3.fromRGB(170, 85, 255)
					v36.Parent = v34
					local v37 = Instance.new("Highlight")
					v37.FillTransparency = 1
					v37.DepthMode = Enum.HighlightDepthMode.Occluded
					v37.Parent = p32
					v_u_4:Create(v37, TweenInfo.new(0.8), {
						["OutlineTransparency"] = 1
					}):Play()
					v_u_3:AddItem(v37, 0.8)
					v_u_4:Create(game.Lighting, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["ExposureCompensation"] = -4
					}):Play()
					v_u_4:Create(v36, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Brightness"] = 90
					}):Play()
					v_u_4:Create(v35.Beat, TweenInfo.new(0.2, Enum.EasingStyle.Quad), {
						["Size"] = UDim2.new(1.3, 0, 1.3, 0),
						["ImageTransparency"] = 0
					}):Play()
					task.wait(0.2)
					v_u_4:Create(v35.Beat, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Size"] = UDim2.new(2, 0, 2, 0),
						["ImageTransparency"] = 1
					}):Play()
					task.wait(0.1)
					v_u_4:Create(game.Lighting, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["ExposureCompensation"] = 0
					}):Play()
					v_u_4:Create(v36, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Brightness"] = 0
					}):Play()
				end
			end
		end,
		["HitFinish"] = function(p38, p39)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v40 = p39:FindFirstChild("HumanoidRootPart")
			if v40 then
				local v41 = v_u_7.Mahito.FocusHit.Burst:Clone()
				if p39:GetAttribute("Moveset") == "Nanami" then
					local v42 = Instance.new("Model")
					local v43 = Instance.new("Part")
					v43.Parent = v42
					v41.Parent = v43
					v42:ScaleTo(1.5)
					v_u_3:AddItem(v42, 0.2)
				end
				v41.Parent = v40
				v41.Glow:Emit(1)
				v41.Wind2:Emit(10)
				v_u_3:AddItem(v41, 0.7)
				v_u_12:PlaySound(v_u_8.Mahito.Slap, v40, game.SoundService.Effect)
				if v_u_5.Character == p38 or v_u_5.Character == p39 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["Finisher"] = function(p_u_44)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v_u_45 = p_u_44:FindFirstChild("HumanoidRootPart")
			if v_u_45 then
				local v_u_46 = p_u_44:GetAttribute("Moveset") == "Nanami"
				local v_u_47 = v_u_7.Mahito.FocusHit.Burst:Clone()
				if v_u_46 then
					local v48 = Instance.new("Model")
					local v49 = Instance.new("Part")
					v49.Parent = v48
					v_u_47.Parent = v49
					v48:ScaleTo(1.5)
					v_u_3:AddItem(v48, 0.2)
				end
				v_u_47.Parent = v_u_45
				task.delay(0.3, function()
					-- upvalues: (copy) v_u_45, (ref) v_u_12, (ref) v_u_8, (copy) v_u_47
					if v_u_45.Parent then
						v_u_12:PlaySound(v_u_8.Itadori.Rush.RushBreak, v_u_45, game.SoundService.Effect)
						v_u_47.Glow:Emit(1)
						task.wait(0.3)
						v_u_47.Wind:Emit(10)
						v_u_47.Wind2:Emit(10)
					end
				end)
				local v_u_50 = v_u_46 and p_u_44.Torso or p_u_44.Head
				for _ = 1, 7 do
					local v_u_51 = v_u_7.Mahito.Morph:Clone()
					v_u_51.Weld.Part0 = v_u_50
					v_u_51.Color = v_u_50.Color
					v_u_51.Material = v_u_50.Material
					v_u_51.Weld.C1 = CFrame.new(math.random(-v_u_50.Size.X, v_u_50.Size.X) / 2, math.random(-v_u_50.Size.Y, v_u_50.Size.Y) / 2, math.random(-v_u_50.Size.Z, v_u_50.Size.Z) / 2)
					v_u_51.Parent = workspace.Effects
					local v52 = math.random(10, 20) / (v_u_46 and 6 or 10)
					v_u_51.Size = Vector3.new(0, 0, 0)
					v_u_4:Create(v_u_51, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(1, 1, 1) * v52
					}):Play()
					v_u_3:AddItem(v_u_51, 1.5)
					task.delay(0.6, function()
						-- upvalues: (copy) v_u_51, (ref) v_u_4
						v_u_51.Weld:Destroy()
						local v53 = v_u_51
						local v54 = math.random(-40, 40)
						local v55 = math.random(-20, 40)
						local v56 = math.random
						v53.Velocity = Vector3.new(v54, v55, v56(-40, 40))
						v_u_4:Create(v_u_51, TweenInfo.new(0.5), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
				task.delay(0.6, function()
					-- upvalues: (copy) p_u_44, (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (copy) v_u_50, (ref) v_u_3, (copy) v_u_46, (ref) v_u_5, (copy) v_u_45, (ref) v_u_9
					if p_u_44.Parent then
						local v57 = v_u_12:PlaySound(v_u_8.Itadori.Dismantle.Explode, p_u_44, game.SoundService.Effect)
						v57.RollOffMaxDistance = 400
						v57.RollOffMinDistance = 100
						for _ = 1, 10 do
							local v58 = v_u_7.Damage.Chunk:Clone()
							v58.CFrame = v_u_50.CFrame
							v58.Blood.Enabled = false
							local v59 = math.random(-60, 60)
							local v60 = math.random(-30, 60)
							local v61 = math.random
							v58.Velocity = Vector3.new(v59, v60, v61(-60, 60))
							local v62 = math.random(-200, 200)
							local v63 = math.random(-200, 200)
							local v64 = math.random
							v58.RotVelocity = Vector3.new(v62, v63, v64(-200, 200))
							v58.Parent = workspace.Effects
							v_u_3:AddItem(v58, 1)
							if _G.Settings.Gore == false then
								v58.Color = Color3.fromRGB(255, 85, 255)
								v58.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
							end
						end
						if v_u_46 then
							p_u_44.Torso.Transparency = 1
							p_u_44["Left Arm"].Transparency = 1
							p_u_44["Right Arm"].Transparency = 1
						end
						p_u_44.Head.Transparency = 1
						local v65 = p_u_44.Head:FindFirstChildWhichIsA("Decal")
						if v65 then
							v65.Transparency = 1
						end
						for _, v66 in p_u_44:GetChildren() do
							if v66:IsA("Accessory") then
								local v67 = v66:FindFirstChild("Handle", true)
								if v67:FindFirstChild("HairAttachment") or (v67:FindFirstChild("HatAttachment") or (v67:FindFirstChild("FaceCenterAttachment") or (v67:FindFirstChild("FaceFrontAttachment") or v_u_46 and v67:FindFirstChild("NeckAttachment")))) or v_u_46 and v67:FindFirstChild("BodyBackAttachment") then
									v66:Destroy()
								end
							end
						end
						if p_u_44:FindFirstChild("SetAssets") and v_u_46 then
							p_u_44.SetAssets:Destroy()
						end
						if v_u_5:DistanceFromCharacter(v_u_45.Position) < 40 then
							v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
						end
					end
				end)
			end
		end,
		["BlackFlashImpact"] = function(p68, p69)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7
			if p68:FindFirstChild("HumanoidRootPart") then
				local v70 = p69:FindFirstChild("HumanoidRootPart")
				if v70 then
					v_u_12:Flash(p69, Color3.new(1, 0, 0))
					v_u_12:PlaySound(v_u_8.Itadori.DivergentFist.BlackFlashHit, v70, game.SoundService.Effect)
					if v_u_5.Character == p68 or v_u_5.Character == p69 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						local v71 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v71.Parent = game.Lighting
						task.wait(0.04)
						v71.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v71.Brightness = 200
						v71.Contrast = -1000
						task.wait(0.04)
						v71:Destroy()
					end
				end
			else
				return
			end
		end,
		["BlackFlashHit"] = function(p72, p73)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v74 = p72:FindFirstChild("HumanoidRootPart")
			if v74 then
				local v75 = p73:FindFirstChild("HumanoidRootPart")
				if v75 then
					local v76 = v_u_7.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					v76.CFrame = v74.CFrame * CFrame.new(2, 1, -5)
					v76.Parent = workspace.Effects
					v76.Wind:Emit(20)
					v76.Sparks:Emit(20)
					v76.Flare:Emit(20)
					v76.Lightning:Emit(25)
					v76.Back1.Back:Emit(1)
					v76.Back2.Back:Emit(1)
					v_u_4:Create(v76.Back1, TweenInfo.new(2), {
						["CFrame"] = v76.Back1.CFrame - v76.Back1.CFrame.LookVector * 20
					}):Play()
					v_u_4:Create(v76.Back2, TweenInfo.new(2), {
						["CFrame"] = v76.Back2.CFrame - v76.Back2.CFrame.LookVector * 20
					}):Play()
					v_u_4:Create(v76.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					v_u_3:AddItem(v76, 3)
					v_u_12:Flash(p73, Color3.new(1, 0, 0), 2)
					v_u_12:PlaySound(v_u_8.Mahito.BlackFlash, v75, game.SoundService.Effect)
					if v_u_5.Character == p72 or v_u_5.Character == p73 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						local v77 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v77.Parent = game.Lighting
						task.wait(0.04)
						v77.Brightness = 200
						v77.Contrast = -1000
						task.wait(0.04)
						v77.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v77.Brightness = -200
						v77.Contrast = 1000
						task.wait(0.04)
						v77:Destroy()
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p79, ...)
		-- upvalues: (copy) v_u_78
		local v80 = v_u_78[p79]
		if v80 then
			v80(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("IdleTransfigurationService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13