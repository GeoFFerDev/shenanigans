-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("TweenService")
game:GetService("Debris")
local v2 = script.Parent:GetAttribute("Jackpot")
local v3 = script.Parent:GetAttribute("Speed")
local v4 = script.Parent.Yuuki.Humanoid:LoadAnimation(script.Animation)
v4:Play(0, nil, v3)
if v2 == false then
	v4.TimePosition = 7
	task.wait(3 / v3)
	v1:Create(script.Parent.Door1, TweenInfo.new(1), {
		["Orientation"] = script.Parent.Door1.Orientation + Vector3.new(0, -90, 0)
	}):Play()
	v1:Create(script.Parent.Door2, TweenInfo.new(1), {
		["Orientation"] = script.Parent.Door1.Orientation + Vector3.new(0, 90, 0)
	}):Play()
	task.wait(1 / v3)
	local v5 = Instance.new("Highlight")
	v5.FillColor = Color3.new(0, 0, 0)
	v5.FillTransparency = 1
	v5.OutlineTransparency = 1
	v5.DepthMode = Enum.HighlightDepthMode.Occluded
	v5.Parent = script.Parent
	v1:Create(v5, TweenInfo.new(1 / v3), {
		["FillTransparency"] = 0.5
	}):Play()
end