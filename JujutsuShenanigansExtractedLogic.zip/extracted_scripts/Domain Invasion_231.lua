-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
function v1.Start(_, p_u_5, p6)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_3
	if p_u_5.Character then
		local v_u_7 = script.Domain:Clone()
		v_u_7.Parent = workspace.Effects
		table.insert(p6, v_u_7)
		task.spawn(function()
			-- upvalues: (copy) p_u_5, (copy) v_u_7
			local v8
			if p_u_5.Character then
				v8 = p_u_5.Character.Humanoid:GetAppliedDescription()
			else
				v8 = game.Players:GetHumanoidDescriptionFromUserId(p_u_5.UserId)
			end
			v_u_7.Rig.Humanoid:ApplyDescriptionReset(v8)
		end)
		local v9 = script.SFX:Clone()
		v9.SoundGroup = game.SoundService.Effect
		v9.Parent = workspace
		table.insert(p6, v9)
		local v10 = v_u_7.Rig.Humanoid:LoadAnimation(script.Character)
		local v11 = v_u_7.Camera.Humanoid:LoadAnimation(script.Camera)
		v10:Play(0, nil, 0)
		table.insert(p6, v10)
		v11:Play(0, nil, 0)
		table.insert(p6, v11)
		task.wait(2.5)
		v_u_4.PlayerGui.Main.Enabled = false
		local v_u_12 = workspace.CurrentCamera
		v_u_12.CameraType = Enum.CameraType.Scriptable
		local v13 = v_u_2.RenderStepped
		table.insert(p6, v13:Connect(function()
			-- upvalues: (copy) v_u_12, (copy) v_u_7
			v_u_12.FieldOfView = 40
			v_u_12.CFrame = v_u_7.Camera.Torso.CFrame
			local v14 = v_u_12.CFrame.Position + v_u_12.CFrame.LookVector * 500
			v_u_7.BG.BG.CFrame = CFrame.new(v14, v_u_12.CFrame.Position) * CFrame.Angles(0, 3.141592653589793, 0)
		end))
		local v15 = tick() + 0.25
		repeat
			task.wait()
		until v10.Length > 0 and (v11.Length > 0 and v9.IsLoaded) or v15 < tick()
		v10:AdjustSpeed(1)
		v11:AdjustSpeed(1)
		v9:Play()
		local v16 = script.DepthOfField:Clone()
		v16.Parent = game.Lighting
		table.insert(p6, v16)
		v_u_7.BG.BG.Clouds:Emit(200)
		v_u_7.BG.Water.Attachment2.ShadowSpark:Emit(100)
		v_u_3:Create(v_u_7.BG.Water.Attachment.Shadow, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
			["TimeScale"] = 0.04
		}):Play()
		v_u_3:Create(v_u_7.BG.Water.Attachment2.ShadowSpark, TweenInfo.new(1.5, Enum.EasingStyle.Exponential), {
			["TimeScale"] = 0.08,
			["Rate"] = 0
		}):Play()
		task.wait(2)
		v_u_7.BG.BG.Clouds:Clear()
		v_u_7.BG.BG.Clouds:Emit(200)
		v10:AdjustSpeed(0.9)
		v11:AdjustSpeed(0.9)
		task.wait(4.5)
		v10:AdjustSpeed(0)
		v11:AdjustSpeed(0)
		v_u_7.BG.BG.Clouds.TimeScale = 0
		v_u_7.BG.Water.Attachment.Shadow.TimeScale = 0
		v_u_7.BG.Water.Attachment2.ShadowSpark.TimeScale = 0
	end
end
return v1