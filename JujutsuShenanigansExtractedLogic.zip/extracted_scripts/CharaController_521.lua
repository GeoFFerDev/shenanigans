-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
local v_u_11 = require(v6.Modules.SraikoVFX)
require(v6.TEMP_CHARA_STUFF.VelocityHandler)
local v_u_12 = require(v6.TEMP_CHARA_STUFF.AnimationRetriever)
local v_u_13 = require(v6.TEMP_CHARA_STUFF.EffectUtility)
local v_u_14 = require(v6.TEMP_CHARA_STUFF.CameraShake)
local v_u_15 = require(v6.TEMP_CHARA_STUFF.Vignette)
local v_u_16 = require(v6.TEMP_CHARA_STUFF.RockHandler)
require(v6.TEMP_CHARA_STUFF.Smoke)
require(v6.TEMP_CHARA_STUFF.Afterimage)
require(v6.TEMP_CHARA_STUFF.MoonUtil)
local v_u_17 = require(v6.TEMP_CHARA_STUFF.RunCameraRig)
require(v6.TEMP_CHARA_STUFF.Create_Clone)
local v_u_18 = require(v6.TEMP_CHARA_STUFF.VelocityUtil)
local v_u_19 = require(v6.TEMP_CHARA_STUFF.Utility)
local v_u_20 = require(v6.TEMP_CHARA_STUFF.Yuki_FOV)
local v_u_21 = require(script.Parent.FightController.Finisher.quickutil)
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
local v25 = v_u_1.CreateController({
	["Name"] = "CharaController"
})
local function v_u_30(p26, p27)
	-- upvalues: (copy) v_u_3
	local v28 = p26:Clone()
	v28.Parent = p27
	for _, v29 in v28:GetDescendants() do
		if v29:IsA("ParticleEmitter") then
			v29:Emit(v29:GetAttribute("EmitCount"))
		end
	end
	v_u_3:AddItem(v28, 2)
	return v28
end
local function v_u_35(p31, p32)
	local v33 = p32 and 1 or 0
	for _, v34 in ipairs(p31:GetDescendants()) do
		if v34:IsA("BasePart") then
			v34.Transparency = v33
		end
	end
end
local v_u_36 = Random.new()
function v25.KnitStart(_)
	-- upvalues: (copy) v_u_8, (copy) v_u_4, (copy) v_u_36, (copy) v_u_2, (copy) v_u_30, (ref) v_u_24, (copy) v_u_9, (copy) v_u_5, (copy) v_u_10, (copy) v_u_3, (copy) v_u_11, (copy) v_u_7, (copy) v_u_16, (copy) v_u_12, (copy) v_u_13, (copy) v_u_21, (copy) v_u_18, (copy) v_u_19, (copy) v_u_17, (copy) v_u_35, (copy) v_u_14, (copy) v_u_15, (copy) v_u_20, (ref) v_u_22, (ref) v_u_23
	local v_u_190 = {
		["DMG"] = function(p37, p38, p39)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_36, (ref) v_u_2
			if p38.Info:FindFirstChild("DefenseDebuff") then
				p39 = p39 * 1.3
			end
			local v40 = p37.Info:FindFirstChild("DMG_M")
			if v40 then
				p39 = p39 * (1 + v40.Value)
			end
			local v_u_41 = v_u_8.Misc.C.UI:Clone()
			v_u_41.Name = "CharaDamageIndicator"
			local v42 = v_u_41.Value
			local v43 = p39 * 10
			local v44 = math.round(v43) / 10
			v42.Text = tostring(v44)
			v_u_41.Value.TextTransparency = 1
			v_u_41.Value.UIStroke.Transparency = 1
			v_u_41.Parent = p38:FindFirstChild("Torso")
			v_u_4:Create(v_u_41.Value, TweenInfo.new(0.25), {
				["TextTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_41.Value.UIStroke, TweenInfo.new(0.25), {
				["Transparency"] = 0
			}):Play()
			local v_u_45 = v_u_36:NextNumber(-3, 3)
			local v_u_46 = v_u_36:NextNumber(-0.75, 1.25)
			local v_u_47 = math.random()
			local v_u_48 = math.random()
			local v_u_49 = math.random()
			local v_u_50 = tick()
			local v_u_51 = 0
			local v_u_52 = 1.5
			local v_u_61 = v_u_2.PreRender:Connect(function(p53)
				-- upvalues: (ref) v_u_51, (copy) v_u_50, (copy) v_u_47, (copy) v_u_48, (copy) v_u_49, (ref) v_u_52, (ref) v_u_4, (copy) v_u_41, (copy) v_u_45, (copy) v_u_46
				v_u_51 = v_u_51 + p53
				local v54 = math.noise(v_u_50 + v_u_47, v_u_51 * 7.15 + v_u_48, v_u_49) * 1.7 * v_u_52
				local v55 = math.noise(v_u_50 + v_u_47, -v_u_51 * 7.19 + v_u_49, v_u_48) * 1.7 * v_u_52
				local v56 = v_u_4
				local v57 = v_u_51 * 1.6666666666666667
				v_u_52 = 1 - v56:GetValue(math.clamp(v57, 0, 1), Enum.EasingStyle.Cubic, Enum.EasingDirection.Out)
				local v58 = v_u_41
				local v59 = v_u_45 + v54
				local v60 = v_u_46 + v55
				v58.StudsOffsetWorldSpace = Vector3.new(v59, v60)
			end)
			v_u_41.Destroying:Once(function()
				-- upvalues: (copy) v_u_61
				v_u_61:Disconnect()
			end)
			task.delay(1.5, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_41
				v_u_4:Create(v_u_41.Value, TweenInfo.new(0.75), {
					["TextTransparency"] = 1
				}):Play()
				v_u_4:Create(v_u_41.Value.UIStroke, TweenInfo.new(0.75), {
					["Transparency"] = 1
				}):Play()
				task.delay(0.75, v_u_41.Destroy, v_u_41)
			end)
		end,
		["Hit"] = function(p62, p63, p64)
			-- upvalues: (ref) v_u_30, (ref) v_u_8, (ref) v_u_24
			local v65 = p62:FindFirstChild("HumanoidRootPart")
			if v65 then
				if p63 == 1 or p63 == 3 then
					v_u_30(v_u_8.Misc.C.M1.Hit1, p62.HumanoidRootPart)
				elseif p63 == 2 or p64 == "Up" then
					local v66 = v_u_30(v_u_8.Misc.C.M1.slashed, p62.HumanoidRootPart)
					local v67 = v66.CFrame
					local v68 = CFrame.fromOrientation
					local v69 = p64 == "Up" and 55 or 0
					v66.CFrame = v67 * v68(0, 0, (math.rad(v69)))
				end
				v_u_24:PlaySound(script.M1s[p64 or p63], v65, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p70, p71)
			-- upvalues: (ref) v_u_24, (ref) v_u_30, (ref) v_u_8
			local v72 = p70:FindFirstChild("HumanoidRootPart")
			if v72 then
				local v73 = p71:FindFirstChild("HumanoidRootPart")
				if v73 then
					v_u_24:PlaySound(script.M1s[2], v72, game.SoundService.Effect)
					local v74 = v_u_30(v_u_8.Misc.C.M1.slashed, v73)
					v74.CFrame = v74.CFrame * CFrame.fromOrientation(0, 0, 0.9599310885968813)
				end
			else
				return
			end
		end,
		["AerialHit"] = function(p75, p76)
			-- upvalues: (ref) v_u_24, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_8, (ref) v_u_3
			local v77 = p75:FindFirstChild("HumanoidRootPart")
			if v77 then
				local v78 = p76:FindFirstChild("HumanoidRootPart")
				if v78 then
					v_u_24:Flash(p76, Color3.new(1, 1, 1))
					v_u_24:PlaySound(v_u_9.Itadori.CraniumSmash.Hit2, v78, game.SoundService.Effect)
					if v_u_5.Character == p75 or v_u_5.Character == p76 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					end
					local v79 = CFrame.new(v77.Position, v78.Position - Vector3.new(0, 4, 0))
					local v80 = v_u_8.Gojo.HardHit:Clone()
					v80.CFrame = v79 + v79.LookVector * 4
					v80.Parent = workspace.Effects
					v80.Dust:Emit(5)
					v80.Ring:Emit(5)
					v80.Sparks:Emit(10)
					v_u_3:AddItem(v80, 0.5)
				end
			else
				return
			end
		end,
		["PossessStart"] = function(p81)
			-- upvalues: (ref) v_u_24, (ref) v_u_10
			local v82 = p81:FindFirstChild("HumanoidRootPart")
			if v82 then
				v_u_24:PlaySound(script.Possess, v82, game.SoundService.Effect)
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
				v_u_24:Flash(p81, Color3.new(1, 0, 0), 2)
			end
		end,
		["FirstPossess"] = function(p_u_83)
			-- upvalues: (ref) v_u_24, (ref) v_u_11, (ref) v_u_3, (ref) v_u_10, (ref) v_u_4
			local v_u_84 = p_u_83:FindFirstChild("HumanoidRootPart")
			if v_u_84 then
				v_u_24:PlaySound(script.FirstPossess, v_u_84, game.SoundService.Effect)
				task.delay(0.667, function()
					-- upvalues: (ref) v_u_11, (copy) v_u_84
					v_u_11.Emit(script.PossessStart.VFX.Boom.Emit.VFX, v_u_84.CFrame, false, 2)
				end)
				task.delay(1.633, function()
					-- upvalues: (ref) v_u_11, (copy) v_u_84
					v_u_11.Emit(script.PossessStart.VFX.DustLand.Emit.VFX, v_u_84.CFrame, false, 2)
					v_u_11.EmitMesh(script.PossessStart.VFX.OpenMeshes.Startupgut.Mesh, v_u_84.CFrame * script.PossessStart.VFX.OpenMeshes.Startupgut.Mesh.Offset.Value)
				end)
				local v_u_85 = script.UI:Clone()
				v_u_85.Enabled = true
				v_u_85.Parent = v_u_84
				v_u_3:AddItem(v_u_85, 8.4)
				task.spawn(function()
					-- upvalues: (ref) v_u_24, (copy) v_u_84, (copy) v_u_85
					v_u_24:PlaySound(script.Talk, v_u_84, game.SoundService.Effect)
					for v86 = 1, 20 do
						v_u_85.Frame.Line1.Text = string.sub("* You found the Worn", 1, v86)
						task.wait(0.04)
					end
					for v87 = 1, 7 do
						v_u_85.Frame.Line2.Text = string.sub("Dagger.", 1, v87)
						task.wait(0.04)
					end
				end)
				task.delay(3.883, function()
					-- upvalues: (ref) v_u_11, (copy) v_u_84, (ref) v_u_10, (ref) v_u_4, (copy) v_u_85, (ref) v_u_24, (copy) p_u_83, (ref) v_u_3
					v_u_11.Emit(script.PossessStart.VFX.Prep.Emit.VFX, v_u_84.CFrame, false, 2)
					task.wait(0.1)
					v_u_11.Emit(script.PossessStart.VFX.Start.Emit.VFX, v_u_84.CFrame, false, 2)
					if (workspace.CurrentCamera.CFrame.Position - v_u_84.Position).Magnitude < 200 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
						workspace.CurrentCamera.FieldOfView = 120
						v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
							["FieldOfView"] = 70
						}):Play()
					end
					v_u_85.Frame.Line1.TextColor3 = Color3.new(1, 0, 0)
					v_u_85.Frame.Line2.TextColor3 = Color3.new(1, 0, 0)
					v_u_85.Frame.Line1.Text = "* You found the Real"
					v_u_85.Frame.Line2.Text = "Knife."
					task.delay(3, function()
						-- upvalues: (ref) v_u_24, (ref) v_u_84, (ref) v_u_85
						local v88 = v_u_24:PlaySound(script.Talk, v_u_84, game.SoundService.Effect)
						v_u_85.Frame.Line2.Text = ""
						for v89 = 1, 11 do
							v_u_85.Frame.Line1.Text = string.sub("About time.", 1, v89)
							task.wait(0.04)
						end
						v88:Destroy()
					end)
					local v90 = script.PossessStart.VFX.GroundCircle:Clone()
					v90.Position = p_u_83.Torso.Position - Vector3.new(0, 2, 0)
					v90.Parent = workspace.Effects
					v_u_3:AddItem(v90, 1)
					task.wait(0.6)
					for _, v91 in v90:GetDescendants() do
						if v91:IsA("ParticleEmitter") then
							v91.Enabled = false
						end
					end
				end)
				task.delay(4.7, function()
					-- upvalues: (ref) v_u_11, (copy) v_u_84
					v_u_11.Emit(script.PossessStart.VFX.Slam.Emit.VFX, v_u_84.CFrame, false, 2)
				end)
				task.delay(7.067, function()
					-- upvalues: (copy) p_u_83, (ref) v_u_11, (copy) v_u_84
					local v92 = p_u_83.SetAssets:FindFirstChild("RealKnife")
					if v92 then
						for _, v93 in v92.BladeInner.knife_point:GetDescendants() do
							if v93:IsA("ParticleEmitter") then
								v93:Emit(v93:GetAttribute("EmitCount"))
							end
						end
						task.wait(0.1)
						v_u_11.EmitMesh(script.PossessStart.VFX.Spin.Startupgut.Mesh, v_u_84.CFrame * script.PossessStart.VFX.Spin.Startupgut.Mesh.Offset.Value)
					end
				end)
			end
		end,
		["PossessEnd"] = function(p94)
			-- upvalues: (ref) v_u_7, (ref) v_u_24, (ref) v_u_10, (ref) v_u_11, (ref) v_u_3, (ref) v_u_4
			local v95 = script.Parent.ResetController.Chara:Clone()
			v95.HumanoidRootPart.CFrame = p94
			for _, v96 in v95:GetDescendants() do
				if v96:IsA("BasePart") then
					v96.CollisionGroup = "Effects"
				end
			end
			v95.Parent = workspace.Effects
			local v97 = Instance.new("Highlight")
			v97.DepthMode = Enum.HighlightDepthMode.Occluded
			v97.FillColor = Color3.fromRGB(38, 82, 98)
			v97.FillTransparency = 5
			v97.OutlineColor = Color3.fromRGB(234, 0, 0)
			v97.OutlineTransparency = 0
			v97.Parent = v95
			for _, v98 in v95:GetChildren() do
				if v98:IsA("BasePart") and v98.Transparency ~= 1 then
					for _, v99 in script.PossessEnd.Aura:GetChildren() do
						v99:Clone().Parent = v98
					end
				end
			end
			local v100 = script.PossessEnd.Heart:Clone()
			v100.PrimaryPart.CFrame = v95.HumanoidRootPart.CFrame
			v100.Parent = v95
			local v_u_101 = v95.Humanoid:LoadAnimation(v_u_7.Misc.C.PossessEnd.User)
			local v_u_102 = v100.AnimationController:LoadAnimation(v_u_7.Misc.C.PossessEnd.Heart)
			v_u_101:Play(0)
			v_u_102:Play(0)
			v_u_101.Looped = false
			task.delay(1, function()
				-- upvalues: (copy) v_u_102, (copy) v_u_101
				v_u_102.TimePosition = v_u_101.TimePosition
			end)
			v_u_24:PlaySound(script.PossessEnd.SFX, workspace, game.SoundService.Effect)
			v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			task.wait(4.75)
			local v103 = script.PossessEnd.Heart2:Clone()
			v103.Parent = v95.Torso
			task.wait(2)
			v103:Destroy()
			v_u_11.Emit(script.PossessEnd.VFX.Boom.Emit.VFX, v95.HumanoidRootPart.CFrame, false, 2)
			v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			task.wait(5.95)
			v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
			local v104 = script.PossessEnd.VFX.GroundCircle:Clone()
			v104.Position = v95.Torso.Position - Vector3.new(0, 2, 0)
			v104.Parent = workspace.Effects
			v_u_3:AddItem(v104, 7)
			v_u_101:AdjustSpeed(0.5)
			v_u_102:AdjustSpeed(0)
			task.wait(2.4)
			v95:Destroy()
			for _, v105 in v104:GetDescendants() do
				if v105:IsA("ParticleEmitter") then
					v105.Enabled = false
				end
			end
			v104.UI.Enabled = true
			v_u_4:Create(v104.UI, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["StudsOffsetWorldSpace"] = Vector3.new(0, 0, -5.5)
			}):Play()
			v_u_4:Create(v104.UI.Value.UIStroke, TweenInfo.new(0.5), {
				["Transparency"] = 1
			}):Play()
			v_u_4:Create(v104.UI.Value, TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
				["TextTransparency"] = 1
			}):Play()
		end,
		["Chase"] = function(p106)
			-- upvalues: (ref) v_u_16, (ref) v_u_36, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_24
			local v_u_107 = p106.HumanoidRootPart
			if v_u_107 then
				task.spawn(function()
					-- upvalues: (copy) v_u_107, (ref) v_u_16, (ref) v_u_36
					local v_u_108 = v_u_107:FindFirstChild("SwingForce")
					task.spawn(function()
						-- upvalues: (copy) v_u_108, (ref) v_u_107, (ref) v_u_16, (ref) v_u_36
						local v109 = 0
						while true do
							v109 = v109 + task.wait(0.03)
							if not v_u_108.Parent then
								break
							end
							if v109 > 0.125 then
								v109 = 0
								local v110 = workspace:Raycast(v_u_107.Position, Vector3.new(-0, -3.5, -0), _G.MapParams)
								if v110 then
									local v111 = script.Dust:Clone()
									v111.CFrame = CFrame.new(v110.Position) * (v_u_107.CFrame - v_u_107.Position)
									v111.Color = v110.Instance.Color
									v111.Parent = workspace.Effects
									task.delay(2.5, v111.Destroy, v111)
									v111.Smoke:Emit(10)
								end
							end
							v_u_16.Rocks(v_u_107.Position - v_u_107.CFrame.RightVector * 2.75, false, v_u_36:NextNumber(0.45, 0.55))
							v_u_16.Rocks(v_u_107.Position + v_u_107.CFrame.RightVector * 2.75, false, v_u_36:NextNumber(0.45, 0.55))
						end
					end)
				end)
				local v112 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v112.CFrame = v_u_107.CFrame * CFrame.new(0, 1, -4)
				v112.Size = Vector3.new(0, 0, 0)
				v112.Parent = workspace.Effects
				v_u_4:Create(v112, TweenInfo.new(0.25), {
					["Size"] = Vector3.new(12, 12, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v112, 0.25)
				v_u_24:PlaySound(v_u_8.Misc.C.Chara.Dashes.Front.Windup, v_u_107, game.SoundService.Effect)
				v_u_24:DustTrail(p106, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
				local v113 = p106.SetAssets:FindFirstChild("RealKnife")
				if v113 then
					local v114 = v113:FindFirstChildWhichIsA("Trail", true)
					if v114 then
						v114.Enabled = true
						task.wait(1.25)
						v114.Enabled = false
					end
				else
					return
				end
			else
				return
			end
		end,
		["Push"] = function(p115)
			-- upvalues: (ref) v_u_4
			if not p115 then
				return
			end
			local v116 = p115:FindFirstChildWhichIsA("NumberValue")
			if v116 then
				v_u_4:Create(v116, TweenInfo.new(0), {
					["Value"] = 144
				}):Play()
			end
			local v117 = tick()
			local v118 = 0
			while true do
				local v119 = task.wait()
				if v116 then
					local v120 = v118 + 43 * (v119 * 60)
					v118 = math.min(144, v120)
					local v121 = 0.895 - (tick() - v117) / 0.895
					v116.Value = v118 * math.max(0, v121)
					local v122 = print
					local v123 = 0.895 - (tick() - v117) / 0.895
					v122((math.max(0, v123)))
				end
				if not p115.Parent then
					return
				end
			end
		end,
		["ChaseSwing"] = function(p124)
			-- upvalues: (ref) v_u_3, (ref) v_u_24, (ref) v_u_8
			local v125 = p124:FindFirstChild("HumanoidRootPart")
			if v125 then
				v_u_3:AddItem(v_u_24:PlaySound(script.M1s.Swing, v125, game.SoundService.Effect), 1.5)
				v_u_24:PlaySound(v_u_8.Misc.C.Chara.Dashes.Front.Swing, v125, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p126, p127, p128)
			-- upvalues: (ref) v_u_3, (ref) v_u_24, (ref) v_u_30, (ref) v_u_8
			local v129 = p126:FindFirstChild("HumanoidRootPart")
			if v129 then
				if p127 == 2 then
					v_u_3:AddItem(v_u_24:PlaySound(script.M1s.Swing, v129, game.SoundService.Effect), 1.5)
					v_u_30(v_u_8.Misc.C.M1["2"], v129)
				elseif p127 == 4 then
					if not p128 then
						v_u_3:AddItem(v_u_24:PlaySound(script.M1s.Swing, v129, game.SoundService.Effect), 1.5)
						v_u_30(v_u_8.Misc.C.M1["1"], v129)
						return
					end
					if p128 == "Up" then
						v_u_3:AddItem(v_u_24:PlaySound(script.M1s.Swing, v129, game.SoundService.Effect), 1.5)
						v_u_30(v_u_8.Misc.C.M1.uppercutslash, v129)
					end
				end
			else
				return
			end
		end,
		["Swing2"] = function(p130, p131, p132)
			if p130:FindFirstChild("HumanoidRootPart") then
				if p131 == 2 or p131 == 4 and (p132 == nil or p132 == "Up") then
					local v133 = p130.SetAssets:FindFirstChild("RealKnife")
					if not v133 then
						return
					end
					local v134 = v133:FindFirstChildWhichIsA("Trail", true)
					if not v134 then
						return
					end
					v134.Enabled = true
					task.wait(0.35)
					v134.Enabled = false
				end
			end
		end,
		["Launch"] = function(p135, p136)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_24, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v137 = p135:FindFirstChild("HumanoidRootPart")
			if v137 then
				local v138 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v138.CFrame = CFrame.new(v137.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v138.Size = Vector3.new(0, 0, 0)
				v138.Parent = workspace.Effects
				v_u_4:Create(v138, TweenInfo.new(0.25), {
					["Size"] = Vector3.new(12, 12, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v138, 0.25)
				if p136 < 0 then
					v_u_24:PlaySound(v_u_9.Megumi.Mahoraga.Throw.Break, v137, game.SoundService.Effect)
					v_u_24:DustBreak(v137.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v137.Position) < 20 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
				end
			end
		end,
		["ClearVelocity"] = function()
			-- upvalues: (ref) v_u_5
			local v139 = v_u_5.Character
			if v139 then
				local v140 = v139:FindFirstChild("HumanoidRootPart")
				if v140 then
					local v141 = v140:FindFirstChildOfClass("BodyVelocity")
					if v141 then
						v141:Destroy()
					end
				end
			else
				return
			end
		end,
		["AwakenStart"] = function(p_u_142)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_5, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_21, (ref) v_u_18, (ref) v_u_19, (ref) v_u_2, (ref) v_u_17
			local v_u_143 = v_u_12.new(p_u_142, v_u_7.Misc.C.Awaken.Awaken)
			if v_u_143 ~= nil then
				local v_u_144 = v_u_143.RootPart
				local v_u_145 = v_u_143.Animation
				local v_u_146 = v_u_143.Job
				local v147 = v_u_5.Character == p_u_142
				if v147 then
					local v_u_148 = script.Music:Clone()
					v_u_148.Parent = workspace
					v_u_148.SoundGroup = game.SoundService.Music2
					v_u_148:Play()
					task.spawn(function()
						-- upvalues: (copy) p_u_142, (ref) v_u_4, (copy) v_u_148, (ref) v_u_3
						repeat
							task.wait()
						until not (p_u_142.Parent and p_u_142:GetAttribute("InUlt"))
						v_u_4:Create(v_u_148, TweenInfo.new(2), {
							["Volume"] = 0
						}):Play()
						v_u_3:AddItem(v_u_148, 2)
					end)
				end
				task.delay(0.15, v_u_13.AddSFX, script.SFX, v147 and workspace or p_u_142.Torso, 0.5)
				task.spawn(function()
					-- upvalues: (copy) p_u_142, (copy) v_u_146, (ref) v_u_21, (copy) v_u_145, (ref) v_u_13, (copy) v_u_143, (copy) v_u_144, (ref) v_u_4
					local v_u_149 = script.Heart:Clone()
					v_u_149.Weld.Part0 = p_u_142.HumanoidRootPart
					v_u_149.Parent = p_u_142
					v_u_146:Task(v_u_149)
					local v_u_150 = nil
					local v_u_151 = nil
					local v_u_152 = script.Assets.spin1:Clone()
					local v_u_153 = script.Assets.spin2:Clone()
					local v_u_154 = script.Assets.groundspin:Clone()
					local v_u_155 = script.Assets.flare:Clone()
					local v156 = workspace.Effects
					local v157 = workspace.Effects
					local v158 = workspace.Effects
					local v159 = workspace.Effects
					v_u_152.Parent = v156
					v_u_153.Parent = v157
					v_u_154.Parent = v158
					v_u_155.Parent = v159
					v_u_146:Task(v_u_152)
					v_u_146:Task(v_u_153)
					v_u_146:Task(v_u_154)
					v_u_146:Task(function()
						-- upvalues: (ref) v_u_21, (copy) v_u_155
						v_u_21:interact(v_u_155, "ParticleEmitter", "Enabled", false)
						task.delay(2, v_u_155.Destroy, v_u_155)
					end)
					v_u_146:Task(v_u_145:GetMarkerReachedSignal("vfx"):Connect(function(p160)
						-- upvalues: (ref) v_u_13, (copy) v_u_155, (ref) p_u_142, (ref) v_u_21, (copy) v_u_152, (ref) v_u_143, (copy) v_u_154, (copy) v_u_153, (ref) v_u_144
						if p160 == "flare" then
							v_u_13.Weld(v_u_155, p_u_142.Head)
							v_u_21:interact(v_u_155, "ParticleEmitter", "Enabled", true)
							return
						elseif p160 == "spin1" then
							v_u_13.Weld(v_u_152, v_u_143.Torso)
							v_u_13.Weld(v_u_154, v_u_143.Torso)
							v_u_21:interact(v_u_152, "ParticleEmitter", "Enabled", true)
							v_u_21:interact(v_u_154, "ParticleEmitter", "Enabled", true)
							return
						elseif p160 == "spin2" then
							v_u_21:interact(v_u_152, "ParticleEmitter", "Enabled", false)
							v_u_21:interact(v_u_154, "ParticleEmitter", "Enabled", false)
							v_u_21:interact(v_u_153, "ParticleEmitter", "Enabled", true)
						else
							if p160 == "Ye" then
								v_u_21:interact(v_u_153, "ParticleEmitter", "Enabled", false)
							end
							local v161 = script.Assets:FindFirstChild(p160)
							if v161 then
								local v162 = v161:Clone()
								v162:PivotTo(v_u_144.CFrame * v161.CFrame)
								v162.Parent = workspace.Effects
								v_u_21:emit(v162)
							end
						end
					end))
					v_u_146:Task(v_u_145:GetMarkerReachedSignal("heart_highlight"):Connect(function(p163)
						-- upvalues: (ref) v_u_151, (copy) v_u_149, (ref) v_u_4
						if p163 == "true" then
							v_u_151 = Instance.new("Highlight")
							v_u_151.FillColor = Color3.new(1, 0, 0)
							v_u_151.OutlineColor = Color3.new(1, 1, 1)
							v_u_151.OutlineTransparency = 1
							v_u_151.FillTransparency = 1
							v_u_151.Parent = v_u_149
							v_u_4:Create(v_u_151, TweenInfo.new(0.3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["FillTransparency"] = 0.111
							}):Play()
						else
							v_u_4:Create(v_u_151, TweenInfo.new(0.08333333333333333, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["FillTransparency"] = 1
							}):Play()
						end
					end))
					v_u_146:Task(v_u_145:GetMarkerReachedSignal("player_highlight"):Connect(function(p164)
						-- upvalues: (ref) v_u_150, (ref) p_u_142, (ref) v_u_4
						if p164 == "true" then
							v_u_150 = Instance.new("Highlight")
							v_u_150.FillTransparency = 1
							v_u_150.OutlineTransparency = 1
							v_u_150.OutlineColor = Color3.new(1, 1, 1)
							v_u_150.Parent = p_u_142
							v_u_4:Create(v_u_150, TweenInfo.new(0.16666666666666666, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["OutlineTransparency"] = 0
							}):Play()
						else
							v_u_4:Create(v_u_150, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
								["OutlineTransparency"] = 1
							}):Play()
						end
					end))
				end)
				if v147 then
					local v_u_165 = -50
					local v_u_166 = v_u_18.Create(v_u_144, "I\'mmm baaaaacckk!")
					v_u_166.MaxForce = Vector3.new(100000, 0, 100000)
					v_u_166.Parent = v_u_144
					v_u_19.BindSignalDisconnectToInstanceDestroying(v_u_2.PostSimulation, v_u_166, function(p167)
						-- upvalues: (copy) v_u_166, (copy) v_u_144, (ref) v_u_165
						v_u_166.Velocity = v_u_144.CFrame.LookVector * v_u_165
						if v_u_165 >= 0 then
							return v_u_166:Destroy()
						end
						local v168 = v_u_165 + p167 * 60 * 0.35
						v_u_165 = math.clamp(v168, -65, 0)
					end)
					v_u_146:Task(v_u_166)
					local v_u_169 = script.Camera:Clone()
					v_u_169.Parent = workspace.Effects
					v_u_146:Task(v_u_169)
					local v_u_170 = v_u_169.Humanoid.Animator:LoadAnimation(v_u_7.Misc.C.Awaken.AwakenCam)
					v_u_13.Weld(v_u_169, v_u_144)
					v_u_170:Play(0)
					v_u_146:Task(v_u_17(v_u_144, v_u_169, nil, {
						["DontDoTransition"] = true
					}))
					v_u_146:Task(v_u_170.Stopped:Connect(function()
						-- upvalues: (copy) v_u_169
						v_u_169:Destroy()
					end))
					v_u_146:Task(v_u_145:GetMarkerReachedSignal("pause"):Connect(function()
						-- upvalues: (copy) v_u_170
						v_u_170:AdjustSpeed(0)
					end))
					local v_u_171 = script.ScreenCover:Clone()
					v_u_171.Enabled = true
					v_u_171.Frame.BackgroundTransparency = 0
					v_u_171.Parent = v_u_5.PlayerGui
					v_u_146:Task(function()
						-- upvalues: (copy) v_u_171, (ref) v_u_4
						if v_u_171 and v_u_171.Parent ~= nil then
							local v172 = TweenInfo.new(1.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
							v_u_4:Create(v_u_171.Frame, v172, {
								["BackgroundTransparency"] = 1
							}):Play()
							task.delay(v172.Time, v_u_171.Destroy, v_u_171)
						end
					end)
					v_u_146:Task(task.delay(0.1, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_171
						v_u_4:Create(v_u_171.Frame, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["BackgroundTransparency"] = 1
						}):Play()
					end))
					UDim2.fromOffset(15, 15)
					ColorSequence.new({
						ColorSequenceKeypoint.new(0, Color3.new(1, 0, 0)),
						ColorSequenceKeypoint.new(0.25, Color3.fromRGB(181, 53, 53)),
						ColorSequenceKeypoint.new(0.5, Color3.fromRGB(109, 32, 32)),
						ColorSequenceKeypoint.new(0.75, Color3.fromRGB(181, 53, 53)),
						ColorSequenceKeypoint.new(1, Color3.new(1, 0, 0))
					})
					v_u_146:Task(task.delay(6.25, function() end))
					local function v173()
						-- upvalues: (ref) v_u_4, (copy) v_u_171
						task.wait(1.25)
						v_u_4:Create(v_u_171.Frame, TweenInfo.new(0.65, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["BackgroundTransparency"] = 0
						}):Play()
					end
					v_u_146:Task(task.delay(7.083333333333333, v173))
				end
			end
		end,
		["CheckStart"] = function(p_u_174)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_35, (ref) v_u_13, (ref) v_u_5, (ref) v_u_14, (ref) v_u_15, (ref) v_u_20
			local v175 = v_u_12.new(p_u_174, v_u_7.Misc.C.Check.Windup)
			if v175 ~= nil then
				local v176 = v175.Animation
				local v177 = v175.Job
				local v_u_178 = script.Check["act button"]:Clone()
				v_u_178.Weld.Part0 = v175.RootPart
				v_u_178.Parent = p_u_174
				local v_u_179 = script.Check["check button"]:Clone()
				v_u_179.Weld.Part0 = v175.RootPart
				v_u_179.Parent = p_u_174
				v175.Job:Task(v_u_178)
				v175.Job:Task(v_u_179)
				v_u_35(v_u_179, true)
				v177:Task(function()
					-- upvalues: (copy) p_u_174
					local v180 = p_u_174:FindFirstChild("Knife")
					if v180 then
						v180.Handle.BladeAttachment.Trail.Enabled = false
					end
				end)
				v175.Job:Task(v_u_13.AddSFX(script.Check.Start_SFX, v175.Torso, 0.5))
				local v181 = p_u_174:FindFirstChild("Knife")
				if v181 then
					v181.Handle.BladeAttachment.Trail.Enabled = true
				end
				if v_u_5.Character == p_u_174 then
					v177:Task(v176:GetMarkerReachedSignal("act"):Connect(function()
						-- upvalues: (ref) v_u_14, (ref) v_u_15, (ref) v_u_20
						v_u_14(0.75, 12.5, 0.01, 0.2, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
						v_u_15(Color3.fromRGB(253, 94, 14), 0.5, 0.4)
						v_u_20.Set(60)
						v_u_20.Tween(70, { 0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out })
					end))
					v177:Task(v176:GetMarkerReachedSignal("check"):Connect(function()
						-- upvalues: (ref) v_u_14, (ref) v_u_15, (ref) v_u_20
						v_u_14(0.75, 12.5, 0.01, 0.2, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
						v_u_15(Color3.fromRGB(255, 255, 255), 0.5, 0.4)
						v_u_20.Set(60)
						v_u_20.Tween(70, { 0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out })
					end))
				end
				v177:Task(v176:GetMarkerReachedSignal("act_bye"):Connect(function()
					-- upvalues: (ref) v_u_35, (copy) v_u_178
					v_u_35(v_u_178, true)
				end))
				v177:Task(v176:GetMarkerReachedSignal("check_hi"):Connect(function()
					-- upvalues: (ref) v_u_35, (copy) v_u_179
					v_u_35(v_u_179, false)
				end))
				v177:Task(v176:GetMarkerReachedSignal("check_bye"):Connect(function()
					-- upvalues: (ref) v_u_35, (copy) v_u_179
					v_u_35(v_u_179, true)
				end))
			end
		end,
		["CheckTarget"] = function(p_u_182, p183, p184)
			-- upvalues: (ref) v_u_5, (ref) v_u_14, (ref) v_u_15, (ref) v_u_20, (ref) v_u_4, (ref) v_u_13, (ref) v_u_12, (ref) v_u_7
			if v_u_5.Character == p_u_182 and true or v_u_5.Character == p183 then
				v_u_14(1.5, 30, 0.01, 0.5, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.45, 0.45, 0.45))
				v_u_15(Color3.fromRGB(253, 0, 0), 0.45, 0.5)
				v_u_20.Set(50)
				v_u_20.Tween(70, { 0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.Out })
				local v_u_185 = Instance.new("Highlight")
				v_u_185.FillTransparency = 1
				v_u_185.OutlineTransparency = 1
				v_u_185.FillColor = Color3.fromRGB(255, 24, 24)
				v_u_185.OutlineColor = Color3.fromRGB(255, 255, 255)
				v_u_185.DepthMode = Enum.HighlightDepthMode.Occluded
				v_u_185.Parent = p183
				local v_u_186 = script.Check.UI:Clone()
				v_u_186.Name = "DEFReduced"
				v_u_186.Value.TextTransparency = 1
				v_u_186.Value.UIStroke.Transparency = 1
				v_u_186.Parent = p183.Torso
				v_u_4:Create(v_u_186.Value, TweenInfo.new(0.1), {
					["TextTransparency"] = 0
				}):Play()
				v_u_4:Create(v_u_186.Value.UIStroke, TweenInfo.new(0.1), {
					["Transparency"] = 0
				}):Play()
				v_u_4:Create(v_u_185, TweenInfo.new(0.15), {
					["FillTransparency"] = 0.6,
					["OutlineTransparency"] = 0.6
				}):Play()
				task.delay(p184, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_186, (copy) v_u_185
					v_u_4:Create(v_u_186.Value, TweenInfo.new(0.75), {
						["TextTransparency"] = 1
					}):Play()
					v_u_4:Create(v_u_186.Value.UIStroke, TweenInfo.new(0.75), {
						["Transparency"] = 1
					}):Play()
					v_u_4:Create(v_u_185, TweenInfo.new(0.75), {
						["FillTransparency"] = 1,
						["OutlineTransparency"] = 1
					}):Play()
					task.delay(0.75, v_u_186.Destroy, v_u_186)
					task.delay(0.75, v_u_185.Destroy, v_u_185)
				end)
				v_u_13.AddSFX(script.Check.Hit_SFX, p183.PrimaryPart)
			end
			local v187 = v_u_12.new(p_u_182, v_u_7.Misc.C.Check.Success)
			if v187 ~= nil then
				v187.Job:Task(v_u_13.AddSFX(script.Check.Flourish, v187.Torso, 0.5))
				v187.Job:Task(function()
					-- upvalues: (copy) p_u_182
					local v188 = p_u_182:FindFirstChild("Knife")
					if v188 then
						v188.Handle.BladeAttachment.Trail.Enabled = false
					end
				end)
				local v189 = p_u_182:FindFirstChild("Knife")
				if v189 then
					v189.Handle.BladeAttachment.Trail.Enabled = true
				end
			end
		end
	}
	v_u_22.Effects:Connect(function(p191, ...)
		-- upvalues: (copy) v_u_190
		local v192 = v_u_190[p191]
		if v192 then
			v192(...)
		end
	end)
	v_u_22.Hitbox:Connect(function(p193, p194, p195)
		-- upvalues: (ref) v_u_23, (ref) v_u_4
		local v196 = p194.HumanoidRootPart
		if not v196 then
			return
		end
		local v197 = nil
		while true do
			local v198 = v_u_23:SphereHitbox(p194, CFrame.new(0, 0, -4), 8)
			for _, v199 in v198 do
				local v200 = v199:FindFirstChild("Info")
				if v200 then
					local v201 = v200:FindFirstChild("Knockback")
					if not v201 or v201.Value ~= false then
						v197 = v198
						break
					end
				end
			end
			if v197 then
				local v202 = p193:FindFirstChildWhichIsA("NumberValue")
				if v202 then
					v_u_4:Create(v202, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p193.Parent then
				break
			end
		end
		p195:FireServer(v197, v196.CFrame)
	end)
end
function v25.KnitInit(_)
	-- upvalues: (ref) v_u_22, (copy) v_u_1, (ref) v_u_23, (ref) v_u_24
	v_u_22 = v_u_1.GetService("CharaService")
	v_u_23 = v_u_1.GetController("HitboxController")
	v_u_24 = v_u_1.GetController("FXController")
end
v25.SpawnAnim = "123754093782071"
v25.SpawnFunc = {
	["Point"] = function(p203, _)
		local v204 = p203.SetAssets:FindFirstChild("RealKnife")
		if v204 then
			for _, v205 in v204.BladeInner.knife_point:GetDescendants() do
				if v205:IsA("ParticleEmitter") then
					v205:Emit(v205:GetAttribute("EmitCount"))
				end
			end
		end
	end
}
return v25