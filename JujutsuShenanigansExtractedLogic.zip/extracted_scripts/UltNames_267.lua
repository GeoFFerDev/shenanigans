-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Gojo"] = {
		"Six Eyes",
		Color3.fromRGB(85, 255, 255),
		Color3.fromRGB(0, 170, 255),
		true
	},
	["Itadori"] = {
		"King of Curses",
		Color3.fromRGB(255, 0, 0),
		Color3.fromRGB(0, 170, 255),
		true
	},
	["Hakari"] = {
		"Idle Death Gamble",
		Color3.fromRGB(85, 255, 127),
		Color3.fromRGB(0, 170, 255),
		true
	},
	["Megumi"] = {
		"Insanity",
		Color3.fromRGB(45, 45, 45),
		Color3.fromRGB(0, 170, 255),
		true
	},
	["Mahito"] = {
		"Essence of the Soul",
		Color3.fromRGB(170, 170, 255),
		Color3.fromRGB(0, 170, 255),
		true
	},
	["Choso"] = {
		"Duty as a Brother",
		Color3.fromRGB(130, 0, 0),
		Color3.fromRGB(0, 0, 0),
		true
	},
	["Todo"] = {
		"False Memories",
		Color3.fromRGB(255, 255, 255),
		Color3.fromRGB(0, 170, 255),
		true
	},
	["Hiromi"] = {
		"Deadly Sentencing",
		Color3.fromRGB(179, 130, 61),
		Color3.fromRGB(88, 57, 37),
		true
	},
	["Locust"] = {
		"Directed Poison",
		Color3.fromRGB(85, 170, 0),
		Color3.fromRGB(85, 170, 0),
		true
	},
	["Yuki"] = {
		"Unrestricted Density",
		Color3.fromRGB(0, 0, 0),
		Color3.fromRGB(0, 0, 0),
		true
	},
	["Yuta"] = {
		"True Love",
		Color3.fromRGB(255, 170, 255),
		Color3.fromRGB(255, 0, 127),
		true
	},
	["Charles"] = {
		"Foresight",
		Color3.fromRGB(255, 255, 255),
		Color3.fromRGB(85, 0, 0),
		true
	},
	["Mechamaru"] = {
		"Absolute",
		Color3.fromRGB(225, 10, 75),
		Color3.fromRGB(85, 85, 85),
		true
	},
	["Naoya"] = {
		"Vengeance",
		Color3.fromRGB(255, 255, 255),
		Color3.fromRGB(128, 126, 255),
		true
	},
	["Nanami"] = {
		"Overtime",
		Color3.fromRGB(131, 203, 199),
		Color3.fromRGB(59, 84, 143),
		true
	},
	["Haruta"] = {
		"Jawbreaker",
		Color3.fromRGB(167, 125, 203),
		Color3.fromRGB(112, 85, 143),
		true
	},
	["Kirara"] = {
		"Car",
		Color3.fromRGB(116, 203, 155),
		Color3.fromRGB(140, 101, 255),
		true
	},
	["Mahoraga"] = {
		"Ritual",
		Color3.fromRGB(255, 255, 255),
		Color3.fromRGB(0, 170, 255),
		false
	},
	["Heian"] = {
		"Incomplete Shrine",
		Color3.fromRGB(85, 0, 0),
		Color3.fromRGB(0, 170, 255),
		true
	},
	["Goku"] = {
		"Monkey",
		Color3.fromRGB(255, 0, 0),
		Color3.new(1, 1, 0),
		true
	},
	["Mokou"] = {
		"Immortal Blaze",
		Color3.fromRGB(255, 170, 0),
		Color3.new(1, 0.333333, 0),
		true
	},
	["Chara"] = {
		"SINCE WHEN WERE YOU THE ONE IN CONTROL?",
		Color3.fromRGB(255, 0, 0),
		Color3.new(0.333333, 0, 0),
		true
	}
}