-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("RunService")
local v2 = require(script.TweenFunctions)
local v_u_3 = require(script.Lerps)
local v_u_4 = v_u_1.Heartbeat
local v5 = {}
local v_u_6 = {
	["Heartbeat"] = true,
	["Stepped"] = true,
	["RenderStepped"] = true
}
if not v_u_1:IsClient() then
	v_u_6.RenderStepped = nil
end
local v_u_7 = {
	["FabricAccelerate"] = {
		["In"] = v2.InFabricAccelerate,
		["Out"] = v2.OutFabricAccelerate,
		["InOut"] = v2.InOutFabricAccelerate,
		["OutIn"] = v2.OutInFabricAccelerate
	},
	["UWPAccelerate"] = {
		["In"] = v2.InUWPAccelerate,
		["Out"] = v2.OutUWPAccelerate,
		["InOut"] = v2.InOutUWPAccelerate,
		["OutIn"] = v2.OutInUWPAccelerate
	},
	["Circ"] = {
		["In"] = v2.InCirc,
		["Out"] = v2.OutCirc,
		["InOut"] = v2.InOutCirc,
		["OutIn"] = v2.OutInCirc
	},
	["RevBack"] = {
		["In"] = v2.InRevBack,
		["Out"] = v2.OutRevBack,
		["InOut"] = v2.InOutRevBack,
		["OutIn"] = v2.OutInRevBack
	},
	["Spring"] = {
		["In"] = v2.InSpring,
		["Out"] = v2.OutSpring,
		["InOut"] = v2.InOutSpring,
		["OutIn"] = v2.OutInSpring
	},
	["Standard"] = {
		["In"] = v2.InStandard,
		["Out"] = v2.OutStandard,
		["InOut"] = v2.InOutStandard,
		["OutIn"] = v2.OutInStandard
	},
	["StandardExpressive"] = {
		["In"] = v2.InStandardExpressive,
		["Out"] = v2.OutStandardExpressive,
		["InOut"] = v2.InOutStandardExpressive,
		["OutIn"] = v2.OutInStandardExpressive
	},
	["Linear"] = {
		["In"] = v2.InLinear,
		["Out"] = v2.OutLinear,
		["InOut"] = v2.InOutLinear,
		["OutIn"] = v2.OutInLinear
	},
	["ExitProductive"] = {
		["In"] = v2.InExitProductive,
		["Out"] = v2.OutExitProductive,
		["InOut"] = v2.InOutExitProductive,
		["OutIn"] = v2.OutInExitProductive
	},
	["Deceleration"] = {
		["In"] = v2.InDeceleration,
		["Out"] = v2.OutDeceleration,
		["InOut"] = v2.InOutDeceleration,
		["OutIn"] = v2.OutInDeceleration
	},
	["Smoother"] = {
		["In"] = v2.InSmoother,
		["Out"] = v2.OutSmoother,
		["InOut"] = v2.InOutSmoother,
		["OutIn"] = v2.OutInSmoother
	},
	["FabricStandard"] = {
		["In"] = v2.InFabricStandard,
		["Out"] = v2.OutFabricStandard,
		["InOut"] = v2.InOutFabricStandard,
		["OutIn"] = v2.OutInFabricStandard
	},
	["RidiculousWiggle"] = {
		["In"] = v2.InRidiculousWiggle,
		["Out"] = v2.OutRidiculousWiggle,
		["InOut"] = v2.InOutRidiculousWiggle,
		["OutIn"] = v2.OutInRidiculousWiggle
	},
	["MozillaCurve"] = {
		["In"] = v2.InMozillaCurve,
		["Out"] = v2.OutMozillaCurve,
		["InOut"] = v2.InOutMozillaCurve,
		["OutIn"] = v2.OutInMozillaCurve
	},
	["Expo"] = {
		["In"] = v2.InExpo,
		["Out"] = v2.OutExpo,
		["InOut"] = v2.InOutExpo,
		["OutIn"] = v2.OutInExpo
	},
	["Sine"] = {
		["In"] = v2.InSine,
		["Out"] = v2.OutSine,
		["InOut"] = v2.InOutSine,
		["OutIn"] = v2.OutInSine
	},
	["Cubic"] = {
		["In"] = v2.InCubic,
		["Out"] = v2.OutCubic,
		["InOut"] = v2.InOutCubic,
		["OutIn"] = v2.OutInCubic
	},
	["EntranceExpressive"] = {
		["In"] = v2.InEntranceExpressive,
		["Out"] = v2.OutEntranceExpressive,
		["InOut"] = v2.InOutEntranceExpressive,
		["OutIn"] = v2.OutInEntranceExpressive
	},
	["Elastic"] = {
		["In"] = v2.InElastic,
		["Out"] = v2.OutElastic,
		["InOut"] = v2.InOutElastic,
		["OutIn"] = v2.OutInElastic
	},
	["Quint"] = {
		["In"] = v2.InQuint,
		["Out"] = v2.OutQuint,
		["InOut"] = v2.InOutQuint,
		["OutIn"] = v2.OutInQuint
	},
	["EntranceProductive"] = {
		["In"] = v2.InEntranceProductive,
		["Out"] = v2.OutEntranceProductive,
		["InOut"] = v2.InOutEntranceProductive,
		["OutIn"] = v2.OutInEntranceProductive
	},
	["Bounce"] = {
		["In"] = v2.InBounce,
		["Out"] = v2.OutBounce,
		["InOut"] = v2.InOutBounce,
		["OutIn"] = v2.OutInBounce
	},
	["Smooth"] = {
		["In"] = v2.InSmooth,
		["Out"] = v2.OutSmooth,
		["InOut"] = v2.InOutSmooth,
		["OutIn"] = v2.OutInSmooth
	},
	["Back"] = {
		["In"] = v2.InBack,
		["Out"] = v2.OutBack,
		["InOut"] = v2.InOutBack,
		["OutIn"] = v2.OutInBack
	},
	["Quart"] = {
		["In"] = v2.InQuart,
		["Out"] = v2.OutQuart,
		["InOut"] = v2.InOutQuart,
		["OutIn"] = v2.OutInQuart
	},
	["StandardProductive"] = {
		["In"] = v2.InStandardProductive,
		["Out"] = v2.OutStandardProductive,
		["InOut"] = v2.InOutStandardProductive,
		["OutIn"] = v2.OutInStandardProductive
	},
	["Quad"] = {
		["In"] = v2.InQuad,
		["Out"] = v2.OutQuad,
		["InOut"] = v2.InOutQuad,
		["OutIn"] = v2.OutInQuad
	},
	["FabricDecelerate"] = {
		["In"] = v2.InFabricDecelerate,
		["Out"] = v2.OutFabricDecelerate,
		["InOut"] = v2.InOutFabricDecelerate,
		["OutIn"] = v2.OutInFabricDecelerate
	},
	["Acceleration"] = {
		["In"] = v2.InAcceleration,
		["Out"] = v2.OutAcceleration,
		["InOut"] = v2.InOutAcceleration,
		["OutIn"] = v2.OutInAcceleration
	},
	["SoftSpring"] = {
		["In"] = v2.InSoftSpring,
		["Out"] = v2.OutSoftSpring,
		["InOut"] = v2.InOutSoftSpring,
		["OutIn"] = v2.OutInSoftSpring
	},
	["ExitExpressive"] = {
		["In"] = v2.InExitExpressive,
		["Out"] = v2.OutExitExpressive,
		["InOut"] = v2.InOutExitExpressive,
		["OutIn"] = v2.OutInExitExpressive
	},
	["Sharp"] = {
		["In"] = v2.InSharp,
		["Out"] = v2.OutSharp,
		["InOut"] = v2.InOutSharp,
		["OutIn"] = v2.OutInSharp
	}
}
local function v_u_11(p8)
	-- upvalues: (copy) v_u_4
	local v9 = math.max(p8 or 0.03, 0)
	local v10 = v9
	while v9 > 0 do
		v9 = v9 - v_u_4:Wait()
	end
	return v10 - v9
end
function v5.Create(_, p_u_12, p13)
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_7, (copy) v_u_3, (copy) v_u_11
	if not p_u_12 or typeof(p_u_12) ~= "Instance" then
		return warn("Invalid object to tween:", p_u_12)
	end
	local v_u_14 = type(p13) == "table" and (p13 or {}) or {}
	local v_u_15 = v_u_6[v_u_14.StepType] and v_u_1[v_u_14.StepType] or v_u_1.Stepped
	local v_u_16 = v_u_7[v_u_14.EasingStyle or "Quad"][v_u_14.EasingDirection or "In"]
	local v17 = v_u_14.Time
	local v18 = type(v17) == "number" and (v_u_14.Time or 1) or 1
	local v_u_19 = math.max(v18, 0.001)
	local v20 = v_u_14.Goal
	local v21 = type(v20) == "table" and (v_u_14.Goal or {}) or {}
	local v22 = v_u_14.DelayTime
	local v_u_23
	if type(v22) == "number" and v_u_14.DelayTime > 0.027 then
		v_u_23 = v_u_14.DelayTime
	else
		v_u_23 = false
	end
	local v24 = v_u_14.RepeatCount
	local v25
	if type(v24) == "number" then
		local v26 = v_u_14.RepeatCount
		v25 = math.max(v26, -1) or 0
	else
		v25 = 0
	end
	local v_u_27 = v25 + 1
	local v_u_28 = {}
	for v29, v30 in pairs(v21) do
		v_u_28[v29] = v_u_3[typeof(v30)](p_u_12[v29], v30)
	end
	local v_u_31 = Instance.new("BindableEvent")
	local v_u_32 = Instance.new("BindableEvent")
	local v_u_33 = Instance.new("BindableEvent")
	local v_u_34 = nil
	local v_u_35 = os.clock()
	local v_u_36 = 0
	local v_u_37 = {
		["Instance"] = p_u_12,
		["PlaybackState"] = Enum.PlaybackState.Begin,
		["Completed"] = v_u_31.Event,
		["Resumed"] = v_u_33.Event,
		["Stopped"] = v_u_32.Event,
		["Destroy"] = function()
			-- upvalues: (ref) v_u_34, (copy) v_u_31, (copy) v_u_32, (copy) v_u_33, (ref) v_u_37
			if v_u_34 then
				v_u_34:Disconnect()
				v_u_34 = nil
			end
			v_u_31:Destroy()
			v_u_32:Destroy()
			v_u_33:Destroy()
			v_u_37 = nil
		end
	}
	local v_u_38 = false
	local v_u_39 = 0
	local function v_u_51(p40, p_u_41)
		-- upvalues: (ref) v_u_34, (copy) v_u_27, (ref) v_u_37, (copy) v_u_31, (ref) v_u_38, (ref) v_u_39, (copy) v_u_23, (ref) v_u_11, (ref) v_u_35, (ref) v_u_36, (copy) v_u_15, (copy) v_u_19, (copy) v_u_28, (copy) p_u_12, (copy) v_u_51, (ref) v_u_14, (copy) v_u_16
		if v_u_34 then
			v_u_34:Disconnect()
			v_u_34 = nil
		end
		local v_u_42 = p40 or 1
		if v_u_27 == 0 or v_u_27 >= v_u_42 then
			v_u_39 = v_u_42
			if p_u_41 then
				v_u_38 = true
			end
			if v_u_23 then
				v_u_37.PlaybackState = Enum.PlaybackState.Delayed;
				(v_u_23 < 2 and v_u_11 or wait)(v_u_23)
			end
			v_u_35 = os.clock() - v_u_36
			v_u_34 = v_u_15:Connect(function()
				-- upvalues: (ref) v_u_36, (ref) v_u_35, (ref) v_u_19, (copy) p_u_41, (ref) v_u_28, (ref) p_u_12, (ref) v_u_34, (ref) v_u_51, (ref) v_u_42, (ref) v_u_14, (ref) v_u_16
				v_u_36 = os.clock() - v_u_35
				if v_u_19 <= v_u_36 then
					if p_u_41 then
						for v43, v44 in pairs(v_u_28) do
							p_u_12[v43] = v44(0)
						end
					else
						for v45, v46 in pairs(v_u_28) do
							p_u_12[v45] = v46(1)
						end
					end
					v_u_34:Disconnect()
					v_u_34 = nil
					if p_u_41 then
						v_u_36 = 0
						v_u_51(v_u_42 + 1, false)
						return
					elseif v_u_14.Reverses then
						v_u_36 = 0
						v_u_51(v_u_42, true)
					else
						v_u_36 = 0
						v_u_51(v_u_42 + 1, false)
					end
				else
					local v47 = v_u_16(p_u_41 and 1 - v_u_36 / v_u_19 or v_u_36 / v_u_19)
					local v48 = math.clamp(v47, 0, 1)
					for v49, v50 in pairs(v_u_28) do
						p_u_12[v49] = v50(v48)
					end
					return
				end
			end)
			v_u_37.PlaybackState = Enum.PlaybackState.Playing
		else
			v_u_37.PlaybackState = Enum.PlaybackState.Completed
			v_u_31:Fire()
			v_u_38 = false
			v_u_39 = 1
		end
	end
	function v_u_37.Play()
		-- upvalues: (ref) v_u_36, (copy) v_u_51
		v_u_36 = 0
		v_u_51(1, false)
	end
	function v_u_37.Stop()
		-- upvalues: (ref) v_u_34, (ref) v_u_37, (copy) v_u_32
		if v_u_34 then
			v_u_34:Disconnect()
			v_u_34 = nil
			v_u_37.PlaybackState = Enum.PlaybackState.Cancelled
			v_u_32:Fire()
		end
	end
	function v_u_37.Resume()
		-- upvalues: (copy) v_u_51, (ref) v_u_39, (ref) v_u_38, (copy) v_u_33
		v_u_51(v_u_39, v_u_38)
		v_u_33:Fire()
	end
	return v_u_37
end
return v5