-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
local v_u_8 = require(v4.Modules.StaticLightning)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "RikaLoveBeamController"
})
local v_u_12 = Random.new()
local v_u_13 = workspace.CurrentCamera
local function v_u_32(p14, p15, p16)
	local v17 = p16.Z - 45 - p16.X / 2
	local v18 = math.max(v17, 0)
	local v19 = p14.BlackStart.Size.X
	p14.BlackStart.CFrame = p15 * CFrame.new(0, 0, -22.5) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v20 = p14.BlackStart
	local v21 = p16.X
	local v22 = p16.Y
	v20.Size = Vector3.new(v21, 45, v22)
	p14.PinkStart.CFrame = p14.BlackStart.CFrame
	p14.PinkStart.Size = p14.BlackStart.Size * Vector3.new(0.875, 1, 0.875)
	p14.BlackMiddle.CFrame = p15 * CFrame.new(0, 0, -(v18 / 2 + 45)) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v23 = p14.BlackMiddle
	local v24 = p16.X
	local v25 = p16.Y
	v23.Size = Vector3.new(v24, v18, v25)
	p14.PinkMiddle.CFrame = p14.BlackMiddle.CFrame
	p14.PinkMiddle.Size = p14.BlackMiddle.Size * Vector3.new(0.875, 1, 0.875)
	p14.BlackEnd.CFrame = p15 * CFrame.new(0, 0, -(v18 + 45 + p16.X / 4)) * CFrame.Angles(1.5707963267948966, 0, 0)
	local v26 = p14.BlackEnd
	local v27 = p16.X
	local v28 = p16.X / 2
	local v29 = p16.X
	v26.Size = Vector3.new(v27, v28, v29)
	p14.PinkEnd.CFrame = p14.BlackEnd.CFrame
	p14.PinkEnd.Size = p14.BlackEnd.Size * Vector3.new(0.875, 1, 0.875)
	for _, v30 in p14:GetDescendants() do
		if v30:IsA("Beam") then
			local v31 = v19 / v30.CurveSize0
			v30.CurveSize0 = p16.X / v31
		end
	end
end
local function v_u_37(p33)
	-- upvalues: (copy) v_u_5, (copy) v_u_3
	local v34 = v_u_5.Yuta.LoveBeam.BlackSpec:Clone()
	v34.CFrame = p33.PinkStart.CFrame * CFrame.new(0, -10, 0)
	v34.Parent = p33
	local v35 = p33.BlackMiddle.Size.X
	local v36 = p33.BlackMiddle.Size.Y
	v_u_3:Create(v34, TweenInfo.new(0.3), {
		["Size"] = Vector3.new(v35, 20, v35),
		["CFrame"] = v34.CFrame * CFrame.new(0, v36 / 2, 0)
	}):Play()
	task.wait(0.2)
	v_u_3:Create(v34, TweenInfo.new(0.3), {
		["Size"] = Vector3.new(v35, 0, v35),
		["CFrame"] = p33.PinkStart.CFrame * CFrame.new(0, v36, 0)
	}):Play()
	task.wait(0.3)
	v34:Destroy()
end
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_12, (copy) v_u_13, (copy) v_u_7, (copy) v_u_32, (copy) v_u_8, (copy) v_u_37, (copy) v_u_2
	local v_u_94 = {
		["Bigger"] = function(p38)
			-- upvalues: (ref) v_u_10, (ref) v_u_6
			local v39 = p38:FindFirstChild("RootPart")
			if v39 then
				v_u_10:PlaySound(v_u_6.Yuta.LoveBeam.RikaMovement, v39, game.SoundService.Effect)
				local v40 = tick()
				repeat
					task.wait()
					local v41 = (tick() - v40) / 0.2
					p38:ScaleTo(math.clamp(v41, 0, 1) * 0.7 + 1)
				until tick() - v40 >= 0.2
				p38:ScaleTo(1.7)
			end
		end,
		["Smaller"] = function(p42)
			local v43 = 1 - p42:GetScale()
			local v44 = tick()
			repeat
				task.wait()
				local v45 = (tick() - v44) / 0.2
				p42:ScaleTo(1 + v43 * math.clamp(v45, 0, 1))
			until tick() - v44 >= 0.2
			p42:ScaleTo(1)
		end,
		["Charge"] = function(p46)
			-- upvalues: (ref) v_u_3, (ref) v_u_5, (ref) v_u_12
			v_u_3:Create(p46, TweenInfo.new(0.5), {
				["Size"] = Vector3.new(1.5, 1.5, 1.5)
			}):Play()
			v_u_3:Create(p46.Outline, TweenInfo.new(0.5), {
				["Size"] = Vector3.new(1.57, 1.57, 1.57)
			}):Play()
			p46.Attachment.Charge.Enabled = false
			p46.Attachment.Circles.Enabled = false
			local v47 = v_u_5.Yuta.LoveBeam.ChargeBallEffects.Attachment:Clone()
			v47.Parent = p46
			v47.EnergyBits1.Enabled = true
			task.wait(0.1)
			v47.EnergyBits2.Enabled = true
			v47.EnergyGlow1.Enabled = true
			task.wait(0.2)
			v47.EnergyBits3.Enabled = true
			v47.EnergyGlow2.Enabled = true
			task.wait(0.2)
			p46.Outline:Destroy()
			v_u_3:Create(p46, TweenInfo.new(0.1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, true), {
				["Size"] = Vector3.new(2.25, 2.25, 2.25)
			}):Play()
			task.wait(0.1)
			v_u_3:Create(p46, TweenInfo.new(0.1), {
				["Size"] = Vector3.new(3.25, 3.25, 3.25)
			}):Play()
			for _, v48 in v47:GetChildren() do
				v48.Enabled = true
			end
			local v49 = p46.CFrame
			repeat
				task.wait()
				p46.CFrame = v49 + v_u_12:NextUnitVector() * 0.3
			until not p46.Parent
		end,
		["StartBeamSound"] = function(p50)
			if p50 and p50.Parent then
				local v51 = p50.TrueLove
				v51:Clone().Parent = p50
				v51:Destroy()
				p50.TrueLove.EmitterSize = 100
				p50.TrueLove:Play()
			end
		end,
		["StartBeam"] = function(p_u_52, p_u_53, p54)
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_13, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_32, (ref) v_u_8, (ref) v_u_12, (ref) v_u_37, (ref) v_u_2
			local v55 = p54:FindFirstChild("TrueLove")
			local v_u_56 = Instance.new("Model", workspace.Effects)
			v_u_56.Name = "WhiteHighlight"
			local v57 = Instance.new("Highlight", v_u_56)
			v57.OutlineTransparency = 1
			v57.FillTransparency = 0.2
			v57.FillColor = Color3.new(1, 1, 1)
			v57.Adornee = v_u_56
			v57.DepthMode = Enum.HighlightDepthMode.Occluded
			local v_u_58 = v_u_5.Yuta.LoveBeam.ChargeBall2:Clone()
			v_u_58.CFrame = p_u_52 * CFrame.new(0, 0, 3)
			v_u_58.Transparency = 1
			v_u_58.Parent = v57
			v_u_10:PlayParticles(v_u_58.Attachment1)
			local v59 = v_u_13.CFrame
			local v60 = p_u_52.Position - v59.Position
			if v60.Unit:Dot(v59.LookVector) >= 0.7 and v60.Magnitude < 70 then
				v_u_7.CurrentShaker:Shake(v_u_7.Presets.HeavyHit)
				local v61 = v_u_5.Itadori.DivergentFist.BlackFlashCC:Clone()
				v61.TintColor = Color3.new(1, 0.3, 1)
				v61.Parent = game.Lighting
				task.wait(0.04)
				v61.TintColor = Color3.new(1, 1, 1)
				task.wait(0.04)
				v61.Brightness = 200
				v61.Contrast = -1000
				task.wait(0.04)
				v61:Destroy()
			else
				task.wait(0.12)
			end
			local v_u_62 = v_u_5.Yuta.LoveBeam.Beam:Clone()
			local v_u_63 = Instance.new("Part", workspace.Effects)
			v_u_63.CanCollide = false
			v_u_63.CanQuery = false
			v_u_63.CanTouch = false
			v_u_63.Transparency = 1
			v_u_63.CastShadow = false
			v_u_63.Anchored = true
			v_u_63.CFrame = v_u_62.BlackMiddle.CFrame
			if v55 then
				v55.Parent = v_u_63
				v55.RollOffMinDistance = 180
			end
			p54:Destroy()
			if not workspace:FindFirstChild("Music") then
				local v64 = v_u_10:PlaySound(v_u_6.Yuta.LoveBeam.Music, v_u_63, game.SoundService.Music)
				v64.EmitterSize = 100
				v_u_3:Create(v64, TweenInfo.new(0.5), {
					["Volume"] = 1.25
				}):Play()
			end
			local v_u_65 = Instance.new("Vector3Value")
			v_u_65.Value = Vector3.new(40, 40, 180)
			v_u_32(v_u_62, p_u_52 * CFrame.new(0, 0, -5), (Vector3.new(40, 40, p_u_53:GetAttribute("BeamLength"))))
			v_u_62.Parent = workspace.Effects
			v_u_58.Transparency = 0
			local v_u_66 = true
			local v_u_67 = v_u_58.Position
			task.spawn(function()
				-- upvalues: (ref) v_u_8, (copy) v_u_58, (ref) v_u_12, (ref) v_u_66, (copy) v_u_56, (copy) v_u_67, (copy) v_u_62
				local v_u_68 = v_u_8.ThicknessFade(0.1, 0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut)
				local v_u_69 = {
					{},
					{},
					{}
				}
				while true do
					task.wait(0.06)
					local v70 = v_u_58.CFrame
					local v_u_71 = v70.Position
					for v_u_72, v_u_73 in v_u_69 do
						local v74 = v_u_12:NextUnitVector()
						local v_u_75 = v_u_71 + v70.LookVector * v_u_12:NextNumber(5, 30) + v74 * 20
						local v_u_76 = (v_u_71 + v_u_75) / 2 + v74 * 30
						task.spawn(function()
							-- upvalues: (ref) v_u_66, (ref) v_u_73, (copy) v_u_69, (copy) v_u_72, (ref) v_u_8, (ref) v_u_71, (copy) v_u_75, (copy) v_u_76, (ref) v_u_58, (copy) v_u_68, (ref) v_u_56, (ref) v_u_67, (ref) v_u_12
							for _ = 1, 3 do
								if not v_u_66 then
									break
								end
								v_u_73 = v_u_69[v_u_72]
								v_u_69[v_u_72] = v_u_8.CreateBolt({
									["Position1"] = v_u_71,
									["Position2"] = v_u_75,
									["CurveCenter"] = v_u_76,
									["Color"] = v_u_58.Color,
									["Thickness"] = v_u_68,
									["PartPool"] = v_u_73,
									["Parent"] = v_u_56
								})
								v_u_58.Position = v_u_67 + v_u_12:NextUnitVector() * 0.3
								v_u_71 = v_u_58.Position
								task.wait(0.02)
							end
						end)
					end
					if not (v_u_62.Parent and v_u_66) then
						v_u_56:Destroy()
						return
					end
				end
			end)
			local v_u_77 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_5, (ref) v_u_13, (copy) p_u_52, (ref) v_u_7, (ref) v_u_77, (ref) v_u_12, (ref) v_u_32, (copy) v_u_62, (copy) v_u_65, (copy) p_u_53, (copy) v_u_63
				local v78 = v_u_5.Yuta.LoveBeam.CameraFX:Clone()
				local v79
				if (v_u_13.CFrame.Position - p_u_52.Position).Magnitude < 180 then
					v79 = v_u_7.CurrentShaker:ShakeSustain(v_u_7.Presets.HeavyHit)
				else
					v79 = nil
				end
				while true do
					local v80 = v_u_77 and Vector3.new(1, 1, 0) * v_u_12:NextNumber(1, 5) or Vector3.new(0, 0, 0)
					local v81 = p_u_53
					v_u_32(v_u_62, p_u_52, v_u_65.Value * Vector3.new(1, 1, 0) + v80 + Vector3.new(0, 0, v81:GetAttribute("BeamLength")))
					v_u_63.CFrame = v_u_62.BlackMiddle.CFrame
					local v82, v83 = v_u_62:GetBoundingBox()
					local v84 = v83 / 2
					local v85 = v82:PointToObjectSpace(v_u_13.CFrame.Position)
					local v86
					if v85.Z > v84.Z or v85.Z < -v84.Z then
						v86 = nil
					else
						v86 = (v85 * Vector3.new(1, 1, 0)).Magnitude <= v84.X and true or nil
					end
					if v86 then
						v78.Parent = game.Lighting
					else
						v78.Parent = nil
					end
					task.wait()
					if not v_u_62.Parent then
						if v79 then
							v79:StartFadeOut(0.5)
						end
						v78:Destroy()
						return
					end
				end
			end)
			local v_u_87 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_37, (copy) v_u_62, (ref) v_u_87
				repeat
					task.spawn(v_u_37, v_u_62)
					task.wait(0.3)
				until not (v_u_62.Parent and v_u_87)
			end)
			v_u_3:Create(v_u_65, TweenInfo.new(0.3), {
				["Value"] = Vector3.new(60, 60, 180)
			}):Play()
			task.wait(0.3)
			v_u_3:Create(v_u_65, TweenInfo.new(0.1), {
				["Value"] = Vector3.new(40, 40, 180)
			}):Play()
			task.wait(0.1)
			v_u_3:Create(v_u_65, TweenInfo.new(1), {
				["Value"] = Vector3.new(30, 30, 180)
			}):Play()
			v_u_3:Create(v_u_62.PinkStart, TweenInfo.new(1), {
				["Color"] = Color3.fromRGB(255, 100, 255)
			}):Play()
			v_u_3:Create(v_u_62.PinkMiddle, TweenInfo.new(1), {
				["Color"] = Color3.fromRGB(255, 100, 255)
			}):Play()
			v_u_3:Create(v_u_62.PinkEnd, TweenInfo.new(1), {
				["Color"] = Color3.fromRGB(255, 100, 255)
			}):Play()
			task.wait(1)
			v_u_87 = false
			v_u_3:Create(v_u_65, TweenInfo.new(0.5), {
				["Value"] = Vector3.new(0, 0, 180)
			}):Play()
			for _, v88 in v_u_62:GetDescendants() do
				if v88:IsA("Beam") then
					v_u_3:Create(v88, TweenInfo.new(0.25), {
						["Width0"] = 0,
						["Width1"] = 0
					}):Play()
				elseif v88:IsA("ParticleEmitter") then
					v88.Enabled = false
				end
			end
			task.wait(0.25)
			v_u_66 = false
			v_u_77 = false
			task.wait(0.25)
			v_u_62:Destroy()
			v_u_2:AddItem(v_u_63, 10)
		end,
		["Hit"] = function(p89)
			-- upvalues: (ref) v_u_10
			v_u_10:Flash(p89, Color3.fromRGB(255, 170, 255))
		end,
		["Finisher"] = function(p90)
			-- upvalues: (ref) v_u_5
			local v91 = v_u_5.Yuta.LoveBeam.Smoke
			for _, v92 in p90:GetDescendants() do
				if v92:IsA("BasePart") or v92:IsA("Decal") then
					v92.Transparency = 1
				end
				if v92:IsA("BasePart") then
					v92.CollisionGroup = "NoPlayerCollision"
				end
				if v92.Name ~= "HumanoidRootPart" and v92.Parent == p90 then
					local v93 = v91:Clone()
					v93.Parent = v92
					v93:Emit(20)
				end
			end
		end
	}
	RikaLoveBeamService.Effects:Connect(function(p95, ...)
		-- upvalues: (copy) v_u_94
		local v96 = v_u_94[p95]
		if v96 then
			v96(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (copy) v_u_1, (ref) v_u_9, (ref) v_u_10
	RikaLoveBeamService = v_u_1.GetService("RikaLoveBeamService")
	v_u_9 = v_u_1.GetController("HitboxController")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11