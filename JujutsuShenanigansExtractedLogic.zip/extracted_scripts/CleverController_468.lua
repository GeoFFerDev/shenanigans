-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
require(v4.Modules.CameraShaker)
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "CleverController"
})
function v9.KnitStart(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_6, (copy) v_u_5, (copy) v_u_3, (copy) v_u_2, (ref) v_u_7
	local v_u_33 = {
		["Startup"] = function(p10)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v11 = p10:FindFirstChild("HumanoidRootPart")
			if v11 then
				v_u_8:PlaySound(v_u_6.Locust.FourArmed, v11, game.SoundService.Effect)
			end
		end,
		["Barrage"] = function(p12, p13)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_2, (ref) v_u_8, (ref) v_u_6
			local v14 = p12:FindFirstChild("HumanoidRootPart")
			if not v14 then
				return
			end
			local v15 = p12:FindFirstChildWhichIsA("Shirt")
			local v16 = p12["Left Arm"].Color
			local v17 = p12["Right Arm"].Color
			local v18 = 0
			while true do
				local v19 = v_u_5.Hakari.Barrage:Clone()
				if v15 then
					v15:Clone().Parent = v19
				end
				v19["Left Arm"].Color = v16
				v19["Right Arm"].Color = v17
				for _, v20 in v19:GetChildren() do
					if v20:IsA("BasePart") then
						if v20.Name == "ColorArm" then
							v20:Destroy()
						else
							local v21 = v14.CFrame * CFrame.new(math.random(-25, 25) / 10, math.random(-10, 10) / 10, math.random(-10, 10) / 10)
							local v22 = CFrame.Angles
							local v23 = math.random(70, 110)
							local v24 = math.rad(v23)
							local v25 = math.random(-20, 20)
							local v26 = math.rad(v25)
							local v27 = math.random(-20, 20)
							v20.CFrame = v21 * v22(v24, v26, (math.rad(v27)))
							v_u_3:Create(v20, TweenInfo.new(0.1), {
								["CFrame"] = v20.CFrame + v14.CFrame.LookVector * 7
							}):Play()
							v_u_3:Create(v20, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
								["Transparency"] = 1
							}):Play()
							local v28 = v_u_5.Gojo.LapseBlue.Throw:Clone()
							v28.CFrame = v14.CFrame - v14.Position + v20.Position + v14.CFrame.LookVector * 8
							v28.Size = Vector3.new(0, 0, 1)
							v28.Parent = v19
							v_u_3:Create(v28, TweenInfo.new(0.15), {
								["Size"] = Vector3.new(4, 4, 0),
								["Transparency"] = 1
							}):Play()
							v_u_2:AddItem(v28, 0.15)
						end
					end
				end
				v19.Parent = workspace.Effects
				v_u_2:AddItem(v19, 0.6)
				v18 = v18 + 1
				if v18 == 2 then
					v_u_8:PlaySound(v_u_6.Misc.Swing.Fist, v14, game.SoundService.Effect)
					v18 = 0
				end
				task.wait(0.025)
				if not p13.Parent then
					return
				end
			end
		end,
		["Hit"] = function(p29)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_8:Flash(p29, Color3.new(1, 1, 1))
				v_u_8:PlaySound(v_u_6.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 3)), v30, game.SoundService.Effect)
			end
		end,
		["Hit2"] = function(p31)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			local v32 = p31:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_8:Flash(p31, Color3.new(1, 1, 1))
				v_u_8:PlaySound(v_u_6.Gojo.M1:FindFirstChild("Hit4"), v32, game.SoundService.Effect)
				v_u_8:PlaySound(v_u_6.Itadori.CraniumSmash.Hit2, v32, game.SoundService.Effect)
			end
		end
	}
	v_u_7.Effects:Connect(function(p34, ...)
		-- upvalues: (copy) v_u_33
		local v35 = v_u_33[p34]
		if v35 then
			v35(...)
		end
	end)
end
function v9.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("CleverService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v9