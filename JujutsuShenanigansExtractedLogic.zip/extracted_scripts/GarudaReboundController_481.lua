-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = require(v6.Modules.BloodyZee)
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "GarudaReboundController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_2, (copy) v_u_7, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (copy) v_u_10, (ref) v_u_11
	local v_u_79 = {
		["Startup"] = function(p14)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_12:PlaySound(v_u_8.Yuki.Rebound.Startup, v15, game.SoundService.Effect)
			end
		end,
		["Punch"] = function(p16)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_12:PlaySound(v_u_8.Yuki.Rebound.Punch, v17, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p_u_18, p19, p_u_20)
			-- upvalues: (ref) v_u_2
			local v_u_21 = p_u_18.CFrame
			local v_u_22 = tick()
			local v_u_23 = p_u_18:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_21, (copy) p_u_18, (ref) v_u_22
				v_u_21 = p_u_18.CFrame
				v_u_22 = tick()
			end)
			local v_u_24 = p19 or 160
			local v_u_25 = nil
			v_u_25 = v_u_2.Stepped:Connect(function(_, p26)
				-- upvalues: (copy) p_u_18, (ref) v_u_25, (copy) v_u_23, (copy) p_u_20, (ref) v_u_21, (ref) v_u_24, (ref) v_u_22
				if p_u_18.Parent then
					if p_u_18:GetAttribute("Freeze") then
						p_u_18.Trail.Lifetime = 20
					else
						p_u_18.Trail.Lifetime = p_u_20 and 0.5 or 0.1
						workspace:BulkMoveTo({ p_u_18 }, { v_u_21 + v_u_21.LookVector * (v_u_24 * (tick() - v_u_22)) }, Enum.BulkMoveMode.FireCFrameChanged)
						local v27 = p_u_18.Attachment
						v27.CFrame = v27.CFrame * CFrame.Angles(0, 0, math.random(0, 3.141592653589793))
						local v28 = p_u_18.GarudaBall.Weld
						local v29 = v28.C1
						local v30 = CFrame.Angles
						local v31 = 400 * p26
						local v32 = math.rad(v31)
						local v33 = 400 * p26
						v28.C1 = v29 * v30(v32, math.rad(v33), 0)
					end
				else
					v_u_25:Disconnect()
					v_u_23:Disconnect()
					return
				end
			end)
		end,
		["Recall"] = function(p34, p35, p36, p37)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v38 = p34:FindFirstChild("HumanoidRootPart")
			if v38 then
				for _, v39 in p35:GetDescendants() do
					if v39:IsA("Beam") or v39:IsA("ParticleEmitter") then
						v39.Enabled = false
					end
				end
				local v40 = tick()
				if p37 == 0.1 then
					v_u_12:PlaySound(v_u_8.Yuki.Rebound.Return, v38, game.SoundService.Effect)
					repeat
						task.wait()
						local v41 = (tick() - v40) / p37
						p35.Position = p36:Lerp(v38.Position, v41)
					until not v38.Parent or p37 < tick() - v40
				else
					v_u_12:PlaySound(v_u_8.Yuki.Rebound.Bounce, v38, game.SoundService.Effect)
					repeat
						task.wait()
						local v42 = (tick() - v40) / p37
						local v43 = p36:Lerp(v38.Position, v42)
						local v44 = v42 * 3.14
						local v45 = math.sin(v44) * 15
						local v46 = v43 + Vector3.new(0, v45, 0)
						p35.CFrame = CFrame.lookAlong(v46, v46 - p35.Position)
					until not v38.Parent or p37 < tick() - v40
				end
				if p35 then
					p35:Destroy()
				end
			end
		end,
		["Hit"] = function(p47, p48)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v49 = p48:FindFirstChild("HumanoidRootPart")
			if v49 then
				v_u_12:Flash(p48, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Yuki.Rebound.Hit, v49, game.SoundService.Effect)
				local v50 = v_u_7.Gojo.Twofold.Sparks:Clone()
				v50.Parent = v49.RootAttachment
				v50:Emit(20)
				v_u_3:AddItem(v50, 0.4)
				if v_u_5 == p47 or v_u_5.Character == p48 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end,
		["HeavyHit"] = function(p51, p52)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				local v54 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
				v54.Position = v53.Position
				v54.Parent = workspace.Effects
				v_u_3:AddItem(v54, 1)
				v54.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v54.Wind.Color = v54.Sparks.Color
				v54.Wind2.Color = v54.Sparks.Color
				v54.Sparks:Emit(50)
				v54.Wind:Emit(7)
				v54.Wind2:Emit(7)
				v_u_12:Flash(p52, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v53, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Todo.BruteForce.Hit, v53, game.SoundService.Effect)
				if v_u_5 == p51 or v_u_5.Character == p52 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["Kick"] = function(p55)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v56 = p55:FindFirstChild("HumanoidRootPart")
			if v56 then
				local v57 = v_u_7.Choso.CounterSwing.Shock:Clone()
				v57.Size = Vector3.new(6, 30, 6)
				v57.CFrame = v56.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v57.Parent = workspace.Effects
				v_u_3:AddItem(v57, 0.2)
				v_u_4:Create(v57, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = v57.Position + v56.CFrame.LookVector * 10
				}):Play()
				v_u_12:PlaySound(v_u_8.Mahito.Stockpile.Swing2, v56, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Todo.BruteForce.Swing, v56, game.SoundService.Effect)
				if v_u_5.Character == p55 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Woosh"] = function(p58)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v59 = p58:FindFirstChild("HumanoidRootPart")
			if v59 then
				local v60 = v_u_7.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v60.CFrame = v59.CFrame * CFrame.new(2, 1, -5)
				v60.Parent = workspace.Effects
				v60.Wind:Emit(20)
				v60.PointLight:Destroy()
				v60.Back1.Back:Emit(1)
				v60.Back2.Back:Emit(1)
				v_u_4:Create(v60.Back1, TweenInfo.new(2), {
					["CFrame"] = v60.Back1.CFrame - v60.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_4:Create(v60.Back2, TweenInfo.new(2), {
					["CFrame"] = v60.Back2.CFrame - v60.Back2.CFrame.LookVector * 20
				}):Play()
				v_u_3:AddItem(v60, 3)
				local v61 = v_u_7.Choso.CounterSwing.Shock:Clone()
				v61.Size = Vector3.new(6, 30, 6)
				v61.CFrame = v59.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v61.Parent = workspace.Effects
				v_u_3:AddItem(v61, 0.2)
				v_u_4:Create(v61, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = v61.Position + v59.CFrame.LookVector * 10
				}):Play()
				v_u_12:PlaySound(v_u_8.Mahito.Stockpile.Swing2, v59, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Todo.BruteForce.Swing, v59, game.SoundService.Effect)
				if v_u_5.Character == p58 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Impact"] = function(p62)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9
			local v63 = p62:FindFirstChild("HumanoidRootPart")
			if v63 then
				if v_u_5.Character == p62 then
					local v_u_64 = Instance.new("ColorCorrectionEffect", game.Lighting)
					v_u_3:AddItem(v_u_64, 0.85)
					v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["FieldOfView"] = 50
					}):Play()
					v_u_4:Create(v_u_64, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["Saturation"] = -0.5
					}):Play()
					task.delay(0.5, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_64
						v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(0.35, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
							["FieldOfView"] = 70
						}):Play()
						v_u_4:Create(v_u_64, TweenInfo.new(0.35, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["Saturation"] = 0
						}):Play()
					end)
					if math.random(1, 20) == 1 then
						v_u_12:PlaySound(v_u_8.Yuki.Secret, v63, game.SoundService.Voice)
						v_u_12:PlaySound(v_u_8.Yuki.SecretSFX, v63, game.SoundService.Effect)
					end
				end
				local v_u_65 = v_u_7.Yuki.KickWarp:Clone()
				v_u_65.Weld.Part0 = p62["Left Leg"]
				v_u_65.Parent = workspace.Effects
				v_u_3:AddItem(v_u_65, 1.5)
				local v66 = Instance.new("Highlight", v_u_65)
				v66.FillTransparency = 1
				v66.OutlineTransparency = 1
				v_u_3:AddItem(v66, 1.5)
				v_u_4:Create(v_u_65, TweenInfo.new(0.6, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(25, 1, 25),
					["Transparency"] = 5
				}):Play()
				v_u_4:Create(v_u_65.Weld, TweenInfo.new(0.85, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
					["C1"] = v_u_65.Weld.C1 * CFrame.Angles(0, 179, 0)
				}):Play()
				task.delay(0.6, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_65
					v_u_4:Create(v_u_65, TweenInfo.new(0.25, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(0, 50, 0),
						["Transparency"] = 1
					}):Play()
					v_u_65.impactframelines1.Enabled = true
					v_u_65.impactframeines3.Enabled = true
					task.wait(0.25)
					v_u_65.impactframelines1.Enabled = false
					v_u_65.impactframeines3.Enabled = false
					v_u_65.Flare:Destroy()
				end)
				v_u_65.Flare.Flare:Emit(8)
				v_u_65.Flare.Wind2:Emit(10)
				for _, v67 in v_u_65.Hit:GetChildren() do
					v67:Emit(v67:GetAttribute("EmitCount"))
					v_u_4:Create(v67, TweenInfo.new(0.85, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["TimeScale"] = 1
					}):Play()
				end
				v_u_12:PlaySound(v_u_8.Yuki.Rebound.Slow, v63, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v63.Position).Magnitude < 150 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1)
				end
			end
		end,
		["TrueFinish"] = function(p68, p69, p70)
			-- upvalues: (ref) v_u_5, (ref) v_u_12, (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_9
			local v71 = p69:FindFirstChild("HumanoidRootPart")
			if v71 then
				if v_u_5.Character == p69 or v_u_5 == p68 then
					v_u_12:PlaySound(v_u_8.Yuki.Freeze, workspace, game.SoundService.Effect)
					game.Lighting.ExposureCompensation = 3
					task.wait(0.3)
					game.Lighting.ExposureCompensation = 0
				else
					v_u_12:PlaySound(v_u_8.Yuki.Freeze, v71, game.SoundService.Effect)
					task.wait(0.3)
				end
				v_u_12:PlaySound(v_u_8.Yuki.Explode, v71, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Yuki.Explode2, v71, game.SoundService.Effect)
				for _, v72 in p69:GetDescendants() do
					if v72:IsA("BasePart") or v72:IsA("Decal") then
						v72.Transparency = 1
					end
				end
				local v73 = CFrame.lookAlong(v71.Position, p70)
				for _ = 1, 100 do
					v_u_10:Blood(v73, math.random(200, 300), 40, 40)
				end
				if _G.Settings.Gore then
					local v74 = v_u_7.Heian.BloodSpread:Clone()
					v74.Parent = p69.Head
					v74:Emit(60)
					v_u_3:AddItem(v74, 2)
				end
				for _ = 1, 20 do
					local v_u_75 = v_u_7.Damage.Chunk:Clone()
					v_u_75.CFrame = v71.CFrame
					v_u_75.CollisionGroup = "Effects"
					v_u_75.Velocity = p70 * math.random(50, 200)
					v_u_75.CanCollide = true
					local v76 = math.random(-200, 200)
					local v77 = math.random(-200, 200)
					local v78 = math.random
					v_u_75.RotVelocity = Vector3.new(v76, v77, v78(-200, 200))
					v_u_75.Parent = workspace.Effects
					v_u_3:AddItem(v_u_75, 2)
					task.delay(2, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_75
						v_u_4:Create(v_u_75, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_75.Blood.Enabled = false
						v_u_75.Trail.Enabled = false
					end)
					if _G.Settings.Gore == false then
						v_u_75.Color = Color3.fromRGB(255, 85, 255)
						v_u_75.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
						v_u_75.Blood.Color = v_u_75.Trail.Color
					end
				end
				if v_u_5:DistanceFromCharacter(v71.Position) < 40 or v_u_5 == p68 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p80, ...)
		-- upvalues: (copy) v_u_79
		local v81 = v_u_79[p80]
		if v81 then
			v81(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("GarudaReboundService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13