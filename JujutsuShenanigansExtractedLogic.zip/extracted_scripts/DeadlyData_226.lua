-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Crimes"] = {
		"Teaming",
		"Attempted murder",
		"Murder",
		"Littering",
		"Theft",
		"Destruction of public property",
		"Loitering",
		"Grand Theft Auto",
		"Toxicity",
		"Driving without a license",
		"Using Vessel",
		"Suggesting a Vessel buff",
		"Trespassing",
		"Vandalism",
		"Going skydiving on a sunday",
		"Leaking supporter streams",
		"Inciting Honored One",
		"Mass murder in Shibuya",
		"Using a forbidden technique",
		"Spamming Confess",
		"Ragequitting",
		"Steering Mahoraga\'s wheel",
		"Suggesting Strongest of Today",
		"Doing a green combo",
		"Disrupting the delivery system",
		"Criticising Unlicensed Studios"
	},
	["Dialog"] = {
		{
			{ "I didn\'t do it!", "...", "It was me." },
			{ "Evidence says otherwise", "...?", "That takes care of that." }
		},
		{
			{ "That wasn\'t me", "...", "IT WAS ME!" },
			{ "You did.......", "Too scared to admit it?", "Thanks for making my life easier." }
		},
		{
			{ "It says gullible on the ceiling!", "I plead the 5th.", "Let\'s get this over with." },
			{ "I\'m not falling for that...", "That doesn\'t help your case...", "GUILTY." }
		},
		{
			{ "I didn\'t...", ".....", "Yeah, I did that." },
			{ "Cat got your tongue?", "Are you feeling remorse?", "...?!" }
		}
	},
	["DialogFail"] = {
		"Erm...",
		"What?",
		"That\'s not quite right.",
		"Are you sure?"
	}
}