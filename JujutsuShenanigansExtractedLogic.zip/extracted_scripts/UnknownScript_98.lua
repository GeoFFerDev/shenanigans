-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

if script.Parent.Parent == game.Players.LocalPlayer.Character then
	local v1 = require(game.ReplicatedStorage.Modules.CameraShaker)
	v1.CurrentShaker:ShakeSustain(v1.Presets.Snap):StartFadeOut(1)
end