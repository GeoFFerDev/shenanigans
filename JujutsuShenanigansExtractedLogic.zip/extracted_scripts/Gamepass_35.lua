-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "gamepass",
	["Description"] = "Gifts a gamepass to the player",
	["Group"] = { "Owner", "Developer", "HeadMod" },
	["Args"] = {
		{
			["Type"] = "username",
			["Name"] = "Username"
		},
		{
			["Type"] = "number",
			["Name"] = "ID of gamepass"
		}
	}
}
return v1