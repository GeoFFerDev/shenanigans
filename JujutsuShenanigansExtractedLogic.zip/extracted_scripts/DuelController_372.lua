-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
require(v5.Modules.Icon)
local _ = v5.Animations
local _ = v5.Utils
local v_u_6 = v5.Sounds
require(v5.Modules.CameraShaker)
local v_u_7 = require(v5.Modules.MVP)
require(game.ReplicatedStorage.Modules.CountryCodes)
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "DuelController"
})
local v_u_11 = {
	{
		["Title"] = "Revealing one\'s hands",
		["Name"] = "Reveal",
		["Background"] = 81779608092469,
		["Info"] = { "1.1x HP", "Cooldowns are shown next to you" }
	},
	{
		["Title"] = "Overtime",
		["Name"] = "Overtime",
		["Background"] = 7061206855,
		["Info"] = { "0.9x DMG for all but your last lives", "1.25x DMG your last life" }
	},
	{
		["Title"] = "Taking a Gamble",
		["Name"] = "Gamble",
		["Background"] = 112774677152378,
		["Info"] = { "1.2x DMG", "Lose one random skill every respawn" }
	},
	{
		["Title"] = "Never Again",
		["Name"] = "Never",
		["Background"] = 81810628540744,
		["Info"] = { "1.35x DMG", "Lose a skill once it\'s used twice" }
	},
	{
		["Title"] = "True Love",
		["Name"] = "True",
		["Background"] = 74011425921907,
		["Info"] = { "1.3x AWK", "Awakening automatically activates", "Death when awakening ends" }
	},
	{
		["Title"] = "Enchain",
		["Name"] = "Enchain",
		["Background"] = 136074741603886,
		["Info"] = { "1.3x AWK", "Instantly restore all health when activating awakening", "You can not harm anyone for the first 12 seconds" }
	}
}
local function v_u_17(p12)
	-- upvalues: (copy) v_u_17
	local v13 = {}
	for v14, v16 in pairs(p12) do
		if type(v16) == "table" then
			local v16 = v_u_17(v16)
		end
		v13[v14] = v16
	end
	return v13
end
function v10.Start(_)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (ref) v_u_9, (copy) v_u_6, (ref) v_u_8, (copy) v_u_2, (copy) v_u_7, (copy) v_u_17, (copy) v_u_11
	local v_u_18 = nil
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_9, (ref) v_u_6, (ref) v_u_8
		local v_u_19 = v_u_4.PlayerGui:WaitForChild("Ranked")
		local v_u_20 = game.Teams:WaitForChild("Sorcerers")
		local v_u_21 = game.Teams:WaitForChild("Curses")
		local v_u_22 = UDim2.new(0, 0, 0.4, 0)
		local v23 = v_u_19.NameL
		v23.Position = v23.Position - v_u_22
		local v24 = v_u_19.NameR
		v24.Position = v24.Position - v_u_22
		local v25 = v_u_19.StockL
		v25.Position = v25.Position - v_u_22
		local v26 = v_u_19.StockR
		v26.Position = v26.Position - v_u_22
		v_u_19.Enabled = true
		for _ = 1, v_u_20:GetAttribute("Lives") or 3 do
			v_u_19.Preset.Stock:Clone().Parent = v_u_19.StockL
		end
		v_u_20:GetAttributeChangedSignal("Lives"):Connect(function()
			-- upvalues: (copy) v_u_19, (copy) v_u_20, (ref) v_u_3, (ref) v_u_9, (ref) v_u_6
			for _, v27 in v_u_19.StockL:GetChildren() do
				if v27.Name == "Stock" then
					v27:Destroy()
				end
			end
			for _ = 1, v_u_20:GetAttribute("Lives") or 3 do
				v_u_19.Preset.Stock:Clone().Parent = v_u_19.StockL
			end
			if workspace:GetAttribute("Match") == true then
				v_u_19.StockL.Position = game.StarterGui.Ranked.StockL.Position + UDim2.new(0, 0, 0, 20)
				v_u_3:Create(v_u_19.StockL, TweenInfo.new(0.75, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					["Position"] = game.StarterGui.Ranked.StockL.Position
				}):Play()
				v_u_9:PlaySound(v_u_6.Misc.UI.StockLose, workspace, game.SoundService.Effect)
			end
		end)
		for _ = 1, v_u_21:GetAttribute("Lives") or 3 do
			v_u_19.Preset.Stock2:Clone().Parent = v_u_19.StockR
		end
		v_u_21:GetAttributeChangedSignal("Lives"):Connect(function()
			-- upvalues: (copy) v_u_19, (copy) v_u_21, (ref) v_u_3, (ref) v_u_9, (ref) v_u_6
			for _, v28 in v_u_19.StockR:GetChildren() do
				if v28.Name == "Stock2" then
					v28:Destroy()
				end
			end
			for _ = 1, v_u_21:GetAttribute("Lives") or 3 do
				v_u_19.Preset.Stock2:Clone().Parent = v_u_19.StockR
			end
			if workspace:GetAttribute("Match") == true then
				v_u_19.StockR.Position = game.StarterGui.Ranked.StockR.Position + UDim2.new(0, 0, 0, 20)
				v_u_3:Create(v_u_19.StockR, TweenInfo.new(0.75, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					["Position"] = game.StarterGui.Ranked.StockR.Position
				}):Play()
				v_u_9:PlaySound(v_u_6.Misc.UI.StockLose, workspace, game.SoundService.Effect)
			end
		end)
		local v29 = v_u_20:GetPlayers()
		for v30, v31 in v29 do
			v29[v30] = v31.Name
		end
		v_u_19.NameL.Text = table.concat(v29, ", ")
		local v32 = v_u_21:GetPlayers()
		for v33, v34 in v32 do
			v32[v33] = v34.Name
		end
		v_u_19.NameR.Text = table.concat(v32, ", ")
		workspace:GetAttributeChangedSignal("Match"):Connect(function()
			-- upvalues: (ref) v_u_3, (copy) v_u_19, (copy) v_u_22
			if workspace:GetAttribute("Match") == true then
				local v35 = TweenInfo.new(1.25, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				v_u_3:Create(v_u_19.NameL, v35, {
					["Position"] = game.StarterGui.Ranked.NameL.Position
				}):Play()
				v_u_3:Create(v_u_19.NameR, v35, {
					["Position"] = game.StarterGui.Ranked.NameR.Position
				}):Play()
				v_u_3:Create(v_u_19.StockL, v35, {
					["Position"] = game.StarterGui.Ranked.StockL.Position
				}):Play()
				v_u_3:Create(v_u_19.StockR, v35, {
					["Position"] = game.StarterGui.Ranked.StockR.Position
				}):Play()
			else
				local v36 = TweenInfo.new(1.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In)
				v_u_3:Create(v_u_19.NameL, v36, {
					["Position"] = game.StarterGui.Ranked.NameL.Position - v_u_22
				}):Play()
				v_u_3:Create(v_u_19.NameR, v36, {
					["Position"] = game.StarterGui.Ranked.NameR.Position - v_u_22
				}):Play()
				v_u_3:Create(v_u_19.StockL, v36, {
					["Position"] = game.StarterGui.Ranked.StockL.Position - v_u_22
				}):Play()
				v_u_3:Create(v_u_19.StockR, v36, {
					["Position"] = game.StarterGui.Ranked.StockR.Position - v_u_22
				}):Play()
			end
		end)
		if workspace:GetAttribute("Match") == true then
			local v37 = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
			v_u_3:Create(v_u_19.NameL, v37, {
				["Position"] = game.StarterGui.Ranked.NameL.Position
			}):Play()
			v_u_3:Create(v_u_19.NameR, v37, {
				["Position"] = game.StarterGui.Ranked.NameR.Position
			}):Play()
			v_u_3:Create(v_u_19.StockL, v37, {
				["Position"] = game.StarterGui.Ranked.StockL.Position
			}):Play()
			v_u_3:Create(v_u_19.StockR, v37, {
				["Position"] = game.StarterGui.Ranked.StockR.Position
			}):Play()
		end
		v_u_19.Menu.Rematch.MouseButton1Down:Connect(function()
			-- upvalues: (copy) v_u_19, (ref) v_u_9, (ref) v_u_6, (ref) v_u_8
			v_u_19.Menu.Rematch.Text = "Voted"
			v_u_9:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Music)
			v_u_9:PlaySound(v_u_6.Misc.UI.Switch, workspace, game.SoundService.Music)
			v_u_8.MatchEnd:Fire(1)
		end)
		v_u_19.Menu.Return.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_8
			v_u_9:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Music)
			v_u_8.MatchEnd:Fire(2)
		end)
		v_u_19.Menu.Rematch.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			v_u_9:PlaySound(v_u_6.Misc.UI.Hover, workspace, game.SoundService.Effect)
		end)
		v_u_19.Menu.Return.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			v_u_9:PlaySound(v_u_6.Misc.UI.Hover, workspace, game.SoundService.Effect)
		end)
	end)
	local v_u_92 = {
		["Countdown"] = function()
			-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v38 = v_u_4.PlayerGui:WaitForChild("Ranked")
			for _, v39 in v38.Vows:GetChildren() do
				v39.Visible = false
			end
			v_u_9:PlaySound(v_u_6.Misc.UI.Countdown, workspace, game.SoundService.Effect)
			local v_u_40 = v38.Preset.Countdown:Clone()
			v_u_40.Parent = v38
			v_u_3:Create(v_u_40, TweenInfo.new(0.9, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				["Rotation"] = 0,
				["Size"] = UDim2.new(0, 200, 0, 200)
			}):Play()
			task.wait(1)
			v_u_40.Size = UDim2.new(0, 300, 0, 300)
			v_u_40.Rotation = 25
			v_u_40.Text = "<stroke> 2 </stroke>"
			v_u_3:Create(v_u_40, TweenInfo.new(0.9, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				["Rotation"] = 0,
				["Size"] = UDim2.new(0, 200, 0, 200)
			}):Play()
			task.wait(1)
			v_u_40.Size = UDim2.new(0, 300, 0, 300)
			v_u_40.Rotation = 25
			v_u_40.Text = "<stroke> 1 </stroke>"
			v_u_3:Create(v_u_40, TweenInfo.new(0.9, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				["Rotation"] = 0,
				["Size"] = UDim2.new(0, 200, 0, 200)
			}):Play()
			task.wait(1)
			v_u_40.Size = UDim2.new(0, 300, 0, 300)
			v_u_40.Rotation = 25
			v_u_40.Text = "<stroke> GO! </stroke>"
			v_u_3:Create(v_u_40, TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				["Rotation"] = 0,
				["Size"] = UDim2.new(0, 200, 0, 200)
			}):Play()
			v_u_3:Create(v_u_40, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
				["TextTransparency"] = 1
			}):Play()
			v_u_2:AddItem(v_u_40, 2)
			task.spawn(function()
				-- upvalues: (copy) v_u_40
				repeat
					v_u_40.Text = "<stroke transparency=\"" .. v_u_40.TextTransparency .. "\">GO!</stroke>"
					task.wait()
				until not v_u_40.Parent
			end)
		end,
		["Result"] = function(p41, p42, p43)
			-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_6, (ref) v_u_18, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2
			local v44 = v_u_4.PlayerGui:WaitForChild("Ranked")
			local v_u_45 = v44:FindFirstChild("Result")
			if not v_u_45 then
				v_u_45 = game.StarterGui.Ranked.Result:Clone()
				v_u_45.Parent = v44
			end
			v_u_9:PlaySound(v_u_6.Misc.UI.DuelEnd, workspace, game.SoundService.Music)
			if p42 then
				if v_u_18 then
					v_u_7:MVP_End(v_u_18, true)
					v_u_18 = nil
				end
				v_u_18 = v_u_7:MVP_Play(p42, p43 or "King Of Curses")
			end
			if v_u_4.Team == p41 then
				v_u_9:PlaySound(v_u_6.Misc.UI.Win, workspace, game.SoundService.Effect)
				v_u_45.Star.Visible = true
				v_u_45.Flash.Visible = true
				v_u_45.Fade.Visible = true
				v_u_3:Create(v_u_45.Star, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = UDim2.new(0, 0, 0, 0),
					["Rotation"] = 0
				}):Play()
				v_u_3:Create(v_u_45.Flash, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = UDim2.new(1, 0, 0.2, 0)
				}):Play()
				v_u_3:Create(v_u_45.Fade, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = UDim2.new(1, 0, 0.5, 0)
				}):Play()
				task.delay(2, function()
					-- upvalues: (ref) v_u_3, (ref) v_u_45, (ref) v_u_2
					local v46 = TweenInfo.new(0.5)
					v_u_3:Create(v_u_45.Star, v46, {
						["ImageTransparency"] = 1
					}):Play()
					v_u_3:Create(v_u_45.Flash, v46, {
						["TextTransparency"] = 1
					}):Play()
					v_u_3:Create(v_u_45.Fade, v46, {
						["ImageTransparency"] = 1
					}):Play()
					v_u_2:AddItem(v_u_45, 0.5)
					repeat
						v_u_45.Flash.Text = "<stroke transparency=\"" .. v_u_45.Flash.TextTransparency .. "\">SHENANIGAN\'ED!</stroke>"
						task.wait()
					until not v_u_45.Parent
				end)
			else
				v_u_9:PlaySound(v_u_6.Misc.UI.Lose, workspace, game.SoundService.Effect)
				v_u_45.Flash.TextColor3 = Color3.fromRGB(171, 171, 255)
				v_u_45.Fade.ImageColor3 = Color3.fromRGB(85, 85, 127)
				v_u_45.Flash.Visible = true
				v_u_45.Fade.Visible = true
				v_u_3:Create(v_u_45.Flash, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = UDim2.new(1, 0, 0.2, 0)
				}):Play()
				v_u_3:Create(v_u_45.Fade, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = UDim2.new(1, 0, 0.5, 0)
				}):Play()
				task.delay(2, function()
					-- upvalues: (ref) v_u_3, (ref) v_u_45, (ref) v_u_2
					local v47 = TweenInfo.new(0.5)
					v_u_3:Create(v_u_45.Flash, v47, {
						["TextTransparency"] = 1
					}):Play()
					v_u_3:Create(v_u_45.Fade, v47, {
						["ImageTransparency"] = 1
					}):Play()
					v_u_2:AddItem(v_u_45, 0.5)
					repeat
						v_u_45.Flash.Text = "<stroke transparency=\"" .. v_u_45.Flash.TextTransparency .. "\">SHENANIGAN\'ED!</stroke>"
						task.wait()
					until not v_u_45.Parent
				end)
			end
		end,
		["Vows"] = function()
			-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_6, (ref) v_u_17, (ref) v_u_11, (ref) v_u_3, (ref) v_u_8, (ref) v_u_2
			local v_u_48 = v_u_4.PlayerGui:WaitForChild("Ranked")
			local v_u_49 = v_u_48.Vows
			v_u_49.TextLabel.Visible = true
			v_u_9:PlaySound(v_u_6.Misc.UI.VowChoose, workspace, game.SoundService.Effect)
			local v_u_50 = v_u_17(v_u_11)
			local v_u_51 = {}
			local v52 = 0
			for v_u_53 = 1, 3 do
				local v_u_54 = v_u_49["Vow" .. v_u_53]
				task.delay(v52, function()
					-- upvalues: (ref) v_u_9, (ref) v_u_6, (copy) v_u_54, (ref) v_u_3, (copy) v_u_50, (copy) v_u_48, (ref) v_u_8, (copy) v_u_49, (copy) v_u_51, (copy) v_u_53, (ref) v_u_2
					v_u_9:PlaySound(v_u_6.Misc.UI.CardFlip, workspace, game.SoundService.Effect)
					local v55 = v_u_54
					v55.Position = v55.Position - UDim2.new(0, 0, 1, 0)
					v_u_3:Create(v_u_54, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["Position"] = v_u_54.Position + UDim2.new(0, 0, 1, 0)
					}):Play()
					v_u_54.AnchorPoint = Vector2.new(0.5, 0.5)
					v_u_54.Size = UDim2.new(0, 200, 0, 250)
					local v56 = math.random(1, #v_u_50)
					local v_u_57 = v_u_50[v56]
					v_u_54.Title.Text = v_u_57.Title
					v_u_54.BG.Image = "rbxassetid://" .. v_u_57.Background
					for _, v58 in v_u_57.Info do
						local v59 = v_u_48.Preset.Info:Clone()
						v59.Text = "\226\128\162 " .. v58
						v59.Parent = v_u_54.Info
					end
					local v60 = v_u_54.TextButton.MouseEnter:Connect(function()
						-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_3, (ref) v_u_54
						v_u_9:PlaySound(v_u_6.Misc.UI.Hover, workspace, game.SoundService.Effect)
						v_u_9:PlaySound(v_u_6.Misc.UI.Hover, workspace, game.SoundService.Effect)
						v_u_3:Create(v_u_54, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
							["Size"] = UDim2.new(0, 205, 0, 255),
							["AnchorPoint"] = Vector2.new(0.5, 0.525)
						}):Play()
					end)
					local v61 = v_u_54.TextButton.MouseLeave:Connect(function()
						-- upvalues: (ref) v_u_3, (ref) v_u_54
						v_u_3:Create(v_u_54, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
							["Size"] = UDim2.new(0, 200, 0, 250),
							["AnchorPoint"] = Vector2.new(0.5, 0.5)
						}):Play()
					end)
					local v65 = v_u_54.TextButton.MouseButton1Down:Connect(function()
						-- upvalues: (ref) v_u_8, (copy) v_u_57, (ref) v_u_9, (ref) v_u_6, (ref) v_u_49, (ref) v_u_54
						v_u_8.Vows:Fire(v_u_57.Name)
						v_u_9:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
						v_u_9:PlaySound(v_u_6.Misc.UI.Switch, workspace, game.SoundService.Effect)
						for _, v62 in v_u_49:GetChildren() do
							if v62:IsA("Frame") then
								local v63 = v62 == v_u_54 and Color3.new(1, 1, 1) or Color3.new(0, 0, 0)
								v62.UIStroke.Color = v63
								v62.Title.TextColor3 = v63
								for _, v64 in v62.Info:GetChildren() do
									if v64:IsA("TextLabel") then
										v64.TextColor3 = v63
									end
								end
							end
						end
					end)
					v_u_54.Visible = true
					local v66 = v_u_51
					table.insert(v66, v60)
					local v67 = v_u_51
					table.insert(v67, v61)
					local v68 = v_u_51
					table.insert(v68, v65)
					table.remove(v_u_50, v56)
					if v_u_53 == 1 then
						while true do
							for v69 = 1, 3 do
								local v70 = math.random(100, 200) / 100
								local v71 = TweenInfo.new(v70, Enum.EasingStyle.Linear)
								local v72 = math.random(40, 80) / 100
								local v73 = v_u_48.Preset.Particle:Clone()
								v73.Position = UDim2.new(math.random(0, 100) / 100, 0, 1.3, 0)
								v73.Size = UDim2.new(v72, 0, v72, 0)
								v73.Parent = v_u_49["Vow" .. v69].Effect
								v_u_3:Create(v73, v71, {
									["Position"] = v73.Position - UDim2.new(0, 0, 1.6, 0)
								}):Play()
								v_u_2:AddItem(v73, v70)
							end
							task.wait(0.1)
							if v_u_49.Vow1.Visible == false then
								goto l5
							end
						end
					else
						::l5::
						return
					end
				end)
				v52 = v52 + 0.15
			end
			for v74 = 10, 1, -1 do
				v_u_49.TextLabel.Text = "Choose a binding vow (" .. v74 .. "):"
				task.wait(1)
			end
			for _, v75 in v_u_48.Vows:GetChildren() do
				v75.Visible = false
			end
			for _, v76 in v_u_51 do
				v76:Disconnect()
			end
			for _, v77 in v_u_49:GetChildren() do
				if v77:IsA("Frame") then
					local v78 = Color3.new(0, 0, 0)
					v77.UIStroke.Color = v78
					v77.Title.TextColor3 = v78
					for _, v79 in v77.Info:GetChildren() do
						if v79:IsA("TextLabel") then
							v79:Destroy()
						end
					end
				end
			end
		end,
		["Teleport"] = function(p80)
			-- upvalues: (ref) v_u_4
			local v81 = v_u_4.PlayerGui:WaitForChild("Ranked")
			local v82 = v81.Preset.Teleport:Clone()
			v82.Parent = v81.Parent
			v82.TextLabel.Text = p80
			v82.Sound.SoundGroup = game.SoundService.Effect
			v82.Sound:Play()
			game:GetService("TweenService"):Create(v82.Frame, TweenInfo.new(0.3), {
				["BackgroundTransparency"] = 0.5
			}):Play()
			game:GetService("TweenService"):Create(v82.TextLabel, TweenInfo.new(0.3), {
				["TextTransparency"] = 0
			}):Play()
		end,
		["Menu"] = function(p83, p84)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_9, (ref) v_u_6
			local v85 = v_u_4.PlayerGui:WaitForChild("Ranked")
			v85.Menu.Visible = true
			v85.Menu.Rematch.Text = "Rematch (" .. p83 .. " Left)"
			v85.Menu.Rematch.Visible = true
			v85.Menu.Return.Visible = true
			v_u_3:Create(v85.Menu, TweenInfo.new(0.3), {
				["GroupTransparency"] = 0.5
			}):Play()
			for v86, v87 in p84 or {} do
				local v_u_88 = v85.Parent.Roulette.Preset.Rewards:Clone()
				v_u_88.Parent = v85.Stats
				v_u_88.Text = v87
				v_u_88.Visible = false
				task.delay(0.3 + v86 * 0.075, function()
					-- upvalues: (copy) v_u_88, (ref) v_u_9, (ref) v_u_6
					if v_u_88.Parent then
						v_u_88.Visible = true
						v_u_9:PlaySound(v_u_6.Misc.UI.Coin, workspace, game.SoundService.Effect)
					end
				end)
			end
			v85.Stats.Visible = true
		end,
		["MenuClose"] = function()
			-- upvalues: (ref) v_u_4, (ref) v_u_3
			local v89 = v_u_4.PlayerGui:WaitForChild("Ranked")
			v_u_3:Create(v89.Menu, TweenInfo.new(0.3), {
				["GroupTransparency"] = 1
			}):Play()
			task.wait(0.3)
			v89.Menu.Visible = false
			for _, v90 in v89.Stats:GetChildren() do
				if not v90:IsA("UIListLayout") then
					v90:Destroy()
				end
			end
			v89.Stats.Visible = false
		end,
		["Rematch"] = function()
			-- upvalues: (ref) v_u_4, (ref) v_u_2, (ref) v_u_9, (ref) v_u_6, (ref) v_u_18, (ref) v_u_7
			local v91 = v_u_4.PlayerGui:WaitForChild("Ranked").Preset.Teleport:Clone()
			v_u_2:AddItem(v91, 1.5)
			v91.Parent = v_u_4.PlayerGui
			v91.TextLabel.Text = "REMATCHING!"
			v_u_9:PlaySound(v_u_6.Misc.UI.Gamemode, workspace, game.SoundService.Effect)
			game:GetService("TweenService"):Create(v91.Frame, TweenInfo.new(0.3), {
				["BackgroundTransparency"] = 0.5
			}):Play()
			game:GetService("TweenService"):Create(v91.TextLabel, TweenInfo.new(0.3), {
				["TextTransparency"] = 0
			}):Play()
			task.wait(0.3)
			game:GetService("TweenService"):Create(v91.Frame, TweenInfo.new(0.7), {
				["BackgroundTransparency"] = 0
			}):Play()
			task.wait(0.7)
			game:GetService("TweenService"):Create(v91.Frame, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 1
			}):Play()
			game:GetService("TweenService"):Create(v91.TextLabel, TweenInfo.new(0.5), {
				["TextTransparency"] = 1
			}):Play()
			if v_u_18 then
				v_u_7:MVP_End(v_u_18, true)
				v_u_18 = nil
			end
		end
	}
	v_u_8.Effects:Connect(function(p93, ...)
		-- upvalues: (copy) v_u_92
		local v94 = v_u_92[p93]
		if v94 then
			v94(...)
		end
	end)
end
function v10.KnitStart(_) end
function v10.KnitInit(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9
	v_u_8 = v_u_1.GetService("DuelService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10