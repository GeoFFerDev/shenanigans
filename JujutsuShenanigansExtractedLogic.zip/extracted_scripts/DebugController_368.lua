-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Remotes
local _ = v5.Utils
local v_u_6 = v5.Sounds
local v_u_7 = require(game.ReplicatedStorage.Modules.CameraShaker)
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "DebugController"
})
local v_u_12 = v_u_4
local v_u_13 = {
	["Lock"] = false,
	["Voice"] = false,
	["Respawn2"] = true,
	["Destroy"] = true,
	["OP"] = false,
	["FF"] = true,
	["TI"] = false,
	["Item"] = true,
	["RC"] = false,
	["CC"] = false,
	["Dummy1"] = false,
	["Dummy2"] = false,
	["Dummy3"] = false,
	["Dummy4"] = false,
	["Dummy5"] = false,
	["Dummy6"] = false,
	["Dummy7"] = false,
	["Dummy8"] = false,
	["Gravity"] = 196.2,
	["WalkSpeed"] = 16,
	["JumpPower"] = 40,
	["ServerName"] = "",
	["ServerIcon"] = 0,
	["Workshop"] = false,
	["Fidelity"] = 2,
	["Tick"] = 20,
	["Damage"] = 1,
	["Knockback"] = 1
}
local v_u_14 = {
	["Flight"] = false,
	["Build"] = false,
	["PSPerms"] = false,
	["CD"] = true,
	["Ult"] = false,
	["Stun"] = false,
	["Respawn"] = true,
	["DeathKick"] = true,
	["Skill"] = true,
	["SkillM1"] = true,
	["SkillUlt"] = true,
	["Parkour"] = true,
	["Burst"] = true,
	["ApplyNew"] = false
}
local v_u_15 = {
	["Kick"] = true,
	["Heal"] = true,
	["ResetCD"] = true,
	["Kill"] = true,
	["Bring"] = true,
	["Go"] = true,
	["Respawn3"] = true
}
local v_u_28 = {
	["Flight"] = function()
		-- upvalues: (ref) v_u_12
		local v16 = v_u_12.Character
		if v16 then
			local v17 = v16:FindFirstChild("HumanoidRootPart")
			if v17 then
				return v17:FindFirstChild("FlightForce") ~= nil
			end
		end
	end,
	["Build"] = function()
		-- upvalues: (ref) v_u_12
		return v_u_12:FindFirstChild("BuildTag") ~= nil
	end,
	["PSPerms"] = function()
		-- upvalues: (ref) v_u_12
		return v_u_12:GetAttribute("PS_Perms")
	end,
	["CD"] = function()
		-- upvalues: (ref) v_u_12
		local v18 = v_u_12.Character
		if v18 and v18:FindFirstChild("Info") then
			return not v18.Info:GetAttribute("CD")
		end
	end,
	["Ult"] = function()
		-- upvalues: (ref) v_u_12
		local v19 = v_u_12.Character
		if v19 then
			return v19:GetAttribute("UltDrain")
		end
	end,
	["Stun"] = function()
		-- upvalues: (ref) v_u_12
		local v20 = v_u_12.Character
		if v20 and v20:FindFirstChild("Info") then
			return v20.Info:GetAttribute("NoStun")
		end
	end,
	["Respawn"] = function()
		-- upvalues: (ref) v_u_12
		local v21 = v_u_12.Character
		if v21 and v21:FindFirstChild("Info") then
			return not v21.Info:GetAttribute("NoRes")
		end
	end,
	["DeathKick"] = function()
		-- upvalues: (ref) v_u_12
		local v22 = v_u_12.Character
		if v22 and v22:FindFirstChild("Info") then
			return v22.Info:GetAttribute("DeathKick")
		end
	end,
	["Skill"] = function()
		-- upvalues: (ref) v_u_12
		local v23 = v_u_12.Character
		if v23 and v23:FindFirstChild("Info") then
			return not v23.Info:GetAttribute("Skill")
		end
	end,
	["SkillM1"] = function()
		-- upvalues: (ref) v_u_12
		local v24 = v_u_12.Character
		if v24 and v24:FindFirstChild("Info") then
			return not v24.Info:GetAttribute("M1")
		end
	end,
	["SkillUlt"] = function()
		-- upvalues: (ref) v_u_12
		local v25 = v_u_12.Character
		if v25 and v25:FindFirstChild("Info") then
			return not v25.Info:GetAttribute("Ult")
		end
	end,
	["Parkour"] = function()
		-- upvalues: (ref) v_u_12
		local v26 = v_u_12.Character
		if v26 and v26:FindFirstChild("Info") then
			return not v26.Info:GetAttribute("Parkour")
		end
	end,
	["Burst"] = function()
		-- upvalues: (ref) v_u_12
		local v27 = v_u_12.Character
		if v27 and v27:FindFirstChild("Info") then
			return not v27.Info:GetAttribute("Burst")
		end
	end
}
local function v_u_31(p29, p30)
	if p30 == true then
		p29.Toggle.BackgroundColor3 = Color3.fromRGB(85, 255, 0)
		p29.Toggle.Side.BackgroundColor3 = Color3.fromRGB(169, 255, 189)
		p29.Toggle.Side.Position = UDim2.new(0, 0, 0, 0)
	else
		p29.Toggle.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
		p29.Toggle.Side.BackgroundColor3 = Color3.fromRGB(85, 0, 0)
		p29.Toggle.Side.Position = UDim2.new(0.5, 0, 0, 0)
	end
end
function v11.KnitStart(_)
	-- upvalues: (copy) v_u_4, (ref) v_u_12, (copy) v_u_14, (copy) v_u_31, (copy) v_u_28, (ref) v_u_10, (copy) v_u_6, (ref) v_u_8, (copy) v_u_13, (copy) v_u_15, (copy) v_u_3, (copy) v_u_2, (copy) v_u_7
	local v_u_32 = v_u_4.PlayerGui:WaitForChild("Menus")
	local v_u_33 = v_u_32.Group.Private
	v_u_33:SetAttribute("Loaded", true)
	v_u_4:WaitForChild("leaderstats")
	local function v_u_36()
		-- upvalues: (ref) v_u_12, (copy) v_u_33, (ref) v_u_14, (ref) v_u_31, (ref) v_u_28
		if v_u_12 == "All" then
			v_u_33.Items.Players.Players.ApplyNew.Visible = true
			for _, v34 in v_u_33.Items.Players.Players:GetDescendants() do
				if v34:IsA("Frame") and (v_u_14[v34.Name] ~= nil and v34:FindFirstChild("Toggle")) then
					v_u_31(v34, v_u_14[v34.Name])
				end
			end
		else
			v_u_33.Items.Players.Players.ApplyNew.Visible = false
			for _, v35 in v_u_33.Items.Players.Players:GetDescendants() do
				if v35:IsA("Frame") and (v_u_28[v35.Name] ~= nil and v35:FindFirstChild("Toggle")) then
					v_u_31(v35, v_u_28[v35.Name]())
				end
			end
		end
	end
	for _, v_u_37 in v_u_33.Categories:GetChildren() do
		if v_u_37:IsA("TextButton") then
			v_u_37.MouseButton1Down:Connect(function()
				-- upvalues: (copy) v_u_33, (copy) v_u_37, (ref) v_u_10, (ref) v_u_6, (copy) v_u_36
				for _, v38 in v_u_33.Categories:GetChildren() do
					if v38:IsA("TextButton") then
						v38.Select.Visible = v38 == v_u_37
					end
				end
				v_u_10:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
				if v_u_37.Name == "Players" then
					v_u_36()
				end
				for _, v39 in v_u_33.Items:GetChildren() do
					v39.Visible = v39.Name == v_u_37.Name
				end
			end)
		end
	end
	local v_u_40 = v_u_32.Preset.Player:Clone()
	v_u_40.Name = "All"
	v_u_40.Display.Text = "All"
	v_u_40.Main.Text = "All Players"
	v_u_40.Parent = v_u_33.Items.Players.List
	v_u_40.Select.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_12, (copy) v_u_36, (ref) v_u_10, (ref) v_u_6, (copy) v_u_33, (copy) v_u_40
		v_u_12 = "All"
		v_u_36()
		v_u_10:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v41 in v_u_33.Items.Players.List:GetChildren() do
			if v41:IsA("Frame") then
				if v41 == v_u_40 then
					v41.BackgroundTransparency = 0.5
				else
					v41.BackgroundTransparency = 1
				end
			end
		end
	end)
	local function v47(p_u_42)
		-- upvalues: (copy) v_u_32, (ref) v_u_12, (copy) v_u_33, (copy) v_u_36, (ref) v_u_10, (ref) v_u_6
		local v_u_43 = v_u_32.Preset.Player:Clone()
		v_u_43.Name = p_u_42.Name
		v_u_43.Display.Text = p_u_42.DisplayName or p_u_42.Name
		v_u_43.Main.Text = "(@" .. p_u_42.Name .. ")"
		if p_u_42 == v_u_12 then
			v_u_43.BackgroundTransparency = 0.5
		end
		v_u_43.Parent = v_u_33.Items.Players.List
		v_u_43.Select.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_12, (copy) p_u_42, (ref) v_u_36, (ref) v_u_10, (ref) v_u_6, (ref) v_u_33, (copy) v_u_43
			v_u_12 = p_u_42
			v_u_36()
			v_u_10:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
			for _, v44 in v_u_33.Items.Players.List:GetChildren() do
				if v44:IsA("Frame") then
					if v44 == v_u_43 then
						v44.BackgroundTransparency = 0.5
					else
						v44.BackgroundTransparency = 1
					end
				end
			end
		end)
		p_u_42.CharacterAdded:Connect(function()
			-- upvalues: (copy) p_u_42, (ref) v_u_12, (ref) v_u_36
			if p_u_42 == v_u_12 then
				task.defer(function()
					-- upvalues: (ref) v_u_36
					v_u_36()
				end)
			end
		end)
		pcall(function()
			-- upvalues: (copy) p_u_42, (copy) v_u_43
			local v45 = game.Players:GetUserIdFromNameAsync(p_u_42.Name)
			local v46 = game.Players:GetUserThumbnailAsync(v45, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size48x48)
			v_u_43.Icon.Image = v46
		end)
	end
	v_u_8.Debug:Connect(function(p48, p49)
		-- upvalues: (copy) v_u_33, (ref) v_u_31
		if p48 and p49 ~= nil then
			for _, v50 in v_u_33.Items:GetDescendants() do
				if v50:IsA("Frame") and (v50.Name == p48 and (v50.Parent == v_u_33.Items.Server or v50.Parent == v_u_33.Items.Players.Players)) then
					if v50:FindFirstChild("Toggle") then
						v_u_31(v50, p49)
					elseif v50:FindFirstChild("TextBox") then
						v50.TextBox.Text = p49
					end
				end
			end
		end
	end)
	v_u_8.Update:Connect(function(p51)
		-- upvalues: (ref) v_u_14, (copy) v_u_36
		if p51 then
			for v52, v53 in p51 do
				if v_u_14[v52] ~= nil then
					v_u_14[v52] = v53
				end
			end
		end
		v_u_36()
	end)
	for _, v54 in game.Players:GetChildren() do
		task.spawn(v47, v54)
	end
	game.Players.PlayerAdded:Connect(v47)
	game.Players.PlayerRemoving:Connect(function(p55)
		-- upvalues: (ref) v_u_12, (ref) v_u_4, (copy) v_u_36, (copy) v_u_33
		if v_u_12 == p55 then
			v_u_12 = v_u_4
		end
		v_u_36()
		for _, v56 in v_u_33.Items.Players.List:GetChildren() do
			if v56:IsA("Frame") then
				if v56.Name == v_u_12.Name then
					v56.BackgroundTransparency = 0.5
				elseif v56.Name == p55.Name then
					v56:Destroy()
				else
					v56.BackgroundTransparency = 1
				end
			end
		end
	end)
	for _, v_u_57 in v_u_33.Items:GetDescendants() do
		if v_u_57:IsA("Frame") and (v_u_57.Parent == v_u_33.Items.Server or v_u_57.Parent == v_u_33.Items.Players.Players) then
			local v_u_58 = v_u_57.Name
			if v_u_13[v_u_58] == nil then
				if v_u_14[v_u_58] == nil then
					if v_u_15[v_u_58] ~= nil then
						v_u_57.Button.MouseButton1Down:Connect(function()
							-- upvalues: (ref) v_u_8, (copy) v_u_58, (ref) v_u_12, (ref) v_u_10, (ref) v_u_6
							v_u_8.Debug:Fire(v_u_58, v_u_12)
							v_u_10:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
						end)
					end
				else
					v_u_57.Toggle.Side.MouseButton1Down:Connect(function()
						-- upvalues: (ref) v_u_8, (copy) v_u_58, (ref) v_u_12, (ref) v_u_10, (ref) v_u_6
						v_u_8.Debug:Fire(v_u_58, v_u_12)
						v_u_10:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
						v_u_10:PlaySound(v_u_6.Misc.UI.Switch, workspace, game.SoundService.Effect)
					end)
				end
			elseif v_u_57:FindFirstChild("Toggle") then
				v_u_31(v_u_57, v_u_13[v_u_58])
				v_u_57.Toggle.Side.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_8, (copy) v_u_58, (ref) v_u_10, (ref) v_u_6
					v_u_8.Debug:Fire(v_u_58)
					v_u_10:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_10:PlaySound(v_u_6.Misc.UI.Switch, workspace, game.SoundService.Effect)
				end)
			elseif v_u_57:FindFirstChild("Button") then
				v_u_57.Button.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_8, (copy) v_u_58, (ref) v_u_10, (ref) v_u_6
					v_u_8.Debug:Fire(v_u_58)
					v_u_10:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
				end)
			elseif v_u_57:FindFirstChild("TextBox") then
				v_u_57.TextBox.FocusLost:Connect(function()
					-- upvalues: (ref) v_u_8, (copy) v_u_58, (copy) v_u_57, (ref) v_u_10, (ref) v_u_6
					v_u_8.Debug:Fire(v_u_58, v_u_57.TextBox.Text)
					v_u_10:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
				end)
			end
		end
	end
	local v_u_59 = game.ReplicatedStorage.Remotes.Request
	v_u_59.OnClientEvent:Connect(function(p_u_60, p61)
		-- upvalues: (ref) v_u_10, (ref) v_u_6, (copy) v_u_59, (ref) v_u_3
		local v62 = Instance.new("BindableFunction", script)
		function v62.OnInvoke(p63)
			-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_59, (copy) p_u_60
			v_u_10:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
			if p63 == "Allow" then
				v_u_59:FireServer(p_u_60)
			end
		end
		v_u_3:AddItem(v62, 2)
		game:GetService("StarterGui"):SetCore("SendNotification", {
			["Title"] = "Build Mode Request",
			["Text"] = p_u_60.Name .. p61,
			["Button1"] = "Allow",
			["Button2"] = "Deny",
			["Callback"] = v62,
			["Duration"] = 2
		})
	end)
	v_u_4.PlayerGui.ChildRemoved:Connect(function(p64)
		if p64.Name == "BuildTools" then
			for _, v65 in workspace.Logic:GetDescendants() do
				if v65:IsA("BillboardGui") then
					v65.Enabled = false
				elseif v65:IsA("SelectionBox") then
					v65.Visible = false
				elseif v65:IsA("Beam") then
					v65:Destroy()
				end
			end
		end
	end)
	v_u_33:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (ref) v_u_8
		v_u_8.Update:Fire()
	end)
	v_u_33.Items.Presets:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (ref) v_u_10, (ref) v_u_6, (copy) v_u_33
		v_u_10:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_33.Visible = false
		for _, v66 in v_u_33.Categories:GetChildren() do
			if v66:IsA("TextButton") then
				v66.Select.Visible = v66.Name == "Server"
			end
		end
		for _, v67 in v_u_33.Items:GetChildren() do
			v67.Visible = v67.Name == "Server"
		end
		_G.WorkshopIcon:select()
	end)
	v_u_2.InputBegan:Connect(function(p68, p69)
		-- upvalues: (ref) v_u_8, (ref) v_u_4
		if p69 then
			return
		elseif p68.KeyCode == Enum.KeyCode.M then
			v_u_8.Debug:Fire("Build", v_u_4)
			return
		elseif p68.KeyCode == Enum.KeyCode.N then
			v_u_8.Debug:Fire("Flight", v_u_4)
		elseif p68.KeyCode == Enum.KeyCode.V then
			v_u_8.Debug:Fire("ResetCD", v_u_4)
		end
	end)
	if workspace.Map.Destructible:FindFirstChild("Model") and workspace.Map.Destructible.Model:FindFirstChild("StationControl") then
		workspace.Map.Destructible.Model.StationControl.Handle.Train.OnClientEvent:Connect(function()
			-- upvalues: (ref) v_u_7
			local v_u_70 = workspace.Effects:WaitForChild("Train", 1)
			task.spawn(function()
				-- upvalues: (copy) v_u_70, (ref) v_u_7
				while true do
					task.wait(0.05)
					local v71 = (workspace.CurrentCamera.CFrame.Position - v_u_70.Position).Magnitude
					if v71 <= 500 then
						local v72 = workspace.CurrentCamera.CFrame.Position
						if not workspace:Raycast(v72, v_u_70.Position - v72, _G.MapParams) then
							if v71 < 150 then
								v_u_7.CurrentShaker:Shake(v_u_7.Presets.Snap)
							elseif v71 < 300 then
								v_u_7.CurrentShaker:Shake(v_u_7.Presets.HeavyHit)
							elseif v71 > 300 then
								v_u_7.CurrentShaker:Shake(v_u_7.Presets.LightHit)
							end
						end
					end
					if not v_u_70.Parent then
						return
					end
				end
			end)
		end)
	end
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9, (ref) v_u_10
	v_u_8 = v_u_1.GetService("DebugService")
	v_u_9 = v_u_1.GetService("BuildService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11