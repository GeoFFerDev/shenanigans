-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "ToadController"
})
local v_u_13 = RaycastParams.new()
v_u_13.FilterType = Enum.RaycastFilterType.Include
v_u_13.FilterDescendantsInstances = { workspace.Map, workspace.Spawns, workspace.Domains }
function v12.KnitStart(_)
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (ref) v_u_11, (copy) v_u_8, (copy) v_u_4, (copy) v_u_2, (copy) v_u_13, (ref) v_u_10
	local v_u_74 = {
		["Grab"] = function(p14)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = v_u_7.Itadori.CounterHit.Feint:Clone()
				for _, v17 in v16:GetChildren() do
					v17.Color = ColorSequence.new(Color3.fromRGB(125, 45, 152))
					v17.TimeScale = 0.5
				end
				v16.Parent = v15
				v16.Sparks:Emit(30)
				v16.Ring:Emit(6)
				v_u_3:AddItem(v16, 1)
			end
		end,
		["Toad"] = function(p18, p19, p_u_20, p21)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_2
			local v_u_22 = p19:FindFirstChild("HumanoidRootPart")
			if v_u_22 then
				if v_u_5 == p18 or v_u_5.Character == p19 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				local v_u_23 = v_u_7.Megumi.Spawn:Clone()
				v_u_23.Parent = workspace.Effects
				v_u_23.Position = p_u_20
				v_u_3:AddItem(v_u_23, 3)
				v_u_23.Shadow:Emit(12)
				v_u_23.Dive:Emit(6)
				v_u_23.Dive.Size = NumberSequence.new(8)
				v_u_23.Shadow.Size = NumberSequence.new({
					NumberSequenceKeypoint.new(0, 0),
					NumberSequenceKeypoint.new(0.5, 8),
					NumberSequenceKeypoint.new(0.75, 9),
					NumberSequenceKeypoint.new(1, 10)
				})
				local v_u_24 = v_u_7.Megumi.Toad:Clone()
				v_u_24.RootPart.CFrame = CFrame.new(p_u_20)
				v_u_24.Parent = p21
				local v_u_25 = v_u_24.AnimationController:LoadAnimation(v_u_24.AnimationController.Summon)
				v_u_25:Play(0, nil, 1.3333333333333333)
				v_u_11:PlaySound(v_u_8.Megumi.Toad.Spawn, v_u_24.RootPart, game.SoundService.Effect)
				task.delay(0.55, function()
					-- upvalues: (copy) v_u_22, (copy) p_u_20, (copy) v_u_24, (ref) v_u_4, (ref) v_u_11, (ref) v_u_8, (copy) v_u_25
					if v_u_22.Parent then
						if (p_u_20 - v_u_22.Position).Magnitude > 100 then
							local _ = v_u_24.Position + CFrame.new(v_u_24.Position, v_u_22.Position).LookVector * 100
						else
							local _ = v_u_22.Position
						end
						v_u_4:Create(v_u_24.Torso.Attachment, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
							["WorldPosition"] = v_u_22.Position
						}):Play()
						v_u_11:PlaySound(v_u_8.Megumi.Toad.Fly, v_u_24.RootPart, game.SoundService.Effect)
						task.wait(0.2)
						v_u_25:AdjustSpeed(0.9)
						v_u_4:Create(v_u_24.Torso.Attachment, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
							["Position"] = Vector3.new(0, 0.05, -3.9)
						}):Play()
						v_u_11:PlaySound(v_u_8.Megumi.Toad.Flyback, v_u_24.RootPart, game.SoundService.Effect)
					end
				end)
				local v_u_26 = tick()
				local v_u_27 = nil
				v_u_27 = v_u_2.Stepped:Connect(function(_, _)
					-- upvalues: (copy) v_u_22, (copy) v_u_26, (ref) v_u_27, (copy) v_u_24, (ref) v_u_4, (ref) v_u_3, (copy) v_u_23, (ref) v_u_11, (ref) v_u_8
					if v_u_22.Parent and tick() <= v_u_26 + 1.2 then
						local v28 = v_u_22.Position.X
						local v29 = v_u_24.RootPart.Position.Y
						local v30 = v_u_22.Position.Z
						local v31 = Vector3.new(v28, v29, v30)
						v_u_24.RootPart.CFrame = CFrame.new(v_u_24.RootPart.Position, v31)
					else
						v_u_27:Disconnect()
						for _, v32 in v_u_24:GetDescendants() do
							if v32:IsA("BasePart") then
								v_u_4:Create(v32, TweenInfo.new(0.2), {
									["Color"] = Color3.new(0, 0, 0)
								}):Play()
							end
						end
						v_u_3:AddItem(v_u_24, 0.2)
						v_u_23.Shadow:Emit(12)
						v_u_23.Dive:Emit(6)
						v_u_11:PlaySound(v_u_8.Megumi.Toad.Despawn, v_u_23, game.SoundService.Effect)
					end
				end)
			end
		end,
		["ToadAir"] = function(_, p33, p_u_34, p_u_35)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_13, (ref) v_u_4, (ref) v_u_11, (ref) v_u_8, (ref) v_u_2
			local v_u_36 = p33:FindFirstChild("HumanoidRootPart")
			if v_u_36 then
				for v_u_37 = 1, 10 do
					task.spawn(function()
						-- upvalues: (copy) v_u_37, (ref) v_u_7, (ref) v_u_3, (copy) p_u_34, (ref) v_u_13, (copy) v_u_36, (copy) p_u_35, (ref) v_u_4, (ref) v_u_11, (ref) v_u_8, (ref) v_u_2
						local v38 = 0.5 - 0.05 * (v_u_37 - 1)
						local v39 = v_u_7.Megumi.Shadow:Clone()
						v39.Parent = workspace.Effects
						v39.Dive.Enabled = false
						v39.Shadow.Enabled = false
						v_u_3:AddItem(v39, 5)
						local v40 = p_u_34
						local v41 = math.random(-70, 70) / 10
						local v42 = math.random(-70, 70) / 10
						local v43 = v40 + Vector3.new(v41, 0, v42)
						local v44 = workspace:Raycast(v43 + Vector3.new(0, 4, 0), Vector3.new(0, -8, 0), v_u_13)
						if v44 then
							v43 = v44.Position
							v39.CFrame = CFrame.new(v44.Position, v44.Position + v44.Normal)
							v39.Shadow:Emit(4)
							v39.Dive:Emit(1)
						else
							v39.Position = v43
							v39.ShadowAir:Emit(4)
						end
						local v_u_45 = v_u_7.Megumi.ToadNue:Clone()
						v_u_45.CFrame = v_u_36.CFrame - v_u_36.Position + v43
						v_u_45.Pos.Value = v_u_45.Position
						v_u_45.Parent = p_u_35
						local v46 = v_u_4
						local v47 = v_u_45.Pos
						local v48 = TweenInfo.new(v38, Enum.EasingStyle.Back)
						local v49 = {}
						local v50 = v_u_45.Position
						local v51 = math.random(30, 60) / 10
						v49.Value = v50 + Vector3.new(0, v51, 0)
						v46:Create(v47, v48, v49):Play()
						v_u_3:AddItem(v_u_45, 3)
						local v_u_52 = math.random(0, 3.141592653589793)
						v_u_11:PlaySound(v_u_8.Megumi.Toad.Spawn, v_u_45, game.SoundService.Effect)
						local v_u_53 = nil
						v_u_53 = v_u_2.Heartbeat:Connect(function(_)
							-- upvalues: (ref) v_u_36, (copy) v_u_45, (ref) v_u_53, (ref) v_u_52
							if v_u_36.Parent and v_u_45.Parent then
								v_u_52 = v_u_52 + 0.2
								if v_u_52 > 3.141592653589793 then
									v_u_52 = 0
								end
								local v54 = v_u_52
								local v55 = math.sin(v54)
								v_u_45.CFrame = CFrame.new(v_u_45.Pos.Value, v_u_36.Position)
								v_u_45.CFrame = v_u_45.CFrame + Vector3.new(0, v55, 0)
								if v55 < 0 then
									v55 = -v55
								end
								local v56 = v_u_45.Wings
								local v57 = v55 * 7
								v56.Size = Vector3.new(v57, 2.8, 0.233)
							else
								v_u_53:Disconnect()
							end
						end)
						task.wait(v38)
						if (p_u_34 - v_u_36.Position).Magnitude > 100 then
							local _ = v_u_45.Position + CFrame.new(v_u_45.Position, v_u_36.Position).LookVector * 100
						else
							local _ = v_u_36.Position
						end
						v_u_4:Create(v_u_45.Attachment, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
							["WorldPosition"] = v_u_36.Position
						}):Play()
						task.wait(0.2)
						v_u_4:Create(v_u_45.Attachment, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
							["Position"] = Vector3.new(0, 0.45, -0.4)
						}):Play()
						v_u_4:Create(v_u_45.Pos, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
							["Value"] = v_u_45.Pos.Value + Vector3.new(0, 2.5, 0)
						}):Play()
						task.wait(0.4)
						local v58 = v_u_4
						local v59 = v_u_45.Pos
						local v60 = TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
						local v61 = {}
						local v62 = v_u_45.Pos.Value
						local v63 = math.random(100, 200) / 10
						v61.Value = v62 + Vector3.new(0, v63, 0)
						v58:Create(v59, v60, v61):Play()
						task.wait(math.random(120, 160) / 100)
						v_u_11:PlaySound(v_u_8.Megumi.Toad.Despawn, v39, game.SoundService.Effect)
						v39.Position = v_u_45.Position
						v39.ShadowAir:Emit(4)
						v_u_45:Destroy()
					end)
					task.wait(0.05)
				end
			end
		end,
		["Hit"] = function(_, p64, p65)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v66 = p64:FindFirstChild("HumanoidRootPart")
			if v66 then
				local v67 = p65:FindFirstChild("Toad")
				if v67 then
					v_u_11:Flash(p64, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_8.Gojo.LapseBlue.Grab, v66, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_8.Megumi.Toad.Hit, v66, game.SoundService.Effect)
					local v68 = v_u_7.Megumi.TongueGrab:Clone()
					v68.Weld.Part0 = v66
					v67.Torso.Tongue.Beam.Attachment1 = v68.Attachment
					v68.Parent = workspace.Effects
					v_u_3:AddItem(v68, 0.6)
				end
			else
				return
			end
		end,
		["HitAir"] = function(_, p69, p70)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v71 = p69:FindFirstChild("HumanoidRootPart")
			if v71 then
				v_u_11:Flash(p69, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Gojo.LapseBlue.Grab, v71, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_8.Megumi.Toad.Hit, v71, game.SoundService.Effect)
				local v_u_72 = v_u_7.Megumi.TongueGrab:Clone()
				v_u_72.Weld.Part0 = v71
				v_u_72.Parent = workspace.Effects
				v_u_3:AddItem(v_u_72, 1.2)
				for _, v_u_73 in p70:GetChildren() do
					v_u_73.Tongue.Beam.Attachment1 = v_u_72.Attachment
					task.delay(0.2, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_73, (copy) v_u_72
						v_u_4:Create(v_u_73.Tongue.Beam, TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							["CurveSize0"] = -20
						}):Play()
						task.wait(0.5)
						v_u_4:Create(v_u_73.Tongue.Beam, TweenInfo.new(0.3), {
							["CurveSize0"] = 10
						}):Play()
						task.wait(0.5)
						v_u_73.Attachment.WorldPosition = v_u_72.Position
						v_u_73.Tongue.Beam.Attachment1 = v_u_73.Attachment
						v_u_4:Create(v_u_73.Tongue.Beam, TweenInfo.new(0.4), {
							["CurveSize0"] = 0
						}):Play()
						v_u_4:Create(v_u_73.Attachment, TweenInfo.new(0.4), {
							["Position"] = v_u_73.Tongue.Position
						}):Play()
					end)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p75, ...)
		-- upvalues: (copy) v_u_74
		local v76 = v_u_74[p75]
		if v76 then
			v76(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("ToadService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12