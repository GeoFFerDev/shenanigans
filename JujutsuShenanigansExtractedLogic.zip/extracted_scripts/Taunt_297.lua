-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 3,
	["SortOrder"] = 5,
	["Val"] = "VolTA",
	["Desc"] = "Change the volume for taunts",
	["Max"] = 2,
	["Callback"] = function(p1)
		game.SoundService.Taunt.Volume = p1
	end
}