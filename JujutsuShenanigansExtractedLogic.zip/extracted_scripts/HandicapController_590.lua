-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = v_u_6.Animations
local v_u_8 = v_u_6.Utils
local v_u_9 = v_u_6.Sounds
local v_u_10 = require(v_u_6.Modules.CameraShaker)
local v_u_11 = require(v_u_6.Modules.BloodyZee)
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v17 = v_u_1.CreateController({
	["Name"] = "HandicapController"
})
local v_u_18 = RaycastParams.new()
v_u_18.FilterType = Enum.RaycastFilterType.Include
v_u_18.FilterDescendantsInstances = { workspace.Map }
function v17.Swing(_, _, p_u_19, p20, p_u_21)
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_2
	local v22 = v_u_5.Character
	if v22 then
		local v_u_23 = v22:FindFirstChild("HumanoidRootPart")
		if v_u_23 then
			local v_u_24
			if p20 then
				v_u_24 = Instance.new("NumberValue", p_u_19)
				v_u_24.Value = p_u_21.Magnitude
				v_u_4:Create(v_u_24, TweenInfo.new(p20, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["Value"] = 0
				}):Play()
			else
				v_u_24 = nil
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_23, (copy) p_u_21, (ref) v_u_24, (copy) p_u_19, (ref) v_u_2
				while true do
					local v25 = v_u_23.CFrame:VectorToWorldSpace(p_u_21)
					if v_u_24 then
						p_u_19.Velocity = v25.Unit * v_u_24.Value
					else
						p_u_19.Velocity = v25
					end
					v_u_2.Stepped:Wait()
					if not (p_u_19.Parent and v_u_23.Parent) then
						return
					end
				end
			end)
		end
	else
		return
	end
end
function v17.MovementForce(_, p26, p27, p28, p29)
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v30 = Instance.new("BodyVelocity", p26.Torso)
	v30.MaxForce = Vector3.new(40000, 40000, 40000)
	v30.P = 40000
	v30.Name = "MovementForce"
	v30.Velocity = p27
	v_u_4:Create(v30, TweenInfo.new(0.3), {
		["Velocity"] = p28
	}):Play()
	v_u_3:AddItem(v30, p29)
end
function v17.ClearForce(_, p31, p32)
	for _, v33 in p31:GetChildren() do
		if v33:IsA("BodyVelocity") and (not p32 or v33 ~= p32) and (v33.Name == "SwingForce" or v33.Name == "MovementForce") then
			v33:Destroy()
		end
	end
end
function v17.KnitStart(p_u_34)
	-- upvalues: (ref) v_u_12, (copy) v_u_2, (copy) v_u_3, (copy) v_u_18, (copy) v_u_9, (ref) v_u_15, (copy) v_u_5, (copy) v_u_10, (copy) v_u_8, (copy) v_u_1, (copy) v_u_7, (copy) v_u_4, (copy) v_u_11, (ref) v_u_14, (copy) v_u_6, (ref) v_u_13
	v_u_12.Effects:Connect(function(p_u_35, p36, p_u_37, p38)
		-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_18, (ref) v_u_9, (ref) v_u_15, (ref) v_u_5, (ref) v_u_10, (ref) v_u_8, (copy) p_u_34, (ref) v_u_1, (ref) v_u_7, (ref) v_u_4, (ref) v_u_11
		if p36 == "Collide" then
			local v_u_39 = false
			local v_u_40 = false
			local v_u_41 = nil
			local v_u_42 = tick()
			local v_u_43 = nil
			v_u_43 = v_u_2.Stepped:Connect(function(_, p44)
				-- upvalues: (copy) p_u_35, (copy) p_u_37, (ref) v_u_43, (ref) v_u_41, (ref) v_u_3, (ref) v_u_18, (ref) v_u_39, (ref) v_u_9, (ref) v_u_15, (ref) v_u_40, (ref) v_u_5, (ref) v_u_10, (ref) v_u_42, (ref) v_u_8
				if p_u_35 and (p_u_35.Parent and (p_u_37.Parent and p_u_37:GetAttribute("Ragdoll") > 0)) then
					local v45 = p_u_35.Velocity.Magnitude
					local v46 = workspace:Raycast(p_u_35.Position, Vector3.new(0, -3, 0), v_u_18)
					if v46 and v_u_39 == false then
						v_u_39 = true
						local v47 = v_u_9.Impact.Players["RagdollFall" .. math.random(1, 3)]
						local v48 = p_u_35.Velocity.Magnitude / 50
						v47.Volume = math.clamp(v48, 0, 3)
						v_u_15:PlaySound(v47, p_u_35, game.SoundService.Effect)
					elseif not v46 and v_u_39 == true then
						v_u_39 = false
					end
					local v49 = p_u_35.Velocity * p44 * 3
					local v50 = workspace:Raycast(p_u_35.Position, v49, v_u_18)
					if v50 and v45 > 100 then
						if v_u_40 == false then
							v_u_40 = true
							v_u_15:PlaySound(v_u_9.Hakari.OverLuck.Hit1, p_u_35, game.SoundService.Effect)
							v_u_15:PlaySound(v_u_9.Itadori.Rush.RushLaunch, p_u_35, game.SoundService.Effect)
							v_u_15:DustBreak(v50.Position - v49.Unit, -v49, 4, 1, 0.4, 1)
							if v_u_5:DistanceFromCharacter(p_u_35.Position) < 100 then
								v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
							end
						end
					else
						v_u_40 = false
					end
					if _G.Settings.DesPHY and (tick() - v_u_42 > 0.05 and v45 > 50) then
						v_u_42 = tick()
						v_u_15:DustBreak(p_u_35.Position, Vector3.new(0, 1, 0), 3, 2, 0.4, 1, 4)
					end
					if v45 >= 100 then
						if v_u_41 == nil then
							v_u_41 = v_u_8.Damage.RagdollWind:Clone()
							v_u_41.Parent = workspace.Effects
						end
						v_u_41.Wind1.Enabled = true
						v_u_41.Wind2.Enabled = true
						v_u_41.Trail.Enabled = v45 > 150
						if p_u_35.Parent then
							v_u_41.CFrame = CFrame.new(p_u_35.Position, p_u_35.Position - p_u_35.Velocity)
							return
						end
					elseif v_u_41 then
						v_u_41.Wind1.Enabled = false
						v_u_41.Wind2.Enabled = false
						v_u_41.Trail.Enabled = false
					end
				else
					v_u_43:Disconnect()
					if v_u_41 ~= nil then
						v_u_41.Wind1.Enabled = false
						v_u_41.Wind2.Enabled = false
						v_u_41.Trail.Enabled = false
						v_u_3:AddItem(v_u_41, 0.2)
					end
				end
			end)
			return
		end
		if p36 == "Swing" then
			p_u_34:Swing(p_u_35.Parent, p_u_35, p_u_37, p38)
			return
		end
		if p36 == "Death" then
			if _G.Settings.VolKS == false then
				return
			else
				local v51 = p_u_37:FindFirstChild("HumanoidRootPart")
				if v51 then
					local v52 = v_u_9.Impact.Players.Death:Clone()
					v52.SoundGroup = game.SoundService.Effect
					v52.SoundId = "rbxassetid://" .. p_u_35
					v52.Volume = 1
					v52.Parent = v51
					v52:Play()
					v_u_3:AddItem(v52, 4)
				end
			end
		end
		if p36 == "Spawn" then
			local v_u_53 = p_u_37:FindFirstChild("HumanoidRootPart")
			if not v_u_53 then
				return
			end
			local v_u_54 = v_u_1.GetController(p38 .. "Controller")
			if v_u_54 and (v_u_54.SpawnFunc and v_u_54.SpawnAnim) then
				local v_u_55 = {}
				local v_u_56 = v_u_53.Position
				v_u_7.Misc.SpawnAnim.AnimationId = "rbxassetid://" .. v_u_54.SpawnAnim
				local v_u_57 = p_u_37.Humanoid:LoadAnimation(v_u_7.Misc.SpawnAnim)
				local v59 = v_u_57:GetMarkerReachedSignal("Function"):Connect(function(p58)
					-- upvalues: (copy) v_u_54, (copy) p_u_37, (copy) v_u_55
					if v_u_54.SpawnFunc[p58] then
						v_u_54.SpawnFunc[p58](p_u_37, v_u_55)
					end
				end)
				table.insert(v_u_55, v59)
				local v60 = p_u_37.Info.ChildAdded:Connect(function()
					-- upvalues: (copy) v_u_57
					v_u_57:Stop()
				end)
				table.insert(v_u_55, v60)
				local v61 = p_u_37.Humanoid.HealthChanged:Connect(function()
					-- upvalues: (copy) v_u_57
					v_u_57:Stop()
				end)
				table.insert(v_u_55, v61)
				local v62 = v_u_2.Stepped:Connect(function()
					-- upvalues: (copy) v_u_56, (copy) v_u_53, (copy) v_u_57
					if ((v_u_56 - v_u_53.Position) * Vector3.new(1, 0, 1)).Magnitude > 1 then
						v_u_57:Stop()
					end
				end)
				table.insert(v_u_55, v62)
				local v63 = p_u_37.AncestryChanged:Connect(function()
					-- upvalues: (copy) v_u_57
					v_u_57:Stop()
				end)
				table.insert(v_u_55, v63)
				local v_u_64 = nil
				v_u_64 = v_u_57.Stopped:Connect(function()
					-- upvalues: (ref) v_u_64, (copy) v_u_55
					v_u_64:Disconnect()
					for v65 = #v_u_55, 1, -1 do
						local v66 = v_u_55[v65]
						if v66 then
							table.remove(v_u_55, v65)
							if typeof(v66) == "RBXScriptConnection" then
								v66:Disconnect()
							elseif v66:IsA("AnimationTrack") then
								v66:Stop()
							else
								v66:Destroy()
							end
						end
					end
				end)
				v_u_57:Play(0)
				return
			end
			::l16::
		else
			if p36 ~= "Poison" then
				if p36 == "Bleed" then
					local v67 = p_u_37:FindFirstChild("HumanoidRootPart")
					if v67 then
						if p_u_35 ~= 0 then
							for _ = 1, p_u_35 do
								v_u_15:PlaySound(v_u_9.Misc.Bleed, v67, game.SoundService.Effect)
								if _G.Settings.Gore == false then
									v_u_15:Flash(p_u_37, Color3.fromRGB(255, 85, 255), 1)
								else
									v_u_15:Flash(p_u_37, Color3.fromRGB(85, 0, 0), 1)
									for _ = 1, 2 do
										v_u_11:Blood(p_u_37.Torso.CFrame, math.random(15, 30), 180, 180)
									end
									for _, v68 in v_u_8.Damage.Explode:GetDescendants() do
										if v68:IsA("Attachment") then
											local v69 = v68:Clone()
											v69.Parent = p_u_37:FindFirstChild(v68.Parent.Name)
											v69.Blood.Enabled = false
											v69.Blood:Emit(8)
											v_u_3:AddItem(v69, 1)
										end
									end
								end
							end
						end
					else
						return
					end
				end
				if p36 == "SBleed" then
					local v70 = p_u_37:FindFirstChild("HumanoidRootPart")
					if v70 then
						v_u_15:PlaySound(v_u_9.Misc.SBleed, v70, game.SoundService.Effect)
						if _G.Settings.Gore == false then
							v_u_15:Flash(p_u_37, Color3.fromRGB(255, 85, 255), 0.5)
						else
							v_u_15:Flash(p_u_37, Color3.fromRGB(85, 0, 0), 0.5)
							v_u_11:Blood(p_u_37.Torso.CFrame, math.random(15, 30), 180, 180)
						end
					else
						return
					end
				end
				if p36 == "WakeupEvade" then
					local v71 = p_u_37.HumanoidRootPart
					if not v71 then
						return
					end
					if p_u_37:GetAttribute("Dead") then
						return
					end
					local v72 = v_u_8.Itadori.CounterHit:Clone()
					v72.Position = v71.Position
					v72.Parent = workspace.Effects
					v72.Glow.Color = ColorSequence.new(Color3.fromRGB(0, 150, 200))
					v72.Sparks.Color = ColorSequence.new(Color3.fromRGB(0, 150, 200))
					v72.Glow:Emit(1)
					v72.Sparks:Emit(20)
					v_u_3:AddItem(v72, 0.5)
				end
				goto l16
			end
			local v73 = p_u_37:FindFirstChild("HumanoidRootPart")
			if not v73 then
				return
			end
			local v74 = v_u_8.Megumi.Poison:Clone()
			v74.Parent = v73
			v_u_4:Create(v74, TweenInfo.new(10), {
				["Rate"] = 0
			}):Play()
			v_u_3:AddItem(v74, p_u_35 + 1)
			for v75 = 1, p_u_35 do
				if not p_u_37.Parent or p_u_37:GetAttribute("Dead") then
					goto l16
				end
				v_u_15:Flash(p_u_37, Color3.fromRGB(85, 0, 127), 2)
				v_u_15:PlaySound(v_u_9.Megumi.Serpent["Poison" .. v75 % 3 + 1], v73, game.SoundService.Effect)
				task.wait(1)
			end
		end
	end)
	v_u_14.SFX:Connect(function(p76, p77)
		-- upvalues: (ref) v_u_9
		local v78 = p76:FindFirstChild("HumanoidRootPart") or p76:IsA("BasePart") and p76
		if v78 then
			local v79 = p77.ID
			local v80 = p77.VOLUME or 1
			local v81 = p77.SPEED or 1
			local v82 = p77.START or 0
			local v83 = p77.END or 500
			if workspace:GetAttribute("Creator") then
				v80 = math.clamp(v80, 0, 2.5)
			end
			if p77.CANCEL == true then
				for _, v84 in pairs(v78:GetChildren()) do
					if v84:IsA("Sound") and v84.SoundId == "rbxassetid://" .. v79 then
						v84:Destroy()
					end
				end
			else
				local v_u_85 = v_u_9.Impact.Players.Death:Clone()
				v_u_85.SoundGroup = game.SoundService.Effect
				v_u_85.SoundId = "rbxassetid://" .. v79
				v_u_85.Volume = v80
				v_u_85.PlaybackSpeed = v81
				v_u_85.PlaybackRegionsEnabled = true
				v_u_85.PlaybackRegion = NumberRange.new(v82, v83)
				v_u_85.TimePosition = v82
				if p77.GLOBAL == true then
					v78 = workspace or v78
				end
				v_u_85.Parent = v78
				v_u_85:Play()
				v_u_85.Stopped:Connect(function()
					-- upvalues: (copy) v_u_85
					v_u_85:Destroy()
				end)
			end
		else
			return
		end
	end)
	v_u_14.FX:Connect(function(p86, p87)
		-- upvalues: (ref) v_u_6
		local v88 = require(v_u_6.Modules.BuilderFX)
		if v88[p87.EFFECT] then
			v88[p87.EFFECT](p86, p87)
		end
	end)
	v_u_13.Effects:Connect(function(p89, p90)
		-- upvalues: (ref) v_u_15, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
		local v91 = p89:FindFirstChild("HumanoidRootPart")
		if v91 then
			if p90 then
				v_u_15:PlaySound(v_u_9.Impact.Players.Perfect, v91, game.SoundService.Effect)
			else
				if p89:GetAttribute("Sword") or p89:GetAttribute("Moveset") == "Mechamaru" then
					local v92 = v_u_9.Misc.SwordBlock["Block" .. math.random(1, 3)]
					v92.Pitch = math.random(90, 110) / 100
					v_u_15:PlaySound(v92, v91, game.SoundService.Effect)
					local v93 = v_u_8.Damage.SwordBlockHit:Clone()
					v93.Parent = v91
					v93:Emit(10)
					v_u_3:AddItem(v93, 0.3)
				end
				local v94 = v_u_9.Misc.Block["Block" .. math.random(1, 3)]
				v94.Pitch = math.random(90, 110) / 100
				v_u_15:PlaySound(v94, v91, game.SoundService.Effect)
				local v95 = v_u_8.Damage.BlockHit:Clone()
				v95.Parent = v91
				v95:Emit(1)
				v_u_3:AddItem(v95, 0.3)
			end
		else
			return
		end
	end)
	local v_u_96 = {}
	local v_u_97 = {}
	for v98 = 1, #v_u_6.Animations.Misc.Hits.Normal:GetChildren() do
		local v99 = "Hit" .. v98
		table.insert(v_u_96, v99)
	end
	for v100 = 1, #v_u_6.Animations.Misc.Hits.Chara:GetChildren() do
		local v101 = "Hit" .. v100
		table.insert(v_u_96, v101)
	end
	local v_u_102 = v_u_6.Animations.Misc.Hits.Normal:GetChildren()
	local v_u_103 = v_u_6.Animations.Misc.Hits.Chara:GetChildren()
	v_u_12.Hit:Connect(function(p104, p105)
		-- upvalues: (copy) v_u_97, (copy) v_u_96, (copy) v_u_103, (copy) v_u_102
		local v106 = p105 and v_u_97 or v_u_96
		local v107 = p105 and v_u_103 or v_u_102
		local v108 = p104:FindFirstChild("Humanoid")
		if v108 then
			local v109 = math.random(1, #v107)
			if v108:GetAttribute("LHit") == v109 then
				repeat
					v109 = math.random(1, #v107)
				until v108:GetAttribute("LHit") ~= v109
			end
			v108:SetAttribute("LHit", v109)
			for _, v110 in v108:GetPlayingAnimationTracks() do
				if table.find(v106, v110.Name) then
					v110:Stop(0.04)
				end
			end
			return v108:LoadAnimation(v107[v109]):Play(0.04, nil, 0.75)
		end
	end)
end
function v17.KnitInit(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_15, (ref) v_u_14, (ref) v_u_16
	v_u_12 = v_u_1.GetService("HandicapService")
	v_u_13 = v_u_1.GetService("BlockService")
	v_u_15 = v_u_1.GetController("FXController")
	v_u_14 = v_u_1.GetService("CustomService")
	v_u_16 = v_u_1.GetController("ToolController")
end
return v17