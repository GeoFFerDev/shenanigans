-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return require(script.Parent.Parent["sleitnick_symbol@2.0.1"].symbol)