-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
require(v6.Modules.Icon)
local _ = v6.Animations
local _ = v6.Utils
local v_u_7 = v6.Sounds
require(v6.Modules.CameraShaker)
local v_u_8 = require(v_u_5.PlayerScripts.PlayerModule)
local v_u_9 = require(v6.Modules.MVP)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "RouletteController"
})
local v_u_14 = {
	"Be the first to reach 12 kills with reduced cooldowns and increased damage!",
	"Be the last one standing in a battle against players with every moveset shuffled!",
	"Survive against the enemy team in a clash of sorcery!",
	"Clash against the strongest sorcerer of history!",
	"Survive till the end as waves of curses attack!",
	"Survive until the end without being tagged!",
	"Be the last one standing on the platform as it melts!",
	"GOD BLESS AMERICA RAHHHHHH!!!!!!!!!!! \240\159\166\133\240\159\166\133\240\159\166\133"
}
function v13.Start(_)
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_2, (ref) v_u_12, (copy) v_u_7, (ref) v_u_10, (copy) v_u_9, (ref) v_u_11, (copy) v_u_14, (copy) v_u_3, (copy) v_u_8
	task.spawn(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_4, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_10
		local v_u_15 = v_u_5.PlayerGui:WaitForChild("Roulette")
		v_u_15.Enabled = true
		workspace:GetAttributeChangedSignal("Timer"):Connect(function()
			-- upvalues: (copy) v_u_15, (ref) v_u_4
			if workspace:GetAttribute("Timer") == nil then
				v_u_15.Time.Visible = false
			else
				v_u_15.Time.Text = workspace:GetAttribute("Timer")
				v_u_15.Time.Size = UDim2.new(1, 0, 0.15, 0)
				v_u_15.Time.AnchorPoint = Vector2.new(0.5, 0.2)
				v_u_15.Time.Rotation = 5
				v_u_15.Time.Visible = true
				v_u_4:Create(v_u_15.Time, TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					["Size"] = UDim2.new(1, 0, 0.1, 0),
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Rotation"] = 0
				}):Play()
			end
		end)
		local v_u_16 = v_u_5.PlayerGui.Roulette.Gamemode_Items.Buttons
		v_u_2.RenderStepped:Connect(function(p17)
			-- upvalues: (copy) v_u_15, (ref) v_u_5, (copy) v_u_16
			local v18 = v_u_15.Load.WaitSpin
			v18.Rotation = v18.Rotation + 30 * p17
			if v_u_5.Team and (v_u_5.Team.Name == "Lobby" and not (v_u_5.Character and v_u_5.Character:GetAttribute("Dead"))) then
				v_u_5.PlayerGui.Main.Enabled = false
				if _G.MVP_PLAYING == true then
					v_u_16.Visible = false
				else
					v_u_16.Visible = true
				end
			else
				v_u_5.PlayerGui.Main.Enabled = true
				v_u_16.Visible = false
				return
			end
		end)
		v_u_16.Spectate.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_10
			v_u_12:PlaySound(v_u_7.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_12:PlaySound(v_u_7.Misc.UI.Switch, workspace, game.SoundService.Effect)
			v_u_10.Spectate:Fire()
		end)
		local v_u_19 = false
		v_u_16.AFK.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_19, (copy) v_u_16, (ref) v_u_10
			v_u_12:PlaySound(v_u_7.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_12:PlaySound(v_u_7.Misc.UI.Switch, workspace, game.SoundService.Effect)
			v_u_19 = not v_u_19
			v_u_16.AFK.BackgroundColor3 = v_u_19 == true and Color3.fromRGB(255, 152, 152) or Color3.fromRGB(170, 255, 127)
			v_u_16.AFK.Text = v_u_19 == true and "AFK" or "PLAYING"
			v_u_10.Spectate:Fire(v_u_19)
		end)
	end)
	local v_u_104 = {
		["Transition"] = function(p20)
			-- upvalues: (ref) v_u_5, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4
			local v21 = v_u_5.PlayerGui:WaitForChild("Roulette"):WaitForChild("Load")
			v21.Gamemode.Text = p20
			v21.WaitTime.Size = UDim2.new(0, 0, 0, 10)
			v_u_12:PlaySound(v_u_7.Misc.UI.Load1, workspace, game.SoundService.Effect)
			local v22 = TweenInfo.new(0.5)
			v_u_4:Create(v21, v22, {
				["BackgroundTransparency"] = 0,
				["ImageTransparency"] = 0
			}):Play()
			v_u_4:Create(v21.WaitSpin, v22, {
				["ImageTransparency"] = 0
			}):Play()
			v_u_4:Create(v21.WaitTime, v22, {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_4:Create(v21.WaitTime, TweenInfo.new(1), {
				["Size"] = UDim2.new(1, 0, 0, 10)
			}):Play()
			v_u_4:Create(v21.Gamemode, v22, {
				["TextTransparency"] = 0
			}):Play()
			repeat
				task.wait()
			until not workspace:GetAttribute("Loading")
			local v23 = TweenInfo.new(1)
			v_u_12:PlaySound(v_u_7.Misc.UI.Load2, workspace, game.SoundService.Effect)
			v_u_4:Create(v21, v23, {
				["BackgroundTransparency"] = 1,
				["ImageTransparency"] = 1
			}):Play()
			v_u_4:Create(v21.WaitSpin, v23, {
				["ImageTransparency"] = 1
			}):Play()
			v_u_4:Create(v21.WaitTime, v23, {
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_4:Create(v21.Gamemode, v23, {
				["TextTransparency"] = 1
			}):Play()
		end,
		["Result"] = function(p24)
			-- upvalues: (ref) v_u_5, (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_11
			local v_u_25 = v_u_5.PlayerGui:WaitForChild("Roulette")
			v_u_12:PlaySound(v_u_7.Misc.UI.DuelEnd, workspace, game.SoundService.Music)
			local v26 = 0
			local v27 = {}
			local v28 = nil
			local v_u_29 = nil
			for v30, v31 in p24 do
				local v32 = game.Players:FindFirstChild(v31[3])
				if v32 then
					if v32 == v_u_5 then
						v_u_29 = v31[2]
					end
					if v26 <= v31[1] then
						v26 = v31[1]
						v28 = v32
					end
					local v33 = { v32.UserId, v32.DisplayName or v32.Name, v31[1] }
					table.insert(v27, v33)
				else
					p24[v30] = nil
				end
			end
			table.sort(v27, function(p34, p35)
				return p34[3] > p35[3]
			end)
			local v36 = nil
			if v28 then
				v36 = v_u_9:MVP_Play(v28, v28:GetAttribute("MVP") or "King of Curses")
			else
				task.wait(8.5)
			end
			local v_u_37 = v_u_25.Preset.Winner:Clone()
			v_u_37.Parent = v_u_25.Result
			v_u_4:Create(v_u_37, TweenInfo.new(1), {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_37.Total, TweenInfo.new(1), {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_37.Title, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_37.Total.Title, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			task.wait(1)
			v_u_37.Flash.BackgroundTransparency = 0
			v_u_4:Create(v_u_37.Flash, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_37.Single.Visible = true
			for v38, v_u_39 in v27 do
				local v_u_40 = v_u_25.Preset.PlaceLead:Clone()
				v_u_40.Title.Text = "#" .. v38 .. " " .. v_u_39[2]
				v_u_40.Score.Text = v_u_39[3]
				v_u_40.LayoutOrder = v38
				v_u_40.Parent = v_u_37.Single
				if v38 <= 3 then
					v_u_40.BackgroundTransparency = 0
					if v38 == 1 then
						v_u_40.First.Enabled = true
					elseif v38 == 2 then
						v_u_40.Second.Enabled = true
					else
						v_u_40.Third.Enabled = true
					end
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_39, (copy) v_u_40
					local v41 = game.Players:GetUserThumbnailAsync(v_u_39[1], Enum.ThumbnailType.AvatarBust, Enum.ThumbnailSize.Size150x150)
					v_u_40.UserIcon.Image = v41
				end)
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_29, (copy) v_u_25, (copy) v_u_37, (ref) v_u_12, (ref) v_u_7, (ref) v_u_11
				if v_u_29 then
					local v42 = 0
					for v43, v44 in v_u_29 do
						if math.ceil(v44) > 0 then
							task.wait(0.6)
							v42 = v42 + math.ceil(v44)
							local v45 = v_u_25.Preset.Rewards:Clone()
							v45.Text = v43 .. " (" .. math.ceil(v44) .. "$)"
							v45.Parent = v_u_37.Rewards
							v_u_37.Total.Total.Text = math.clamp(v42, 0, 50) .. "$"
							v_u_12:PlaySound(v_u_7.Misc.UI.Coin, workspace, game.SoundService.Effect)
						end
					end
					v_u_37.Total.Total.Text = math.clamp(v42, 0, 50) .. "$"
					if v42 <= 0 then
						local v46 = v_u_25.Preset.Rewards:Clone()
						v46.Text = "NOTHING??????? (0$)"
						v46.Parent = v_u_37.Rewards
						v_u_12:PlaySound(v_u_7.Misc.UI.CoinZero, workspace, game.SoundService.Music)
						v_u_12:PlaySound(v_u_7.Misc.UI.CoinZero2, workspace, game.SoundService.Effect)
						v_u_11.Give:Fire("Poor Performance")
					else
						v_u_12:PlaySound(v_u_7.Misc.UI.CoinTotal, workspace, game.SoundService.Music)
						task.wait(0.5)
						v_u_12:PlaySound(v_u_7.Misc.UI.CoinTotal2, workspace, game.SoundService.Effect)
					end
				else
					return
				end
			end)
			task.wait(5.5)
			task.wait(0.5)
			v_u_37:Destroy()
			if v36 then
				v_u_9:MVP_End(v36, true)
			end
		end,
		["ResultTeam"] = function(p47, p48, p49, p50)
			-- upvalues: (ref) v_u_5, (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_11
			local v_u_51 = v_u_5.PlayerGui:WaitForChild("Roulette")
			v_u_12:PlaySound(v_u_7.Misc.UI.DuelEnd, workspace, game.SoundService.Music)
			local v52 = 0
			local v53 = {}
			local v54 = 0
			local v55 = {}
			local v56 = nil
			local v_u_57 = nil
			local v58 = nil
			for v59, v60 in p47 do
				local v61 = game.Players:FindFirstChild(v60[3])
				if v61 then
					if v61 == v_u_5 then
						v_u_57 = v60[2]
					end
					if v61.Team == p48 then
						if v52 <= v60[1] then
							v52 = v60[1]
							v56 = v61
						end
						local v62 = { v61.UserId, v61.DisplayName or v61.Name, v60[1] }
						table.insert(v53, v62)
					else
						if v54 <= v60[1] then
							v54 = v60[1]
							v58 = v61
						end
						local v63 = { v61.UserId, v61.DisplayName or v61.Name, v60[1] }
						table.insert(v55, v63)
					end
				else
					p47[v59] = nil
				end
			end
			table.sort(v53, function(p64, p65)
				return p64[3] > p65[3]
			end)
			table.sort(v55, function(p66, p67)
				return p66[3] > p67[3]
			end)
			if p50 == p48 then
				v58 = nil
			else
				v56 = nil
			end
			local v68 = nil
			if v56 or v58 then
				v68 = v_u_9:MVP_Play(v56 or v58, (v56 or v58):GetAttribute("MVP") or "King of Curses")
			else
				task.wait(8.5)
			end
			local v_u_69 = v_u_51.Preset.Winner:Clone()
			v_u_69.Parent = v_u_51.Result
			v_u_4:Create(v_u_69, TweenInfo.new(1), {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_69.Total, TweenInfo.new(1), {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_69.Title, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			v_u_4:Create(v_u_69.Total.Title, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			task.wait(1)
			v_u_69.Flash.BackgroundTransparency = 0
			v_u_4:Create(v_u_69.Flash, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_69.Team.Visible = true
			v_u_69.Team.Win.UIStroke.Color = p48.TeamColor.Color
			v_u_69.Team.Lose.UIStroke.Color = p49.TeamColor.Color
			for v70, v_u_71 in v53 do
				local v_u_72 = v_u_51.Preset.PlaceLead:Clone()
				v_u_72.Title.Text = "#" .. v70 .. " " .. v_u_71[2]
				v_u_72.Score.Text = v_u_71[3]
				v_u_72.LayoutOrder = v70
				v_u_72.Size = UDim2.new(1, -10, 0.2, 0)
				v_u_72.Parent = v_u_69.Team.Win
				task.spawn(function()
					-- upvalues: (copy) v_u_71, (copy) v_u_72
					local v73 = game.Players:GetUserThumbnailAsync(v_u_71[1], Enum.ThumbnailType.AvatarBust, Enum.ThumbnailSize.Size150x150)
					v_u_72.UserIcon.Image = v73
				end)
			end
			for v74, v_u_75 in v55 do
				local v_u_76 = v_u_51.Preset.PlaceLead:Clone()
				v_u_76.Title.Text = "#" .. v74 .. " " .. v_u_75[2]
				v_u_76.Score.Text = v_u_75[3]
				v_u_76.LayoutOrder = v74
				v_u_76.Size = UDim2.new(1, -10, 0.2, 0)
				v_u_76.Parent = v_u_69.Team.Lose
				task.spawn(function()
					-- upvalues: (copy) v_u_75, (copy) v_u_76
					local v77 = game.Players:GetUserThumbnailAsync(v_u_75[1], Enum.ThumbnailType.AvatarBust, Enum.ThumbnailSize.Size150x150)
					v_u_76.UserIcon.Image = v77
				end)
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_57, (copy) v_u_51, (copy) v_u_69, (ref) v_u_12, (ref) v_u_7, (ref) v_u_11
				if v_u_57 then
					local v78 = 0
					for v79, v80 in v_u_57 do
						if math.ceil(v80) > 0 then
							task.wait(0.6)
							v78 = v78 + math.ceil(v80)
							local v81 = v_u_51.Preset.Rewards:Clone()
							v81.Text = v79 .. " (" .. math.ceil(v80) .. "$)"
							v81.Parent = v_u_69.Rewards
							v_u_69.Total.Total.Text = math.clamp(v78, 0, 50) .. "$"
							v_u_12:PlaySound(v_u_7.Misc.UI.Coin, workspace, game.SoundService.Effect)
						end
					end
					v_u_69.Total.Total.Text = math.clamp(v78, 0, 50) .. "$"
					if v78 <= 0 then
						local v82 = v_u_51.Preset.Rewards:Clone()
						v82.Text = "NOTHING??????? (0$)"
						v82.Parent = v_u_69.Rewards
						v_u_12:PlaySound(v_u_7.Misc.UI.CoinZero, workspace, game.SoundService.Music)
						v_u_12:PlaySound(v_u_7.Misc.UI.CoinZero2, workspace, game.SoundService.Effect)
						v_u_11.Give:Fire("Poor Performance")
					else
						v_u_12:PlaySound(v_u_7.Misc.UI.CoinTotal, workspace, game.SoundService.Music)
						task.wait(0.5)
						v_u_12:PlaySound(v_u_7.Misc.UI.CoinTotal2, workspace, game.SoundService.Effect)
					end
				else
					return
				end
			end)
			task.wait(5.5)
			task.wait(0.5)
			v_u_69:Destroy()
			if v68 then
				v_u_9:MVP_End(v68, true)
			end
		end,
		["Announce"] = function(p83, p84)
			-- upvalues: (ref) v_u_5, (ref) v_u_12, (ref) v_u_7, (ref) v_u_14, (ref) v_u_4
			local v85 = v_u_5.PlayerGui:WaitForChild("Roulette").Gamemode
			v_u_12:PlaySound(v_u_7.Misc.UI.Gamemode, workspace, game.SoundService.Effect)
			v85.Text = p84 .. "\n<font size=\"30\">" .. v_u_14[p83] .. "</font>"
			v85.Gamemode.Text = v85.Text
			v_u_4:Create(v85, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			v_u_4:Create(v85.Gamemode, TweenInfo.new(1), {
				["TextTransparency"] = 0
			}):Play()
			task.wait(5)
			v_u_4:Create(v85, TweenInfo.new(5), {
				["TextTransparency"] = 1
			}):Play()
			v_u_4:Create(v85.Gamemode, TweenInfo.new(5), {
				["TextTransparency"] = 1
			}):Play()
		end,
		["Credits"] = function(p86, p87)
			-- upvalues: (ref) v_u_5, (ref) v_u_4, (ref) v_u_3
			local v88 = v_u_5.PlayerGui:WaitForChild("Roulette")
			local v89 = v88.Preset.MapCredits:Clone()
			v89.Text = p86
			v89.Creators.Text = "By " .. p87
			v89.Parent = v88
			v_u_4:Create(v89, TweenInfo.new(2.5, Enum.EasingStyle.Exponential), {
				["Position"] = UDim2.new(0, 20, 0, 100),
				["TextTransparency"] = 0,
				["TextStrokeTransparency"] = 0
			}):Play()
			v_u_4:Create(v89.Creators, TweenInfo.new(2.5, Enum.EasingStyle.Exponential), {
				["TextTransparency"] = 0,
				["TextStrokeTransparency"] = 0
			}):Play()
			task.wait(2.5)
			local v90 = TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_4:Create(v89, v90, {
				["TextTransparency"] = 1,
				["TextStrokeTransparency"] = 1
			}):Play()
			v_u_4:Create(v89.Creators, v90, {
				["TextTransparency"] = 1,
				["TextStrokeTransparency"] = 1
			}):Play()
			v_u_3:AddItem(v89, 1.5)
		end,
		["Crow"] = function(p91)
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_12, (ref) v_u_7, (ref) v_u_2, (ref) v_u_8, (ref) v_u_5
			local v92 = p91:WaitForChild("CrowUpd", 0.5)
			if v92 then
				_G.Crow = v92
				local v93 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
				v93.Position = p91.HumanoidRootPart.Position
				v93.Parent = workspace.Effects
				v_u_3:AddItem(v93, 1.5)
				v93.Attachment.Sparks:Emit(20)
				v_u_4:Create(v93, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(0, 0, 0),
					["Transparency"] = 1
				}):Play()
				v_u_12:PlaySound(v_u_7.Todo.Clap, v93, game.SoundService.Effect)
				local v94 = p91.HumanoidRootPart.CFrame
				local v95 = p91.HumanoidRootPart.CFrame
				workspace.CurrentCamera.CameraSubject = p91.Head
				local v96 = 1
				while true do
					local v97 = v_u_2.Heartbeat:Wait()
					if not p91.Parent then
						break
					end
					local v98 = workspace.CurrentCamera.CFrame
					local v99 = v_u_8:GetControls():GetMoveVector()
					local v100 = v98.RightVector * v99.X + -v98.LookVector * v99.Z
					local v101 = v98.LookVector
					if not _G.Shift then
						if v99 == Vector3.new(0, 0, 0) then
							v101 = v94.LookVector
							v96 = 1
						else
							v96 = v96 + 0.4 * v97
							v101 = v100
						end
					end
					v95 = CFrame.lookAlong(v95.Position + v100 * v97 * 20 * v96, v101)
					local v102 = 10 * v97
					v94 = v94:Lerp(v95, (math.clamp(v102, 0, 1)))
					v92:FireServer(v94)
					p91.HumanoidRootPart.CFrame = v94
					if not p91.Parent then
						break
					end
				end
				_G.Crow = nil
				local v103 = v_u_5.Character or v_u_5.CharacterAdded:Wait()
				workspace.CurrentCamera.CameraSubject = v103:WaitForChild("Humanoid", 1)
			end
		end
	}
	v_u_10.Effects:Connect(function(p105, ...)
		-- upvalues: (copy) v_u_104
		local v106 = v_u_104[p105]
		if v106 then
			v106(...)
		end
	end)
end
function v13.KnitStart(_)
	local v_u_107 = game:GetService("TextChatService")
	v_u_107.MessageReceived:Connect(function(p108)
		-- upvalues: (copy) v_u_107
		if workspace:GetAttribute("Roulette") then
			local v109 = p108.Text
			local v110 = p108.TextSource
			if v110 then
				local v111 = workspace.Effects.Crows:FindFirstChild(v110.Name)
				if v111 then
					v_u_107:DisplayBubble(v111.Head, v109)
				end
			else
				return
			end
		else
			return
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("RouletteService")
	v_u_11 = v_u_1.GetService("AchievementService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13