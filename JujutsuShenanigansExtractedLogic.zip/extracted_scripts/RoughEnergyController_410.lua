-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "RoughEnergyController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_32 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:Flash(p12, Color3.fromRGB(85, 255, 127), 0.5)
				v_u_10:PlaySound(v_u_7.Hakari.OverLuck.Charge, v13, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p14)
			-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = v_u_6.Gojo.AirPalm:Clone()
				v16.Parent = workspace.Effects
				v16:SetPrimaryPartCFrame(v15.CFrame * CFrame.new(0, 0, -4))
				v_u_10:PlaySound(v_u_7.Itadori.DivergentFist.Swing, v15, game.SoundService.Effect)
				v_u_3:Create(v16.Blast, TweenInfo.new(0.3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(13, 13, 0),
					["CFrame"] = v16.Blast.CFrame + v15.CFrame.LookVector * 2,
					["Transparency"] = 1
				}):Play()
				v_u_3:Create(v16.Core, TweenInfo.new(0.3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(0, 10, 0),
					["CFrame"] = v16.Core.CFrame + v15.CFrame.LookVector * 5,
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v16, 0.6)
			end
		end,
		["Hit"] = function(p17, p18)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_10:Flash(p18, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v19, game.SoundService.Effect)
				local v20 = v_u_6.Hakari.RoughHit:Clone()
				v20.Position = v19.Position
				v20.Parent = workspace.Effects
				v_u_2:AddItem(v20, 1)
				v_u_3:Create(v20.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v20.Glow:Emit(1)
				v20.Sparks:Emit(50)
				v20.Wind:Emit(7)
				v20.Wind2:Emit(7)
				if v_u_4 == p17 or v_u_4.Character == p18 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Dash"] = function(p21)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v_u_22 = p21:FindFirstChild("HumanoidRootPart")
			if v_u_22 then
				v_u_10:PlaySound(v_u_7.Hakari.EnergySurge.Swing, v_u_22, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Hakari.OverLuck.Speed1, v_u_22, game.SoundService.Effect)
				for v23 = 1, 3 do
					task.delay(0.075 * v23, function()
						-- upvalues: (ref) v_u_6, (copy) v_u_22, (ref) v_u_3, (ref) v_u_2
						local v24 = v_u_6.Itadori.Shock:Clone()
						v24.CFrame = CFrame.lookAlong(v_u_22.Position, Vector3.new(-0, -1, -0)) * CFrame.Angles(1.5707963267948966, 0, 0)
						v24.Transparency = 0.3
						v24.Parent = workspace.Effects
						v_u_3:Create(v24, TweenInfo.new(0.15), {
							["Size"] = Vector3.new(30, 0, 30),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v24, 0.15)
					end)
				end
			end
		end,
		["Crush"] = function(_, p25, p26)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8
			local v27 = v_u_6.Hiromi.Shockwave:Clone()
			v27.Position = p25
			v27.Parent = workspace.Effects
			local v28 = v27.CFrame
			local v29 = CFrame.Angles
			local v30 = math.random(-179, 179)
			v27.CFrame = v28 * v29(0, math.rad(v30), 0)
			v_u_3:Create(v27.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(15, 0, 15)
			}):Play()
			v_u_3:Create(v27.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v27.Floor.Glow:Emit(1)
			v27.Floor.Ring:Emit(10)
			v_u_2:AddItem(v27, 1.5)
			if p26 then
				local v31 = v_u_6.Hakari.RoughImpact:Clone()
				v31.Position = p25
				v31.Parent = workspace.Effects
				v_u_2:AddItem(v31, 2)
				v_u_3:Create(v31.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v31.Glow:Emit(1)
				v31.Sparks:Emit(50)
				v31.Wind2:Emit(7)
				v_u_3:Create(v31.Air, TweenInfo.new(0.2), {
					["Position"] = Vector3.new(0, 0, 0)
				}):Play()
				v_u_10:PlaySound(v_u_7.Hakari.Shock, v31, game.SoundService.Effect)
			end
			v_u_10:PlaySound(v_u_7.Hakari.Impact, v27, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p25).Magnitude < 150 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end
	}
	v_u_9.Effects:Connect(function(p33, ...)
		-- upvalues: (copy) v_u_32
		local v34 = v_u_32[p33]
		if v34 then
			v34(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("RoughEnergyService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11