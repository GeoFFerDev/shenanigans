-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Lighting")
local _ = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v6 = v5.Animations
local v7 = v5.Utils
local _ = v5.Sounds
require(v5.Modules.CameraShaker)
local v8 = require(v5.Modules.SraikoVFX)
require(v5.TEMP_CHARA_STUFF.VelocityHandler)
local v_u_9 = require(v5.TEMP_CHARA_STUFF.AnimationRetriever)
local v_u_10 = require(v5.TEMP_CHARA_STUFF.EffectUtility)
local v_u_11 = require(v5.TEMP_CHARA_STUFF.CameraShake)
local v_u_12 = require(v5.TEMP_CHARA_STUFF.Vignette)
require(v5.TEMP_CHARA_STUFF.RockHandler)
local v_u_13 = require(v5.TEMP_CHARA_STUFF.Smoke)
require(v5.TEMP_CHARA_STUFF.Afterimage)
require(v5.TEMP_CHARA_STUFF.MoonUtil)
local v_u_14 = require(v5.TEMP_CHARA_STUFF.RunCameraRig)
require(v5.TEMP_CHARA_STUFF.Create_Clone)
local v_u_15 = require(v5.TEMP_CHARA_STUFF.VelocityUtil)
local v_u_16 = require(v5.TEMP_CHARA_STUFF.Utility)
local v_u_17 = require(v5.TEMP_CHARA_STUFF.Yuki_FOV)
local _ = v8.Enabled
local _ = v8.Emit
local _ = v8.EmitMesh
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v21 = v_u_1.CreateController({
	["Name"] = "CursedRemedyController"
})
local v_u_22 = v6.Misc.C.CursedRemedy
local v_u_23 = game:GetService("Players").LocalPlayer
local _ = v7.Misc.C.Chara
local v_u_24 = script.Finisher
local function v_u_59(p_u_25, p_u_26, p27)
	-- upvalues: (copy) v_u_10, (copy) v_u_15, (copy) v_u_16, (copy) v_u_2, (copy) v_u_3, (copy) v_u_11, (copy) v_u_12, (copy) v_u_4, (copy) v_u_17
	local v28 = p27.Torso
	local v_u_29 = p27.RootPart
	local v30 = p27.Animation
	local v_u_31 = p27.Job
	script.HitSFX.PlaybackSpeed = v30.Speed
	v_u_31:Task(v_u_10.AddSFX(script.HitSFX, v28, 0.5))
	local v32 = v_u_29:FindFirstChildOfClass("BodyVelocity")
	if v32 then
		v32:Destroy()
	end
	local v_u_33 = v_u_15.Create(v_u_29, "HOLDIN THAT BEAM LES GO SEEYUH")
	v_u_33.MaxForce = Vector3.new(80000, 0, 80000)
	v_u_33.Parent = v_u_29
	local v_u_34 = 0
	v_u_16.BindSignalDisconnectToInstanceDestroying(v_u_2.PostSimulation, v_u_33, function(_)
		-- upvalues: (copy) v_u_33, (copy) v_u_29, (ref) v_u_34
		v_u_33.Velocity = v_u_29.CFrame.LookVector * v_u_34
	end)
	v_u_31:Task(v_u_33)
	local v_u_35 = v_u_31:Task(script.Hit["15"]:Clone())
	v_u_35.Parent = v_u_29
	v_u_31:Task(v30:GetMarkerReachedSignal("slow"):Connect(function(p36)
		-- upvalues: (copy) v_u_35, (ref) v_u_3
		local v37 = p36 == "true"
		local v38 = TweenInfo.new(v37 and 0.25 or 0.75, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
		for _, v39 in pairs(v_u_35:GetDescendants()) do
			if v39.ClassName == "ParticleEmitter" then
				v_u_3:Create(v39, v38, {
					["TimeScale"] = v37 and 0 or 1
				}):Play()
			end
		end
	end))
	v_u_31:Task(v30:GetMarkerReachedSignal("barrage"):Connect(function(_)
		-- upvalues: (copy) v_u_31, (ref) v_u_10, (copy) p_u_25, (ref) v_u_11, (copy) p_u_26
		v_u_31:Task(task.spawn(function()
			-- upvalues: (ref) v_u_10, (ref) p_u_25, (ref) v_u_11, (ref) p_u_26
			local v_u_40 = v_u_10.Distance_Close(p_u_25) and v_u_11(1.5, 30, 0.01, 0, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.4, 0.4, 0.4))
			if v_u_40 then
				task.delay(1, function()
					-- upvalues: (copy) v_u_40
					v_u_40:StartFadeOut(0.5)
				end)
			end
			local v41 = time()
			local v42 = 0
			while p_u_26.Parent and (p_u_26:FindFirstChild("Head") and time() - v41 < 1.25) do
				if v_u_10.Distance_Far(p_u_25) then
					local v43 = script.Hit.barrage:Clone()
					v43.Parent = workspace.Effects
					v_u_10.Weld(v43, p_u_26.Head)
					v_u_10.Arc.EmitAttachment(v43)
				end
				v42 = v42 + 0.5
				local v44 = task.wait
				local v45 = v42 / 100
				v44(0.1 - math.clamp(v45, 0, 0.05))
			end
		end))
	end))
	local v_u_46 = nil
	local v_u_47 = nil
	local v_u_48 = Instance.new("ColorCorrectionEffect")
	v_u_31:Task(v_u_48)
	v_u_31:Task(v30:GetMarkerReachedSignal("vfx"):Connect(function(p49)
		-- upvalues: (ref) v_u_46, (ref) v_u_10, (copy) p_u_25, (ref) v_u_11, (ref) v_u_12, (ref) v_u_34, (ref) v_u_16, (ref) v_u_2, (copy) v_u_33, (copy) v_u_31, (ref) v_u_47, (copy) v_u_29, (copy) v_u_48, (ref) v_u_4, (ref) v_u_3, (ref) v_u_17, (copy) v_u_35
		if p49 == "13" then
			if v_u_46 then
				v_u_46:Destroy()
			end
			if v_u_10.Distance_Close(p_u_25) then
				v_u_11(2, 20, 0.01, 0.15, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
				v_u_12(Color3.fromRGB(255, 0, 0), 0.5, 0.2)
			end
			v_u_34 = -60
			local v_u_50 = nil
			v_u_50 = v_u_16.BindSignalDisconnectToInstanceDestroying(v_u_2.PreSimulation, v_u_33, function(p51)
				-- upvalues: (ref) v_u_34, (ref) v_u_50
				if v_u_34 == 0 then
					return v_u_50:Destroy()
				end
				local v52 = v_u_34 + p51 * 60 * 0.75
				v_u_34 = math.min(v52, 0)
			end)
			v_u_31:Task(v_u_50)
			v_u_31:Task(task.delay(0.5, function()
				-- upvalues: (ref) v_u_50, (ref) v_u_47, (ref) v_u_16, (ref) v_u_2, (ref) v_u_33, (ref) v_u_34, (ref) v_u_31
				v_u_50:Destroy()
				v_u_47 = v_u_16.BindSignalDisconnectToInstanceDestroying(v_u_2.PreSimulation, v_u_33, function(p53)
					-- upvalues: (ref) v_u_34, (ref) v_u_47
					if v_u_34 >= 30 then
						return v_u_47:Destroy()
					end
					local v54 = v_u_34 + p53 * 60 * 6.5
					v_u_34 = math.min(v54, 125)
				end)
				v_u_31:Task(v_u_47)
			end))
			if v_u_10.Distance_Far(p_u_25) then
				v_u_10.Arc.CloneAndEmit(script.Hit["13"], v_u_29)
			end
		elseif p49 == "14" then
			if v_u_47 then
				v_u_47:Destroy()
			end
			if v_u_10.Distance_Close(p_u_25) then
				v_u_11(2, 20, 0.01, 0.15, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
				v_u_12(Color3.fromRGB(255, 0, 0), 0.5, 0.2)
			end
			v_u_34 = 0
			if v_u_10.Distance_Far(p_u_25) then
				v_u_10.Arc.CloneAndEmit(script.Hit["14"], v_u_29)
				return
			end
		else
			if p49 == "15" then
				if v_u_10.Distance_Close(p_u_25) then
					v_u_48.Parent = v_u_4
					v_u_3:Create(v_u_48, TweenInfo.new(2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["TintColor"] = Color3.fromRGB(153, 153, 153)
					}):Play()
					v_u_11(2, 10, 0.01, 2, Vector3.new(0.8, 0.8, 0.8))
					v_u_12(Color3.fromRGB(255, 0, 0), 0.35, 0.4)
					v_u_17.Tween(45, { 2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out })
					v_u_31:Task(function()
						-- upvalues: (ref) v_u_17
						v_u_17.Tween(70, { 0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out })
					end)
				end
				v_u_10.Arc.EmitAttachment(v_u_35)
				return
			end
			if p49 == "16" then
				if v_u_48.Parent ~= nil then
					v_u_3:Create(v_u_48, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["TintColor"] = Color3.fromRGB(255, 255, 255)
					}):Play()
				end
				if v_u_10.Distance_Close(p_u_25) then
					v_u_11(3, 20, 0.01, 1, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
					v_u_12(Color3.fromRGB(255, 0, 0), 0.35, 0.4)
				end
				for _, v55 in pairs(v_u_35:GetDescendants()) do
					if v55.ClassName == "ParticleEmitter" then
						v55.TimeScale = 0
					end
				end
				v_u_10.Arc.CloneAndEmit(script.Hit["16"], v_u_29)
				return
			end
			if v_u_46 then
				v_u_46:Clean()
				v_u_33.Velocity = Vector3.new(0, 0, 0)
			end
			v_u_34 = 45
			v_u_46 = v_u_16.BindSignalDisconnectToInstanceDestroying(v_u_2.PreSimulation, v_u_33, function(p56)
				-- upvalues: (ref) v_u_34, (ref) v_u_46
				if v_u_34 <= 0 then
					return v_u_46:Clean()
				end
				local v57 = v_u_34 - p56 * 60 * 1.4
				v_u_34 = math.max(v57, 0)
			end)
			local v58 = script.Hit:FindFirstChild(p49)
			if v58 and v_u_10.Distance_Far(p_u_25) then
				v_u_10.Arc.CloneAndEmit(v58, v_u_29)
			end
			if v_u_10.Distance_Close(p_u_25) then
				v_u_11(2, 20, 0.01, 0.15, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
				v_u_12(Color3.fromRGB(255, 0, 0), 0.5, 0.2)
			end
		end
	end))
end
function v21.KnitStart(_)
	-- upvalues: (copy) v_u_9, (copy) v_u_22, (copy) v_u_23, (copy) v_u_59, (copy) v_u_3, (copy) v_u_15, (copy) v_u_16, (copy) v_u_2, (copy) v_u_24, (copy) v_u_4, (copy) v_u_3, (copy) v_u_14, (copy) v_u_17, (copy) v_u_10, (copy) v_u_12, (copy) v_u_11, (copy) v_u_13, (ref) v_u_18
	local v_u_146 = {
		["RemedyFinisher"] = function(p_u_60, p_u_61)
			-- upvalues: (ref) v_u_9, (ref) v_u_22, (ref) v_u_23, (ref) v_u_59, (ref) v_u_3, (ref) v_u_15, (ref) v_u_16, (ref) v_u_2, (ref) v_u_24, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_17, (ref) v_u_10, (ref) v_u_12
			local v62 = v_u_9.new(p_u_60, v_u_22.Finisher)
			if v62 ~= nil then
				local v_u_63 = v62.Torso
				local v_u_64 = v62.RootPart
				local v_u_65 = v62.Animation
				local v_u_66 = v62.Job
				local v_u_67 = p_u_60:FindFirstChild("Knife")
				local v_u_68 = p_u_61:FindFirstChild("Head")
				local v_u_69 = p_u_61:FindFirstChild("Humanoid")
				local v_u_70 = v_u_23.Character == p_u_60 and true or v_u_23.Character == p_u_61
				local v_u_71 = math.random(1, 15) == 1
				v_u_59(p_u_60, p_u_61, v62)
				v_u_66:Task(v_u_65:GetMarkerReachedSignal("finisher"):Connect(function()
					-- upvalues: (copy) v_u_66, (copy) v_u_65, (copy) p_u_60, (ref) v_u_3, (copy) v_u_68, (copy) v_u_69, (copy) v_u_64, (ref) v_u_15, (ref) v_u_16, (ref) v_u_2, (copy) v_u_70, (ref) v_u_24, (ref) v_u_4, (ref) v_u_3, (ref) v_u_22, (ref) v_u_14, (ref) v_u_17, (ref) v_u_10, (copy) v_u_67, (ref) v_u_12, (copy) v_u_71, (copy) v_u_63, (copy) p_u_61, (ref) v_u_9
					v_u_66:Clean()
					v_u_66:Task(v_u_65.Stopped:Once(function()
						-- upvalues: (ref) v_u_66
						v_u_66:Cleanup()
					end))
					v_u_66:Task(p_u_60.AncestryChanged:Connect(function()
						-- upvalues: (ref) p_u_60, (ref) v_u_66
						if not p_u_60.Parent then
							v_u_66:Cleanup()
						end
					end))
					local v_u_72 = workspace:FindFirstChild("Music")
					if v_u_72 then
						v_u_72:Pause()
						v_u_66:Task(function()
							-- upvalues: (copy) v_u_72, (ref) v_u_3
							v_u_72:Resume()
							local v73 = v_u_72.Volume
							v_u_72.Volume = 0
							v_u_3:Create(v_u_72, TweenInfo.new(2, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
								["Volume"] = v73
							}):Play()
						end)
					end
					local v_u_74 = nil
					local v_u_75 = false
					local function v_u_81(p76, p77)
						-- upvalues: (ref) v_u_68, (ref) v_u_69
						if v_u_68 then
							v_u_68.Transparency = p76
							for _, v78 in ipairs(v_u_68:GetChildren()) do
								if v78:IsA("BasePart") or v78:IsA("Decal") then
									v78.Transparency = p76
								end
							end
						end
						if v_u_69 then
							for _, v79 in ipairs(v_u_69:GetAccessories()) do
								local v80 = v79:FindFirstChild("Handle")
								if v80 and (p77 or v80.AccessoryWeld.Part1 == v_u_68) then
									v80.Transparency = p76
								end
							end
						end
					end
					v_u_66:Task(function()
						-- upvalues: (ref) v_u_75, (copy) v_u_81
						if not v_u_75 then
							v_u_81(0, true)
						end
					end)
					local v82 = v_u_64:FindFirstChildOfClass("BodyVelocity")
					if v82 then
						v82:Destroy()
					end
					local v_u_83 = v_u_15.Create(v_u_64, "HOLDIN THAT BEAM LES GO SEEYUH")
					v_u_83.MaxForce = Vector3.new(80000, 0, 80000)
					v_u_83.Parent = v_u_64
					v_u_66:Task(v_u_83)
					local v_u_84 = -30
					v_u_16.BindSignalDisconnectToInstanceDestroying(v_u_2.PostSimulation, v_u_83, function(p85)
						-- upvalues: (ref) v_u_84, (copy) v_u_83, (ref) v_u_64
						if v_u_84 == 0 then
							return v_u_83:Destroy()
						end
						v_u_83.Velocity = v_u_64.CFrame.LookVector * v_u_84
						local v86 = v_u_84 + p85 * 60 * 0.75
						v_u_84 = math.min(v86, 0)
					end)
					if v_u_70 then
						local v_u_87 = v_u_66:Task(v_u_24.Camera:Clone())
						v_u_87:PivotTo(v_u_64.CFrame)
						v_u_87.Parent = workspace.Effects
						local v_u_88 = v_u_66:Task(v_u_24.ColorCorrection:Clone())
						v_u_88.Enabled = false
						v_u_88.Parent = v_u_4
						v_u_66:Task(v_u_65:GetMarkerReachedSignal("zoom_scare"):Connect(function(p89)
							-- upvalues: (ref) v_u_88, (ref) v_u_3
							v_u_88.Enabled = p89 == "start"
							if v_u_88.Enabled then
								v_u_3:Create(v_u_88, TweenInfo.new(3.216666666666667, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
									["Contrast"] = 1.3,
									["Saturation"] = -0.5
								}):Play()
							end
						end))
						local v90 = v_u_87.Humanoid.Animator:LoadAnimation(v_u_22.FinisherCamera)
						v_u_66:Task(v90:GetMarkerReachedSignal("hide_head"):Connect(function(p91)
							-- upvalues: (copy) v_u_81
							v_u_81(p91 == "true" and 1 or 0, true)
						end))
						local v_u_92 = false
						v_u_66:Task(task.delay(7.966666666666667, function()
							-- upvalues: (ref) v_u_92
							v_u_92 = true
						end))
						v_u_66:Task(task.delay(9.366666666666667, function()
							-- upvalues: (ref) v_u_92
							v_u_92 = false
						end))
						v_u_66:Task(v90:GetMarkerReachedSignal("camera"):Connect(function()
							-- upvalues: (ref) v_u_66, (copy) v_u_87, (ref) v_u_16, (ref) v_u_92, (ref) v_u_64, (ref) v_u_14
							v_u_66:Task(function()
								-- upvalues: (ref) v_u_87
								v_u_87:Destroy()
							end)
							v_u_66:BindToRender("CursedRemedyFinisherHackyCameraOffset", v_u_16.ShiftlockRenderPriority, function()
								-- upvalues: (ref) v_u_92, (ref) v_u_87, (ref) v_u_64
								if v_u_92 then
									v_u_87:PivotTo(v_u_64.CFrame + Vector3.new(0, 1, 0))
								else
									v_u_87:PivotTo(v_u_64.CFrame)
								end
							end)
							v_u_66:Task(v_u_14(nil, v_u_87, CFrame.identity))
						end))
						v90:Play(0, nil, v_u_65.Speed)
						v90.TimePosition = v_u_65.TimePosition
						v_u_66:Task(v90.Stopped:Once(function()
							-- upvalues: (copy) v_u_87
							v_u_87:Destroy()
						end))
						v_u_66:Task(v_u_17.AnimateWithMoonFileCustomFPS(v_u_24.FOV, nil, nil, nil, 60 * v_u_65.Speed))
						UDim2.fromOffset(15, 15)
						ColorSequence.new({
							ColorSequenceKeypoint.new(0, Color3.new(1, 0, 0)),
							ColorSequenceKeypoint.new(0.25, Color3.fromRGB(181, 53, 53)),
							ColorSequenceKeypoint.new(0.5, Color3.fromRGB(109, 32, 32)),
							ColorSequenceKeypoint.new(0.75, Color3.fromRGB(181, 53, 53)),
							ColorSequenceKeypoint.new(1, Color3.new(1, 0, 0))
						})
						v_u_66:Task(task.delay(12.883333333333333, function() end))
						v_u_66:Task(task.delay(18.966666666666665, function() end))
						v_u_74 = v_u_88
					end
					v_u_66:Task(v_u_65:GetMarkerReachedSignal("fast_block"):Connect(function(p93)
						-- upvalues: (ref) v_u_10, (ref) v_u_24, (ref) v_u_64
						v_u_10.CloneAndEmit(v_u_24.VFX.fast[p93], v_u_64)
					end))
					local v_u_94 = v_u_24.VFX.pulsing:Clone()
					if v_u_67 then
						v_u_94.Parent = v_u_67.BladeInner
					end
					v_u_66:Task(v_u_94)
					v_u_66:Task(v_u_65:GetMarkerReachedSignal("stab"):Connect(function(_)
						-- upvalues: (ref) v_u_70, (ref) v_u_12, (ref) v_u_74, (ref) v_u_4, (ref) v_u_3, (ref) v_u_10, (copy) v_u_94, (ref) v_u_24, (ref) v_u_64
						if v_u_70 then
							v_u_12(Color3.fromRGB(0, 0, 0), 0.1, 1)
							v_u_74.Saturation = 0
							v_u_74.TintColor = Color3.fromRGB(255, 197, 197)
							v_u_74.Contrast = 1
							v_u_74.Enabled = true
							v_u_4.ExposureCompensation = 0.8
							v_u_3:Create(v_u_74, TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
								["Contrast"] = 0,
								["TintColor"] = Color3.fromRGB(255, 255, 255)
							}):Play()
							v_u_3:Create(v_u_4, TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
								["ExposureCompensation"] = 0
							}):Play()
						end
						v_u_10.Arc.ToggleAttachment(v_u_94, true)
						v_u_10.Arc.CloneAndEmit(v_u_24.VFX.stab, v_u_64)
					end))
					v_u_66:Task(v_u_65:GetMarkerReachedSignal("cut"):Connect(function(_)
						-- upvalues: (ref) v_u_70, (ref) v_u_12, (ref) v_u_74, (ref) v_u_4, (ref) v_u_3, (ref) v_u_75, (ref) v_u_68, (ref) v_u_69, (ref) v_u_16, (copy) v_u_81, (ref) v_u_10, (copy) v_u_94, (ref) v_u_24, (ref) v_u_64
						if v_u_70 then
							v_u_12(Color3.fromRGB(0, 0, 0), 0, 1)
							v_u_74.Saturation = 0
							v_u_74.TintColor = Color3.fromRGB(255, 165, 165)
							v_u_74.Contrast = 1.4
							v_u_74.Enabled = true
							v_u_4.ExposureCompensation = 1.5
							v_u_3:Create(v_u_74, TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
								["Contrast"] = 0,
								["TintColor"] = Color3.fromRGB(255, 255, 255)
							}):Play()
							v_u_3:Create(v_u_4, TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
								["ExposureCompensation"] = 0
							}):Play()
						end
						task.spawn(function()
							-- upvalues: (ref) v_u_75, (ref) v_u_68, (ref) v_u_69, (ref) v_u_16, (ref) v_u_81
							if _G.Settings.Gore == true then
								v_u_75 = true
								local v_u_95 = v_u_68:Clone()
								local v96 = Instance.new("Attachment")
								v96.CFrame = CFrame.new(0, -0.6, 0)
								v96.Parent = v_u_95
								for _, v97 in ipairs(v_u_69:GetAccessories()) do
									local v98 = v97:FindFirstChild("Handle")
									if v98 then
										local v99 = v98:FindFirstChild("AccessoryWeld")
										if v99 and v99.Part1 == v_u_68 then
											local v100 = v98:Clone()
											v100.Anchored = false
											v100.Transparency = 0
											v100.AccessoryWeld.Part0 = v100
											v100.AccessoryWeld.Part1 = v_u_95
											v100.Parent = v_u_95
										end
									end
								end
								v_u_95.CFrame = v_u_68.CFrame
								v_u_95.Name = "FakeHead"
								v_u_95.CanCollide = true
								v_u_95.Parent = workspace.Effects
								local v101 = v_u_16.Seed:NextNumber(-5, 10)
								v_u_95.AssemblyLinearVelocity = Vector3.new(-35, v101, 0)
								local v102 = v_u_16.Seed:NextNumber(-5, 5)
								local v103 = v_u_16.Seed:NextNumber(-5, 5)
								local v104 = v_u_16.Seed
								v_u_95.AssemblyAngularVelocity = Vector3.new(v102, v103, v104:NextNumber(-5, 5))
								task.spawn(function()
									-- upvalues: (copy) v_u_95
									while v_u_95 and v_u_95.Parent do
										v_u_95.Transparency = 0
										v_u_95.face.Transparency = 0
										warn("hell yeah")
										task.wait(0.1)
									end
								end)
								task.delay(10, v_u_95.Destroy, v_u_95)
								task.defer(v_u_81, 1)
							end
						end)
						v_u_10.Arc.ToggleAttachment(v_u_94, false)
						v_u_10.Arc.CloneAndEmit(v_u_24.VFX.cut, v_u_64)
					end))
					v_u_66:Task(v_u_65:GetMarkerReachedSignal("vfx"):Connect(function(p105)
						-- upvalues: (ref) v_u_24, (ref) v_u_65, (ref) v_u_66, (ref) v_u_10, (ref) v_u_71, (ref) v_u_70, (ref) v_u_63, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_67, (ref) p_u_60, (ref) p_u_61
						if p105 == "startcatch" then
							v_u_24.SFX.Normal.PlaybackSpeed = v_u_65.Speed
							v_u_24.SFX.Rare.PlaybackSpeed = v_u_65.Speed
							v_u_24.SFX.Normal.PitchShift.Octave = 1 / v_u_65.Speed
							v_u_24.SFX.Rare.PitchShift.Octave = 1 / v_u_65.Speed
							v_u_66:Task(v_u_10.AddSFX(v_u_24.SFX[v_u_71 and "Rare" or "Normal"], v_u_70 and workspace.Effects or v_u_63, 0.4))
						end
						if v_u_70 then
							if p105 == "hit3" then
								v_u_4.ExposureCompensation = 1
								v_u_3:Create(v_u_4, TweenInfo.new(0.4, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
									["ExposureCompensation"] = 0
								}):Play()
								v_u_12(Color3.fromRGB(0, 0, 0), 0.3, 0.5)
							elseif p105 == "hit1" or p105 == "hit2" then
								v_u_4.ExposureCompensation = 0.25
								v_u_3:Create(v_u_4, TweenInfo.new(0.4, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
									["ExposureCompensation"] = 0
								}):Play()
								v_u_12(Color3.fromRGB(0, 0, 0), 0.5, 0.5, true)
							end
						end
						local v106 = v_u_24.VFX:FindFirstChild(p105)
						if v106 == nil then
							return
						else
							local v107 = v106:GetAttribute("attached")
							local v108 = v106:GetAttribute("person")
							if v_u_67 and v108 == "knife" then
								if p105 == "rotate" then
									local v109 = v106:Clone()
									v109.Parent = v_u_67.BladeInner
									v_u_10.Arc.ToggleAttachment(v109, true, 0.6)
									task.delay(2, v109.Destroy, v109)
								else
									v_u_10.Arc.CloneAndEmit(v106, v_u_67.BladeInner)
								end
							else
								local v110 = v108 == "attacker" and p_u_60
								if not v110 then
									if v108 == "victim" then
										v110 = p_u_61
									else
										v110 = false
									end
								end
								if v110 then
									v_u_10.Arc.CloneAndEmit(v106, v110[v107])
								end
								return
							end
						end
					end))
					task.spawn(function()
						-- upvalues: (ref) v_u_9, (ref) p_u_61, (ref) v_u_22, (ref) v_u_10, (ref) v_u_24, (ref) v_u_68
						local v111 = v_u_9.new(p_u_61, v_u_22.FinisherVictim)
						if v111 ~= nil then
							v111.Job:Task(v111.Animation:GetMarkerReachedSignal("vfx"):Connect(function(p112)
								-- upvalues: (ref) v_u_10, (ref) v_u_24, (ref) v_u_68
								if p112 == "wipe" then
									v_u_10.Arc.CloneAndEmit(v_u_24.VFX.wipe, v_u_68)
								end
							end))
						end
					end)
				end))
			end
		end,
		["RemedyHit"] = function(p113, p114)
			-- upvalues: (ref) v_u_9, (ref) v_u_22, (ref) v_u_59
			local v115 = v_u_9.new(p113, v_u_22.Hit)
			if v115 ~= nil then
				v_u_59(p113, p114, v115)
			end
		end,
		["RemedyStart"] = function(p_u_116)
			-- upvalues: (ref) v_u_9, (ref) v_u_22, (ref) v_u_23, (ref) v_u_10, (ref) v_u_15, (ref) v_u_16, (ref) v_u_2, (ref) v_u_17, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
			local v117 = v_u_9.new(p_u_116, v_u_22.Windup)
			if v117 ~= nil then
				local v118 = v117.Torso
				local v_u_119 = v117.RootPart
				local v120 = v117.Animation
				local v_u_121 = v117.Job
				local v_u_122 = v_u_23.Character == p_u_116
				script.StartupSFX.PlaybackSpeed = v120.Speed
				v_u_121:Task(v_u_10.AddSFX(script.StartupSFX, v118, 0.2))
				local v_u_123 = 0
				local v_u_124 = 0
				local v125 = v_u_119:FindFirstChildOfClass("BodyVelocity")
				if v125 then
					v125:Destroy()
				end
				local v_u_126 = v_u_15.Create(v_u_119, "HOLDIN THAT BEAM LES GO")
				v_u_126.MaxForce = Vector3.new(80000, 0, 80000)
				v_u_126.Parent = v_u_119
				v_u_16.BindSignalDisconnectToInstanceDestroying(v_u_2.PostSimulation, v_u_126, function(_)
					-- upvalues: (copy) v_u_126, (copy) v_u_119, (ref) v_u_123, (ref) v_u_124
					v_u_126.Velocity = v_u_119.CFrame.LookVector * v_u_123 + v_u_119.CFrame.RightVector * v_u_124
				end)
				local v_u_127 = nil
				v_u_121:Task(v_u_126)
				if v_u_122 then
					v_u_121:Task(function()
						-- upvalues: (ref) v_u_17
						v_u_17.Tween(70, { 0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out })
					end)
				end
				local v_u_128 = {}
				for _, v129 in ipairs(script.WindupBody:GetChildren()) do
					for _, v130 in ipairs(v129:GetChildren()) do
						local v131 = v130:Clone()
						v131.Parent = p_u_116[v129.Name]
						v_u_128[v131] = true
					end
				end
				v_u_121:Task(function()
					-- upvalues: (copy) v_u_128, (ref) v_u_10
					for v132 in v_u_128 do
						v_u_10.Arc.ToggleAttachment(v132, false)
						task.delay(1, v132.Destroy, v132)
					end
				end)
				if v_u_122 then
					v_u_17.Tween(60, { 0.75, Enum.EasingStyle.Sine, Enum.EasingDirection.Out })
				end
				local v_u_133 = true
				v_u_121:Task(v120:GetMarkerReachedSignal("vfx"):Connect(function(p134)
					-- upvalues: (ref) v_u_10, (copy) p_u_116, (copy) v_u_119, (ref) v_u_11, (ref) v_u_12, (ref) v_u_124, (ref) v_u_123, (ref) v_u_127, (ref) v_u_16, (ref) v_u_2, (copy) v_u_126, (copy) v_u_122, (ref) v_u_133, (ref) v_u_17, (copy) v_u_121, (ref) v_u_13
					local v135 = script.Windup:FindFirstChild(p134)
					if v135 and v_u_10.Distance_Far(p_u_116) then
						v_u_10.Arc.CloneAndEmit(v135, v_u_119)
					end
					if v_u_10.Distance_Close(p_u_116) then
						v_u_11(4, 40, 0.01, 0.2, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.4, 0.4, 0.4))
						v_u_12(Color3.fromRGB(255, 0, 0), 0.25, 0.3)
					end
					if p134 == "1" then
						v_u_124 = 75
						v_u_123 = 60
						if v_u_127 then
							v_u_127:Clean()
						end
						v_u_127 = v_u_16.BindSignalDisconnectToInstanceDestroying(v_u_2.PreSimulation, v_u_126, function(p136)
							-- upvalues: (ref) v_u_124, (ref) v_u_123
							local v137 = p136 * 60
							local v138 = v_u_124 - v137 * 3
							v_u_124 = math.max(v138, 0)
							local v139 = v_u_123 - v137 * 2
							v_u_123 = math.max(v139, 0)
						end)
						if v_u_122 and v_u_133 then
							v_u_17.Set(70)
							v_u_17.Tween(80, {
								0.075,
								Enum.EasingStyle.Quint,
								Enum.EasingDirection.Out,
								0,
								true
							})
							return
						end
					elseif p134 == "2" then
						v_u_124 = -141.75
						v_u_123 = 60
						if v_u_127 then
							v_u_127:Clean()
						end
						v_u_127 = v_u_16.BindSignalDisconnectToInstanceDestroying(v_u_2.PreSimulation, v_u_126, function(p140)
							-- upvalues: (ref) v_u_124, (ref) v_u_123
							local v141 = p140 * 60
							local v142 = v_u_124 + v141 * 3
							v_u_124 = math.min(v142, 0)
							local v143 = v_u_123 - v141 * 2
							v_u_123 = math.max(v143, 0)
						end)
						if v_u_122 then
							v_u_17.Set(70)
							v_u_17.Tween(80, {
								0.075,
								Enum.EasingStyle.Quint,
								Enum.EasingDirection.Out,
								0,
								true
							})
							v_u_133 = true
							return
						end
					elseif p134 == "3" then
						v_u_124 = 0
						v_u_123 = 65
						if v_u_127 then
							v_u_127:Clean()
						end
						v_u_127 = v_u_16.BindSignalDisconnectToInstanceDestroying(v_u_2.PreSimulation, v_u_126, function(p144)
							-- upvalues: (ref) v_u_123, (ref) v_u_127
							local v145 = v_u_123 - p144 * 60 * 1.15
							v_u_123 = math.max(v145, 0)
							if v_u_123 <= 0 then
								v_u_127:Destroy()
							end
						end)
						v_u_121:Task(task.delay(0.3, function()
							-- upvalues: (ref) v_u_123, (ref) v_u_13, (ref) v_u_119
							while v_u_123 > 7.5 do
								v_u_13(v_u_119, 5, 2)
								task.wait(0.045)
							end
						end))
						if v_u_122 then
							v_u_17.Set(70)
							v_u_17.Tween(85, { 0.1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out })
							task.delay(0.1, function()
								-- upvalues: (ref) v_u_17
								v_u_17.Tween(70, { 0.75, Enum.EasingStyle.Sine, Enum.EasingDirection.Out })
							end)
						end
					end
				end))
			end
		end
	}
	v_u_18.Effects:Connect(function(p147, ...)
		-- upvalues: (ref) v_u_146
		local v148 = v_u_146[p147]
		if v148 then
			v148(...)
		end
	end)
end
function v21.KnitInit(_)
	-- upvalues: (ref) v_u_18, (copy) v_u_1, (ref) v_u_19, (ref) v_u_20
	v_u_18 = v_u_1.GetService("CursedRemedyService")
	v_u_19 = v_u_1.GetController("HitboxController")
	v_u_20 = v_u_1.GetController("FXController")
end
return v21