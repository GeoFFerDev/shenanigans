-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
require(v_u_5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "PiercingBloodController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_37 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_7.Choso.PiercingBlood.Startup, v13, game.SoundService.Effect)
			end
		end,
		["Clap"] = function(p14)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_10:PlaySound(v_u_7.Choso.PiercingBlood.Clap, v15, game.SoundService.Effect)
			end
		end,
		["Blood"] = function(p16, p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_4, (ref) v_u_8
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_6.Choso.PiercingBlood:Clone()
				v19.CFrame = v18.CFrame * CFrame.new(0, 0, -3)
				v19.Parent = workspace.Effects
				v_u_2:AddItem(v19, 1)
				if p17 then
					v19.Start.Blood.Speed = NumberRange.new(10, 400)
				end
				v_u_10:PlaySound(v_u_7.Choso.PiercingBlood.Fire, v18, game.SoundService.Effect)
				v19.Start.Blood:Emit(30)
				v19.Start.Burst:Emit(8)
				local v20 = v_u_3
				local v21 = v19.End
				local v22 = TweenInfo.new(0.1)
				local v23 = {}
				local v24 = -(p17 and 60 or 30)
				v23.Position = Vector3.new(0, 0, v24)
				v20:Create(v21, v22, v23):Play()
				v_u_3:Create(v19.Beam, TweenInfo.new(0.3), {
					["Width0"] = 0,
					["Width1"] = 0
				}):Play()
				v_u_2:AddItem(v19.Beam, 0.3)
				local v25 = Instance.new("Model")
				local v26 = v_u_5.Utils.Itadori.RushWind:Clone()
				v26.CFrame = v19.CFrame * CFrame.new(0, -1, 0)
				v26.Parent = v25
				v25.Parent = workspace.Effects
				v25:ScaleTo(0.6)
				v26.Ring:Emit(7)
				v26.Dash1.Dash:Emit(1)
				v26.Dash2.Dash:Emit(1)
				v_u_3:Create(v26, TweenInfo.new(1, Enum.EasingStyle.Quad), {
					["CFrame"] = v26.CFrame - v26.CFrame.LookVector * 16
				}):Play()
				v_u_2:AddItem(v25, 2)
				if v_u_4.Character == p16 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				for v27 = 1, 4 do
					local v28 = v_u_6.Itadori.Shock:Clone()
					v28.CFrame = v19.CFrame * CFrame.Angles(1.5707963267948966, 0, 0) + v19.CFrame.LookVector * ((p17 and 14 or 7) * v27)
					v28.Parent = workspace.Effects
					v_u_3:Create(v28, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v28, 0.15)
					task.wait(0.02)
				end
			end
		end,
		["Hold"] = function(p29, p30)
			-- upvalues: (ref) v_u_10, (ref) v_u_6
			if p29:FindFirstChild("HumanoidRootPart") then
				v_u_10:Flash(p29, Color3.fromRGB(255, 0, 0), 1)
				local v_u_31 = v_u_6.Choso.Concentrate:Clone()
				v_u_31.Parent = p29["Right Arm"].RightGripAttachment
				p30.Destroying:Connect(function()
					-- upvalues: (copy) v_u_31
					v_u_31:Destroy()
				end)
			end
		end,
		["Flash"] = function(p32)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v33 = p32:FindFirstChild("HumanoidRootPart")
			if v33 then
				local v34 = v_u_6.Choso.Flash:Clone()
				v_u_2:AddItem(v34, 0.4)
				v34.Parent = p32["Right Arm"].RightGripAttachment
				v34:Emit(15)
				v_u_3:Create(v34, TweenInfo.new(0.3), {
					["TimeScale"] = 0.4
				}):Play()
				v_u_10:PlaySound(v_u_7.Choso.PiercingBlood.Pressure, v33, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p35)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v36 = p35:FindFirstChild("HumanoidRootPart")
			if v36 then
				v_u_10:Flash(p35, Color3.new(1, 0, 0))
				v_u_10:PlaySound(v_u_7.Choso.PiercingBlood.Hit, v36, game.SoundService.Effect)
			end
		end
	}
	v_u_9.Effects:Connect(function(p38, ...)
		-- upvalues: (copy) v_u_37
		local v39 = v_u_37[p38]
		if v39 then
			v39(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("PiercingBloodService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11