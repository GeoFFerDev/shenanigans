-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v10 = require(v_u_6.Modules.SraikoVFX)
local v_u_11 = require(v_u_6.Knit.Trove)
local _ = v10.Emit
local _ = v10.Enabled
local v_u_12 = v10.EmitMesh
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v17 = v_u_1.CreateController({
	["Name"] = "AbsoluteController"
})
local function v_u_28(p18, p19, p20, p21)
	-- upvalues: (copy) v_u_3
	local v22 = p18:Clone()
	if p20 and p19 then
		local v23 = Instance.new("Weld")
		v23.Part0 = v22
		v23.Part1 = p19
		v23.Parent = v22
	else
		v22.CFrame = p19
	end
	v22.Parent = workspace.Effects
	local v24 = next
	local v25, v26 = v22:GetDescendants()
	for _, v27 in v24, v25, v26 do
		if v27:IsA("ParticleEmitter") then
			v27:Emit(v27:GetAttribute("EmitCount"))
		end
	end
	v_u_3:AddItem(v22, p21 or 5)
end
local function v_u_39(p29, p30, p31, p32, p33)
	-- upvalues: (copy) v_u_3
	local v34 = next
	local v35, v36 = p29:GetDescendants()
	for _, v37 in v34, v35, v36 do
		if v37:IsA("ParticleEmitter") then
			v37.Enabled = p30
		end
	end
	if p32 and p31 then
		local v38 = Instance.new("Weld")
		v38.Part0 = p29
		v38.Part1 = p31
		v38.Parent = p29
	end
	if p33 then
		v_u_3:AddItem(p29, p33)
	end
end
function v17.KnitStart(_)
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (ref) v_u_16, (copy) v_u_8, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_14, (copy) v_u_39, (copy) v_u_28, (copy) v_u_6, (copy) v_u_12, (copy) v_u_11, (ref) v_u_15
	local v_u_40 = Random.new()
	local v_u_428 = {
		["Hit"] = function(p41, p42)
			-- upvalues: (ref) v_u_16, (ref) v_u_8
			local v43 = p41:FindFirstChild("HumanoidRootPart")
			if v43 then
				v_u_16:Flash(p41, Color3.new(1, 1, 1))
				v_u_16:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. p42), v43, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p44, p45)
			-- upvalues: (ref) v_u_16, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v46 = p44:FindFirstChild("HumanoidRootPart")
			if v46 then
				local v47 = p45:FindFirstChild("HumanoidRootPart")
				if v47 then
					v_u_16:Flash(p45, Color3.new(1, 1, 1))
					v_u_16:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit3"), v47, game.SoundService.Effect)
					local v48 = v_u_7.ChaseHit:Clone()
					local v49 = CFrame.new
					local v50 = v47.Position
					local v51 = v46.Position.X
					local v52 = v47.Position.Y
					local v53 = v46.Position.Z
					v48.CFrame = v49(v50, (Vector3.new(v51, v52, v53))) * CFrame.Angles(0, 3.141592653589793, 0)
					v48.Parent = workspace.Effects
					v48.Ring:Emit(7)
					v48.Sparks:Emit(12)
					v_u_3:AddItem(v48, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p54)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_16, (ref) v_u_8
			local v55 = p54.HumanoidRootPart
			if v55 then
				local v56 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v56.CFrame = v55.CFrame * CFrame.new(0, 1, -4)
				v56.Size = Vector3.new(0, 0, 2)
				v56.Parent = workspace.Effects
				v_u_4:Create(v56, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v56, 0.3)
				v_u_16:PlaySound(v_u_8.Misc.Chase, v55, game.SoundService.Effect)
				v_u_16:DustTrail(p54, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p57)
			-- upvalues: (ref) v_u_16, (ref) v_u_8
			local v58 = p57:FindFirstChild("HumanoidRootPart")
			if v58 then
				v_u_16:PlaySound(v_u_8.Misc.Swing.Fist, v58, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p59, p60, p61)
			-- upvalues: (ref) v_u_16
			if p61 == "Down" then
				v_u_16:ArmFlash(p59["Right Leg"], Color3.fromRGB(225, 10, 75), 0.4)
				return
			elseif p60 == 1 or (p60 == 2 or p60 == 4) then
				v_u_16:ArmFlash(p59["Right Arm"], Color3.fromRGB(225, 10, 75), 0.3)
			else
				v_u_16:ArmFlash(p59["Left Arm"], Color3.fromRGB(225, 10, 75), 0.3)
			end
		end,
		["Swing3"] = function(p62, p63, _)
			-- upvalues: (ref) v_u_16, (ref) v_u_8
			local v64 = p62:FindFirstChild("HumanoidRootPart")
			if v64 then
				v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.M1Swing["Swing" .. p63], v64, game.SoundService.Effect)
			end
		end,
		["Hit2"] = function(p65, p66)
			-- upvalues: (ref) v_u_16, (ref) v_u_8
			local v67 = p65:FindFirstChild("HumanoidRootPart")
			if v67 then
				v_u_16:Flash(p65, Color3.new(1, 1, 1))
				v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.M1:FindFirstChild("Hit" .. p66), v67, game.SoundService.Effect)
			end
		end,
		["Sparks"] = function(p68)
			-- upvalues: (ref) v_u_7, (ref) v_u_16, (ref) v_u_8, (ref) v_u_4
			local v69 = v_u_7.Mechamaru.Detonate:Clone()
			v69.PointLight.Brightness = 0
			v69.PointLight.Range = 0
			v69.Parent = p68
			v_u_16:PlaySound(v_u_8.Mechamaru.Offload.Sparks, v69, game.SoundService.Effect)
			task.wait(0.2)
			v_u_4:Create(v69.PointLight, TweenInfo.new(0.8), {
				["Brightness"] = 5,
				["Range"] = 20
			}):Play()
			task.wait(0.8)
			v69:Destroy()
		end,
		["Explosion"] = function(p70, p71)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_16, (ref) v_u_8, (ref) v_u_4
			local v72
			if p71 then
				local v73 = v_u_7.Mechamaru.DetonateUltScaled:Clone()
				v73.Detonate.WorldPosition = p70
				v73.Parent = workspace.Effects
				v72 = v73.Detonate
			else
				v72 = v_u_7.Mechamaru.Detonate:Clone()
				v72.Lightning:Destroy()
				v72.PointLight:Destroy()
				v72.WorldPosition = p70
				v72.Parent = workspace.Effects
			end
			for _, v74 in v72:GetDescendants() do
				if v74:IsA("ParticleEmitter") then
					v74:Emit(v74:GetAttribute("EmitCount"))
				end
			end
			v_u_3:AddItem(v72, 3)
			v_u_16:PlaySound(v_u_8.Mechamaru.Offload.Explode, v72, game.SoundService.Effect)
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - p70).Magnitude > 150 then
					return
				end
				Random.new()
				TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				local v75 = p71 and 2 or 1
				for _ = 1, p71 and 35 or 10 do
					local v_u_76 = v_u_7.Hiromi.GavelShard:Clone()
					v_u_76.Position = p70
					v_u_76.Size = v_u_76.Size * (math.random(150, 220) / 100 * v75)
					local v77 = math.random(-80, 80)
					local v78 = math.random(30, 60)
					local v79 = math.random
					v_u_76.Velocity = Vector3.new(v77, v78, v79(-80, 80)) * v75
					local v80 = math.random(-50, 50)
					local v81 = math.random(-50, 50)
					local v82 = math.random
					v_u_76.RotVelocity = Vector3.new(v80, v81, v82(-50, 50))
					v_u_76.Color = p71 and Color3.fromRGB(138, 153, 179) or v_u_76.Color
					v_u_76.Parent = workspace.Effects
					v_u_3:AddItem(v_u_76, 2)
					task.delay(1, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_76
						v_u_4:Create(v_u_76, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
			end
		end,
		["RedLights"] = function(p83)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_5, (ref) v_u_16, (ref) v_u_8, (ref) v_u_3, (copy) v_u_40, (ref) v_u_9
			local v84 = p83.HumanoidRootPart
			if not v84 then
				return
			end
			local v85 = v_u_7.Mechamaru.RedLights:Clone()
			local v86 = v85.PointLight
			local v_u_87 = v85.Attachment
			local v88 = v_u_87.LightBurst
			local v89 = v_u_87.Ring
			v85.Parent = workspace.Effects
			local v90 = v85.Size
			local v91 = v86.Range
			v85.Size = Vector3.new(0, 1, 0)
			v86.Range = 0
			local v92 = TweenInfo.new(5)
			v_u_4:Create(v85, v92, {
				["Size"] = v90
			}):Play()
			v_u_4:Create(v86, v92, {
				["Range"] = v91
			}):Play()
			local v93 = v_u_5:DistanceFromCharacter(v84.Position) < 40
			if v93 then
				v_u_4:Create(game.Lighting, v92, {
					["ExposureCompensation"] = -3
				}):Play()
			end
			local v94
			if v93 then
				v94 = v84.AncestryChanged:Connect(function(_)
					-- upvalues: (ref) v_u_4
					v_u_4:Create(game.Lighting, TweenInfo.new(0.1), {
						["ExposureCompensation"] = 0
					}):Play()
				end)
			else
				v94 = nil
			end
			local v95 = tick()
			local v96 = 2
			local v97 = 0
			local v98 = 0
			while v84.Parent do
				if 1 / v96 <= v97 then
					local v99 = 0
					local v100 = nil
					while v84.Parent and v99 < 20 do
						local v101 = workspace
						local v102 = v85.Size.X / 2
						local v103 = v85.Position
						local v104 = math.random(-v102, v102)
						local v105 = math.random
						local v106 = -v102
						v100 = v101:Raycast(v103 + Vector3.new(v104, 0, v105(v106, v102)), Vector3.new(-0, -20, -0), _G.MapParams)
						v99 = v99 + 1
						if v100 then
							break
						end
					end
					if not (v84.Parent and v100) then
						break
					end
					v_u_87.WorldPosition = v100.Position
					v88:Emit(1)
					v89:Emit(5)
					if _G.Settings.DesPHY then
						if v98 < 10 then
							v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.RedLightRock, v_u_87, game.SoundService.Effect)
						end
						if (workspace.CurrentCamera.CFrame.Position - v100.Position).Magnitude > 150 then
							break
						end
						Random.new()
						TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
						for _ = 1, 4 do
							local v_u_107 = v_u_7.Hiromi.GavelShard:Clone()
							v_u_107.Position = v100.Position
							v_u_107.Size = v_u_107.Size * (math.random(12, 15) / 10)
							local v108 = math.random(-20, 20)
							local v109 = math.random(10, 20)
							local v110 = math.random
							v_u_107.Velocity = Vector3.new(v108, v109, v110(-20, 20))
							local v111 = math.random(-50, 50)
							local v112 = math.random(-50, 50)
							local v113 = math.random
							v_u_107.RotVelocity = Vector3.new(v111, v112, v113(-50, 50))
							v_u_107.Color = v100.Instance.Color
							v_u_107.Material = v100.Instance.Material
							v_u_107.Parent = workspace.Effects
							v_u_3:AddItem(v_u_107, 2)
							task.delay(1, function()
								-- upvalues: (ref) v_u_4, (copy) v_u_107
								v_u_4:Create(v_u_107, TweenInfo.new(1), {
									["Size"] = Vector3.new(0, 0, 0)
								}):Play()
							end)
						end
					end
					local v114 = v96 + 1
					v96 = math.min(v114, 4)
					v97 = 0
					v88.Size = NumberSequence.new(v88.Size.Keypoints[1].Value + 5)
					if v98 < 10 then
						task.delay(v_u_40:NextNumber(0, 0.3), function()
							-- upvalues: (ref) v_u_16, (ref) v_u_8, (copy) v_u_87, (ref) v_u_40
							v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.RedLight, v_u_87, game.SoundService.Effect).PlaybackSpeed = v_u_40:NextNumber(0.8, 1.2)
						end)
					end
					if v_u_5:DistanceFromCharacter(v85.Position) < 40 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
					v98 = v98 + 1
				end
				if not v84.Parent then
					break
				end
				local v115 = v84.Position
				local v116 = workspace:Raycast(v115, Vector3.new(-0, -50, -0), _G.MapParams)
				if v116 then
					v85.Position = v116.Position + Vector3.new(0, 0.2, 0)
				end
				v97 = v97 + task.wait()
				if tick() - v95 >= 5 then
					break
				end
			end
			v88.TimeScale = 2
			task.wait(1)
			if v93 then
				v94:Disconnect()
				v_u_4:Create(game.Lighting, TweenInfo.new(0.1), {
					["ExposureCompensation"] = 0
				}):Play()
			end
			task.wait(0.2)
			v85:Destroy()
		end,
		["RootCamera"] = function(p117)
			-- upvalues: (ref) v_u_5
			local v118 = v_u_5.Character
			if v118 then
				workspace.CurrentCamera.CameraSubject = ({ v118.HumanoidRootPart, v118.Head, v118.Humanoid })[p117]
			end
		end,
		["LightUpEyes"] = function(p119)
			-- upvalues: (ref) v_u_5, (ref) v_u_9
			local v120 = p119:FindFirstChild("MechamaruHead")
			if v120 then
				for _, v121 in v120.MHead:GetChildren() do
					if v121:IsA("Attachment") then
						for _, v122 in v121:GetChildren() do
							v122:Emit(v122:GetAttribute("EmiteCount"))
							if v122.Name == "ConstantGlow" or v122.Name == "Out" then
								v122.Enabled = true
							end
						end
					end
				end
				local v123
				if p119 == v_u_5.Character then
					v123 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
				else
					v123 = nil
				end
				task.wait(2)
				if v123 then
					v123:StartFadeOut(0.5)
				end
				for _, v124 in v120.MHead:GetChildren() do
					if v124:IsA("Attachment") then
						for _, v125 in v124:GetChildren() do
							if v125.Name == "Out" then
								v125.Enabled = false
							end
						end
					end
				end
			end
		end,
		["ComeOut"] = function(p126)
			-- upvalues: (ref) v_u_16, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.FloorClimb, p126.Parent.HumanoidRootPart, game.SoundService.Effect)
			local v127 = workspace:Raycast(p126.Position, Vector3.new(0, -20, 0), _G.MapParams)
			if v127 then
				local v128 = v_u_7.Mechamaru.ArmDust:Clone()
				v128.Position = v127.Position
				v128.Parent = workspace.Effects
				v_u_3:AddItem(v128, 1)
				for _, v129 in v128:GetDescendants() do
					if v129:IsA("ParticleEmitter") then
						if v129.Name == "Smoke2" then
							v129.Color = ColorSequence.new(v127.Instance.Color)
						end
						v129:Emit(v129:GetAttribute("EmitCount"))
					end
				end
			end
			if (workspace.CurrentCamera.CFrame.Position - p126.Position).Magnitude <= 50 or v_u_5.Character and p126:IsDescendantOf(v_u_5.Character) then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["ComeOut2"] = function(p130)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v131 = p130["Left Arm"]
			local v132 = workspace:Raycast(v131.Position, Vector3.new(0, -20, 0), _G.MapParams)
			if v132 then
				local v133 = v_u_7.Mechamaru.ArmDust2:Clone()
				v133.WorldPosition = v132.Position
				v133.Parent = workspace.Effects
				v_u_3:AddItem(v133, 1)
				for _, v134 in v133:GetDescendants() do
					if v134:IsA("ParticleEmitter") then
						if v134.Name == "Smoke2" then
							v134.Color = ColorSequence.new(v132.Instance.Color)
						end
						v134:Emit(v134:GetAttribute("EmitCount"))
					end
				end
			end
			if (workspace.CurrentCamera.CFrame.Position - v131.Position).Magnitude <= 50 or v_u_5.Character and v131:IsDescendantOf(v_u_5.Character) then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["ComeOut3"] = function(p135)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v136 = p135["Right Arm"].RightGripAttachment
			local v137 = workspace:Raycast(v136.WorldPosition, Vector3.new(0, -20, 0), _G.MapParams)
			if v137 then
				local v138 = v_u_7.Mechamaru.ArmDust2:Clone()
				v138.WorldPosition = v137.Position
				v138.Parent = workspace.Effects
				v_u_3:AddItem(v138, 1)
				for _, v139 in v138:GetDescendants() do
					if v139:IsA("ParticleEmitter") then
						if v139.Name == "Smoke2" then
							v139.Color = ColorSequence.new(v137.Instance.Color)
						end
						v139:Emit(v139:GetAttribute("EmitCount"))
					end
				end
			end
			if (workspace.CurrentCamera.CFrame.Position - v136.Position).Magnitude <= 50 or v_u_5.Character and v136:IsDescendantOf(v_u_5.Character) then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["TorsoComeOut"] = function(p140)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v141 = p140.HumanoidRootPart
			local v142 = workspace:Raycast(v141.Position, Vector3.new(0, -20, 0), _G.MapParams)
			if v142 then
				local v143 = v_u_7.Mechamaru.ArmDust:Clone()
				local v144 = Instance.new("Model", workspace.Effects)
				v143.Parent = v144
				v144:ScaleTo(1.5)
				v143.Position = v142.Position
				v_u_3:AddItem(v144, 1)
				for _, v145 in v143:GetDescendants() do
					if v145:IsA("ParticleEmitter") then
						if v145.Name == "Smoke2" then
							v145.Color = ColorSequence.new(v142.Instance.Color)
						end
						v145:Emit(v145:GetAttribute("EmitCount"))
					end
				end
			end
			if (workspace.CurrentCamera.CFrame.Position - v141.Position).Magnitude <= 50 or v_u_5.Character and v141:IsDescendantOf(v_u_5.Character) then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["MechaJump"] = function(p146)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v147 = p146.HumanoidRootPart
			local v148 = workspace:Raycast(v147.Position, Vector3.new(0, -30, 0), _G.MapParams)
			if v148 then
				local v149 = v_u_7.Mechamaru.Dust:Clone()
				local v150 = Instance.new("Model", workspace.Effects)
				v149.Parent = v150
				v150:ScaleTo(1.5)
				v149.Position = v148.Position
				v_u_3:AddItem(v150, 1)
				for _, v151 in v149:GetDescendants() do
					if v151:IsA("ParticleEmitter") then
						if v151.Name == "Smoke2" then
							v151.Color = ColorSequence.new(v148.Instance.Color)
						end
						v151:Emit(v151:GetAttribute("EmitCount"))
					end
				end
			end
			if (workspace.CurrentCamera.CFrame.Position - v147.Position).Magnitude <= 50 or v_u_5.Character and v147:IsDescendantOf(v_u_5.Character) then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["MechaLand"] = function(p152)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v153 = p152.HumanoidRootPart
			local v154 = workspace:Raycast(v153.Position, Vector3.new(0, -30, 0), _G.MapParams)
			if v154 then
				local v155 = v_u_7.Mechamaru.AbsoluteLand:Clone()
				v155.Parent = workspace.Effects
				v155.WorldPosition = v154.Position
				v_u_3:AddItem(v155, 2)
				for _, v156 in v155:GetDescendants() do
					v156:Emit(v156:GetAttribute("EmitCount"))
				end
			end
			if (workspace.CurrentCamera.CFrame.Position - v153.Position).Magnitude <= 50 or v_u_5.Character and v153:IsDescendantOf(v_u_5.Character) then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
			end
		end,
		["UltHUD"] = function()
			-- upvalues: (ref) v_u_7, (ref) v_u_5, (ref) v_u_4, (ref) v_u_2, (ref) v_u_14, (ref) v_u_16, (ref) v_u_8, (copy) v_u_40
			local v_u_157 = v_u_7.Mechamaru.MechamaruHUD:Clone()
			v_u_157.Parent = v_u_5.PlayerGui
			local v_u_158 = v_u_157.ScreenNoise
			local v_u_159 = v_u_157.Configuration.Video
			local v_u_160 = v_u_157.StaggerMeter
			local v161 = v_u_157.UltBar
			local v_u_162 = v161.FillBar
			local v_u_163 = v161.TextBar.TextLabel
			local v_u_164 = v_u_162.Size.Y.Offset
			local v_u_165 = v_u_162.FillBar.Size.X.Offset
			v_u_158.ImageTransparency = 0.5
			local v_u_166 = true
			local v_u_167 = true
			local function v_u_178(p168, p169, p170)
				local v171 = string.format("%02d%02d%02d", p168, p169, p170)
				local v172 = ""
				local v173 = false
				local v174 = v172
				local v175 = v173
				for v176 = 1, #v171 do
					local v177 = v171:sub(v176, v176)
					if v177 == "0" then
						if v175 then
							v172 = v174 .. v177
							v174 = v172
						else
							v172 = v174 .. "<font color=\"rgb(77,72,93)\">" .. v177 .. "</font>"
							v174 = v172
						end
					else
						v173 = true
						if v173 then
							v172 = v174 .. v177
							v174 = v172
							v175 = v173
						else
							v172 = v174 .. "<font color=\"rgb(77,72,93)\">" .. v177 .. "</font>"
							v174 = v172
							v175 = v173
						end
					end
					if v176 == 2 or v176 == 4 then
						if v175 then
							v172 = v174 .. "."
							v174 = v172
						else
							v172 = v174 .. "<font color=\"rgb(77,72,93)\">.</font>"
							v174 = v172
						end
					end
				end
				return v174
			end
			local v179 = v161.Size
			v161.Size = UDim2.fromOffset(0, v179.Y.Offset)
			v_u_4:Create(v161, TweenInfo.new(0.3), {
				["Size"] = v179
			}):Play()
			local v_u_180 = v_u_163.TextColor3
			local v_u_181 = v_u_162.FillBar.ImageColor3
			v_u_163.TextColor3 = Color3.fromRGB(255, 100, 100)
			v_u_162.FillBar.ImageColor3 = Color3.new(1, 0, 0)
			task.spawn(function()
				-- upvalues: (ref) v_u_5, (copy) v_u_162, (copy) v_u_165, (copy) v_u_164, (copy) v_u_163, (copy) v_u_178, (ref) v_u_166, (ref) v_u_4, (copy) v_u_180, (copy) v_u_181
				local v182 = tick()
				repeat
					task.wait()
					local v183 = (tick() - v182) / 1.5
					local v184 = math.clamp(v183, 0, 1) * v_u_5:GetAttribute("Ultimate") / 100
					local v185 = math.clamp(v184, 0, 1)
					v_u_162.Size = UDim2.fromOffset(v185 * v_u_165, v_u_164)
					local v186 = v185 * 18
					local v187 = math.floor(v186)
					v_u_163.Text = v_u_178(v187, string.format("%.2f", v186 - v187):sub(-2), (string.format("%.4f", v186):sub(-2)))
				until tick() - v182 >= 1.5
				v_u_166 = false
				v_u_4:Create(v_u_163, TweenInfo.new(0.3, Enum.EasingStyle.Bounce, Enum.EasingDirection.Out), {
					["TextColor3"] = Color3.new(0.06, 0.65, 0.06)
				}):Play()
				v_u_4:Create(v_u_162.FillBar, TweenInfo.new(0.3, Enum.EasingStyle.Bounce, Enum.EasingDirection.Out), {
					["ImageColor3"] = Color3.new(0.06, 0.65, 0.06)
				}):Play()
				task.wait(0.5)
				v_u_163.TextColor3 = v_u_180
				v_u_162.FillBar.ImageColor3 = v_u_181
			end)
			task.spawn(function()
				-- upvalues: (ref) v_u_2, (ref) v_u_14, (copy) v_u_160, (copy) v_u_157, (copy) v_u_158, (ref) v_u_166, (ref) v_u_5, (copy) v_u_162, (copy) v_u_165, (copy) v_u_164, (copy) v_u_163, (copy) v_u_178, (ref) v_u_167, (ref) v_u_4
				local v188 = v_u_2.JumpRequest:Connect(function()
					-- upvalues: (ref) v_u_14
					v_u_14.JumpRequest:Fire()
				end)
				local v189 = v_u_160.Counter.TextColor3
				while v_u_157.Parent do
					task.wait()
					if v_u_158.ImageTransparency < 1 then
						local v190 = v_u_158
						v190.Rotation = v190.Rotation + 180
						v_u_158.Position = UDim2.new(0.5, math.random(-100, 100), 0.5, math.random(-100, 100))
					end
					if not v_u_166 then
						local v191 = v_u_5:GetAttribute("Ultimate") / 100
						local v192 = math.clamp(v191, 0, 1)
						v_u_162.Size = UDim2.fromOffset(v192 * v_u_165, v_u_164)
						local v193 = v192 * 18
						local v194 = math.floor(v193)
						local v195 = (v193 - v194) * 12
						v_u_163.Text = v_u_178(v194, math.floor(v195), (string.format("%.4f", v193):sub(-2)))
					end
					if not v_u_167 then
						if v_u_5.Character.Info:FindFirstChild("MechamaruScreenNoise") then
							if v_u_158.ImageTransparency ~= 0.8 then
								v_u_4:Create(v_u_158, TweenInfo.new(0.2), {
									["ImageTransparency"] = 0.8
								}):Play()
								v_u_4:Create(v_u_157.Crosses, TweenInfo.new(0.2), {
									["ImageTransparency"] = 0.4
								}):Play()
							end
						elseif v_u_158.ImageTransparency ~= 1 then
							v_u_4:Create(v_u_158, TweenInfo.new(0.2), {
								["ImageTransparency"] = 1
							}):Play()
							v_u_4:Create(v_u_157.Crosses, TweenInfo.new(0.2), {
								["ImageTransparency"] = 1
							}):Play()
						end
						local v196 = (v_u_5.Character:GetAttribute("Stagger") or 0) / 25 * 100
						local v197 = math.clamp(v196, 0, 100)
						local v198 = math.round(v197)
						v_u_160.Counter.TextColor3 = v189:Lerp(Color3.fromRGB(255, 100, 100), v198 / 100)
						v_u_160.Counter.Text = ("%*%%"):format(v198)
						v_u_160.GroupTransparency = math.map(v_u_158.ImageTransparency, 1, 0.8, 1, 0)
					end
				end
				v188:Disconnect()
			end)
			local v_u_199 = 1
			local v_u_200 = {
				"rbxassetid://122208693881451",
				"rbxassetid://81482311156770",
				"rbxassetid://87369203514322",
				"rbxassetid://94841460244177",
				"rbxassetid://103828796906918",
				"rbxassetid://133129637180980"
			}
			local v_u_201 = {}
			for v_u_202 = 1, 9 do
				local v203 = v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.VideoAppear, workspace, game.SoundService.Effect)
				v203.PlaybackSpeed = v_u_40:NextNumber(0.8, 1.2)
				v203.Volume = v_u_40:NextNumber(0.4, 0.7)
				local v_u_204 = v_u_40:NextInteger(2, 3)
				for v_u_205 = 1, v_u_204 do
					task.spawn(function()
						-- upvalues: (ref) v_u_199, (copy) v_u_200, (copy) v_u_159, (copy) v_u_201, (copy) v_u_202, (ref) v_u_40, (copy) v_u_205, (copy) v_u_204, (copy) v_u_157, (ref) v_u_4
						local v206 = v_u_199 % #v_u_200
						local v207 = v206 == 0 and #v_u_200 or v206
						v_u_199 = v_u_199 + 1
						local v208 = v_u_159:Clone()
						local v209 = v_u_201
						table.insert(v209, v208)
						v208.ImageLabel.ImageContent = Content.fromUri(v_u_200[v207])
						v208.ImageLabel.White.Transparency = 0
						local v210 = v208.Size
						v208.Size = UDim2.fromOffset(v210.X.Offset, 0)
						v208.Position = UDim2.fromScale(0.11 * (v_u_202 - 0.5) + v_u_40:NextNumber(-0.1, 0.1), (v_u_205 - 0.5) / v_u_204 + v_u_40:NextNumber(-0.1, 0.1))
						local v211 = v_u_40:NextNumber(0.7, 1)
						v208.Parent = v_u_157
						v_u_4:Create(v208, TweenInfo.new(0.2), {
							["Size"] = UDim2.fromOffset(v210.X.Offset * v211, v210.Y.Offset * v211)
						}):Play()
						task.wait(0.2)
						v_u_4:Create(v208.ImageLabel.White, TweenInfo.new(0.3, Enum.EasingStyle.Bounce, Enum.EasingDirection.Out), {
							["BackgroundTransparency"] = 1
						}):Play()
					end)
				end
				task.wait(v_u_40:NextNumber(0.05, 0.15))
			end
			task.wait(0.5)
			v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.VideoEnd, workspace, game.SoundService.Effect)
			for v_u_212, v_u_213 in v_u_201 do
				task.spawn(function()
					-- upvalues: (ref) v_u_4, (copy) v_u_213, (copy) v_u_212
					v_u_4:Create(v_u_213.Overlay, TweenInfo.new(0.3, Enum.EasingStyle.Bounce, Enum.EasingDirection.Out), {
						["ImageColor3"] = Color3.new(0.06, 0.65, 0.06)
					}):Play()
					task.wait(0.2)
					v_u_4:Create(v_u_213.ImageLabel.White, TweenInfo.new(0.3, Enum.EasingStyle.Bounce, Enum.EasingDirection.Out), {
						["BackgroundTransparency"] = 0
					}):Play()
					task.wait(0.3 + v_u_212 / 30)
					v_u_4:Create(v_u_213, TweenInfo.new(0.1), {
						["Size"] = UDim2.fromOffset(v_u_213.Size.X.Offset, 0)
					}):Play()
					task.wait(0.1)
					v_u_213:Destroy()
				end)
			end
			task.wait(0.3)
			v_u_4:Create(v_u_158, TweenInfo.new(0.5), {
				["ImageTransparency"] = 0.8
			}):Play()
			task.wait(1)
			v_u_4:Create(v_u_158, TweenInfo.new(0.5), {
				["ImageTransparency"] = 1
			}):Play()
			v_u_4:Create(v_u_157.Crosses, TweenInfo.new(0.5), {
				["ImageTransparency"] = 1
			}):Play()
			task.wait(0.5)
			v_u_167 = false
		end,
		["TorsoParticle"] = function(p214)
			-- upvalues: (ref) v_u_7, (ref) v_u_39
			local v215 = p214:FindFirstChild("MechamaruTorso")
			if v215 then
				v215 = v215:FindFirstChild("MTorso")
			end
			if v215 then
				local v216 = v_u_7.Mechamaru.DeathVFX.Torso:Clone()
				v216.Parent = v215
				task.delay(2.9, v_u_39, v216, false, nil, false, 5)
			end
		end,
		["SmallWind"] = function(p217)
			-- upvalues: (ref) v_u_28, (ref) v_u_7
			local v218 = p217:FindFirstChild("MechamaruTorso")
			if v218 then
				v218 = v218:FindFirstChild("MTorso")
			end
			if v218 then
				v_u_28(v_u_7.Mechamaru.DeathVFX.SmallWind1, CFrame.new(v218.Position) + Vector3.new(0, -2, 0), false, 5)
			end
		end,
		["SmallWind2"] = function(p219)
			-- upvalues: (ref) v_u_28, (ref) v_u_7
			local v220 = p219:FindFirstChild("MechamaruTorso")
			if v220 then
				v220 = v220:FindFirstChild("MTorso")
			end
			if v220 then
				v_u_28(v_u_7.Mechamaru.DeathVFX.SmallWind2, CFrame.new(v220.Position) + Vector3.new(0, -2, 0), false, 5)
			end
		end,
		["DustLand"] = function(p221)
			-- upvalues: (ref) v_u_28, (ref) v_u_7
			local v222 = p221:FindFirstChild("MechamaruTorso")
			if v222 then
				v222 = v222:FindFirstChild("MTorso")
			end
			if v222 then
				v_u_28(v_u_7.Mechamaru.DeathVFX.DustLand, CFrame.new(v222.Position) + Vector3.new(0, -2, 0), false, 5)
			end
		end,
		["DropkickLeap"] = function(p223, p224)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v225 = p223:FindFirstChild("HumanoidRootPart")
			if v225 then
				local v226 = Instance.new("Model")
				local v227 = v_u_7.Gojo.HardHit:Clone()
				v227.CFrame = v225.CFrame * CFrame.Angles(1.9198621771937625, 0, 0)
				v227.Ring.RotSpeed = NumberRange.new(300, 600)
				v227.Ring.Speed = NumberRange.new(0.1, 20)
				v227.Parent = v226
				v226:ScaleTo(5)
				v226.Parent = workspace.Effects
				v227.Ring:Emit(15)
				v_u_3:AddItem(v226, 0.5)
				p224.Position = v225.Position + Vector3.new(0, 25, 0)
			end
		end,
		["Dropkick"] = function(p228)
			-- upvalues: (ref) v_u_16, (ref) v_u_8
			local v229 = p228:FindFirstChild("HumanoidRootPart")
			if v229 then
				v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.Dropkick, v229, game.SoundService.Effect)
			end
		end,
		["DropkickSpark"] = function(p230)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v231 = p230:FindFirstChild("HumanoidRootPart")
			if v231 then
				local v232 = v_u_7.Mechamaru.DropkickSpark:Clone()
				v232.Parent = p230["Left Leg"]
				v_u_3:AddItem(v232, 3)
				for _, v_u_233 in v232:GetChildren() do
					task.delay(v_u_233:GetAttribute("EmitDelay"), function()
						-- upvalues: (copy) v_u_233
						v_u_233:Emit(v_u_233:GetAttribute("EmitCount"))
					end)
				end
				task.wait(0.4)
				for _, v234 in v232:GetChildren() do
					v234:Clear()
				end
				local v235 = Instance.new("Model")
				local v236 = v_u_7.Gojo.HardHit:Clone()
				v236.CFrame = v231.CFrame * CFrame.Angles(1.9198621771937625, 0, 0)
				v236.Ring.RotSpeed = NumberRange.new(300, 600)
				v236.Ring.Speed = NumberRange.new(0.1, 20)
				v236.Parent = v235
				v235:ScaleTo(3)
				v235.Parent = workspace.Effects
				v236.Ring:Emit(15)
				v_u_3:AddItem(v235, 0.5)
			end
		end,
		["DropkickHold"] = function(p237, p238)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v239 = p237:FindFirstChild("HumanoidRootPart")
			if v239 then
				while p238.Parent and p237.Parent do
					local v240 = Instance.new("Model")
					local v241 = v_u_7.Gojo.HardHit:Clone()
					v241.CFrame = v239.CFrame * CFrame.Angles(1.9198621771937625, 0, 0)
					v241.Position = v241.Position + p238.Velocity.Unit * 30
					v241.Ring.RotSpeed = NumberRange.new(300, 600)
					v241.Ring.Speed = NumberRange.new(0.1, 20)
					v241.Parent = v240
					v240:ScaleTo(3)
					v240.Parent = workspace.Effects
					v241.Ring:Emit(8)
					v_u_3:AddItem(v240, 0.5)
					task.wait(0.2)
				end
			end
		end,
		["DropkickLand"] = function(p242)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_16, (ref) v_u_8, (ref) v_u_9
			local v243 = Instance.new("Model")
			local v244 = v_u_7.Itadori.CrushingBlow:Clone()
			v244.PointLight:Destroy()
			v244.Beam:Destroy()
			v_u_7.Misc.Items.TNTExplosion.Effect:Clone().Parent = v244
			v244.Parent = v243
			v243:ScaleTo(5)
			v244.CFrame = p242 * CFrame.Angles(1.5707963267948966, 0, 0)
			v243.Parent = workspace.Effects
			v244.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 1, 1))
			v244.Floor.Ring:Emit(10)
			v244.Floor.Wind2:Emit(8)
			v244.Effect:Emit(120)
			v_u_3:AddItem(v243, 1.5)
			v_u_16:PlaySound(v_u_8.Yuta.VeilstepHit, v244, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p242.Position).Magnitude <= 100 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["MechaHoldJump"] = function(p245)
			-- upvalues: (ref) v_u_5, (ref) v_u_7, (ref) v_u_3, (ref) v_u_9
			local v246 = p245.HumanoidRootPart
			if v246 then
				if p245 == v_u_5.Character then
					v246.Velocity = v246.Velocity + Vector3.new(0, 120, 0)
				end
				local v247 = workspace:Raycast(v246.Position, Vector3.new(0, -30, 0), _G.MapParams)
				if v247 then
					local v248 = v_u_7.Mechamaru.Dust:Clone()
					local v249 = v248.bigimpact
					v249.Impact15:Destroy()
					v249.Impact40:Destroy()
					v249.Flare234New:Destroy()
					v249.ParticleEmitterR1:Destroy()
					v249.ParticleEmitterR2:Destroy()
					v249.Spec1:Destroy()
					v249["Spinning Shard 2"]:Destroy()
					v249["claw slashes impact lines"]:Destroy()
					v249["claw slashes impact lines1"]:Destroy()
					v249["claw slashes impact lines2"]:Destroy()
					v249["claw slashes impact lines3"]:Destroy()
					v249.n2:Destroy()
					v249.n4:Destroy()
					v249.specs:Destroy()
					v249.specs1:Destroy()
					v249.specs2:Destroy()
					v249.specs3:Destroy()
					v249.specs4:Destroy()
					local v250 = Instance.new("Model", workspace.Effects)
					v248.Parent = v250
					v250:ScaleTo(1.5)
					v248.Position = v247.Position
					v_u_3:AddItem(v250, 1)
					for _, v251 in v248:GetDescendants() do
						if v251:IsA("ParticleEmitter") then
							if v251.Name == "Smoke2" then
								v251.Color = ColorSequence.new(v247.Instance.Color)
							end
							v251:Emit(v251:GetAttribute("EmitCount"))
						end
					end
				end
				if (workspace.CurrentCamera.CFrame.Position - v246.Position).Magnitude <= 50 or v_u_5.Character == p245 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Jump"] = function(p252)
			-- upvalues: (ref) v_u_16, (ref) v_u_8
			local v253 = p252:FindFirstChild("HumanoidRootPart")
			if v253 then
				v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.Jump, v253, game.SoundService.Effect)
			end
		end,
		["Eject"] = function(p254)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_6, (ref) v_u_16, (ref) v_u_8
			local v255 = p254:FindFirstChild("HumanoidRootPart")
			if v255 then
				if p254 == v_u_5.Character then
					v255.Velocity = v255.Velocity + Vector3.new(0, 120, 0)
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v256 = v_u_5.PlayerGui:FindFirstChild("MechamaruHUD")
					if v256 then
						v256:Destroy()
					end
				end
				local v257 = v_u_6.Utils.Mechamaru.BoosterL:Clone()
				v257.Parent = p254
				local v258 = v_u_6.Utils.Mechamaru.BoosterR:Clone()
				v258.Parent = p254
				local function v262(p259, p260)
					local v_u_261 = Instance.new("Motor6D")
					v_u_261.C0 = CFrame.new(0, 0.75, 0.625) * CFrame.Angles(0.7853981633974483, 0, 0)
					v_u_261.Part0 = p260
					v_u_261.Part1 = p259
					v_u_261.Name = p259.Name
					v_u_261.Parent = p260
					p259.Parent.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_261
						v_u_261:Destroy()
					end)
				end
				v_u_16:PlaySound(v_u_8.Mechamaru.BoostOn.Start, v255, game.SoundService.Effect)
				v262(v258["Arm BoostterrrrR"], p254["Right Arm"])
				v262(v257["Arm BoostterrrrL"], p254["Left Arm"])
				local v263 = v258["Arm BoostterrrrR"].Stage2
				local v264 = next
				local v265, v266 = v263:GetDescendants()
				for _, v267 in v264, v265, v266 do
					if v267:IsA("ParticleEmitter") then
						v267.Enabled = true
					end
				end
				local v268 = v257["Arm BoostterrrrL"].Stage2
				local v269 = next
				local v270, v271 = v268:GetDescendants()
				for _, v272 in v269, v270, v271 do
					if v272:IsA("ParticleEmitter") then
						v272.Enabled = true
					end
				end
				task.wait(0.15)
				local v273 = v258["Arm BoostterrrrR"].Stage2
				local v274 = next
				local v275, v276 = v273:GetDescendants()
				for _, v277 in v274, v275, v276 do
					if v277:IsA("ParticleEmitter") then
						v277.Enabled = false
					end
				end
				local v278 = v257["Arm BoostterrrrL"].Stage2
				local v279 = next
				local v280, v281 = v278:GetDescendants()
				for _, v282 in v279, v280, v281 do
					if v282:IsA("ParticleEmitter") then
						v282.Enabled = false
					end
				end
				task.wait(0.3)
				v257:Destroy()
				v258:Destroy()
			end
		end,
		["DrillShow"] = function(p_u_283)
			-- upvalues: (ref) v_u_16, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_28
			local v284 = p_u_283:FindFirstChild("Right Arm")
			local v285 = p_u_283:FindFirstChild("HumanoidRootPart")
			if v284 and v285 then
				v_u_16:PlaySound(v_u_8.Mechamaru.UltraSpin.Start, v285, game.SoundService.Effect)
				v_u_16:PlaySound(v_u_8.Mechamaru.UltraSpin.Dash, v285, game.SoundService.Effect)
				local v_u_286 = v_u_7.Mechamaru.Drill:Clone()
				v_u_286.Weld.Part0 = v284
				v_u_286.B.Weld.Part0 = v284
				v_u_286.F.Weld.Part0 = v284
				v_u_286.L.Weld.Part0 = v284
				v_u_286.R.Weld.Part0 = v284
				local v287 = next
				local v288, v289 = v_u_286:GetChildren()
				for _, v290 in v287, v288, v289 do
					if v290:IsA("BasePart") then
						v290.Transparency = 0
					end
				end
				local v291 = v_u_286.Metalbit.Sparks
				local v292 = next
				local v293, v294 = v291:GetDescendants()
				for _, v295 in v292, v293, v294 do
					if v295:IsA("ParticleEmitter") then
						v295.Enabled = true
					end
				end
				v_u_286.Parent = p_u_283
				v_u_3:AddItem(v_u_286, 2.2)
				task.delay(1.7, function()
					-- upvalues: (copy) v_u_286, (copy) p_u_283, (ref) v_u_4
					if v_u_286.Parent and p_u_283.Parent then
						local v296 = next
						local v297, v298 = v_u_286:GetChildren()
						for _, v299 in v296, v297, v298 do
							if v299:IsA("BasePart") then
								v_u_4:Create(v299, TweenInfo.new(0.3), {
									["Transparency"] = 1
								}):Play()
							end
						end
					end
				end)
				v_u_28(v_u_7.Mechamaru.EjectDeathVFX.CEEmit.Strike, v285.CFrame, false, 3)
			end
		end,
		["BoostRepeat2"] = function(p300)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v301 = p300:FindFirstChild("HumanoidRootPart")
			if not v301 then
				return
			end
			for _ = 1, 7 do
				if not (p300.Parent and v301.Parent) then
					break
				end
				v_u_12(v_u_7.Mechamaru.EjectDeathVFX.BoostRepeat.Mesh, v301.CFrame * CFrame.new(0, -3, -3) * v_u_7.Mechamaru.EjectDeathVFX.BoostRepeat.Mesh.Offset.Value)
				task.wait(0.1)
			end
		end,
		["DustLandEject"] = function(p302)
			-- upvalues: (ref) v_u_28, (ref) v_u_7, (ref) v_u_12
			local v303 = p302:FindFirstChild("HumanoidRootPart")
			if v303 then
				v_u_28(v_u_7.Mechamaru.EjectDeathVFX.DustLand.VFX, v303.CFrame, false, 3)
				v_u_12(v_u_7.Mechamaru.EjectDeathVFX.DustLand.Mesh, v303.CFrame * v_u_7.Mechamaru.EjectDeathVFX.DustLand.Mesh.Offset.Value)
			end
		end,
		["DustLand2Eject"] = function(p304)
			-- upvalues: (ref) v_u_7, (ref) v_u_39, (ref) v_u_28, (ref) v_u_12
			local v305 = p304:FindFirstChild("HumanoidRootPart")
			if v305 then
				local v306 = v_u_7.Mechamaru.EjectDeathVFX.BoostEnabled.Strike:Clone()
				v_u_39(v306, true, v305, true, 4)
				task.delay(0.85, v_u_39, v306, false)
				v_u_28(v_u_7.Mechamaru.EjectDeathVFX.DustLand2.VFX, v305.CFrame, false, 3)
				v_u_12(v_u_7.Mechamaru.EjectDeathVFX.DustLand2.Mesh, v305.CFrame * v_u_7.Mechamaru.EjectDeathVFX.DustLand2.Mesh.Offset.Value)
			end
		end,
		["DiveEject"] = function(p307)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_28, (ref) v_u_7, (ref) v_u_12, (ref) v_u_6
			local v308 = p307:FindFirstChild("HumanoidRootPart")
			if v308 then
				if p307 == v_u_5.Character then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v309 = v_u_5.PlayerGui:FindFirstChild("MechamaruHUD")
					if v309 then
						v309:Destroy()
					end
				end
				v_u_28(v_u_7.Mechamaru.EjectDeathVFX.BoostDash.Strike, v308.CFrame, false, 3)
				v_u_12(v_u_7.Mechamaru.EjectDeathVFX.BoostDash.Mesh, v308.CFrame * v_u_7.Mechamaru.EjectDeathVFX.BoostDash.Mesh.Offset.Value)
				local v310 = v_u_6.Utils.Mechamaru.BoosterL:Clone()
				v310.Parent = p307
				local v311 = v_u_6.Utils.Mechamaru.BoosterR:Clone()
				v311.Parent = p307
				local function v315(p312, p313)
					local v_u_314 = Instance.new("Motor6D")
					v_u_314.C0 = CFrame.new(0, 0.75, 0.625) * CFrame.Angles(0.7853981633974483, 0, 0)
					v_u_314.Part0 = p313
					v_u_314.Part1 = p312
					v_u_314.Name = p312.Name
					v_u_314.Parent = p313
					p312.Parent.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_314
						v_u_314:Destroy()
					end)
				end
				v315(v311["Arm BoostterrrrR"], p307["Right Arm"])
				v315(v310["Arm BoostterrrrL"], p307["Left Arm"])
				local v316 = v311["Arm BoostterrrrR"].Stage2
				local v317 = next
				local v318, v319 = v316:GetDescendants()
				for _, v320 in v317, v318, v319 do
					if v320:IsA("ParticleEmitter") then
						v320.Enabled = true
					end
				end
				local v321 = v310["Arm BoostterrrrL"].Stage2
				local v322 = next
				local v323, v324 = v321:GetDescendants()
				for _, v325 in v322, v323, v324 do
					if v325:IsA("ParticleEmitter") then
						v325.Enabled = true
					end
				end
				task.wait(2.883)
				local v326 = v311["Arm BoostterrrrR"].Stage2
				local v327 = next
				local v328, v329 = v326:GetDescendants()
				for _, v330 in v327, v328, v329 do
					if v330:IsA("ParticleEmitter") then
						v330.Enabled = false
					end
				end
				local v331 = v310["Arm BoostterrrrL"].Stage2
				local v332 = next
				local v333, v334 = v331:GetDescendants()
				for _, v335 in v332, v333, v334 do
					if v335:IsA("ParticleEmitter") then
						v335.Enabled = false
					end
				end
				task.wait(0.3)
				v310:Destroy()
				v311:Destroy()
			end
		end,
		["EjectDiveHit"] = function(p336, _, p337)
			-- upvalues: (ref) v_u_11, (ref) v_u_16, (ref) v_u_8, (ref) v_u_7
			if p336:GetAttribute("Moveset") == "Mechamaru" then
				local v338 = p336:FindFirstChild("HumanoidRootPart")
				local v339 = p336:FindFirstChild("Right Arm")
				if p337.Parent and (v338 and v339) then
					local v340 = v_u_11.new()
					v340:AttachToInstance(p337)
					v_u_16:PlaySound(v_u_8.Mechamaru.UltraSpin.Hit, v338, game.SoundService.Effect)
					local v341 = v340:Clone(v_u_7.Mechamaru.Drill)
					v341.Weld.Part0 = v339
					v341.B.Weld.Part0 = v339
					v341.F.Weld.Part0 = v339
					v341.L.Weld.Part0 = v339
					v341.R.Weld.Part0 = v339
					v341.Parent = p336
				end
			else
				return
			end
		end,
		["UltEnd"] = function(p342)
			-- upvalues: (ref) v_u_16, (ref) v_u_8
			local v343 = p342:FindFirstChild("HumanoidRootPart")
			if v343 then
				v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.UltEnd, v343, game.SoundService.Effect)
			end
		end,
		["ULTM1Rotation"] = function(p344, p345, p346)
			-- upvalues: (ref) v_u_5
			local v347 = p344:FindFirstChild("HumanoidRootPart")
			if v347 then
				if p344 == v_u_5.Character then
					local v348 = p344:FindFirstChild("Humanoid")
					local v349 = Instance.new("AlignOrientation")
					v349.Name = "Rotation"
					v349.Attachment0 = v347:FindFirstChild("RootAttachment") or Instance.new("Attachment")
					v349.Attachment0.Name = "RootAttachment"
					v349.Attachment0.Parent = v347
					v349.MaxTorque = 5000000 * p344:GetScale()
					v349.Responsiveness = 40
					v349.MaxAngularVelocity = 5000000 * p344:GetScale()
					v349.PrimaryAxisOnly = false
					v349.ReactionTorqueEnabled = false
					v349.Mode = Enum.OrientationAlignmentMode.OneAttachment
					v349.AlignType = Enum.AlignType.AllAxes
					v349.Parent = v347
					local v350
					if p346 then
						v350 = p346:FindFirstChild("HumanoidRootPart")
					else
						v350 = nil
					end
					while p344.Parent do
						task.wait()
						local v351 = v350 and v350.Parent and CFrame.lookAt(v347.Position, v350.Position).LookVector or workspace.CurrentCamera.CFrame.LookVector
						if p346 then
							v348.AutoRotate = false
						end
						local v352 = v351.Y
						local v353 = v347.CFrame.LookVector.Y or 0
						local v354 = (v353 + (v352 - v353) * 0.4) * 1
						local v355 = v351.X
						local v356 = v351.Z
						local v357 = (Vector3.new(v355, 0, v356).Unit + Vector3.new(0, v354, 0)).Unit
						local v358 = v357.Y
						v348.HipHeight = math.abs(v358) * -1.25
						v349.CFrame = CFrame.lookAt(v347.Position, v347.Position + v357)
						if not p345 or p345.Parent == nil then
							break
						end
					end
					for _ = 1, 12 do
						task.wait()
						v349.MaxTorque = v349.MaxTorque * 0.6
						v349.MaxAngularVelocity = v349.MaxAngularVelocity * 0.6
					end
					v349:Destroy()
					v348.HipHeight = 0
					if p346 then
						v348.AutoRotate = true
					end
				end
			else
				return
			end
		end,
		["MechaDamage"] = function(p359, p360)
			-- upvalues: (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_16, (ref) v_u_5, (ref) v_u_9
			local v361 = p359:IsA("BasePart") and (p359.Name == "Head" or p359.Name == "Torso") and v_u_8.Yuta.MetalHit or v_u_8.Yuta.MetalHit2
			if p359:IsA("Model") then
				p359 = p359.Head
			end
			local v362 = v_u_7.Mechamaru.Detonate.Lightning:Clone()
			v362.Enabled = false
			v362.Parent = p359
			v362:Emit(3)
			v_u_3:AddItem(v362, 0.4)
			v_u_16:PlaySound(v361, p359, game.SoundService.Effect)
			if v_u_5.Character and p359:IsDescendantOf(v_u_5.Character) or v_u_5.Character == p360 then
				local v363 = Instance.new("Folder")
				v363.Name = "MechamaruScreenNoise"
				v363.Parent = v_u_5.Character.Info
				v_u_3:AddItem(v363, 0.2)
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
			end
		end,
		["KickStart"] = function(p364)
			-- upvalues: (ref) v_u_16, (ref) v_u_8
			local v365 = p364:FindFirstChild("HumanoidRootPart")
			if v365 then
				v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.KickStart, v365, game.SoundService.Effect)
			end
		end,
		["KickSwing"] = function(p366)
			-- upvalues: (ref) v_u_16, (ref) v_u_8
			local v367 = p366:FindFirstChild("HumanoidRootPart")
			if v367 then
				v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.KickSwing, v367, game.SoundService.Effect)
			end
		end,
		["MechaKickFinal"] = function(p368, p369)
			-- upvalues: (ref) v_u_16, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_9
			if typeof(p368) ~= "Vector3" then
				local v370 = p368:FindFirstChild("HumanoidRootPart")
				if not v370 then
					return
				end
				v_u_16:Flash(p368, Color3.new(1, 1, 1))
				v_u_16:PlaySound(v_u_8.Yuta.MetalHit, v370, game.SoundService.Effect)
				p368 = v370.Position
			end
			local v371 = v_u_7.Itadori.CrushingBlow:Clone()
			v371.PointLight:Destroy()
			v371.Beam:Destroy()
			if p369 then
				v371.CFrame = CFrame.lookAlong(p368, p369) * CFrame.Angles(1.5707963267948966, 0, 0)
			else
				v371.Position = p368
			end
			local v372 = Instance.new("Model")
			v371.Parent = v372
			v372:ScaleTo(3)
			v372.Parent = workspace.Effects
			v371.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 1, 1))
			v371.Floor.Ring:Emit(10)
			v371.Floor.Wind2:Emit(8)
			v_u_3:AddItem(v372, 1.5)
			v_u_16:PlaySound(v_u_8.Yuta.VeilstepHit, v371, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p368).Magnitude <= 50 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["Stagger"] = function(p373, p374)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_16, (ref) v_u_8, (ref) v_u_5
			for _, v375 in p373:GetChildren() do
				if v375:IsA("BasePart") and v375.Name ~= "HumanoidRootPart" then
					local v376 = v_u_7.Mechamaru.Detonate.Lightning:Clone()
					v376.Enabled = false
					v376.Parent = v375
					v376:Emit(3)
					v_u_3:AddItem(v376, 0.4)
				end
			end
			v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.Stagger, p373.HumanoidRootPart, game.SoundService.Effect)
			if p373 == v_u_5.Character then
				local v377 = v_u_5.PlayerGui:FindFirstChild("MechamaruHUD")
				if not v377 then
					return
				end
				local v378 = Instance.new("Folder")
				v378.Name = "MechamaruScreenNoise"
				v378.Parent = v_u_5.Character.Info
				local v379 = v377.ScreenNoise
				local v380 = {
					[true] = Color3.fromRGB(0, 170, 255),
					[false] = Color3.fromRGB(255, 100, 100)
				}
				local v381 = true
				while p374.Parent or v_u_5.Character.Info:FindFirstChild("Stagger") do
					v381 = not v381
					v379.ImageColor3 = v380[v381]
					if not v381 then
						v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.Beep, workspace, game.SoundService.Effect)
					end
					task.wait(0.5)
				end
				v379.ImageColor3 = v380[true]
				v378:Destroy()
			end
		end,
		["StaggerGetUp"] = function(p382)
			-- upvalues: (ref) v_u_16, (ref) v_u_8
			v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.StaggerGetUp, p382.HumanoidRootPart, game.SoundService.Effect)
		end,
		["LockOn"] = function(p383, p384, p385, p386)
			-- upvalues: (ref) v_u_5, (ref) v_u_16, (ref) v_u_8, (copy) v_u_40, (ref) v_u_4
			if p383.Parent then
				local v387 = p383:FindFirstChild("HumanoidRootPart")
				if v387 then
					local v388 = v_u_5.PlayerGui:FindFirstChild("MechamaruHUD")
					if v388 then
						local v389 = workspace.CurrentCamera
						local v_u_390 = v388.Configuration.LockOn:Clone()
						local v_u_391 = nil
						local v_u_392 = v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.LockOn.FastBeeps, workspace, game.SoundService.Effect)
						local v393 = v_u_40:NextNumber(-3, 3)
						local v394 = v_u_40:NextNumber(-3, 3)
						local v395 = Vector2.new(v393, v394).Unit * 3
						local v396 = v395.X
						local v397 = v395.Y
						v_u_390.OuterCircle.Position = UDim2.fromScale(0.5 + v396, 0.5 + v397)
						v_u_390.InnerBarredCircle.Position = UDim2.fromScale(0.5 - v396, 0.5 - v397)
						local v398 = p384 * 900
						v_u_390.OuterCircle.Rotation = v398
						v_u_390.InnerBarredCircle.Rotation = v398
						v_u_4:Create(v_u_390.OuterCircle, TweenInfo.new(p384), {
							["Position"] = UDim2.fromScale(0.5, 0.5),
							["Rotation"] = 0
						}):Play()
						v_u_4:Create(v_u_390.InnerBarredCircle, TweenInfo.new(p384), {
							["Position"] = UDim2.fromScale(0.5, 0.5),
							["Rotation"] = 0
						}):Play()
						task.delay(p384, function()
							-- upvalues: (copy) v_u_390, (copy) v_u_392, (ref) v_u_16, (ref) v_u_8, (ref) v_u_391, (ref) v_u_4
							if v_u_390.Parent then
								v_u_392:Destroy()
								v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.LockOn.Lock, workspace, game.SoundService.Effect)
								v_u_391 = v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.LockOn.LongBeep, workspace, game.SoundService.Effect)
								v_u_390.OuterCircle.ImageColor3 = Color3.new(1, 0, 0)
								v_u_390.InnerBarredCircle.Visible = false
								local v399 = v_u_390.InnerCircle.Size
								v_u_390.InnerCircle.Size = UDim2.fromOffset(v399.X.Offset * 0.8, v399.Y.Offset * 0.8)
								v_u_4:Create(v_u_390.InnerCircle, TweenInfo.new(0.2), {
									["Size"] = v399
								}):Play()
								v_u_390.InnerCircle.Visible = true
								v_u_390.TextLabel.Visible = true
							end
						end)
						v_u_390.Parent = v388
						local v400 = Instance.new("Folder")
						v400.Name = "MechamaruScreenNoise"
						v400.Parent = v_u_5.Character.Info
						local v401 = tick()
						local v402 = v_u_391
						while p386.Parent and v387.Parent do
							local v403 = v387.Position
							local v404, v405 = v389:WorldToScreenPoint(v403)
							if v405 then
								v_u_390.Position = UDim2.fromOffset(v404.X, v404.Y)
								local v406 = tick() - v401
								local v407 = v_u_390.InnerBarredCircle.Dot
								local v408 = v406 * 12
								local v409 = math.sin(v408)
								v407.ImageTransparency = math.abs(v409)
							end
							v_u_390.Visible = v405
							if p385 then
								v389.CFrame = CFrame.lookAt(v389.CFrame.Position, v403)
							end
							task.wait()
						end
						v_u_390:Destroy()
						v400:Destroy()
						if v_u_392 then
							v_u_392:Destroy()
						end
						if v402 then
							v402:Destroy()
						end
					end
				else
					return
				end
			else
				return
			end
		end,
		["StaggerPunishSound"] = function(p410, p411)
			-- upvalues: (ref) v_u_16, (ref) v_u_8
			local v412 = p411:FindFirstChild("HumanoidRootPart")
			local v413 = p410:FindFirstChild("HumanoidRootPart")
			if v412 then
				v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.StaggerPunish, v412, game.SoundService.Effect)
			end
			if v413 then
				v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.StaggerPunishUser, v413, game.SoundService.Effect)
			end
		end,
		["StaggerSecondJump"] = function(p414, p415)
			-- upvalues: (ref) v_u_5, (ref) v_u_9
			if p414 == v_u_5.Character or p415 == v_u_5.Character then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				local v416 = v_u_5.PlayerGui:FindFirstChild("MechamaruHUD")
				if not v416 then
					return
				end
				local v417 = Instance.new("Folder")
				v417.Name = "MechamaruScreenNoise"
				v417.Parent = v_u_5.Character.Info
				v416.ScreenNoise.ImageTransparency = 0
				task.wait(0.3)
				v417:Destroy()
			end
		end,
		["EnergyOutputUI"] = function(p_u_418)
			-- upvalues: (ref) v_u_7, (ref) v_u_16, (ref) v_u_8, (ref) v_u_4
			local v419 = p_u_418:FindFirstChild("HumanoidRootPart")
			if v419 then
				if p_u_418:GetAttribute("InUlt") then
					local v420 = v_u_7.Mechamaru.EnergyMeter:Clone()
					v420.Parent = v419
					local v_u_421 = v420:FindFirstChild("Bars")
					local v_u_422 = p_u_418:GetAttribute("EnergyOutput")
					local v427 = p_u_418:GetAttributeChangedSignal("EnergyOutput"):Connect(function()
						-- upvalues: (copy) p_u_418, (ref) v_u_16, (ref) v_u_8, (copy) v_u_421, (ref) v_u_4, (ref) v_u_422
						local v423 = p_u_418:GetAttribute("EnergyOutput")
						v_u_16:PlaySound(v_u_8.Mechamaru.Absolute.LockOn.Lock, workspace, game.SoundService.Effect)
						for _, v424 in v_u_421:GetChildren() do
							if v424:IsA("Frame") then
								local v425 = v424.Name
								local v426 = tonumber(v425)
								if v423 < v426 then
									v_u_4:Create(v424, TweenInfo.new(0), {
										["BackgroundColor3"] = Color3.new()
									}):Play()
									v424.BackgroundTransparency = 0.5
								elseif v_u_422 < v426 then
									v424.BackgroundColor3 = Color3.new(1, 1, 1)
									v424.BackgroundTransparency = 0
									v_u_4:Create(v424, TweenInfo.new(0.2), {
										["BackgroundColor3"] = Color3.fromRGB(255, 10, 75)
									}):Play()
								end
							end
						end
						v_u_422 = v423
						v_u_4:Create(v_u_421, TweenInfo.new(0), {
							["GroupTransparency"] = 0
						}):Play()
						task.wait(1)
						if v423 == v_u_422 then
							v_u_4:Create(v_u_421, TweenInfo.new(1), {
								["GroupTransparency"] = 1
							}):Play()
						end
					end)
					p_u_418:GetAttributeChangedSignal("InUlt"):Wait()
					v427:Disconnect()
					v420:Destroy()
				end
			else
				return
			end
		end
	}
	v_u_14.Effects:Connect(function(p429, ...)
		-- upvalues: (copy) v_u_428
		local v430 = v_u_428[p429]
		if v430 then
			v430(...)
		end
	end)
	v_u_14.EjectHitbox:Connect(function(p431, p432, p433)
		-- upvalues: (ref) v_u_15
		local v434 = p432.HumanoidRootPart
		if not v434 then
			return
		end
		while true do
			local v435 = workspace:Raycast(v434.Position, p431.Velocity.Unit * 7, _G.MapParams)
			local v436 = v_u_15:SphereHitbox(p432, CFrame.new(0, -5, -5), 12)
			if #v436 > 0 or v435 then
				local v437
				if v435 then
					v437 = v435.Position
				else
					v437 = v435
				end
				p433:FireServer(v436, v437)
				if v435 then
					p431:Destroy()
				end
			end
			task.wait(0.025)
			if not p431.Parent then
				return
			end
		end
	end)
	v_u_14.DropkickHitbox:Connect(function(p438, p439, p440)
		-- upvalues: (ref) v_u_4, (ref) v_u_9
		local v441 = p439.HumanoidRootPart
		if v441 then
			v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(0.2), {
				["FieldOfView"] = 100
			}):Play()
			local v442 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.LightHit)
			while p439.Parent and (v441.Parent and (p440.Parent and p438.Parent)) do
				local v443 = workspace:Raycast(v441.Position, p438.Velocity.Unit * 40, _G.MapParams)
				if v443 then
					local v444 = {}
					local v445
					if v443 then
						v445 = v443.Position
					else
						v445 = v443
					end
					p440:FireServer(v444, v445)
					if v443 then
						p438:Destroy()
					end
				end
				task.wait(0.025)
				if not p438.Parent then
					break
				end
			end
			v442:StartFadeOut(0.2)
			v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(0.2), {
				["FieldOfView"] = 70
			}):Play()
		end
	end)
end
function v17.KnitInit(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_1, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16
	v_u_13 = v_u_1.GetService("MechamaruService")
	v_u_14 = v_u_1.GetService("AbsoluteService")
	v_u_15 = v_u_1.GetController("HitboxController")
	v_u_16 = v_u_1.GetController("FXController")
end
return v17