-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 1,
	["SortOrder"] = 6,
	["Val"] = "RagSFX",
	["Desc"] = "Toggle the audios that plays when limbs collide with parts"
}