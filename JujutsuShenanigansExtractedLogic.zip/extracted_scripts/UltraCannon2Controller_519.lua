-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.EffectUtils)
local v_u_10 = require(v5.Knit.Trove)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "UltraCannon2Controller"
})
function v15.KnitStart(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_10, (ref) v_u_14, (copy) v_u_7, (copy) v_u_9, (copy) v_u_6, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (copy) v_u_2, (ref) v_u_11
	local v_u_84 = {
		["Aerial"] = function(p16, p17)
			-- upvalues: (ref) v_u_13
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = p16:FindFirstChild("Humanoid")
				if v19 then
					local v20 = Instance.new("BodyGyro", v18)
					v20.P = 10000
					v20.MaxTorque = Vector3.new(40000, 40000, 40000)
					p17.Position = v18.Position + Vector3.new(0, 6, 0)
					v19.PlatformStand = true
					repeat
						local v21 = v_u_13:GetMouseTarget()
						v20.CFrame = p17:GetAttribute("Aim") or CFrame.new(v18.Position, v21)
						task.wait()
					until not p17.Parent
					v20:Destroy()
					v19.PlatformStand = false
				end
			else
				return
			end
		end,
		["Start"] = function(p22, p23)
			-- upvalues: (ref) v_u_10, (ref) v_u_14, (ref) v_u_7
			local v24 = p22:FindFirstChild("HumanoidRootPart")
			if v24 then
				local v25 = v_u_10.new()
				v25:AttachToInstance(p23)
				v25:Add(v_u_14:PlaySound(v_u_7.Mechamaru.UltraCannon.Start, v24, game.SoundService.Effect))
			end
		end,
		["ChargeStart"] = function(p26, p27)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_10, (ref) v_u_4, (ref) v_u_8
			local v28 = p26:FindFirstChild("HumanoidRootPart")
			if v28 then
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraCannonVFX.ChargeStart, v28)
			end
			local v29 = p26:FindFirstChild("Left Arm")
			if v29 then
				local v30 = v_u_10.new()
				v30:AttachToInstance(p27)
				local v31 = v30:Clone(v_u_6.Mechamaru["Hand blasterL"])
				v31.Weld.Part0 = v29
				if p26:GetAttribute("Moveset") ~= "Mechamaru" then
					v31.BlasterL.Transparency = 1
					v31.Neon.Transparency = 1
				end
				v31.Parent = p26
			end
			if v_u_4.Character == p26 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightLoop)
			end
		end,
		["AlbatrosStart"] = function(p_u_32, p33)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_14, (ref) v_u_7, (ref) v_u_10, (ref) v_u_3, (ref) v_u_4
			local v34 = p_u_32:FindFirstChild("HumanoidRootPart")
			if v34 then
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraCannonVFX.AlbatrosStart, v34)
				v_u_14:PlaySound(v_u_7.Mechamaru.UltraCannon.Albatros, v34, game.SoundService.Effect)
			end
			local v_u_35 = v_u_10.new()
			v_u_35:AttachToInstance(p33)
			local v36 = p_u_32:FindFirstChild("Head")
			if v36 and p_u_32:GetAttribute("Moveset") == "Mechamaru" then
				local v37 = v_u_35:Clone(v_u_6.Mechamaru["Mecha mouth blaster"])
				v37.Weld.Part0 = v36
				v37.Parent = p_u_32
			end
			local function v42(p38)
				-- upvalues: (copy) p_u_32, (ref) v_u_6, (ref) v_u_9, (copy) v_u_35, (ref) v_u_3
				local v39 = p_u_32:FindFirstChild(p38)
				if v39 then
					local v_u_40 = v_u_6.Mechamaru[("Booster%*"):format((p38:sub(1, 1)))]:Clone()
					v_u_40.Weld.Part0 = v39
					local v41 = v_u_40:FindFirstChildOfClass("UnionOperation")
					v41.Stage1:Destroy()
					v41.Stage2:Destroy()
					if p_u_32:GetAttribute("Moveset") ~= "Mechamaru" then
						v_u_9.Visibility(v_u_40, false)
					end
					v_u_35:Add(function()
						-- upvalues: (ref) v_u_3, (copy) v_u_40, (ref) v_u_9
						v_u_3:AddItem(v_u_40, 0.3)
						v_u_9.Visibility(v_u_40, false, 0.15)
					end)
					v_u_40.Parent = p_u_32
				end
			end
			v42("Left Arm")
			v42("Right Arm")
			local _ = v_u_4.Character == p_u_32
		end,
		["AlbatrosCharge"] = function(p43, p44)
			-- upvalues: (ref) v_u_10, (ref) v_u_9, (ref) v_u_6, (ref) v_u_4, (ref) v_u_8
			local v45 = p43:FindFirstChild("HumanoidRootPart")
			if v45 then
				local v46 = v_u_10.new()
				v46:AttachToInstance(p44)
				v46:Add(v_u_9.Enable("ParticleEmitter", v_u_6.Mechamaru.UltraCannonVFX.AlbatrosCharge.Enable.AlbatrosChargeEnable, v45))
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraCannonVFX.AlbatrosCharge, v45)
			end
			local v47 = p43:FindFirstChild("Hand blasterL")
			if v47 then
				v_u_9.Enable("ParticleEmitter", v47, nil, nil, true)
			end
			if v_u_4.Character == p43 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
			end
		end,
		["AlbatrosFire"] = function(p_u_48, p_u_49)
			-- upvalues: (ref) v_u_10, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v_u_50 = p_u_48:FindFirstChild("HumanoidRootPart")
			if v_u_50 then
				local v51 = v_u_10.new()
				v51:AttachToInstance(p_u_49)
				local v_u_52 = 37.5
				local v_u_53 = v51:Add(v_u_9.Enable({ "ParticleEmitter", "Beam" }, v_u_6.Mechamaru.UltraCannonVFX.AlbatrosFire.Beam, v_u_50, 1.75))
				v_u_53.Weld.C0 = CFrame.Angles(0, 3.141592653589793, 0)
				local v54 = v_u_50:FindFirstChild("AlbatrosChargeEnable")
				if v54 then
					v54:Destroy()
				end
				local v_u_55 = v51:Add(v_u_9.Enable("ParticleEmitter", v_u_6.Mechamaru.UltraCannonVFX.AlbatrosFire.Enable, v_u_50, 1.75))
				local v56 = p_u_48:FindFirstChild("BoosterL")
				if v56 then
					v56 = v56:FindFirstChildOfClass("UnionOperation")
				end
				if v56 then
					v_u_9.Enable("ParticleEmitter", v_u_6.Mechamaru.UltraCannonVFX.AlbatrosFire.BoosterLEnable, v56, 1.75)
				end
				local v57 = p_u_48:FindFirstChild("BoosterR")
				if v57 then
					v57 = v57:FindFirstChildOfClass("UnionOperation")
				end
				if v57 then
					v_u_9.Enable("ParticleEmitter", v_u_6.Mechamaru.UltraCannonVFX.AlbatrosFire.BoosterREnable, v57, 1.75)
				end
				task.spawn(function()
					-- upvalues: (ref) v_u_6, (copy) p_u_49, (ref) v_u_9, (copy) v_u_50
					local v58 = v_u_6.Mechamaru.UltraCannonVFX.AlbatrosRepeat.ConeSwirl
					local v59 = v58:GetAttribute("RepeatCount")
					local v60 = v58:GetAttribute("RepeatDelay")
					for _ = 1, v59 do
						if not p_u_49.Parent then
							break
						end
						v_u_9.AutoMeshes(v58, v_u_50)
						task.wait(v60)
					end
				end)
				task.spawn(function()
					-- upvalues: (copy) p_u_49, (copy) v_u_50, (ref) v_u_52, (copy) v_u_53, (copy) v_u_55, (ref) v_u_6, (ref) v_u_3, (ref) v_u_9, (ref) v_u_4, (copy) p_u_48, (ref) v_u_8
					for _ = 1, 21 do
						if not (p_u_49.Parent and v_u_50.Parent) then
							break
						end
						local v61 = workspace:Raycast(v_u_50.Position, v_u_50.CFrame.LookVector * 37.5, _G.MapParams)
						v_u_52 = v61 and v61.Distance or 37.5
						if v_u_53.Parent then
							v_u_53.End.CFrame = CFrame.new(0, 0, v_u_52)
							v_u_53.End2.CFrame = CFrame.new(0, 0, v_u_52 / 1.2)
							v_u_53.Attachment.CFrame = CFrame.new(0, 0, v_u_52 / 3) * CFrame.Angles(0, 3.141592653589793, 0)
						end
						if v_u_55.Parent then
							local v62 = v_u_55.Wind
							local v63 = v_u_52 / 1.3
							v62.Size = vector.create(1, 0.187, v63)
							v_u_55.Wind.Weld.C0 = CFrame.new(0, -3.1, -v_u_52 / 1.2)
							for _, v64 in v_u_55.Attachment1:GetChildren() do
								if v64:IsA("ParticleEmitter") then
									v64.Speed = NumberRange.new(0, v64:GetAttribute("MaxSpeed") * (v_u_52 / 37.5))
								end
							end
						end
						for _, v65 in v_u_6.Mechamaru.UltraCannonVFX.AlbatrosRepeat.Beam:GetChildren() do
							local v66 = v65.Start:Clone()
							v_u_3:AddItem(v66, 0.15)
							v66.CFrame = v_u_50.CFrame * v66.CFrame
							local v67 = v65.End.Size
							local v68 = v_u_9.Tween
							local v69 = {
								["CFrame"] = v_u_50.CFrame * CFrame.new(0, 0, -v_u_52 / 2 - 2)
							}
							local v70 = v67.X
							local v71 = v67.Y
							local v72 = v67.Z - 23 + v_u_52
							v69.Size = vector.create(v70, v71, v72)
							v68(v66, 0.15, "Cubic", "Out", v69)
							v66.Parent = workspace.Effects
						end
						if v_u_4.Character == p_u_48 then
							v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
						end
						task.wait(0.07)
					end
					task.wait(0.2)
					if p_u_49.Parent and v_u_4.Character == p_u_48 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
					end
				end)
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraCannonVFX.FireCannon, v_u_50)
				if v_u_4.Character == p_u_48 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
				end
			end
		end,
		["AlbatrosHit"] = function(p73)
			-- upvalues: (ref) v_u_14
			if p73:FindFirstChild("HumanoidRootPart") then
				v_u_14:Flash(p73, Color3.fromRGB(255, 255, 255))
			end
		end,
		["FireCannon"] = function(p74, p_u_75)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_14, (ref) v_u_7, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v76 = p74:FindFirstChild("HumanoidRootPart")
			if v76 then
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraCannonVFX.FireCannon, v76)
				v_u_14:PlaySound(v_u_7.Mechamaru.UltraCannon.Shoot, v76, game.SoundService.Effect)
			end
			local v77 = p74:FindFirstChild("Hand blasterL")
			if v77 then
				v_u_9.Enable("ParticleEmitter", v77, nil, nil, true)
			end
			if p_u_75.Parent then
				local v_u_78 = p_u_75.CFrame
				local v_u_79 = tick()
				local v_u_80 = p_u_75:GetPropertyChangedSignal("Position"):Connect(function()
					-- upvalues: (ref) v_u_78, (copy) p_u_75, (ref) v_u_79
					v_u_78 = p_u_75.CFrame
					v_u_79 = tick()
				end)
				local v_u_81 = nil
				v_u_81 = v_u_2.Stepped:Connect(function()
					-- upvalues: (copy) p_u_75, (ref) v_u_81, (copy) v_u_80, (ref) v_u_78, (ref) v_u_79
					if p_u_75.Parent then
						workspace:BulkMoveTo({ p_u_75 }, { v_u_78 + v_u_78.LookVector * (180 * (tick() - v_u_79)) }, Enum.BulkMoveMode.FireCFrameChanged)
					else
						v_u_81:Disconnect()
						v_u_80:Disconnect()
					end
				end)
			end
			if v_u_4.Character == p74 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
			end
		end,
		["ProjectileCancel"] = function(p82)
			-- upvalues: (ref) v_u_9
			if p82.Parent then
				p82.Transparency = 1
				v_u_9.Enable({ "ParticleEmitter", "Trail" }, p82, nil, nil, true)
			end
		end,
		["ProjectileExplode"] = function(p83)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_14, (ref) v_u_7, (ref) v_u_8
			if p83.Parent then
				p83.Transparency = 1
				v_u_9.Enable({ "ParticleEmitter", "Trail" }, p83, nil, nil, true)
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraCannonVFX.ProjectileExplode, p83)
				v_u_14:PlaySound(v_u_7.Mechamaru.UltraCannon.Explode, p83, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - p83.Position).Magnitude <= 60 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p85, ...)
		-- upvalues: (copy) v_u_84
		local v86 = v_u_84[p85]
		if v86 then
			v86(...)
		end
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14
	v_u_11 = v_u_1.GetService("UltraCannon2Service")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("ToolController")
	v_u_14 = v_u_1.GetController("FXController")
end
return v15