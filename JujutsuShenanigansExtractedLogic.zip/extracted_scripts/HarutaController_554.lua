-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = v_u_6.Animations
local v_u_8 = v_u_6.Utils
local v_u_9 = v_u_6.Sounds
local v_u_10 = require(v_u_6.Modules.CameraShaker)
local v_u_11 = require(v_u_6.Modules.BloodyZee)
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "HarutaController"
})
function v15.KnitStart(_)
	-- upvalues: (ref) v_u_14, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_5, (copy) v_u_10, (copy) v_u_4, (copy) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (ref) v_u_12, (ref) v_u_13
	local v_u_116 = {
		["Hit"] = function(p16, p17, p18, p19)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v20 = p16:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = p17:FindFirstChild("HumanoidRootPart")
				if v21 then
					v_u_14:Flash(p17, Color3.new(1, 1, 1))
					if p16.SetAssets:FindFirstChild("HarutaSword") then
						local v22 = p19 == "Up" and 1 or p18
						v_u_14:PlaySound(v_u_9.Haruta.M1:FindFirstChild("Hit" .. v22), v21, game.SoundService.Effect)
						if p19 ~= "Down" then
							local v23 = v_u_8.Yuta.SlashHit:Clone()
							v23.CFrame = CFrame.lookAlong(v21.Position, v20.CFrame.LookVector)
							local v24 = {
								[2] = CFrame.Angles(0, 0, 0.2617993877991494),
								[3] = CFrame.Angles(0, 0, 0.4363323129985824)
							}
							if v24[p18] then
								v23.CFrame = v23.CFrame * v24[p18]
							elseif p19 == "Up" then
								v23.CFrame = v23.CFrame * CFrame.Angles(0, 0, -1.3089969389957472)
							end
							v23.Parent = workspace.Effects
							v_u_3:AddItem(v23, 0.5)
							v23.Slash:Emit(5)
						end
					else
						v_u_14:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. p18), v20, game.SoundService.Effect)
						return
					end
				else
					return
				end
			else
				return
			end
		end,
		["ChaseHit"] = function(p25, p26, p27)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v28 = p25:FindFirstChild("HumanoidRootPart")
			if v28 then
				local v29 = p26:FindFirstChild("HumanoidRootPart")
				if v29 then
					if p25.SetAssets:FindFirstChild("HarutaSword") and not p27 then
						v_u_14:Flash(p26, Color3.new(1, 1, 1))
						v_u_14:PlaySound(v_u_9.Haruta.M1:FindFirstChild("Hit" .. math.random(1, 3)), v29, game.SoundService.Effect)
					else
						v_u_14:Flash(p26, Color3.new(1, 1, 1))
						v_u_14:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit3"), v29, game.SoundService.Effect)
					end
					local v30 = v_u_8.ChaseHit:Clone()
					local v31 = CFrame.new
					local v32 = v29.Position
					local v33 = v28.Position.X
					local v34 = v29.Position.Y
					local v35 = v28.Position.Z
					v30.CFrame = v31(v32, (Vector3.new(v33, v34, v35))) * CFrame.Angles(0, 3.141592653589793, 0)
					v30.Parent = workspace.Effects
					v_u_3:AddItem(v30, 0.5)
					v30.Ring:Emit(7)
					v30.Sparks:Emit(12)
				end
			else
				return
			end
		end,
		["AerialHit"] = function(p36, p37)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_8, (ref) v_u_3
			local v38 = p36:FindFirstChild("HumanoidRootPart")
			if v38 then
				local v39 = p37:FindFirstChild("HumanoidRootPart")
				if v39 then
					v_u_14:Flash(p37, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_9.Itadori.CraniumSmash.Hit2, v39, game.SoundService.Effect)
					if v_u_5.Character == p36 or v_u_5.Character == p37 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					end
					local v40 = CFrame.new(v38.Position, v39.Position - Vector3.new(0, 4, 0))
					local v41 = v_u_8.Gojo.HardHit:Clone()
					v41.CFrame = v40 + v40.LookVector * 4
					v41.Parent = workspace.Effects
					v41.Dust:Emit(5)
					v41.Ring:Emit(5)
					v41.Sparks:Emit(10)
					v_u_3:AddItem(v41, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p42)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9
			local v43 = p42.HumanoidRootPart
			if v43 then
				local v44 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v44.CFrame = v43.CFrame * CFrame.new(0, 1, -4)
				v44.Size = Vector3.new(0, 0, 2)
				v44.Parent = workspace.Effects
				v_u_4:Create(v44, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v44, 0.3)
				v_u_14:PlaySound(v_u_9.Misc.Chase, v43, game.SoundService.Effect)
				v_u_14:DustTrail(p42, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p45, p46, p47)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v48 = p45:FindFirstChild("HumanoidRootPart")
			if v48 then
				if p45.SetAssets:FindFirstChild("HarutaSword") then
					local v49 = (p47 == "Up" or p47 == "Down") and 1 or (p46 or 4)
					v_u_14:PlaySound(v_u_9.Haruta.M1:FindFirstChild("Swing" .. v49), v48, game.SoundService.Effect)
				else
					v_u_14:PlaySound(v_u_9.Misc.Swing.Fist, v48, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Swing2"] = function(p50, p51, p52)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14
			local v53 = p50.SetAssets:FindFirstChild("HarutaSword")
			if v53 then
				local v54 = v_u_8.Haruta.CombatTrail:Clone()
				v54.Weld.Part0 = v53.Blade
				v54.Parent = workspace.Effects
				task.wait(p51 == 4 and 0.425 or 0.325)
				v54.Trail.Enabled = false
				v_u_4:Create(v54, TweenInfo.new(0.1), {
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v54, 0.2)
				return
			elseif p52 == "Down" then
				v_u_14:ArmFlash(p50["Right Leg"], Color3.fromRGB(167, 125, 203), 0.4)
				return
			elseif p51 == 1 or p51 == 4 then
				v_u_14:ArmFlash(p50["Right Arm"], Color3.fromRGB(167, 125, 203), 0.3)
			else
				v_u_14:ArmFlash(p50["Left Arm"], Color3.fromRGB(167, 125, 203), 0.3)
			end
		end,
		["Launch"] = function(p55, p56)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_11
			local v57 = p55:FindFirstChild("HumanoidRootPart")
			if v57 then
				local v58 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v58.CFrame = CFrame.new(v57.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v58.Size = Vector3.new(0, 0, 5)
				v58.Parent = workspace.Effects
				v_u_4:Create(v58, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v58.Position + Vector3.new(0, p56, 0)
				}):Play()
				v_u_3:AddItem(v58, 0.3)
				if p56 < 0 then
					v_u_14:PlaySound(v_u_9.Megumi.Mahoraga.Throw.Break, v57, game.SoundService.Effect)
					v_u_14:DustBreak(v57.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v57.Position) < 20 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
					v_u_14:PlaySound(v_u_9.Choso.BloodEdge.StabHit, v57, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
					for _ = 1, 8 do
						v_u_11:Blood(CFrame.lookAt(p55.Torso.Position, p55.Torso.Position + Vector3.new(0, 10, 0)), math.random(20, 40), math.random(20, 40), math.random(20, 40))
					end
				end
			end
		end,
		["Miracles"] = function(p_u_59)
			task.spawn(function()
				-- upvalues: (copy) p_u_59
				repeat
					task.wait()
				until _G.Settings ~= nil and (_G.Settings.UIS ~= nil and p_u_59:FindFirstChild("UIScale"))
				p_u_59.UIScale.Scale = _G.Settings.UIS
			end)
		end,
		["UpdateMiracles"] = function(p60, p61)
			for v62 = 1, 6 do
				p60:FindFirstChild("Mir" .. v62, true).Fill.Visible = v62 <= p61
			end
		end,
		["Stab"] = function(p63, p64)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_11
			if p63:FindFirstChild("HumanoidRootPart") then
				local v65 = p64:FindFirstChild("HumanoidRootPart")
				if v65 then
					v_u_14:PlaySound(v_u_9.Choso.BloodEdge.StabHit, v65, game.SoundService.Effect)
					for _ = 1, 20 do
						v_u_11:Blood(p64.Torso.CFrame, math.random(5, 80), 25, 25)
					end
				end
			else
				return
			end
		end,
		["Kick"] = function(_, p66)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v67 = p66:FindFirstChild("HumanoidRootPart")
			if v67 then
				v_u_14:Flash(p66, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit4"), v67, game.SoundService.Effect)
			end
		end,
		["DodgeAttempt"] = function(p68)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_8, (ref) v_u_3
			local v69 = p68:FindFirstChild("HumanoidRootPart")
			if v69 then
				v_u_14:Flash(p68, Color3.fromRGB(167, 125, 203), 0.2)
				v_u_14:PlaySound(v_u_9.Itadori.ManjiKick.Startup, v69, game.SoundService.Effect)
				if v_u_5.Character == p68 then
					local v70 = v_u_8.Itadori.CounterHit.Feint:Clone()
					for _, v71 in v70:GetChildren() do
						v71.Color = ColorSequence.new(Color3.fromRGB(167, 125, 203))
					end
					v70.Parent = v69
					v70.Ring:Emit(1)
					v70.Ring.Lifetime = NumberRange.new(0.2)
					v_u_3:AddItem(v70, 0.2)
				end
			end
		end,
		["MiracleGain"] = function(p72)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v73 = p72:FindFirstChild("HumanoidRootPart")
			if v73 then
				v_u_14:Flash(p72, Color3.fromRGB(209, 157, 255), 0.4)
				v_u_9.Haruta.Gain.PlaybackSpeed = math.random(90, 110) / 100
				v_u_14:PlaySound(v_u_9.Haruta.Gain, v73, game.SoundService.Effect)
			end
		end,
		["MiracleUse"] = function(p74)
			-- upvalues: (ref) v_u_14, (ref) v_u_5, (ref) v_u_10
			if p74:FindFirstChild("HumanoidRootPart") then
				v_u_14:Flash(p74, Color3.fromRGB(209, 157, 255), 0.2)
				if v_u_5.Character == p74 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["Dodge"] = function(p75)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9, (ref) v_u_7
			local v76 = p75:FindFirstChild("HumanoidRootPart")
			if v76 then
				local v77 = v_u_8.Damage.HitGlow:Clone()
				if p75:GetScale() ~= 1 then
					v77:ScaleTo(p75:GetScale())
				end
				v77.Parent = workspace.Effects
				v_u_3:AddItem(v77, 0.5)
				for _, v78 in v77:GetChildren() do
					local v79 = p75:FindFirstChild(v78.Name)
					if v79 then
						v78.CFrame = v79.CFrame
					end
					v78.Color = Color3.fromRGB(167, 125, 203)
					v78.Anchored = true
					v78.Transparency = 0.1
					v_u_4:Create(v78, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
				v_u_14:PlaySound(v_u_9.Itadori.ManjiKick.Dodge, v76, game.SoundService.Effect)
				local v80 = {
					"Dodge1",
					"Dodge2",
					"Dodge3",
					"Dodge4",
					"Dodge5"
				}
				for _, v81 in p75.Humanoid:GetPlayingAnimationTracks() do
					if table.find(v80, v81.Name) then
						v81:Stop(0.02)
					end
				end
				p75.Humanoid:LoadAnimation(v_u_7.Hiromi.Dodge:GetChildren()[math.random(1, 5)]):Play(0.02)
			end
		end,
		["SwordCatch"] = function(p82)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_10
			local v83 = p82:FindFirstChild("HumanoidRootPart")
			if v83 then
				v_u_14:PlaySound(v_u_9.Haruta.Catch, v83, game.SoundService.Effect)
				v_u_14:ArmFlash(p82["Right Arm"], Color3.fromRGB(167, 125, 203))
				local v84 = v_u_6.Utils.Haruta.SwordGrab:Clone()
				v84.Parent = p82["Right Arm"]
				v84.Ring:Emit(5)
				v84.Star:Emit(1)
				v_u_3:AddItem(v84, 0.8)
				if v_u_5.Character == p82 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["Taunt"] = function(p85, p86)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v87 = p85:FindFirstChild("HumanoidRootPart")
			if v87 then
				local v_u_88 = v_u_14:PlaySound(v_u_9.Haruta.Taunt, v87, game.SoundService.Effect)
				p86.AncestryChanged:Connect(function()
					-- upvalues: (copy) v_u_88
					v_u_88:Destroy()
				end)
			end
		end,
		["JawbreakerStart"] = function(p_u_89, p90, p_u_91, p_u_92)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_10, (ref) v_u_6, (ref) v_u_2
			local v_u_93 = p_u_89:FindFirstChild("HumanoidRootPart")
			if v_u_93 then
				local v_u_94 = p_u_91:FindFirstChild("HumanoidRootPart")
				if v_u_94 then
					v_u_14:Flash(p_u_89, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_9.Hiromi.Execution.Curb, v_u_93, game.SoundService.Effect)
					v_u_14:PlaySound(v_u_9.Hiromi.Execution.Step, v_u_93, game.SoundService.Effect)
					local v95 = v_u_8.Locust.Slam:Clone()
					v95.Position = p_u_91.Head.Position
					v95.Parent = workspace.Effects
					for _, v96 in v95.Attachment:GetChildren() do
						v96:Emit(v96:GetAttribute("EmitCount"))
					end
					v_u_3:AddItem(v95, 0.5)
					local v_u_97 = v_u_8.Mechamaru.Dust:Clone()
					v_u_97.bigimpact:Destroy()
					v_u_97.Smoke2:Destroy()
					v_u_97.Position = v_u_94.Position - Vector3.new(0, 3, 0)
					v_u_97.Parent = workspace.Effects
					v_u_3:AddItem(v_u_97, 2.5)
					for _, v98 in v_u_97:GetChildren() do
						v98:Emit(v98:GetAttribute("EmitCount"))
						v_u_4:Create(v98, TweenInfo.new(0.3), {
							["TimeScale"] = 0.1
						}):Play()
					end
					task.delay(1.7, function()
						-- upvalues: (ref) v_u_14, (ref) v_u_9, (copy) v_u_93, (copy) v_u_97
						v_u_14:PlaySound(v_u_9.Hiromi.Execution.Curb, v_u_93, game.SoundService.Effect)
						for _, v99 in v_u_97:GetChildren() do
							v99:Emit(v99:GetAttribute("EmitCount"))
							v99.TimeScale = 1
						end
					end)
					if v_u_5.Character ~= p_u_91 then
						v_u_14:PlaySound(v_u_9.Haruta.Jawbreaker, v_u_94, game.SoundService.Effect)
					end
					if v_u_5.Character == p90 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
						task.wait(1.7)
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
					elseif v_u_5.Character == p_u_91 then
						local v_u_100 = workspace.CurrentCamera
						local v_u_101 = v_u_100.CFrame
						v_u_14:PlaySound(v_u_9.Haruta.Jawbreaker, workspace, game.SoundService.Effect)
						local v_u_102 = v_u_6.Utils.Haruta.JawbreakerUI:Clone()
						v_u_102.BG.CurrentCamera = workspace.CurrentCamera
						v_u_102.Skull.CurrentCamera = workspace.CurrentCamera
						v_u_102.Parent = v_u_5.PlayerGui
						local v_u_103 = v_u_6.Utils.Damage.Skeleton.Head:Clone()
						v_u_103.Anchored = true
						v_u_103.Mesh.Scale = Vector3.new(0.8, 0.8, 0.8)
						v_u_103.Parent = v_u_102.Skull
						v_u_14:WorldModelChar(p_u_91, v_u_102.BG)
						local v_u_104 = Instance.new("NumberValue", v_u_102)
						v_u_4:Create(v_u_104, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
							["Value"] = 1
						}):Play()
						v_u_3:AddItem(v_u_104, 0.5)
						v_u_4:Create(v_u_102.BG, TweenInfo.new(0.5), {
							["ImageTransparency"] = 0.1
						}):Play()
						v_u_4:Create(v_u_102.BG, TweenInfo.new(0.85), {
							["BackgroundTransparency"] = 0.65
						}):Play()
						v_u_4:Create(v_u_102.BG.Vignette, TweenInfo.new(0.85), {
							["ImageTransparency"] = 0
						}):Play()
						v_u_4:Create(v_u_102.Skull, TweenInfo.new(1), {
							["ImageTransparency"] = 0
						}):Play()
						task.delay(0.85, function()
							-- upvalues: (ref) v_u_4, (copy) v_u_102
							v_u_4:Create(v_u_102.BG, TweenInfo.new(0.85), {
								["BackgroundTransparency"] = 1
							}):Play()
							v_u_4:Create(v_u_102.BG.Vignette, TweenInfo.new(0.85), {
								["ImageTransparency"] = 1
							}):Play()
							task.wait(0.15)
							local v105 = TweenInfo.new(0.7, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
							v_u_4:Create(v_u_102.Skull, v105, {
								["ImageTransparency"] = 1
							}):Play()
							v_u_4:Create(v_u_102.BG, v105, {
								["ImageTransparency"] = 1
							}):Play()
						end)
						local v_u_106 = 0
						local v_u_107 = nil
						tick()
						local v_u_108 = v_u_8.Haruta.JawbreakerCutscene
						v_u_107 = v_u_2.RenderStepped:Connect(function(p109)
							-- upvalues: (ref) v_u_106, (copy) v_u_108, (copy) p_u_89, (copy) v_u_93, (copy) p_u_92, (copy) v_u_100, (copy) v_u_101, (copy) v_u_94, (copy) v_u_104, (ref) v_u_107, (ref) v_u_5, (ref) v_u_4, (ref) v_u_10, (copy) v_u_102, (ref) v_u_3, (copy) v_u_103, (copy) p_u_91
							v_u_106 = v_u_106 + p109 * 120
							local v110 = v_u_108.Frames
							local v111 = v_u_106
							local v112 = math.ceil(v111)
							local v113 = v110:FindFirstChild((tonumber(v112)))
							if v113 and (p_u_89 and (p_u_89.Parent and (v_u_93 and p_u_92.Parent))) then
								v_u_100.CFrame = v_u_101:Lerp(v_u_94.CFrame * v113.Value, v_u_104.Value)
								v_u_100.CameraType = Enum.CameraType.Scriptable
							else
								v_u_107:Disconnect()
								v_u_100.CameraType = Enum.CameraType.Custom
								v_u_100.FieldOfView = 70
								v_u_100.CameraSubject = (v_u_5.Character or v_u_5.CharacterAdded:Wait()):WaitForChild("Humanoid")
								game.Lighting.ExposureCompensation = -2
								v_u_4:Create(game.Lighting, TweenInfo.new(1), {
									["ExposureCompensation"] = 0
								}):Play()
								v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
								v_u_102:Destroy()
								local v114 = Instance.new("BlurEffect", game.Lighting)
								v_u_3:AddItem(v114, 8)
								v114.Size = 64
								v_u_4:Create(v114, TweenInfo.new(8, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
									["Size"] = 0
								}):Play()
								local v115 = Instance.new("ColorCorrectionEffect", game.Lighting)
								v_u_3:AddItem(v115, 9)
								v115.TintColor = Color3.new(1, 0, 0)
								v115.Contrast = 200
								task.wait(0.05)
								v115.Contrast = -200
								v115.TintColor = Color3.new(1, 1, 1)
								task.wait(0.05)
								v115.Contrast = 0
								v115.TintColor = Color3.new(1, 0.3, 0.3)
								v_u_4:Create(v115, TweenInfo.new(8, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
									["TintColor"] = Color3.fromRGB(255, 201, 201)
								}):Play()
								task.wait(8)
								v_u_4:Create(v115, TweenInfo.new(2.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
									["TintColor"] = Color3.fromRGB(255, 255, 255)
								}):Play()
							end
							v_u_103.CFrame = p_u_91.Head.CFrame
						end)
					end
				else
					return
				end
			else
				return
			end
		end
	}
	v_u_12.Effects:Connect(function(p117, ...)
		-- upvalues: (copy) v_u_116
		local v118 = v_u_116[p117]
		if v118 then
			v118(...)
		end
	end)
	v_u_12.Hitbox:Connect(function(p119, p120, p121)
		-- upvalues: (ref) v_u_13, (ref) v_u_4
		local v122 = p120.HumanoidRootPart
		if not v122 then
			return
		end
		local v123 = nil
		while true do
			local v124 = v_u_13:SphereHitbox(p120, CFrame.new(0, 0, -4), 8)
			for _, v125 in v124 do
				local v126 = v125:FindFirstChild("Info")
				if v126 then
					local v127 = v126:FindFirstChild("Knockback")
					if not v127 or v127.Value ~= false then
						v123 = v124
						break
					end
				end
			end
			if v123 then
				local v128 = p119:FindFirstChildWhichIsA("NumberValue")
				if v128 then
					v_u_4:Create(v128, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p119.Parent then
				break
			end
		end
		p121:FireServer(v123, v122.CFrame)
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14
	v_u_12 = v_u_1.GetService("HarutaService")
	v_u_13 = v_u_1.GetController("HitboxController")
	v_u_14 = v_u_1.GetController("FXController")
end
return v15