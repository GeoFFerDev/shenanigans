-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = v_u_6.Animations
local v_u_8 = v_u_6.Utils
local v_u_9 = v_u_6.Sounds
local v_u_10 = require(v_u_6.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "ShadowSwarmController"
})
local v_u_16 = RaycastParams.new()
v_u_16.FilterType = Enum.RaycastFilterType.Include
v_u_16.FilterDescendantsInstances = { workspace.Map }
function v15.KnitStart(_)
	-- upvalues: (ref) v_u_14, (copy) v_u_9, (copy) v_u_2, (copy) v_u_4, (ref) v_u_13, (copy) v_u_7, (copy) v_u_8, (copy) v_u_16, (copy) v_u_3, (copy) v_u_5, (copy) v_u_10, (copy) v_u_6, (ref) v_u_11
	local v_u_88 = {
		["Domain"] = function(p17)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_14:PlaySound(v_u_9.Megumi.Voice, v18, game.SoundService.Voice)
				v_u_14:DomainBurst(v18)
			end
		end,
		["Start"] = function(p19)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_14:PlaySound(v_u_9.Megumi.ShadowGarden.Start, v20, game.SoundService.Effect)
			end
		end,
		["Summon"] = function(p21, p22)
			-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_14, (ref) v_u_13, (ref) v_u_9, (ref) v_u_7, (ref) v_u_8, (ref) v_u_16, (ref) v_u_3
			local v_u_23 = p21:FindFirstChild("HumanoidRootPart")
			if v_u_23 then
				local v_u_24 = p21:Clone()
				local v_u_25 = p21:Clone()
				v_u_24.Parent = p22
				v_u_25.Parent = p22
				for _, v26 in p22:GetDescendants() do
					if v26:IsA("BasePart") then
						if v26.Name == "HumanoidRootPart" or v26.Name == "Torso" then
							v26.CollisionGroup = "Effects"
						else
							v26.CollisionGroup = "NoCollision"
						end
						v26.Massless = true
					end
				end
				local v_u_27 = Instance.new("Weld", v_u_24)
				v_u_27.C0 = CFrame.new(-6, 0, -3)
				v_u_27.Name = "FolderWeld"
				local v_u_28 = Instance.new("Weld", v_u_25)
				v_u_28.C0 = CFrame.new(6, 0, -2)
				v_u_28.Name = "FolderWeld"
				v_u_27:GetPropertyChangedSignal("Enabled"):Connect(function()
					-- upvalues: (copy) v_u_24, (copy) v_u_27
					v_u_24.HumanoidRootPart.Anchored = v_u_27.Enabled
				end)
				v_u_28:GetPropertyChangedSignal("Enabled"):Connect(function()
					-- upvalues: (copy) v_u_25, (copy) v_u_28
					v_u_25.HumanoidRootPart.Anchored = v_u_28.Enabled
				end)
				local v_u_29 = nil
				v_u_29 = v_u_2.Stepped:Connect(function()
					-- upvalues: (copy) v_u_27, (copy) v_u_28, (ref) v_u_29, (copy) v_u_24, (copy) v_u_23, (copy) v_u_25
					if v_u_27.Parent and v_u_28.Parent then
						if v_u_27.Enabled == true then
							v_u_24.HumanoidRootPart.CFrame = v_u_23.CFrame * v_u_27.C0
						end
						if v_u_28.Enabled == true then
							v_u_25.HumanoidRootPart.CFrame = v_u_23.CFrame * v_u_28.C0
						end
					else
						v_u_29:Disconnect()
					end
				end)
				v_u_4:Create(v_u_27, TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
					["C0"] = CFrame.new(-6, 0, 4)
				}):Play()
				v_u_4:Create(v_u_28, TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
					["C0"] = CFrame.new(6, 0, 4)
				}):Play()
				v_u_14:Flash(v_u_24, Color3.new(0, 0, 0), 1.5)
				v_u_14:Flash(v_u_25, Color3.new(0, 0, 0), 1.5)
				v_u_13:Tilt(v_u_24)
				v_u_13:Tilt(v_u_25)
				v_u_14:PlaySound(v_u_9.Megumi.ShadowEnter, v_u_23, game.SoundService.Effect)
				local v_u_30 = v_u_24.Humanoid:LoadAnimation(v_u_7.Megumi.ShadowSwarmRun)
				local v_u_31 = v_u_25.Humanoid:LoadAnimation(v_u_7.Megumi.ShadowSwarmRun)
				v_u_30:Play(0, nil, 1.2000000000000002)
				v_u_31:Play(0, nil, 1.5)
				v_u_31.TimePosition = 4.2
				local v_u_32 = v_u_8.Megumi.Shadow:Clone()
				local v_u_33 = v_u_8.Megumi.Shadow:Clone()
				v_u_32.Shadow.Enabled = false
				v_u_33.Shadow.Enabled = false
				v_u_32.Parent = v_u_24
				v_u_33.Parent = v_u_25
				task.delay(0.2, function()
					-- upvalues: (copy) v_u_32, (copy) v_u_33, (copy) v_u_30, (copy) v_u_31
					v_u_32.Dive.Enabled = false
					v_u_33.Dive.Enabled = false
					task.wait(0.8)
					v_u_30:AdjustSpeed(0.8)
					v_u_31:AdjustSpeed(1)
				end)
				local v34 = Instance.new("Highlight")
				v34.DepthMode = Enum.HighlightDepthMode.Occluded
				v34.FillTransparency = 0
				v34.FillColor = Color3.new(0, 0, 0)
				v34.OutlineColor = Color3.new(0, 0, 0)
				v34.Parent = v_u_24
				local v35 = v34:Clone()
				v35.Parent = v_u_25
				v_u_4:Create(v34, TweenInfo.new(1), {
					["OutlineTransparency"] = 0,
					["FillTransparency"] = 0.5
				}):Play()
				v_u_4:Create(v35, TweenInfo.new(1), {
					["OutlineTransparency"] = 0,
					["FillTransparency"] = 0.5
				}):Play()
				local v36 = workspace:Raycast(v_u_24.HumanoidRootPart.Position, Vector3.new(0, -8, 0), v_u_16)
				local v37 = workspace:Raycast(v_u_25.HumanoidRootPart.Position, Vector3.new(0, -8, 0), v_u_16)
				if v36 then
					v_u_32.CFrame = CFrame.new(v36.Position, v36.Position + v36.Normal)
					v_u_32.Shadow:Emit(20)
				else
					v_u_32.CFrame = v_u_25.HumanoidRootPart.CFrame
					v_u_32.ShadowAir:Emit(20)
				end
				if v37 then
					v_u_33.CFrame = CFrame.new(v37.Position, v37.Position + v37.Normal)
					v_u_33.Shadow:Emit(20)
				else
					v_u_33.CFrame = v_u_25.HumanoidRootPart.CFrame
					v_u_33.ShadowAir:Emit(20)
				end
				p22.Destroying:Connect(function()
					-- upvalues: (copy) v_u_24, (copy) v_u_25, (ref) v_u_3, (copy) v_u_27, (copy) v_u_28, (ref) v_u_4, (ref) v_u_16, (copy) v_u_32, (copy) v_u_33, (ref) v_u_14, (ref) v_u_9, (copy) v_u_23
					v_u_24.Parent = workspace.Effects
					v_u_25.Parent = workspace.Effects
					v_u_3:AddItem(v_u_24, 1)
					v_u_3:AddItem(v_u_25, 1)
					v_u_27:Destroy()
					v_u_28:Destroy()
					v_u_24.HumanoidRootPart.Anchored = true
					v_u_25.HumanoidRootPart.Anchored = true
					v_u_4:Create(v_u_24.HumanoidRootPart, TweenInfo.new(0.5), {
						["CFrame"] = v_u_24.HumanoidRootPart.CFrame - Vector3.new(0, 4, 0)
					}):Play()
					v_u_4:Create(v_u_25.HumanoidRootPart, TweenInfo.new(0.5), {
						["CFrame"] = v_u_25.HumanoidRootPart.CFrame - Vector3.new(0, 4, 0)
					}):Play()
					local v38 = workspace:Raycast(v_u_24.Torso.Position + Vector3.new(0, 3, 0), Vector3.new(0, -8, 0), v_u_16)
					local v39 = workspace:Raycast(v_u_25.Torso.Position + Vector3.new(0, 3, 0), Vector3.new(0, -8, 0), v_u_16)
					if v38 then
						v_u_32.CFrame = CFrame.new(v38.Position, v38.Position + v38.Normal)
						v_u_32.Shadow:Emit(20)
					else
						v_u_32.CFrame = v_u_25.HumanoidRootPart.CFrame
						v_u_32.ShadowAir:Emit(20)
					end
					if v39 then
						v_u_33.CFrame = CFrame.new(v39.Position, v39.Position + v39.Normal)
						v_u_33.Shadow:Emit(20)
					else
						v_u_33.CFrame = v_u_25.HumanoidRootPart.CFrame
						v_u_33.ShadowAir:Emit(20)
					end
					v_u_14:PlaySound(v_u_9.Megumi.Rabbit.Despawn, v_u_23, game.SoundService.Effect)
					task.wait(0.5)
					for _, v40 in v_u_24:GetDescendants() do
						if v40:IsA("BasePart") or v40:IsA("Decal") then
							v40.Transparency = 1
						end
					end
					for _, v41 in v_u_25:GetDescendants() do
						if v41:IsA("BasePart") or v41:IsA("Decal") then
							v41.Transparency = 1
						end
					end
				end)
			end
		end,
		["Shadow"] = function(p42)
			-- upvalues: (ref) v_u_8, (ref) v_u_14, (ref) v_u_9, (ref) v_u_16, (ref) v_u_3
			local v43 = p42:FindFirstChild("HumanoidRootPart")
			if v43 then
				local v44 = v_u_8.Megumi.Shadow:Clone()
				v44.Dive.Enabled = false
				v44.Shadow.Enabled = false
				v44.Parent = workspace.Effects
				v44.Dive:Emit(5)
				v_u_14:PlaySound(v_u_9.Megumi.ShadowEnter, v43, game.SoundService.Effect)
				local v45 = workspace:Raycast(p42.Torso.Position + Vector3.new(0, 3, 0), Vector3.new(0, -8, 0), v_u_16)
				if v45 then
					v44.CFrame = CFrame.new(v45.Position, v45.Position + v45.Normal)
					v44.Shadow:Emit(10)
				else
					v44.CFrame = p42.Torso.CFrame
					v44.ShadowAir:Emit(10)
				end
				v_u_3:AddItem(v44, 1)
			end
		end,
		["Dash"] = function(p46, p_u_47)
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_14, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3
			local v_u_48 = p46:FindFirstChild("HumanoidRootPart")
			if v_u_48 then
				local v49 = { 0, 6, -6 }
				if v_u_5.Character == p46 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
				for _, v_u_50 in p_u_47:GetChildren() do
					local v_u_51 = v_u_50:FindFirstChild("FolderWeld")
					if v_u_51 then
						v_u_51.Enabled = false
					end
					task.spawn(function()
						-- upvalues: (copy) v_u_50, (copy) v_u_48, (copy) v_u_51, (copy) p_u_47
						v_u_50.Humanoid.WalkSpeed = 48
						repeat
							v_u_50.Humanoid:Move(v_u_48.CFrame.LookVector)
							task.wait()
						until v_u_51.Enabled == true or (v_u_50.HumanoidRootPart.Anchored == true or not p_u_47.Parent)
					end)
				end
				for v52 = 1, 3 do
					v_u_14:PlaySound(v_u_9.Itadori.Rush.Rush, v_u_48, game.SoundService.Effect)
					local v53 = Instance.new("Model")
					local v54 = v_u_6.Utils.Itadori.RushWind:Clone()
					v54.CFrame = v_u_48.CFrame * CFrame.new(v49[v52], -1, 0)
					v54.Parent = v53
					v53.Parent = workspace.Effects
					v53:ScaleTo(0.6)
					v54.Ring:Emit(7)
					v54.Dash1.Dash:Emit(1)
					v54.Dash2.Dash:Emit(1)
					v_u_3:AddItem(v54, 2)
					task.wait(0.1)
				end
			end
		end,
		["Grab"] = function(p55, p56, p57, p_u_58)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_5, (ref) v_u_2
			local v_u_59 = p56:FindFirstChild("HumanoidRootPart")
			if v_u_59 then
				v_u_14:Flash(p56, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_9.Gojo.LapseBlue.Grab, v_u_59, game.SoundService.Effect)
				for v60, v61 in p57:GetChildren() do
					for _, v62 in v61.Humanoid:GetPlayingAnimationTracks() do
						v62:Stop(0)
					end
					v61.Humanoid:LoadAnimation(v_u_7.Megumi["ShadowSwarm" .. v60]):Play(0)
					v61.HumanoidRootPart.CollisionGroup = "NoCollision"
					local v_u_63 = v61:FindFirstChild("FolderWeld")
					if v_u_63 then
						local v_u_64 = v61.HumanoidRootPart
						v_u_64.Anchored = true
						task.spawn(function()
							-- upvalues: (ref) v_u_4, (copy) v_u_63, (copy) v_u_64, (copy) v_u_59
							v_u_4:Create(v_u_63, TweenInfo.new(0), {
								["C0"] = CFrame.new()
							}):Play()
							for _ = 1, 20 do
								v_u_64.CFrame = v_u_64.CFrame:Lerp(v_u_59.CFrame, 0.2)
								task.wait()
							end
							v_u_63.Enabled = true
						end)
					end
				end
				if v_u_5 == p55 then
					local _ = workspace.CurrentCamera
					local v_u_65 = v_u_5.Character
					local v_u_66 = v_u_65.Humanoid
					v_u_65.Head.CollisionGroup = "NoCollision"
					v_u_65.Torso.CollisionGroup = "NoCollision"
					v_u_2:BindToRenderStep("Cam2", Enum.RenderPriority.Camera.Value + 2, function()
						-- upvalues: (copy) v_u_66, (copy) p_u_58, (ref) v_u_2, (copy) v_u_65
						if v_u_66.Parent and p_u_58.Parent then
							local v67 = (v_u_65.HumanoidRootPart.CFrame + v_u_65.HumanoidRootPart.CFrame.UpVector * 1.5):PointToObjectSpace(v_u_65.Head.Position)
							local v68 = v_u_66
							local v69 = v67.X
							local v70 = v67.Z
							v68.CameraOffset = Vector3.new(v69, 0, v70)
						else
							v_u_2:UnbindFromRenderStep("Cam2")
							v_u_65.Head.CollisionGroup = "Default"
							v_u_65.Torso.CollisionGroup = "Default"
						end
					end)
				end
			end
		end,
		["Hit"] = function(p71)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9
			local v72 = p71:FindFirstChild("HumanoidRootPart")
			if v72 then
				local v73 = v_u_8.Gojo.Twofold.Sparks:Clone()
				v73.Parent = p71.Torso
				v73:Emit(20)
				v_u_3:AddItem(v73, 0.4)
				v_u_14:Flash(p71, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 4)), v72, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p74, p75)
			-- upvalues: (ref) v_u_4, (ref) v_u_3
			local v76 = p74:FindFirstChild("HumanoidRootPart")
			if v76 then
				if p75.Parent then
					local v77 = p75.Attachment
					v77.Parent = v76
					v77.Ring:Emit(15)
					v_u_4:Create(v77.Ring, TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
						["TimeScale"] = 1
					}):Play()
					v_u_3:AddItem(v77, 1)
				end
			else
				return
			end
		end,
		["FinalHit"] = function(p78, p79)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5
			local v80 = p79:FindFirstChild("HumanoidRootPart")
			if v80 then
				v_u_14:Flash(p79, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 4)), v80, game.SoundService.Effect)
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				task.wait(0.15)
				v_u_14:PlaySound(v_u_9.Itadori.CraniumSmash.Hit2, v80, game.SoundService.Effect)
				if v_u_5.Character == p79 or v_u_5 == p78 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
			end
		end,
		["Wep"] = function(p_u_81)
			-- upvalues: (ref) v_u_8, (ref) v_u_3
			p_u_81.Destroying:Connect(function()
				-- upvalues: (ref) v_u_8, (copy) p_u_81, (ref) v_u_3
				local v82 = v_u_8.Megumi.Wep:Clone()
				v82.CFrame = p_u_81.CFrame
				v82.CanCollide = true
				v82.Parent = workspace.Effects
				v_u_3:AddItem(v82, 2)
			end)
		end,
		["ForceFix"] = function(p83, p84, p85, p86)
			local v87 = p83:FindFirstChild("HumanoidRootPart")
			if not v87 then
				return
			end
			while true do
				if p84 and (v87.Position - p85).Magnitude > 100 then
					p84:Destroy()
				end
				task.wait()
				if not p86.Parent then
					return
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p89, ...)
		-- upvalues: (copy) v_u_88
		local v90 = v_u_88[p89]
		if v90 then
			v90(...)
		end
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14
	v_u_11 = v_u_1.GetService("ShadowSwarmService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("MovementController")
	v_u_14 = v_u_1.GetController("FXController")
end
return v15