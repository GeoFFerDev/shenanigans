-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
game:GetService("Debris")
v1.Btn = 1
v1.SortOrder = 8
v1.Val = "TTS"
v1.Desc = "text to shenanigans"
local v_u_2 = {
	["Pitch"] = 1,
	["Speed"] = 1,
	["Accent"] = 1,
	["Voice"] = "TTZ"
}
function v1.Callback(p3)
	-- upvalues: (copy) v_u_2
	if p3 == true then
		game:GetService("TextChatService").OnBubbleAdded = function(p4, p5)
			-- upvalues: (ref) v_u_2
			if p4.Status == Enum.TextChatMessageStatus.Success then
				if p5 == nil and p4.TextSource == nil then
					return
				else
					local v6 = p4.TextSource
					if v6 then
						v6 = game.Players:FindFirstChild(p4.TextSource.Name)
					end
					if v6 then
						local _ = v6.Character:GetAttribute("Pitch") or 1
						local v7 = require(script.TextToZee)
						task.spawn(v7.TTS, p4.Text, v6.Character.PrimaryPart, v_u_2)
					elseif p5 and p5:IsA("Instance") then
						local v8 = require(script.TextToZee)
						task.spawn(v8.TTS, p4.Text, p5, v_u_2)
					end
				end
			else
				return
			end
		end
	else
		game:GetService("TextChatService").OnBubbleAdded = nil
	end
end
return v1