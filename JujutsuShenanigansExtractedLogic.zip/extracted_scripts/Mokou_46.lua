-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "mokou",
	["Description"] = "Adds a player temporarily to the whitelist",
	["Group"] = { "Owner", "HeadMod" },
	["Args"] = {
		{
			["Type"] = "player",
			["Name"] = "Player"
		},
		{
			["Type"] = "number",
			["Name"] = "Duration (in minutes)"
		}
	}
}
return v1