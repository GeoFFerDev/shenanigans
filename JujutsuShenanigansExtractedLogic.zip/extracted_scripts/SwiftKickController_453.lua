-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "SwiftKickController"
})
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_12, (ref) v_u_10
	local v_u_46 = {
		["Start"] = function(p15)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_13:PlaySound(v_u_8.Hakari.FeverBreak.Dash, v16, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p17)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_8
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_7.Todo.Swing:Clone()
				v19.Weld.Part0 = v18
				v19.Parent = workspace.Effects
				v_u_3:AddItem(v19, 0.6)
				v19.Core.Wind:Emit(12)
				v_u_4:Create(v19.Weld, TweenInfo.new(0.4), {
					["C1"] = v19.Weld.C1 * CFrame.Angles(0, -3.141592653589793, 0)
				}):Play()
				v_u_4:Create(v19.Beam, TweenInfo.new(0.4), {
					["Width0"] = 0
				}):Play()
				v_u_13:PlaySound(v_u_8.Hakari.Counter.Startup, v18, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_8.Choso.PiercingBlood.Startup, v18, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p20, p21)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9, (ref) v_u_2
			local v_u_22 = p20:FindFirstChild("HumanoidRootPart")
			if v_u_22 then
				v_u_13:PlaySound(v_u_8.Itadori.Rush.Rush, v_u_22, game.SoundService.Effect)
				local v23 = v_u_6.Utils.Itadori.RushWind:Clone()
				v23.CFrame = v_u_22.CFrame
				v23.Parent = workspace.Effects
				v23.Dust:Emit(7)
				v23.Ring:Emit(7)
				v23.Dash1.Dash:Emit(1)
				v23.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v23, 2)
				local v24 = v_u_7.Itadori.Shock:Clone()
				v24.CFrame = v_u_22.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v24.Parent = workspace.Effects
				v_u_4:Create(v24, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v24, 0.2)
				task.delay(0.1, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_22, (ref) v_u_4, (ref) v_u_3
					local v25 = v_u_7.Itadori.Shock:Clone()
					v25.CFrame = v_u_22.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v25.Parent = workspace.Effects
					v_u_4:Create(v25, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v25, 0.2)
				end)
				if v_u_5.Character == p20 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v26 = Instance.new("NumberValue", p21)
					v26.Value = 150
					v_u_4:Create(v26, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["Value"] = 35
					}):Play()
					repeat
						p21.Velocity = v_u_22.CFrame.LookVector * v26.Value
						v_u_2.Stepped:Wait()
					until not (p21.Parent and v_u_22.Parent)
				end
			end
		end,
		["Hit"] = function(p27, p28)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = v_u_7.Gojo.Twofold.Sparks:Clone()
				v30.Parent = v29.RootAttachment
				v30:Emit(20)
				v_u_3:AddItem(v30, 0.4)
				v_u_13:Flash(p28, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v29, game.SoundService.Effect)
				if v_u_5 == p27 or v_u_5.Character == p28 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["Grab"] = function(p31)
			-- upvalues: (ref) v_u_13, (ref) v_u_8
			local v32 = p31:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_13:Flash(p31, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_8.Gojo.LapseBlue.Grab, v32, game.SoundService.Effect)
				task.wait(0.2)
				v_u_13:PlaySound(v_u_8.Mahito.CrushingRushdown.Leap, v32, game.SoundService.Effect)
			end
		end,
		["Aim"] = function(p33, p34)
			-- upvalues: (ref) v_u_12
			local v35 = p33:FindFirstChild("HumanoidRootPart")
			if v35 then
				local v36 = p33:FindFirstChild("Humanoid")
				if v36 then
					local v37 = Instance.new("BodyGyro", v35)
					v37.P = 10000
					v37.MaxTorque = Vector3.new(40000, 40000, 40000)
					p34.Position = v35.Position + Vector3.new(0, 2, 0)
					v36.PlatformStand = true
					repeat
						local v38 = v_u_12:GetMouseTarget(nil, true)
						v37.CFrame = CFrame.new(v35.Position, v38)
						task.wait()
					until not p34.Parent
					v37:Destroy()
					v36.PlatformStand = false
				end
			else
				return
			end
		end,
		["Throw"] = function(p39, p40)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v41 = p39:FindFirstChild("HumanoidRootPart")
			if v41 then
				local v_u_42 = p40:FindFirstChild("HumanoidRootPart")
				if v_u_42 then
					local v43 = v_u_7.Choso.CounterSwing:Clone()
					v43:PivotTo(v41.CFrame * CFrame.new(2, 1, -4))
					v43.Parent = workspace.Effects
					v_u_3:AddItem(v43, 0.3)
					v_u_4:Create(v43.Shock, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(0, 25, 0),
						["Transparency"] = 1
					}):Play()
					v_u_4:Create(v43.Shock2, TweenInfo.new(0.1), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1,
						["Position"] = v43.Shock2.Position + v41.CFrame.LookVector * 3
					}):Play()
					v_u_4:Create(v43.Shockwave, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(0, 30, 0),
						["Transparency"] = 1,
						["CFrame"] = v43.Shockwave.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
					}):Play()
					v_u_13:PlaySound(v_u_8.Mahito.Stockpile.Swing2, v41, game.SoundService.Effect)
					for v44 = 1, 4 do
						task.delay(0.1 * v44, function()
							-- upvalues: (ref) v_u_7, (copy) v_u_42, (ref) v_u_4, (ref) v_u_3
							local v45 = v_u_7.Itadori.Shock:Clone()
							v45.CFrame = CFrame.lookAlong(v_u_42.Position, v_u_42.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
							v45.Parent = workspace.Effects
							v_u_4:Create(v45, TweenInfo.new(0.15), {
								["Size"] = Vector3.new(10, 0, 10),
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v45, 0.15)
						end)
					end
					if v_u_5.Character == p39 or v_u_5.Character == p40 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p47, ...)
		-- upvalues: (copy) v_u_46
		local v48 = v_u_46[p47]
		if v48 then
			v48(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
	v_u_10 = v_u_1.GetService("SwiftKickService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("ToolController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14