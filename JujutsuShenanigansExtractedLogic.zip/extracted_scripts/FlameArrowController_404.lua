-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "FlameArrowController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10
	local v_u_35 = {
		["HotHands"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_4
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_8.Itadori.FireArrow.Hands, v14, game.SoundService.Effect)
				local v15 = v_u_6.Utils.Itadori.FireArrow.HotHands:Clone()
				v15.Parent = workspace.Effects
				v15.Weld.Part0 = p13["Left Arm"]
				v_u_3:AddItem(v15, 2)
				local v16 = v_u_6.Utils.Itadori.FireArrow.HotHands:Clone()
				v16.Parent = workspace.Effects
				v16.Weld.Part0 = p13["Right Arm"]
				v_u_3:AddItem(v16, 2)
				v_u_4:Create(v15, TweenInfo.new(0.6), {
					["Transparency"] = 0
				}):Play()
				v_u_4:Create(v16, TweenInfo.new(0.6), {
					["Transparency"] = 0
				}):Play()
				task.wait(0.8)
				v15.Flames.Enabled = false
				v16.Flames.Enabled = false
				v_u_4:Create(v15, TweenInfo.new(0.3), {
					["Transparency"] = 1
				}):Play()
				v_u_4:Create(v16, TweenInfo.new(0.3), {
					["Transparency"] = 1
				}):Play()
			end
		end,
		["Clap"] = function(p17)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9, (ref) v_u_11, (ref) v_u_8
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_7.Itadori.FireArrow.FireClap:Clone()
				v19.Parent = workspace.Effects
				v19.Weld.Part0 = v18
				v_u_3:AddItem(v19, 1)
				v_u_4:Create(v19.PointLight, TweenInfo.new(1), {
					["Color"] = Color3.new(1, 0, 0),
					["Brightness"] = 0
				}):Play()
				v19.Dust:Emit(2)
				v19.Smash:Emit(4)
				v19.Flames:Emit(30)
				if v_u_5.Character == p17 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
				v_u_11:PlaySound(v_u_8.Itadori.FireArrow.Clap, v18, game.SoundService.Effect)
			end
		end,
		["Arrow"] = function(p20, p21)
			-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_8
			local v22 = p21.Spike1
			local v23 = p21.Spike2
			v22.Parent = p20["Right Arm"]
			v23.Parent = p20["Right Arm"]
			p21.Attachment1.Parent = p20["Right Arm"]
			task.wait(0.2)
			v_u_4:Create(p21.PointLight, TweenInfo.new(2), {
				["Brightness"] = 20,
				["Range"] = 30
			}):Play()
			task.wait(0.5)
			p21.Attachment0.Flare:Emit(3)
			p21.Attachment0.Heat.Enabled = true
			v_u_4:Create(v22, TweenInfo.new(1.6, Enum.EasingStyle.Back, Enum.EasingDirection.InOut), {
				["Position"] = Vector3.new(2, 2, -3.4)
			}):Play()
			v_u_4:Create(v23, TweenInfo.new(1.6, Enum.EasingStyle.Back, Enum.EasingDirection.InOut), {
				["Position"] = Vector3.new(2, 2, 2.6)
			}):Play()
			v_u_11:PlaySound(v_u_8.Itadori.FireArrow.Arrow, p21, game.SoundService.Effect)
			v_u_4:Create(v_u_11:PlaySound(v_u_8.Itadori.FireArrow.Idle, p21, game.SoundService.Effect), TweenInfo.new(1), {
				["Volume"] = 1
			}):Play()
		end,
		["Fire"] = function(p24)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_11, (ref) v_u_8
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				if v_u_5.Character == p24 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				v_u_11:PlaySound(v_u_8.Itadori.FireArrow.Fire, v25, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p_u_26)
			-- upvalues: (ref) v_u_2
			local v_u_27 = p_u_26.CFrame
			local v_u_28 = tick()
			local v_u_29 = p_u_26:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_27, (copy) p_u_26, (ref) v_u_28
				v_u_27 = p_u_26.CFrame
				v_u_28 = tick()
			end)
			local v_u_30 = nil
			v_u_30 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_26, (ref) v_u_30, (copy) v_u_29, (ref) v_u_27, (ref) v_u_28
				if p_u_26.Parent then
					workspace:BulkMoveTo({ p_u_26 }, { v_u_27 + v_u_27.LookVector * (192 * (tick() - v_u_28)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_30:Disconnect()
					v_u_29:Disconnect()
				end
			end)
		end,
		["Burn"] = function(p31)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_11, (ref) v_u_8
			local v32 = v_u_7.Itadori.FireArrow.Burn:Clone()
			v32.Parent = workspace.Effects
			v32.Position = p31
			v_u_3:AddItem(v32, 3)
			v32.Center.Wind2:Emit(25)
			v32.Flames:Emit(200)
			v_u_4:Create(v32, TweenInfo.new(0.75), {
				["Size"] = Vector3.new(0, 250, 0),
				["CFrame"] = v32.CFrame * CFrame.Angles(0, 3.141592653589793, 0)
			}):Play()
			v_u_4:Create(v32.Beam, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.In), {
				["Width0"] = 0,
				["Width1"] = 0
			}):Play()
			v_u_4:Create(v32.Lines, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.In), {
				["Width0"] = 0,
				["Width1"] = 0
			}):Play()
			v_u_11:PlaySound(v_u_8.Itadori.FireArrow.Explode, v32, game.SoundService.Effect)
		end,
		["Finisher"] = function(p33)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			if p33.HumanoidRootPart then
				v_u_11:Burn(p33)
				for _, v34 in p33:GetChildren() do
					if v34:IsA("BasePart") then
						v_u_7.Damage.Flames:Clone().Parent = v34
					end
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p36, ...)
		-- upvalues: (copy) v_u_35
		local v37 = v_u_35[p36]
		if v37 then
			v37(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("FlameArrowService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12