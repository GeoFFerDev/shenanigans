-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "SeveranceKickController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_41 = {
		["Swing"] = function(p12, p13)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v14 = p12:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_10:PlaySound(p13 and v_u_7.Nanami.SeveranceKick.WhooshBack or v_u_7.Nanami.SeveranceKick.WhooshFront, v14, game.SoundService.Effect)
			end
		end,
		["Whoosh"] = function(p15, p16)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				local v18 = v17.CFrame
				if p16 then
					v18 = v17.CFrame * CFrame.Angles(0, 3.141592653589793, 0)
				end
				local v19 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				local v20 = Instance.new("Model")
				v19.Parent = v20
				v20:ScaleTo(0.7)
				v_u_2:AddItem(v20, 0.2)
				v19.CFrame = v18 * (p16 and CFrame.new(0, 0, -4) or CFrame.new(0, 0, -5))
				v19.Parent = workspace.Effects
				v19.Wind:Emit(10)
				v19.PointLight:Destroy()
				v19.Wind.Lifetime = NumberRange.new(0.9, 1.5)
				v19.Back1.Back.Size = NumberSequence.new(0)
				v19.Back2.Back.Size = NumberSequence.new(0)
				v_u_2:AddItem(v19, 3)
				local v21 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v21.Size = Vector3.new(3, 15, 3)
				v21.CFrame = v18 * CFrame.Angles(1.5707963267948966, 0, 0)
				v21.Parent = workspace.Effects
				v_u_2:AddItem(v21, 0.2)
				v_u_3:Create(v21, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(17.5, 0, 17.5),
					["Transparency"] = 1,
					["Position"] = v21.Position + v18.LookVector * 10
				}):Play()
			end
		end,
		["Hit"] = function(p_u_22, p_u_23, p_u_24, p_u_25, p26)
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v27 = p_u_22:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v_u_28 = p_u_23:FindFirstChild("HumanoidRootPart")
				if v_u_28 then
					if p_u_22 == v_u_4.Character or p_u_23 == v_u_4.Character then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					end
					local v_u_29 = v_u_6.Nanami.SeveranceHit:Clone()
					v_u_29.Parent = workspace.Effects
					v_u_29.CFrame = CFrame.lookAt(v27.Position, v27.Position + p26) * CFrame.new(0, 0, -4)
					v_u_2:AddItem(v_u_29, 1.2)
					local v30 = TweenInfo.new(0.15, Enum.EasingStyle.Circular, Enum.EasingDirection.In)
					local v_u_31 = v_u_3:Create(v_u_29, v30, {
						["Size"] = Vector3.new(4, 4, 4),
						["Transparency"] = 0
					})
					v_u_31:Play()
					for _, v32 in v_u_29.Beams:GetChildren() do
						v_u_3:Create(v32, v30, {
							["Position"] = v32.Position + Vector3.new(0, 0, 9)
						}):Play()
					end
					v_u_10:Flash(p_u_23, Color3.new(0.333333, 0.666667, 1), 0.2)
					v_u_10:PlaySound(v_u_7.Nanami.CrossCut.Hit2, v_u_28, game.SoundService.Effect)
					local v_u_33 = v27:FindFirstChild("WhooshBack") or v27:FindFirstChild("WhooshFront")
					if v_u_33 then
						v_u_33.PlaybackSpeed = 0
					end
					if p_u_22 == v_u_4.Character or p_u_23 == v_u_4.Character then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
					task.delay(p_u_25 and 0.35 or 0.2, function()
						-- upvalues: (copy) v_u_31, (copy) v_u_29, (ref) v_u_3, (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (copy) p_u_23, (copy) v_u_33, (copy) p_u_25, (ref) v_u_7, (copy) v_u_28, (copy) p_u_24, (copy) p_u_22, (ref) v_u_4, (ref) v_u_8
						local v34 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
						v_u_31:Cancel()
						v_u_29.Transparency = 1
						for _, v35 in v_u_29.Beams:GetChildren() do
							v_u_3:Create(v35, v34, {
								["Position"] = v35.Position + Vector3.new(0, 0, 25)
							}):Play()
							v35.Beam.TextureSpeed = 4
							v_u_3:Create(v35.Beam, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
								["Width0"] = 0,
								["Width1"] = 0,
								["TextureSpeed"] = 1
							}):Play()
						end
						v_u_29.Hit.Sparks:Emit(10)
						v_u_29.Hit.Wind2:Emit(6)
						v_u_3:Create(v_u_29.PointLight, TweenInfo.new(0.5), {
							["Brightness"] = 0
						}):Play()
						v_u_3:Create(v_u_29, v34, {
							["CFrame"] = v_u_29.CFrame + v_u_29.CFrame.LookVector * 12
						}):Play()
						v_u_29.Wind:Emit(6)
						v_u_29.Back1.Back:Emit(1)
						v_u_29.Back2.Back:Emit(1)
						v_u_3:Create(v_u_29.Back1, TweenInfo.new(0.4), {
							["CFrame"] = v_u_29.Back1.CFrame - v_u_29.Back1.CFrame.LookVector * 20
						}):Play()
						v_u_3:Create(v_u_29.Back2, TweenInfo.new(0.4), {
							["CFrame"] = v_u_29.Back2.CFrame - v_u_29.Back2.CFrame.LookVector * 20
						}):Play()
						local v36 = v_u_6.Choso.CounterSwing.Shock:Clone()
						v36.Size = Vector3.new(30, 6, 30)
						v36.CFrame = v_u_29.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
						v36.Parent = workspace.Effects
						v_u_2:AddItem(v36, 0.4)
						v_u_3:Create(v36, TweenInfo.new(0.4), {
							["Size"] = Vector3.new(0, 30, 0),
							["Transparency"] = 1,
							["Position"] = v36.Position + v_u_29.CFrame.LookVector * 10
						}):Play()
						v_u_10:Flash(p_u_23, Color3.new(0.333333, 0.666667, 1), 0.6)
						if v_u_33 then
							v_u_33.PlaybackSpeed = 1
						end
						if p_u_25 then
							v_u_10:PlaySound(v_u_7.Nanami.SeveranceKick.HitBackStun, v_u_28, game.SoundService.Effect)
						else
							v_u_10:PlaySound(p_u_24 and v_u_7.Nanami.SeveranceKick.HitBack or v_u_7.Nanami.SeveranceKick.HitFront, v_u_28, game.SoundService.Effect)
						end
						if p_u_22 == v_u_4.Character or p_u_23 == v_u_4.Character then
							v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
						end
					end)
				end
			else
				return
			end
		end,
		["ThrowableWind"] = function(p37)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v38 = p37:FindFirstChild("HumanoidRootPart")
			if v38 then
				v_u_10:PlaySound(v_u_7.Yuta.PunchSwing, v38, game.SoundService.Effect)
			end
		end,
		["ThrowableHit"] = function(p39, _)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_8
			local v40 = p39:FindFirstChild("HumanoidRootPart")
			if v40 then
				v_u_10:PlaySound(v_u_7.Yuta.MetalHit, v40, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Hakari.Impact, v40, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v40.Position).Magnitude < 150 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p42, ...)
		-- upvalues: (copy) v_u_41
		local v43 = v_u_41[p42]
		if v43 then
			v43(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("SeveranceKickService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11