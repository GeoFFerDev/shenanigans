-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(script.Parent.Parent.Trove)
local v_u_2 = require(script.Parent.Parent.Signal)
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = {}
v_u_4.__index = v_u_4
function v_u_4.new()
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_2, (copy) v_u_3
	local v5 = v_u_4
	local v6 = setmetatable({}, v5)
	v6._trove = v_u_1.new()
	v6.TouchTap = v6._trove:Construct(v_u_2.Wrap, v_u_3.TouchTap)
	v6.TouchTapInWorld = v6._trove:Construct(v_u_2.Wrap, v_u_3.TouchTapInWorld)
	v6.TouchMoved = v6._trove:Construct(v_u_2.Wrap, v_u_3.TouchMoved)
	v6.TouchLongPress = v6._trove:Construct(v_u_2.Wrap, v_u_3.TouchLongPress)
	v6.TouchPan = v6._trove:Construct(v_u_2.Wrap, v_u_3.TouchPan)
	v6.TouchPinch = v6._trove:Construct(v_u_2.Wrap, v_u_3.TouchPinch)
	v6.TouchRotate = v6._trove:Construct(v_u_2.Wrap, v_u_3.TouchRotate)
	v6.TouchSwipe = v6._trove:Construct(v_u_2.Wrap, v_u_3.TouchSwipe)
	v6.TouchStarted = v6._trove:Construct(v_u_2.Wrap, v_u_3.TouchStarted)
	v6.TouchEnded = v6._trove:Construct(v_u_2.Wrap, v_u_3.TouchEnded)
	return v6
end
function v_u_4.IsTouchEnabled(_)
	-- upvalues: (copy) v_u_3
	return v_u_3.TouchEnabled
end
function v_u_4.Destroy(p7)
	p7._trove:Destroy()
end
return v_u_4