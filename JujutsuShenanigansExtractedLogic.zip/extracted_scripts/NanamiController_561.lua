-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "NanamiController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (copy) v_u_6, (copy) v_u_2, (ref) v_u_10, (ref) v_u_11
	local v_u_102 = {
		["Hit"] = function(p14, p15, p16, p17, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			if p14:FindFirstChild("HumanoidRootPart") then
				local v18 = p15:FindFirstChild("HumanoidRootPart")
				if v18 then
					local v19 = p14:GetAttribute("InUlt")
					v_u_12:Flash(p15, Color3.new(1, 1, 1))
					if p17 == "Down" or p17 == "Up" and v19 or p17 ~= "Up" and (v19 and (p16 == 1 or p16 == 3)) then
						v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. p16), v18, game.SoundService.Effect)
						return
					elseif p17 == "Up" then
						v_u_12:PlaySound(v_u_8.Nanami.M1.Up, v18, game.SoundService.Effect)
					else
						v_u_12:PlaySound(v_u_8.Nanami.M1:FindFirstChild("Hit" .. p16), v18, game.SoundService.Effect)
					end
				else
					return
				end
			else
				return
			end
		end,
		["BlackFlashHit"] = function(p20, p21)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			if p20:FindFirstChild("HumanoidRootPart") then
				local v22 = p21:FindFirstChild("HumanoidRootPart")
				if v22 then
					local v23 = v_u_7.Itadori.PerfectHit:Clone()
					v23.Position = v22.Position
					v23.Parent = workspace.Effects
					v_u_3:AddItem(v23, 1)
					v_u_12:Flash(p21, Color3.new(1, 0, 0))
					v_u_12:PlaySound(v_u_8.Nanami.BlackFlash, v22, game.SoundService.Effect)
					v23.Wind2:Emit(8)
					v23.Lightning:Emit(6)
					v23.Sparks:Emit(15)
					v23.Sparks2:Emit(20)
					v_u_4:Create(v23.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					if v_u_5.Character == p20 or v_u_5.Character == p21 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["ChaseHit"] = function(p24, p25)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v26 = p24:FindFirstChild("HumanoidRootPart")
			if v26 then
				local v27 = p25:FindFirstChild("HumanoidRootPart")
				if v27 then
					v_u_12:Flash(p25, Color3.new(1, 1, 1))
					v_u_12:PlaySound(p24:GetAttribute("InUlt") and v_u_8.Gojo.M1:FindFirstChild("Hit3") or v_u_8.Nanami.M1:FindFirstChild("Hit3"), v27, game.SoundService.Effect)
					local v28 = v_u_7.ChaseHit:Clone()
					local v29 = CFrame.new
					local v30 = v27.Position
					local v31 = v26.Position.X
					local v32 = v27.Position.Y
					local v33 = v26.Position.Z
					v28.CFrame = v29(v30, (Vector3.new(v31, v32, v33))) * CFrame.Angles(0, 3.141592653589793, 0)
					v28.Parent = workspace.Effects
					v28.Ring:Emit(7)
					v28.Sparks:Emit(12)
					v_u_3:AddItem(v28, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p34)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v35 = p34.HumanoidRootPart
			if v35 then
				local v36 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v36.CFrame = v35.CFrame * CFrame.new(0, 1, -4)
				v36.Size = Vector3.new(0, 0, 2)
				v36.Parent = workspace.Effects
				v_u_4:Create(v36, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v36, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v35, game.SoundService.Effect)
				v_u_12:DustTrail(p34, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Ultimate"] = function(p37)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v38 = p37:FindFirstChild("HumanoidRootPart")
			if v38 then
				v_u_12:PlaySound(v_u_8.Nanami.Ultimate, v38, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p39)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v40 = p39:FindFirstChild("HumanoidRootPart")
			if v40 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v40, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p_u_41, p42, p43)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12
			local function v47(p44)
				-- upvalues: (copy) p_u_41, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
				local v45 = p_u_41.SetAssets:FindFirstChild("NanamiCleaver")
				if v45 then
					local v46 = v_u_7.Nanami.CombatTrail:Clone()
					v46.Weld.Part0 = v45.Blade
					v46.Parent = workspace.Effects
					task.wait(p44 or 0.35)
					v46.Trail.Enabled = false
					v_u_4:Create(v46, TweenInfo.new(0.1), {
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v46, 0.2)
				end
			end
			if p43 == "Down" then
				if p_u_41:GetAttribute("InUlt") then
					v_u_12:ArmFlash(p_u_41["Right Arm"], Color3.fromRGB(129, 168, 203), 0.4)
				else
					v_u_12:ArmFlash(p_u_41["Right Leg"], Color3.fromRGB(129, 168, 203), 0.4)
				end
			elseif p_u_41:GetAttribute("InUlt") then
				if p42 == 1 or (p42 == 3 or p42 == 4 and p43 == "Air") then
					v_u_12:ArmFlash(p_u_41["Right Arm"], Color3.fromRGB(129, 168, 203), p42 == 4 and 0.45 or false)
				else
					v47()
				end
			else
				v47(p42 == 4 and 0.45 or false)
				return
			end
		end,
		["Launch"] = function(p48, p49)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v50 = p48:FindFirstChild("HumanoidRootPart")
			if v50 then
				local v51 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v51.CFrame = CFrame.new(v50.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v51.Size = Vector3.new(0, 0, 5)
				v51.Parent = workspace.Effects
				v_u_4:Create(v51, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v51.Position + Vector3.new(0, p49, 0)
				}):Play()
				v_u_3:AddItem(v51, 0.3)
				if p49 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v50, game.SoundService.Effect)
					v_u_12:DustBreak(v50.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v50.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["EyeFlash"] = function(_, p52)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				local v54 = v_u_6.Utils.Itadori.EyeTrails:Clone()
				v54.Eye1:Destroy()
				v54.Trail1:Destroy()
				v54.Weld.Part0 = p52.Head
				v54.Parent = workspace.Effects
				v54.Sparks.Color = ColorSequence.new(Color3.fromRGB(129, 168, 203))
				v54.Eye2.Glow.Color = ColorSequence.new(Color3.fromRGB(129, 168, 203))
				v54.Glow:Emit(1)
				v54.Trail2.Trail.Enabled = false
				v54.Eye2.Glow.Enabled = false
				v54.Sparks:Emit(15)
				v54.Eye2.Glow:Emit(1)
				v_u_3:AddItem(v54, 0.5)
				v_u_12:PlaySound(v_u_8.Nanami.EyeFlash, v53, game.SoundService.Effect)
			end
		end,
		["Chat"] = function(p55)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v56 = p55:FindFirstChild("Torso")
			if v56 then
				local v57 = v_u_7.Nanami.Dialogue:Clone()
				v57.Parent = v56
				local v58 = v57.Text1.Position
				v57.Text1.Position = v58 - UDim2.new(0, 0, 0.1, 0)
				v57.Text1.TextTransparency = 0
				v_u_4:Create(v57.Text1, TweenInfo.new(3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v58
				}):Play()
				v_u_4:Create(v57.Text1, TweenInfo.new(2), {
					["TextTransparency"] = 1
				}):Play()
				task.wait(0.75)
				local v59 = v57.Chat1.Position
				v57.Chat1.Position = v59 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v57.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v59
				}):Play()
				v_u_4:Create(v57.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v57.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(1.5)
				v_u_3:AddItem(v57, 4)
				local v60 = v57.Chat2.Position
				v57.Chat2.Position = v60 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v57.Chat2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v60
				}):Play()
				v_u_4:Create(v57.Chat2, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v57.Chat2.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(1)
				for _, v61 in v57:GetDescendants() do
					if v61:IsA("Frame") then
						v_u_4:Create(v61, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = v61.Position - UDim2.new(0, 0, 0.1, 0),
							["BackgroundTransparency"] = 1
						}):Play()
					elseif v61:IsA("TextLabel") then
						v_u_4:Create(v61, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["SpawnRatio"] = function(p_u_62, p63, p_u_64, p_u_65, p_u_66, p_u_67)
			-- upvalues: (ref) v_u_5, (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_2
			local v_u_68 = p63:FindFirstChild("HumanoidRootPart")
			if v_u_68 then
				if p_u_62 == v_u_5 then
					p_u_64.Enabled = true
					p_u_64.StudsOffset = Vector3.new(0, 3.5, 3)
					v_u_12:PlaySound(v_u_8.Nanami.Ratio.Appear, v_u_68, game.SoundService.Effect)
					local v_u_69 = math.random(1, 2) == 1 and -1 or 1
					local v70 = (workspace.CurrentCamera.CFrame.Position - v_u_68.Position).Magnitude / 35
					local v_u_71 = math.clamp(v70, 1, 5.5)
					if p_u_62 ~= v_u_5 then
						local v72 = (workspace.CurrentCamera.CFrame.Position - v_u_68.Position).Magnitude / 10
						v_u_71 = math.clamp(v72, 1, 5.5) * 0.25
					end
					p_u_64.Bar.Rotation = -180 * v_u_69
					p_u_64.Size = UDim2.fromScale(v_u_71 * 15, v_u_71 * 2.25)
					local v_u_73 = v_u_4:Create(p_u_64.Bar, TweenInfo.new(p_u_66, Enum.EasingStyle.Exponential), {
						["Rotation"] = 90 * v_u_69
					})
					v_u_73:Play()
					local v74 = v_u_4:Create(p_u_64, TweenInfo.new(0.4), {
						["Size"] = UDim2.fromScale(v_u_71 * 10, v_u_71 * 1.5)
					})
					v74:Play()
					v_u_4:Create(p_u_64.Bar.Cursor, TweenInfo.new(0.2), {
						["ImageTransparency"] = 0.15
					}):Play()
					v74.Completed:Connect(function()
						-- upvalues: (ref) v_u_71, (copy) v_u_68, (copy) p_u_62, (ref) v_u_5, (copy) p_u_64
						task.spawn(function()
							-- upvalues: (ref) v_u_71, (ref) v_u_68, (ref) p_u_62, (ref) v_u_5, (ref) p_u_64
							while true do
								local v75 = (workspace.CurrentCamera.CFrame.Position - v_u_68.Position).Magnitude / 35
								v_u_71 = math.clamp(v75, 1, 5.5)
								if p_u_62 ~= v_u_5 then
									local v76 = (workspace.CurrentCamera.CFrame.Position - v_u_68.Position).Magnitude / 10
									v_u_71 = math.clamp(v76, 1, 5.5) * 0.25
								end
								p_u_64.Size = UDim2.fromScale(v_u_71 * 10, v_u_71 * 1.5)
								task.wait()
								if p_u_64.Parent == nil then
									return
								end
							end
						end)
					end)
					local v_u_77 = p_u_64:WaitForChild("Bar")
					local v_u_78 = nil
					v_u_78 = v_u_2.RenderStepped:Connect(function()
						-- upvalues: (copy) p_u_64, (copy) p_u_65, (copy) v_u_77, (copy) v_u_73, (ref) v_u_4, (copy) v_u_69, (ref) v_u_12, (ref) v_u_8, (copy) v_u_68, (ref) v_u_78, (copy) p_u_67, (copy) p_u_66
						if p_u_64.Parent and (p_u_65.Value ~= true and p_u_65.Parent ~= nil) then
							local v79 = (workspace:GetServerTimeNow() - p_u_67) / p_u_66
							v_u_77.Cursor.Position = UDim2.fromScale(0.5, 1 - v79)
						else
							if p_u_64.Parent then
								v_u_77.Cursor.Position = UDim2.fromScale(0.5, 1 - p_u_65:GetAttribute("CurrentTiming"))
							end
							if p_u_65.Value and p_u_64.Parent then
								v_u_73:Cancel()
								p_u_64.Bar.Cursor.Size = UDim2.fromScale(p_u_64.Bar.Cursor.Size.X.Scale * 2, p_u_64.Bar.Cursor.Size.Y.Scale * 2)
								v_u_4:Create(p_u_64.Bar.Cursor, TweenInfo.new(0.25), {
									["Position"] = UDim2.fromScale(0.5, 0.30000000000000004),
									["Size"] = UDim2.fromScale(p_u_64.Bar.Cursor.Size.X.Scale * 0.5, p_u_64.Bar.Cursor.Size.Y.Scale * 0.5)
								}):Play()
								v_u_4:Create(p_u_64, TweenInfo.new(0.25, Enum.EasingStyle.Exponential), {
									["StudsOffset"] = Vector3.new(0, 0, 3)
								}):Play()
								v_u_4:Create(p_u_64.Bar, TweenInfo.new(0.25, Enum.EasingStyle.Exponential), {
									["Rotation"] = (90 + math.random(-15, 15)) * v_u_69
								}):Play()
								v_u_12:PlaySound(v_u_8.Nanami.Ratio.Success, v_u_68, game.SoundService.Effect)
							end
							v_u_78:Disconnect()
						end
					end)
				else
					p_u_64.Enabled = false
				end
			else
				return
			end
		end,
		["DestroyRatio"] = function(p80, p81, p82, p83)
			-- upvalues: (ref) v_u_7, (ref) v_u_5, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9, (ref) v_u_12, (ref) v_u_8
			local v84 = p81:FindFirstChild("HumanoidRootPart")
			if v84 then
				if p83 then
					local v85 = p82:Clone()
					v85.Name = "RatioVisual"
					p82:Destroy()
					local v_u_86 = v_u_7.Nanami.SplitRatio:Clone()
					if p80 == v_u_5 or p81 == v_u_5.Character then
						v_u_86.Left.Ratio.AlwaysOnTop = true
						v_u_86.Part.Ratio.AlwaysOnTop = true
						v85.AlwaysOnTop = true
						local v_u_87 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v_u_87.TintColor = Color3.fromRGB(60, 60, 60)
						v_u_87.Brightness = -0.8
						v_u_87.Contrast = 0
						v_u_87.Saturation = 0
						v_u_87.Parent = game.Lighting
						task.spawn(function()
							-- upvalues: (copy) v_u_87, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9, (copy) v_u_86
							task.wait(0.04)
							task.wait(0.04)
							v_u_87.Brightness = -0.6
							v_u_4:Create(v_u_87, TweenInfo.new(0.2), {
								["Brightness"] = 0,
								["TintColor"] = Color3.new(1, 1, 1)
							}):Play()
							v_u_3:AddItem(v_u_87, 0.2)
							v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
							task.wait(0.2)
							v_u_86.Left.Ratio.AlwaysOnTop = false
							v_u_86.Part.Ratio.AlwaysOnTop = false
						end)
					end
					v85.Enabled = true
					v85.Parent = v84
					v85.Bar.Visible = true
					v85.Bar.Cursor.ImageColor3 = Color3.fromRGB(255, 0, 0)
					local v88 = v85.StudsOffset
					local v89 = 1
					for _ = 1, 3 do
						local v90 = math.random(-5, 5) / 10
						local v91 = math.random(-5, 5) / 10
						local v92 = v88.Z
						v85.StudsOffset = Vector3.new(v90, v91, v92)
						v85.Size = UDim2.fromScale(v85.Size.X.Scale * 1.04, v85.Size.Y.Scale * 1.04)
						v89 = v89 * 1.04
						task.wait(0.02666666666666667)
					end
					v85:Destroy()
					v_u_12:PlaySound(v_u_8.Nanami.Ratio.Break, v84, game.SoundService.Effect)
					local v93 = v_u_7.Nanami.RatioBreak:Clone()
					v93.Parent = v84
					v_u_3:AddItem(v93, 2)
					for _, v94 in pairs(v93:GetDescendants()) do
						if v94:IsA("ParticleEmitter") then
							v94:Emit(v94:GetAttribute("EmitCount"))
						end
					end
					local v95 = (workspace.CurrentCamera.CFrame.Position - v84.Position).Magnitude / 35
					local v96 = math.clamp(v95, 1, 5.5)
					if p80 ~= v_u_5 then
						local v97 = (workspace.CurrentCamera.CFrame.Position - v84.Position).Magnitude / 10
						v96 = math.clamp(v97, 1, 5.5) * 0.25
					end
					v_u_86.Parent = workspace.Effects
					v_u_86:PivotTo(v84.CFrame)
					for _, v98 in pairs(v_u_86:GetChildren()) do
						local v99 = v98.Name == "Left" and -1 or 1
						v98.Ratio.Size = UDim2.fromScale(v96 * 5 * v89, v96 * 1.5 * v89)
						v98.AssemblyLinearVelocity = CFrame.lookAt(workspace.CurrentCamera.CFrame.Position, v84.Position).RightVector * (v99 * 25) + Vector3.new(0, 40, 0)
						v_u_4:Create(v98.Ratio.Bar, TweenInfo.new(0.8), {
							["Rotation"] = 90 - v99 * math.random(90, 360)
						}):Play()
					end
					v_u_3:AddItem(v_u_86, 1)
					v85:Destroy()
				elseif v_u_5 == p80 then
					v_u_12:PlaySound(v_u_8.Nanami.Ratio.Disappear, v84, game.SoundService.Effect)
					p82.Bar.Cursor.Visible = false
					v_u_4:Create(p82.Bar.Bar, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
						["ImageTransparency"] = 1,
						["Size"] = UDim2.fromScale(0, p82.Bar.Bar.Size.Y)
					}):Play()
				end
			else
				return
			end
		end,
		["Dismember"] = function(p100)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v101 = p100:FindFirstChild("HumanoidRootPart")
			if v101 then
				v_u_12:PlaySound(v_u_8.Nanami.Dismember, v101, game.SoundService.Effect)
			end
		end
	}
	v_u_10.Effects:Connect(function(p103, ...)
		-- upvalues: (copy) v_u_102
		local v104 = v_u_102[p103]
		if v104 then
			v104(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p105, p106, p107)
		-- upvalues: (ref) v_u_11, (ref) v_u_4
		local v108 = p106.HumanoidRootPart
		if not v108 then
			return
		end
		local v109 = nil
		while true do
			local v110 = v_u_11:SphereHitbox(p106, CFrame.new(0, 0, -4), 8)
			for _, v111 in v110 do
				local v112 = v111:FindFirstChild("Info")
				if v112 then
					local v113 = v112:FindFirstChild("Knockback")
					if not v113 or v113.Value ~= false then
						v109 = v110
						break
					end
				end
			end
			if v109 then
				local v114 = p105:FindFirstChildWhichIsA("NumberValue")
				if v114 then
					v_u_4:Create(v114, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p105.Parent then
				break
			end
		end
		p107:FireServer(v109, v108.CFrame)
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("NanamiService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13