-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
local v_u_11 = require(v6.Modules.BloodyZee)
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "CharlesController"
})
function v15.KnitStart(_)
	-- upvalues: (ref) v_u_14, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_10, (copy) v_u_2, (copy) v_u_7, (copy) v_u_11, (ref) v_u_12, (ref) v_u_13
	local v_u_149 = {
		["Hit"] = function(p16, p17, p18)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			if p16:FindFirstChild("HumanoidRootPart") then
				local v19 = p17:FindFirstChild("HumanoidRootPart")
				if v19 then
					v_u_14:Flash(p17, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_9.Charles.M1:FindFirstChild("Hit" .. p18), v19, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["ChaseHit"] = function(p20, p21)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v22 = p20:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = p21:FindFirstChild("HumanoidRootPart")
				if v23 then
					v_u_14:Flash(p21, Color3.new(1, 1, 1))
					v_u_14:PlaySound(v_u_9.Charles.M1:FindFirstChild("Hit3"), v23, game.SoundService.Effect)
					local v24 = v_u_8.ChaseHit:Clone()
					local v25 = CFrame.new
					local v26 = v23.Position
					local v27 = v22.Position.X
					local v28 = v23.Position.Y
					local v29 = v22.Position.Z
					v24.CFrame = v25(v26, (Vector3.new(v27, v28, v29))) * CFrame.Angles(0, 3.141592653589793, 0)
					v24.Parent = workspace.Effects
					v24.Ring:Emit(7)
					v24.Sparks:Emit(12)
					v_u_3:AddItem(v24, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p30)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9
			local v31 = p30.HumanoidRootPart
			if v31 then
				local v32 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v32.CFrame = v31.CFrame * CFrame.new(0, 1, -4)
				v32.Size = Vector3.new(0, 0, 2)
				v32.Parent = workspace.Effects
				v_u_4:Create(v32, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v32, 0.3)
				v_u_14:PlaySound(v_u_9.Misc.Chase, v31, game.SoundService.Effect)
				v_u_14:DustTrail(p30, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p33, _)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v34 = p33:FindFirstChild("HumanoidRootPart")
			if v34 then
				v_u_14:PlaySound(v_u_9.Misc.Swing.Fist, v34, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p35, p36, p37)
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			if p35.HumanoidRootPart then
				local v38 = game.Players:GetPlayerFromCharacter(p35)
				local v39 = not v38 and 0 or (v38:GetAttribute("Ultimate") or 0) / 100
				local v40 = Color3.fromRGB(255, 255, 255):Lerp(Color3.fromRGB(85, 0, 0), v39)
				if p37 == "Down" or p36 == 4 and not p37 then
					v_u_14:ArmFlash(p35["Right Leg"], v40, 0.4)
					return
				elseif p37 == "Up" then
					v_u_14:ArmFlash(p35["Right Arm"], v40, 0.3)
				else
					local v41 = p35.SetAssets:FindFirstChild("GWarstaff")
					if v41 then
						local v42 = v_u_8.Charles.CombatTrail:Clone()
						v42.Color = v40
						v42.Trail.Color = ColorSequence.new(v40)
						v42.Weld.Part0 = v41
						v42.Parent = workspace.Effects
						task.wait(0.35)
						v42.Trail.Enabled = false
						v_u_4:Create(v42, TweenInfo.new(0.1), {
							["Transparency"] = 1
						}):Play()
						v_u_3:AddItem(v42, 0.2)
					end
				end
			else
				return
			end
		end,
		["Launch"] = function(p43, p44)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v45 = p43:FindFirstChild("HumanoidRootPart")
			if v45 then
				local v46 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v46.CFrame = CFrame.new(v45.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v46.Size = Vector3.new(0, 0, 5)
				v46.Parent = workspace.Effects
				v_u_4:Create(v46, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v46.Position + Vector3.new(0, p44, 0)
				}):Play()
				v_u_3:AddItem(v46, 0.3)
				if p44 < 0 then
					v_u_14:PlaySound(v_u_9.Megumi.Mahoraga.Throw.Break, v45, game.SoundService.Effect)
					v_u_14:DustBreak(v45.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v45.Position) < 20 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
				end
			end
		end,
		["Startup"] = function(p47)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v48 = p47:FindFirstChild("HumanoidRootPart")
			if v48 then
				v_u_14:PlaySound(v_u_9.Charles.UltStart, v48, game.SoundService.Effect)
			end
		end,
		["UltimateNo"] = function(p_u_49, p_u_50, p_u_51)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_4, (ref) v_u_3, (ref) v_u_5, (ref) v_u_10, (ref) v_u_8, (ref) v_u_2
			local v_u_52 = p_u_51:FindFirstChild("HumanoidRootPart")
			if v_u_52 then
				local v_u_53 = v_u_14:PlaySound(v_u_9.Charles.Ult, v_u_52, game.SoundService.Effect)
				task.delay(2, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_53, (ref) v_u_3
					v_u_4:Create(v_u_53, TweenInfo.new(0.5), {
						["Volume"] = 0
					}):Play()
					v_u_3:AddItem(v_u_53, 0.5)
				end)
				if v_u_5.Character == p_u_50 or v_u_5.Character == p_u_51 then
					v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.HeavyHit):StartFadeOut(1)
				end
				local v_u_56 = {
					[1.1] = function()
						-- upvalues: (ref) v_u_8, (copy) v_u_52, (ref) v_u_3, (ref) v_u_4
						local v54 = v_u_8.Todo.Swing:Clone()
						v54.Weld.Part0 = v_u_52
						v54.Parent = workspace.Effects
						v_u_3:AddItem(v54, 0.6)
						v54.Core.Wind:Emit(12)
						v_u_4:Create(v54.Weld, TweenInfo.new(0.4), {
							["C1"] = v54.Weld.C1 * CFrame.Angles(0, -3.6651914291880923, 0)
						}):Play()
						v_u_4:Create(v54.Beam, TweenInfo.new(0.4), {
							["Width0"] = 0
						}):Play()
					end,
					[1.733] = function()
						-- upvalues: (copy) p_u_51, (ref) v_u_8, (ref) v_u_3, (ref) v_u_5, (copy) p_u_50, (ref) v_u_10
						if p_u_51.Parent then
							local v55 = v_u_8.Gojo.Twofold:Clone()
							v_u_3:AddItem(v55, 1)
							v55.CFrame = p_u_51.Head.CFrame * CFrame.new(0, -0.5, -0.5)
							v55.Size = Vector3.new(0, 0, 0)
							v55.Parent = workspace.Effects
							v55.Sparks:Emit(10)
							if v_u_5.Character == p_u_50 or v_u_5.Character == p_u_51 then
								v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
							end
						end
					end
				}
				local v_u_57 = nil
				local v_u_58 = tick()
				v_u_57 = v_u_2.RenderStepped:Connect(function(_)
					-- upvalues: (copy) v_u_58, (copy) v_u_56, (copy) p_u_49, (copy) v_u_52, (ref) v_u_57
					local v59 = tick() - v_u_58
					local v60 = 0
					for v61, v62 in v_u_56 do
						if v59 < v61 then
							v60 = v60 + 1
						else
							v_u_56[v61] = nil
							pcall(v62)
						end
					end
					if v60 <= 0 or not p_u_49.Parent and v_u_52.Parent then
						v_u_57:Disconnect()
					end
				end)
			end
		end,
		["Ultimate"] = function(p_u_63, p_u_64, p_u_65)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_7, (ref) v_u_14, (ref) v_u_9, (ref) v_u_2, (ref) v_u_10
			local v_u_66 = p_u_65:FindFirstChild("HumanoidRootPart")
			if v_u_66 then
				local function v_u_70(p67)
					-- upvalues: (copy) p_u_65, (ref) v_u_8, (ref) v_u_3
					local v68 = p67 == 1 and p_u_65["Left Arm"] or p_u_65["Right Arm"]
					local v69 = v_u_8.Charles.ParryFX.Core:Clone()
					v69.Parent = v68
					v_u_3:AddItem(v69, 1)
					v69.Dust:Emit(1)
					v69.Ring:Emit(2)
				end
				local v_u_89 = {
					[1.1] = function()
						-- upvalues: (ref) v_u_8, (copy) v_u_66, (ref) v_u_3, (ref) v_u_4
						local v71 = v_u_8.Todo.Swing:Clone()
						v71.Weld.Part0 = v_u_66
						v71.Parent = workspace.Effects
						v_u_3:AddItem(v71, 0.6)
						v71.Core.Wind:Emit(12)
						v_u_4:Create(v71.Weld, TweenInfo.new(0.4), {
							["C1"] = v71.Weld.C1 * CFrame.Angles(0, -3.6651914291880923, 0)
						}):Play()
						v_u_4:Create(v71.Beam, TweenInfo.new(0.4), {
							["Width0"] = 0
						}):Play()
					end,
					[1.733] = function()
						-- upvalues: (copy) p_u_65, (ref) v_u_8, (ref) v_u_3
						if p_u_65.Parent then
							local v_u_72 = v_u_8.Gojo.Twofold:Clone()
							v_u_3:AddItem(v_u_72, 1)
							v_u_72.CFrame = p_u_65.Head.CFrame * CFrame.new(0, -0.5, -0.5)
							v_u_72.Size = Vector3.new(0, 0, 0)
							v_u_72.Parent = workspace.Effects
							v_u_72.Sparks.TimeScale = 0.05
							v_u_72.Sparks:Emit(10)
							task.delay(0.2, function()
								-- upvalues: (copy) v_u_72
								v_u_72.Sparks.TimeScale = 1
							end)
						end
					end,
					[1.917] = function()
						-- upvalues: (ref) v_u_8, (copy) v_u_66, (ref) v_u_4, (ref) v_u_3
						local v73 = v_u_8.Hiromi.Shockwave:Clone()
						v73.Position = v_u_66.Position + v_u_66.CFrame.LookVector * 5 - Vector3.new(0, 2.5, 0)
						v73.Parent = workspace.Effects
						local v74 = v73.CFrame
						local v75 = CFrame.Angles
						local v76 = math.random(-179, 179)
						v73.CFrame = v74 * v75(0, math.rad(v76), 0)
						v_u_4:Create(v73.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
							["Scale"] = Vector3.new(15, 0, 15)
						}):Play()
						v_u_4:Create(v73.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
							["Transparency"] = 1
						}):Play()
						v73.Floor.Ring:Emit(10)
						v_u_3:AddItem(v73, 1.5)
					end,
					[2.383] = function()
						-- upvalues: (copy) p_u_65, (copy) v_u_66, (ref) v_u_5, (copy) p_u_64, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
						if p_u_65 or not v_u_66 then
							if v_u_5.Character == p_u_65 or v_u_5.Character == p_u_64 then
								local v_u_77 = v_u_8.Charles.Afterimage:Clone()
								if p_u_65:GetScale() ~= 1 then
									v_u_77:ScaleTo(p_u_65:GetScale())
								end
								v_u_77.HumanoidRootPart.CFrame = v_u_66.CFrame
								v_u_77.Parent = workspace.Effects
								v_u_77.Control:LoadAnimation(v_u_7.Charles.UltimateAfter):Play(0, nil, 0.6)
								v_u_3:AddItem(v_u_77, 1.6)
								local v78 = Instance.new("Highlight", v_u_77)
								v78.DepthMode = Enum.HighlightDepthMode.Occluded
								v78.FillColor = Color3.new(1, 1, 1)
								v78.FillTransparency = 0.9
								v78.OutlineTransparency = 0.6
								task.spawn(function()
									-- upvalues: (ref) p_u_65, (copy) v_u_77, (ref) v_u_4, (ref) v_u_3
									for _, v79 in p_u_65:GetChildren() do
										if v79:IsA("Accessory") then
											local v80 = v79:FindFirstChildWhichIsA("SpecialMesh", true)
											local v81 = game:GetService("AssetService"):CreateMeshPartAsync(v80.MeshId)
											v81.Size = v80.Parent.Size * v80.Scale
											v81.CanCollide = false
											v81.Material = Enum.Material.Glass
											v81.Transparency = 3
											local v82 = v80.Parent.AccessoryWeld:Clone()
											v82.Part0 = v81
											v82.Part1 = v_u_77:FindFirstChild(v82.Part1.Name)
											v82.Parent = v81
											v81.Parent = v_u_77
										end
									end
									local v83 = Instance.new("ColorCorrectionEffect", game.Lighting)
									v_u_4:Create(v83, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
										["Saturation"] = -2,
										["Contrast"] = -2
									}):Play()
									task.wait(1.6)
									v_u_4:Create(v83, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
										["Saturation"] = 0,
										["Contrast"] = 0
									}):Play()
									v_u_3:AddItem(v83, 0.5)
								end)
							end
						else
							return
						end
					end,
					[5.283] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(1)
					end,
					[5.45] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(2)
					end,
					[5.683] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(1)
					end,
					[5.9] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(1)
					end,
					[6] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(2)
					end,
					[6.3] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(2)
					end,
					[6.483] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(1)
					end,
					[6.617] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(2)
					end,
					[6.75] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(1)
					end,
					[6.833] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(2)
					end,
					[6.9] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(1)
					end,
					[6.983] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(2)
					end,
					[7.1] = function()
						-- upvalues: (copy) v_u_70
						v_u_70(1)
					end,
					[7.7] = function()
						-- upvalues: (copy) p_u_64, (ref) v_u_8, (ref) v_u_3
						local v84 = p_u_64.SetAssets:FindFirstChild("GWarStaff")
						if v84 then
							local v85 = v_u_8.Charles.ParryFX.Glow:Clone()
							v85.Parent = v84.Trail
							v85:Emit(1)
							v_u_3:AddItem(v85, 0.4)
						end
					end,
					[8.15] = function()
						-- upvalues: (copy) p_u_65, (copy) v_u_66, (ref) v_u_5, (copy) p_u_64, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
						if p_u_65 or not v_u_66 then
							if v_u_5.Character == p_u_65 or v_u_5.Character == p_u_64 then
								local v86 = v_u_8.Charles.HitEnd:Clone()
								v86.CFrame = v_u_66.CFrame
								v86.Parent = workspace.Effects
								v_u_3:AddItem(v86, 0.766)
								local v87 = TweenInfo.new(0.766, Enum.EasingStyle.Exponential)
								for _, v88 in v86:GetDescendants() do
									if v88:IsA("Beam") then
										v_u_4:Create(v88, v87, {
											["TextureSpeed"] = 0
										}):Play()
									elseif v88:IsA("ParticleEmitter") then
										v_u_4:Create(v88, v87, {
											["TimeScale"] = 0
										}):Play()
									end
								end
							end
						else
							return
						end
					end
				}
				v_u_14:PlaySound(v_u_9.Charles.Ult, v_u_66, game.SoundService.Effect)
				v_u_14:PlaySound(v_u_9.Charles.UltVoice, v_u_66, game.SoundService.Voice)
				if v_u_5.Character == p_u_64 or v_u_5.Character == p_u_65 then
					local v_u_90 = workspace.CurrentCamera
					local v_u_91 = v_u_90.CFrame
					local v_u_92 = Instance.new("NumberValue")
					v_u_4:Create(v_u_92, TweenInfo.new(0.8, Enum.EasingStyle.Exponential), {
						["Value"] = 1
					}):Play()
					v_u_3:AddItem(v_u_92, 0.8)
					local v_u_93 = 0
					local v_u_94 = nil
					local v_u_95 = tick()
					local v_u_96 = v_u_8.Charles.CounterCutscene
					v_u_94 = v_u_2.RenderStepped:Connect(function(p97)
						-- upvalues: (ref) v_u_93, (copy) v_u_96, (copy) p_u_64, (copy) v_u_66, (copy) p_u_63, (copy) v_u_90, (copy) v_u_91, (copy) v_u_92, (copy) v_u_95, (copy) v_u_89, (ref) v_u_94, (ref) v_u_5, (ref) v_u_4, (ref) v_u_10
						v_u_93 = v_u_93 + p97 * 60
						local v98 = v_u_96.Frames
						local v99 = v_u_93
						local v100 = math.ceil(v99)
						local v101 = v98:FindFirstChild((tonumber(v100)))
						local v102 = v_u_96.FOV
						local v103 = v_u_93
						local v104 = math.ceil(v103)
						local v105 = v102:FindFirstChild((tonumber(v104)))
						if v101 and (v105 and (p_u_64.Parent and (v_u_66 and p_u_63.Parent))) then
							v_u_90.CFrame = v_u_91:Lerp(v_u_66.CFrame * v101.Value, v_u_92.Value)
							v_u_90.FieldOfView = v105.Value
							v_u_90.CameraType = Enum.CameraType.Scriptable
							local v106 = tick() - v_u_95
							for v107, v108 in v_u_89 do
								if v106 >= v107 then
									v_u_89[v107] = nil
									pcall(v108)
								end
							end
						else
							v_u_94:Disconnect()
							v_u_90.CameraType = Enum.CameraType.Custom
							v_u_90.FieldOfView = 70
							v_u_90.CameraSubject = (v_u_5.Character or v_u_5.CharacterAdded:Wait()):WaitForChild("Humanoid")
							game.Lighting.ExposureCompensation = 2
							v_u_4:Create(game.Lighting, TweenInfo.new(1), {
								["ExposureCompensation"] = 0
							}):Play()
							v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
						end
					end)
				else
					local v_u_109 = nil
					local v_u_110 = tick()
					v_u_109 = v_u_2.RenderStepped:Connect(function(_)
						-- upvalues: (copy) v_u_110, (copy) v_u_89, (copy) p_u_63, (copy) v_u_66, (ref) v_u_109
						local v111 = tick() - v_u_110
						local v112 = 0
						for v113, v114 in v_u_89 do
							if v111 < v113 then
								v112 = v112 + 1
							else
								v_u_89[v113] = nil
								pcall(v114)
							end
						end
						if v112 <= 0 or not p_u_63.Parent and v_u_66.Parent then
							v_u_109:Disconnect()
						end
					end)
				end
			else
				return
			end
		end,
		["Dead"] = function(p115)
			-- upvalues: (ref) v_u_14, (ref) v_u_11
			if p115.HumanoidRootPart then
				v_u_14:Bleed(p115)
				for _ = 1, 40 do
					v_u_11:Blood(p115.Torso.CFrame * CFrame.Angles(0, 3.141592653589793, 0), math.random(-150, -5), 25, 25)
				end
			end
		end,
		["Mark"] = function(p116, p117, p118)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v119 = p116.HumanoidRootPart
			if v119 then
				local v120 = CFrame.new(p117, v119.Position)
				local v121 = (p117 - v119.Position).Magnitude
				local v122 = v_u_8.Mahito.Dash:Clone()
				v122.CFrame = v120 + v120.LookVector * v121 / 2
				v122.Size = Vector3.new(5, 5, v121)
				v122.Parent = workspace.Effects
				v_u_4:Create(v122, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 0, v121),
					["CFrame"] = v122.CFrame * CFrame.Angles(0, 0, 3.141592653589793)
				}):Play()
				v_u_3:AddItem(v122, 0.2)
				if p118 then
					local v123 = v_u_8.Charles.Mark:Clone()
					v123.Weld.Part0 = p116.Torso
					v123.Parent = workspace.Effects
					v_u_3:AddItem(v123, 30)
					repeat
						task.wait()
					until not (p118.Parent and (p118.Parent.Parent and p118.Parent.Parent.Parent))
					v_u_4:Create(v123, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
					v_u_4:Create(v123.Decal, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
					v123.Aura.Enabled = false
				end
			else
				return
			end
		end,
		["Future"] = function(p_u_124, p125, p_u_126)
			-- upvalues: (ref) v_u_14, (ref) v_u_5, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_7, (ref) v_u_2
			local v_u_127 = p_u_124.HumanoidRootPart
			if v_u_127 then
				v_u_14:Flash(p_u_124, Color3.new(1, 1, 1), 0.4)
				if v_u_5 == p125 then
					local v_u_128 = v_u_8.Charles.Afterimage:Clone()
					v_u_3:AddItem(v_u_128, 0.8)
					if p_u_124:GetScale() ~= 1 then
						v_u_128:ScaleTo(p_u_124:GetScale())
					end
					v_u_128.HumanoidRootPart.CFrame = v_u_127.CFrame
					v_u_128.Parent = workspace.Effects
					local v_u_129 = Instance.new("Highlight", v_u_128)
					v_u_129.DepthMode = Enum.HighlightDepthMode.Occluded
					v_u_129.FillColor = Color3.new(1, 1, 1)
					v_u_129.FillTransparency = 0.9
					v_u_129.OutlineTransparency = 0.7
					task.spawn(function()
						-- upvalues: (copy) p_u_124, (copy) v_u_128, (ref) v_u_4, (copy) v_u_129, (ref) v_u_7, (copy) p_u_126, (copy) v_u_127, (ref) v_u_2
						for _, v130 in p_u_124:GetChildren() do
							if v130:IsA("Accessory") then
								local v131 = v130:FindFirstChildWhichIsA("SpecialMesh", true)
								local v132 = game:GetService("AssetService"):CreateMeshPartAsync(v131.MeshId)
								v132.Size = v131.Parent.Size * v131.Scale
								v132.CanCollide = false
								v132.Material = Enum.Material.Glass
								v132.Transparency = 3
								local v133 = v131.Parent.AccessoryWeld:Clone()
								v133.Part0 = v132
								v133.Part1 = v_u_128:FindFirstChild(v133.Part1.Name)
								v133.Parent = v132
								v132.Parent = v_u_128
							end
						end
						local v134 = TweenInfo.new(0.8, Enum.EasingStyle.Sine, Enum.EasingDirection.In)
						v_u_4:Create(v_u_129, v134, {
							["FillTransparency"] = 1,
							["OutlineTransparency"] = 1
						}):Play()
						for _, v135 in v_u_128:GetDescendants() do
							if v135:IsA("Decal") then
								v135.Transparency = 1
							elseif v135:IsA("BasePart") and v135.Transparency ~= 1 then
								v_u_4:Create(v135, v134, {
									["Transparency"] = 1
								}):Play()
							end
						end
						local v136 = v_u_7.Misc.Movement.DashLeft
						local v137 = CFrame.new(-12, 0, 0)
						if p_u_126 == "Right" then
							v136 = v_u_7.Misc.Movement.DashRight
							v137 = CFrame.new(12, 0, 0)
						elseif p_u_126 == "Back" then
							v136 = v_u_7.Misc.Movement.DashBack
							v137 = CFrame.new(0, 0, 12)
						end
						local v_u_138 = Instance.new("NumberValue", v_u_128)
						v_u_4:Create(v_u_138, TweenInfo.new(0.4, Enum.EasingStyle.Quad), {
							["Value"] = 1
						}):Play()
						task.delay(0.4, function()
							-- upvalues: (ref) v_u_4, (copy) v_u_138
							v_u_4:Create(v_u_138, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
								["Value"] = 0
							}):Play()
						end)
						v_u_128.Control:LoadAnimation(v136):Play(nil, nil, p_u_126 == "Back" and 0.8 or 1.8)
						repeat
							v_u_128.HumanoidRootPart.CFrame = v_u_127.CFrame:Lerp(v_u_127.CFrame * v137, v_u_138.Value)
							v_u_2.RenderStepped:Wait()
						until not (v_u_128.Parent and v_u_127.Parent)
					end)
				else
					p_u_124.Humanoid.AutoRotate = false
					task.wait(0.7)
					p_u_124.Humanoid.AutoRotate = true
				end
			else
				return
			end
		end,
		["Perfect"] = function(p_u_139)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9, (ref) v_u_7
			local v140 = p_u_139:FindFirstChild("HumanoidRootPart")
			if v140 then
				local v141 = v_u_8.Damage.HitGlow:Clone()
				if p_u_139:GetScale() ~= 1 then
					v141:ScaleTo(p_u_139:GetScale())
				end
				v141.Parent = workspace.Effects
				v_u_3:AddItem(v141, 0.5)
				for _, v142 in v141:GetChildren() do
					local v143 = p_u_139:FindFirstChild(v142.Name)
					if v143 then
						v142.CFrame = v143.CFrame
					end
					v142.Color = Color3.new(0, 0, 0)
					v142.Anchored = true
					v_u_4:Create(v142, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
				v_u_14:PlaySound(v_u_9.Itadori.ManjiKick.Dodge, v140, game.SoundService.Effect)
				local v_u_144 = {
					"Dodge1",
					"Dodge2",
					"Dodge3",
					"Dodge4",
					"Dodge5"
				}
				for _, v145 in p_u_139.Humanoid:GetPlayingAnimationTracks() do
					if table.find(v_u_144, v145.Name) then
						v145:Stop(0.02)
					end
				end
				p_u_139.Humanoid:LoadAnimation(v_u_7.Hiromi.Dodge:GetChildren()[math.random(1, 5)]):Play(0.02)
				local v_u_146 = nil
				v_u_146 = p_u_139.Info.ChildAdded:Connect(function(p147)
					-- upvalues: (copy) p_u_139, (copy) v_u_144, (ref) v_u_146
					if p147.Name == "Stun" or p147.Name == "InSkill" then
						for _, v148 in p_u_139.Humanoid:GetPlayingAnimationTracks() do
							if table.find(v_u_144, v148.Name) then
								v148:Stop(0.02)
							end
						end
						v_u_146:Disconnect()
						v_u_146 = nil
					end
				end)
				task.wait(0.3)
				if v_u_146 then
					v_u_146:Disconnect()
				end
			end
		end
	}
	v_u_12.Effects:Connect(function(p150, ...)
		-- upvalues: (copy) v_u_149
		local v151 = v_u_149[p150]
		if v151 then
			v151(...)
		end
	end)
	v_u_12.Hitbox:Connect(function(p152, p153, p154)
		-- upvalues: (ref) v_u_13, (ref) v_u_4
		local v155 = p153.HumanoidRootPart
		if not v155 then
			return
		end
		local v156 = nil
		while true do
			local v157 = v_u_13:SphereHitbox(p153, CFrame.new(0, 0, -4), 8)
			for _, v158 in v157 do
				local v159 = v158:FindFirstChild("Info")
				if v159 then
					local v160 = v159:FindFirstChild("Knockback")
					if not v160 or v160.Value ~= false then
						v156 = v157
						break
					end
				end
			end
			if v156 then
				local v161 = p152:FindFirstChildWhichIsA("NumberValue")
				if v161 then
					v_u_4:Create(v161, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p152.Parent then
				break
			end
		end
		p154:FireServer(v156, v155.CFrame)
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14
	v_u_12 = v_u_1.GetService("CharlesService")
	v_u_13 = v_u_1.GetController("HitboxController")
	v_u_14 = v_u_1.GetController("FXController")
end
return v15