-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v9 = RaycastParams.new()
v9.FilterType = Enum.RaycastFilterType.Include
v9.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "CheapShotController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_2, (ref) v_u_10
	local v_u_36 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:PlaySound(v_u_7.Haruta.SwordThrow, v15, game.SoundService.Effect)
			end
		end,
		["ArmWave"] = function(p16)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_11:PlaySound(v_u_7.Haruta.Wave, v17, game.SoundService.Effect)
			end
		end,
		["Throw"] = function(p18)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = v_u_6.Haruta.SwordThrow:Clone()
				v20.Parent = v19
				for _, v21 in v20:GetDescendants() do
					if v21:IsA("ParticleEmitter") then
						v21:Emit(v21:GetAttribute("EmitCount"))
					end
				end
				local v22 = v_u_6.Gojo.HardHit:Clone()
				v22.CFrame = v19.CFrame + v19.CFrame.LookVector * 3.5
				v22.Parent = workspace.Effects
				v22.Ring:Emit(5)
				v_u_3:AddItem(v22, 0.5)
				if p18 == v_u_4.Character then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["Hit"] = function(p23, p24, p25)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3
			local v26 = p23:FindFirstChild("HumanoidRootPart")
			if v26 then
				local v27 = p25 or 0
				local v28 = p24:FindFirstChild("HumanoidRootPart")
				if v28 then
					v_u_11:Flash(p24, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Yuta.M1.Hit1, v28, game.SoundService.Effect)
					local v29 = v_u_6.Yuta.SlashHit:Clone()
					v29.CFrame = CFrame.lookAlong((v28.CFrame * CFrame.new(v27, 0, 0)).Position, v26.CFrame.LookVector) * CFrame.Angles(0, 0, -1.5707963267948966)
					v29.Parent = workspace.Effects
					v_u_3:AddItem(v29, 0.5)
					v29.Slash:Emit(5)
				end
			else
				return
			end
		end,
		["Interp"] = function(p_u_30)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_2
			v_u_11:PlaySound(v_u_7.Haruta.SwordSpin, p_u_30, game.SoundService.Effect, true)
			local v_u_31 = p_u_30.CFrame
			local v_u_32 = tick()
			local v_u_33 = p_u_30:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_31, (copy) p_u_30, (ref) v_u_32
				v_u_31 = p_u_30.CFrame
				v_u_32 = tick()
			end)
			local v_u_34 = nil
			v_u_34 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_30, (ref) v_u_34, (copy) v_u_33, (ref) v_u_31, (ref) v_u_32
				if p_u_30.Parent then
					workspace:BulkMoveTo({ p_u_30 }, { v_u_31 + v_u_31.LookVector * (150 * (tick() - v_u_32)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_34:Disconnect()
					v_u_33:Disconnect()
				end
			end)
		end,
		["Finisher"] = function(p35)
			-- upvalues: (ref) v_u_11
			if p35:FindFirstChild("HumanoidRootPart") then
				v_u_11:Bleed(p35)
			end
		end
	}
	v_u_10.Effects:Connect(function(p37, ...)
		-- upvalues: (copy) v_u_36
		local v38 = v_u_36[p37]
		if v38 then
			v38(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_12, (ref) v_u_11
	v_u_10 = v_u_1.GetService("CheapShotService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v13