-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "BlackMucusController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10
	local v_u_28 = {
		["Start"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_8.Locust.BlackMucus.Use, v14, game.SoundService.Effect)
			end
		end,
		["Fire"] = function(p15, p16)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				local v18 = v_u_7.Locust.MucusFire:Clone()
				v18.CFrame = p16 * CFrame.new(0, 0, -5)
				v18.Parent = workspace.Effects
				v18.Wind:Emit(20)
				v18.Back1.Back:Emit(1)
				v18.Back2.Back:Emit(1)
				v_u_4:Create(v18.Back1, TweenInfo.new(2), {
					["CFrame"] = v18.Back1.CFrame - v18.Back1.CFrame.LookVector * 10
				}):Play()
				v_u_4:Create(v18.Back2, TweenInfo.new(2), {
					["CFrame"] = v18.Back2.CFrame - v18.Back2.CFrame.LookVector * 10
				}):Play()
				v_u_3:AddItem(v18, 2)
				v_u_11:PlaySound(v_u_8.Locust.BlackMucus.Fire, v17, game.SoundService.Effect)
				if v_u_5.Character == p15 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end,
		["Interp"] = function(p_u_19)
			-- upvalues: (ref) v_u_2, (ref) v_u_11, (ref) v_u_8
			local v_u_20 = p_u_19.CFrame
			local v_u_21 = tick()
			local v_u_22 = p_u_19:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_20, (copy) p_u_19, (ref) v_u_21
				v_u_20 = p_u_19.CFrame
				v_u_21 = tick()
			end)
			local v_u_23 = false
			local v_u_24 = nil
			v_u_24 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_19, (ref) v_u_24, (copy) v_u_22, (ref) v_u_20, (ref) v_u_21, (ref) v_u_23, (ref) v_u_11, (ref) v_u_8
				if p_u_19.Parent then
					workspace:BulkMoveTo({ p_u_19 }, { v_u_20 + v_u_20.LookVector * (125 * (tick() - v_u_21)) }, Enum.BulkMoveMode.FireCFrameChanged)
					if p_u_19.Parent == workspace.Effects and v_u_23 == false then
						v_u_23 = true
						v_u_11:PlaySound(v_u_8.Locust.BlackMucus.Explode, p_u_19, game.SoundService.Effect)
					end
				else
					v_u_24:Disconnect()
					v_u_22:Disconnect()
				end
			end)
		end,
		["Hit"] = function(p25, p26)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				v_u_11:Flash(p26, Color3.new(0.65, 0, 1), 15)
				v_u_11:PlaySound(v_u_8.Locust.BlackMucus.Hit, v27, game.SoundService.Effect)
				if v_u_5 == p25 or v_u_5.Character == p26 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p29, ...)
		-- upvalues: (copy) v_u_28
		local v30 = v_u_28[p29]
		if v30 then
			v30(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("BlackMucusService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12