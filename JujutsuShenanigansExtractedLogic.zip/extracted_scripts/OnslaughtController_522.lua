-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v2 = game.ReplicatedStorage
local v3 = v2.Animations
local v4 = v2.Utils
local _ = v2.Sounds
require(v2.Modules.CameraShaker)
local v5 = require(v2.Modules.SraikoVFX)
require(v2.TEMP_CHARA_STUFF.VelocityHandler)
local v_u_6 = require(v2.TEMP_CHARA_STUFF.AnimationRetriever)
local v_u_7 = require(v2.TEMP_CHARA_STUFF.EffectUtility)
local v_u_8 = require(v2.TEMP_CHARA_STUFF.CameraShake)
local v_u_9 = require(v2.TEMP_CHARA_STUFF.Vignette)
local _ = v5.Enabled
local _ = v5.Emit
local _ = v5.EmitMesh
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "OnslaughtController"
})
local v_u_14 = v3.Misc.C.Onslaught
local v_u_15 = game:GetService("Players").LocalPlayer
local v_u_16 = v4.Misc.C.Chara
function v13.KnitStart(_)
	-- upvalues: (copy) v_u_15, (copy) v_u_8, (copy) v_u_9, (copy) v_u_7, (copy) v_u_16, (copy) v_u_6, (copy) v_u_14, (ref) v_u_10
	local v_u_17 = nil
	v_u_17 = {
		["Slam"] = function(p18)
			-- upvalues: (ref) v_u_15, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7
			if v_u_15:DistanceFromCharacter(p18.Position) < 20 then
				v_u_8(1.75, 17.5, 0.01, 0.35, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
				v_u_9(Color3.fromRGB(255, 0, 0), 0.35, 0.25)
			end
			v_u_7.CloneAndEmit(script.Assets.slam, p18)
		end,
		["Slash"] = function(p19, p20)
			-- upvalues: (ref) v_u_15, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7
			if v_u_15:DistanceFromCharacter(p19.Position) < 20 then
				v_u_8(1.5, 15, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
				v_u_9(Color3.fromRGB(255, 0, 0), 0.5, 0.25)
			end
			v_u_7.CloneAndEmit(script.Assets[("slash%*"):format(p20)], p19)
		end,
		["KickSwing"] = function(p21, p22)
			-- upvalues: (ref) v_u_15, (ref) v_u_8, (ref) v_u_7
			if v_u_15:DistanceFromCharacter(p21.Position) < 20 then
				v_u_8(1, 10, 0.01, 0.2, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
			end
			v_u_7.CloneAndEmit(script.Assets[("kickswing%*"):format(p22)], p21)
		end,
		["Smack"] = function(p23, p24)
			-- upvalues: (ref) v_u_7, (ref) v_u_16
			v_u_7.EmitEffects(v_u_16.Hit, p23)
			local v25 = script.SFX.Hits:FindFirstChild(p24)
			if v25 then
				v_u_7.AddSFX(v25, p23)
			end
		end,
		["Kick"] = function(p26)
			-- upvalues: (ref) v_u_15, (ref) v_u_8, (ref) v_u_7
			if v_u_15:DistanceFromCharacter(p26.Position) < 20 then
				v_u_8(1.5, 15, 0.01, 0.2, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
			end
			v_u_7.CloneAndEmit(script.Assets.kick, p26)
		end,
		["Stab"] = function(p27)
			-- upvalues: (ref) v_u_7
			v_u_7.CloneAndEmit(script.Assets.stab, p27)
		end,
		["SlashHit"] = function(p28, p29)
			-- upvalues: (ref) v_u_16, (ref) v_u_7
			local v30 = v_u_16.Assets.slashed:Clone()
			v30.CFrame = CFrame.new(0.35, 0, -0.3) * CFrame.Angles(0, 0, -1.5707963267948966)
			v30.Parent = p28
			v_u_7.Emit(v30)
			local v31 = script.SFX.Hits:FindFirstChild(p29)
			if v31 then
				v_u_7.AddSFX(v31, p28)
			end
		end,
		["StabHit"] = function(p32, p33)
			-- upvalues: (ref) v_u_15, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7
			if v_u_15:DistanceFromCharacter(p32.Position) < 20 then
				v_u_8(1.5, 15, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
				v_u_9(Color3.fromRGB(255, 0, 0), 0.5, 0.25)
			end
			local v34 = script.SFX.Hits:FindFirstChild(p33)
			if v34 then
				v_u_7.AddSFX(v34, p32)
			end
		end,
		["Hit"] = function(p35)
			-- upvalues: (ref) v_u_6, (ref) v_u_14, (ref) v_u_7
			local v36 = v_u_6.new(p35, v_u_14.NormalHit)
			if v36 ~= nil then
				local v37 = v36.Torso
				local _ = v36.RootPart
				local v38 = v36.Job
				local v39 = v36.Animation
				script.SFX.Whooshes.PlaybackSpeed = v39.Speed
				v38:Task(v_u_7.AddSFX(script.SFX.Whooshes, v37, 0.25))
			end
		end,
		["Windup"] = function(p40)
			-- upvalues: (ref) v_u_6, (ref) v_u_14, (ref) v_u_15, (ref) v_u_8, (ref) v_u_7
			local v41 = v_u_6.new(p40, v_u_14.NormalWindup)
			if v41 ~= nil then
				local v42 = v41.Torso
				local v_u_43 = v41.RootPart
				local v44 = v41.Job
				local v45 = v41.Animation
				local v_u_46 = p40.SetAssets:FindFirstChild("RealKnife")
				if v_u_46 ~= nil then
					v_u_46.Handle.BladeAttachment.Trail.Enabled = true
					v44:Task(function()
						-- upvalues: (copy) v_u_46
						if v_u_46.Parent ~= nil then
							v_u_46.Handle.BladeAttachment.Trail.Enabled = false
						end
					end)
				end
				v44:Task(v45:GetMarkerReachedSignal("hit"):Once(function()
					-- upvalues: (ref) v_u_15, (copy) v_u_43, (ref) v_u_8, (ref) v_u_7
					if v_u_15:DistanceFromCharacter(v_u_43.Position) < 20 then
						v_u_8(1, 10, 0.01, 0.2, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
					end
					v_u_7.CloneAndEmit(script.Assets.swing, v_u_43)
				end))
				script.SFX.Windup.PlaybackSpeed = v45.Speed
				v44:Task(v_u_7.AddSFX(script.SFX.Windup, v42, 0.25))
			end
		end,
		["AerialDrop"] = function(_, p47)
			-- upvalues: (ref) v_u_7, (ref) v_u_15, (ref) v_u_8, (ref) v_u_17
			v_u_7.CloneAndEmit(script.Aerial.Assets.drop, p47)
			if v_u_15:DistanceFromCharacter(p47.Position) < 20 then
				v_u_8(1, 10, 0.01, 0.2, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.5, 0.5, 0.5))
			end
			v_u_17.AerialHit(p47.Parent)
		end,
		["AerialStab"] = function(_, p48)
			-- upvalues: (ref) v_u_7, (ref) v_u_15, (ref) v_u_8, (ref) v_u_9
			v_u_7.CloneAndEmit(script.Aerial.Assets.stab, p48)
			if v_u_15:DistanceFromCharacter(p48.Position) < 20 then
				v_u_8(1.75, 25, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.15, 0.15, 0.15))
				v_u_9(Color3.fromRGB(255, 0, 0), 0.5, 0.25)
			end
		end,
		["AerialHit"] = function(p49)
			-- upvalues: (ref) v_u_7
			v_u_7.AddSFX(script.Aerial.HitSFX, p49.PrimaryPart, 0.25)
		end,
		["AerialWindup"] = function(p50)
			-- upvalues: (ref) v_u_7
			v_u_7.AddSFX(script.Aerial.WindupSFX, p50.PrimaryPart, 1.7)
		end
	}
	v_u_10.Effects:Connect(function(p51, ...)
		-- upvalues: (ref) v_u_17
		local v52 = v_u_17[p51]
		if v52 then
			v52(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("OnslaughtService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13