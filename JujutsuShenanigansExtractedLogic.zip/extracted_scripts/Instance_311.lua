-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {}
v_u_1.__index = v_u_1
v_u_1.CameraShakeState = {
	["FadingIn"] = 0,
	["FadingOut"] = 1,
	["Sustained"] = 2,
	["Inactive"] = 3
}
function v_u_1.new(p2, p3, p4, p5)
	-- upvalues: (copy) v_u_1
	local v6 = p4 or 0
	local v7 = p5 or 0
	local v8 = v6 == nil and 0 or v6
	local v9 = v7 == nil and 0 or v7
	local v10 = type(p2) == "number"
	assert(v10, "Magnitude must be a number")
	local v11 = type(p3) == "number"
	assert(v11, "Roughness must be a number")
	local v12 = type(v8) == "number"
	assert(v12, "FadeInTime must be a number")
	local v13 = type(v9) == "number"
	assert(v13, "FadeOutTime must be a number")
	local v14 = {
		["Magnitude"] = p2,
		["Roughness"] = p3,
		["PositionInfluence"] = Vector3.new(0, 0, 0),
		["RotationInfluence"] = Vector3.new(0, 0, 0),
		["DeleteOnInactive"] = true,
		["FadeOutDuration"] = v9,
		["FadeInDuration"] = v8,
		["Sustain"] = v8 > 0,
		["CurrentFadeTime"] = v8 > 0 and 0 or 1,
		["Tick"] = Random.new():NextNumber(-100, 100),
		["IsACameraShakeInstance"] = true
	}
	local v15 = v_u_1
	return setmetatable(v14, v15)
end
function v_u_1.UpdateShake(p16, p17)
	local v18 = p16.Tick
	local v19 = p16.CurrentFadeTime
	p16.AccumulatedTime = (p16.AccumulatedTime or 0) + p17
	while p16.AccumulatedTime >= 0.016666666666666666 do
		p16.AccumulatedTime = p16.AccumulatedTime - 0.016666666666666666
		if p16.FadeInDuration > 0 and p16.Sustain then
			if v19 < 1 then
				v19 = v19 + 0.016666666666666666 / p16.FadeInDuration
			elseif p16.FadeOutDuration > 0 then
				p16.Sustain = false
			end
		end
		if not p16.Sustain then
			local v20 = v19 - 0.016666666666666666 / p16.FadeOutDuration
			v19 = math.max(0, v20)
		end
		p16.Tick = v18 + 0.016666666666666666 * p16.Roughness * (p16.Sustain and 1 or v19)
		p16.CurrentFadeTime = v19
	end
	local v21 = math.noise(p16.Tick, 0) * 0.5
	local v22 = math.noise(0, p16.Tick) * 0.5
	local v23 = math.noise(p16.Tick, p16.Tick) * 0.5
	return Vector3.new(v21, v22, v23) * p16.Magnitude * p16.CurrentFadeTime
end
function v_u_1.StartFadeOut(p24, p25)
	if p25 == 0 then
		p24.CurrentFadeTime = 0
	end
	p24.FadeOutDuration = p25
	p24.FadeInDuration = 0
	p24.Sustain = false
end
function v_u_1.StartFadeIn(p26, p27)
	if p27 == 0 then
		p26.CurrentFadeTime = 1
	end
	p26.FadeInDuration = p27 or p26.FadeInDuration
	p26.FadeOutDuration = 0
	p26.Sustain = true
end
function v_u_1.GetNormalizedFadeTime(p28)
	return p28.CurrentFadeTime
end
function v_u_1.IsShaking(p29)
	return p29.CurrentFadeTime > 0 and true or p29.Sustain
end
function v_u_1.IsFadingOut(p30)
	local v31 = not p30.Sustain
	if v31 then
		v31 = p30.CurrentFadeTime > 0
	end
	return v31
end
function v_u_1.IsFadingIn(p32)
	local v33 = p32.CurrentFadeTime < 1 and p32.Sustain
	if v33 then
		v33 = p32.FadeInDuration > 0
	end
	return v33
end
function v_u_1.GetState(p34)
	-- upvalues: (copy) v_u_1
	if p34:IsFadingIn() then
		return v_u_1.CameraShakeState.FadingIn
	elseif p34:IsFadingOut() then
		return v_u_1.CameraShakeState.FadingOut
	elseif p34:IsShaking() then
		return v_u_1.CameraShakeState.Sustained
	else
		return v_u_1.CameraShakeState.Inactive
	end
end
return v_u_1