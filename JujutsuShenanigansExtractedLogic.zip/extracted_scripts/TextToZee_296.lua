-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
game:GetService("Debris")
local v_u_2 = game:GetService("RunService")
game:GetService("TweenService")
local v_u_3 = game:GetService("ReplicatedStorage").Remotes.TTS
function syllable(p4, p5, p6, p7)
	-- upvalues: (copy) v_u_2
	if p5 then
		if p4 then
			local v8 = (p6.Pitch or 1) * (p7 or 1)
			local v9 = p6.Speed or 1
			local v10 = p6.Volume or 1
			local v11
			if #p4 == 3 then
				v11 = string.sub(p4, 3, 3)
				p4 = string.sub(p4, 1, 2)
			else
				v11 = nil
			end
			local v12 = (script.Voices:FindFirstChild(p6.Voice or "TTZ") or script.Voices.TTZ):FindFirstChild(p4)
			if v12 then
				local v13 = v12.TimeLength == 0 and 0.1 or (v12.TimeLength or 0.1)
				if v11 == "1" then
					v10 = v10 + 0.25
					v9 = v9 + 0.1
					v8 = v8 + 0.05
				elseif v11 == "2" then
					v10 = v10 + 0.1
					v9 = v9 + 0.05
				elseif v11 == "0" then
					v10 = v10 - 0.1
					v9 = v9 - 0.075
				end
				local v_u_14 = v12:Clone()
				local v15 = Instance.new("PitchShiftSoundEffect")
				v15.Octave = v8
				v15.Parent = v_u_14
				v_u_14.SoundGroup = game.SoundService.Voice
				v_u_14.PlaybackSpeed = v_u_14.PlaybackSpeed * v9
				v_u_14.Volume = v_u_14.Volume * v10
				v_u_14.Parent = p5
				v_u_14:Play()
				task.delay(v13, function()
					-- upvalues: (copy) v_u_14
					v_u_14:Destroy()
				end)
				local v16 = tick()
				local v17 = 0
				while v_u_14.PlaybackLoudness >= v17 do
					v17 = v_u_14.PlaybackLoudness
					v_u_2.RenderStepped:Wait()
					if tick() > v16 + v13 or not v_u_14.Parent then
						break
					end
				end
			else
				if p4 == " " then
					task.wait(0.05 / v9)
					return
				end
				if p4 == "." or (p4 == "!" or p4 == "?") then
					task.wait(0.7 / v9)
					return
				end
				if p4 == "," then
					task.wait(0.5 / v9)
					return
				end
				task.wait(0.3 / v9)
			end
		end
	else
		return
	end
end
local v_u_18 = {}
function v1.TTS(p19, p20, p21)
	-- upvalues: (copy) v_u_3, (copy) v_u_18
	local v22 = v_u_3:InvokeServer(p19, p21.Accent)
	if not v22 then
		return
	end
	local v23 = tick()
	v_u_18[p20] = v23
	for _, v24 in v22 do
		if v_u_18[p20] ~= v23 then
			break
		end
		for _, v25 in v24 do
			syllable(v25[1], p20, p21, v25[2])
		end
	end
	if v_u_18[p20] == v23 then
		v_u_18[p20] = nil
	end
end
return v1