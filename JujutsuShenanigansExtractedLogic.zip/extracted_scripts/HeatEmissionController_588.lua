-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.EffectUtils)
local v_u_10 = require(v_u_5.Knit.Trove)
local v_u_11 = require(v_u_5.Modules.SraikoVFX)
local v_u_12 = v_u_11.Enabled
local v_u_13 = v_u_11.Emit
local v_u_14 = nil
local v_u_15 = nil
local v16 = v_u_1.CreateController({
	["Name"] = "HeatEmissionController"
})
function v16.KnitStart(_)
	-- upvalues: (copy) v_u_10, (copy) v_u_5, (ref) v_u_15, (copy) v_u_7, (copy) v_u_6, (copy) v_u_11, (copy) v_u_2, (copy) v_u_13, (copy) v_u_3, (copy) v_u_12, (copy) v_u_9, (copy) v_u_4, (copy) v_u_8, (ref) v_u_14
	local v_u_51 = {
		["Start"] = function(p17, p18)
			-- upvalues: (ref) v_u_10, (ref) v_u_5, (ref) v_u_15, (ref) v_u_7
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = v_u_10.new()
				v20:AttachToInstance(p18)
				local v21 = v20:Clone(v_u_5.Utils.Mechamaru.BoosterL)
				v21.Parent = p17
				local v22 = v20:Clone(v_u_5.Utils.Mechamaru.BoosterR)
				v22.Parent = p17
				local function v26(p23, p24)
					local v_u_25 = Instance.new("Motor6D")
					v_u_25.C0 = CFrame.new(0, 0.75, 0.625) * CFrame.Angles(0.7853981633974483, 0, 0)
					v_u_25.Part0 = p24
					v_u_25.Part1 = p23
					v_u_25.Name = p23.Name
					v_u_25.Parent = p24
					p23.Parent.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_25
						v_u_25:Destroy()
					end)
				end
				v26(v22["Arm BoostterrrrR"], p17["Right Arm"])
				v26(v21["Arm BoostterrrrL"], p17["Left Arm"])
				v_u_15:PlaySound(v_u_7.Mechamaru.HeatEmission.Start, v19, game.SoundService.Effect)
			end
		end,
		["Leap"] = function(p27)
			-- upvalues: (ref) v_u_6, (ref) v_u_11, (ref) v_u_2, (ref) v_u_13, (ref) v_u_3, (ref) v_u_12
			local v28 = p27:FindFirstChild("HumanoidRootPart")
			if v28 then
				local v29 = v_u_6.Mechamaru.BoostOnVFX.BoostHit.Meshes.Mesh:Clone()
				local v30 = v_u_11.HandleMesh(v29, v28.CFrame * v29.Offset.Value)
				v29.Parent = workspace.Effects
				v_u_2:AddItem(v29, v30)
				v_u_13(v_u_6.Mechamaru.BoostOnVFX.BoostHit.Emit.Strike, v28, true, 3)
				local v31 = v_u_6.Hiromi.Shockwave:Clone()
				v31.Position = v28.Position - Vector3.new(0, 3, 0)
				v31.Parent = workspace.Effects
				local v32 = v_u_6.Misc.M.DashHit:Clone()
				v32.Position = v28.Position - Vector3.new(0, 3, 0)
				v32.Parent = workspace.Effects
				for _, v33 in v32:GetDescendants() do
					if v33:IsA("ParticleEmitter") then
						v33:Emit(v33:GetAttribute("EmitCount"))
					end
				end
				v_u_2:AddItem(v32, 1)
				local v34 = v_u_6.Misc.M.Slash.PointLight:Clone()
				v34.Parent = v32
				v_u_3:Create(v34, TweenInfo.new(0.6), {
					["Brightness"] = 0,
					["Color"] = Color3.new(1, 0, 0)
				}):Play()
				local v35 = v31.CFrame
				local v36 = CFrame.Angles
				local v37 = math.random(-179, 179)
				v31.CFrame = v35 * v36(0, math.rad(v37), 0)
				v_u_3:Create(v31.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
					["Scale"] = Vector3.new(15, 0, 15)
				}):Play()
				v_u_3:Create(v31.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
					["Transparency"] = 1
				}):Play()
				v31.Floor.Glow:Emit(1)
				v31.Floor.Ring:Emit(10)
				v_u_2:AddItem(v31, 1.5)
				local v38 = p27:FindFirstChild("BoosterR")
				local v39 = p27:FindFirstChild("BoosterL")
				if v38 and v39 then
					v_u_12(v38["Arm BoostterrrrR"].Stage1, false)
					v_u_12(v38["Arm BoostterrrrR"].Stage2, true)
					v_u_12(v39["Arm BoostterrrrL"].Stage1, false)
					v_u_12(v39["Arm BoostterrrrL"].Stage2, true)
					task.wait(0.4)
					v_u_12(v38["Arm BoostterrrrR"].Stage2, false)
					v_u_12(v39["Arm BoostterrrrL"].Stage2, false)
				end
			end
		end,
		["Blast"] = function(p40, p41)
			-- upvalues: (ref) v_u_15, (ref) v_u_7, (ref) v_u_6, (ref) v_u_11, (ref) v_u_2, (ref) v_u_9, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v42 = p40:FindFirstChild("HumanoidRootPart")
			if v42 then
				local v43 = (v42.CFrame - Vector3.new(0, 2, 0)) * CFrame.Angles(-0.5235987755982988, 0, 0)
				v_u_15:PlaySound(v_u_7.Mechamaru.HeatEmission.Vent, v42, game.SoundService.Effect)
				local v44 = v_u_6.Mechamaru.BoostOnVFX.BoostHit.Meshes.Mesh:Clone()
				local v45 = v_u_11.HandleMesh(v44, v43 * v44.Offset.Value)
				v44.Parent = workspace.Effects
				v_u_2:AddItem(v44, v45)
				local v46 = v_u_6.Mechamaru.Heat:Clone()
				v46.Parent = workspace.Effects
				v46.CFrame = v43
				v46.Smoke:Emit(30)
				v_u_2:AddItem(v46, 1.5)
				local v47 = v_u_6.Misc.M.Slash.PointLight:Clone()
				v47.Parent = v46
				if p41 then
					v46.Flames:Emit(30)
					v46.Attachment.Wind2:Emit(5)
					v_u_9.AutoEffects(v_u_6.Mechamaru.UltraCannonVFX.FireCannon, v42)
					v_u_15:PlaySound(v_u_7.Mechamaru.HeatEmission.Ignition, v42, game.SoundService.Effect)
					v47.Brightness = 15
					v_u_3:Create(v47, TweenInfo.new(0.6), {
						["Brightness"] = 0,
						["Color"] = Color3.new(1, 0, 0)
					}):Play()
					if v_u_4.Character == p40 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
						return
					end
				else
					local v48 = v_u_6.Choso.CounterSwing.Shock:Clone()
					v48.Size = Vector3.new(6, 30, 6)
					v48.CFrame = v43 * CFrame.Angles(1.5707963267948966, 0, 0)
					v48.Parent = workspace.Effects
					v_u_2:AddItem(v48, 0.2)
					v_u_3:Create(v48, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(25, 0, 25),
						["Transparency"] = 1,
						["Position"] = v48.Position + v42.CFrame.LookVector * 10
					}):Play()
					v_u_3:Create(v47, TweenInfo.new(0.1), {
						["Brightness"] = 0,
						["Color"] = Color3.new(1, 0, 0)
					}):Play()
					if v_u_4.Character == p40 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			end
		end,
		["Hit"] = function(p49, _)
			-- upvalues: (ref) v_u_15, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v_u_50 = p49:FindFirstChild("HumanoidRootPart")
			if v_u_50 then
				v_u_15:Flash(p49, Color3.new(1, 1, 1))
				task.delay(0.4, function()
					-- upvalues: (ref) v_u_15, (ref) v_u_7, (copy) v_u_50
					v_u_15:PlaySound(v_u_7.Naoya.Decisive.Swing2, v_u_50, game.SoundService.Effect)
				end)
				if v_u_4.Character == p49 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_14.Effects:Connect(function(p52, ...)
		-- upvalues: (copy) v_u_51
		local v53 = v_u_51[p52]
		if v53 then
			v53(...)
		end
	end)
end
function v16.KnitInit(_)
	-- upvalues: (ref) v_u_14, (copy) v_u_1, (ref) v_u_15
	v_u_14 = v_u_1.GetService("HeatEmissionService")
	v_u_15 = v_u_1.GetController("FXController")
end
return v16