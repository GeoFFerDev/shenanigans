-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {
	["DebugLogging"] = false,
	["VisualizeCasts"] = false
}
v_u_1.__index = v_u_1
v_u_1.__type = "FastCast"
v_u_1.HighFidelityBehavior = {
	["Default"] = 1,
	["Always"] = 3
}
local v_u_2 = require(script.ActiveCast)
local v_u_3 = require(script.Signal)
require(script.Table)
require(script.TypeDefinitions)
v_u_2.SetStaticFastCastReference(v_u_1)
function v_u_1.new()
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v4 = {
		["LengthChanged"] = v_u_3.new("LengthChanged"),
		["RayHit"] = v_u_3.new("RayHit"),
		["RayPierced"] = v_u_3.new("RayPierced"),
		["CastTerminating"] = v_u_3.new("CastTerminating"),
		["WorldRoot"] = workspace
	}
	local v5 = v_u_1
	return setmetatable(v4, v5)
end
function v_u_1.newBehavior()
	-- upvalues: (copy) v_u_1
	return {
		["RaycastParams"] = nil,
		["Acceleration"] = Vector3.new(),
		["MaxDistance"] = 1000,
		["CanPierceFunction"] = nil,
		["HighFidelityBehavior"] = v_u_1.HighFidelityBehavior.Default,
		["HighFidelitySegmentSize"] = 0.5,
		["CosmeticBulletTemplate"] = nil,
		["CosmeticBulletProvider"] = nil,
		["CosmeticBulletContainer"] = nil,
		["AutoIgnoreContainer"] = true
	}
end
local v_u_6 = v_u_1.newBehavior()
function v_u_1.Fire(p7, p8, p9, p10, p11)
	-- upvalues: (copy) v_u_6, (copy) v_u_2
	if p11 == nil then
		p11 = v_u_6
	end
	local v12 = v_u_2.new(p7, p8, p9, p10, p11)
	v12.RayInfo.WorldRoot = p7.WorldRoot
	return v12
end
return v_u_1