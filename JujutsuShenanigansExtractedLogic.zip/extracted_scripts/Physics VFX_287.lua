-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 1,
	["SortOrder"] = 5,
	["Val"] = "DesPHY",
	["Desc"] = "Toggles the visibility of physics heavy effects"
}