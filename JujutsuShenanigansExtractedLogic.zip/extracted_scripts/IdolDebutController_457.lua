-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "IdolDebutController"
})
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_9, (copy) v_u_5, (copy) v_u_7, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_10, (copy) v_u_2, (ref) v_u_11
	local v_u_58 = {
		["Swing"] = function(p15)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Swag, v16, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Mahito.DrillSplit.Leap, v16, game.SoundService.Effect)
				local v17 = workspace.Effects:FindFirstChild("FollowTakada")
				if v17 and v_u_5.Character == p15 then
					local v18 = v17.Humanoid:LoadAnimation(v_u_7.Todo.IdolDebut)
					v18:Play()
					task.wait(0.7)
					v18:Stop()
				end
			end
		end,
		["Swing2"] = function(p19)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_4
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = v_u_8.Hakari.RoughSwing:Clone()
				v21.Weld.C0 = CFrame.new(0, 1, 0) * CFrame.Angles(0, 0, 3.839724354387525)
				v21.Beam.Width0 = 50
				v21.Beam.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v21.Core.Flames.Enabled = false
				v21.Weld.Part0 = v20
				v21.Beam.CurveSize0 = -8
				v21.Beam.CurveSize1 = 8
				local v22 = v21.A0
				v22.CFrame = v22.CFrame - Vector3.new(3.6, 0, 0)
				local v23 = v21.A1
				v23.CFrame = v23.CFrame + Vector3.new(3.6, 0, 0)
				v21.Parent = workspace.Effects
				v_u_3:AddItem(v21, 1.1)
				v_u_13:PlaySound(v_u_9.Hakari.Counter.Startup, v20, game.SoundService.Effect)
				v_u_4:Create(v21.Weld, TweenInfo.new(0.3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["C1"] = v21.Weld.C1 * CFrame.Angles(0, 3.141592653589793, 0)
				}):Play()
				v_u_4:Create(v21.Beam, TweenInfo.new(0.3), {
					["Width0"] = 0
				}):Play()
			end
		end,
		["Jump"] = function(p24, p25)
			-- upvalues: (ref) v_u_5, (ref) v_u_4
			local v26 = p25.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if v26 then
				local v27 = v26.CFrame.LookVector * 5 - Vector3.new(0, 5, 0)
				if v_u_5.Character == v26.Parent then
					v_u_4:Create(p25, TweenInfo.new(0.5), {
						["P"] = 100000
					}):Play()
					repeat
						p25.Position = p24.Position - v27
						task.wait()
					until not (p25.Parent and p24)
				else
					repeat
						local v28 = v26.CFrame - v26.Position + p24.Position - v27
						v26.CFrame = v26.CFrame:Lerp(v28, 0.15)
						task.wait()
					until not (p25.Parent and p24)
				end
				v_u_4:Create(p25, TweenInfo.new(0.5), {
					["P"] = 100000
				}):Play()
				repeat
					p25.Position = p24.Position - v27
					task.wait()
				until not (p25.Parent and p24)
			end
		end,
		["JumpBurst"] = function(p29, p30)
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			if v_u_5.Character ~= p30 then
				local v31 = v_u_8.Itadori.CrushingBlow:Clone()
				v31.Position = p29
				v31.PointLight:Destroy()
				v31.Air:Destroy()
				v31.Parent = workspace.Effects
				v31.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v31.Floor.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v31.Floor.Ring:Emit(10)
				v31.Floor.Sparks:Emit(10)
				v31.Floor.Wind2:Emit(8)
				v_u_3:AddItem(v31, 1.5)
				v_u_13:PlaySound(v_u_9.Megumi.Mahoraga.Throw.Break, v31, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Itadori.CrushingBlow.GroundImpact, v31, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p_u_32, p_u_33)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_4, (ref) v_u_2
			local v34 = p_u_33:FindFirstChild("HumanoidRootPart")
			if v34 then
				local v35 = v_u_8.Mahito.CrushingRushdown.DrillImpact:Clone()
				v35.Position = v34.Position
				v35.Parent = workspace.Effects
				v_u_3:AddItem(v35, 1)
				v35.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v35.Wind.Color = v35.Sparks.Color
				v35.Wind2.Color = v35.Sparks.Color
				v35.Sparks:Emit(50)
				v35.Wind:Emit(7)
				v35.Wind2:Emit(7)
				v_u_13:Flash(p_u_33, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, v34, game.SoundService.Effect)
				if v_u_5.Character == p_u_32 or v_u_5.Character == p_u_33 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
				if v_u_5.Character == p_u_32 and p_u_32:GetAttribute("InUlt") then
					local v_u_36 = v_u_8.Todo.Debut.Flash:Clone()
					local v_u_37 = Instance.new("Camera", v_u_36.Main)
					v_u_36.Main.CurrentCamera = v_u_37
					v_u_36.Parent = v_u_5.PlayerGui
					v_u_4:Create(v_u_36.Fade, TweenInfo.new(0.2), {
						["BackgroundTransparency"] = 1
					}):Play()
					local v_u_38 = v_u_8.DomainWarn.Panel.Viewport.Display:Clone()
					v_u_38["Left Arm"].FingersL:Destroy()
					v_u_38["Right Arm"].FingersR:Destroy()
					v_u_38.Parent = v_u_36.Main
					pcall(function()
						-- upvalues: (ref) v_u_13, (copy) p_u_32, (copy) v_u_38
						v_u_13:ApplyCopyOutfit(p_u_32, v_u_38)
					end)
					v_u_38.Humanoid:LoadAnimation(v_u_36.User):Play(0)
					local v39 = v_u_8.Todo.Awakening.Takada:Clone()
					v39.Parent = v_u_36.Main
					v39.HumanoidRootPart.CFrame = v_u_38.HumanoidRootPart.CFrame
					v39.Humanoid:LoadAnimation(v_u_36.Takada):Play(0)
					local v_u_40 = v_u_8.DomainWarn.Panel.Viewport.Display:Clone()
					v_u_40["Left Arm"].FingersL:Destroy()
					v_u_40["Right Arm"].FingersR:Destroy()
					v_u_40.Parent = v_u_36.Main
					pcall(function()
						-- upvalues: (ref) v_u_13, (copy) p_u_33, (copy) v_u_40
						v_u_13:ApplyCopyOutfit(p_u_33, v_u_40)
					end)
					v_u_40.Humanoid:LoadAnimation(v_u_36.Target):Play(0)
					local v_u_41 = 0
					local v_u_42 = nil
					local v_u_43 = v_u_8.Todo.Debut.CameraData
					v_u_42 = v_u_2.RenderStepped:Connect(function(p44)
						-- upvalues: (ref) v_u_41, (copy) v_u_43, (copy) v_u_38, (copy) v_u_37, (ref) v_u_42
						v_u_41 = v_u_41 + p44 * 60
						local v45 = v_u_43.Frames
						local v46 = v_u_41
						local v47 = math.ceil(v46)
						local v48 = v45:FindFirstChild((tonumber(v47)))
						local v49 = v_u_43.FOV
						local v50 = v_u_41
						local v51 = math.ceil(v50)
						local v52 = v49:FindFirstChild((tonumber(v51)))
						if v48 and (v52 and v_u_38.Parent) then
							v_u_37.CFrame = v_u_38.HumanoidRootPart.CFrame * v48.Value
							v_u_37.FieldOfView = v52.Value
						else
							v_u_42:Disconnect()
						end
					end)
					task.delay(1, function()
						-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_4, (copy) v_u_36, (ref) v_u_8
						v_u_13:PlaySound(v_u_9.Todo.Debut.Jump, workspace, game.SoundService.Effect)
						v_u_13:PlaySound(v_u_9.Todo.Debut.Jump2, workspace, game.SoundService.Effect)
						task.wait(0.55)
						v_u_13:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, workspace, game.SoundService.Effect)
						task.wait(0.45)
						v_u_4:Create(v_u_36.Fade, TweenInfo.new(0.2), {
							["BackgroundTransparency"] = 0
						}):Play()
						task.wait(0.2)
						v_u_36:Destroy()
						local v53 = v_u_8.Itadori.DivergentFist.BlackFlashCC:Clone()
						v53.TintColor = Color3.fromRGB(255, 0, 255)
						v53.Parent = game.Lighting
						task.wait(0.03)
						v53.Brightness = 200
						v53.Contrast = -1000
						task.wait(0.03)
						v53.TintColor = Color3.new(1, 1, 1)
						v53.Brightness = -200
						v53.Contrast = 1000
						task.wait(0.03)
						v53:Destroy()
						game.Lighting.ExposureCompensation = 2
						v_u_4:Create(game.Lighting, TweenInfo.new(1), {
							["ExposureCompensation"] = 0
						}):Play()
					end)
				end
			end
		end,
		["Hit2"] = function(p54, p55)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v56 = p55:FindFirstChild("HumanoidRootPart")
			if v56 then
				local v57 = v_u_8.Mahito.CrushingRushdown.DrillImpact:Clone()
				v57.Position = v56.Position
				v57.Parent = workspace.Effects
				v_u_3:AddItem(v57, 1)
				v57.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v57.Wind.Color = v57.Sparks.Color
				v57.Wind2.Color = v57.Sparks.Color
				v57.Sparks:Emit(50)
				v57.Wind:Emit(7)
				v57.Wind2:Emit(7)
				v_u_13:Flash(p55, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Itadori.CraniumSmash.Hit2, v56, game.SoundService.Effect)
				v_u_13:PlaySound(v_u_9.Todo.BruteForce.Hit, v56, game.SoundService.Effect)
				if v_u_5.Character == p54 or v_u_5.Character == p55 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p59, ...)
		-- upvalues: (copy) v_u_58
		local v60 = v_u_58[p59]
		if v60 then
			v60(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("IdolDebutService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14