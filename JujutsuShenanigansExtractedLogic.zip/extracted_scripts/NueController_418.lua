-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "NueController"
})
local v_u_13 = RaycastParams.new()
v_u_13.FilterType = Enum.RaycastFilterType.Include
v_u_13.FilterDescendantsInstances = { workspace.Map, workspace.Spawns, workspace.Domains }
function v12.KnitStart(_)
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (copy) v_u_13, (ref) v_u_11, (copy) v_u_8, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10
	local v_u_54 = {
		["Nue"] = function(p14, p_u_15, p_u_16, p_u_17, p_u_18, p_u_19)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_13, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9, (ref) v_u_2
			local v20 = v_u_7.Megumi.Spawn:Clone()
			v20.Parent = workspace.Effects
			v_u_3:AddItem(v20, 1)
			local v21 = workspace:Raycast(p_u_15 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0), v_u_13)
			if v21 then
				p_u_15 = v21.Position - Vector3.new(0, 10, 0)
				v20.CFrame = CFrame.new(v21.Position, v21.Position + v21.Normal)
				v20.Shadow:Emit(12)
				v20.Dive:Emit(6)
			else
				v20.Position = p_u_15
				v20.Shadow.Orientation = Enum.ParticleOrientation.FacingCamera
				v20.Shadow:Emit(6)
			end
			local v_u_22 = v_u_7.Megumi.Nue:Clone()
			v_u_22.RootPart.CFrame = CFrame.new(p_u_15)
			v_u_22.Parent = workspace.Effects
			local v_u_23 = v_u_22.AnimationController:LoadAnimation(v_u_22.AnimationController.Summon)
			v_u_23:Play(0)
			v_u_11:PlaySound(v_u_8.Megumi.Nue.Spawn, v_u_22.RootPart, game.SoundService.Effect)
			if p_u_19 then
				v_u_4:Create(p_u_19, TweenInfo.new(0.75, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["P"] = 100000
				}):Play()
			end
			if v_u_5.Character == p14 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				if p_u_19 then
					p_u_19.Parent = p14["Right Arm"]
				end
			end
			local v_u_24 = v_u_22.RootPart.LowerTorso
			local v_u_25 = v_u_24.C0
			v_u_4:Create(v_u_24, TweenInfo.new(p_u_18 / 2), {
				["C0"] = v_u_25 * CFrame.Angles(0, 0, -0.6981317007977318)
			}):Play()
			task.delay(p_u_18 / 2, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_24, (copy) p_u_18, (copy) v_u_25, (copy) v_u_23
				local v26 = {
					["C0"] = v_u_25
				}
				v_u_4:Create(v_u_24, TweenInfo.new(p_u_18 / 2), v26):Play()
				task.wait(p_u_18 / 2)
				v_u_4:Create(v_u_24, TweenInfo.new(p_u_18 / 2), {
					["C0"] = v_u_25 * CFrame.Angles(0, 0, 0.5235987755982988)
				}):Play()
				v_u_23:AdjustSpeed(-0.7)
			end)
			local v_u_27 = tick()
			local v_u_28 = p_u_17
			local v_u_29 = nil
			v_u_29 = v_u_2.Stepped:Connect(function(_, _)
				-- upvalues: (copy) v_u_27, (copy) p_u_18, (ref) v_u_29, (copy) v_u_22, (ref) v_u_4, (ref) v_u_3, (ref) v_u_7, (copy) p_u_17, (ref) v_u_28, (copy) p_u_16, (ref) p_u_15, (copy) p_u_19, (ref) v_u_5
				local v30 = tick() - v_u_27
				if p_u_18 + 0.6 <= v30 then
					v_u_29:Disconnect()
					for _, v31 in v_u_22:GetDescendants() do
						if v31:IsA("BasePart") then
							v_u_4:Create(v31, TweenInfo.new(0.2), {
								["Color"] = Color3.new(0, 0, 0)
							}):Play()
						end
					end
					v_u_3:AddItem(v_u_22, 0.2)
					local v32 = v_u_7.Megumi.Spawn:Clone()
					v32.CFrame = v_u_22.RootPart.CFrame
					v32.Shadow.LockedToPart = true
					v32.Parent = workspace.Effects
					local v33 = v_u_22.RootPart.CFrame + v_u_22.RootPart.CFrame.LookVector * 20
					v_u_4:Create(v_u_22.RootPart, TweenInfo.new(0.5, Enum.EasingStyle.Quad), {
						["CFrame"] = v33
					}):Play()
					v_u_4:Create(v32, TweenInfo.new(0.5, Enum.EasingStyle.Quad), {
						["CFrame"] = v33
					}):Play()
					v32.Shadow.Orientation = Enum.ParticleOrientation.FacingCamera
					v32.Shadow.EmissionDirection = Enum.NormalId.Right
					v32.Shadow.Lifetime = NumberRange.new(0.3, 0.6)
					v32.Shadow.Speed = NumberRange.new(-100, 100)
					v32.Shadow.Drag = 5
					v32.Shadow:Emit(30)
					v_u_3:AddItem(v32, 1)
				else
					local v34 = p_u_17
					if typeof(v34) ~= "Vector3" then
						v_u_28 = p_u_17.Position
					end
					local v35 = v_u_28 + CFrame.new(p_u_16, v_u_28).LookVector * 50 + Vector3.new(0, 40, 0)
					local v36
					if p_u_18 <= v30 then
						local v37 = (v30 - p_u_18) / 0.6
						local v38 = v_u_28
						local v39 = (v35 + v_u_28) / 2 - Vector3.new(0, 10, 0)
						v36 = (1 - v37) ^ 2 * v38 + 2 * (1 - v37) * v37 * v39 + v37 ^ 2 * v35
					else
						local v40 = v30 / p_u_18
						local v41 = p_u_15
						local v42 = p_u_16
						local v43 = v_u_28
						v36 = (1 - v40) ^ 2 * v41 + 2 * (1 - v40) * v40 * v42 + v40 ^ 2 * v43
					end
					v_u_22.RootPart.CFrame = CFrame.new(v36, v36 + (v36 - v_u_22.RootPart.Position).Unit)
					if p_u_19 and p_u_19.Parent then
						local v44 = p_u_19.Parent.Parent:FindFirstChild("HumanoidRootPart")
						if not v44 then
							return
						end
						if v_u_5.Character == v44.Parent then
							local v45 = v_u_22.RightLeg.CFrame.UpVector * -3
							p_u_19.Position = v_u_22.RightLeg.Position - v45
							return
						end
						local v46 = v_u_22.RightLeg.CFrame.UpVector * 1.5 - v_u_22.RightLeg.CFrame.LookVector * 4
						local v47 = v44.CFrame - v44.Position + v_u_22.RightLeg.Position - v46
						v44.CFrame = v44.CFrame - v44.Position + v44.CFrame:Lerp(v47, p_u_19.P / 100000).Position
					end
				end
			end)
		end,
		["Hit"] = function(p48, p49)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v50 = p49:FindFirstChild("HumanoidRootPart")
			if v50 then
				local v51 = v_u_7.Megumi.NueShock:Clone()
				v51.Parent = workspace.Effects
				v_u_3:AddItem(v51, 1)
				v51.CFrame = v50.CFrame
				v51.Hit:Emit(20)
				v_u_4:Create(v51.Electric, TweenInfo.new(0.2), {
					["Rate"] = 0
				}):Play()
				v_u_11:Flash(p49, Color3.fromRGB(255, 85, 255), 1)
				v_u_11:PlaySound(v_u_8.Megumi.Nue.Hit1, v50, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_8.Megumi.Nue.Hit2, v50, game.SoundService.Effect)
				if v_u_5 == p48 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				elseif v_u_5.Character == p49 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			else
				return
			end
		end,
		["Finisher"] = function(p52)
			-- upvalues: (ref) v_u_11, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7
			if p52.HumanoidRootPart then
				v_u_11:Burn(p52)
				if v_u_5.Character == p52 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v53 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
					v53.TintColor = Color3.new(1, 1, 1)
					v53.Parent = game.Lighting
					task.wait(0.04)
					v53.TintColor = Color3.new(1, 0, 0.498039)
					task.wait(0.04)
					v53.Brightness = 200
					v53.Contrast = -1000
					task.wait(0.04)
					v53:Destroy()
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p55, ...)
		-- upvalues: (copy) v_u_54
		local v56 = v_u_54[p55]
		if v56 then
			v56(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("NueService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12