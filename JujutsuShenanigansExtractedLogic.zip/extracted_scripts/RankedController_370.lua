-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_2 = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
require(v3.Modules.Icon)
local _ = v3.Animations
local _ = v3.Utils
local v_u_4 = v3.Sounds
require(v3.Modules.CameraShaker)
require(v3.Modules.MVP)
local v_u_5 = require(game.ReplicatedStorage.Modules.CountryCodes)
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "RankedController"
})
function getFlagEmoji(p11)
	local v12 = {
		["a"] = "\240\159\135\166",
		["b"] = "\240\159\135\167",
		["c"] = "\240\159\135\168",
		["d"] = "\240\159\135\169",
		["e"] = "\240\159\135\170",
		["f"] = "\240\159\135\171",
		["g"] = "\240\159\135\172",
		["h"] = "\240\159\135\173",
		["i"] = "\240\159\135\174",
		["j"] = "\240\159\135\175",
		["k"] = "\240\159\135\176",
		["l"] = "\240\159\135\177",
		["m"] = "\240\159\135\178",
		["n"] = "\240\159\135\179",
		["o"] = "\240\159\135\180",
		["p"] = "\240\159\135\181",
		["q"] = "\240\159\135\182",
		["r"] = "\240\159\135\183",
		["s"] = "\240\159\135\184",
		["t"] = "\240\159\135\185",
		["u"] = "\240\159\135\186",
		["v"] = "\240\159\135\187",
		["w"] = "\240\159\135\188",
		["x"] = "\240\159\135\189",
		["y"] = "\240\159\135\190",
		["z"] = "\240\159\135\191"
	}
	local v13 = string.lower(p11)
	local v14 = string.sub(v13, 1, 1)
	local v15 = string.sub(v13, 2, 2)
	return v12[v14] .. v12[v15]
end
function v10.KnitStart(_)
	-- upvalues: (copy) v_u_2, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (copy) v_u_4, (ref) v_u_6, (copy) v_u_5
	local v_u_16 = v_u_2.PlayerGui:WaitForChild("Menus").Group
	local v_u_17 = v_u_16.Ranked
	v_u_17:SetAttribute("Loaded", true)
	task.spawn(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_8
		repeat
			task.wait()
		until workspace:GetAttribute("Init") == true
		if workspace:GetAttribute("Match") == nil then
			if workspace:GetAttribute("Roulette") ~= nil then
				v_u_8:Start()
			end
		else
			v_u_7:Start()
		end
	end)
	local function v_u_20()
		-- upvalues: (copy) v_u_17
		for _, v18 in v_u_17:GetChildren() do
			if v18.Name == "Loading" then
				v18.Visible = true
			elseif v18:IsA("GuiObject") then
				v18.Visible = false
			end
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_17
			repeat
				local v19 = v_u_17.Loading.Icon
				v19.Rotation = v19.Rotation + 1
				task.wait()
			until v_u_17.Loading.Visible == false
		end)
	end
	v_u_17.Modes.Ranked.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_20, (ref) v_u_6
		v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_20()
		v_u_6.Teleport:Fire(1)
	end)
	v_u_17.Modes.Servers.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_17
		v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v21 in v_u_17:GetChildren() do
			if v21:IsA("GuiObject") then
				v21.Visible = false
			end
		end
		v_u_17.Servers.Visible = true
		v_u_17.Return.Visible = true
		v_u_17.Load.Visible = true
		v_u_17.Create.Visible = true
	end)
	v_u_17.Return.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_17
		v_u_9:PlaySound(v_u_4.Misc.UI.Switch, workspace, game.SoundService.Effect)
		for _, v22 in v_u_17:GetChildren() do
			if v22:IsA("GuiObject") then
				v22.Visible = false
			end
		end
		v_u_17.Modes.Visible = true
		v_u_17.JoinFriend.Visible = true
	end)
	v_u_17.Create.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_17
		v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v23 in v_u_17:GetChildren() do
			if v23:IsA("GuiObject") then
				v23.Visible = false
			end
		end
		v_u_17.Create2.Visible = true
		v_u_17.Return.Visible = true
	end)
	v_u_17.JoinFriend.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_17, (ref) v_u_2, (copy) v_u_16, (copy) v_u_20, (ref) v_u_6
		v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v24 in v_u_17:GetChildren() do
			if v24:IsA("GuiObject") then
				v24.Visible = false
			end
		end
		v_u_17.Return.Visible = true
		v_u_17.Friends.Visible = true
		local v25 = v_u_2:GetFriendsOnline(200)
		for _, v26 in v_u_17.Friends:GetChildren() do
			if v26:IsA("Frame") then
				v26:Destroy()
			end
		end
		for _, v_u_27 in v25 do
			if v_u_27.LocationType == 4 and v_u_27.PlaceId == game.PlaceId then
				local v_u_28 = v_u_16.Parent.Preset.FriendServer:Clone()
				v_u_28.Title.Text = v_u_27.DisplayName
				v_u_28.Count.Visible = false
				v_u_28.Desc.Text = "@" .. v_u_27.UserName
				task.spawn(function()
					-- upvalues: (copy) v_u_27, (copy) v_u_28
					local v29 = game.Players:GetUserThumbnailAsync(v_u_27.VisitorId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size48x48)
					v_u_28.FriendIcon.Image = v29
				end)
				v_u_28.Parent = v_u_17.Friends
				v_u_28.Button.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_9, (ref) v_u_4, (ref) v_u_20, (ref) v_u_6, (copy) v_u_27
					v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_20()
					v_u_6.Teleport:Fire(6, v_u_27.VisitorId)
				end)
			end
		end
	end)
	local v_u_30 = 5
	v_u_17.Modes.Public.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_20, (ref) v_u_6
		v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_20()
		v_u_6.Teleport:Fire(2)
	end)
	v_u_17.Modes.Roulette.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_17, (ref) v_u_6, (ref) v_u_30
		v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v31 in v_u_17:GetChildren() do
			if v31:IsA("GuiObject") then
				v31.Visible = false
			end
		end
		for _, v32 in v_u_17.GamemodeServers:GetChildren() do
			if v32:IsA("Frame") and v32.Name == "RouServer" then
				v32:Destroy()
			end
		end
		v_u_17.GamemodeServers.Visible = true
		v_u_17.Return.Visible = true
		v_u_6.Filter:Fire(2)
		v_u_30 = 5
	end)
	v_u_17.Modes.Creator.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_17, (ref) v_u_6, (ref) v_u_30
		v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v33 in v_u_17:GetChildren() do
			if v33:IsA("GuiObject") then
				v33.Visible = false
			end
		end
		for _, v34 in v_u_17.GamemodeServers:GetChildren() do
			if v34:IsA("Frame") and v34.Name == "RouServer" then
				v34:Destroy()
			end
		end
		v_u_17.GamemodeServers.Visible = true
		v_u_17.Return.Visible = true
		v_u_6.Filter:Fire(3)
		v_u_30 = 7
	end)
	v_u_17.Modes.Chara.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_17, (ref) v_u_6, (ref) v_u_30
		v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v35 in v_u_17:GetChildren() do
			if v35:IsA("GuiObject") then
				v35.Visible = false
			end
		end
		for _, v36 in v_u_17.GamemodeServers:GetChildren() do
			if v36:IsA("Frame") and v36.Name == "RouServer" then
				v36:Destroy()
			end
		end
		v_u_17.GamemodeServers.Visible = true
		v_u_17.Return.Visible = true
		v_u_6.Filter:Fire(4)
		v_u_30 = 8
	end)
	v_u_17.GamemodeServers.QuickJoin.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_20, (ref) v_u_6, (ref) v_u_30
		v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_20()
		v_u_6.Teleport:Fire(v_u_30, true)
	end)
	v_u_17.GamemodeServers.QuickJoinGlobal.Button.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_20, (ref) v_u_6, (ref) v_u_30
		v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_20()
		v_u_6.Teleport:Fire(v_u_30)
	end)
	local v_u_37 = v_u_17.Create2.TextBox
	v_u_37.FocusLost:Connect(function(p38)
		-- upvalues: (copy) v_u_37, (ref) v_u_6
		if p38 then
			local v39 = v_u_37.Text
			v_u_37.Text = "Filtering..."
			v_u_37.TextEditable = false
			v_u_6.Filter:Fire(v39)
		end
	end)
	v_u_17.Create2.Create.MouseButton1Down:Connect(function()
		-- upvalues: (copy) v_u_37, (ref) v_u_9, (ref) v_u_4, (copy) v_u_20, (ref) v_u_6
		if v_u_37.TextEditable ~= false then
			v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_20()
			v_u_6.Teleport:Fire(3, v_u_37.Text)
		end
	end)
	local v_u_40 = false
	local v_u_41 = false
	v_u_17.Load.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_40, (ref) v_u_9, (ref) v_u_4, (ref) v_u_6, (ref) v_u_41, (copy) v_u_17
		if v_u_40 ~= true then
			v_u_40 = true
			v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
			v_u_6.Filter:Fire(1, v_u_41)
			for _, v42 in v_u_17.Servers:GetChildren() do
				if v42:IsA("Frame") then
					v42:Destroy()
				end
			end
			v_u_17.Load.Loading.Visible = true
			repeat
				task.wait()
			until v_u_40 == false
			v_u_17.Load.Loading.Visible = false
		end
	end)
	v_u_17.Load.Sort.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_41, (copy) v_u_17
		v_u_41 = not v_u_41
		v_u_17.Load.Sort.Rotation = v_u_41 and 180 or 0
	end)
	v_u_17.Create2.Rejoin.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (copy) v_u_20, (ref) v_u_6, (ref) v_u_2
		v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_20()
		v_u_6.Teleport:Fire(4, v_u_2.UserId)
	end)
	v_u_6.Teleport:Connect(function()
		-- upvalues: (copy) v_u_17
		for _, v43 in v_u_17:GetChildren() do
			if v43:IsA("GuiObject") then
				v43.Visible = false
			end
		end
		v_u_17.Modes.Visible = true
		v_u_17.JoinFriend.Visible = true
	end)
	local v_u_44 = nil
	local function v_u_54(p45)
		-- upvalues: (copy) v_u_17, (ref) v_u_5, (ref) v_u_44, (copy) v_u_16, (ref) v_u_41, (ref) v_u_9, (ref) v_u_4, (copy) v_u_20, (ref) v_u_6
		local v46 = string.lower(v_u_17.Create.Searchbox.Text)
		local v47 = nil
		local v48
		if string.sub(v46, 3, 3) == " " then
			v48 = string.upper((string.sub(v46, 1, 2)))
			v46 = string.sub(v46, 4)
			if v_u_5.ContinentCode[v48] then
				v47 = v_u_5.ContinentCode[v48]
				v48 = nil
			end
		else
			v48 = nil
		end
		local v49 = tick()
		v_u_44 = v49
		for v50, v_u_51 in p45 do
			if v_u_44 ~= v49 then
				break
			end
			local v52 = v_u_51.value[6] or 1
			local v53 = v_u_16.Parent.Preset.PrivateServer:Clone()
			v53.Name = v_u_51.key
			v53.Desc.Text = getFlagEmoji(v_u_51.value[4]) .. " " .. v_u_51.value[1]
			v53.Title.Text = v_u_51.value[2]
			v53.Count.Text = v52 .. "/20"
			v53:SetAttribute("CC", v_u_51.value[4])
			v53.LayoutOrder = v_u_41 == true and v52 and v52 or -v52
			v53.Button.Image = "rbxassetid://" .. (v_u_51.value[5] or 0)
			v53.Parent = v_u_17.Servers
			if v48 and v_u_51.value[4] ~= v48 or (v47 and v_u_5.CountryCodes[v_u_51.value[4]] ~= v47 or not string.match(string.lower(v_u_51.value[2]), v46)) then
				v53.Visible = false
			else
				v53.Visible = true
			end
			v53.Button.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_9, (ref) v_u_4, (ref) v_u_20, (ref) v_u_6, (copy) v_u_51
				v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
				v_u_20()
				v_u_6.Teleport:Fire(4, v_u_51.key)
			end)
			if v50 % 15 == 0 then
				task.wait()
			end
		end
	end
	local function v_u_61(p55, p_u_56)
		-- upvalues: (copy) v_u_17, (copy) v_u_16, (ref) v_u_9, (ref) v_u_4, (copy) v_u_20, (ref) v_u_6
		for _, v57 in v_u_17.GamemodeServers:GetChildren() do
			if v57:IsA("Frame") and (v57.Name ~= "QuickJoin" and v57.Name ~= "QuickJoinGlobal") then
				v57:Destroy()
			end
		end
		for v_u_58, v59 in p55 do
			local v60 = v_u_16.Parent.Preset.RouServer:Clone()
			v60.Name = v_u_58
			v60.Count.Text = v59
			v60.Title.Text = getFlagEmoji(v_u_58) .. " " .. v_u_58
			v60.Parent = v_u_17.GamemodeServers
			v60.Button.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_9, (ref) v_u_4, (ref) v_u_20, (ref) v_u_6, (copy) p_u_56, (copy) v_u_58
				v_u_9:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
				v_u_20()
				v_u_6.Teleport:Fire(p_u_56, v_u_58)
			end)
		end
	end
	v_u_17.Create.Searchbox:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_17, (ref) v_u_5
		local v62 = string.lower(v_u_17.Create.Searchbox.Text)
		local v63 = nil
		local v64
		if string.sub(v62, 3, 3) == " " then
			v64 = string.upper((string.sub(v62, 1, 2)))
			v62 = string.sub(v62, 4)
			if v_u_5.ContinentCode[v64] then
				v63 = v_u_5.ContinentCode[v64]
				v64 = nil
			end
		else
			v64 = nil
		end
		for _, v65 in v_u_17.Servers:GetChildren() do
			if v65:IsA("Frame") then
				local v66 = v65:GetAttribute("CC")
				if v64 and v66 ~= v64 or (v63 and v_u_5.CountryCodes[v66] ~= v63 or not string.match(string.lower(v65.Title.Text), v62)) then
					v65.Visible = false
				else
					v65.Visible = true
				end
			end
		end
	end)
	v_u_17:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_17
		if v_u_17.Visible ~= true then
			for _, v67 in v_u_17.Servers:GetChildren() do
				if v67:IsA("Frame") then
					v67:Destroy()
				end
			end
		end
	end)
	v_u_6.Filter:Connect(function(p_u_68, p69)
		-- upvalues: (copy) v_u_37, (copy) v_u_61, (copy) v_u_54, (ref) v_u_40
		if typeof(p_u_68) == "string" then
			v_u_37.Text = p_u_68
			v_u_37.TextEditable = true
			return
		elseif p69 == "ROULETTE" then
			pcall(function()
				-- upvalues: (ref) v_u_61, (copy) p_u_68
				v_u_61(p_u_68, 5)
			end)
			return
		elseif p69 == "CREATOR" then
			pcall(function()
				-- upvalues: (ref) v_u_61, (copy) p_u_68
				v_u_61(p_u_68, 7)
			end)
		else
			local v70, v71 = pcall(function()
				-- upvalues: (ref) v_u_54, (copy) p_u_68
				v_u_54(p_u_68)
			end)
			if not v70 then
				warn(v71)
			end
			v_u_40 = false
		end
	end)
end
function v10.KnitInit(_)
	-- upvalues: (ref) v_u_6, (copy) v_u_1, (ref) v_u_9, (ref) v_u_8, (ref) v_u_7
	v_u_6 = v_u_1.GetService("RankedService")
	v_u_9 = v_u_1.GetController("FXController")
	v_u_8 = v_u_1.GetController("RouletteController")
	v_u_7 = v_u_1.GetController("DuelController")
end
return v10