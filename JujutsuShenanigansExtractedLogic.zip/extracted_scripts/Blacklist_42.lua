-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "blacklist",
	["Description"] = "Add an ID to the killsound or billboard blacklist",
	["Group"] = { "Owner", "Developer", "HeadMod" },
	["Args"] = {
		{
			["Type"] = "number",
			["Name"] = "ID"
		}
	}
}
return v1