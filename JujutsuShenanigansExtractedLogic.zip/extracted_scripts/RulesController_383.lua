-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_2 = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local _ = v3.Utils
local _ = v3.Sounds
local v_u_4 = nil
local v_u_5 = nil
local v6 = v_u_1.CreateController({
	["Name"] = "RulesController"
})
v6.Rules = require(v3.Modules.Rules)
function v6.KnitStart(p_u_7)
	-- upvalues: (copy) v_u_2, (ref) v_u_4
	local v_u_8 = v_u_2.PlayerGui:WaitForChild("Menus").Group.Rules
	v_u_8:SetAttribute("Loaded", true)
	local v9 = v_u_8.ScrollingFrame.Rule
	for v10, v11 in p_u_7.Rules.List do
		local v12 = v9:Clone()
		v12.Text = ("- %*"):format(v11)
		v12.LayoutOrder = v10
		v12.Parent = v_u_8.ScrollingFrame
	end
	local v_u_13 = v_u_2:GetAttribute("LastRulesAccepted")
	if not v_u_13 then
		v_u_2:GetAttributeChangedSignal("LastRulesAccepted"):Wait()
		v_u_13 = v_u_2:GetAttribute("LastRulesAccepted")
	end
	if v_u_13 ~= p_u_7.Rules.Version then
		v_u_8.Accept.Visible = true
		v_u_2:GetAttributeChangedSignal("LastRulesAccepted"):Once(function()
			-- upvalues: (ref) v_u_13, (ref) v_u_2, (copy) p_u_7, (copy) v_u_8
			v_u_13 = v_u_2:GetAttribute("LastRulesAccepted")
			if v_u_13 == p_u_7.Rules.Version then
				v_u_8.Accept.Visible = false
			end
		end)
	end
	v_u_8.Accept.MouseButton1Click:Connect(function()
		-- upvalues: (copy) v_u_8, (ref) v_u_4
		if v_u_8.Accept.Text ~= "..." then
			v_u_8.Accept.Text = "..."
			v_u_4.AcceptRules:Fire()
		end
	end)
end
function v6.KnitInit(_)
	-- upvalues: (ref) v_u_5, (copy) v_u_1, (ref) v_u_4
	v_u_5 = v_u_1.GetController("FXController")
	v_u_4 = v_u_1.GetService("JoinService")
end
return v6