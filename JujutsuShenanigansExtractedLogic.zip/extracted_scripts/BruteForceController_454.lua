-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "BruteForceController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_33 = {
		["Swing"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_7.Todo.BruteForce.Start, v14, game.SoundService.Effect)
			end
		end,
		["UhOH"] = function(p15)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_11:PlaySound(v_u_7.Todo.Woosh, v16, game.SoundService.Music)
			end
		end,
		["Woosh"] = function(p17, p18)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v20.CFrame = v19.CFrame * CFrame.new(2, 1, -5)
				v20.Parent = workspace.Effects
				v20.Wind:Emit(20)
				if p18 then
					v20.Sparks:Emit(20)
					v_u_3:Create(v20.PointLight, TweenInfo.new(0.6), {
						["Brightness"] = 0
					}):Play()
					v_u_11:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlash, v19, game.SoundService.Effect)
				else
					v20.PointLight:Destroy()
				end
				v20.Back1.Back:Emit(1)
				v20.Back2.Back:Emit(1)
				v_u_3:Create(v20.Back1, TweenInfo.new(2), {
					["CFrame"] = v20.Back1.CFrame - v20.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_3:Create(v20.Back2, TweenInfo.new(2), {
					["CFrame"] = v20.Back2.CFrame - v20.Back2.CFrame.LookVector * 20
				}):Play()
				v_u_2:AddItem(v20, 3)
				local v21 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v21.Size = Vector3.new(6, 30, 6)
				v21.CFrame = v19.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v21.Parent = workspace.Effects
				v_u_2:AddItem(v21, 0.2)
				v_u_3:Create(v21, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = v21.Position + v19.CFrame.LookVector * 10
				}):Play()
				v_u_11:PlaySound(v_u_7.Mahito.Stockpile.Swing2, v19, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Todo.BruteForce.Swing, v19, game.SoundService.Effect)
				if v_u_4.Character == p17 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Hit"] = function(p22, p23)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				local v25 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v25.Position = v24.Position
				v25.Parent = workspace.Effects
				v_u_2:AddItem(v25, 1)
				v25.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v25.Wind.Color = v25.Sparks.Color
				v25.Wind2.Color = v25.Sparks.Color
				v25.Sparks:Emit(50)
				v25.Wind:Emit(7)
				v25.Wind2:Emit(7)
				v_u_11:Flash(p23, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v24, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Todo.BruteForce.Hit, v24, game.SoundService.Effect)
				if v_u_4 == p22 or v_u_4.Character == p23 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["BlackFlashHit"] = function(p26, p27, p28)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v_u_29 = p26:FindFirstChild("HumanoidRootPart")
			if v_u_29 then
				local v30 = p27:FindFirstChild("HumanoidRootPart")
				if v30 then
					local v_u_31 = v_u_6.Todo.BlackFlashHit:Clone()
					v_u_31.Position = v30.Position
					v_u_31.Parent = workspace.Effects
					v_u_2:AddItem(v_u_31, 2)
					v_u_11:Flash(p27, Color3.new(1, 0, 0), 2)
					v_u_11:PlaySound(v_u_7.Mahito.BlackFlash, v30, game.SoundService.Effect)
					task.delay(0.07, function()
						-- upvalues: (copy) v_u_31, (ref) v_u_3
						v_u_31.Wind2:Emit(10)
						v_u_31.Sparks:Emit(40)
						v_u_31.Sparks2:Emit(30)
						v_u_31.Lightning:Emit(10)
						v_u_3:Create(v_u_31, TweenInfo.new(0.1), {
							["Size"] = Vector3.new(18, 18, 18),
							["Transparency"] = 1
						}):Play()
					end)
					if p28 then
						v_u_11:PlaySound(v_u_7.Todo.Wapam, v_u_29, game.SoundService.Music)
						v_u_11:Bleed(p27)
						task.delay(0.2, function()
							-- upvalues: (ref) v_u_11, (ref) v_u_7, (copy) v_u_29
							v_u_11:PlaySound(v_u_7.Todo.WapamVoice, v_u_29, game.SoundService.Voice)
						end)
					end
					if v_u_4.Character == p26 or v_u_4.Character == p27 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
						local v32 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v32.Parent = game.Lighting
						task.wait(0.03)
						v32.Brightness = 200
						v32.Contrast = -1000
						task.wait(0.03)
						v32.TintColor = Color3.new(1, 1, 1)
						v32.Brightness = -200
						v32.Contrast = 1000
						task.wait(0.03)
						v32:Destroy()
						if p28 then
							game.Lighting.ExposureCompensation = 2
							v_u_3:Create(game.Lighting, TweenInfo.new(1), {
								["ExposureCompensation"] = 0
							}):Play()
						end
					end
				end
			else
				return
			end
		end
	}
	v_u_9.Effects:Connect(function(p34, ...)
		-- upvalues: (copy) v_u_33
		local v35 = v_u_33[p34]
		if v35 then
			v35(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("BruteForceService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12