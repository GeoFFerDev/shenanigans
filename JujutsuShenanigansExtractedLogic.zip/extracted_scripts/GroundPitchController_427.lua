-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "GroundPitchController"
})
local v12 = RaycastParams.new()
v12.FilterType = Enum.RaycastFilterType.Include
v12.FilterDescendantsInstances = { workspace.Map, workspace.Spawns, workspace.Domains }
function v11.KnitStart(_)
	-- upvalues: (copy) v_u_8, (ref) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_6, (copy) v_u_2, (ref) v_u_9
	local v_u_47 = {
		["Crunch"] = function(p13, p_u_14, p15)
			-- upvalues: (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_6
			local v_u_16 = p13:FindFirstChild("HumanoidRootPart")
			if v_u_16 then
				local v17 = TweenInfo.new(0.5)
				local v18 = #p15
				local v19 = (workspace.CurrentCamera.CFrame.Position - p_u_14.Position).Magnitude
				if v19 < 40 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				task.delay(0.3, function()
					-- upvalues: (copy) p_u_14, (copy) v_u_16, (ref) v_u_10, (ref) v_u_7
					if p_u_14.Parent and v_u_16.Parent then
						v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Wind, v_u_16, game.SoundService.Effect)
					end
				end)
				if v19 <= 75 then
					for _, v20 in p15 do
						local v21 = Instance.new("Part")
						v21.CanCollide = false
						v21.Massless = true
						v21.Position = v20[1]
						v21.Orientation = v20[2]
						v21.Color = v20[3]
						v21.Material = v20[4]
						v21.Size = v20[5]
						v21.Transparency = v20[6]
						v21.Parent = p_u_14.Rocks
						local v22 = Instance.new("Weld")
						v22.C1 = p_u_14.CFrame:ToObjectSpace(v21.CFrame)
						v22.Part1 = v21
						v22.Part0 = p_u_14
						v22.Parent = v21
						local v23 = v_u_4
						local v24 = {}
						local v25 = CFrame.new(math.random(-v18, v18) / 20, math.random(-v18, v18) / 20, math.random(-v18, v18) / 20)
						local v26 = CFrame.Angles
						local v27 = math.random(0, 360)
						local v28 = math.rad(v27)
						local v29 = math.random(0, 360)
						local v30 = math.rad(v29)
						local v31 = math.random(0, 360)
						v24.C1 = v25 * v26(v28, v30, (math.rad(v31)))
						v23:Create(v22, v17, v24):Play()
					end
					p_u_14.Destroying:Connect(function()
						-- upvalues: (copy) p_u_14, (ref) v_u_3, (ref) v_u_4, (ref) v_u_6, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8
						local v32 = TweenInfo.new(3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
						for v33, v34 in p_u_14.Rocks:GetChildren() do
							if v33 <= 25 then
								v34.CanCollide = true
								v34.CollisionGroup = "Effects"
								v34.Parent = workspace.Effects
								v_u_3:AddItem(v34, 3)
								v_u_4:Create(v34, v32, {
									["Size"] = Vector3.new(0, 0, 0)
								}):Play()
							end
						end
						local v35 = p_u_14.Ring
						local v36 = v_u_6.Megumi.Mahoraga.Rock:Clone()
						v36.Transparency = 1
						v36.Anchored = true
						v36.CFrame = p_u_14.CFrame
						v36.Parent = workspace.Effects
						v35.Parent = v36
						v36.Attachment.Dust:Emit(20)
						v36.Attachment.Hit:Emit(20)
						v36.Attachment.Sparks:Emit(20)
						v_u_3:AddItem(v36, 1.5)
						v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v36, game.SoundService.Effect)
						if (workspace.CurrentCamera.CFrame.Position - p_u_14.Position).Magnitude < 40 then
							v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						end
					end)
				end
			else
				return
			end
		end,
		["Throw"] = function(p37)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v38 = p37:FindFirstChild("HumanoidRootPart")
			if v38 then
				v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Throw, v38, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p_u_39)
			-- upvalues: (ref) v_u_2
			local v_u_40 = p_u_39.CFrame
			local v_u_41 = tick()
			local v_u_42 = p_u_39:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_40, (copy) p_u_39, (ref) v_u_41
				v_u_40 = p_u_39.CFrame
				v_u_41 = tick()
			end)
			local v_u_43 = nil
			v_u_43 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_39, (ref) v_u_43, (copy) v_u_42, (ref) v_u_40, (ref) v_u_41
				if p_u_39.Parent then
					workspace:BulkMoveTo({ p_u_39 }, { v_u_40 + v_u_40.LookVector * (150 * (tick() - v_u_41)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_43:Disconnect()
					v_u_42:Disconnect()
				end
			end)
		end,
		["Hit"] = function(p44)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v45 = p44:FindFirstChild("HumanoidRootPart")
			if v45 then
				v_u_10:Flash(p44, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit1"), v45, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Itadori.Rush.RushHit, v45, game.SoundService.Effect)
			end
		end,
		["Finisher"] = function(p46)
			-- upvalues: (ref) v_u_10
			if p46.HumanoidRootPart then
				v_u_10:Bleed(p46)
			end
		end
	}
	v_u_9.Effects:Connect(function(p48, ...)
		-- upvalues: (copy) v_u_47
		local v49 = v_u_47[p48]
		if v49 then
			v49(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("GroundPitchService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11