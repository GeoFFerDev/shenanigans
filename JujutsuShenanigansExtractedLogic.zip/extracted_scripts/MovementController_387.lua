-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game.Players.LocalPlayer
local v7 = game.ReplicatedStorage
local v_u_8 = v7.Animations
local v_u_9 = v7.Utils
local v_u_10 = v7.Sounds
local v_u_11 = UserSettings().GameSettings
local v_u_12 = require(v7.Modules.CameraShaker)
local v_u_13 = require(v7.TEMP_CHARA_STUFF.CharaDash)
local v14 = v_u_1.CreateController({
	["Name"] = "MovementController"
})
local v_u_15 = tick()
_G.Shift = false
v14.LockOn = nil
local v16 = RaycastParams.new()
v16.FilterType = Enum.RaycastFilterType.Include
v16.FilterDescendantsInstances = { workspace.Map }
_G.MapParams = v16
local v_u_17 = v_u_8.Misc.Movement.Parkour
local v_u_18 = v_u_10.Misc.Footstep.Water
local v_u_19 = {
	[Enum.Material.Plastic] = "rbxassetid://5761648082",
	[Enum.Material.SmoothPlastic] = "rbxassetid://5761648082",
	[Enum.Material.Slate] = "rbxassetid://5639243489",
	[Enum.Material.Concrete] = "rbxassetid://5639243489",
	[Enum.Material.Brick] = "rbxassetid://5639243489",
	[Enum.Material.Cobblestone] = "rbxassetid://5639243489",
	[Enum.Material.Fabric] = "rbxassetid://619083295",
	[Enum.Material.Glass] = "rbxassetid://3437778169",
	[Enum.Material.Metal] = "rbxassetid://5639245164",
	[Enum.Material.DiamondPlate] = "rbxassetid://5639245590",
	[Enum.Material.Wood] = "rbxassetid://5632735811",
	[Enum.Material.WoodPlanks] = "rbxassetid://5632735811",
	[Enum.Material.Grass] = "rbxassetid://5639244517",
	[Enum.Material.Ground] = "rbxassetid://5639243992",
	[Enum.Material.Sand] = "rbxassetid://5639245918",
	[Enum.Material.Snow] = "rbxassetid://7437372937"
}
local v_u_20 = nil
local v_u_21 = {
	["Back"] = Vector3.new(0, 0, 1),
	["Front"] = Vector3.new(0, 0, -1),
	["Left"] = Vector3.new(-1, 0, 0),
	["Right"] = Vector3.new(1, 0, 0)
}
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = 0
local v_u_25 = {
	["Vault"] = {
		"125187993473697",
		"95602001882956",
		"107860751460547",
		"79201532345509"
	},
	["Dive"] = { "98195977533316", "85222050280022" },
	["Slide"] = { "98500512116998" },
	["Climb"] = { "104763108763761" },
	["BounceR"] = { "94327920127463" },
	["BounceL"] = { "113609963676386" }
}
local v_u_26 = nil
local v_u_27 = 0
local v_u_28 = nil
local v_u_29 = nil
for v30, v31 in v_u_19 do
	local v32 = v_u_18:Clone()
	v32.SoundId = v31
	v32.Parent = v_u_18.Parent
	v_u_19[v30] = v32
end
function v14.Dash(_, p33, p_u_34, p35)
	-- upvalues: (copy) v_u_13, (ref) v_u_20, (copy) v_u_10, (copy) v_u_6, (copy) v_u_21, (copy) v_u_8, (ref) v_u_15, (ref) v_u_22, (copy) v_u_4, (copy) v_u_5, (copy) v_u_3
	local v_u_36 = p_u_34.HumanoidRootPart
	if v_u_36 then
		local v_u_37 = p_u_34.Humanoid
		if v_u_37 then
			if p_u_34:GetAttribute("Moveset") == "Chara" then
				v_u_13(p_u_34, p35)
			else
				v_u_20:PlaySound(v_u_10.Misc.Dash, v_u_36, game.SoundService.Effect)
				local v38 = v_u_20
				local v39 = 0.4
				local v40 = p35 == "Left" and CFrame.new() or (p35 == "Back" and CFrame.Angles(0, 1.5707963267948966, 0) or p35 == "Right" and CFrame.Angles(0, 3.141592653589793, 0))
				if not v40 then
					if p35 == "Front" then
						v40 = CFrame.Angles(0, -1.5707963267948966, 0)
					else
						v40 = false
					end
				end
				v38:DustTrail(p_u_34, v39, v40)
				if v_u_6 == p33 then
					local v41 = p_u_34.Info:FindFirstChild("DashMultiplier")
					local v42 = v41 and v41.Value or 1
					workspace.CurrentCamera.FieldOfView = 70
					local v43 = v_u_21[p35] * (200 * v42)
					local v_u_44 = v_u_37:LoadAnimation((v_u_8.Misc.Movement:FindFirstChild("Dash" .. p35)))
					v_u_44.Priority = Enum.AnimationPriority.Movement
					v_u_44:Play(nil, nil, p35 == "Back" and 0.8 or 1.8)
					v_u_15 = tick()
					v_u_22:ClearForce(p_u_34.Torso)
					v_u_22:ClearForce(v_u_36)
					local v_u_45 = Instance.new("BodyVelocity", p_u_34.Torso)
					v_u_45.MaxForce = Vector3.new(40000, 0, 40000)
					v_u_45.P = 40000
					v_u_45.Name = "MovementForce"
					v_u_4:AddItem(v_u_45, 0.4)
					v_u_22:Swing(v_u_36, v_u_45, 0.4, v43)
					local v46 = v_u_45:FindFirstChildWhichIsA("NumberValue")
					if v46 then
						v_u_5:Create(v46, TweenInfo.new(0.4, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
							["Value"] = 16 * v42
						}):Play()
					end
					local v_u_47 = nil
					v_u_47 = v_u_3.RenderStepped:Connect(function()
						-- upvalues: (copy) v_u_45, (ref) v_u_47, (copy) v_u_37, (copy) p_u_34, (copy) v_u_36
						if not v_u_45.Parent then
							v_u_47:Disconnect()
						end
						if v_u_37.AutoRotate == false then
							return
						elseif p_u_34.Head.LocalTransparencyModifier == 0 then
							local v48 = workspace.CurrentCamera.CFrame.LookVector
							local v49 = v_u_36
							local v50 = CFrame.new
							local v51 = v_u_36.Position
							local v52 = v_u_36.Position
							local v53 = v48.X
							local v54 = v48.Z
							v49.CFrame = v50(v51, v52 + Vector3.new(v53, 0, v54))
						end
					end)
					local v_u_55 = p_u_34:GetAttributeChangedSignal("Stun"):Connect(function()
						-- upvalues: (copy) p_u_34, (copy) v_u_45, (copy) v_u_44, (ref) v_u_47
						if p_u_34:GetAttribute("Stun") and v_u_45.Parent then
							v_u_45.Velocity = Vector3.new(0, 0, 0)
							v_u_45:Destroy()
							v_u_44:Stop()
							v_u_47:Disconnect()
						end
					end)
					task.delay(0.4, function()
						-- upvalues: (ref) v_u_55, (ref) v_u_47
						v_u_55:Disconnect()
						v_u_47:Disconnect()
					end)
				end
			end
		else
			return
		end
	else
		return
	end
end
local v_u_56 = {
	Vector3.new(0.5, 0.5, 0.5),
	Vector3.new(-0.5, 0.5, 0.5),
	Vector3.new(0.5, 0.5, -0.5),
	Vector3.new(-0.5, 0.5, -0.5),
	Vector3.new(0.5, -0.5, 0.5),
	Vector3.new(-0.5, -0.5, 0.5),
	Vector3.new(0.5, -0.5, -0.5),
	Vector3.new(-0.5, -0.5, -0.5)
}
local v57 = {}
for v58, _ in v_u_56 do
	v57[v58] = v_u_56[v58].Unit
end
local function v_u_61(p59)
	local v60 = p59:FindFirstChild("Handle")
	if v60 then
		v60.Parent = Instance.new("Folder", p59)
	end
end
function v14.Tilt(_, p_u_62)
	-- upvalues: (copy) v_u_6, (copy) v_u_25, (copy) v_u_17, (copy) v_u_61, (copy) v_u_3, (copy) v_u_56, (copy) v_u_10, (ref) v_u_20, (copy) v_u_18, (copy) v_u_9, (copy) v_u_4, (copy) v_u_19, (copy) v_u_12
	local v_u_63 = p_u_62:FindFirstChild("HumanoidRootPart")
	local v_u_64 = p_u_62:FindFirstChild("Humanoid")
	if v_u_63 and v_u_64 then
		if not p_u_62:GetAttribute("NoProcess") then
			if v_u_6.Character == p_u_62 then
				v_u_64:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
				v_u_64:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
				for _, v65 in v_u_25 do
					for _, v66 in v65 do
						v_u_17.AnimationId = "rbxassetid://" .. v66
						v_u_64:LoadAnimation(v_u_17)
					end
				end
				if p_u_62:GetAttribute("Ragdoll") > 0 then
					v_u_64:ChangeState(Enum.HumanoidStateType.Physics)
				end
				p_u_62:GetAttributeChangedSignal("Ragdoll"):Connect(function()
					-- upvalues: (copy) p_u_62, (copy) v_u_64
					if p_u_62:GetAttribute("Ragdoll") > 0 then
						v_u_64:ChangeState(Enum.HumanoidStateType.Physics)
					else
						v_u_64:ChangeState(Enum.HumanoidStateType.GettingUp)
					end
				end)
			end
			for _, v67 in p_u_62:GetChildren() do
				if v67:IsA("Accessory") then
					local v68 = v67:FindFirstChild("Handle")
					if v68 then
						v68.Parent = Instance.new("Folder", v67)
					end
				end
			end
			p_u_62.ChildAdded:Connect(function(p69)
				-- upvalues: (ref) v_u_61
				if p69:IsA("Accessory") then
					task.defer(v_u_61, p69)
				end
			end)
			local v_u_70 = 0
			local v_u_71 = {
				["Left Arm"] = false,
				["Right Arm"] = false,
				["Left Leg"] = false,
				["Right Leg"] = false,
				["Head"] = false
			}
			local v_u_72 = nil
			v_u_72 = v_u_3.Stepped:Connect(function()
				-- upvalues: (copy) v_u_63, (ref) v_u_72, (copy) p_u_62, (copy) v_u_71, (ref) v_u_56, (ref) v_u_70, (ref) v_u_10, (ref) v_u_20
				if not (v_u_63 and v_u_63.parent) then
					v_u_72:Disconnect()
					return
				end
				if p_u_62:GetAttribute("Ragdoll") <= 0 or (workspace.CurrentCamera.CFrame.Position - v_u_63.Position).Magnitude > 300 then
					for v73, _ in v_u_71 do
						v_u_71[v73] = false
					end
					return
				end
				if not _G.Settings.RagSFX then
					return
				end
				for v74, _ in v_u_71 do
					local v75 = p_u_62:FindFirstChild(v74)
					if v75 then
						local v76 = v75.CFrame.LookVector
						local v77 = v75.CFrame.RightVector
						local v78 = v75.CFrame.UpVector
						local v79 = false
						for v80 = 1, 8 do
							local v81 = v76 * v_u_56[v80].Z + v77 * v_u_56[v80].X + v78 * v_u_56[v80].Y
							local v82 = v_u_63.Position + v81 * v75.Size
							if workspace:Raycast(v82, v81.Unit * 0.2, _G.MapParams) then
								v79 = true
								break
							end
						end
						if v79 and v_u_71[v74] == false then
							v_u_71[v74] = true
							if tick() - v_u_70 > 0.075 then
								v_u_70 = tick()
								v_u_20:PlaySound(v_u_10.Impact.Players.Ragdoll_Collision["Hit" .. math.random(1, 8)], v75, game.SoundService.Effect)
							end
						elseif not v79 and v_u_71[v74] == true then
							v_u_71[v74] = false
						end
					end
				end
			end)
			local v_u_83 = v_u_63:FindFirstChild("RootJoint")
			local v_u_84 = v_u_83.C1
			local v_u_85 = nil
			v_u_85 = v_u_3.Stepped:Connect(function(_, p86)
				-- upvalues: (copy) v_u_63, (copy) v_u_83, (ref) v_u_85, (copy) v_u_84
				if v_u_63 and v_u_83 then
					local v87 = v_u_63.CFrame:VectorToObjectSpace(v_u_63.Velocity)
					local v88 = v_u_83
					local v89 = v_u_83.C1
					local v90 = v_u_84
					local v91 = CFrame.Angles
					local v92 = v87.Z
					local v93 = math.clamp(v92, -6, 6)
					local v94 = math.rad(v93)
					local v95 = v87.X
					local v96 = math.clamp(v95, -6, 6)
					local v97 = math.rad(v96)
					local v98 = v87.X
					local v99 = math.clamp(v98, -6, 6)
					local v100 = v90 * v91(v94, v97, (math.rad(v99)))
					local v101 = CFrame.Angles
					local v102 = v_u_63.RotVelocity.Y
					local v103 = math.clamp(v102, -6, 6)
					v88.C1 = v89:lerp(v100 * v101(0, 0, (math.rad(v103))), 6 * p86)
				else
					v_u_85:Disconnect()
				end
			end)
			local v_u_104 = {
				{ false, tick() },
				{ false, tick() }
			}
			local v_u_105 = { p_u_62:FindFirstChild("Left Leg"), p_u_62:FindFirstChild("Right Leg") }
			local v_u_106 = nil
			v_u_106 = v_u_3.Stepped:Connect(function()
				-- upvalues: (copy) p_u_62, (copy) v_u_105, (ref) v_u_106, (copy) v_u_104, (ref) v_u_20, (ref) v_u_18, (copy) v_u_63, (ref) v_u_9, (ref) v_u_4, (ref) v_u_19, (ref) v_u_12
				if p_u_62.Parent and (v_u_105[1] and v_u_105[2]) then
					for v107, v108 in v_u_105 do
						local v109 = v108.Position + v108.CFrame.UpVector * (1 * p_u_62:GetScale())
						local v110 = workspace:Raycast(v109, v108.CFrame.UpVector * -(2 * p_u_62:GetScale() + 0.3), _G.MapParams)
						if v110 and v_u_104[v107][1] == false then
							v_u_104[v107][1] = true
							if tick() - v_u_104[v107][2] >= 0.1 then
								v_u_104[v107][2] = tick()
								local v111 = v110.Material
								if v110.Instance.Name == "Water" then
									v_u_20:PlaySound(v_u_18, v_u_63, game.SoundService.Effect)
									local v112 = v_u_9.Water:Clone()
									v112.CFrame = CFrame.new(v110.Position + v110.Normal * 0.1, v110.Position + v110.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0)
									v112.Ring:Emit(3)
									v112.Splash:Emit(7)
									v112.Parent = workspace.Effects
									v_u_4:AddItem(v112, 4)
								elseif v_u_19[v111] then
									if p_u_62:GetAttribute("Makora") or p_u_62:GetAttribute("UltMecha") then
										v_u_19[v111].Volume = 3
										v_u_19[v111].PlaybackSpeed = v107 == 1 and 0.8 or 0.9
										if (workspace.CurrentCamera.CFrame.Position - v_u_63.Position).Magnitude < 30 then
											v_u_12.CurrentShaker:Shake(v_u_12.Presets.LightHit)
										end
									else
										v_u_19[v111].Volume = 0.5
										v_u_19[v111].PlaybackSpeed = v107 == 1 and 0.9 or 1
									end
									v_u_20:PlaySound(v_u_19[v111], v_u_63, game.SoundService.Effect)
								end
							end
						elseif not v110 and v_u_104[v107][1] == true then
							v_u_104[v107][1] = false
						end
					end
				else
					v_u_106:Disconnect()
				end
			end)
		end
	else
		return
	end
end
local v_u_113 = 2
function v14.DashRequest(p114)
	-- upvalues: (copy) v_u_6, (ref) v_u_29, (ref) v_u_15, (ref) v_u_23, (ref) v_u_26, (ref) v_u_113
	local v115 = v_u_6.Character
	if v115 then
		local v116 = v115.HumanoidRootPart
		local v117 = v115.Humanoid
		if v116 and v117 then
			local v118 = workspace.CurrentCamera.CFrame.LookVector
			local v119 = CFrame.new
			local v120 = v116.Position
			local v121 = v116.Position
			local v122 = v118.X
			local v123 = v118.Z
			local v124 = v119(v120, v121 + Vector3.new(v122, 0, v123))
			local v125 = v117.MoveDirection:Dot(v124.LookVector)
			local v126 = math.round(v125)
			local v127 = v117.MoveDirection:Dot(v124.RightVector)
			local v128 = math.round(v127)
			local v129 = v126 == 1 and "Front" or (v126 == -1 and "Back" or (v128 == 1 and "Right" or (v128 == -1 and "Left" or "Front")))
			if v115.Info:FindFirstChild("Knockback") or v115:GetAttribute("Burst") and not v115.Info:GetAttribute("Burst") or v115.Info:FindFirstChild("ForceEsc") then
				v_u_29.Dash:Fire(v129, true)
				return
			elseif v115.Info:FindFirstChild("Block") then
				return
			elseif v115.Info:FindFirstChild("Stun") then
				return
			elseif v115:GetAttribute("Ragdoll") > 0 then
				return
			elseif v115.Info:FindFirstChild("NoDash") then
				return
			else
				local v130 = v115.Info:FindFirstChild("InSkill")
				if v130 and v130.Value == false then
					return
				elseif v129 == "Front" and v115:GetAttribute("Moveset") ~= "Naoya" then
					if tick() - v_u_15 < 0.4 then
						return
					else
						local v131 = v115.Info:FindFirstChild("Item")
						if v131 and v131:FindFirstChild("Dash") then
							v_u_23.Dash:Fire()
							return
						elseif v115:FindFirstChild("CustomChar") and v115.CustomChar:GetAttribute("CustomChase") then
							v_u_26:GetToolService("CustomService").Chase:Fire(v_u_26.ExtraData.Custom())
						else
							v_u_26:UseSetService("Chase", v117.FloorMaterial == Enum.Material.Air)
						end
					end
				elseif v129 == "Back" and v115:GetAttribute("Moveset") == "Chara" then
					if tick() - v_u_15 < 0.4 then
						return
					elseif not v115.Info:FindFirstChild("BackdashCooldown") then
						v_u_26:UseSetService("Backdash")
					end
				else
					local v132 = v115.Info:FindFirstChild("NoSprint")
					if v132 and v132.Value == false then
						return
					elseif v115:GetAttribute("Moveset") == "Naoya" then
						if tick() - v_u_15 < 0.3 then
							return
						else
							if tick() - v_u_15 > 2 then
								v_u_113 = 2
							end
							if v_u_113 > 0 then
								v_u_113 = v_u_113 - 1
								v_u_29.Dash:Fire(v129)
								p114:Dash(v_u_6, v115, v129)
							end
						end
					elseif tick() - v_u_15 >= 2 then
						v_u_29.Dash:Fire(v129)
						p114:Dash(v_u_6, v115, v129)
					end
				end
			end
		else
			return
		end
	else
		return
	end
end
function v14.Parkour(_, p_u_133, p134, p_u_135)
	-- upvalues: (ref) v_u_24, (ref) v_u_22, (copy) v_u_10, (ref) v_u_20, (ref) v_u_29, (copy) v_u_25, (copy) v_u_17
	if p_u_133.Info:GetAttribute("Parkour") then
		return
	elseif p_u_133.Info:FindFirstChild("NoParkour") then
		return
	else
		local v136 = p134.Position
		local v137 = p_u_135:GetState()
		local v138 = p_u_133:GetScale()
		if v137 ~= Enum.HumanoidStateType.Climbing then
			local v139 = p134.CFrame
			local v140 = CFrame.lookAlong(v139.Position, v139.LookVector * Vector3.new(1, 0, 1))
			local v141 = v140.LookVector * v138
			local v142 = v140.UpVector * v138
			local v143 = v140.RightVector * v138
			if v137 == Enum.HumanoidStateType.Running then
				if workspace:Raycast(v136, v142 * -3, _G.MapParams) then
					v_u_24 = 0
				end
				local v144 = workspace:Raycast(v136, v141 * 3.5, _G.MapParams)
				if v144 then
					local v145 = workspace:Raycast(v136 + v142 * 1.5, v141 * 3.5, _G.MapParams)
					local v146 = workspace:Raycast(v136 - v142 * 2.5, v141 * 3.5, _G.MapParams)
					if v145 or not v146 then
						if workspace:Raycast(v136 + v142 * 1.5, v141 * 6, _G.MapParams) and not workspace:Raycast(v136 - v142 * 2.5, v141 * 6, _G.MapParams) then
							local v147 = v136 - v142 * 2.5 + v141 * 6
							if not workspace:Raycast(v147, v142 * 5, _G.MapParams) then
								v_u_22:ClearForce(p_u_133.Torso)
								p_u_133:SetAttribute("Movement", true)
								p_u_135.HipHeight = -2
								task.delay(0.35, function()
									-- upvalues: (copy) p_u_133, (copy) p_u_135
									p_u_133:SetAttribute("Movement", nil)
									p_u_135.HipHeight = 0
								end)
								v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
								v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, p134, game.SoundService.Effect)
								v_u_29.Parkour:Fire()
								v_u_17.AnimationId = "rbxassetid://" .. v_u_25.Slide[math.random(1, #v_u_25.Slide)]
								local v148 = p_u_135:LoadAnimation(v_u_17)
								v148.Priority = Enum.AnimationPriority.Movement
								v148:Play(0.06)
								v_u_22:MovementForce(p_u_133, v141 * 35 - v142 * 80, v141 * 28, 0.3)
								return
							end
						end
					else
						if workspace:Raycast(v136 + v142 * 4, v141 * 3.5, _G.MapParams) then
							v_u_22:ClearForce(p_u_133.Torso)
							p_u_133:SetAttribute("Movement", true)
							p_u_135.HipHeight = -2
							task.delay(0.4, function()
								-- upvalues: (copy) p_u_133, (copy) p_u_135
								p_u_133:SetAttribute("Movement", nil)
								p_u_135.HipHeight = 0
							end)
							v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
							v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, p134, game.SoundService.Effect)
							v_u_29.Parkour:Fire()
							v_u_17.AnimationId = "rbxassetid://" .. v_u_25.Dive[math.random(1, #v_u_25.Dive)]
							local v149 = p_u_135:LoadAnimation(v_u_17)
							v149.Priority = Enum.AnimationPriority.Movement
							v149:Play(0.1)
							v_u_22:MovementForce(p_u_133, v141 * 35 + Vector3.new(0, 30, 0), v141 * 28, 0.3)
							return
						end
						if v146.Distance - v144.Distance > -2 * v138 then
							v_u_22:ClearForce(p_u_133.Torso)
							p_u_133:SetAttribute("Movement", true)
							task.delay(0.3, function()
								-- upvalues: (copy) p_u_133
								p_u_133:SetAttribute("Movement", nil)
							end)
							v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
							v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, p134, game.SoundService.Effect)
							v_u_29.Parkour:Fire()
							v_u_17.AnimationId = "rbxassetid://" .. v_u_25.Vault[math.random(1, #v_u_25.Vault)]
							local v150 = p_u_135:LoadAnimation(v_u_17)
							v150.Priority = Enum.AnimationPriority.Movement
							v150:Play(0.1)
							v_u_22:MovementForce(p_u_133, v141 * 24 + v142 * 40, v141 * 24, 0.3)
							return
						end
					end
				end
			elseif v137 == Enum.HumanoidStateType.Freefall then
				local v151 = workspace:Raycast(v136, v142 * 4, _G.MapParams)
				if not v151 then
					local v152 = v136 + v142 * 4 + v141 * 3
					local v153 = true
					local v154 = workspace:Raycast(v136 + v142 * 4, v141 * 3, _G.MapParams)
					if v154 then
						v152 = v154.Position
						if v154.Distance < 0.5 then
							v153 = false
						end
					end
					if workspace:Raycast(v152 - v141 * 0.2, v142 * -2, _G.MapParams) and v153 then
						v_u_22:ClearForce(p_u_133.Torso)
						p_u_133:SetAttribute("Movement", true)
						task.delay(0.3, function()
							-- upvalues: (copy) p_u_133
							p_u_133:SetAttribute("Movement", nil)
						end)
						v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
						v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, p134, game.SoundService.Effect)
						v_u_29.Parkour:Fire()
						v_u_17.AnimationId = "rbxassetid://" .. v_u_25.Climb[math.random(1, #v_u_25.Climb)]
						local v155 = p_u_135:LoadAnimation(v_u_17)
						v155.Priority = Enum.AnimationPriority.Movement
						v155:Play(0.1)
						v_u_22:MovementForce(p_u_133, v142 * 40, v142 * 10 + v141 * 12, 0.3)
					end
				end
				local v156 = p_u_135.MoveDirection:Dot(p134.CFrame.RightVector)
				local v157 = math.round(v156)
				local v158 = p_u_133:GetAttribute("Moveset") == "Goku" and 4 or 3
				if v157 ~= 0 and (v_u_24 < v158 and (not p_u_133:GetAttribute("Movement") and (p_u_135.Jump == true and (not v151 and workspace:Raycast(v136, v143 * (v157 * 3), _G.MapParams))))) then
					v_u_22:ClearForce(p_u_133.Torso)
					p_u_133:SetAttribute("Movement", true)
					v_u_24 = v_u_24 + 1
					task.delay(0.4, function()
						-- upvalues: (copy) p_u_133
						p_u_133:SetAttribute("Movement", nil)
					end)
					v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
					v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, p134, game.SoundService.Effect)
					v_u_29.Parkour:Fire()
					local v159 = v157 == 1 and v_u_25.BounceR or v_u_25.BounceL
					v_u_17.AnimationId = "rbxassetid://" .. v159[math.random(1, #v159)]
					local v160 = p_u_135:LoadAnimation(v_u_17)
					v160.Priority = Enum.AnimationPriority.Movement
					v160:Play(0.1)
					v_u_22:MovementForce(p_u_133, p134.Velocity + v143 * (v157 * 50), v142 * 20 - v143 * (v157 * 40) + v141 * 30, 0.4)
				end
			end
		end
	end
end
local _ = {
	["Itadori"] = { Color3.fromRGB(85, 255, 255), Color3.fromRGB(255, 0, 0) },
	["Hakari"] = { Color3.fromRGB(85, 255, 127) },
	["Megumi"] = { Color3.fromRGB(31, 31, 31) },
	["Mahoraga"] = { Color3.fromRGB(255, 255, 127) },
	["Mahito"] = { Color3.fromRGB(170, 85, 255) },
	["Choso"] = { Color3.fromRGB(170, 0, 0) },
	["Locust"] = { Color3.fromRGB(0, 170, 127) },
	["Yuki"] = { Color3.fromRGB(255, 170, 255) },
	["Mechamaru"] = { Color3.fromRGB(225, 10, 75) }
}
function v14.KnitStart(p_u_161)
	-- upvalues: (ref) v_u_29, (copy) v_u_10, (ref) v_u_20, (copy) v_u_9, (copy) v_u_4, (copy) v_u_5, (ref) v_u_15, (copy) v_u_2, (copy) v_u_6, (ref) v_u_27, (copy) v_u_3, (copy) v_u_11, (ref) v_u_26, (ref) v_u_28
	for _, v162 in workspace.Characters:GetChildren() do
		p_u_161:Tilt(v162)
	end
	workspace.Characters.ChildAdded:Connect(function(p_u_163)
		-- upvalues: (copy) p_u_161
		task.defer(function()
			-- upvalues: (ref) p_u_161, (copy) p_u_163
			p_u_161:Tilt(p_u_163)
		end)
	end)
	v_u_29.Effects:Connect(function(p164, p165, p166, p167)
		-- upvalues: (copy) p_u_161, (ref) v_u_10, (ref) v_u_20, (ref) v_u_9, (ref) v_u_4, (ref) v_u_5
		if p165 == "Dash" then
			p_u_161:Dash(p164, p166, p167)
			return
		elseif p165 == "Parkour" then
			local v168 = p166.HumanoidRootPart
			if v168 then
				if p167 then
					v_u_10.Misc.Parkour.Roll.Pitch = math.random(90, 110) / 100
					v_u_20:PlaySound(v_u_10.Misc.Parkour.Roll, v168, game.SoundService.Effect)
				else
					v_u_10.Misc.Parkour.Parkour.Pitch = math.random(90, 110) / 100
					v_u_20:PlaySound(v_u_10.Misc.Parkour.Parkour, v168, game.SoundService.Effect)
				end
			else
				return
			end
		elseif p165 == "Escape" then
			local v169 = p166.HumanoidRootPart
			if v169 then
				if p164 == 1 then
					local v170 = v_u_9.DashCancel:Clone()
					v170.Position = v169.Position
					v170.Parent = workspace.Effects
					v170.Ring:Emit(7)
					v170.Wind:Emit(4)
					v_u_4:AddItem(v170, 0.5)
				else
					v_u_20:PlaySound(v_u_10.Misc.Burst2, v169, game.SoundService.Effect)
					v_u_20:Flash(p166, Color3.new(1, 1, 1), 1)
					local v171 = v_u_9.DashCancel:Clone()
					v171.Position = v169.Position
					v171.Parent = workspace.Effects
					v171.Burst:Emit(8)
					v171.Sparks:Emit(20)
					v171.Ring:Emit(7)
					v171.Wind:Emit(4)
					v_u_4:AddItem(v171, 1)
					local v_u_172 = v_u_9.Damage.Rage:Clone()
					v_u_172.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v_u_172.Parent = p166.Torso
					v_u_4:AddItem(v_u_172, 8)
					v_u_172.Rate = 80
					v_u_5:Create(v_u_172, TweenInfo.new(1), {
						["Rate"] = 0
					}):Play()
					task.delay(1, function()
						-- upvalues: (copy) v_u_172
						v_u_172.Enabled = false
					end)
				end
			else
				return
			end
		elseif p165 == "Grab" then
			local v173 = p166.HumanoidRootPart
			if v173 then
				v_u_20:PlaySound(v_u_10.Misc["Throwable" .. p164], v173, game.SoundService.Effect)
			end
		else
			if p165 == "Hit" then
				local v174 = p166.HumanoidRootPart
				if not v174 then
					return
				end
				local v175 = v_u_9.Gojo.Twofold.Sparks:Clone()
				v175.Parent = v174.RootAttachment
				v175:Emit(20)
				v_u_4:AddItem(v175, 0.4)
				v_u_20:Flash(p166, Color3.new(1, 1, 1))
				v_u_20:PlaySound(v_u_10.Itadori.DivergentFist.DivergentHit, v174, game.SoundService.Effect)
			end
			return
		end
	end)
	v_u_29.Throwable:Connect(function(p176, p177, p178)
		-- upvalues: (ref) v_u_5
		local v179 = p176.PrimaryPart:FindFirstChildWhichIsA("Weld")
		if v179 then
			local v180 = p177:FindFirstChild("Head")
			if v180 then
				local v181 = v179.C1
				v179.C1 = p178:ToObjectSpace(v180.CFrame)
				v_u_5:Create(v179, TweenInfo.new(0.26666666666666666, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
					["C1"] = v181
				}):Play()
			end
		else
			return
		end
	end)
	v_u_29.ResetDash:Connect(function()
		-- upvalues: (ref) v_u_15
		v_u_15 = tick() - 2
	end)
	v_u_2.InputBegan:Connect(function(p182, p183)
		-- upvalues: (ref) v_u_6, (ref) v_u_27, (copy) p_u_161
		if p183 then
			return
		else
			local v184 = v_u_6.Character
			if v184 then
				if v184:IsDescendantOf(workspace.Effects) then
					return
				elseif p182.KeyCode == Enum.KeyCode.W then
					if v184.Info:FindFirstChild("NoSprint") then
						return
					elseif tick() - v_u_27 >= 0.2 then
						v_u_27 = tick()
					else
						v184:SetAttribute("Sprint", true)
					end
				else
					if p182.KeyCode == Enum.KeyCode.Q or p182.KeyCode == Enum.KeyCode.ButtonY then
						p_u_161:DashRequest()
					end
					return
				end
			else
				return
			end
		end
	end)
	v_u_2.InputEnded:Connect(function(p185, _)
		-- upvalues: (ref) v_u_6
		local v186 = v_u_6.Character
		if v186 then
			if not v186:IsDescendantOf(workspace.Effects) then
				if p185.KeyCode == Enum.KeyCode.W then
					v186:SetAttribute("Sprint", nil)
				end
			end
		else
			return
		end
	end)
	local v_u_187 = nil
	local v_u_188 = nil
	local v_u_189 = nil
	local v_u_190 = nil
	v_u_3:BindToRenderStep("Cam", Enum.RenderPriority.Camera.Value + 1, function(p191)
		-- upvalues: (ref) v_u_187, (ref) v_u_188, (ref) v_u_189, (ref) v_u_190, (ref) v_u_11, (ref) v_u_2, (ref) v_u_26, (ref) v_u_6, (copy) p_u_161
		if v_u_187 and (v_u_187.Parent and (v_u_188 and (v_u_189 and v_u_190))) then
			if v_u_187:FindFirstChild("Head") then
				local v192 = workspace.CurrentCamera
				local v193 = (v_u_187.Head.Position - workspace.CurrentCamera.CFrame.Position).Magnitude
				local v194
				if _G.Shift == true and v193 > 2 then
					v_u_11.RotationType = Enum.RotationType.CameraRelative
					v_u_2.MouseBehavior = Enum.MouseBehavior.LockCenter
					v194 = v_u_26.LastInput == "Mobile" and Vector3.new(2, 0.75, 0) or Vector3.new(1.75, 0, 0)
				else
					v194 = Vector3.new(0, 0, 0)
				end
				local v195 = v_u_187:GetScale()
				local v196 = v194 * v195
				local v197 = v_u_6.PlayerGui.Controls.LockTarget
				if p_u_161.LockOn == nil then
					v197.Adornee = nil
					v197.Enabled = false
					v_u_6:SetAttribute("LockOn", nil)
				else
					local v198 = p_u_161.LockOn:FindFirstChild("HumanoidRootPart")
					if v_u_189.Health <= 0 or not v198 then
						p_u_161.LockOn = nil
						_G.Shift = false
						v197.Adornee = nil
						v197.Enabled = false
						v_u_6:SetAttribute("LockOn", nil)
					elseif v192.CameraType ~= Enum.CameraType.Scriptable then
						_G.Shift = true
						local v199 = v198.Position + v_u_188.CFrame.RightVector * 1.75 * v195
						local v200 = CFrame.lookAt(v192.CFrame.Position, v199)
						local v201 = 54 * p191
						local v202 = math.clamp(v201, 0, 1)
						local v203 = v192.CFrame:Lerp(v200, v202)
						v192.CFrame = v203 - v203.Position + v192.CFrame.Position
						v197.Adornee = v198
						v197.Enabled = true
						v_u_6:SetAttribute("LockOn", true)
					end
				end
				if v192.CameraSubject == v_u_189 then
					local v204 = _G.Settings.Follow == true and ((v_u_188.CFrame + v_u_188.CFrame.UpVector * 1.5):PointToObjectSpace(v_u_187.Head.Position) or Vector3.new(0, 0, 0)) or Vector3.new(0, 0, 0)
					if v_u_187:GetAttribute("Dead") then
						v192.CameraSubject = v_u_187.Head
					else
						v_u_189.CameraOffset = v196 + (v_u_189.CameraOffset - v196):Lerp(v204, v_u_187:GetAttribute("Ragdoll") > 0 and 1 or 0.5)
					end
				else
					v_u_189.CameraOffset = v_u_189.CameraOffset:Lerp(Vector3.new(0, 0, 0), 0.5)
					return
				end
			else
				return
			end
		else
			return
		end
	end)
	local v_u_205 = {
		["Stun"] = 0,
		["NoJump"] = 0,
		["Block"] = 0,
		["Emote"] = 0
	}
	local v_u_206 = 0
	local v_u_207 = nil
	local v_u_208 = nil
	local v_u_209 = nil
	local v_u_210 = nil
	local v_u_211 = require(v_u_6.PlayerScripts.PlayerModule)
	v_u_3.Stepped:Connect(function(_, p212)
		-- upvalues: (ref) v_u_187, (ref) v_u_188, (ref) v_u_189, (ref) v_u_190, (ref) v_u_6, (copy) v_u_205, (ref) v_u_209, (ref) v_u_210, (copy) p_u_161, (ref) v_u_206, (ref) v_u_28, (ref) v_u_207, (ref) v_u_9, (ref) v_u_5, (ref) v_u_20, (ref) v_u_10, (ref) v_u_208, (copy) v_u_211
		if v_u_187 and (v_u_187.Parent and (v_u_188 and (v_u_189 and v_u_190))) then
			local v213 = 1 - v_u_189.Health / v_u_189.MaxHealth
			local v214 = math.clamp(v213, 0, 1) * 3
			local v215 = v214 ~= v214 and 0 or v214
			local v216 = (workspace.CurrentCamera.CFrame.LookVector * Vector3.new(1, 0, 1)).Unit:Dot(v_u_189.MoveDirection)
			local v217 = game.StarterPlayer.CharacterWalkSpeed - v215
			local v218 = game.StarterPlayer.CharacterJumpPower
			local v219 = v_u_205.NoJump > 0 and 0 or v218
			local v220 = v_u_190:FindFirstChild("NoSprint")
			if v220 then
				v_u_187:SetAttribute("Sprint", nil)
				if v220:GetAttribute("S") then
					v217 = v220:GetAttribute("S")
				end
			elseif v216 > 0.5 and _G.Settings.AutoRun then
				v_u_187:SetAttribute("Sprint", true)
			elseif v216 < 0.5 then
				v_u_187:SetAttribute("Sprint", nil)
			end
			if v_u_205.Stun > 0 then
				v217 = 0.1
				v219 = 0
			elseif v_u_205.Block > 0 then
				v217 = v216 < 0 and 4 or 6
				v219 = 0
			elseif v_u_187:GetAttribute("Sprint") then
				v217 = game.StarterPlayer.CharacterWalkSpeed * 1.375 - v215
				if not v_u_187:GetAttribute("Movement") then
					p_u_161:Parkour(v_u_187, v_u_188, v_u_189)
				end
			end
			local v221 = v_u_190:FindFirstChild("Emote")
			if v221 then
				for _, v222 in game:GetService("CollectionService"):GetTagged("Emote") do
					v222.Enabled = false
				end
				if v221:GetAttribute("Team") then
					v_u_206 = v_u_206 + p212
					if v_u_206 >= 300 then
						v_u_206 = 0
						v_u_28.Give:Fire("Committed to the peace")
					end
				end
			else
				for _, v223 in game:GetService("CollectionService"):GetTagged("Emote") do
					v223.Enabled = true
				end
				v_u_206 = 0
			end
			if v_u_189:GetAttribute("Speed") then
				v217 = v217 * v_u_189:GetAttribute("Speed")
			end
			if v_u_189:GetAttribute("Speed2") then
				v217 = v217 * v_u_189:GetAttribute("Speed2")
			end
			if v_u_189:GetAttribute("Jump") then
				v219 = v219 * v_u_189:GetAttribute("Jump")
			end
			if v_u_6:GetAttribute("Spectate") == true then
				v217 = 0
				v219 = 0
			end
			local v224 = v_u_187:GetAttribute("Movement") and 0 or v219
			v_u_189.WalkSpeed = v217
			v_u_189.JumpPower = v224
			v_u_188.Anchored = false
			local v225 = v_u_6.PlayerGui.Main.Ultimate.Evade.Fill
			v225.Size = UDim2.new(v_u_187:GetAttribute("Evade") / 50, 0, 1, 0)
			if v_u_187:GetAttribute("Dead") then
				v225.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
				v225.Gradient.Enabled = true
				if v_u_207 then
					v_u_207:Destroy()
					v_u_207 = nil
				end
				if v_u_208 then
					v_u_208:Destroy()
					v_u_208 = nil
				end
			else
				if v_u_187:GetAttribute("Burst") then
					v225.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
					v225.Gradient.Enabled = false
				else
					v225.BackgroundColor3 = Color3.fromRGB(0, 85, 127)
					v225.Gradient.Enabled = true
				end
				if v_u_187:GetAttribute("Burst") and (v_u_187:GetAttribute("Stun") or v_u_187:GetAttribute("Ragdoll") > 0) then
					if not (v_u_207 and v_u_207.Parent) then
						v_u_207 = v_u_9.Damage.BurstIcon.BurstIcon:Clone()
						v_u_207.Parent = v_u_188
						v_u_207.Glow:Emit(1)
						v_u_5:Create(v_u_207.Icon.Glow, TweenInfo.new(0.1), {
							["ImageTransparency"] = 0
						}):Play()
						v_u_20:PlaySound(v_u_10.Misc.Evade, v_u_188, game.SoundService.Effect)
					end
					if not (v_u_208 and v_u_208.Parent) then
						v_u_208 = Instance.new("Highlight", v_u_187)
						v_u_208.FillColor = Color3.fromRGB(255, 255, 255)
						v_u_208.FillTransparency = 0.95
					end
				else
					if v_u_207 then
						v_u_207:Destroy()
						v_u_207 = nil
					end
					if v_u_208 then
						v_u_208:Destroy()
						v_u_208 = nil
					end
				end
				if v_u_187:GetAttribute("Ragdoll") > 0 then
					local v226 = v_u_188.Velocity.X
					local v227 = v_u_188.Velocity.Z
					local v228 = Vector3.new(v226, 0, v227).Unit:Dot(v_u_189.MoveDirection)
					local v229 = v228 <= 0 and 1 or -(v228 - 1)
					local v230 = v_u_188.Velocity.Magnitude * 1.3 * v229
					local v231 = v_u_188
					v231.Velocity = v231.Velocity + v_u_189.MoveDirection * v230 * p212
					local v232 = v_u_211:GetControls():GetMoveVector()
					if v232.X ~= 0 then
						local v233 = v_u_188
						v233.RotVelocity = v233.RotVelocity + workspace.CurrentCamera.CFrame.LookVector * (v232.X * 60 * p212)
					end
					if v232.Z ~= 0 then
						local v234 = v_u_188
						v234.RotVelocity = v234.RotVelocity + workspace.CurrentCamera.CFrame.RightVector * (v232.Z * 60 * p212)
						return
					end
				end
			end
			return
		else
			v_u_187 = v_u_6.Character
			if v_u_187 then
				v_u_188 = v_u_187:FindFirstChild("HumanoidRootPart")
				v_u_189 = v_u_187:FindFirstChild("Humanoid")
				v_u_190 = v_u_187:FindFirstChild("Info")
				if v_u_188 and (v_u_189 and v_u_190) then
					for v235, _ in v_u_205 do
						v_u_205[v235] = 0
					end
					for _, v236 in v_u_190:GetChildren() do
						if v_u_205[v236.Name] then
							local v237 = v_u_205
							local v238 = v236.Name
							local v239 = v_u_205[v236.Name] + 1
							v237[v238] = math.clamp(v239, 0, (1 / 0))
						end
					end
					if v_u_209 then
						v_u_209:Disconnect()
						v_u_209 = nil
					end
					v_u_209 = v_u_190.ChildAdded:Connect(function(p240)
						-- upvalues: (ref) v_u_205
						if v_u_205[p240.Name] then
							local v241 = v_u_205
							local v242 = p240.Name
							local v243 = v_u_205[p240.Name] + 1
							v241[v242] = math.clamp(v243, 0, (1 / 0))
						end
					end)
					if v_u_210 then
						v_u_210:Disconnect()
						v_u_210 = nil
					end
					v_u_210 = v_u_190.ChildRemoved:Connect(function(p244)
						-- upvalues: (ref) v_u_205
						if v_u_205[p244.Name] then
							local v245 = v_u_205
							local v246 = p244.Name
							local v247 = v_u_205[p244.Name] - 1
							v245[v246] = math.clamp(v247, 0, (1 / 0))
						end
					end)
				end
			else
				return
			end
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_29, (copy) v_u_1, (ref) v_u_23, (ref) v_u_28, (ref) v_u_26, (ref) v_u_22, (ref) v_u_20
	v_u_29 = v_u_1.GetService("MovementService")
	v_u_23 = v_u_1.GetService("ItemService")
	v_u_28 = v_u_1.GetService("AchievementService")
	v_u_26 = v_u_1.GetController("ToolController")
	v_u_22 = v_u_1.GetController("HandicapController")
	v_u_20 = v_u_1.GetController("FXController")
end
return v14