-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "LuckyRushdownController"
})
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (copy) v_u_2, (copy) v_u_7, (ref) v_u_13, (ref) v_u_10
	local v_u_39 = {
		["Dash"] = function(p15, p16, p17)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9, (ref) v_u_4, (ref) v_u_2
			local v18 = p15:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_12:PlaySound(v_u_8.Itadori.Rush.Rush, v18, game.SoundService.Effect)
				local v19 = v_u_6.Utils.Itadori.RushWind:Clone()
				v19.CFrame = v18.CFrame
				v19.Parent = workspace.Effects
				v19.Dust:Emit(7)
				v19.Ring:Emit(7)
				v19.Dash1.Dash:Emit(1)
				v19.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v19, 2)
				if v_u_5.Character == p15 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v20 = Instance.new("NumberValue", p16)
					v20.Value = 200 * p17
					v_u_4:Create(v20, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["Value"] = 50 * p17
					}):Play()
					repeat
						p16.Velocity = v18.CFrame.LookVector * v20.Value
						v_u_2.Stepped:Wait()
					until not (p16.Parent and v18.Parent)
				end
			end
		end,
		["Grab"] = function(p21)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v22 = p21:FindFirstChild("HumanoidRootPart")
			if v22 then
				v_u_12:Flash(p21, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Gojo.LapseBlue.Grab, v22, game.SoundService.Effect)
			end
		end,
		["Throw"] = function(p23)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				local v25 = v24.CFrame * CFrame.new(2, 0, 0) * CFrame.Angles(0.3490658503988659, 0, 0)
				local v26 = v_u_7.Gojo.HardHit:Clone()
				v26.CFrame = v25 + v25.LookVector * 3.5
				v26.Parent = workspace.Effects
				v26.Dust:Emit(5)
				v26.Ring:Emit(5)
				v26.Sparks:Emit(10)
				v_u_3:AddItem(v26, 0.5)
				v_u_12:PlaySound(v_u_8.Itadori.CursedStrikes.Startup, v24, game.SoundService.Effect)
				if v_u_5.Character == p23 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Jump"] = function(p27, p28)
			-- upvalues: (ref) v_u_5, (ref) v_u_4, (ref) v_u_13
			local v29 = p28.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if not v29 then
				return
			end
			local v30 = v29.CFrame.LookVector * 5
			if v_u_5.Character == v29.Parent then
				v_u_4:Create(p28, TweenInfo.new(0.5), {
					["P"] = 100000
				}):Play()
				repeat
					p28.Position = p27.Position - v30
					task.wait()
				until not (p28.Parent and p27)
				::l6::
				v_u_4:Create(p28, TweenInfo.new(0.5), {
					["P"] = 100000
				}):Play()
				repeat
					p28.Position = p27.Position - v30
					task.wait()
				until not (p28.Parent and p27)
				return
			else
				while true do
					if v_u_13.lastRecvServer[v29.Parent] ~= nil then
						v_u_13.lastRecvServer[v29.Parent] = false
					end
					local v31 = v29.CFrame - v29.Position + p27.Position - v30
					v29.CFrame = v29.CFrame:Lerp(v31, 0.15)
					task.wait()
					if not (p28.Parent and p27) then
						goto l6
					end
				end
			end
		end,
		["JumpBurst"] = function(p32)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v33 = v_u_7.Itadori.CrushingBlow:Clone()
			v33.Position = p32
			v33.PointLight:Destroy()
			v33.Air:Destroy()
			v33.Parent = workspace.Effects
			v33.Floor.Wind2.Color = ColorSequence.new(Color3.new(0, 1, 0))
			v33.Floor.Sparks.Color = ColorSequence.new(Color3.new(0, 1, 0))
			v33.Floor.Ring:Emit(10)
			v33.Floor.Sparks:Emit(10)
			v33.Floor.Wind2:Emit(8)
			v_u_3:AddItem(v33, 1.5)
			v_u_12:PlaySound(v_u_8.Itadori.CrushingBlow.GroundImpact, v33, game.SoundService.Effect)
		end,
		["Hit"] = function(p34, p35, p36)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v37 = p35:FindFirstChild("HumanoidRootPart")
			if v37 then
				v_u_12:Flash(p35, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Hit1, v37, game.SoundService.Effect)
				local v38 = v_u_7.Hakari.RoughHit:Clone()
				v38.Position = v37.Position
				v38.Parent = workspace.Effects
				v_u_3:AddItem(v38, 1)
				v_u_4:Create(v38.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v38.Glow:Emit(1)
				v38.Sparks:Emit(50)
				v38.Wind:Emit(7)
				v38.Wind2:Emit(7)
				if v_u_5 == p34 or v_u_5.Character == p35 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				if p36 then
					v_u_12:PlaySound(v_u_8.Itadori.Rush.RushBreak, v37, game.SoundService.Effect)
					v_u_12:Bleed(p35)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p40, ...)
		-- upvalues: (copy) v_u_39
		local v41 = v_u_39[p40]
		if v41 then
			v41(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
	v_u_10 = v_u_1.GetService("LuckyRushdownService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetController("JoinController")
end
return v14