-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "FurnaceArrowController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10
	local v_u_65 = {
		["HotHands"] = function(p13, p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:PlaySound(v_u_8.Heian.FireArrow.Hands, v15, game.SoundService.Effect)
				local v16 = v_u_7.Heian.FlameArrow.Hands:Clone()
				v16.LA.Weld.Part1 = p13["Left Arm"]
				v16.RA.Weld.Part1 = p13["Right Arm"]
				v16.Parent = p14
			end
		end,
		["Clap"] = function(p17, p18)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = p18:FindFirstChild("Hands")
				if v20 then
					for _, v21 in v20.LA.startup:GetChildren() do
						v21.Enabled = false
					end
					for _, v22 in v20.RA.startup:GetChildren() do
						v22.Enabled = false
					end
					for _, v23 in v20.LA.fire:GetChildren() do
						v23.Enabled = true
					end
					for _, v24 in v20.RA.fire:GetChildren() do
						v24.Enabled = true
					end
					for _, v25 in v20.LA.Beam:GetChildren() do
						v25.Enabled = true
					end
					v_u_4:Create(v_u_11:PlaySound(v_u_8.Heian.FireArrow.FlameIdle, v20.RA, game.SoundService.Effect), TweenInfo.new(3), {
						["Volume"] = 1
					}):Play()
				end
				local v26 = v_u_7.Heian.FlameArrow.Clap:Clone()
				v26.CFrame = v19.CFrame
				v_u_3:AddItem(v26, 2)
				v26.Parent = p18
				for _, v27 in v26.C1:GetChildren() do
					v27:Emit(v27:GetAttribute("EmitCount"))
				end
				if v_u_5.Character == p17 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				v_u_11:PlaySound(v_u_8.Heian.FireArrow.Clap, v19, game.SoundService.Effect)
			end
		end,
		["Clap2"] = function(p28, p29)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9, (ref) v_u_11, (ref) v_u_8
			local v30 = p28:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v31 = v_u_7.Heian.FlameArrow.Clap:Clone()
				v31.CFrame = v30.CFrame
				v_u_3:AddItem(v31, 2)
				v31.Parent = p29
				for _, v32 in v31.C2:GetChildren() do
					v32:Emit(v32:GetAttribute("EmitCount"))
				end
				if v_u_5.Character == p28 then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(2)
				end
				v_u_11:PlaySound(v_u_8.Heian.FireArrow.Clap, v30, game.SoundService.Effect)
				task.wait(0.2)
				if p28:GetAttribute("Moveset") == "Heian" then
					v_u_11:PlaySound(v_u_8.Heian.FireArrow.Voice, v30, game.SoundService.Voice)
				end
			else
				return
			end
		end,
		["Arrow"] = function(p33, p34)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_11, (ref) v_u_8
			local v35 = p33:FindFirstChild("HumanoidRootPart")
			if v35 then
				local v36 = p34:FindFirstChild("Hands")
				if v36 then
					for _, v37 in v36.LA.fire:GetChildren() do
						v37.Enabled = false
					end
					for _, v38 in v36.RA.fire:GetChildren() do
						v38.Enabled = false
					end
					for _, v39 in v36.LA.Beam:GetChildren() do
						v39.Enabled = false
					end
				end
				local v40 = v_u_7.Heian.FlameArrow.Arrow:Clone()
				v40.Weld.Part1 = v35
				v40.Parent = p34
				local v41 = TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
				for _, v42 in v40.Beam:GetChildren() do
					v_u_4:Create(v42, v41, {
						["Brightness"] = 50
					}):Play()
				end
				v_u_4:Create(v40.light.SpotLight, TweenInfo.new(0.4), {
					["Brightness"] = 2
				}):Play()
				v_u_4:Create(v40.Ground.PointLight, TweenInfo.new(1), {
					["Brightness"] = 2
				}):Play()
				v_u_11:PlaySound(v_u_8.Heian.FireArrow.Arrow, v35, game.SoundService.Effect)
				if p33:GetAttribute("Moveset") == "Heian" then
					v_u_11:PlaySound(v_u_8.Heian.FireArrow.FugaVoice, v35, game.SoundService.Voice)
				end
			else
				return
			end
		end,
		["Fire"] = function(p43, p44)
			-- upvalues: (ref) v_u_3, (ref) v_u_7, (ref) v_u_5, (ref) v_u_9, (ref) v_u_11, (ref) v_u_8
			local v45 = p43:FindFirstChild("HumanoidRootPart")
			if v45 then
				local v46 = p44:FindFirstChild("Hands")
				if v46 then
					v46:Destroy()
				end
				local v47 = p44:FindFirstChild("Arrow")
				if v47 then
					for _, v48 in v47:GetDescendants() do
						if v48:IsA("Beam") or (v48:IsA("ParticleEmitter") or (v48:IsA("SpotLight") or v48:IsA("PointLight"))) then
							v48.Enabled = false
						end
					end
					local v49 = v47.Ground
					v49.Parent = v45
					v_u_3:AddItem(v49, 2)
				end
				local v50 = v_u_7.Heian.FlameArrow.Shot:Clone()
				v50.CFrame = v45.CFrame
				v_u_3:AddItem(v50, 2)
				v50.Parent = workspace.Effects
				for _, v51 in v50.Attachment:GetChildren() do
					v51:Emit(v51:GetAttribute("EmitCount"))
				end
				if v_u_5.Character == p43 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				v_u_11:PlaySound(v_u_8.Heian.FireArrow.Fire, v45, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p_u_52)
			-- upvalues: (ref) v_u_2
			local v_u_53 = p_u_52.CFrame
			local v_u_54 = tick()
			local v_u_55 = p_u_52:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_53, (copy) p_u_52, (ref) v_u_54
				v_u_53 = p_u_52.CFrame
				v_u_54 = tick()
			end)
			local v_u_56 = nil
			v_u_56 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_52, (ref) v_u_56, (copy) v_u_55, (ref) v_u_53, (ref) v_u_54
				if p_u_52.Parent then
					workspace:BulkMoveTo({ p_u_52 }, { v_u_53 + v_u_53.LookVector * (192 * (tick() - v_u_54)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_56:Disconnect()
					v_u_55:Disconnect()
				end
			end)
		end,
		["Burn"] = function(p57)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9
			local v58 = v_u_7.Heian.FlameArrow.explode:Clone()
			v58.Startup.Position = p57
			v58.boom.Position = p57
			v58.Parent = workspace.Effects
			v_u_3:AddItem(v58, 4)
			for _, v_u_59 in v58.Startup:GetDescendants() do
				if v_u_59:IsA("ParticleEmitter") then
					v_u_59:Emit(v_u_59:GetAttribute("EmitCount"))
					v_u_59.Enabled = true
					task.delay(v_u_59:GetAttribute("EmitDuration"), function()
						-- upvalues: (copy) v_u_59
						v_u_59.Enabled = false
					end)
				end
			end
			v_u_11:PlaySound(v_u_8.Heian.FireArrow.Shockwave, v58.Startup, game.SoundService.Effect)
			task.wait(0.4)
			for _, v_u_60 in v58.boom.Attachment:GetDescendants() do
				if v_u_60:IsA("ParticleEmitter") then
					v_u_60.Enabled = true
					task.delay(0.5, function()
						-- upvalues: (copy) v_u_60
						v_u_60.Enabled = false
					end)
				end
			end
			local v61 = v_u_7.Megumi.Mahoraga.WorldSlash.mesh:Clone()
			v61.Position = p57
			v61.Decal.Transparency = 0
			v61.Mesh.Scale = Vector3.new(2, 50, 2)
			v61.Parent = v58
			v_u_4:Create(v61, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Size"] = Vector3.new(80, 40, 80),
				["CFrame"] = v61.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
			}):Play()
			v_u_4:Create(v61.Mesh, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(60, 10, 60)
			}):Play()
			v_u_4:Create(v61.Decal, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v_u_3:AddItem(v61, 1)
			local v62 = v_u_7.Itadori.FireArrow.Burn:Clone()
			v62.Parent = v58
			v62.Position = p57
			v62.Center.Wind2:Emit(25)
			v62.Flames:Emit(200)
			v_u_4:Create(v62, TweenInfo.new(0.75), {
				["Size"] = Vector3.new(0, 250, 0),
				["CFrame"] = v62.CFrame * CFrame.Angles(0, 3.141592653589793, 0)
			}):Play()
			v_u_4:Create(v62.Beam, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.In), {
				["Width0"] = 0,
				["Width1"] = 0
			}):Play()
			v_u_4:Create(v62.Lines, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.In), {
				["Width0"] = 0,
				["Width1"] = 0
			}):Play()
			v_u_11:PlaySound(v_u_8.Heian.FireArrow.Explode, v62, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p57).Magnitude < 300 then
				v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1)
			end
		end,
		["Finisher"] = function(p63)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			if p63.HumanoidRootPart then
				v_u_11:Burn(p63)
				for _, v64 in p63:GetChildren() do
					if v64:IsA("BasePart") then
						v_u_7.Damage.Flames:Clone().Parent = v64
					end
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p66, ...)
		-- upvalues: (copy) v_u_65
		local v67 = v_u_65[p66]
		if v67 then
			v67(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("FurnaceArrowService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12