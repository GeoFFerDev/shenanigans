-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = v5.Animations
local v_u_7 = v5.Utils
local v_u_8 = v5.Sounds
local v_u_9 = require(v5.Modules.CameraShaker)
local v_u_10 = require(v5.Modules.LightningBeams)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "BrothersController"
})
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_8, (copy) v_u_9, (copy) v_u_2, (copy) v_u_3, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4, (copy) v_u_10, (ref) v_u_11
	local v_u_42 = {
		["Clap"] = function(p15)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_9
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_13:PlaySound(v_u_8.Todo.Clap, v16, game.SoundService.Effect)
				if (v16.Position - workspace.CurrentCamera.CFrame.Position).Magnitude < 130 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Swap"] = function(p_u_17, p_u_18)
			-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (ref) v_u_4
			local v_u_19 = p_u_17:FindFirstChild("HumanoidRootPart")
			if v_u_19 then
				local v_u_20 = {}
				for _, v21 in p_u_17:GetDescendants() do
					if (v21:IsA("BasePart") or v21:IsA("Decal")) and v21.Transparency ~= 1 then
						local v22 = v21.Transparency
						v21.Transparency = 1
						v_u_20[v21] = v22
					end
				end
				local v23 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
				v23.Position = v_u_19.Position
				v23.Parent = workspace.Effects
				v_u_2:AddItem(v23, 1.5)
				v23.Attachment.Sparks:Emit(20)
				v_u_3:Create(v23, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(0, 0, 0),
					["Transparency"] = 1
				}):Play()
				v_u_13:PlaySound(v_u_8.Itadori.ManjiKick.Startup, v23, game.SoundService.Effect)
				local v_u_24 = nil
				pcall(function()
					-- upvalues: (ref) v_u_24, (ref) v_u_7, (copy) v_u_19, (ref) v_u_6
					v_u_24 = v_u_7.Todo.Yuji:Clone()
					for _, v25 in v_u_24:GetDescendants() do
						if v25:IsA("BasePart") then
							v25.CollisionGroup = "Effects"
						end
					end
					v_u_24.HumanoidRootPart.CFrame = v_u_19.CFrame
					v_u_24.Parent = workspace.Effects
					local v26 = v_u_24.Humanoid:LoadAnimation(v_u_6.Todo.Brothers)
					v26:Play(0)
					v26.TimePosition = 2.4
				end)
				task.spawn(function()
					-- upvalues: (ref) v_u_24, (copy) v_u_19, (copy) p_u_17, (copy) p_u_18, (copy) v_u_20, (ref) v_u_2, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8
					while true do
						if v_u_24 and v_u_24:FindFirstChild("HumanoidRootPart") then
							v_u_24.HumanoidRootPart.CFrame = v_u_19.CFrame
						end
						task.wait()
						if not p_u_17.Parent or (not v_u_19.Parent or (not p_u_18 or (not p_u_18.Parent or p_u_18.Value == true))) then
							if v_u_24 then
								v_u_24:Destroy()
							end
							for v27, v28 in v_u_20 do
								if v27.Parent then
									v27.Transparency = v28
								end
							end
							local v29 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
							v29.Position = v_u_19.Position
							v29.Parent = workspace.Effects
							v_u_2:AddItem(v29, 1.5)
							v29.Attachment.Sparks:Emit(20)
							v_u_3:Create(v29, TweenInfo.new(0.3), {
								["Size"] = Vector3.new(0, 0, 0),
								["Transparency"] = 1
							}):Play()
							v_u_13:PlaySound(v_u_8.Itadori.ManjiKick.Startup, v29, game.SoundService.Effect)
							return
						end
					end
				end)
				if v_u_4.Character == p_u_17 then
					local v_u_30 = workspace.Effects:FindFirstChild("FollowTakada")
					if v_u_30 and v_u_4.Character == p_u_17 then
						v_u_30:ScaleTo(0.01)
						task.delay(1.34, function()
							-- upvalues: (copy) v_u_30
							v_u_30:ScaleTo(1)
						end)
					end
				end
			end
		end,
		["BlackFlash"] = function(p31, p32)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_10, (ref) v_u_4, (ref) v_u_9
			local v33 = p31:FindFirstChild("HumanoidRootPart")
			if v33 then
				local v34 = p32:FindFirstChild("HumanoidRootPart")
				if v34 then
					for _, v35 in p32:GetChildren() do
						if v35:IsA("BasePart") then
							local v36 = v_u_7.Itadori.DivergentFist.FlashBurn:Clone()
							v36.Parent = v35
							v_u_2:AddItem(v36, 1)
						end
					end
					local v37 = v_u_7.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					v37.CFrame = v33.CFrame * CFrame.new(2, 1, -5)
					v37.Parent = workspace.Effects
					v37.Wind:Emit(20)
					v37.Sparks:Emit(20)
					v37.Flare:Emit(20)
					v37.Lightning:Emit(25)
					v37.Back1.Back:Emit(1)
					v37.Back2.Back:Emit(1)
					v_u_3:Create(v37.Back1, TweenInfo.new(2), {
						["CFrame"] = v37.Back1.CFrame - v37.Back1.CFrame.LookVector * 20
					}):Play()
					v_u_3:Create(v37.Back2, TweenInfo.new(2), {
						["CFrame"] = v37.Back2.CFrame - v37.Back2.CFrame.LookVector * 20
					}):Play()
					v_u_3:Create(v37.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					v_u_2:AddItem(v37, 3)
					v_u_13:PlaySound(v_u_8.Itadori.DivergentFist.BlackFlashHit, v34, game.SoundService.Effect)
					v_u_13:PlaySound(v_u_8.Itadori.DivergentFist.Voice, v33, game.SoundService.Effect)
					local v38 = Instance.new("Model", workspace.Effects.Bolt)
					local v39 = Instance.new("Highlight", v38)
					v39.DepthMode = Enum.HighlightDepthMode.Occluded
					v39.OutlineColor = Color3.new(1, 0, 0)
					v39.FillColor = Color3.new(0, 0, 0)
					v39.FillTransparency = 0
					v_u_2:AddItem(v38, 1.2)
					local v_u_40 = v_u_10.new(v37.Core, v34.RootAttachment, nil, v38)
					v_u_40.Color = Color3.new(1, 0, 0)
					v_u_40.PulseSpeed = 1000
					v_u_40.FadeLength = 0.35
					v_u_40.MaxRadius = 20
					v_u_40.MinRadius = 0
					v_u_40.AnimationSpeed = 300
					v_u_40.MinThicknessMultiplier = 0.5
					v_u_40.MaxThicknessMultiplier = 10
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_40
						v_u_40.MaxThicknessMultiplier = 5
						task.wait(0.1)
						v_u_40.MaxThicknessMultiplier = 3
						task.wait(0.1)
						v_u_40.MaxThicknessMultiplier = 2
						task.wait(0.1)
						v_u_40.MaxThicknessMultiplier = 1
						task.wait(0.4)
						v_u_40:Destroy()
					end)
					if v_u_4.Character == p31 or v_u_4.Character == p32 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
						local v41 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v41.Parent = game.Lighting
						task.wait(0.04)
						v41.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v41.Brightness = 200
						v41.Contrast = -1000
						task.wait(0.04)
						v41:Destroy()
					end
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p43, ...)
		-- upvalues: (copy) v_u_42
		local v44 = v_u_42[p43]
		if v44 then
			v44(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("BrothersService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14