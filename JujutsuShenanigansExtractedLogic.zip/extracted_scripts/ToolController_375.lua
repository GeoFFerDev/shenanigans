-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game.Players.LocalPlayer
local v7 = game.ReplicatedStorage
local v_u_8 = UserSettings().GameSettings
local v_u_9 = require(v7.Modules.Icon)
local v_u_10 = v7.Animations
local _ = v7.Utils
local _ = v7.Sounds
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = {}
local v_u_18 = v_u_1.CreateController({
	["Name"] = "ToolController"
})
local v_u_19 = require(v7.Modules.UltNames)
local v_u_20 = {
	"LB",
	"LT",
	"RT",
	"RB",
	"NIL",
	"NIL",
	"NIL",
	"NIL",
	"NIL"
}
local v_u_21 = {
	"L1",
	"L2",
	"R2",
	"R1",
	"NIL",
	"NIL",
	"NIL",
	"NIL",
	"NIL"
}
v_u_18.ShowReady = false
local v_u_22 = {
	[Enum.KeyCode.One] = 1,
	[Enum.KeyCode.Two] = 2,
	[Enum.KeyCode.Three] = 3,
	[Enum.KeyCode.Four] = 4,
	[Enum.KeyCode.Five] = 5,
	[Enum.KeyCode.Six] = 6,
	[Enum.KeyCode.Seven] = 7,
	[Enum.KeyCode.Eight] = 8,
	[Enum.KeyCode.Nine] = 9,
	[Enum.KeyCode.ButtonL1] = 1,
	[Enum.KeyCode.ButtonL2] = 2,
	[Enum.KeyCode.ButtonR2] = 3,
	[Enum.KeyCode.ButtonR1] = 4
}
local v_u_23 = {
	["Cursed Strikes"] = 1,
	["Crushing Blow"] = 1,
	["Dismantle"] = 1,
	["Lapse Blue"] = 2,
	["Reversal Red MAX"] = 1,
	["Lapse Blue MAX"] = 1,
	["Hollow Purple"] = 1,
	["Shutter Doors"] = 2,
	["Rough Energy"] = 1,
	["Rabbit Escape"] = 2,
	["Nue"] = 2,
	["Toad"] = 2,
	["Divine Dog: Totality"] = 2,
	["Mahoraga"] = 2,
	["Takedown"] = 2,
	["Stockpile"] = 1,
	["Body Disfigure"] = 2,
	["Face Blitz"] = 2,
	["Crushing Rushdown"] = 2,
	["Flowing Red Scale"] = 1,
	["Slicing Exorcism"] = 1,
	["Kamehameha"] = 1,
	["Ki Spam"] = 1,
	["Staff Extend"] = 1,
	["Grapple"] = 2,
	["Execution"] = 1,
	["Garuda Rebound"] = 2,
	["Mass Breaker"] = 1,
	["Shut Up!"] = 1,
	["Severing Path"] = 1,
	["Veilstep"] = 1,
	["Revolve"] = 1,
	["Resolute Slash"] = 2,
	["Copy"] = 5,
	["Authentic Mutual Love"] = 2,
	["Ultra Cannon"] = 1,
	["Puppet Barrage"] = 2,
	["Pigeon Viola"] = 2,
	["Technique Charge"] = 2,
	["Decisive Strike"] = 2,
	["Tendril Grab"] = 2,
	["Severance Kick"] = 4,
	["Blunt Cut"] = 1,
	["Collapse"] = 1,
	["Sharpen"] = 1,
	["Ambush"] = 1,
	["Onslaught"] = 1
}
local v_u_25 = {
	["Custom"] = function()
		-- upvalues: (copy) v_u_6, (copy) v_u_18
		local v24 = v_u_6.Character
		return {
			v24.Humanoid.FloorMaterial == Enum.Material.Air,
			v_u_18:GetTarget(),
			require(v_u_6.PlayerScripts.PlayerModule.ControlModule):GetMoveVector(),
			v24.Humanoid.Jump == true
		}
	end
}
v_u_18.ExtraData = v_u_25
function v_u_18.GetPlatform(_, p26)
	-- upvalues: (copy) v_u_2
	if p26 == Enum.UserInputType.Touch then
		return "Mobile"
	end
	local v27 = p26.Name
	if string.sub(v27, 1, 7) == "Gamepad" then
		return v_u_2:GetStringForKeyCode(Enum.KeyCode.ButtonB) == "ButtonCircle" and "Playstation" or "Xbox"
	end
	if p26 ~= Enum.UserInputType.Keyboard then
		local v28 = p26.Name
		if string.sub(v28, 1, 5) ~= "Mouse" then
			return
		end
	end
	return "Keyboard"
end
local v_u_29 = Instance.new("ObjectValue")
v_u_18.Selected = v_u_29
local v_u_30 = v_u_6:GetMouse()
local v_u_31 = {
	"Keyboard",
	"Playstation",
	"Xbox",
	"Mobile"
}
local v_u_32 = game:GetService("CollectionService")
v_u_6:GetMouse().TargetFilter = workspace.Effects
local function v_u_39()
	-- upvalues: (copy) v_u_31, (copy) v_u_18, (copy) v_u_32
	local v33 = table.clone(v_u_31)
	table.remove(v33, table.find(v33, v_u_18.LastInput))
	local v34 = v_u_18.LastInput
	table.insert(v33, v34)
	for _, v35 in v33 do
		local v36 = v_u_32:GetTagged(v35)
		local v37 = v35 == v_u_18.LastInput
		for _, v38 in v36 do
			v38.Visible = v37
		end
	end
end
function v_u_18.GetMouseTarget(p40, p41, p42)
	-- upvalues: (copy) v_u_6, (copy) v_u_30
	local v43 = workspace.CurrentCamera
	local v44 = p41 == nil and 300 or p41
	if p40.LastInput == "Mobile" or p42 then
		local v45 = RaycastParams.new()
		v45.FilterType = Enum.RaycastFilterType.Exclude
		v45.FilterDescendantsInstances = { p42 and workspace.Characters or v_u_6.Character, workspace.Effects, workspace.Logic }
		local v46 = v43.CFrame.LookVector * v44
		local v47 = workspace:Raycast((v43.CFrame + v43.CFrame.UpVector * 1).Position, v46, v45)
		if v47 then
			return v47.Position
		else
			return v43.CFrame.Position + v46
		end
	else
		local v48 = RaycastParams.new()
		v48.FilterType = Enum.RaycastFilterType.Exclude
		v48.FilterDescendantsInstances = { p42 and workspace.Characters or v_u_6.Character, workspace.Effects, workspace.Logic }
		local v49 = CFrame.lookAt(v43.CFrame.Position, v_u_30.Hit.Position).LookVector * v44
		local v50 = workspace:Raycast(v43.CFrame.Position, v49, v48)
		if v50 then
			return v50.Position
		else
			return v43.CFrame.Position + v49
		end
	end
end
function v_u_18.GetTarget(p51)
	-- upvalues: (copy) v_u_6, (copy) v_u_30
	local v52 = v_u_6.Character
	if v52 then
		local v53 = nil
		local v54 = workspace.CurrentCamera
		local v55 = v54.ViewportSize.Y / 5
		local v56
		if p51.LastInput == "Mobile" then
			v56 = v_u_6.PlayerGui.Controls.Crosshair.AbsolutePosition
		else
			v56 = Vector2.new(v_u_30.X, v_u_30.Y)
		end
		local v57 = v52:GetAttribute("Moveset") == "Chaos" and 1000 or (v52:GetAttribute("Moveset") == "Haruta" and 350 or (v52:GetAttribute("Moveset") == "Mechamaru" and 300 or (v52:GetAttribute("Moveset") == "Chara" and 60 or 100)))
		local v58 = next
		local v59, v60 = workspace.Characters:GetChildren()
		for _, v61 in v58, v59, v60 do
			local v62 = v61:FindFirstChildOfClass("Humanoid")
			if v62 then
				v62 = v61:FindFirstChild("HumanoidRootPart")
			end
			if (not v61:GetAttribute("HitboxNPC") or v61.Owner.Value ~= v52) and (v61.Name ~= "HarutaSwordNPC" and (v61 ~= v_u_6.Character and (v62 and v57 >= (v54.CFrame.Position - v62.Position).Magnitude))) then
				local v63, v64 = v54:WorldToScreenPoint(v62.Position)
				local v65 = (Vector2.new(v63.X, v63.Y) - Vector2.new(v56.X, v56.Y)).Magnitude
				if v64 and v65 < v55 then
					v53 = v61
					v55 = v65
				end
			end
		end
		return v53
	end
end
function v_u_18.GetTargetOrProjectile(p66)
	-- upvalues: (copy) v_u_6, (copy) v_u_30, (copy) v_u_32
	if v_u_6.Character then
		local v67 = nil
		local v68 = workspace.CurrentCamera
		local v69 = v68.ViewportSize.Y / 5
		local v70
		if p66.LastInput == "Mobile" then
			v70 = v_u_6.PlayerGui.Controls.Crosshair.AbsolutePosition
		else
			v70 = Vector2.new(v_u_30.X, v_u_30.Y)
		end
		local v71 = {}
		for _, v72 in workspace.Characters:GetChildren() do
			local v73 = v72:FindFirstChildOfClass("Humanoid")
			if v73 then
				v73 = v72:FindFirstChild("HumanoidRootPart")
			end
			if v72 ~= v_u_6.Character and v73 then
				table.insert(v71, v73)
			end
		end
		for _, v74 in workspace.Map.Destructible.Throwable:GetChildren() do
			local v75 = v74.PrimaryPart
			if v75 and (v75.Parent and (v75.Anchored ~= true and (v75.Velocity.Magnitude > 0.3 and not v75:FindFirstChildWhichIsA("Weld")))) then
				table.insert(v71, v75)
			end
		end
		for _, v76 in v_u_32:GetTagged("CanBoogieWoogie") do
			local v77 = v76.PrimaryPart
			table.insert(v71, v77)
		end
		for _, v78 in v71 do
			if (v68.CFrame.Position - v78.Position).Magnitude <= 100 then
				local v79, v80 = v68:WorldToScreenPoint(v78.Position)
				local v81 = (Vector2.new(v79.X, v79.Y) - Vector2.new(v70.X, v70.Y)).Magnitude
				if v80 and v81 < v69 then
					v67 = v78
					v69 = v81
				end
			end
		end
		if v67 then
			v67 = v67.Parent
		end
		return v67
	end
end
function v_u_18.GetToolService(_, p82)
	-- upvalues: (copy) v_u_17, (copy) v_u_1
	local v83 = v_u_17[p82]
	if v83 then
		return v83
	end
	local v84 = v_u_1.GetService(p82)
	v_u_17[p82] = v84
	return v84
end
function v_u_18.UseSetService(p85, p86, ...)
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_25
	local v87 = v_u_6.Character
	if v87 then
		if p86 == "Ultimate" then
			if v87:FindFirstChild("CustomChar") and v87.CustomChar:GetAttribute("CustomUltData") then
				v_u_1.GetService("CustomService").Awaken:Fire(v_u_25.Custom())
				return
			end
			if v87:GetAttribute("Enchain") then
				local v88 = p85:GetToolService("ItadoriService")
				if v88 then
					v88.UltimateEnchain:Fire(...)
				end
				return
			end
		end
		local v89 = p85:GetToolService(v87:GetAttribute("Moveset") .. "Service")
		if v89 and v89[p86] then
			v89[p86]:Fire(...)
		end
	end
end
function v_u_18.ReturnKey(_, p90)
	-- upvalues: (copy) v_u_6
	local v91 = v_u_6.Character
	if v91 then
		for _, v92 in v91.Moveset:GetChildren() do
			if v92:GetAttribute("Key") == p90 and (v92:GetAttribute("Service") and not (v92:GetAttribute("AWK") and v91:GetAttribute("InUlt"))) and (not v92:GetAttribute("AWK2") or v91:GetAttribute("InUlt")) then
				return v92
			end
		end
	end
end
function v_u_18.UseTool(p93, p_u_94, p95)
	-- upvalues: (copy) v_u_6, (copy) v_u_23, (copy) v_u_18, (copy) v_u_25, (copy) v_u_1
	local v_u_96 = v_u_6.Character
	if v_u_96 then
		local v97 = p93:GetToolService(p_u_94:GetAttribute("Service"))
		if v97 and v97[p95] then
			local v_u_98 = v_u_23[p_u_94.Name] == 1 and v_u_96.Humanoid.FloorMaterial == Enum.Material.Air and true or (v_u_23[p_u_94.Name] == 2 and p93:GetTarget() or v_u_23[p_u_94.Name] == 3 and v_u_18:GetMouseTarget(75) or (v_u_23[p_u_94.Name] == 4 and require(v_u_6.PlayerScripts.PlayerModule.ControlModule):GetMoveVector() or (v_u_23[p_u_94.Name] == 5 and {
				v_u_96.Humanoid.FloorMaterial == Enum.Material.Air,
				p93:GetTarget(),
				v_u_18:GetMouseTarget(75),
				require(v_u_6.PlayerScripts.PlayerModule.ControlModule):GetMoveVector()
			} or false)))
			if p95 == "Activated" then
				local v99 = v97[p95]
				local v100 = not v_u_98 and v_u_25[p_u_94.Name]
				if v100 then
					v100 = v_u_25[p_u_94.Name]()
				end
				v99:Fire(p_u_94, v100)
			elseif p95 == "Deactivated" then
				pcall(function()
					-- upvalues: (copy) p_u_94, (ref) v_u_1, (ref) v_u_98, (copy) v_u_96
					local v101 = p_u_94:GetAttribute("Service")
					local v102 = #p_u_94:GetAttribute("Service") - 7
					local v103 = string.sub(v101, 0, v102)
					local v104 = v_u_1.GetController(v103 .. "Controller")
					if v104 and v104.ToolDeactivate then
						v_u_98 = v104.ToolDeactivate(v_u_96)
					end
				end)
				v97[p95]:Fire(p_u_94, v_u_98)
			end
		end
	end
end
function v_u_18.UseKey(p105, p106, p107)
	-- upvalues: (copy) v_u_6
	if v_u_6.Character then
		local v108 = p105:ReturnKey(p106)
		if v108 then
			p105:UseTool(v108, p107)
		end
	else
		return
	end
end
function v_u_18.UpdateShift(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_8
	local v109 = v_u_6.PlayerGui.Controls
	if _G.Shift == true then
		v109.Crosshair.ImageTransparency = 0.5
		v_u_2.MouseIcon = "rbxasset://textures/collapsibleArrowDown.png"
	else
		v_u_8.RotationType = Enum.RotationType.MovementRelative
		v_u_2.MouseBehavior = Enum.MouseBehavior.Default
		v109.Crosshair.ImageTransparency = 1
		v_u_2.MouseIcon = ""
	end
end
local v_u_110 = false
local function v_u_119(p111)
	-- upvalues: (ref) v_u_13
	if not p111.Info:FindFirstChild("NoThrowable") then
		local v112 = p111.HumanoidRootPart
		local v113 = 4 * p111:GetScale()
		local v114 = v112.Position + v112.CFrame.LookVector * 3
		local v115 = nil
		for _, v116 in workspace.Map.Destructible.Throwable:GetChildren() do
			if v116.PrimaryPart and not (v116:GetAttribute("B") or v116:GetAttribute("Hold")) then
				local v117 = (v114 - v116.PrimaryPart.Position).Magnitude
				if v113 >= v117 then
					v115 = v116
					v113 = v117
				end
			end
		end
		local v118 = p111.Info:FindFirstChild("Throwable")
		if v115 and not v118 then
			v_u_13.Throwable:Fire(v115)
			return true
		end
		if v118 and (v118.Value and not v118.Value:GetAttribute("Stored")) then
			v_u_13.Throwable:Fire(v118.Value)
			return true
		end
	end
end
function v_u_18.Melee(p120)
	-- upvalues: (copy) v_u_6, (ref) v_u_14, (copy) v_u_119, (copy) v_u_29, (ref) v_u_110, (ref) v_u_15, (copy) v_u_25
	local v121 = v_u_6.Character
	if not v121 then
		return
	end
	if _G.Crow and _G.Crow:IsDescendantOf(workspace.Effects.Crows) then
		_G.Crow:FireServer(true)
		return
	end
	_G.Crow = nil
	if v121.Info:FindFirstChild("Emote") then
		v_u_14.EmoteEnd:Fire()
	end
	if v_u_119(v121) then
		return
	end
	if _G.Settings.AutoUse == false and v_u_29.Value then
		v_u_110 = true
		local v122 = v_u_29.Value:GetAttribute("Key")
		p120:UseKey(v122, "Activated")
		repeat
			task.wait()
		until not v121.Parent or v_u_110 == false
		p120:UseKey(v122, "Deactivated")
		return
	end
	v_u_110 = true
	while true do
		local v123 = v121.Info:FindFirstChild("Item")
		if v123 and v123:FindFirstChild("M1") then
			local v124 = v121.Humanoid.Jump == true
			local v125 = v121.Humanoid.FloorMaterial == Enum.Material.Air
			v_u_15.M1:Fire(v125 and "Down" or v124 and "Up", p120:GetTarget())
		else
			local v126 = v121.Humanoid.Jump == true
			local v127 = v121.Humanoid.FloorMaterial == Enum.Material.Air
			if v121:FindFirstChild("CustomM1") then
				p120:GetToolService("CustomService").Melee:Fire(v_u_25.Custom())
			else
				p120:UseSetService("Activated", v127 and "Down" or v126 and "Up")
			end
		end
		task.wait(0.025)
		if not v121.Parent or v_u_110 == false then
			return
		end
	end
end
function v_u_18.Special(p128)
	-- upvalues: (copy) v_u_6, (ref) v_u_15, (copy) v_u_25
	local v129 = v_u_6.Character
	if v129 then
		local v130 = v129.Info:FindFirstChild("Item")
		if v130 and v130:FindFirstChild("M2") then
			v_u_15.M2:Fire()
			return
		elseif v129:FindFirstChild("CustomChar") and v129.CustomChar:GetAttribute("CustomSpecial") then
			p128:GetToolService("CustomService").Special:Fire(v_u_25.Custom())
			return
		else
			local v131 = v129:GetAttribute("Moveset")
			if v131 == "Todo" then
				p128:UseSetService("RightActivated", p128:GetTargetOrProjectile())
				return
			elseif v131 == "Naoya" then
				p128:UseSetService("RightActivated", p128:GetMouseTarget(75))
			else
				p128:UseSetService("RightActivated", p128:GetTarget())
			end
		end
	else
		return
	end
end
function v_u_18.ReleaseSpecial(p132)
	-- upvalues: (copy) v_u_6
	if v_u_6.Character then
		p132:UseSetService("RightDeactivated")
	end
end
function v_u_18.Block(p133)
	-- upvalues: (copy) v_u_6, (ref) v_u_14, (ref) v_u_12
	local v134 = v_u_6.Character
	if v134 then
		if v134.Info:FindFirstChild("Emote") then
			if _G.UsingPiano == 2 then
				return
			end
			v_u_14.EmoteEnd:Fire()
		end
		local v135 = p133:GetTarget()
		v_u_12.Activated:Fire(v135)
	end
end
function v_u_18.KnitStart(p_u_136)
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_22, (copy) v_u_29, (copy) v_u_3, (ref) v_u_16, (ref) v_u_110, (ref) v_u_12, (copy) v_u_9, (ref) v_u_11, (copy) v_u_30, (copy) v_u_4, (copy) v_u_5, (copy) v_u_18, (copy) v_u_20, (copy) v_u_21, (copy) v_u_19, (copy) v_u_10, (copy) v_u_39, (copy) v_u_32
	local v_u_137 = v_u_6.PlayerGui:WaitForChild("Main")
	local v_u_138 = v_u_137.Ultimate.Bar
	local v_u_139 = v_u_137.Ultimate.Title
	local v_u_140 = v_u_6.PlayerGui:WaitForChild("Controls").Mobile
	v_u_2.InputBegan:Connect(function(p141, p142)
		-- upvalues: (copy) p_u_136, (ref) v_u_22, (ref) v_u_29, (ref) v_u_3, (ref) v_u_16
		if p142 then
			return
		elseif p141.UserInputType == Enum.UserInputType.MouseButton1 or p141.KeyCode == Enum.KeyCode.ButtonB then
			p_u_136:Melee()
			return
		elseif v_u_22[p141.KeyCode] == nil then
			if p141.KeyCode == Enum.KeyCode.R or p141.KeyCode == Enum.KeyCode.DPadLeft then
				p_u_136:Special()
				return
			elseif p141.KeyCode == Enum.KeyCode.G or p141.KeyCode == Enum.KeyCode.DPadRight then
				p_u_136:UseSetService("Ultimate")
				return
			elseif p141.KeyCode == Enum.KeyCode.F or p141.KeyCode == Enum.KeyCode.ButtonX then
				p_u_136:Block()
				return
			elseif p141.KeyCode == Enum.KeyCode.LeftShift or p141.KeyCode == Enum.KeyCode.DPadDown then
				_G.Shift = not _G.Shift
				p_u_136:UpdateShift()
			elseif p141.KeyCode == Enum.KeyCode.ButtonL3 or p141.KeyCode == Enum.KeyCode.J and v_u_3:IsStudio() then
				if v_u_16.LockOn then
					v_u_16.LockOn = nil
					return
				end
				v_u_16.LockOn = p_u_136:GetTarget()
			end
		elseif _G.Settings.AutoUse == true then
			p_u_136:UseKey(v_u_22[p141.KeyCode], "Activated")
			return
		else
			local v143 = p_u_136:ReturnKey(v_u_22[p141.KeyCode])
			if v143 and v143 ~= v_u_29.Value then
				v_u_29.Value = v143
			else
				v_u_29.Value = nil
			end
		end
	end)
	v_u_2.InputEnded:Connect(function(p144, _)
		-- upvalues: (ref) v_u_22, (copy) p_u_136, (ref) v_u_110, (ref) v_u_12
		if v_u_22[p144.KeyCode] == nil then
			if p144.KeyCode == Enum.KeyCode.R or p144.KeyCode == Enum.KeyCode.DPadLeft then
				p_u_136:ReleaseSpecial()
				return
			elseif p144.UserInputType == Enum.UserInputType.MouseButton1 or p144.KeyCode == Enum.KeyCode.ButtonB then
				v_u_110 = false
				return
			elseif p144.KeyCode == Enum.KeyCode.G or p144.KeyCode == Enum.KeyCode.DPadRight then
				p_u_136:UseSetService("Deultimate")
			elseif p144.KeyCode == Enum.KeyCode.F or p144.KeyCode == Enum.KeyCode.ButtonX then
				v_u_12.Deactivated:Fire()
			end
		else
			p_u_136:UseKey(v_u_22[p144.KeyCode], "Deactivated")
			return
		end
	end)
	v_u_138.Touch.MouseButton1Down:Connect(function()
		-- upvalues: (copy) p_u_136
		p_u_136:UseSetService("Ultimate")
	end)
	v_u_138.Touch.MouseButton1Up:Connect(function()
		-- upvalues: (copy) p_u_136
		p_u_136:UseSetService("Deultimate")
	end)
	local v_u_145 = v_u_9.new()
	v_u_145:setImage(15117261700)
	local v_u_146 = false
	local v_u_147 = nil
	local v_u_148 = v_u_9.new()
	v_u_148:setLabel("Lock Layout")
	v_u_148:select()
	v_u_148:autoDeselect(false)
	v_u_148.toggled:Connect(function(p149)
		-- upvalues: (ref) v_u_146, (ref) v_u_147, (copy) v_u_140, (ref) v_u_11
		v_u_146 = not p149
		if v_u_146 == false then
			v_u_147 = nil
			for _, v150 in v_u_140.Jump:GetChildren() do
				v150.ImageColor3 = Color3.fromRGB(255, 255, 255)
				v150.ImageLabel.ImageColor3 = Color3.fromRGB(255, 255, 255)
			end
			v_u_11.MobileLayout:Fire({ v_u_140.Jump.Block.Position.X.Offset, v_u_140.Jump.Block.Position.Y.Offset }, { v_u_140.Jump.Dash.Position.X.Offset, v_u_140.Jump.Dash.Position.Y.Offset }, { v_u_140.Jump.Melee.Position.X.Offset, v_u_140.Jump.Melee.Position.Y.Offset }, { v_u_140.Jump.Special.Position.X.Offset, v_u_140.Jump.Special.Position.Y.Offset })
		else
			for _, v151 in v_u_140.Jump:GetChildren() do
				v151.ImageColor3 = Color3.fromRGB(85, 255, 255)
				v151.ImageLabel.ImageColor3 = Color3.fromRGB(85, 255, 255)
			end
		end
	end)
	v_u_11.MobileLayout:Connect(function(p152)
		-- upvalues: (copy) v_u_140
		v_u_140.Jump.Block.Position = UDim2.new(v_u_140.Jump.Block.Position.X.Scale, p152[1], v_u_140.Jump.Block.Position.Y.Scale, p152[2])
		v_u_140.Jump.Dash.Position = UDim2.new(v_u_140.Jump.Dash.Position.X.Scale, p152[3], v_u_140.Jump.Dash.Position.Y.Scale, p152[4])
		v_u_140.Jump.Melee.Position = UDim2.new(v_u_140.Jump.Melee.Position.X.Scale, p152[5], v_u_140.Jump.Melee.Position.Y.Scale, p152[6])
		v_u_140.Jump.Special.Position = UDim2.new(v_u_140.Jump.Special.Position.X.Scale, p152[7], v_u_140.Jump.Special.Position.Y.Scale, p152[8])
	end)
	v_u_11.MobileLayout:Fire()
	local v153 = v_u_9.new()
	v153:setLabel("Reset Layout")
	v153:oneClick(true)
	v153.selected:Connect(function(_)
		-- upvalues: (copy) v_u_140, (copy) v_u_148
		for _, v154 in v_u_140.Jump:GetChildren() do
			v154.Position = UDim2.new(v154.Position.X.Scale, 0, v154.Position.Y.Scale, 0)
		end
		v_u_148:select()
	end)
	v_u_145:setDropdown({ v_u_148, v153 })
	local v_u_155 = v_u_147
	local v_u_156 = v_u_146
	for _, v_u_157 in v_u_140.Jump:GetChildren() do
		v_u_157.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_156, (ref) v_u_155, (copy) v_u_157, (copy) p_u_136, (ref) v_u_16
			if v_u_156 == true then
				v_u_155 = v_u_157
				return
			elseif v_u_157.Name == "Melee" then
				p_u_136:Melee()
				return
			elseif v_u_157.Name == "Block" then
				p_u_136:Block()
				return
			elseif v_u_157.Name == "Special" then
				p_u_136:Special()
			elseif v_u_157.Name == "Dash" then
				v_u_16:DashRequest()
			end
		end)
		v_u_157.InputEnded:Connect(function()
			-- upvalues: (ref) v_u_156, (ref) v_u_155, (copy) v_u_157, (ref) v_u_110, (ref) v_u_12, (copy) p_u_136
			if v_u_156 == true and v_u_155 == v_u_157 then
				v_u_155 = nil
			end
			if v_u_157.Name == "Melee" then
				v_u_110 = false
				return
			elseif v_u_157.Name == "Block" then
				v_u_12.Deactivated:Fire()
			elseif v_u_157.Name == "Special" then
				p_u_136:ReleaseSpecial()
			end
		end)
	end
	v_u_140.ShiftLock.MouseButton1Down:Connect(function()
		-- upvalues: (copy) p_u_136
		_G.Shift = not _G.Shift
		p_u_136:UpdateShift()
	end)
	v_u_3.RenderStepped:Connect(function()
		-- upvalues: (copy) v_u_140, (ref) v_u_155, (ref) v_u_30, (copy) v_u_137
		if v_u_140.Visible == true then
			if v_u_155 then
				local v158 = v_u_140.Jump.AbsoluteSize
				local v159 = v158 * Vector2.new(v_u_155.Position.X.Scale, v_u_155.Position.Y.Scale)
				local v160 = v_u_140.Jump.AbsolutePosition + v159
				local v161 = Vector2.new(v_u_30.X, v_u_30.Y) - v160 - Vector2.new(v158.X / 2, v158.Y / 2)
				v_u_155.Position = UDim2.new(v_u_155.Position.X.Scale, v161.X, v_u_155.Position.Y.Scale, v161.Y)
			end
			local v162 = v_u_137.AbsoluteSize
			local v163 = v162.X
			local v164 = v162.Y
			local v165 = math.min(v163, v164) <= 500
			local v166 = v165 and 70 or 120
			v_u_140.Jump.Size = UDim2.new(0, v166, 0, v166)
			v_u_140.Jump.Position = v165 and UDim2.new(1, -(v166 * 1.5 - 10), 1, -v166 - 20) or UDim2.new(1, -(v166 * 1.5 - 10), 1, -v166 * 1.75)
		end
	end)
	local v_u_167 = 0
	v_u_3.Stepped:Connect(function(p168, p169)
		-- upvalues: (ref) v_u_6, (copy) v_u_138, (copy) p_u_136, (ref) v_u_167, (ref) v_u_4, (ref) v_u_5
		local v170 = v_u_6.Character
		local v171 = v_u_6:GetAttribute("Ultimate")
		local v172 = v_u_138.Fill
		local v173 = UDim2.new
		local v174 = v_u_138.Fill.Size.X.Scale
		local v175 = v171 / 100
		local v176 = 10 * p169
		v172.Size = v173(v174 + (v175 - v174) * v176, 0, 1, 0)
		local v177
		if v170 then
			v177 = not v170:GetAttribute("InUlt") or false
		else
			v177 = false
		end
		if v170:GetAttribute("Moveset") == "Yuki" then
			v177 = v177 and v170:GetAttribute("Dead")
			if v177 then
				v177 = not v170:GetAttribute("LastResort")
			end
		end
		if v170:GetAttribute("Moveset") == "Haruta" then
			if v177 then
				v177 = v170:GetAttribute("Sword") == nil
			end
		end
		local v178 = v_u_138.Ready
		local v179 = p_u_136.ShowReady == true and p_u_136.ShowReady
		if v179 then
			v177 = v179
		elseif v177 then
			v177 = v171 >= 100
		end
		v178.Visible = v177
		if v170:GetAttribute("Ult2") then
			v_u_138.Fill2.Visible = true
			local v180 = v_u_138.Fill2
			local v181 = UDim2.new
			local v182 = v_u_138.Fill2.Size.X.Scale
			local v183 = v170:GetAttribute("Ult2") / 100
			local v184 = 10 * p169
			v180.Size = v181(v182 + (v183 - v182) * v184, 0, 0, 4)
			v_u_138.Fill2.BackgroundColor3 = Color3.fromHSV(p168 % 1, 0.7, 1)
		else
			v_u_138.Fill2.Visible = false
			v_u_138.Fill2.Size = UDim2.new(0, 0, 0, 4)
		end
		if v171 >= 100 and (v_u_167 < 100 and (v170 and not v170:GetAttribute("InUlt"))) then
			local v185 = Instance.new("Highlight", v170)
			v_u_4:AddItem(v185, 2)
			v185.FillColor = Color3.new(1, 1, 1)
			v185.FillTransparency = 0
			v_u_5:Create(v185, TweenInfo.new(1.25), {
				["FillTransparency"] = 1
			}):Play()
			v_u_5:Create(v185, TweenInfo.new(2), {
				["OutlineTransparency"] = 1
			}):Play()
			local v186 = Instance.new("PointLight", v170.Torso)
			v186.Brightness = 10
			v_u_4:AddItem(v186, 2)
			v_u_5:Create(v186, TweenInfo.new(2), {
				["Brightness"] = 0,
				["Range"] = 4
			}):Play()
		end
		v_u_167 = v171
	end)
	v_u_6:GetAttributeChangedSignal("UI"):Connect(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_5, (copy) v_u_139, (copy) v_u_138, (copy) v_u_137
		if v_u_6:GetAttribute("UI") == false then
			v_u_5:Create(v_u_139, TweenInfo.new(0.9), {
				["Position"] = UDim2.new(0.5, 0, 1, 50)
			}):Play()
			v_u_5:Create(v_u_138, TweenInfo.new(0.9), {
				["Position"] = UDim2.new(0.5, 0, 1, 75)
			}):Play()
			v_u_5:Create(v_u_138.Parent.Evade, TweenInfo.new(0.9), {
				["Position"] = UDim2.new(0.5, -150, 1, 87)
			}):Play()
			v_u_5:Create(v_u_138.Parent.Special, TweenInfo.new(0.9), {
				["Position"] = UDim2.new(0.5, 150, 1, 87)
			}):Play()
			v_u_5:Create(v_u_137.Moveset, TweenInfo.new(0.6), {
				["Position"] = UDim2.new(0.5, 0, 1, 160)
			}):Play()
			if v_u_137.Parent:FindFirstChild("Miracles") then
				v_u_5:Create(v_u_137.Parent.Miracles.Miracles, TweenInfo.new(0.9), {
					["Position"] = UDim2.new(0.5, 0, 1, 50)
				}):Play()
				return
			end
		else
			v_u_5:Create(v_u_139, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["Position"] = UDim2.new(0.5, 0, 1, -115)
			}):Play()
			v_u_5:Create(v_u_138, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["Position"] = UDim2.new(0.5, 0, 1, -90)
			}):Play()
			v_u_5:Create(v_u_138.Parent.Evade, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["Position"] = UDim2.new(0.5, -150, 1, -78)
			}):Play()
			v_u_5:Create(v_u_138.Parent.Special, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["Position"] = UDim2.new(0.5, 150, 1, -78)
			}):Play()
			v_u_5:Create(v_u_137.Moveset, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["Position"] = UDim2.new(0.5, 0, 1, -5)
			}):Play()
			if v_u_137.Parent:FindFirstChild("Miracles") then
				v_u_5:Create(v_u_137.Parent.Miracles.Miracles, TweenInfo.new(1.5), {
					["Position"] = UDim2.new(0.5, 0, 1, -115)
				}):Play()
			end
		end
	end)
	local function v_u_190()
		-- upvalues: (ref) v_u_6, (copy) v_u_137
		local v187 = v_u_6.Character:GetAttribute("InUlt") == true and true or nil
		for _, v188 in v_u_137.Moveset:GetChildren() do
			if v188:IsA("Frame") then
				local v189 = v188.Item.Value
				if v189 and v189:IsDescendantOf(workspace.Characters) then
					if v189:GetAttribute("AWK") and v187 or (v189:GetAttribute("AWK2") and not v187 or v189.Parent.Name ~= "Moveset") then
						v188.Visible = false
					else
						v188.Visible = true
					end
				else
					v188.Visible = false
				end
			end
		end
	end
	local v_u_191 = {}
	local function v_u_204(p_u_192, p_u_193)
		-- upvalues: (copy) v_u_191, (ref) v_u_18, (ref) v_u_6, (copy) v_u_137, (ref) v_u_20, (ref) v_u_21, (copy) p_u_136, (ref) v_u_29, (copy) v_u_190, (ref) v_u_5
		if p_u_192:IsA("NumberValue") then
			if not v_u_191[p_u_192] then
				if p_u_192.Name == "Custom" and p_u_192:GetAttribute("USE") then
					v_u_18:UseTool(p_u_192, "Activated")
				end
				if p_u_192.Name == "Custom" and p_u_192:GetAttribute("USEONDEATH") then
					v_u_6.Character:GetAttributeChangedSignal("Dead"):Once(function()
						-- upvalues: (ref) v_u_18, (copy) p_u_192
						v_u_18:UseTool(p_u_192, "Activated")
					end)
				end
				local v_u_194 = v_u_137.Preset.Item:Clone()
				local v_u_195 = v_u_194.Cooldown
				v_u_194.Name = p_u_192.Name
				v_u_194.ItemName.Text = p_u_192:GetAttribute("Tag") or p_u_192.Name
				v_u_194.Parent = v_u_137.Moveset
				v_u_191[p_u_192] = v_u_194
				if p_u_192:GetAttribute("Key") then
					v_u_194.LayoutOrder = p_u_192:GetAttribute("Key")
					v_u_194.Key.Text = p_u_192:GetAttribute("Key")
					if v_u_20[p_u_192:GetAttribute("Key")] then
						v_u_194.XboxKey.Text = v_u_20[p_u_192:GetAttribute("Key")]
					end
					if v_u_21[p_u_192:GetAttribute("Key")] then
						v_u_194.PlaystationKey.Text = v_u_21[p_u_192:GetAttribute("Key")]
					end
					v_u_194.ItemName.MouseButton1Down:Connect(function()
						-- upvalues: (ref) p_u_136, (copy) p_u_192
						local v196 = p_u_192
						p_u_136:UseKey(tonumber(v196:GetAttribute("Key")), "Activated")
					end)
					v_u_194.ItemName.MouseButton1Up:Connect(function()
						-- upvalues: (ref) p_u_136, (copy) p_u_192
						local v197 = p_u_192
						p_u_136:UseKey(tonumber(v197:GetAttribute("Key")), "Deactivated")
					end)
				end
				p_u_192:GetAttributeChangedSignal("Tip"):Connect(function()
					-- upvalues: (copy) p_u_192, (copy) v_u_194
					if p_u_192:GetAttribute("Tip") then
						v_u_194.Tip.Text = p_u_192:GetAttribute("Tip")
						v_u_194.Tip.Visible = true
					else
						v_u_194.Tip.Visible = false
					end
				end)
				if p_u_192:GetAttribute("Tip") then
					v_u_194.Tip.Text = p_u_192:GetAttribute("Tip")
					v_u_194.Tip.Visible = true
				else
					v_u_194.Tip.Visible = false
				end
				v_u_194.Item.Value = p_u_192
				v_u_194:GetPropertyChangedSignal("Visible"):Connect(function()
					-- upvalues: (copy) v_u_194, (ref) v_u_29, (copy) p_u_192
					if not v_u_194.Visible then
						if v_u_29.Value == p_u_192 then
							v_u_29.Value = nil
						end
					end
				end)
				p_u_192.AncestryChanged:Connect(function()
					-- upvalues: (copy) p_u_192, (ref) v_u_190, (copy) p_u_193, (copy) v_u_194, (ref) v_u_191, (ref) v_u_29
					if p_u_192:IsDescendantOf(workspace.Characters) then
						task.defer(v_u_190)
						return
					elseif p_u_192.Parent ~= p_u_193 then
						v_u_194:Destroy()
						v_u_191[p_u_192] = nil
						if v_u_29.Value == p_u_192 then
							v_u_29.Value = nil
						end
					end
				end)
				p_u_192:GetPropertyChangedSignal("Name"):Connect(function()
					-- upvalues: (copy) v_u_194, (copy) p_u_192
					v_u_194.Name = p_u_192.Name
					v_u_194.ItemName.Text = p_u_192:GetAttribute("Tag") or p_u_192.Name
				end)
				p_u_192:GetAttributeChangedSignal("Tag"):Connect(function()
					-- upvalues: (copy) v_u_194, (copy) p_u_192
					v_u_194.Name = p_u_192.Name
					v_u_194.ItemName.Text = p_u_192:GetAttribute("Tag") or p_u_192.Name
				end)
				if p_u_192:GetAttribute("LastUse") then
					local v_u_198 = {}
					p_u_192:GetAttributeChangedSignal("LastUse"):Connect(function()
						-- upvalues: (copy) v_u_198, (copy) p_u_192, (copy) v_u_195, (copy) v_u_194, (ref) v_u_6, (ref) v_u_5
						local v199 = tick()
						v_u_198[p_u_192] = v199
						local v200 = workspace:GetServerTimeNow()
						local v201 = p_u_192.Value - (v200 - p_u_192:GetAttribute("LastUse"))
						repeat
							local v202 = 1 - (workspace:GetServerTimeNow() - v200) / v201
							local v203 = math.clamp(v202, 0, 1)
							v_u_195.Size = UDim2.new(1, 0, v203, 0)
							task.wait()
						until v201 <= workspace:GetServerTimeNow() - v200 or (not p_u_192.Parent or (not v_u_194.Parent or v_u_6.Character and v_u_6.Character.Info:GetAttribute("CD"))) or v_u_198[p_u_192] ~= v199
						if v_u_198[p_u_192] == v199 then
							v_u_198[p_u_192] = nil
						end
						if v_u_194.Parent then
							local _ = v200 <= 0
							v_u_195.Size = UDim2.new(1, 0, 0, 0)
							v_u_194.BackgroundColor3 = Color3.new(1, 1, 1)
							v_u_5:Create(v_u_194, TweenInfo.new(1), {
								["BackgroundColor3"] = Color3.fromRGB(31, 31, 31)
							}):Play()
						end
					end)
				end
			end
		else
			return
		end
	end
	local function v_u_209(p205)
		-- upvalues: (ref) v_u_19, (copy) v_u_139, (copy) v_u_138
		local v206 = p205:GetAttribute("Moveset")
		if v_u_19[v206] then
			v_u_139.Visible = true
			v_u_138.Visible = true
			v_u_139.Text = p205:GetAttribute("CustomUlt") or v_u_19[v206][1]
			v_u_138.Fill.BackgroundColor3 = v_u_19[v206][2]
			v_u_138.Fill.UIGradient.Color = ColorSequence.new(v_u_19[v206][3], Color3.new(1, 1, 1))
			v_u_138.Parent.Special.Fill.BackgroundColor3 = v_u_19[v206][2]
			v_u_138.Parent.Special.Fill.UIGradient.Color = v_u_138.Fill.UIGradient.Color
			for _, v207 in v_u_138.Ready:GetDescendants() do
				if v207:IsA("TextLabel") then
					v207.TextTransparency = v_u_19[v206][4] and 0 or 1
				elseif v207:IsA("UIStroke") then
					v207.Enabled = v_u_19[v206][4]
				end
			end
			if v_u_19[v206][5] and not v_u_138.Fill:FindFirstChild("CustomImage") then
				local v208 = Instance.new("ImageLabel")
				v208.Image = "rbxassetid://" .. v_u_19[v206][5]
				v208.Size = UDim2.fromScale(1, 1)
				v208.BackgroundTransparency = 1
				v208.Name = "CustomImage"
				v208.Parent = v_u_138
				return
			end
			if v_u_138:FindFirstChild("CustomImage") then
				v_u_138.CustomImage:Destroy()
				return
			end
		else
			v_u_139.Visible = false
			v_u_138.Visible = false
		end
	end
	v_u_29:GetPropertyChangedSignal("Value"):Connect(function()
		-- upvalues: (ref) v_u_29, (copy) v_u_137
		local v210 = v_u_29.Value
		if v210 == nil then
			for _, v211 in v_u_137.Moveset:GetChildren() do
				if v211:IsA("Frame") then
					v211.Outline.Enabled = false
				end
			end
		else
			for _, v212 in v_u_137.Moveset:GetChildren() do
				if v212:IsA("Frame") then
					v212.Outline.Enabled = v210.Name == v212.Name
				end
			end
		end
	end)
	local function v231(p_u_213)
		-- upvalues: (copy) v_u_137, (copy) v_u_191, (copy) v_u_209, (ref) v_u_29, (copy) v_u_204, (copy) v_u_190, (copy) v_u_138, (ref) v_u_6, (ref) v_u_3, (ref) v_u_10
		if p_u_213:IsDescendantOf(workspace.Effects) then
			return
		end
		local v214 = p_u_213:WaitForChild("Moveset")
		for _, v215 in v_u_137.Moveset:GetChildren() do
			if v215:IsA("Frame") then
				for v218, v217 in v_u_191 do
					if v217 == v215 then
						goto l9
					end
				end
				local v218 = nil
				::l9::
				if not v218 or v218.Parent ~= v214 then
					v215:Destroy()
				end
			end
		end
		p_u_213:GetAttributeChangedSignal("Moveset"):Connect(function()
			-- upvalues: (ref) v_u_209, (copy) p_u_213
			v_u_209(p_u_213)
		end)
		p_u_213:GetAttributeChangedSignal("CustomUlt"):Connect(function()
			-- upvalues: (ref) v_u_209, (copy) p_u_213
			v_u_209(p_u_213)
		end)
		v_u_29.Value = nil
		v_u_209(p_u_213)
		local v_u_219 = p_u_213:WaitForChild("Moveset")
		if #v_u_219:GetChildren() > 0 then
			for _, v220 in v_u_219:GetChildren() do
				v_u_204(v220, v_u_219)
			end
		end
		v_u_219.ChildAdded:Connect(function(p221)
			-- upvalues: (ref) v_u_204, (copy) v_u_219, (ref) v_u_190
			v_u_204(p221, v_u_219)
			v_u_190()
		end)
		p_u_213:GetAttributeChangedSignal("InUlt"):Connect(v_u_190)
		v_u_190()
		local v_u_222 = {}
		v_u_138.Parent.Special.Fill.Size = UDim2.new(1, 0, 1, 0)
		p_u_213:GetAttributeChangedSignal("LastM2"):Connect(function()
			-- upvalues: (copy) v_u_222, (copy) p_u_213, (ref) v_u_138, (ref) v_u_6
			local v223 = tick()
			v_u_222[p_u_213] = v223
			local v224 = workspace:GetServerTimeNow()
			local v225 = (p_u_213:GetAttribute("M2_CD") or 0) - (v224 - (p_u_213:GetAttribute("LastM2") or 0))
			if v225 <= 0 then
				v_u_138.Parent.Special.Fill.Size = UDim2.new(1, 0, 1, 0)
			else
				repeat
					local v226 = (workspace:GetServerTimeNow() - v224) / v225
					local v227 = math.clamp(v226, 0, 1)
					v_u_138.Parent.Special.Fill.Size = UDim2.new(v227, 0, 1, 0)
					task.wait()
				until not v_u_6.Character.Parent or (v225 <= workspace:GetServerTimeNow() - v224 or (v_u_6.Character.Info:GetAttribute("CD") or v_u_222[p_u_213] ~= v223))
				v_u_138.Parent.Special.Fill.Size = UDim2.new(1, 0, 1, 0)
				if v_u_222[p_u_213] == v223 then
					v_u_222[p_u_213] = nil
				end
			end
		end)
		task.spawn(function()
			-- upvalues: (copy) p_u_213, (ref) v_u_3, (ref) v_u_10
			local v228 = p_u_213:GetAttribute("Moveset")
			if not v228 then
				p_u_213:GetAttributeChangedSignal("Moveset"):Wait()
				v228 = p_u_213:GetAttribute("Moveset")
			end
			v_u_3.Stepped:Wait()
			local v229 = v_u_10:FindFirstChild(v228)
			if not v229 then
				if v228 == "Mokou" then
					v229 = v_u_10.Misc.M
				elseif v228 == "Chara" then
					v229 = v_u_10.Misc.C
				end
				if not v229 then
					return
				end
			end
			for _, v230 in v229:GetDescendants() do
				if v230:IsA("Animation") then
					p_u_213.Humanoid:LoadAnimation(v230)
				end
			end
		end)
	end
	if v_u_6.Character then
		v231(v_u_6.Character)
	end
	v_u_6.CharacterAdded:Connect(v231)
	p_u_136.LastInput = v_u_18:GetPlatform(v_u_2:GetLastInputType())
	v_u_39()
	if p_u_136.LastInput ~= "Mobile" then
		v_u_145:setEnabled(false)
	end
	v_u_2.InputBegan:Connect(function(p232, p233)
		-- upvalues: (copy) p_u_136, (ref) v_u_39, (copy) v_u_145, (ref) v_u_16
		if not p233 then
			local v234 = p_u_136:GetPlatform(p232.UserInputType)
			if v234 and v234 ~= p_u_136.LastInput then
				p_u_136.LastInput = v234
				v_u_39()
				v_u_145:setEnabled(v234 == "Mobile")
				if v234 ~= "Xbox" and v234 ~= "Playstation" then
					v_u_16.LockOn = nil
				end
			end
		end
	end)
	local function v238(p235)
		-- upvalues: (ref) v_u_32, (copy) p_u_136
		local v236 = true
		for _, v237 in v_u_32:GetTags(p235) do
			if v237 == p_u_136.LastInput then
				v236 = false
			end
		end
		if v236 == true then
			p235.Visible = false
		end
	end
	v_u_32:GetInstanceAddedSignal("Xbox"):Connect(v238)
	v_u_32:GetInstanceAddedSignal("Playstation"):Connect(v238)
	v_u_32:GetInstanceAddedSignal("Mobile"):Connect(v238)
	v_u_32:GetInstanceAddedSignal("Keyboard"):Connect(v238)
end
function v_u_18.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16
	v_u_11 = v_u_1.GetService("JoinService")
	v_u_12 = v_u_1.GetService("BlockService")
	v_u_13 = v_u_1.GetService("MovementService")
	v_u_14 = v_u_1.GetService("EmoteService")
	v_u_15 = v_u_1.GetService("ItemService")
	v_u_16 = v_u_1.GetController("MovementController")
end
return v_u_18