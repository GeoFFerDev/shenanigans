-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "DivineDogController"
})
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Include
v_u_12.FilterDescendantsInstances = { workspace.Map, workspace.Spawns, workspace.Domains }
function v11.KnitStart(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_3, (ref) v_u_10, (copy) v_u_7, (copy) v_u_2, (copy) v_u_12, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_47 = {
		["Summon"] = function(p13)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v14 = v_u_6.Megumi.Spawn:Clone()
			v14.Parent = workspace.Effects
			v_u_3:AddItem(v14, 1)
			v14.Position = p13.Position - Vector3.new(0, 3.5, 0)
			v14.Shadow:Emit(12)
			v14.Dive:Emit(6)
			v_u_10:PlaySound(v_u_7.Megumi.DivineDog.Spawn, v14, game.SoundService.Effect)
		end,
		["Follow"] = function(p15, p_u_16, p_u_17)
			-- upvalues: (ref) v_u_2, (ref) v_u_6, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7, (ref) v_u_12
			local v_u_18 = p15:FindFirstChild("HumanoidRootPart")
			if v_u_18 then
				local v19 = p_u_16.AnimationController
				local v_u_20 = v19:LoadAnimation(v19.DivineDogsIdle)
				local v_u_21 = v19:LoadAnimation(v19.DivineDogsWalk)
				local v_u_22 = v19:LoadAnimation(v19.Emote)
				v_u_20:Play()
				v_u_21:Play(nil, 0.01, 2)
				v_u_22.Priority = Enum.AnimationPriority.Action2
				local v_u_24 = p15.Info.ChildAdded:Connect(function(p23)
					-- upvalues: (copy) v_u_20, (copy) v_u_22
					if p23.Name == "Emote" then
						v_u_20:Stop()
						v_u_22:Play()
						p23.Destroying:Connect(function()
							-- upvalues: (ref) v_u_20, (ref) v_u_22
							v_u_20:Play()
							v_u_22:Stop()
						end)
					end
				end)
				local v_u_25 = p_u_16.RootPart.Position
				local v_u_26 = nil
				v_u_26 = v_u_2.Stepped:Connect(function(_, p27)
					-- upvalues: (copy) v_u_18, (copy) p_u_17, (copy) p_u_16, (ref) v_u_26, (copy) v_u_24, (ref) v_u_6, (ref) v_u_25, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7, (ref) v_u_12, (copy) v_u_20, (copy) v_u_21
					if v_u_18.Parent and (p_u_17 and (p_u_17.Parent and p_u_16:FindFirstChild("RootPart"))) then
						local v28 = v_u_18.Position + v_u_18.CFrame.RightVector * 8
						local v29 = workspace:Raycast(v28 + Vector3.new(0, 2, 0), Vector3.new(0, -20, 0), v_u_12)
						if v29 then
							v28 = v29.Position + Vector3.new(0, 3.5, 0)
						end
						local v30
						if p_u_16.Target.Value and p_u_16.Target.Value:FindFirstChild("HumanoidRootPart") then
							local v31 = p_u_16.Target.Value:FindFirstChild("HumanoidRootPart")
							if p_u_16.Target:GetAttribute("CF") then
								v30 = p_u_16.RootPart.CFrame:Lerp(p_u_16.Target:GetAttribute("CF"), 0.1)
							else
								local v32 = CFrame.new(v_u_18.Position, v31.Position).LookVector
								v30 = p_u_16.RootPart.CFrame:Lerp(CFrame.new(v31.Position - v32 * 9, v31.Position - v32 * 10) + Vector3.new(0, 1, 0), 0.1)
							end
							v_u_20:AdjustWeight(0.01)
							v_u_21:AdjustWeight(0.01)
						else
							v30 = p_u_16.RootPart.CFrame:Lerp((v_u_18.CFrame - v_u_18.Position + v28) * CFrame.Angles(0, 3.141592653589793, 0), 0.1)
							if (v_u_25 - v30.Position).Magnitude > 6 * p27 then
								v_u_20:AdjustWeight(0.01)
								v_u_21:AdjustWeight(2)
								local v33 = p_u_16.RootPart.CFrame:VectorToObjectSpace(v_u_18.Velocity)
								local v34 = CFrame.Angles
								local v35 = v33.X
								local v36 = math.clamp(v35, -5, 5)
								v30 = v30 * v34(0, math.rad(v36), 0)
							else
								v_u_20:AdjustWeight(1)
								v_u_21:AdjustWeight(0.01)
							end
						end
						p_u_16:SetPrimaryPartCFrame(v30)
						v_u_25 = p_u_16.RootPart.Position
					else
						v_u_26:Disconnect()
						v_u_24:Disconnect()
						local v37 = v_u_6.Megumi.Spawn:Clone()
						v37.Position = v_u_25
						v37.Shadow.LockedToPart = true
						v37.Parent = workspace.Effects
						v37.Shadow.Orientation = Enum.ParticleOrientation.FacingCamera
						v37.Shadow.EmissionDirection = Enum.NormalId.Right
						v37.Shadow.Lifetime = NumberRange.new(0.3, 0.6)
						v37.Shadow:Emit(30)
						v_u_3:AddItem(v37, 1)
						v_u_10:PlaySound(v_u_7.Megumi.DivineDog.Despawn, v37, game.SoundService.Effect)
					end
				end)
			end
		end,
		["Slash"] = function(p38, p39)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3
			local v40 = p38:FindFirstChild("RootPart")
			if v40 then
				if p39 < 3 then
					v_u_10:PlaySound(v_u_7.Megumi.DivineDog.Slash, v40, game.SoundService.Effect)
				else
					v_u_10:PlaySound(v_u_7.Megumi.DivineDog.Bite, v40, game.SoundService.Effect)
				end
				task.wait(0.5)
				local v41 = v_u_6.Megumi.DivineAttack:Clone()
				v41.CFrame = v40.CFrame * CFrame.Angles(0, 3.141592653589793, 0) * CFrame.new(0, 0, -6)
				v41.Parent = workspace.Effects
				v_u_3:AddItem(v41, 0.2)
				if p39 == 1 then
					v41.CFrame = v41.CFrame * CFrame.Angles(0, 0, -0.7853981633974483)
					v41.Slash1.Slash:Emit(3)
					v41.Slash2.Slash:Emit(3)
					v41.Slash3.Slash:Emit(3)
					return
				elseif p39 == 2 then
					v41.CFrame = v41.CFrame * CFrame.Angles(0, 0, 0.7853981633974483)
					v41.Slash1.Slash:Emit(3)
					v41.Slash2.Slash:Emit(3)
					v41.Slash3.Slash:Emit(3)
				else
					v41.Bite:Emit(1)
				end
			else
				return
			end
		end,
		["Hit"] = function(p42, p43, p44)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v45 = p43:FindFirstChild("HumanoidRootPart")
			if v45 then
				v_u_10:Flash(p43, Color3.fromRGB(255, 255, 255))
				if p44 < 3 then
					v_u_10:PlaySound(v_u_7.Megumi.DivineDog.SlashHit, v45, game.SoundService.Effect)
				else
					v_u_10:PlaySound(v_u_7.Megumi.DivineDog.BiteHit, v45, game.SoundService.Effect)
				end
				if v_u_4 == p42 or v_u_4.Character == p43 then
					if p44 < 3 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
						return
					end
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Finisher"] = function(p46)
			-- upvalues: (ref) v_u_10
			if p46.HumanoidRootPart then
				v_u_10:Bleed(p46)
			end
		end
	}
	v_u_9.Effects:Connect(function(p48, ...)
		-- upvalues: (copy) v_u_47
		local v49 = v_u_47[p48]
		if v49 then
			v49(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("DivineDogService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11