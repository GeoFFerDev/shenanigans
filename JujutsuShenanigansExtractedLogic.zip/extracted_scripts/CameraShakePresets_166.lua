-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(script.Parent.CameraShakeInstance)
local v_u_12 = {
	["LightHit"] = function()
		-- upvalues: (copy) v_u_1
		local v2 = v_u_1.new(4, 7, 0.1, 0.75)
		v2.PositionInfluence = Vector3.new(0.25, 0.25, 0)
		v2.RotationInfluence = Vector3.new(0, 0, 0)
		return v2
	end,
	["MediumHit"] = function()
		-- upvalues: (copy) v_u_1
		local v3 = v_u_1.new(6, 9.5, 0.1, 0.85)
		v3.PositionInfluence = Vector3.new(0.325, 0.325, 0)
		v3.RotationInfluence = Vector3.new(0, 0, 0)
		return v3
	end,
	["HeavyHit"] = function()
		-- upvalues: (copy) v_u_1
		local v4 = v_u_1.new(8, 14, 0, 1.25)
		v4.PositionInfluence = Vector3.new(0.5, 0.5, 0)
		v4.RotationInfluence = Vector3.new(0, 0, 0)
		return v4
	end,
	["Snap"] = function()
		-- upvalues: (copy) v_u_1
		local v5 = v_u_1.new(8, 25, 0, 0.7)
		v5.PositionInfluence = Vector3.new(0.6, 0.6, 0)
		v5.RotationInfluence = Vector3.new(0, 0, 0)
		return v5
	end,
	["SnapOh"] = function()
		-- upvalues: (copy) v_u_1
		local v6 = v_u_1.new(8, 25, 0, 1.4)
		v6.PositionInfluence = Vector3.new(0.6, 0.6, 0)
		v6.RotationInfluence = Vector3.new(0, 0, 0)
		return v6
	end,
	["LightLoop"] = function()
		-- upvalues: (copy) v_u_1
		local v7 = v_u_1.new(7, 7, 0.04, 0.04)
		v7.PositionInfluence = Vector3.new(0.1, 0.1, 0)
		v7.RotationInfluence = Vector3.new(0, 0, 0)
		return v7
	end,
	["HeavyLoop"] = function()
		-- upvalues: (copy) v_u_1
		local v8 = v_u_1.new(7, 12, 0.03, 0.03)
		v8.PositionInfluence = Vector3.new(0.3, 0.3, 0)
		v8.RotationInfluence = Vector3.new(0, 0, 0)
		return v8
	end,
	["SmallBump"] = function()
		-- upvalues: (copy) v_u_1
		local v9 = v_u_1.new(2.5, 4, 0.1, 0.75)
		v9.PositionInfluence = Vector3.new(0.01, 0.01, 0.01)
		v9.RotationInfluence = Vector3.new(0.25, 0.25, 0.25)
		return v9
	end,
	["QuickBumpSmall"] = function()
		-- upvalues: (copy) v_u_1
		local v10 = v_u_1.new(4, 14, 0, 0.3)
		v10.PositionInfluence = Vector3.new(0.12, 0.18, 0.12)
		v10.RotationInfluence = Vector3.new(1.2, 1.2, 1.2)
		return v10
	end,
	["ViolenterBump"] = function()
		-- upvalues: (copy) v_u_1
		local v11 = v_u_1.new(4.5, 13.5, 0.1, 0.35)
		v11.PositionInfluence = Vector3.new(0.3, 0.3, 0.3)
		v11.RotationInfluence = Vector3.new(1.4, 1.4, 1.4)
		return v11
	end
}
return setmetatable({}, {
	["__index"] = function(_, p13)
		-- upvalues: (copy) v_u_12
		local v14 = v_u_12[p13]
		if type(v14) == "function" then
			return v14()
		end
		error("No preset found with index \"" .. p13 .. "\"")
	end
})