-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("ReplicatedStorage")
local _ = game:GetService("Players").LocalPlayer
local v_u_1 = workspace.CurrentCamera
local v_u_4 = require(script.CameraShaker).new(Enum.RenderPriority.Camera.Value + 10, function(p2)
	-- upvalues: (copy) v_u_1
	local v3 = v_u_1
	v3.CFrame = v3.CFrame * p2
end)
v_u_4:Start()
return function(...)
	-- upvalues: (copy) v_u_4
	if _G.Settings.ScreenShake then
		return v_u_4:Fire(...)
	end
end