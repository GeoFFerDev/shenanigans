-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("TweenService")
local function v_u_16(p2, p3, p4, p5)
	local v6 = p2:GetAttribute(p4 .. "_TweenParams")
	local v7 = {
		{ "TweenStyle", p5 },
		{ "TweenDirection", Enum.EasingDirection.Out }
	}
	local v_u_8 = {}
	if typeof(v6) == "string" then
		local v9 = { v6:match("(%a+),(%a+)") }
		for v10 = 1, 2 do
			local v_u_11 = v9[v10]
			local v12 = v7[v10]
			local v_u_13 = v12[1]
			local v14 = v12[2]
			if v_u_11 then
				if not pcall(function()
					-- upvalues: (copy) v_u_8, (copy) v_u_13, (copy) v_u_11
					v_u_8[v_u_13] = Enum[v_u_13][v_u_11]
				end) then
					v_u_8[v_u_13] = v14
				end
			else
				v_u_8[v_u_13] = v14
			end
		end
	else
		for _, v15 in v7 do
			v_u_8[v15[1]] = v15[2]
		end
	end
	return TweenInfo.new(p3, v_u_8.TweenStyle, v_u_8.TweenDirection)
end
return function(p17, p18, p19, p_u_20, p_u_21)
	-- upvalues: (copy) v_u_1, (copy) v_u_16
	local v22 = p17.Parent:FindFirstChild("End")
	if v22 then
		local v23 = p17:Clone()
		local v24 = p17.Parent
		local v25 = tonumber(v24:GetAttribute("StartTransparency")) or 0
		if v23:IsA("MeshPart") then
			v23.Transparency = v25
		elseif v23:IsA("BasePart") and v23:FindFirstChildOfClass("Decal") then
			v23.Transparency = 1
		end
		v23.Parent = workspace.CurrentCamera
		local v26 = p17.Parent
		local v27 = tonumber(v26:GetAttribute("Duration")) or 0.1
		if v23:FindFirstChildOfClass("Decal") then
			v_u_1:Create(v23, v_u_16(p17.Parent, v27, "Part", Enum.EasingStyle.Cubic), {
				["Size"] = v22.Size,
				["CFrame"] = v22.CFrame
			}):Play()
		else
			v_u_1:Create(v23, v_u_16(p17.Parent, v27, "Part", Enum.EasingStyle.Cubic), {
				["Size"] = v22.Size,
				["CFrame"] = v22.CFrame,
				["Color"] = v22.Color
			}):Play()
			if p18 then
				v_u_1:Create(v23, v_u_16(p17.Parent, v27, "Part", Enum.EasingStyle.Cubic), {
					["Transparency"] = 1
				}):Play()
			else
				v23.Transparency = 0
			end
		end
		local v28 = v23:FindFirstChildOfClass("SpecialMesh")
		local v29 = v22:FindFirstChildOfClass("SpecialMesh")
		if v28 and v29 then
			v_u_1:Create(v28, v_u_16(p17.Parent, v27, "Mesh", Enum.EasingStyle.Sine), {
				["Scale"] = v29.Scale
			}):Play()
		end
		local v_u_30 = v23:FindFirstChildOfClass("Decal")
		local v31 = v22:FindFirstChildOfClass("Decal")
		if v_u_30 and v31 then
			v_u_30.Transparency = v25
			v_u_1:Create(v_u_30, v_u_16(p17.Parent, v27, "Decal", Enum.EasingStyle.Cubic), {
				["Color3"] = v31.Color3
			}):Play()
			if p18 then
				v_u_1:Create(v_u_30, v_u_16(p17.Parent, v27, "Decal", Enum.EasingStyle.Cubic), {
					["Transparency"] = 1
				}):Play()
			else
				p17.Parent:GetAttribute("Duration")
			end
			if p19 then
				task.spawn(function()
					-- upvalues: (copy) p_u_20, (copy) v_u_30, (copy) p_u_21
					for v32 = 1, #p_u_20 do
						v_u_30.Texture = p_u_20[v32]
						task.wait(p_u_21)
					end
				end)
			end
		end
		task.delay(v27, v23.Destroy, v23)
	else
		warn("Goal is not defined.")
	end
end