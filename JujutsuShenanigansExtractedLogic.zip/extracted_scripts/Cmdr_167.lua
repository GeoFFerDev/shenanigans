-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("RunService")
local v2 = require(script.Shared:WaitForChild("Util"))
if v1:IsServer() == false then
	error("Cmdr server module is somehow running on a client!")
end
local v3 = {
	["ReplicatedRoot"] = nil,
	["RemoteFunction"] = nil,
	["RemoteEvent"] = nil,
	["Util"] = v2,
	["DefaultCommandsFolder"] = script.BuiltInCommands
}
local v_u_7 = setmetatable(v3, {
	["__index"] = function(p_u_4, p5)
		local v_u_6 = p_u_4.Registry[p5]
		if v_u_6 and type(v_u_6) == "function" then
			return function(_, ...)
				-- upvalues: (copy) v_u_6, (copy) p_u_4
				return v_u_6(p_u_4.Registry, ...)
			end
		end
	end
})
v_u_7.Registry = require(script.Shared.Registry)(v_u_7)
v_u_7.Dispatcher = require(script.Shared.Dispatcher)(v_u_7)
require(script.Initialize)(v_u_7)
function v_u_7.RemoteFunction.OnServerInvoke(p8, p9, p10)
	-- upvalues: (ref) v_u_7
	return #p9 > 500000 and "Input too long" or v_u_7.Dispatcher:EvaluateAndRun(p9, p8, p10)
end
return v_u_7