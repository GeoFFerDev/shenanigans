-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = v_u_6.Animations
local v_u_8 = v_u_6.Utils
local v_u_9 = v_u_6.Sounds
local v_u_10 = require(v_u_6.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "TwofoldKickController"
})
function v13.KnitStart(_)
	-- upvalues: (copy) v_u_8, (copy) v_u_4, (copy) v_u_3, (ref) v_u_12, (copy) v_u_9, (copy) v_u_10, (copy) v_u_5, (copy) v_u_2, (copy) v_u_7, (copy) v_u_6, (ref) v_u_11
	local v_u_126 = {
		["Swing1"] = function(p14)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_9
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = v_u_8.Gojo.Twofold:Clone()
				v16.CFrame = v15.CFrame * CFrame.new(0, -2, -2) * CFrame.Angles(-0.2617993877991494, 0, 0)
				v16.Transparency = 0.5
				v16.Parent = workspace.Effects
				v16.Swing2.Swing1:Emit(10)
				v_u_4:Create(v16, TweenInfo.new(0.3), {
					["CFrame"] = v16.CFrame + v16.CFrame.UpVector * 3,
					["Size"] = Vector3.new(0, 10, 0)
				}):Play()
				v_u_3:AddItem(v16, 0.4)
				v_u_12:PlaySound(v_u_9.Misc.Swing.Fist3, v15, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p17)
			-- upvalues: (ref) v_u_12, (ref) v_u_9
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				task.wait(0.15)
				v_u_12:PlaySound(v_u_9.Misc.Swing.Fist2, v18, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p19)
			-- upvalues: (ref) v_u_12, (ref) v_u_9
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_12:Flash(p19, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_9.Itadori.Rush.RushBreak, v20, game.SoundService.Effect)
			end
		end,
		["FinalHit"] = function(p21)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_12, (ref) v_u_9
			local v22 = p21:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = v_u_8.Gojo.Twofold.Sparks:Clone()
				v23.Parent = v22.RootAttachment
				v23:Emit(20)
				v_u_3:AddItem(v23, 0.4)
				v_u_12:Flash(p21, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_9.Itadori.DivergentFist.DivergentHit, v22, game.SoundService.Effect)
			end
		end,
		["Domain"] = function(p_u_24)
			-- upvalues: (ref) v_u_10, (ref) v_u_12, (ref) v_u_9, (ref) v_u_4, (ref) v_u_3, (ref) v_u_8, (ref) v_u_5, (ref) v_u_2
			local v_u_25 = p_u_24:FindFirstChild("HumanoidRootPart")
			if v_u_25 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				local v26 = v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.ShortOpen, workspace, game.SoundService.Effect)
				v_u_4:Create(v26, TweenInfo.new(4, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
					["Volume"] = 0
				}):Play()
				v_u_3:AddItem(v26, 4)
				local v_u_27 = v_u_8.Gojo.InfiniteVoid.ShortVoid:Clone()
				v_u_27.BG.CurrentCamera = workspace.CurrentCamera
				v_u_27.Players.CurrentCamera = workspace.CurrentCamera
				v_u_27.Stuff.CurrentCamera = workspace.CurrentCamera
				local v_u_28 = v_u_27.Stuff.Stuff
				v_u_27.Parent = v_u_5.PlayerGui
				v_u_3:AddItem(v_u_27, 3)
				task.spawn(function()
					-- upvalues: (copy) v_u_27, (ref) v_u_4, (copy) v_u_25, (ref) v_u_2, (copy) v_u_28, (ref) v_u_5, (copy) p_u_24
					local v29 = Instance.new("NumberValue", v_u_27)
					v29.Value = 7
					local v30 = v_u_4:Create(v29, TweenInfo.new(0.15, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
						["Value"] = 250
					})
					v30:Play()
					repeat
						local v31 = workspace.CurrentCamera.CFrame
						v_u_27.BG.Create.Size = Vector3.new(1, 1, 1) * v29.Value
						v_u_27.BG.Create.CFrame = v31 - v31.Position + v_u_25.Position
						task.wait()
					until v30.PlaybackState == Enum.PlaybackState.Completed or not v_u_27.Parent
					v_u_27.BG.Skybox:ScaleTo(400)
					v_u_27.BG.Create.Transparency = 1
					local v32 = workspace.CurrentCamera.CFrame.LookVector
					local v33 = v32.X
					local v34 = v32.Z
					local v35 = Vector3.new(v33, 0, v34).Unit
					if v35 ~= v35 then
						v35 = workspace.CurrentCamera.CFrame.LookVector
					end
					local v36 = CFrame.Angles(0, 0, 0)
					local v37 = CFrame.Angles(0, 0, 0)
					v_u_4:Create(v_u_27.BG, TweenInfo.new(0.7, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
						["ImageColor3"] = Color3.new(1, 1, 1)
					}):Play()
					v_u_4:Create(v_u_27.Players, TweenInfo.new(0.7, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
						["Ambient"] = Color3.fromRGB(87, 108, 127),
						["LightColor"] = Color3.fromRGB(170, 255, 255)
					}):Play()
					while true do
						local v38 = v_u_2.RenderStepped:Wait()
						local v39 = CFrame.Angles
						local v40 = v38 * 7
						local v41 = math.rad(v40)
						local v42 = v38 * 5
						local v43 = math.rad(v42)
						local v44 = v38 * 2
						v36 = v36 * v39(v41, v43, (math.rad(v44)))
						local v45 = CFrame.Angles
						local v46 = v38 * 100
						v37 = v37 * v45(0, 0, (math.rad(v46)))
						if not v_u_27.Parent then
							break
						end
						local v47 = workspace.CurrentCamera.CFrame
						local v48 = v47 - v47.Position + v_u_25.Position
						v_u_28:PivotTo(CFrame.lookAlong(v48.Position, v35) * CFrame.new(0, 0, -200))
						v_u_27.BG.Skybox:PivotTo(CFrame.new(v48.Position) * v36)
						if v47.LookVector:Dot(CFrame.lookAt(v47.Position, v_u_25.Position).LookVector) < 0 then
							v_u_27.BG.Close:PivotTo((v47 - v47.Position + v_u_5.Character.Head.Position) * v37)
						else
							v_u_27.BG.Close:PivotTo((v47 - v47.Position + p_u_24.Head.Position) * v37)
						end
						if not v_u_27.Parent then
							return
						end
					end
				end)
				local v_u_49 = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				for _, v_u_50 in v_u_28.Model:GetChildren() do
					local v_u_51 = v_u_50.Size
					v_u_50.Size = Vector3.new(0, 0, 0)
					task.delay(0.55, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_50, (copy) v_u_49, (copy) v_u_51
						v_u_4:Create(v_u_50, v_u_49, {
							["Size"] = v_u_51 * 2.5
						}):Play()
					end)
				end
				v_u_28.Splatter.Size = Vector3.new(0, 0, 0)
				task.delay(0.1, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_28, (copy) v_u_27
					local v52 = TweenInfo.new(0.1)
					v_u_4:Create(v_u_28.Splatter, v52, {
						["Size"] = Vector3.new(250, 250, 0.001)
					}):Play()
					task.wait(0.1)
					local v53 = TweenInfo.new(1.65, Enum.EasingStyle.Circular, Enum.EasingDirection.Out)
					v_u_4:Create(v_u_28.Splatter, v53, {
						["Size"] = Vector3.new(300, 300, 0.001)
					}):Play()
					task.wait(0.65)
					v_u_28.Parent = v_u_27.BG
				end)
				local v54 = TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut)
				for _, v55 in v_u_27.BG.Close:GetChildren() do
					if v55.Name ~= "Core" then
						v_u_4:Create(v55, v54, {
							["Size"] = Vector3.new(200, 200, 1)
						}):Play()
					end
				end
				for _, v56 in workspace.Characters:GetChildren() do
					if v56 == p_u_24 then
						v_u_12:WorldModelChar(p_u_24, v_u_27.Players)
					end
					local v57 = v56:FindFirstChild("HumanoidRootPart")
					if v57 and (v_u_25.Position - v57.Position).Magnitude < 37.5 then
						v_u_12:WorldModelChar(v56, v_u_27.Players)
					end
				end
				task.wait(0.3)
				v_u_27.Fade.Visible = true
				task.wait(0.7)
				v_u_4:Create(v_u_27.Players, TweenInfo.new(1.2), {
					["Ambient"] = Color3.new(1, 1, 1),
					["LightColor"] = Color3.new(1, 1, 1)
				}):Play()
				v_u_4:Create(v_u_27.Fade, TweenInfo.new(2, Enum.EasingStyle.Cubic, Enum.EasingDirection.InOut), {
					["ImageTransparency"] = 1
				}):Play()
				task.wait(1)
				v_u_4:Create(v_u_27.Players, TweenInfo.new(0.2), {
					["ImageTransparency"] = 1
				}):Play()
			end
		end,
		["DomainWind"] = function(p58)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7, (ref) v_u_4
			local v59 = p58:FindFirstChild("HumanoidRootPart")
			if v59 then
				v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.ShortDomain, v59, game.SoundService.Voice)
				v_u_12:DomainBurst(v59)
				local v60 = v_u_5.Character
				if v60 and v60:FindFirstChild("HumanoidRootPart") then
					local v61 = v60:FindFirstChild("HumanoidRootPart")
					if (v59.Position - v61.Position).Magnitude <= 37.5 then
						v_u_12:Domain(p58, function(p62, p63)
							-- upvalues: (ref) v_u_7, (ref) v_u_4
							p63.Humanoid:LoadAnimation(v_u_7.Gojo.DomainWarn2):Play(0)
							p62.Panel.ImageLabel.Image = "rbxassetid://6938945464"
							p62.Panel.ImageLabel.Size = UDim2.new(0.8, 0, 0.4, 0)
							local v64 = p62.Panel.Camera
							v64.CFrame = v64.CFrame * CFrame.new(0, 0.5, 0)
							p62.Panel.Camera.FieldOfView = 30
							v_u_4:Create(p62.Panel.ImageLabel, TweenInfo.new(1.5), {
								["ImageColor3"] = Color3.new(0.1, 0.1, 0.1)
							}):Play()
							v_u_4:Create(p62.Panel.Viewport, TweenInfo.new(1.5), {
								["Ambient"] = Color3.fromRGB(87, 108, 127),
								["LightColor"] = Color3.fromRGB(170, 255, 255)
							}):Play()
						end)
					end
				end
			end
		end,
		["Music"] = function(p65)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_12, (ref) v_u_9, (ref) v_u_4
			local v_u_66 = p65:FindFirstChild("HumanoidRootPart")
			if v_u_66 then
				local v_u_67 = v_u_8.Gojo.InfiniteVoid.FlashDomain:Clone()
				v_u_67.CFrame = v_u_66.CFrame
				v_u_67.Parent = workspace.Effects
				v_u_3:AddItem(v_u_67, 3)
				v_u_67.Surround:Emit(100)
				task.delay(0.8, function()
					-- upvalues: (copy) v_u_67
					v_u_67.Space:Emit(60)
				end)
				task.delay(1.5, function()
					-- upvalues: (ref) v_u_12, (ref) v_u_9, (copy) v_u_66
					v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.Startup, v_u_66, game.SoundService.Effect)
					task.wait(1)
					v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.ShortDomain2, v_u_66, game.SoundService.Voice)
				end)
				local v68 = v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.Music, v_u_66, game.SoundService.Music)
				local v69 = Instance.new("PitchShiftSoundEffect", v68)
				v69.Octave = 5
				v68.PlaybackSpeed = 0.2
				local v70 = TweenInfo.new(3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				v_u_4:Create(v68, v70, {
					["PlaybackSpeed"] = 1.25
				}):Play()
				v_u_4:Create(v69, v70, {
					["Octave"] = 0.8
				}):Play()
			end
		end,
		["Boost"] = function(p71, p_u_72, p73)
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_4, (ref) v_u_8, (ref) v_u_3, (ref) v_u_12, (ref) v_u_9
			local v74 = p71:FindFirstChild("HumanoidRootPart")
			if v74 then
				if v_u_5.Character == p71 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
					if p73 == 90 then
						game.Lighting.ExposureCompensation = 1
						v_u_4:Create(game.Lighting, TweenInfo.new(0.2), {
							["ExposureCompensation"] = 0
						}):Play()
					end
					local v_u_75 = v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.LightHit)
					v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["FieldOfView"] = p73
					}):Play()
					task.spawn(function()
						-- upvalues: (copy) p_u_72, (ref) v_u_4, (copy) v_u_75
						repeat
							task.wait()
						until not p_u_72:IsDescendantOf(workspace.Characters)
						v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
							["FieldOfView"] = 70
						}):Play()
						v_u_75:StartFadeOut(1)
					end)
				end
				local v76 = v_u_8.Choso.CounterSwing.Shock:Clone()
				v76.Size = Vector3.new(6, 30, 6)
				v76.CFrame = v74.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v76.Parent = workspace.Effects
				v_u_3:AddItem(v76, 0.2)
				v_u_4:Create(v76, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = v76.Position + v74.CFrame.LookVector * 10
				}):Play()
				if p73 == 90 then
					v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.Boost1, v74, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.Boost2, v74, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Trail"] = function(p77, p78, _)
			-- upvalues: (ref) v_u_6, (ref) v_u_3
			if p77:FindFirstChild("HumanoidRootPart") then
				local v79 = v_u_6.Utils.Gojo.HandTrail:Clone()
				v79.Parent = workspace.Effects
				v79.Trail.FaceCamera = true
				v79.Weld.Part0 = p77["Right Leg"]
				v_u_3:AddItem(v79, 10)
				local v80 = v_u_6.Utils.Gojo.HandTrail:Clone()
				v80.Parent = workspace.Effects
				v80.Trail.Color = ColorSequence.new(p77["Left Arm"].Color)
				v80.Weld.Part0 = p77["Left Arm"]
				v_u_3:AddItem(v80, 10)
				local v81 = v_u_6.Utils.Gojo.HandTrail:Clone()
				v81.Parent = workspace.Effects
				v81.Trail.Color = ColorSequence.new(p77["Right Arm"].Color)
				local v82 = v81.Weld
				v82.C1 = v82.C1 * CFrame.Angles(0, 3.141592653589793, 0)
				v81.Weld.Part0 = p77["Right Arm"]
				v_u_3:AddItem(v81, 10)
				local v83 = v_u_6.Utils.Gojo.HandTrail:Clone()
				v83.Parent = workspace.Effects
				v83.Trail.FaceCamera = true
				local v84 = v83.Weld
				v84.C1 = v84.C1 * CFrame.Angles(0, 3.141592653589793, 0)
				v83.Weld.Part0 = p77["Right Leg"]
				v_u_3:AddItem(v83, 10)
				repeat
					task.wait()
				until not (p77.Parent and p78.Parent)
				v79.Trail.Enabled = false
				v_u_3:AddItem(v79, 0.5)
				v80.Trail.Enabled = false
				v_u_3:AddItem(v80, 0.5)
				v81.Trail.Enabled = false
				v_u_3:AddItem(v81, 0.5)
				v83.Trail.Enabled = false
				v_u_3:AddItem(v83, 0.5)
			end
		end,
		["Smear"] = function(p_u_85, p_u_86)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_10, (ref) v_u_4, (ref) v_u_7, (ref) v_u_12, (ref) v_u_9, (ref) v_u_2, (ref) v_u_8
			local v87 = p_u_85:FindFirstChild("HumanoidRootPart")
			if not v87 then
				return
			end
			local v88 = v_u_6.Utils.Gojo.InfiniteVoid.Speed:Clone()
			v88.CFrame = v87.CFrame
			v88.Parent = workspace.Effects
			v_u_3:AddItem(v88, 3)
			local v_u_89 = v_u_6.Utils.Itadori.EyeTrails:Clone()
			v_u_89.Trail1.Trail.Color = ColorSequence.new(Color3.fromRGB(85, 170, 255))
			v_u_89.Trail2.Trail.Color = ColorSequence.new(Color3.fromRGB(85, 170, 255))
			v_u_89.Eye1.Glow:Destroy()
			v_u_89.Eye2.Glow:Destroy()
			v_u_89.Weld.Part0 = p_u_85.Head
			v_u_89.Parent = workspace.Effects
			v_u_89.Glow:Emit(1)
			v_u_3:AddItem(v_u_89, 3)
			task.delay(2.5, function()
				-- upvalues: (copy) v_u_89
				v_u_89.Trail1.Trail.Enabled = false
				v_u_89.Trail2.Trail.Enabled = false
			end)
			if v_u_5.Character == p_u_85 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
				local v_u_90 = v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.Snap)
				v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["FieldOfView"] = 120
				}):Play()
				task.spawn(function()
					-- upvalues: (copy) p_u_85, (copy) p_u_86, (ref) v_u_4, (copy) v_u_90, (ref) v_u_10
					repeat
						task.wait()
					until not (p_u_85.Parent and p_u_86.Parent)
					v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["FieldOfView"] = 70
					}):Play()
					v_u_90:StartFadeOut(0.2)
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
					game.Lighting.ExposureCompensation = 2
					v_u_4:Create(game.Lighting, TweenInfo.new(0.4), {
						["ExposureCompensation"] = 0
					}):Play()
				end)
			end
			local v91 = tick()
			local v92 = p_u_85.Humanoid:LoadAnimation(v_u_7.Mahito.WideStrike)
			v92:Play(0, 5, 1)
			v92.TimePosition = 7
			v92.Priority = Enum.AnimationPriority.Action4
			v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.Barrage, v87, game.SoundService.Effect)
			while true do
				v88.CFrame = v87.CFrame
				if tick() > v91 + 0.05 then
					v_u_12:DustBreak(v87.Position, Vector3.new(0, 1, 0), 20, 1, 0.5, 1, 4)
					v91 = tick()
				end
				v_u_2.RenderStepped:Wait()
				if not (p_u_85.Parent and p_u_86.Parent) then
					v92:Stop(0)
					for _, v93 in v88:GetDescendants() do
						if v93:IsA("ParticleEmitter") or v93:IsA("PointLight") then
							v93.Enabled = false
						end
					end
					local v94 = v_u_8.Misc.M.WingFly:Clone()
					v94:PivotTo(v88.CFrame)
					v94.Parent = workspace.Effects
					v_u_3:AddItem(v94, 3)
					v94.WHAT:Destroy()
					v_u_4:Create(v94.Mesh.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = v94.Mesh.End.Size,
						["Transparency"] = 1,
						["CFrame"] = v94.Mesh.End.CFrame
					}):Play()
					v_u_4:Create(v94.Mesh2.Start, TweenInfo.new(2, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = v94.Mesh2.End.Size,
						["Transparency"] = 1,
						["CFrame"] = v94.Mesh2.End.CFrame
					}):Play()
					v_u_4:Create(v94.Mesh3.Start, TweenInfo.new(2.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = v94.Mesh3.End.Size,
						["Transparency"] = 1,
						["CFrame"] = v94.Mesh3.End.CFrame
					}):Play()
					v94.Mesh.End:Destroy()
					v94.Mesh2.End:Destroy()
					v94.Mesh3.End:Destroy()
					return
				end
			end
		end,
		["SpeedHit"] = function(p95, p96, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
			if p95:FindFirstChild("HumanoidRootPart") then
				local v97 = p96:FindFirstChild("HumanoidRootPart")
				if v97 then
					v_u_12:Flash(p96, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.Hits["Hit" .. math.random(1, 3)], v97, game.SoundService.Effect)
					local v98 = v_u_8.Choso.CounterSwing:Clone()
					v98:PivotTo(v97.CFrame * CFrame.Angles(math.random(0, 3.141592653589793), math.random(0, 3.141592653589793), math.random(0, 3.141592653589793)))
					v98.Parent = workspace.Effects
					v_u_3:AddItem(v98, 0.2)
					v_u_4:Create(v98.Shock, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(0, 25, 0),
						["Transparency"] = 1
					}):Play()
					v_u_4:Create(v98.Shock2, TweenInfo.new(0.1), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1,
						["Position"] = v98.Shock2.Position + v98.Shock2.CFrame.LookVector * 3
					}):Play()
					v_u_4:Create(v98.Shockwave, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(0, 30, 0),
						["Transparency"] = 1,
						["CFrame"] = v98.Shockwave.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
					}):Play()
				end
			else
				return
			end
		end,
		["Slow"] = function(p99, p100, p101)
			-- upvalues: (ref) v_u_12, (ref) v_u_9
			local v102 = p99:FindFirstChild("HumanoidRootPart")
			if v102 then
				if not p100 then
					v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.ShortDomain3, v102, game.SoundService.Effect)
				end
				if p101 then
					v_u_12:PlaySound(v_u_9.Nanami.Sharpen.Basic, v102, game.SoundService.Effect)
				end
				v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.Slowdown, v102, game.SoundService.Effect)
				v_u_12:DustTrail(p99, 1)
				for _ = 1, 10 do
					v_u_12:DustBreak(v102.Position, Vector3.new(0, 1, 0), 3, 2, 0.4, 1, 4)
					task.wait(0.05)
				end
			end
		end,
		["SpeedFinish"] = function(p103)
			-- upvalues: (ref) v_u_12
			if p103.HumanoidRootPart then
				v_u_12:Bleed(p103)
			end
		end,
		["Cut"] = function(p_u_104, p_u_105)
			-- upvalues: (ref) v_u_8, (ref) v_u_5, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_9, (ref) v_u_2
			local v_u_106 = p_u_104.HumanoidRootPart
			if v_u_106 then
				local v_u_107 = p_u_104.SetAssets:FindFirstChild("GojoMask")
				if v_u_107 then
					local v_u_108 = Instance.new("Attachment", v_u_107)
					v_u_108.Position = Vector3.new(0, 0, 0.5)
					v_u_8.Gojo.InfiniteVoid.Glow:Clone().Parent = v_u_108
					v_u_8.Gojo.InfiniteVoid.Speed.PointLight:Clone().Parent = v_u_108
					v_u_107.Eye1.Glow.ZOffset = 0.1
					v_u_107.Eye2.Glow.ZOffset = 0.1
					task.delay(7, function()
						-- upvalues: (copy) v_u_107, (copy) v_u_108
						v_u_107.Eye1.Glow.ZOffset = 0.5
						v_u_107.Eye2.Glow.ZOffset = 0.5
						v_u_108:Destroy()
					end)
				end
				local v109 = v_u_8.Gojo.InfiniteVoid.Fade:Clone()
				v109.Parent = v_u_5.PlayerGui
				task.wait(1)
				v_u_4:Create(v109.Frame, TweenInfo.new(1), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_3:AddItem(v109, 1)
				local v110 = v_u_8.Misc.M.WingFly:Clone()
				v110:PivotTo(v_u_106.CFrame)
				v110.Parent = workspace.Effects
				v_u_3:AddItem(v110, 3)
				v110.WHAT:Destroy()
				v_u_4:Create(v110.Mesh.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = v110.Mesh.End.Size,
					["Transparency"] = 1,
					["CFrame"] = v110.Mesh.End.CFrame
				}):Play()
				v_u_4:Create(v110.Mesh2.Start, TweenInfo.new(2, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = v110.Mesh2.End.Size,
					["Transparency"] = 1,
					["CFrame"] = v110.Mesh2.End.CFrame
				}):Play()
				v_u_4:Create(v110.Mesh3.Start, TweenInfo.new(2.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = v110.Mesh3.End.Size,
					["Transparency"] = 1,
					["CFrame"] = v110.Mesh3.End.CFrame
				}):Play()
				v110.Mesh.End:Destroy()
				v110.Mesh2.End:Destroy()
				v110.Mesh3.End:Destroy()
				v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.Breathe, v_u_106, game.SoundService.Voice)
				task.delay(0.6, function()
					-- upvalues: (copy) p_u_104, (ref) v_u_8, (ref) v_u_3
					local v111 = p_u_104.Head
					local v112 = v_u_8.Gojo.InfiniteVoid.Puddle.Breath:Clone()
					v112.Parent = v111
					v_u_3:AddItem(v112, 8)
					for _ = 1, 6 do
						v112.Breath:Emit(2)
						v112.BreathL:Emit(3)
						v112.BreathR:Emit(3)
						task.wait(1.05)
					end
				end)
				local v_u_113 = workspace.CurrentCamera
				local v_u_114 = 0
				local v_u_115 = nil
				tick()
				local v_u_116 = v_u_8.Gojo.InfiniteVoid.Cutscene
				v_u_115 = v_u_2.RenderStepped:Connect(function(p117)
					-- upvalues: (ref) v_u_114, (copy) v_u_116, (copy) p_u_104, (copy) v_u_106, (copy) p_u_105, (copy) v_u_113, (ref) v_u_115, (ref) v_u_5, (ref) v_u_4
					v_u_114 = v_u_114 + p117 * 60
					local v118 = v_u_116.Frames
					local v119 = v_u_114
					local v120 = math.ceil(v119)
					local v121 = v118:FindFirstChild((tonumber(v120)))
					local v122 = v_u_116.FOV
					local v123 = v_u_114
					local v124 = math.ceil(v123)
					local v125 = v122:FindFirstChild((tonumber(v124)))
					if v121 and (v125 and (p_u_104.Parent and (v_u_106.Parent and p_u_105.Parent))) then
						v_u_113.CFrame = v_u_106.CFrame * v121.Value
						v_u_113.FieldOfView = v125.Value
						v_u_113.CameraType = Enum.CameraType.Scriptable
					else
						v_u_115:Disconnect()
						v_u_113.CameraType = Enum.CameraType.Custom
						v_u_113.FieldOfView = 70
						v_u_113.CameraSubject = (v_u_5.Character or v_u_5.CharacterAdded:Wait()):WaitForChild("Humanoid")
						game.Lighting.ExposureCompensation = 1
						v_u_4:Create(game.Lighting, TweenInfo.new(0.2), {
							["ExposureCompensation"] = 0
						}):Play()
					end
				end)
			end
		end
	}
	v_u_11.Effects:Connect(function(p127, ...)
		-- upvalues: (copy) v_u_126
		local v128 = v_u_126[p127]
		if v128 then
			v128(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("TwofoldKickService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13