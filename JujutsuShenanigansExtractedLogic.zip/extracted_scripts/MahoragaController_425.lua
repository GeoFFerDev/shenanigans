-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "MahoragaController"
})
local v_u_13 = {
	{ "7485051715", Color3.fromRGB(255, 0, 0) },
	{ "7461510428", Color3.fromRGB(0, 255, 0) },
	{ "2698713530", Color3.fromRGB(0, 0, 255) }
}
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_13, (ref) v_u_9, (ref) v_u_10
	local v_u_59 = {
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_11:Flash(p14, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.M1:FindFirstChild("Hit" .. p15), v16, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p17, p18)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = p18:FindFirstChild("HumanoidRootPart")
				if v20 then
					v_u_11:Flash(p18, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit3"), v20, game.SoundService.Effect)
					local v21 = v_u_6.ChaseHit:Clone()
					local v22 = CFrame.new
					local v23 = v20.Position
					local v24 = v19.Position.X
					local v25 = v20.Position.Y
					local v26 = v19.Position.Z
					v21.CFrame = v22(v23, (Vector3.new(v24, v25, v26))) * CFrame.Angles(0, 3.141592653589793, 0)
					v21.Parent = workspace.Effects
					v21.Ring:Emit(7)
					v21.Sparks:Emit(12)
					v_u_2:AddItem(v21, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p27)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v28 = p27.HumanoidRootPart
			if v28 then
				local v29 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v29.CFrame = v28.CFrame * CFrame.new(0, 1, -4)
				v29.Size = Vector3.new(0, 0, 2)
				v29.Parent = workspace.Effects
				v_u_3:Create(v29, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v29, 0.3)
				v_u_11:PlaySound(v_u_7.Misc.Chase, v28, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p30)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				v_u_11:PlaySound(v_u_7.Misc.Swing.Fist, v31, game.SoundService.Effect)
			end
		end,
		["Launch"] = function(p32, p33)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v34 = p32:FindFirstChild("HumanoidRootPart")
			if v34 then
				local v35 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v35.CFrame = CFrame.new(v34.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v35.Size = Vector3.new(0, 0, 5)
				v35.Parent = workspace.Effects
				v_u_3:Create(v35, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v35.Position + Vector3.new(0, p33, 0)
				}):Play()
				v_u_2:AddItem(v35, 0.3)
				if p33 < 0 then
					v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v34, game.SoundService.Effect)
					v_u_11:DustBreak(v34.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_4:DistanceFromCharacter(v34.Position) < 20 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					end
				end
			end
		end,
		["Wheel"] = function(p36)
			-- upvalues: (ref) v_u_3
			for _, v37 in p36:GetDescendants() do
				if v37:IsA("ImageLabel") then
					p36.UIScale.Scale = _G.Settings.UIS
					v_u_3:Create(v37, TweenInfo.new(1), {
						["ImageTransparency"] = 0
					}):Play()
				end
			end
		end,
		["Wheel2"] = function(p38)
			-- upvalues: (ref) v_u_4, (ref) v_u_13
			local v39 = v_u_4.PlayerGui:FindFirstChild("Adaptation").Adaptation
			if v39 then
				v39.Type.Image = "rbxassetid://" .. v_u_13[p38][1]
				v39.Type.ImageColor3 = v_u_13[p38][2]
			end
		end,
		["Wheel3"] = function(p40, p41)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_3, (ref) v_u_13, (ref) v_u_4
			local v42 = p40:FindFirstChild("HumanoidRootPart")
			if v42 then
				local v43 = p40:FindFirstChild("Outfit")
				if v43 then
					v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Adapt, v42, game.SoundService.Effect)
					local v44 = v43.Head.DivineWheelWeld
					v44.C1 = CFrame.new() * CFrame.Angles(0, -90, 0)
					v_u_3:Create(v44, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
						["C1"] = CFrame.new()
					}):Play()
					local v45 = v43.Head.DivineWheel
					v45.Color = v_u_13[p41][2]
					v_u_3:Create(v45, TweenInfo.new(0.4), {
						["Color"] = Color3.fromRGB(188, 155, 93)
					}):Play()
				end
				if v_u_4.Character == p40 then
					local v46 = v_u_4.PlayerGui:FindFirstChild("Adaptation").Adaptation
					if not v46 then
						return
					end
					v46.WheelBG.ImageColor3 = v_u_13[p41][2]
					v46.Wheel.Rotation = -90
					v46.WheelBG.Rotation = -90
					v_u_3:Create(v46.Wheel, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
						["Rotation"] = 0
					}):Play()
					v_u_3:Create(v46.WheelBG, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
						["Rotation"] = 0
					}):Play()
				end
			end
		end,
		["ParryStart"] = function(p47)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v48 = p47:FindFirstChild("HumanoidRootPart")
			if v48 then
				v_u_11:PlaySound(v_u_7.Misc.Swing.Fist2, v48, game.SoundService.Effect)
			end
		end,
		["Parry"] = function(p49, p50)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_7, (ref) v_u_11, (ref) v_u_4, (ref) v_u_8
			local v51 = p49:FindFirstChild("HumanoidRootPart")
			if v51 then
				local v52 = v_u_6.Megumi.Mahoraga.Parry:Clone()
				v52.Position = v51.Position
				v52.Highlight.Position = v51.Position
				v52.Parent = workspace.Effects
				v52.Attachment.Ring:Emit(3)
				v52.Attachment.Star:Emit(1)
				v52.Attachment.Sparks:Emit(10)
				v_u_2:AddItem(v52, 0.4)
				v_u_7.Megumi.Mahoraga.Parry.Pitch = math.random(80, 120) / 100
				v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Parry, v51, game.SoundService.Effect)
				if v_u_4.Character == p49 or v_u_4.Character == p50 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Parry2"] = function(p53, p54)
			-- upvalues: (ref) v_u_3, (ref) v_u_2, (ref) v_u_6, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v55 = p53:FindFirstChild("HumanoidRootPart")
			if v55 then
				local v56 = Instance.new("Highlight", p53)
				v56.FillTransparency = 0
				v56.DepthMode = Enum.HighlightDepthMode.Occluded
				v56.OutlineColor = Color3.fromRGB(255, 255, 255)
				v56.FillColor = Color3.fromRGB(255, 0, 0)
				v_u_3:Create(v56, TweenInfo.new(0.4), {
					["FillTransparency"] = 1,
					["OutlineTransparency"] = 1
				}):Play()
				v_u_2:AddItem(v56, 0.4)
				local v57 = v_u_6.Megumi.Mahoraga.Parry:Clone()
				v57.CFrame = v55.CFrame * CFrame.new(0, -1, -2)
				v57.Parent = workspace.Effects
				local v58 = Instance.new("Highlight", v57)
				v58.FillTransparency = 1
				v58.OutlineTransparency = 1
				v_u_2:AddItem(v58, 0.1)
				v_u_3:Create(v57, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(40, 40, 40),
					["Transparency"] = 1
				}):Play()
				v57.Scream.Dust:Emit(10)
				v57.Scream.Ring:Emit(10)
				v57.Scream.Sparks:Emit(15)
				v_u_2:AddItem(v57, 1)
				v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Parry2, v55, game.SoundService.Effect)
				if v_u_4.Character == p53 or v_u_4.Character == p54 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p60, ...)
		-- upvalues: (copy) v_u_59
		local v61 = v_u_59[p60]
		if v61 then
			v61(...)
		end
	end)
	v_u_9.Hitbox:Connect(function(p62, p63, p64)
		-- upvalues: (ref) v_u_10, (ref) v_u_3
		local v65 = p63.HumanoidRootPart
		if not v65 then
			return
		end
		local v66 = nil
		while true do
			local v67 = v_u_10:SphereHitbox(p63, CFrame.new(0, 0, -6), 12)
			for _, v68 in v67 do
				local v69 = v68:FindFirstChild("Info")
				if v69 then
					local v70 = v69:FindFirstChild("Knockback")
					if not v70 or v70.Value ~= false then
						v66 = v67
						break
					end
				end
			end
			if v66 then
				local v71 = p62:FindFirstChildWhichIsA("NumberValue")
				if v71 then
					v_u_3:Create(v71, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p62.Parent then
				break
			end
		end
		p64:FireServer(v66, v65.CFrame)
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("MahoragaService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12