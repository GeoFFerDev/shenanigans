-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("TweenService")
local v2 = {}
local v_u_3 = Random.new()
local v_u_4 = Instance.new("Part")
v_u_4.TopSurface = 0
v_u_4.BottomSurface = 0
v_u_4.Anchored = true
v_u_4.CanCollide = false
v_u_4.Locked = true
v_u_4.CastShadow = false
v_u_4.Name = "BoltPart"
v_u_4.Material = Enum.Material.Neon
v_u_4.Color = Color3.new(1, 1, 1)
v_u_4.Transparency = 0
local v_u_5 = nil
function v2.CreateBolt(p6)
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (ref) v_u_5
	local v7 = p6.Position1
	local v8 = p6.Position2
	if not (v7 and v8) then
		error("Missing positions data")
	end
	local v9 = p6.PartCount or 10
	local v10 = p6.CurveCenter or (v7 + v8) / 2
	local v11 = p6.MinRadius or 1
	local v12 = p6.MaxRadius or 2
	local v13 = p6.PartPool or {}
	local v14 = p6.Color or Color3.new(1, 1, 1)
	local v15 = p6.Parent or workspace
	local v_u_16 = p6.Thickness or 0.2
	local v17 = type(v_u_16) == "number" and function()
		-- upvalues: (copy) v_u_16
		return v_u_16
	end or v_u_16
	local v18 = {}
	for v19 = 0, v9 do
		local v20 = v19 ~= 0 and v19 ~= v9
		local v21 = v19 / v9
		local v22 = v7:Lerp(v10, v21):Lerp(v10:Lerp(v8, v21), v21)
		if v20 then
			v22 = v22 + v_u_3:NextUnitVector() * v_u_3:NextNumber(v11, v12)
		end
		v18[v19] = v22
	end
	local v23 = {}
	for v24 = 0, v9 - 1 do
		local v25 = table.remove(v13, 1) or v_u_4:Clone()
		if v14 then
			v25.Color = v14
		end
		local v26 = v18[v24]
		local v27 = v18[v24 + 1]
		local v28 = (v26 - v27).Magnitude
		local v29 = v17(v24 / v9)
		v25.Size = Vector3.new(v29, v29, v28)
		v25.Parent = v15
		local v30 = CFrame.lookAt((v26 + v27) / 2, v27)
		if v_u_5 then
			local v31 = v_u_5[1]
			table.insert(v31, v25)
			local v32 = v_u_5[2]
			table.insert(v32, v30)
		else
			v_u_5 = {
				{ v25 },
				{ v30 }
			}
			task.defer(function()
				-- upvalues: (ref) v_u_5
				workspace:BulkMoveTo(v_u_5[1], v_u_5[2], Enum.BulkMoveMode.FireCFrameChanged)
				v_u_5 = nil
			end)
		end
		table.insert(v23, v25)
	end
	return v23
end
function v2.ThicknessFade(p_u_33, p_u_34, p35, p36)
	-- upvalues: (copy) v_u_1
	local v_u_37 = p35 or Enum.EasingStyle.Linear
	local v_u_38 = p36 or Enum.EasingDirection.Out
	return function(p39)
		-- upvalues: (copy) p_u_34, (copy) p_u_33, (ref) v_u_1, (ref) v_u_37, (ref) v_u_38
		local v40 = p_u_34 - p_u_33
		return p_u_33 + v_u_1:GetValue(1 - p39, v_u_37, v_u_38) * v40
	end
end
return v2