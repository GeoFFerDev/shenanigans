-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("UserInputService")
local v1 = game:GetService("TweenService")
local v_u_2 = script.Parent.Remote.Value
local v3 = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
v1:Create(script.Parent.TextBox, v3, {
	["Position"] = UDim2.new(0.5, 0, 0.5, 0),
	["BackgroundTransparency"] = 0.5,
	["TextTransparency"] = 0
}):Play()
v1:Create(script.Parent.TextBox.UIStroke, v3, {
	["Transparency"] = 0
}):Play()
v1:Create(script.Parent.TextBox.TextButton, v3, {
	["BackgroundTransparency"] = 0.5,
	["TextTransparency"] = 0
}):Play()
v1:Create(script.Parent.TextBox.TextButton.UIStroke, v3, {
	["Transparency"] = 0
}):Play()
v1:Create(script.Parent.TextBox.ReportButton, v3, {
	["BackgroundTransparency"] = 0.5,
	["TextTransparency"] = 0
}):Play()
v1:Create(script.Parent.TextBox.ReportButton.UIStroke, v3, {
	["Transparency"] = 0
}):Play()
v1:Create(script.Parent.TextBox.Warnng, v3, {
	["TextTransparency"] = 0
}):Play()
script.Parent.TextBox.FocusLost:Connect(function(p4)
	-- upvalues: (copy) v_u_2
	if p4 then
		v_u_2:FireServer(script.Parent.Promptobj.Value, script.Parent.TextBox.Text)
		script.Parent:Destroy()
	end
end)
script.Parent.TextBox.TextButton.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_2
	v_u_2:FireServer(script.Parent.Promptobj.Value, script.Parent.TextBox.Text)
	script.Parent:Destroy()
end)
script.Parent.TextBox.ReportButton.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_2
	v_u_2:FireServer(script.Parent.Promptobj.Value, "Report")
	script.Parent:Destroy()
end)