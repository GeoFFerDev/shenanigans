-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "CursoryImpactController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_59 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_7.Naoya.Cursory.Swing, v13, game.SoundService.Effect)
				v_u_10:ArmFlash(p12["Right Arm"], Color3.fromRGB(128, 126, 255), 0.65)
			end
		end,
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_10:Flash(p15, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Naoya.Cursory.Hit, v16, game.SoundService.Effect)
				local v17 = v_u_6.Megumi.Mahoraga.WorldSlash.mesh:Clone()
				v17.Position = v16.Position - Vector3.new(0, 2, 0)
				v17.Decal.Transparency = 0
				v17.Mesh.Scale = Vector3.new(2, -5, 2)
				v17.Decal.Transparency = 0.8
				v17.Parent = workspace.Effects
				v_u_3:Create(v17, TweenInfo.new(0.9, Enum.EasingStyle.Exponential), {
					["CFrame"] = v17.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
				}):Play()
				v_u_3:Create(v17.Mesh, TweenInfo.new(0.9, Enum.EasingStyle.Exponential), {
					["Scale"] = Vector3.new(15, 25, 15)
				}):Play()
				v_u_3:Create(v17.Decal, TweenInfo.new(0.9, Enum.EasingStyle.Exponential), {
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v17, 0.9)
				if v_u_4.Character == p15 or v_u_4 == p14 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				for _ = 1, 3 do
					local v18 = math.random(300, 500) / 10
					local v19 = v_u_6.Gojo.LapseBlue.Throw:Clone()
					v19.Transparency = 0.7
					v19.Position = p15.Head.Position
					local v20 = math.random(-180, 180)
					local v21 = math.random(-180, 180)
					local v22 = math.random
					v19.Orientation = Vector3.new(v20, v21, v22(-180, 180))
					v19.Size = Vector3.new(0, 0, 7)
					v19.Parent = workspace.Effects
					v_u_3:Create(v19, TweenInfo.new(0.15, Enum.EasingStyle.Quad), {
						["Size"] = Vector3.new(v18, v18, 0),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v19, 0.15)
					task.wait(0.025)
				end
			end
		end,
		["UhOh"] = function(p23)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				v_u_10:PlaySound(v_u_7.Naoya.Cursory.Kick, v24, game.SoundService.Effect)
				task.wait(0.2)
				v_u_10:ArmFlash(p23["Right Leg"], Color3.fromRGB(128, 126, 255), 0.65)
			end
		end,
		["Grab"] = function(p25)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v26 = p25:FindFirstChild("HumanoidRootPart")
			if v26 then
				v_u_10:Flash(p25, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v26, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Naoya.Cursory.Grab, v26, game.SoundService.Effect)
				if v_u_4.Character == p25 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Hit2"] = function(p27, p28)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v30.Position = v29.Position
				v30.Parent = workspace.Effects
				v_u_2:AddItem(v30, 1)
				v30.Sparks.Color = ColorSequence.new(Color3.new(0.666667, 0.666667, 1))
				v30.Wind.Color = v30.Sparks.Color
				v30.Wind2.Color = v30.Sparks.Color
				v30.Sparks:Emit(50)
				v30.Wind:Emit(7)
				v30.Wind2:Emit(7)
				v_u_10:Flash(p28, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Naoya.Cursory.KickHit, v29, game.SoundService.Effect)
				if v_u_4.Character == p28 or v_u_4 == p27 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Throw"] = function(p31)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v32 = p31.HumanoidRootPart
			if v32 then
				local v33 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v33.CFrame = v32.CFrame * CFrame.new(2, 1, -5)
				v33.Parent = workspace.Effects
				v33.PointLight:Destroy()
				v33.Wind:Emit(20)
				v_u_2:AddItem(v33, 3)
				local v34 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v34.Size = Vector3.new(6, 30, 6)
				v34.CFrame = v32.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v34.Parent = workspace.Effects
				v_u_2:AddItem(v34, 0.2)
				v_u_3:Create(v34, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = v34.Position + v32.CFrame.LookVector * 10
				}):Play()
				v_u_10:PlaySound(v_u_7.Todo.BruteForce.Swing, v32, game.SoundService.Effect)
				if v_u_4.Character == p31 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Zwoosh"] = function(p35, _)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v36 = p35:FindFirstChild("HumanoidRootPart")
			if v36 then
				local v37 = TweenInfo.new(1.2)
				v_u_10:PlaySound(v_u_7.Naoya.Decisive.Startup, v36, game.SoundService.Effect)
				local v38 = v_u_6.Damage.HitGlow:Clone()
				v_u_2:AddItem(v38, 1.2)
				v38.Parent = workspace.Effects
				for _, v39 in v38:GetChildren() do
					v39.Color = Color3.fromRGB(128, 126, 255)
					v39.Anchored = true
					v39.CFrame = p35[v39.Name].CFrame
					v_u_3:Create(v39, v37, {
						["Transparency"] = 1,
						["Position"] = v39.Position
					}):Play()
				end
				local v40 = v_u_6.Naoya.Teleport:Clone()
				v40.CFrame = v36.CFrame
				v40.Parent = workspace.Effects
				v40.Lines:Emit(8)
				v40.Floor.Dust:Emit(30)
				v_u_2:AddItem(v40, 1)
				local v41 = {}
				for _, v42 in p35:GetDescendants() do
					if (v42:IsA("BasePart") or v42:IsA("Decal")) and v42.Transparency ~= 1 then
						local v43 = v42.Transparency
						v42.Transparency = 1
						v41[v42] = v43
					end
				end
				task.wait(0.25)
				v_u_10:PlaySound(v_u_7.Naoya.Decisive.Flicker2, v36, game.SoundService.Effect)
				for v44, v45 in v41 do
					if v44.Parent then
						v44.Transparency = v45
					end
				end
				local v46 = v_u_6.Naoya.Teleport:Clone()
				v46.CFrame = v36.CFrame
				v46.Parent = workspace.Effects
				v46.Lines:Emit(8)
				v46.Floor.Dust:Emit(30)
				v_u_2:AddItem(v46, 1)
			end
		end,
		["Swing"] = function(p47)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v48 = p47:FindFirstChild("HumanoidRootPart")
			if v48 then
				local v49 = v_u_6.Naoya.RoughSwing:Clone()
				v49.Weld.C0 = CFrame.new(0, 1, 0) * CFrame.Angles(0, 0, 3.4033920413889427)
				v49.Core.Flames.Enabled = false
				v49.Weld.Part0 = v48
				v49.Beam.CurveSize0 = -8
				v49.Beam.CurveSize1 = 8
				local v50 = v49.A0
				v50.CFrame = v50.CFrame - Vector3.new(3.6, 0, 0)
				local v51 = v49.A1
				v51.CFrame = v51.CFrame + Vector3.new(3.6, 0, 0)
				v49.Parent = workspace.Effects
				v_u_2:AddItem(v49, 0.3)
				v_u_3:Create(v49.Weld, TweenInfo.new(0.3, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["C1"] = v49.Weld.C1 * CFrame.Angles(0, 3.141592653589793, 0)
				}):Play()
				v_u_3:Create(v49.Beam, TweenInfo.new(0.3), {
					["Width0"] = 0
				}):Play()
			end
		end,
		["Swing2"] = function(p52)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				for v54 = 1, 2 do
					local v_u_55 = v_u_6.Naoya.RoughSwing:Clone()
					v_u_55.Weld.C0 = CFrame.new(0, 1, 0) * CFrame.Angles(0, 0, -0.4363323129985824)
					v_u_55.Weld.Part0 = v53
					v_u_55.Parent = workspace.Effects
					v_u_2:AddItem(v_u_55, 0.8)
					if v54 == 2 then
						v_u_55.Beam.CurveSize0 = -8
						v_u_55.Beam.CurveSize1 = 8
						local v56 = v_u_55.A0
						v56.CFrame = v56.CFrame - Vector3.new(3.6, 0, 0)
						local v57 = v_u_55.A1
						v57.CFrame = v57.CFrame + Vector3.new(3.6, 0, 0)
						local v58 = v_u_55.Weld
						v58.C1 = v58.C1 * CFrame.Angles(0, 3.141592653589793, 0)
					end
					v_u_3:Create(v_u_55.Weld, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["C1"] = v_u_55.Weld.C1 * CFrame.Angles(0, 3.141592653589793, 0)
					}):Play()
					v_u_3:Create(v_u_55.Beam, TweenInfo.new(0.5), {
						["Width0"] = 0
					}):Play()
					task.delay(0.3, function()
						-- upvalues: (copy) v_u_55
						v_u_55.Core.Flames.Enabled = false
					end)
					task.wait(0.05)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p60, ...)
		-- upvalues: (copy) v_u_59
		local v61 = v_u_59[p60]
		if v61 then
			v61(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("CursoryImpactService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11