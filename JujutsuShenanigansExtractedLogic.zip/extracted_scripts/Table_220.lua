-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = Random.new()
local v_u_2 = table
local v_u_30 = {
	["contains"] = function(p3, p4)
		-- upvalues: (copy) v_u_30
		return v_u_30.indexOf(p3, p4) ~= nil
	end,
	["indexOf"] = function(p5, p6)
		-- upvalues: (copy) v_u_30
		return table.find(p5, p6) or v_u_30.keyOf(p5, p6)
	end,
	["keyOf"] = function(p7, p8)
		for v9, v10 in pairs(p7) do
			if v10 == p8 then
				return v9
			end
		end
		return nil
	end,
	["insertAndGetIndexOf"] = function(p11, p12)
		p11[#p11 + 1] = p12
		return #p11
	end,
	["skip"] = function(p13, p14)
		return table.move(p13, p14 + 1, #p13, 1, table.create(#p13 - p14))
	end,
	["take"] = function(p15, p16)
		return table.move(p15, 1, p16, 1, table.create(p16))
	end,
	["range"] = function(p17, p18, p19)
		return table.move(p17, p18, p19, 1, table.create(p19 - p18 + 1))
	end,
	["skipAndTake"] = function(p20, p21, p22)
		return table.move(p20, p21 + 1, p21 + p22, 1, table.create(p22))
	end,
	["random"] = function(p23)
		-- upvalues: (copy) v_u_1
		return p23[v_u_1:NextInteger(1, #p23)]
	end,
	["join"] = function(p24, p25)
		local v26 = table.create(#p24 + #p25)
		table.move(p24, 1, #p24, 1, v26)
		return table.move(p25, 1, #p25, #p24 + 1, v26)
	end,
	["removeObject"] = function(p27, p28)
		-- upvalues: (copy) v_u_30
		local v29 = v_u_30.indexOf(p27, p28)
		if v29 then
			table.remove(p27, v29)
		end
	end
}
return setmetatable({}, {
	["__index"] = function(_, p31)
		-- upvalues: (copy) v_u_30, (copy) v_u_2
		if v_u_30[p31] == nil then
			return v_u_2[p31]
		else
			return v_u_30[p31]
		end
	end,
	["__newindex"] = function(_, _, _)
		error("Add new table entries by editing the Module itself.")
	end
})