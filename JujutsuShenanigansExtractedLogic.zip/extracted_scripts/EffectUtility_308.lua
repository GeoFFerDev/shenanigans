-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {}
local v_u_2 = game:GetService("Debris")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("SoundService")
local v5 = game:GetService("Players")
local v_u_6 = game:GetService("TweenService")
local v_u_7 = game:GetService("RunService")
local v_u_8, v_u_9
if v_u_7:IsClient() then
	v_u_8 = require(v3.Knit.Knit)
	v_u_9 = v_u_8.GetController("FXController")
else
	v_u_9 = nil
	v_u_8 = nil
end
local v_u_10 = v5.LocalPlayer
local v11 = RaycastParams.new()
v11.FilterDescendantsInstances = { workspace:WaitForChild("Map") }
v11.FilterType = Enum.RaycastFilterType.Include
v11.IgnoreWater = true
function v_u_1.Emit(p12)
	-- upvalues: (copy) v_u_2
	local v13 = next
	local v14, v15 = p12:QueryDescendants("ParticleEmitter")
	local v16 = 1
	for _, v17 in v13, v14, v15 do
		v17:Emit(v17:GetAttribute("EmitCount"))
		if v16 < v17.Lifetime.Max then
			v16 = v17.Lifetime.Max
		end
	end
	v_u_2:AddItem(p12, v16)
end
function v_u_1.EmitAttachment(p18)
	local v19 = next
	local v20, v21 = p18:QueryDescendants("ParticleEmitter")
	for _, v22 in v19, v20, v21 do
		v22:Emit(v22:GetAttribute("EmitCount"))
	end
end
function v_u_1.CloneAndEmit(p23, p24)
	-- upvalues: (copy) v_u_2
	local v25 = p23:Clone()
	if p23:IsA("Attachment") then
		v25.Parent = p24
	else
		v25.CFrame = p24.CFrame * p23.CFrame
		v25.Parent = workspace.Effects
	end
	local v26 = next
	local v27, v28 = v25:QueryDescendants("ParticleEmitter")
	local v29 = 1
	for _, v30 in v26, v27, v28 do
		v30:Emit(v30:GetAttribute("EmitCount"))
		if v29 < v30.Lifetime.Max then
			v29 = v30.Lifetime.Max
		end
	end
	v_u_2:AddItem(v25, v29)
	return v25
end
function v_u_1.Toggle(p31, p32)
	local v33 = next
	local v34, v35 = p31:QueryDescendants("ParticleEmitter")
	for _, v36 in v33, v34, v35 do
		v36.Enabled = p32
	end
end
function v_u_1.EmitEffects(p37, p38)
	-- upvalues: (copy) v_u_1
	local v39 = Instance.new("Attachment")
	v39.CFrame = p38.CFrame
	local v40 = next
	local v41, v42 = p37:GetChildren()
	for _, v43 in v40, v41, v42 do
		v43:Clone().Parent = v39
	end
	v39.Parent = workspace.Effects
	v_u_1.Emit(v39)
end
function v_u_1.AddSFX(p44, p45, _)
	-- upvalues: (ref) v_u_9, (ref) v_u_8, (copy) v_u_4
	if not v_u_9 then
		v_u_9 = v_u_8.GetController("FXController")
	end
	return v_u_9:PlaySound(p44, p45, v_u_4.Effect)
end
function v_u_1.Distance_Close(p46, p47)
	-- upvalues: (copy) v_u_10
	return v_u_10.Character == p46 and true or v_u_10:DistanceFromCharacter(p46.PrimaryPart.Position) < (p47 or 17.5)
end
function v_u_1.Distance_Far(p48, p49)
	-- upvalues: (copy) v_u_10
	return v_u_10.Character == p48 and true or v_u_10:DistanceFromCharacter(p48.PrimaryPart.Position) < (p49 or 75)
end
function v_u_1.Weld(p50, p51, p52)
	if p50:IsA("Model") then
		p50 = p50.PrimaryPart
	end
	if p51:IsA("Model") then
		p51 = p51.PrimaryPart
	end
	p50.Anchored = false
	p50.CanCollide = false
	p50.CanTouch = false
	p50.CanQuery = false
	p50.Massless = true
	local v53 = Instance.new("Weld")
	v53.Part0 = p50
	v53.Part1 = p51
	if p52 then
		v53.C1 = p52
	end
	v53.Parent = p50
	return v53
end
function v_u_1.ToggleAttachment(p54, p55, p56)
	-- upvalues: (copy) v_u_2
	local v57 = next
	local v58, v59 = p54:QueryDescendants("ParticleEmitter")
	for _, v60 in v57, v58, v59 do
		v60.Enabled = p55
	end
	if p56 then
		v_u_2:AddItem(p54, p56)
	end
end
function v_u_1.EmitAndToggle(p61, p62, p63)
	-- upvalues: (copy) v_u_1
	local v64 = p61:Clone()
	v64.Parent = p62
	v_u_1.EmitAttachment(v64)
	v_u_1.ToggleAttachment(v64, true, p63)
	return v64
end
function v_u_1._BeamTransparencyTween(p_u_65, p66, p_u_67, p68, p69, p70)
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	local v_u_71 = p_u_65.Transparency.Keypoints
	local v_u_72 = #v_u_71
	local v73 = nil
	local v74 = nil
	if typeof(p66) == "number" then
		v73 = p66
		v74 = v73
		local v75 = v73
		v73 = v74
		v75 = v74
	elseif typeof(p66) == "string" then
		local v76, v77 = p66:match("([^,]+),([^,]+)")
		v73 = tonumber(v76)
		v74 = tonumber(v77)
	end
	if v73 and not p_u_65.Enabled then
		p_u_65.Enabled = true
		local v_u_78 = p68 or Enum.EasingStyle.Linear
		local v_u_79 = p69 or Enum.EasingDirection.In
		local v_u_80 = p_u_65.TextureSpeed
		local v_u_81 = p_u_65.Transparency
		local v_u_82 = table.create(v_u_72)
		local v_u_83 = table.create(v_u_72)
		for v84, v85 in ipairs(v_u_71) do
			v_u_82[v84] = v85.Value
			local v86 = v85.Time
			v_u_83[v84] = v73 + (v74 - v73) * v86
		end
		v_u_6:Create(p_u_65, TweenInfo.new(p_u_67, v_u_78, v_u_79), {
			["TextureSpeed"] = p70
		}):Play()
		local v_u_87 = nil
		local v_u_88 = 0
		v_u_87 = v_u_7.Heartbeat:Connect(function(p89)
			-- upvalues: (ref) v_u_88, (copy) p_u_67, (ref) v_u_87, (ref) v_u_6, (ref) v_u_78, (ref) v_u_79, (copy) v_u_72, (copy) v_u_71, (copy) v_u_82, (copy) v_u_83, (copy) p_u_65
			v_u_88 = v_u_88 + p89
			if p_u_67 < v_u_88 then
				v_u_87:Disconnect()
				v_u_87 = nil
			else
				local v90 = v_u_88 / p_u_67
				local v91 = v_u_6:GetValue(math.clamp(v90, 0, 1), v_u_78, v_u_79)
				local v92 = table.create(v_u_72)
				for v93, v94 in ipairs(v_u_71) do
					local v95 = v_u_82[v93] + (v_u_83[v93] - v_u_82[v93]) * v91
					v92[v93] = NumberSequenceKeypoint.new(v94.Time, v95, v94.Envelope)
				end
				p_u_65.Transparency = NumberSequence.new(v92)
			end
		end)
		return function()
			-- upvalues: (copy) p_u_65, (copy) v_u_80, (copy) v_u_81
			p_u_65.Enabled = false
			p_u_65.TextureSpeed = v_u_80
			p_u_65.Transparency = v_u_81
		end
	end
end
function v_u_1.TweenBeamTransparency(p96, p97)
	-- upvalues: (copy) v_u_1
	local v98 = p96:GetAttribute("BeamsParent")
	if v98 and p96:FindFirstChild(v98) then
		p96 = p96[v98]
	end
	for _, v99 in p96:QueryDescendants("Beam") do
		local v100 = v_u_1._BeamTransparencyTween(v99, p97.transparency or 1, p97.duration or 2, p97.beamEasingStyle or Enum.EasingStyle.Sine, p97.beamEasingDirection or Enum.EasingDirection.Out, p97.speed or 0)
		task.delay((p97.duration or 2) + 0.15, v100)
	end
end
function v_u_1.Unit(p101, p102)
	return p101.Magnitude < 1e-7 and (p102 or Vector3.new(0, 0, 0)) or p101.Unit
end
function v_u_1.CalculateYDifference(p103, p104)
	return (p103.Position - p104.Position).Y
end
function v_u_1.CalculateUnitDifference(p105, p106)
	local v107 = (p106.Position - p105.Position).Unit
	if v107 == v107 then
		return v107
	else
		return -p106.LookVector
	end
end
v_u_1.Arc = {}
v_u_1.Arc.Emit = v_u_1.Emit
v_u_1.Arc.EmitAndToggle = v_u_1.EmitAndToggle
v_u_1.Arc.CloneAndEmit = v_u_1.CloneAndEmit
v_u_1.Arc.EmitAttachment = v_u_1.EmitAttachment
v_u_1.Arc.ToggleAttachment = v_u_1.ToggleAttachment
v_u_1.Arc.TweenBeamTransparency = v_u_1.TweenBeamTransparency
return v_u_1