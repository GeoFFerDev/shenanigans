-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "moveset",
	["Description"] = "Loads a moveset into your inventory",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"Mod",
		"Tester",
		"Youtuber"
	},
	["Args"] = {
		{
			["Type"] = "string",
			["Name"] = "Moveset"
		},
		{
			["Type"] = "boolean",
			["Name"] = "Ultimate",
			["Optional"] = true
		}
	}
}
return v1