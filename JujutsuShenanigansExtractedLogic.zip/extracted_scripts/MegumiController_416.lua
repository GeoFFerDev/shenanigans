-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "MegumiController"
})
local v_u_14 = RaycastParams.new()
v_u_14.FilterType = Enum.RaycastFilterType.Include
v_u_14.FilterDescendantsInstances = { workspace.Map, workspace.Spawns, workspace.Domains }
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_14, (copy) v_u_2, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (ref) v_u_10, (ref) v_u_11
	local v_u_52 = {
		["Hit"] = function(p15, p16)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_12:Flash(p15, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. p16), v17, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p18, p19)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v20 = p18:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = p19:FindFirstChild("HumanoidRootPart")
				if v21 then
					v_u_12:Flash(p19, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit3"), v21, game.SoundService.Effect)
					local v22 = v_u_7.ChaseHit:Clone()
					local v23 = CFrame.new
					local v24 = v21.Position
					local v25 = v20.Position.X
					local v26 = v21.Position.Y
					local v27 = v20.Position.Z
					v22.CFrame = v23(v24, (Vector3.new(v25, v26, v27))) * CFrame.Angles(0, 3.141592653589793, 0)
					v22.Parent = workspace.Effects
					v22.Ring:Emit(7)
					v22.Sparks:Emit(12)
					v_u_3:AddItem(v22, 0.5)
				end
			else
				return
			end
		end,
		["Shadow"] = function(p28, p29)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_14, (ref) v_u_2, (ref) v_u_3
			local v30 = p28.HumanoidRootPart
			if not v30 then
				return
			end
			v_u_12:PlaySound(v_u_8.Megumi.ShadowEnter, v30, game.SoundService.Effect)
			local v_u_31 = v_u_7.Megumi.Shadow:Clone()
			v_u_31.Parent = p28
			task.delay(0.2, function()
				-- upvalues: (copy) v_u_31
				v_u_31.Dive.Enabled = false
			end)
			while true do
				local v32 = workspace:Raycast(v30.Position, Vector3.new(0, -8, 0), v_u_14)
				if v32 then
					v_u_31.Shadow.Enabled = true
					v_u_31.ShadowAir.Enabled = false
					v_u_31.CFrame = CFrame.new(v32.Position, v32.Position + v32.Normal)
				else
					v_u_31.CFrame = v30.CFrame - Vector3.new(0, 3, 0)
					v_u_31.Shadow.Enabled = false
					v_u_31.ShadowAir.Enabled = true
				end
				v_u_2.RenderStepped:Wait()
				if not p29.Parent then
					v_u_12:PlaySound(v_u_8.Megumi.Rabbit.Despawn, v30, game.SoundService.Effect)
					v_u_31.Shadow.Enabled = false
					v_u_31.ShadowAir.Enabled = false
					v_u_31.Dive:Emit(20)
					v_u_3:AddItem(v_u_31, 1)
					return
				end
			end
		end,
		["Chase"] = function(p33)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v34 = p33.HumanoidRootPart
			if v34 then
				local v35 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v35.CFrame = v34.CFrame * CFrame.new(0, 1, -4)
				v35.Size = Vector3.new(0, 0, 2)
				v35.Parent = workspace.Effects
				v_u_4:Create(v35, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v35, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v34, game.SoundService.Effect)
				v_u_12:DustTrail(p33, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p36)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v37 = p36:FindFirstChild("HumanoidRootPart")
			if v37 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v37, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p38, p39, p40)
			-- upvalues: (ref) v_u_12
			if p39 == 1 or (p39 == 3 or p40 == "Up") then
				v_u_12:ArmFlash(p38["Right Arm"], Color3.fromRGB(0, 0, 0), 0.3)
				return
			elseif p39 == 2 then
				v_u_12:ArmFlash(p38["Left Arm"], Color3.fromRGB(0, 0, 0), 0.3)
			elseif p39 == 4 then
				v_u_12:ArmFlash(p38["Left Leg"], Color3.fromRGB(0, 0, 0), p40 == "Down" and 0.4 or 0.3)
			end
		end,
		["Launch"] = function(p41, p42)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v43 = p41:FindFirstChild("HumanoidRootPart")
			if v43 then
				local v44 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v44.CFrame = CFrame.new(v43.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v44.Size = Vector3.new(0, 0, 5)
				v44.Parent = workspace.Effects
				v_u_4:Create(v44, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v44.Position + Vector3.new(0, p42, 0)
				}):Play()
				v_u_3:AddItem(v44, 0.3)
				if p42 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v43, game.SoundService.Effect)
					v_u_12:DustBreak(v43.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v43.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Chat"] = function(p45)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v46 = p45:FindFirstChild("Torso")
			if v46 then
				v_u_12:PlaySound(v_u_8.Megumi.Awaken, v46, game.SoundService.Effect)
				local v47 = v_u_7.Megumi.Dialogue:Clone()
				v47.Parent = v46
				local v48 = v47.Text1.Position
				v47.Text1.Position = v48 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v47.Text1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v48
				}):Play()
				v_u_4:Create(v47.Text1, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				v_u_4:Create(v47.Text1.UIStroke, TweenInfo.new(0.3), {
					["Transparency"] = 0
				}):Play()
				task.wait(1.1)
				local v49 = v47.Text2.Position
				v47.Text2.Position = v49 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v47.Text2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v49
				}):Play()
				v_u_4:Create(v47.Text2, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				v_u_4:Create(v47.Text2.UIStroke, TweenInfo.new(0.3), {
					["Transparency"] = 0
				}):Play()
				task.wait(0.25)
				local v50 = v47.Chat1.Position
				v47.Chat1.Position = v50 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v47.Chat1, TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v50
				}):Play()
				v_u_4:Create(v47.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v47.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.9)
				v_u_3:AddItem(v47, 0.6)
				for _, v51 in v47:GetDescendants() do
					if v51:IsA("Frame") then
						v_u_4:Create(v51, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = v51.Position - UDim2.new(0, 0, 0.2, 0),
							["BackgroundTransparency"] = 1
						}):Play()
					elseif v51:IsA("TextLabel") then
						v_u_4:Create(v51, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
						if v51:FindFirstChild("UIStroke") then
							v_u_4:Create(v51:FindFirstChild("UIStroke"), TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["Transparency"] = 1
							}):Play()
						end
					end
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p53, ...)
		-- upvalues: (copy) v_u_52
		local v54 = v_u_52[p53]
		if v54 then
			v54(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p55, p56, p57)
		-- upvalues: (ref) v_u_11, (ref) v_u_4
		local v58 = p56.HumanoidRootPart
		if not v58 then
			return
		end
		local v59 = nil
		while true do
			local v60 = v_u_11:SphereHitbox(p56, CFrame.new(0, 0, -4), 8)
			for _, v61 in v60 do
				local v62 = v61:FindFirstChild("Info")
				if v62 then
					local v63 = v62:FindFirstChild("Knockback")
					if not v63 or v63.Value ~= false then
						v59 = v60
						break
					end
				end
			end
			if v59 then
				local v64 = p55:FindFirstChildWhichIsA("NumberValue")
				if v64 then
					v_u_4:Create(v64, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p55.Parent then
				break
			end
		end
		p57:FireServer(v59, v58.CFrame)
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("MegumiService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13