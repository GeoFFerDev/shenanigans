-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(script.Parent.Parent.Trove)
local v_u_2 = require(script.Parent.Parent.Signal)
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = {}
v_u_4.__index = v_u_4
function v_u_4.new()
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_2
	local v5 = v_u_4
	local v6 = setmetatable({}, v5)
	v6._trove = v_u_1.new()
	v6.KeyDown = v6._trove:Construct(v_u_2)
	v6.KeyUp = v6._trove:Construct(v_u_2)
	v6:_setup()
	return v6
end
function v_u_4.IsKeyDown(_, p7)
	-- upvalues: (copy) v_u_3
	return v_u_3:IsKeyDown(p7)
end
function v_u_4.AreKeysDown(p8, p9, p10)
	local v11 = p8:IsKeyDown(p9)
	if v11 then
		v11 = p8:IsKeyDown(p10)
	end
	return v11
end
function v_u_4.AreEitherKeysDown(p12, p13, p14)
	return p12:IsKeyDown(p13) or p12:IsKeyDown(p14)
end
function v_u_4._setup(p_u_15)
	-- upvalues: (copy) v_u_3
	p_u_15._trove:Connect(v_u_3.InputBegan, function(p16, p17)
		-- upvalues: (copy) p_u_15
		if not p17 then
			if p16.UserInputType == Enum.UserInputType.Keyboard then
				p_u_15.KeyDown:Fire(p16.KeyCode)
			end
		end
	end)
	p_u_15._trove:Connect(v_u_3.InputEnded, function(p18, p19)
		-- upvalues: (copy) p_u_15
		if not p19 then
			if p18.UserInputType == Enum.UserInputType.Keyboard then
				p_u_15.KeyUp:Fire(p18.KeyCode)
			end
		end
	end)
end
function v_u_4.Destroy(p20)
	p20._trove:Destroy()
end
return v_u_4