-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = require(game.ReplicatedStorage.Knit.Knit)
v1.AddControllersDeep(script.Parent:WaitForChild("Controllers"))
v1.Start():catch(warn)
print("Loaded Knit on client!")
require(game.ReplicatedStorage:WaitForChild("CmdrClient")):SetActivationKeys({ Enum.KeyCode.F2 })