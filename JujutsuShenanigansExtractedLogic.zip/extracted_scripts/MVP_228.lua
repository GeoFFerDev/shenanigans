-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {}
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game.Players.LocalPlayer
function v_u_1.MVP_Play(_, p_u_5, p6)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_3, (copy) v_u_1
	if p_u_5 then
		local v_u_7 = script:FindFirstChild(p6)
		if v_u_7 then
			_G.MVP_PLAYING = true
			local v_u_8 = {}
			local v10, v11 = pcall(function()
				-- upvalues: (ref) v_u_4, (ref) v_u_2, (ref) v_u_3, (copy) v_u_7, (copy) p_u_5, (copy) v_u_8
				local v_u_9 = script.Fade:Clone()
				v_u_9.Parent = v_u_4.PlayerGui
				v_u_2:Create(v_u_9.Frame, TweenInfo.new(2), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_3:AddItem(v_u_9, 3)
				task.delay(2.5, function()
					-- upvalues: (ref) v_u_2, (copy) v_u_9
					v_u_2:Create(v_u_9.Frame, TweenInfo.new(0.5), {
						["BackgroundTransparency"] = 1
					}):Play()
				end)
				require(v_u_7):Start(p_u_5, v_u_8)
			end)
			if not v10 then
				v_u_1:MVP_End(v_u_8, true)
				warn(v11)
			end
			_G.MVP_PLAYING = nil
			return v_u_8
		end
	end
end
function v_u_1.MVP_End(_, p12, p13)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_3
	if not p13 then
		local v14 = script.Fade:Clone()
		v14.Parent = v_u_4.PlayerGui
		v_u_2:Create(v14.Frame, TweenInfo.new(2), {
			["BackgroundTransparency"] = 0
		}):Play()
		v_u_3:AddItem(v14, 2.5)
		task.wait(2)
		v_u_2:Create(v14.Frame, TweenInfo.new(0.5), {
			["BackgroundTransparency"] = 1
		}):Play()
	end
	for v15 = #p12, 1, -1 do
		local v16 = p12[v15]
		if v16 then
			table.remove(p12, v15)
			if typeof(v16) == "RBXScriptConnection" then
				v16:Disconnect()
			elseif type(v16) == "function" then
				pcall(v16)
			elseif v16:IsA("AnimationTrack") then
				v16:Stop()
			else
				v16:Destroy()
			end
		end
	end
	local v17 = workspace.CurrentCamera
	v17.CameraType = Enum.CameraType.Custom
	v17.FieldOfView = 70
	if v_u_4.Character then
		v17.CameraSubject = v_u_4.Character.Humanoid
	end
	v_u_4.PlayerGui.Main.Enabled = true
end
return v_u_1