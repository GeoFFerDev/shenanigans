-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("HttpService")
require("./Helper")
local v_u_3 = {
	["BETWEEN"] = {
		["min"] = 0.12,
		["max"] = 0.28
	}
}
local v_u_4 = Random.new()
local v_u_5 = {}
v_u_5.__index = v_u_5
function v_u_5._bumpGen(p6)
	p6._Gen = p6._Gen + 1
end
function v_u_5._isAlive(p7, p8)
	local v9 = not p7._Stopped
	if v9 then
		v9 = not (p7._Active and p8) or p8 == p7._Gen
	end
	return v9
end
function v_u_5._sleep(p10, p11)
	-- upvalues: (copy) v_u_1
	local v12 = p10._Gen
	local v13 = 0
	while p10:_isAlive(v12) and v13 < p11 do
		if p10._Deadline and os.clock() >= p10._Deadline then
			return false
		end
		v13 = v13 + v_u_1.Heartbeat:Wait()
	end
	return p10:_isAlive(v12)
end
function v_u_5._refillBag(p14)
	-- upvalues: (copy) v_u_4
	local v15 = #p14.Pool
	p14._Bag = table.create(v15)
	for v16 = 1, v15 do
		p14._Bag[v16] = p14.Pool[v16]
	end
	for v17 = v15, 2, -1 do
		local v18 = v_u_4:NextInteger(1, v17)
		local v19 = p14._Bag
		local v20 = p14._Bag
		local v21 = p14._Bag[v18]
		local v22 = p14._Bag[v17]
		v19[v17] = v21
		v20[v18] = v22
	end
	if p14._LastId and (v15 > 1 and p14._Bag[1].id == p14._LastId) then
		local v23 = v_u_4:NextInteger(2, v15)
		local v24 = p14._Bag
		local v25 = p14._Bag
		local v26 = p14._Bag[v23]
		local v27 = p14._Bag[1]
		v24[1] = v26
		v25[v23] = v27
	end
	p14._BagI = 1
	p14._BagDirty = false
end
function v_u_5._nextEntry(p28)
	if p28._BagDirty or (not p28._Bag or (p28._BagI > #p28._Bag or #p28._Bag == 0)) then
		if #p28.Pool == 0 then
			return nil
		end
		p28:_refillBag()
	end
	local v29 = p28._Bag[p28._BagI]
	p28._BagI = p28._BagI + 1
	return v29
end
function v_u_5._runLoop(p30)
	-- upvalues: (copy) v_u_4
	p30._Active = true
	p30:_bumpGen()
	while true do
		local v31 = p30:_isAlive() and (not p30._Deadline or os.clock() < p30._Deadline) and p30:_nextEntry()
		if not v31 then
			break
		end
		p30._LastId = v31.id
		task.spawn(v31.run)
		if not (p30:_sleep(v31.time) and p30:_sleep((v_u_4:NextNumber(p30.Between.min, p30.Between.max)))) then
			break
		end
	end
	p30._Active = false
end
function v_u_5.AddEntry(p32, p33)
	local v34 = p32.Pool
	table.insert(v34, p33)
	p32._BagDirty = true
	return p32
end
function v_u_5.Clear(p35)
	table.clear(p35.Pool)
	p35._LastId = nil
	p35._Bag = {}
	p35._BagI = 1
	p35._BagDirty = false
	return p35
end
function v_u_5.setBetween(p36, p37, p38)
	p36.Between.min = math.max(0, p37)
	local v39 = p36.Between
	local v40 = p36.Between.min
	v39.max = math.max(v40, p38)
	return p36
end
function v_u_5.setDeadline(p41, p42)
	p41._Deadline = p42 and os.clock() + p42 or nil
	return p41
end
function v_u_5.RandArenaPos(p43)
	-- upvalues: (copy) v_u_4
	local v44 = p43.State.Arena.Size
	return Vector2.new(v_u_4:NextNumber(-(v44.X * 0.5), v44.X * 0.5), v_u_4:NextNumber(-(v44.Y * 0.5), v44.Y * 0.5))
end
function v_u_5.Defer(p_u_45, p46, p_u_47)
	local v_u_48 = p_u_45._Gen
	task.delay(p46, function()
		-- upvalues: (copy) p_u_45, (copy) v_u_48, (copy) p_u_47
		if p_u_45:_isAlive(v_u_48) and (not p_u_45._Deadline or os.clock() < p_u_45._Deadline) then
			p_u_47()
		end
	end)
end
function v_u_5.Start(p_u_49, p50)
	if p_u_49._Active then
		return p_u_49
	end
	p_u_49:setDeadline(p50)
	task.spawn(function()
		-- upvalues: (copy) p_u_49
		p_u_49:_runLoop()
	end)
	return p_u_49
end
function v_u_5.Stop(p51)
	if not p51._Stopped then
		p51._Stopped = true
		p51._Active = false
		p51:_bumpGen()
	end
end
function v_u_5.new(p52, p53, p54, p55, p56)
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_5
	local v57 = {
		["Trove"] = p52,
		["Signals"] = p53,
		["State"] = p54,
		["Arena"] = p55,
		["GUI"] = p56,
		["Pool"] = {},
		["Between"] = table.clone(v_u_3.BETWEEN),
		["_Active"] = false,
		["_Stopped"] = false,
		["_Deadline"] = nil,
		["_Gen"] = 0,
		["_LastId"] = nil,
		["_Bag"] = {},
		["_BagI"] = 1,
		["_BagDirty"] = false,
		["_UUID"] = v_u_2:GenerateGUID(false)
	}
	local v58 = v_u_5
	return setmetatable(v57, v58)
end
function v_u_5.Destroy(p59)
	p59:Stop()
	table.clear(p59)
	setmetatable(p59, nil)
end
return v_u_5