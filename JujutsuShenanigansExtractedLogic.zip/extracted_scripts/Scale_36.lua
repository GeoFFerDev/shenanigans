-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "scale",
	["Description"] = "Scales the player\'s character",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"Mod",
		"Youtuber"
	},
	["Args"] = {
		{
			["Type"] = "player",
			["Name"] = "Player"
		},
		{
			["Type"] = "number",
			["Name"] = "Scale"
		}
	}
}
return v1