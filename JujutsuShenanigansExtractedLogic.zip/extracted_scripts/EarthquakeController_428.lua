-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "EarthquakeController"
})
function v11.KnitStart(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (ref) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_22 = {
		["Start"] = function(p12)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				local v_u_14 = v_u_6.Megumi.Mahoraga.Cursed:Clone()
				v_u_14.Weld.Part0 = p12["Right Arm"]
				v_u_14.Parent = workspace.Effects
				v_u_14.Shine.Sparks:Emit(10)
				v_u_14.Shine.Glow:Emit(1)
				v_u_2:AddItem(v_u_14, 1)
				task.delay(0.2, function()
					-- upvalues: (copy) v_u_14, (ref) v_u_3
					v_u_14.Shine.Shine:Emit(2)
					v_u_3:Create(v_u_14.Shine.PointLight, TweenInfo.new(0.8), {
						["Brightness"] = 0
					}):Play()
					task.wait(0.4)
					v_u_14.Trail.Enabled = false
				end)
				v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Earthquake.Startup, v13, game.SoundService.Effect)
			end
		end,
		["Crush"] = function(p15, p16, p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8
			local v18 = v_u_6.Megumi.Mahoraga.Earthquake:Clone()
			v18.Position = p16
			v18.Parent = workspace.Effects
			v_u_3:Create(v18.Air, TweenInfo.new(0.2), {
				["Position"] = Vector3.new(0, 0, 0)
			}):Play()
			v_u_3:Create(v18.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v18.Floor.Ring:Emit(10)
			v18.Floor.Wind:Emit(8)
			v_u_2:AddItem(v18, 1)
			if v_u_4 == p15 and not p17 then
				v18.Floor.FluxFissureRef:Emit(1)
				v18.Floor.FluxFissure:Emit(1)
				v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Earthquake.Attempt, workspace, game.SoundService.Effect)
			end
			v_u_10:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v18, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p16).Magnitude < 80 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Crush2"] = function(p19)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8
			local v20 = v_u_6.Megumi.Mahoraga.Earthquake:Clone()
			v20.Position = p19
			v20.Parent = workspace.Effects
			v20.Air:Destroy()
			v_u_3:Create(v20.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v_u_3:Create(v20.Floor.Ring2, TweenInfo.new(0.4), {
				["TimeScale"] = 0.5
			}):Play()
			v20.Floor.Ring2:Emit(10)
			v20.Floor.Wind2:Emit(15)
			v20.Floor.Dust:Emit(100)
			v_u_2:AddItem(v20, 3)
			local v21 = v_u_6.Megumi.Mahoraga.WorldSlash.mesh:Clone()
			v21.Position = p19
			v21.Decal.Transparency = 0
			v21.Mesh.Scale = Vector3.new(2, 50, 2)
			v21.Parent = v20
			v_u_3:Create(v21, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Size"] = Vector3.new(80, 40, 80),
				["CFrame"] = v21.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
			}):Play()
			v_u_3:Create(v21.Mesh, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(60, 10, 60)
			}):Play()
			v_u_3:Create(v21.Decal, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v_u_2:AddItem(v21, 1)
			v_u_10:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v20, game.SoundService.Effect)
			v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Earthquake.Success, v20, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p19).Magnitude < 180 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end
	}
	v_u_9.Effects:Connect(function(p23, ...)
		-- upvalues: (copy) v_u_22
		local v24 = v_u_22[p23]
		if v24 then
			v24(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("EarthquakeService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11