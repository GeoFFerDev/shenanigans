-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local v_u_4 = v3.Utils
local v_u_5 = v3.Sounds
local v_u_6 = require(v3.Modules.CameraShaker)
local v_u_7 = require(v3.Modules.BloodyZee)
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "RikaDownslamController"
})
function v10.KnitStart(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_5, (copy) v_u_4, (copy) v_u_2, (copy) v_u_6, (copy) v_u_7
	local v_u_35 = {
		["RikaHit"] = function(p11)
			-- upvalues: (ref) v_u_9, (ref) v_u_5
			local v12 = p11:FindFirstChild("HumanoidRootPart")
			if v12 then
				v_u_9:Flash(p11, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_5.Yuta.M1.Hit4, v12, game.SoundService.Effect)
			end
		end,
		["RikaFloorHit"] = function(p13, p14)
			-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_4, (ref) v_u_2, (ref) v_u_6
			if typeof(p13) ~= "Vector3" then
				local v15 = p13:FindFirstChild("HumanoidRootPart")
				if not v15 then
					return
				end
				v_u_9:Flash(p13, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_5.Yuta.M1.Hit4, v15, game.SoundService.Effect)
				p13 = v15.Position
			end
			local v16 = v_u_4.Itadori.CrushingBlow:Clone()
			v16.PointLight:Destroy()
			v16.Beam:Destroy()
			if p14 then
				v16.CFrame = CFrame.lookAlong(p13, p14) * CFrame.Angles(1.5707963267948966, 0, 0)
			else
				v16.Position = p13
			end
			v16.Parent = workspace.Effects
			v16.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 1, 1))
			v16.Floor.Ring:Emit(10)
			v16.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v16, 1.5)
			v_u_9:PlaySound(v_u_5.Yuta.VeilstepHit, v16, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p13).Magnitude <= 50 then
				v_u_6.CurrentShaker:Shake(v_u_6.Presets.HeavyHit)
			end
		end,
		["RikaGrab"] = function(p17, p18)
			-- upvalues: (ref) v_u_9, (ref) v_u_5
			v_u_9:PlaySound(v_u_5.Yuta.VeilstepJump, p17, game.SoundService.Effect).TimePosition = 0.2
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_9:PlaySound(v_u_5.Yuta.Rika.Grab, v19, game.SoundService.Effect)
			end
		end,
		["StartFly"] = function(p20)
			-- upvalues: (ref) v_u_9, (ref) v_u_5
			v_u_9:PlaySound(v_u_5.Yuta.Rika.StartFly, p20, game.SoundService.Effect)
		end,
		["DownslamFinisher"] = function(p21)
			-- upvalues: (ref) v_u_7, (ref) v_u_9, (ref) v_u_5, (ref) v_u_4, (ref) v_u_2
			local v22 = p21.HumanoidRootPart
			if v22 then
				local v23 = v22.Position
				local v24 = CFrame.lookAlong(v23, Vector3.new(0, 1, 0))
				for _ = 1, 8 do
					v_u_7:Blood(v24, 30, 20, 20)
				end
				local v25 = v_u_9:PlaySound(v_u_5.Yuta.VeilstepHit, v22, game.SoundService.Effect)
				v25.Volume = v25.Volume * 1.5
				v_u_9:PlaySound(v_u_5.Itadori.Dismantle.Explode, v22, game.SoundService.Effect)
				for _, v26 in p21:GetDescendants() do
					if v26:IsA("BasePart") or v26:IsA("Decal") then
						v26.Transparency = 1
					end
				end
				for _, v27 in p21:GetChildren() do
					if v27:IsA("BasePart") then
						for _ = 1, 2 do
							local v28 = v_u_4.Damage.Chunk:Clone()
							v28.CFrame = v27.CFrame
							local v29 = math.random(-80, 80)
							local v30 = math.random(-80, 80)
							local v31 = math.random
							v28.Velocity = Vector3.new(v29, v30, v31(-80, 80))
							local v32 = math.random(-200, 200)
							local v33 = math.random(-200, 200)
							local v34 = math.random
							v28.RotVelocity = Vector3.new(v32, v33, v34(-200, 200))
							v28.Parent = workspace.Effects
							v_u_2:AddItem(v28, 1)
							if _G.Settings.Gore == false then
								v28.Color = Color3.fromRGB(255, 85, 255)
								v28.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
								v28.Blood.Color = v28.Trail.Color
							end
						end
					end
				end
			end
		end
	}
	RikaDownslamService.Effects:Connect(function(p36, ...)
		-- upvalues: (copy) v_u_35
		local v37 = v_u_35[p36]
		if v37 then
			v37(...)
		end
	end)
end
function v10.KnitInit(_)
	-- upvalues: (copy) v_u_1, (ref) v_u_8, (ref) v_u_9
	RikaDownslamService = v_u_1.GetService("RikaDownslamService")
	v_u_8 = v_u_1.GetController("HitboxController")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10