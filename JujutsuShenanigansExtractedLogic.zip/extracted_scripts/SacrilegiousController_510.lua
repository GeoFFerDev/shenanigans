-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "SacrilegiousController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_5, (copy) v_u_9, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (copy) v_u_6, (ref) v_u_10
	local v_u_43 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_8.Charles.Despair.Spin, v14, game.SoundService.Effect)
			end
		end,
		["Stab"] = function(p15, p16)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_11:Flash(p16, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Hiromi.Execution.Stab, v17, game.SoundService.Effect)
				if v_u_5 == p15 or v_u_5.Character == p16 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Dialog"] = function(p18, p19)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			if p18:FindFirstChild("HumanoidRootPart") then
				local v20 = v_u_7.Charles.Dialogue:Clone()
				v20.StudsOffset = p19 == 1 and Vector3.new(-2.5, -0.5, 2) or Vector3.new(2.5, -0.5, 2)
				v20.Chat.Sub.Text = p19 == 1 and "STOP DESECRATING THIS WORK!!" or "DID YOU EVEN READ THE ORIGINAL PROPERLY!?"
				v20.Parent = p18.Head
				local v21 = v20.Chat.Position
				v20.Chat.Position = v21 + UDim2.new(0, 0, 0.5, 0)
				v_u_4:Create(v20.Chat, TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v21
				}):Play()
				v_u_4:Create(v20.Chat, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v20.Chat.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.8)
				v_u_3:AddItem(v20, 0.5)
				for _, v22 in v20:GetDescendants() do
					if v22:IsA("Frame") then
						v_u_4:Create(v22, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = v21 + UDim2.new(0, 0, 0.3, 0),
							["BackgroundTransparency"] = 1
						}):Play()
					elseif v22:IsA("TextLabel") then
						v_u_4:Create(v22, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["Hit"] = function(p23, p24)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				v_u_11:Flash(p24, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Charles.ShutUp.Hit, v25, game.SoundService.Effect)
				if v_u_5 == p23 or v_u_5.Character == p24 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Spin"] = function(p26)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				v_u_11:PlaySound(v_u_8.Charles.Throw, v27, game.SoundService.Effect)
			end
		end,
		["Hit2"] = function(p28, p29)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_11:Flash(p29, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Charles.ShutUp.Hit2, v30, game.SoundService.Effect)
				local v31 = v_u_7.Gojo.Twofold.Sparks:Clone()
				v31.Parent = v30.RootAttachment
				v31:Emit(20)
				v_u_3:AddItem(v31, 0.4)
				if v_u_5 == p28 or v_u_5.Character == p29 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Dash"] = function(p32, p33)
			-- upvalues: (ref) v_u_2, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_6, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v_u_34 = p32.HumanoidRootPart
			if v_u_34 then
				v_u_2.Stepped:Wait()
				local v_u_35 = CFrame.new(p33, v_u_34.Position)
				local v36 = (p33 - v_u_34.Position).Magnitude
				local v37 = v_u_7.Mahito.Dash:Clone()
				v37.CFrame = v_u_35 + v_u_35.LookVector * v36 / 2
				v37.Size = Vector3.new(5, 5, v36)
				v37.Parent = workspace.Effects
				v_u_4:Create(v37, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 0, v36),
					["CFrame"] = v37.CFrame * CFrame.Angles(0, 0, 3.141592653589793)
				}):Play()
				v_u_3:AddItem(v37, 0.2)
				local v38 = Instance.new("Model")
				local v39 = v_u_6.Utils.Itadori.RushWind:Clone()
				v39.CFrame = v_u_34.CFrame * CFrame.new(0, -1, 0)
				v39.Parent = v38
				v38.Parent = workspace.Effects
				v38:ScaleTo(0.6)
				v39.Ring:Emit(7)
				v39.Dash1.Dash:Emit(1)
				v39.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v38, 2)
				local v40 = v_u_7.Itadori.Shock:Clone()
				v40.CFrame = v_u_35 * CFrame.Angles(1.5707963267948966, 0, 0)
				v40.Parent = workspace.Effects
				v_u_4:Create(v40, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(10, 0, 10),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v40, 0.3)
				task.delay(0.075, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_35, (ref) v_u_4, (ref) v_u_3, (copy) v_u_34
					local v41 = v_u_7.Itadori.Shock:Clone()
					v41.CFrame = v_u_35 * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_35.LookVector * 3
					v41.Parent = workspace.Effects
					v_u_4:Create(v41, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v41, 0.2)
					task.wait(0.075)
					local v42 = v_u_7.Itadori.Shock:Clone()
					v42.CFrame = v_u_34.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v42.Parent = workspace.Effects
					v_u_4:Create(v42, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v42, 0.2)
				end)
				v_u_11:PlaySound(v_u_8.Yuki.Swing, v_u_34, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_8.Charles.Despair.Swing, v_u_34, game.SoundService.Effect)
				if v_u_5.Character == p32 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p44, ...)
		-- upvalues: (copy) v_u_43
		local v45 = v_u_43[p44]
		if v45 then
			v45(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("SacrilegiousService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12