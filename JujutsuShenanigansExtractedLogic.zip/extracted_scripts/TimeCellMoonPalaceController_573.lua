-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = v5.Animations
local v_u_7 = v5.Utils
local v_u_8 = v5.Sounds
require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "TimeCellMoonPalaceController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_9, (copy) v_u_7, (copy) v_u_2, (copy) v_u_4, (copy) v_u_6, (copy) v_u_3, (ref) v_u_10
	local v_u_68 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7, (ref) v_u_2, (ref) v_u_4, (ref) v_u_6, (ref) v_u_3
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_8.Naoya.MoonPalace.Voice, v14, game.SoundService.Voice)
				v_u_11:DomainBurst(v14)
				for _ = 1, 40 do
					v_u_9:Blood(p13.Torso.CFrame, 50, 360, 360)
				end
				if _G.Settings.Gore then
					local v15 = v_u_7.Heian.BloodSpread:Clone()
					v15.Parent = v14
					v15:Emit(80)
					v_u_2:AddItem(v15, 2)
				end
				local v16 = v_u_4.Character
				if v16 and v16:FindFirstChild("HumanoidRootPart") then
					local v17 = v16:FindFirstChild("HumanoidRootPart")
					if (v14.Position - v17.Position).Magnitude <= 37.5 then
						v_u_11:Domain(p13, function(p18, p19)
							-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_3
							p19.Humanoid:LoadAnimation(v_u_6.Naoya.DomainWarn):Play(0)
							p18.Panel.ImageLabel.Image = "rbxassetid://5141175245"
							p18.Panel.ImageLabel.Size = UDim2.new(0.7, 0, 0.7, 0)
							p18.Panel.ImageLabel.ImageColor3 = Color3.fromRGB(49, 28, 39)
							p18.Panel.Viewport.LightColor = Color3.fromRGB(170, 170, 255)
							p18.Panel.Viewport.Ambient = Color3.fromRGB(77, 59, 60)
							p18.Panel.Viewport.LightDirection = Vector3.new(0, 1, 0)
							local v20 = v_u_7.Naoya.MoonPalace.Eye:Clone()
							v20.Parent = p18.Panel
							v_u_3:Create(v20, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["Size"] = UDim2.new(0.5, 0, 0.5, 0)
							}):Play()
							v_u_3:Create(v20.ImageLabel, TweenInfo.new(2, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
								["Size"] = UDim2.new(0.7, 0, 0.7, 0),
								["Rotation"] = 100
							}):Play()
						end)
					end
				end
			end
		end,
		["Opening"] = function(p21, p22, p_u_23, p24)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_8
			local v_u_25 = v_u_7.Naoya.MoonPalace.DomainBG:Clone()
			v_u_25.Parent = p21
			v_u_25.CFrame = p21.CFrame
			task.spawn(function()
				-- upvalues: (copy) p_u_23, (copy) v_u_25
				repeat
					task.wait()
				until not (p_u_23.Parent and (p_u_23.Parent.Parent and p_u_23.Parent.Parent.Parent))
				v_u_25:Destroy()
			end)
			if not p24 then
				local v_u_26 = p22.DomainGround
				v_u_26.Surround.Enabled = true
				v_u_3:Create(v_u_26.Surround, TweenInfo.new(0.8), {
					["ShapePartial"] = 1
				}):Play()
				v_u_2:AddItem(v_u_26, 2)
				local v27 = v_u_11:PlaySound(v_u_8.Naoya.MoonPalace.Flicker, workspace, game.SoundService.Effect)
				v_u_3:Create(v27, TweenInfo.new(3), {
					["PlaybackSpeed"] = 2,
					["Volume"] = 0
				}):Play()
				v_u_2:AddItem(v27, 3)
				task.delay(0.8, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_26, (ref) v_u_11
					v_u_3:Create(v_u_26, TweenInfo.new(0.4), {
						["Transparency"] = 0
					}):Play()
					v_u_11:DomainMapFade(Color3.new(0, 0, 0), 0.4, 1.6)
				end)
				task.wait(1.5)
			end
			if p_u_23 and p_u_23.Parent then
				local v_u_28 = v_u_11:PlaySound(v_u_8.Naoya.MoonPalace.Music, workspace, game.SoundService.Music, true)
				game.SoundService.AmbientReverb = Enum.ReverbType.Arena
				local v_u_29 = Instance.new("ColorCorrectionEffect", game.Lighting)
				v_u_29.Name = "DomainCC"
				v_u_3:Create(v_u_29, TweenInfo.new(1.5), {
					["Brightness"] = 0.1,
					["Contrast"] = 2,
					["TintColor"] = Color3.fromRGB(255, 174, 174)
				}):Play()
				local v_u_30 = Instance.new("Highlight")
				v_u_30.DepthMode = Enum.HighlightDepthMode.Occluded
				v_u_30.FillTransparency = 1
				v_u_30.OutlineTransparency = 1
				v_u_30.Parent = workspace.Characters
				v_u_3:Create(v_u_30, TweenInfo.new(0.5), {
					["OutlineTransparency"] = 0
				}):Play()
				task.spawn(function()
					-- upvalues: (copy) p_u_23, (ref) v_u_3, (copy) v_u_28, (ref) v_u_2, (copy) v_u_29, (copy) v_u_30
					repeat
						task.wait()
					until not (p_u_23.Parent and (p_u_23.Parent.Parent and p_u_23.Parent.Parent.Parent))
					game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
					v_u_3:Create(v_u_28, TweenInfo.new(2), {
						["Volume"] = 0
					}):Play()
					v_u_2:AddItem(v_u_28, 2)
					v_u_29:Destroy()
					v_u_30:Destroy()
				end)
				local v_u_31 = v_u_25.Model
				v_u_31:PivotTo(v_u_25.CFrame * CFrame.Angles(0, -1.5707963267948966, 0) - Vector3.new(0, 9, 0))
				if p24 then
					v_u_31.Eye.Size = Vector3.new(30, 30, 30)
				else
					for _, v32 in v_u_31.Model:GetDescendants() do
						if v32:IsA("BasePart") then
							local v33 = v32.Size
							v32.Size = Vector3.new(0, 0, 0)
							local v34 = v32.CFrame
							local v35 = math.random(100, 200)
							v32.CFrame = (v34 - Vector3.new(0, v35, 0)) * CFrame.Angles(math.random(-3.141592653589793, 3.141592653589793), math.random(-3.141592653589793, 3.141592653589793), math.random(-3.141592653589793, 3.141592653589793))
							v_u_3:Create(v32, TweenInfo.new(math.random(10, 20) / 10, Enum.EasingStyle.Exponential), {
								["CFrame"] = v34
							}):Play()
							v_u_3:Create(v32, TweenInfo.new(math.random(15, 40) / 10, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
								["Size"] = v33
							}):Play()
						end
					end
					task.wait(0.5)
					v_u_3:Create(v_u_31.Eye, TweenInfo.new(0.5), {
						["Size"] = Vector3.new(30, 30, 30)
					}):Play()
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_31, (copy) v_u_25
					repeat
						v_u_31.Eye.CFrame = CFrame.lookAt(v_u_31.Eye.Position, workspace.CurrentCamera.CFrame.Position)
						task.wait()
					until not v_u_25.Parent
				end)
			end
		end,
		["Shatter"] = function(p36)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_11, (ref) v_u_8, (ref) v_u_3
			local v37 = v_u_7.Domain:Clone()
			v37.Transparency = 1
			v37.CanCollide = false
			v37.Position = p36
			v37.Shatter.Color = ColorSequence.new(Color3.new(0, 0, 0))
			v37.Parent = workspace.Effects
			v_u_2:AddItem(v37, 3)
			for _, v38 in v37:GetChildren() do
				if v38.Name == "Shatter" then
					v38:Emit(100)
				else
					v38:Destroy()
				end
			end
			v_u_11:PlaySound(v_u_8.Naoya.MoonPalace.Shatter, v37, game.SoundService.Effect)
			v37.Transparency = 0
			v37.Color = Color3.new(0, 0, 0)
			v_u_3:Create(v37, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v37.Position).Magnitude > 150 then
					return
				end
				local v39 = Random.new()
				local v40 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v41 = v_u_7.Gojo.Shard:Clone()
					local v42 = v39:NextUnitVector().Unit
					local v43 = math.random(1, 8)
					local v44 = math.random
					v41.Size = Vector3.new(0.1, v43, v44(1, 8))
					v41.CFrame = CFrame.lookAlong(p36, v42) * CFrame.Angles(1.5707963267948966, 0, 0) + v42 * 37.5
					v41.CFrame = v41.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v41.Color = Color3.new(0, 0, 0)
					v41.CanCollide = true
					v41.CollisionGroup = "Effects"
					v41.Parent = workspace.Effects
					local v45 = math.random(-50, 50)
					local v46 = math.random(-50, 50)
					local v47 = math.random
					v41.RotVelocity = Vector3.new(v45, v46, v47(-50, 50))
					v41.Transparency = 0
					v41.Material = Enum.Material.Neon
					v_u_3:Create(v41, v40, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v41, 4)
				end
			end
		end,
		["Hit"] = function(p48)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2, (ref) v_u_9, (ref) v_u_3
			local v49 = p48:FindFirstChild("HumanoidRootPart")
			if v49 then
				v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Slash, v49, game.SoundService.Effect)
				local v_u_50 = v_u_7.Naoya.MoonPalace.Hit:Clone()
				if _G.Settings.Gore ~= true then
					v_u_50.Color = ColorSequence.new(Color3.fromRGB(255, 0, 255))
				end
				v_u_50.Parent = p48.Torso
				v_u_2:AddItem(v_u_50, 0.2)
				task.delay(0.1, function()
					-- upvalues: (copy) v_u_50
					v_u_50.Enabled = false
				end)
				v_u_9:Blood(p48.Torso.CFrame, 50, 180, 180)
				if _G.Settings.DesPHY then
					if (workspace.CurrentCamera.CFrame.Position - v49.Position).Magnitude > 100 then
						return
					end
					local v51 = Random.new()
					local v52 = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
					local v53 = v_u_7.Gojo.Shard:Clone()
					local v54 = v51:NextUnitVector().Unit
					local v55 = math.random(5, 20) / 10
					local v56 = math.random(5, 20) / 10
					v53.Size = Vector3.new(0.2, v55, v56)
					v53.CFrame = v49.CFrame * CFrame.new(math.random(-2, 2), math.random(-4, 4), 0)
					v53.CFrame = v53.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v53.CanCollide = true
					v53.CollisionGroup = "Effects"
					v53.Parent = workspace.Effects
					v53.Transparency = 0.5
					v53.Color = v_u_7.Naoya.NaoyaGlass.Color
					v53.Material = Enum.Material.Neon
					local v57 = math.random(-50, 50)
					local v58 = math.random(-50, 50)
					local v59 = math.random
					v53.RotVelocity = Vector3.new(v57, v58, v59(-50, 50))
					v53.Velocity = v54 * math.random(50, 100)
					v_u_3:Create(v53, v52, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v53, 1)
				end
			end
		end,
		["Form"] = function(p60, p61)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2
			local v62 = p60:FindFirstChild("HumanoidRootPart")
			if v62 then
				v_u_11:PlaySound(v_u_8.Mahito.Variants.Transform3, v62, game.SoundService.Effect)
				local v63 = p61.CurseBody
				local v64 = p61.Body.Color
				repeat
					task.wait()
				until not p61:IsDescendantOf(workspace)
				for _ = 1, 15 do
					local v65 = v_u_7.Mahito.Morph:Clone()
					v65.Weld.Part0 = v62
					v65.Color = v63.Color
					v65.Material = v63.Material
					v65.Weld.C0 = CFrame.new(math.random(-200, 200) / 100, math.random(-300, -200) / 100, math.random(-300, 300) / 100)
					v65.Parent = workspace.Effects
					local v66 = math.random(100, 250) / 100
					local v67 = math.random(40, 80) / 100
					v65.Size = Vector3.new(1, 1, 1) * v66
					v65.Color = v64
					v_u_3:Create(v65, TweenInfo.new(v67, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_3:Create(v65.Weld, TweenInfo.new(v67, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
						["C0"] = CFrame.new(0, -2, 0)
					}):Play()
					v_u_2:AddItem(v65, v67)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p69, ...)
		-- upvalues: (copy) v_u_68
		local v70 = v_u_68[p69]
		if v70 then
			v70(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("TimeCellMoonPalaceService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12