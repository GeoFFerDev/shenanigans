-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 2,
	["Desc"] = "The world is upside down, scream."
}
local v_u_2 = nil
local v_u_3 = game:GetService("RunService")
function v1.Callback(p4)
	-- upvalues: (ref) v_u_2, (copy) v_u_3
	if p4 == true and not v_u_2 then
		v_u_2 = v_u_3.RenderStepped:Connect(function()
			local v5 = workspace.CurrentCamera
			v5.CFrame = v5.CFrame * CFrame.Angles(0, 0, 3.141592653589793)
		end)
	elseif v_u_2 then
		v_u_2:Disconnect()
		v_u_2 = nil
	end
end
return v1