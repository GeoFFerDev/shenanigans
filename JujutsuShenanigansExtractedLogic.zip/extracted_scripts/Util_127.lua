-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("RunService")
local v_u_2 = require(script.Parent.Parent.Option)
local v_u_6 = {
	["IsServer"] = v1:IsServer(),
	["WaitForChildTimeout"] = 60,
	["DefaultCommFolderName"] = "__comm__",
	["None"] = newproxy(),
	["GetCommSubFolder"] = function(p3, p4)
		-- upvalues: (copy) v_u_6, (copy) v_u_2
		local v5
		if v_u_6.IsServer then
			v5 = p3:FindFirstChild(p4)
			if not v5 then
				v5 = Instance.new("Folder")
				v5.Name = p4
				v5.Parent = p3
			end
		else
			v5 = p3:WaitForChild(p4, v_u_6.WaitForChildTimeout)
		end
		return v_u_2.Wrap(v5)
	end
}
return v_u_6