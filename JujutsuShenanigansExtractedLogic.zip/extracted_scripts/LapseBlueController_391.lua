-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = require(v6.Modules.BloodyZee)
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "LapseBlueController"
})
function v13.KnitStart(_)
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (ref) v_u_12, (copy) v_u_8, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (copy) v_u_10, (ref) v_u_11
	local v_u_83 = {
		["LapseBlue"] = function(p14)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_4
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = v_u_7.Gojo.LapseBlue.LapseBlue:Clone()
				v16.Parent = workspace.Effects
				v16.CFrame = v15.CFrame
				v16.Weld.Part0 = v15
				v_u_3:AddItem(v16, 0.8)
				v_u_12:PlaySound(v_u_8.Gojo.LapseBlue.LapseBlue, v15, game.SoundService.Effect)
				v_u_4:Create(v16.Zoom.PointLight, TweenInfo.new(0.3), {
					["Range"] = 30
				}):Play()
				v_u_4:Create(v16.Zoom.PointLight, TweenInfo.new(0.3), {
					["Brightness"] = 12
				}):Play()
				v_u_4:Create(v16, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(2, 2, 2)
				}):Play()
				task.wait(0.3)
				v_u_4:Create(v16.Zoom.PointLight, TweenInfo.new(0.15), {
					["Range"] = 0
				}):Play()
				v_u_4:Create(v16, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 0, 0)
				}):Play()
				v16.Center.Aura.Enabled = false
				v16.Zoom.Aura:Emit(20)
				local v17 = Instance.new("Highlight", v16.Grab)
				v17.FillTransparency = 1
				v17.OutlineTransparency = 1
				v16.Grab.Transparency = 50
				v_u_4:Create(v16.Grab, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(15, 15, 15),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v16.Grab, 0.4)
			end
		end,
		["BlueGrab"] = function(p18)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = v_u_7.Itadori.CounterHit.Feint:Clone()
				for _, v21 in v20:GetChildren() do
					v21.Color = ColorSequence.new(Color3.fromRGB(85, 170, 255))
				end
				v20.Parent = v19
				v20.Sparks:Emit(10)
				v20.Ring:Emit(3)
				v_u_3:AddItem(v20, 0.5)
				v_u_12:Flash(p18, Color3.fromRGB(85, 170, 255), 0.5)
			end
		end,
		["Grab"] = function(p22, p23, p24)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v25 = p22:FindFirstChild("HumanoidRootPart")
			local v26 = p23:FindFirstChild("HumanoidRootPart")
			v_u_12:Flash(p23, Color3.new(1, 1, 1))
			v_u_12:PlaySound(v_u_8.Gojo.LapseBlue.Grab, v26, game.SoundService.Effect)
			local v27 = (v25.Position - v26.Position).Magnitude / 60
			local v28 = CFrame.new(v25.Position, v26.Position)
			task.wait(v27)
			if p24.Parent then
				v_u_12:Flash(p23, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Gojo.LapseBlue.Infinity, v25, game.SoundService.Effect)
				local v29 = v_u_7.Gojo.LapseBlue.Infinity:Clone()
				v29.CFrame = v28
				v29.Parent = workspace.Effects
				v29.Attachment.Ring:Emit(5)
				v29.Attachment.Infinity:Emit(10)
				v_u_3:AddItem(v29, 0.5)
			end
		end,
		["Hit"] = function(p30, p31)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v32 = p30:FindFirstChild("HumanoidRootPart")
			local v33 = p31:FindFirstChild("HumanoidRootPart")
			v_u_12:Flash(p31, Color3.new(1, 1, 1))
			v_u_12:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v33, game.SoundService.Effect)
			local v34 = CFrame.new(v32.Position, v33.Position + Vector3.new(0, 3.5, 0))
			local v35 = v_u_7.Gojo.HardHit:Clone()
			v35.CFrame = v34 + v34.LookVector * 3.5
			v35.Parent = workspace.Effects
			v35.Dust:Emit(5)
			v35.Ring:Emit(5)
			v35.Sparks:Emit(10)
			v_u_3:AddItem(v35, 0.5)
			if v_u_5.Character == p30 or v_u_5.Character == p31 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["Finisher"] = function(p36, p37, p_u_38, p_u_39)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10
			if #p36 < 15 then
				for _ = 1, 15 - #p36 do
					local v40 = {}
					local v41 = CFrame.new
					local v42 = math.random(-8, 8)
					local v43 = math.random(-8, -2)
					local v44 = math.random
					__set_list(v40, 1, {v41(p37 + Vector3.new(v42, v43, v44(-8, 8))), Color3.fromRGB(86, 66, 54), Enum.Material.Ground, Vector3.new(2, 2, 2)})
					table.insert(p36, v40)
				end
			elseif #p36 > 40 then
				for v45 = 40, #p36 do
					table.remove(p36, v45)
				end
			end
			local v_u_46 = v_u_7.Gojo.LapseBlue.LapseBlue:Clone()
			v_u_46.CFrame = CFrame.new(p_u_38)
			v_u_46.Transparency = 1
			v_u_46.Center.Aura.Enabled = false
			v_u_46.Anchored = true
			v_u_46.Parent = workspace.Effects
			v_u_3:AddItem(v_u_46, 4)
			local v_u_47
			if p_u_39[1] then
				v_u_47 = p_u_39[1]:FindFirstChild("HumanoidRootPart")
			else
				v_u_47 = nil
			end
			local v_u_48 = nil
			v_u_48 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) v_u_46, (ref) v_u_48, (ref) v_u_47, (copy) p_u_38
				if not v_u_46.Parent then
					v_u_48:Disconnect()
				end
				v_u_46.Position = v_u_47 and v_u_47.Position or p_u_38
			end)
			v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Throw, v_u_46, game.SoundService.Effect).PlaybackSpeed = 1.1
			if (workspace.CurrentCamera.CFrame.Position - v_u_46.Position).Magnitude < 150 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
			for v_u_49, v_u_50 in p36 do
				local v_u_51 = Instance.new("Part")
				v_u_51.Anchored = true
				v_u_51.CanCollide = false
				v_u_51.Massless = true
				v_u_51.CFrame = v_u_50[1]
				v_u_51.Color = v_u_50[2]
				v_u_51.Material = v_u_50[3]
				v_u_51.Size = v_u_50[4]
				v_u_51.Parent = v_u_46
				v_u_3:AddItem(v_u_51, 4)
				local v_u_52 = math.random(30, 80) / 100
				local v_u_53 = Instance.new("NumberValue", v_u_51)
				v_u_4:Create(v_u_53, TweenInfo.new(v_u_52, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["Value"] = 1
				}):Play()
				local v54 = math.random(-180, 180)
				local v55 = math.random(-180, 180)
				local v56 = math.random
				local v_u_57 = Vector3.new(v54, v55, v56(-180, 180))
				local v58 = math.random(-35, 35) / 10
				local v59 = math.random(-35, 35) / 10
				local v60 = math.random(-35, 35) / 10
				local v_u_61 = Vector3.new(v58, v59, v60)
				local v62 = math.random(-30, 30) / 0.8 * v_u_52
				local v63 = math.random(-30, 30) / 0.8 * v_u_52
				local v64 = math.random(-30, 30) / 0.8 * v_u_52
				local v_u_65 = Vector3.new(v62, v63, v64)
				local v_u_71 = v_u_2.Stepped:Connect(function()
					-- upvalues: (ref) v_u_47, (copy) p_u_38, (copy) v_u_65, (copy) v_u_53, (copy) v_u_51, (copy) v_u_61, (copy) v_u_57, (copy) v_u_50
					local v66 = v_u_47 and v_u_47.Position or p_u_38
					local v67 = v66 + v_u_65
					if v_u_53.Value == 1 then
						v_u_51.Position = v66 + v_u_61
						v_u_51.Orientation = v_u_57
					else
						local v68 = v_u_53.Value
						local v69 = v_u_50[1].Position
						local v70 = (1 - v68) ^ 2 * v69 + 2 * (1 - v68) * v68 * v67 + v68 ^ 2 * v66
						v_u_51.CFrame = v_u_51.CFrame - v_u_51.Position + v70
					end
				end)
				task.delay(v_u_52, function()
					-- upvalues: (copy) v_u_51, (copy) v_u_49, (ref) v_u_12, (ref) v_u_8, (ref) v_u_10, (copy) v_u_46, (ref) v_u_9, (copy) v_u_52, (ref) v_u_71
					local v72 = v_u_51
					v72.Size = v72.Size * 1.5
					if v_u_49 % 7 == 0 then
						v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.M1["Hit" .. math.random(3, 4)], v_u_51, game.SoundService.Effect)
						v_u_10:Blood(v_u_51.CFrame, 70, 180, 180)
						if (workspace.CurrentCamera.CFrame.Position - v_u_46.Position).Magnitude < 150 then
							v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
						end
					end
					if v_u_49 % 3 == 0 then
						v_u_46.Explode.HitBase:Emit(1)
					end
					task.wait(1.5 - v_u_52)
					v_u_71:Disconnect()
				end)
			end
			task.delay(1.5, function()
				-- upvalues: (copy) p_u_39, (copy) p_u_38, (copy) v_u_46, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_3
				for _, v73 in p_u_39 do
					if v73.Parent then
						for _, v74 in v73:GetDescendants() do
							if v74:IsA("BasePart") or v74:IsA("Decal") then
								v74.Transparency = 1
							end
						end
					end
				end
				if (workspace.CurrentCamera.CFrame.Position - p_u_38).Magnitude < 150 then
					for _, v_u_75 in v_u_46:GetChildren() do
						if v_u_75:IsA("BasePart") and v_u_75 ~= v_u_46.Grab then
							local v76 = {
								["Position"] = p_u_38
							}
							v_u_4:Create(v_u_75, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), v76):Play()
							task.delay(0.5, function()
								-- upvalues: (copy) v_u_75, (ref) v_u_4
								if _G.Settings.DesPHY then
									v_u_75.Anchored = false
									local v77 = v_u_75
									local v78 = math.random(-50, 50)
									local v79 = math.random(0, 100)
									local v80 = math.random
									v77.Velocity = Vector3.new(v78, v79, v80(-50, 40))
									v_u_4:Create(v_u_75, TweenInfo.new(math.random(1.5, 2), Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
										["Size"] = Vector3.new(0, 0, 0)
									}):Play()
									task.wait(0.1)
									v_u_75.CanCollide = true
									v_u_75.CollisionGroup = "Effects"
								else
									v_u_75:Destroy()
								end
							end)
						end
					end
				else
					for _, v81 in v_u_46:GetChildren() do
						if v81:IsA("BasePart") and v81 ~= v_u_46.Grab then
							v81:Destroy()
						end
					end
				end
				local v82 = Instance.new("Highlight", v_u_46.Grab)
				v82.FillTransparency = 1
				v82.OutlineTransparency = 1
				v_u_46.Grab.Size = Vector3.new(30, 30, 30)
				v_u_4:Create(v_u_46.Grab, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Transparency"] = 40
				}):Play()
				v_u_4:Create(v_u_46.Grab, TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
					["Size"] = Vector3.new(0, 0, 0)
				}):Play()
				v_u_12:PlaySound(v_u_8.Gojo.LapseBlue.LapseBlue, v_u_46, game.SoundService.Effect)
				v_u_4:Create(v_u_46.Zoom.PointLight, TweenInfo.new(0.3), {
					["Range"] = 30,
					["Brightness"] = 12
				}):Play()
				v_u_46.Zoom.Aura.Enabled = true
				task.wait(0.5)
				v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v_u_46, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Gojo.LapseBlue.Absorb, v_u_46, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v_u_46.Position).Magnitude < 150 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				v_u_4:Create(v_u_46.Zoom.PointLight, TweenInfo.new(0.15), {
					["Range"] = 0
				}):Play()
				v_u_46.Zoom.Aura.Enabled = false
				v_u_46.Explode.Dust:Emit(10)
				v_u_46.Explode.Hit:Emit(10)
				v_u_46.Explode.Ring:Emit(10)
				v_u_4:Create(v_u_46.Grab, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v_u_46.Grab, 0.4)
			end)
		end
	}
	v_u_11.Effects:Connect(function(p84, ...)
		-- upvalues: (copy) v_u_83
		local v85 = v_u_83[p84]
		if v85 then
			v85(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("LapseBlueService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13