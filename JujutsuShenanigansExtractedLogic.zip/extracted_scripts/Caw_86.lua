-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game.ReplicatedStorage.Sounds.Misc.Crow
local v2 = game.ReplicatedStorage.Animations.Misc.Crow
local v3 = script.Parent.Parent:WaitForChild("AnimControl")
local v_u_4 = script.Parent.Parent:WaitForChild("HumanoidRootPart")
v3:LoadAnimation(v2):Play(0)
script.Parent.OnClientEvent:Connect(function()
	-- upvalues: (copy) v_u_1, (copy) v_u_4
	local v_u_5 = v_u_1["Caw" .. math.random(1, 3)]:Clone()
	v_u_5.SoundGroup = game.SoundService.Effect
	v_u_5.Parent = v_u_4
	v_u_5:Play()
	v_u_5.Ended:Connect(function()
		-- upvalues: (copy) v_u_5
		v_u_5:Destroy()
	end)
end)