-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = typeof
return function(p2)
	-- upvalues: (copy) v_u_1
	local v3 = v_u_1(p2)
	if v3 == "table" then
		local v4 = getmetatable(p2)
		if v_u_1(v4) == "table" then
			local v5 = v4.__type
			if v5 == nil then
				return v3
			else
				return v5
			end
		else
			return v3
		end
	else
		return v3
	end
end