-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "Mokou1Controller"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_31 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				task.wait(0.1)
				v_u_10:PlaySound(v_u_7.Misc.M.Slash, v14, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p15, p16)
			-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_7, (ref) v_u_2, (ref) v_u_3
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				local v18 = v_u_6.Misc.M.Slash:Clone()
				if p16 == 1 then
					local v19 = v18.Weld
					v19.C0 = v19.C0 * CFrame.Angles(0, 0, 3.9269908169872414)
					v_u_10:PlaySound(v_u_7.Misc.M.Mokou1Voice, v17, game.SoundService.Voice)
				elseif p16 == 2 then
					local v20 = v18.Weld
					v20.C0 = v20.C0 * CFrame.Angles(0, 0, -1.3962634015954636)
				else
					local v21 = v18.Weld
					v21.C0 = v21.C0 * CFrame.Angles(0, 0, 0.7853981633974483)
				end
				v18.Weld.Part0 = v17
				v18.Parent = workspace.Effects
				v_u_2:AddItem(v18, 1)
				v18.Wind:Emit(12)
				v_u_3:Create(v18.Weld, TweenInfo.new(0.4), {
					["C1"] = v18.Weld.C1 * CFrame.Angles(0, -3.141592653589793, 0)
				}):Play()
				v_u_3:Create(v18.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0,
					["Color"] = Color3.new(1, 0, 0)
				}):Play()
				for _, v22 in v18:GetDescendants() do
					if v22:IsA("ParticleEmitter") then
						v_u_3:Create(v22, TweenInfo.new(0.4), {
							["Rate"] = 0
						}):Play()
					elseif v22:IsA("Beam") then
						v_u_3:Create(v22, TweenInfo.new(0.4), {
							["Width0"] = 0
						}):Play()
					end
				end
			end
		end,
		["Hit"] = function(p23, p24)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				v_u_10:Flash(p24, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Mahito.Soulfire.Hit, v25, game.SoundService.Effect)
				local v26 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v26.Parent = v25.RootAttachment
				v26:Emit(20)
				v_u_2:AddItem(v26, 0.4)
				if v_u_4.Character == p24 or v_u_4 == p23 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Hit2"] = function(p27, p28)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				v_u_10:Flash(p28, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Mahito.Soulfire.Hit, v29, game.SoundService.Effect)
				local v30 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v30.Parent = v29.RootAttachment
				v30:Emit(20)
				v_u_2:AddItem(v30, 0.4)
				if v_u_4.Character == p28 or v_u_4 == p27 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p32, ...)
		-- upvalues: (copy) v_u_31
		local v33 = v_u_31[p32]
		if v33 then
			v33(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("Mokou1Service")
	v_u_10 = v_u_1.GetController("FXController")
	v_u_11 = v_u_1.GetController("ToolController")
end
return v12