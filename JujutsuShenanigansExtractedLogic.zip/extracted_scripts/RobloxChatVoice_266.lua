-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	[105199432380841] = {
		["Sound"] = 136360298072269,
		["Volume"] = 0.5,
		["CD"] = 2.5,
		["Name"] = "mahito itadori"
	},
	[18680487885] = {
		["Sound"] = 78896502619972,
		["Volume"] = 0.6,
		["CD"] = 2.2,
		["Name"] = "sorry nanami"
	},
	[18257697094] = {
		["Sound"] = 83421804187475,
		["Volume"] = 1.6,
		["CD"] = 1.1,
		["Name"] = "best friend"
	},
	[129622474979733] = {
		["Sound"] = 97653793049098,
		["Volume"] = 1.3,
		["CD"] = 2,
		["Name"] = "BEST FRIEND"
	},
	[71411567772779] = {
		["Sound"] = 81647678860208,
		["Volume"] = 0.9,
		["CD"] = 4.5,
		["Name"] = "what are you mahito"
	},
	[7061193663] = {
		["Sound"] = 134720365521601,
		["Volume"] = 1.3,
		["CD"] = 3,
		["Name"] = "yo its been a while"
	},
	[7948969023] = {
		["Sound"] = 7147847068,
		["Volume"] = 1,
		["CD"] = 1.4,
		["Name"] = "yowai mo"
	},
	[7061369096] = {
		["Sound"] = 18956314488,
		["Volume"] = 1.5,
		["CD"] = 1.3,
		["Name"] = "next"
	},
	[137318879402973] = {
		["Sound"] = 91314701968093,
		["Volume"] = 1.3,
		["CD"] = 1.3,
		["Name"] = "idiot"
	},
	[99137255050147] = {
		["Sound"] = 124723824798365,
		["Volume"] = 1.5,
		["CD"] = 1.5,
		["Name"] = "you did it"
	},
	[18319797565] = {
		["Sound"] = 124478817965650,
		["Volume"] = 1.1,
		["CD"] = 1.8,
		["Name"] = "laugh"
	},
	[18370175258] = {
		["Sound"] = 109660701821480,
		["Volume"] = 1.7,
		["CD"] = 1.4,
		["Name"] = "oi"
	},
	[97871211303571] = {
		["Sound"] = 72270862303024,
		["Volume"] = 1,
		["CD"] = 0.8,
		["Name"] = "mambo"
	},
	[89667437228243] = {
		["Sound"] = 85458465816182,
		["Volume"] = 0.9,
		["CD"] = 3.3,
		["Name"] = "yujiiiii"
	},
	[15917626934] = {
		["Sound"] = 130066562156553,
		["Volume"] = 1.2,
		["CD"] = 1.2,
		["Name"] = "convergence"
	},
	[15753185070] = {
		["Sound"] = 126062298173538,
		["Volume"] = 1.2,
		["CD"] = 4.7,
		["Name"] = "apologize"
	},
	[16363777391] = {
		["Sound"] = 83353502086066,
		["Volume"] = 1,
		["CD"] = 0.5,
		["Name"] = "huh"
	},
	[18246120711] = {
		["Sound"] = 79557514967485,
		["Volume"] = 1,
		["CD"] = 1.5,
		["Name"] = "vibraslap"
	},
	[10173613362] = {
		["Sound"] = 83040544565202,
		["Volume"] = 1.5,
		["CD"] = 0.9,
		["Name"] = "nanami sigh"
	},
	[15709610550] = {
		["Sound"] = 93636313859907,
		["Volume"] = 0.9,
		["CD"] = 2.8,
		["Name"] = "filthy monkey"
	},
	[12917642257] = {
		["Sound"] = 83684170238132,
		["Volume"] = 0.7,
		["CD"] = 4,
		["Name"] = "don"
	},
	[82476745705122] = {
		["Sound"] = 133255654446521,
		["Volume"] = 0.7,
		["CD"] = 23,
		["Name"] = "heavenly ramble"
	},
	[6265242673] = {
		["Sound"] = 120491615591769,
		["Volume"] = 0.7,
		["CD"] = 1,
		["Name"] = "satoru gojo!!!"
	},
	[16159090773] = {
		["Sound"] = 136810908754750,
		["Volume"] = 0.9,
		["CD"] = 1,
		["Name"] = "for real"
	},
	[7061190867] = {
		["Sound"] = 136033743459006,
		["Volume"] = 2,
		["CD"] = 0.6,
		["Name"] = "for real"
	},
	[112599702984899] = {
		["Sound"] = 85491616155103,
		["Volume"] = 0.8,
		["CD"] = 1.2,
		["Name"] = "you cryin"
	},
	[6743603446] = {
		["Sound"] = 120433297149723,
		["Volume"] = 0.8,
		["CD"] = 1.1,
		["Name"] = "toji fushiguro"
	},
	[128755610900618] = {
		["Sound"] = 127466398361373,
		["Volume"] = 1.5,
		["CD"] = 1.2,
		["Name"] = "ganbare ganbare"
	},
	[136335654594541] = {
		["Sound"] = 113451393764801,
		["Volume"] = 0.9,
		["CD"] = 2.7,
		["Name"] = "disrespectful rush"
	},
	[131371183130808] = {
		["Sound"] = 74559114283681,
		["Volume"] = 0.9,
		["CD"] = 0.5,
		["Name"] = "somethings off"
	},
	[13997948756] = {
		["Sound"] = 93687341563646,
		["Volume"] = 1.5,
		["CD"] = 2,
		["Name"] = "angry"
	},
	[100445971002729] = {
		["Sound"] = 96682343073262,
		["Volume"] = 0.7,
		["CD"] = 5,
		["Name"] = "stand proud"
	},
	[5775509840] = {
		["Sound"] = 75909189523782,
		["Volume"] = 0.8,
		["CD"] = 2,
		["Name"] = "waste of time"
	},
	[18976119144] = {
		["Sound"] = 75069825195204,
		["Volume"] = 0.8,
		["CD"] = 1.3,
		["Name"] = "sata andagi"
	},
	[96326653225562] = {
		["Sound"] = 129765136259554,
		["Volume"] = 0.8,
		["CD"] = 1.4,
		["Name"] = "where are you going"
	},
	[78044670447386] = {
		["Sound"] = 71783048161793,
		["Volume"] = 1.5,
		["CD"] = 1.2,
		["Name"] = "idk this guy"
	}
}
return v1