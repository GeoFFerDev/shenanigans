-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "ManjiKickController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (ref) v_u_9
	local v_u_32 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			v_u_10:PlaySound(v_u_7.Itadori.ManjiKick.Startup, v13, game.SoundService.Effect)
		end,
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			v_u_10:Flash(p15, Color3.new(1, 1, 1))
			v_u_10:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v16, game.SoundService.Effect)
			if v_u_4 == p14 or v_u_4.Character == p15 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Fade"] = function(p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_6.Damage.HitGlow:Clone()
				if p17:GetScale() ~= 1 then
					v19:ScaleTo(p17:GetScale())
				end
				v19.Parent = workspace.Effects
				v_u_2:AddItem(v19, 0.5)
				for _, v20 in v19:GetChildren() do
					local v21 = p17:FindFirstChild(v20.Name)
					if v21 then
						v20.CFrame = v21.CFrame
					end
					v20.Color = Color3.new(0, 0, 0)
					v20.Anchored = true
					v20.Transparency = 0.1
					v_u_3:Create(v20, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
				v_u_10:PlaySound(v_u_7.Itadori.ManjiKick.Dodge, v18, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p22)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			v_u_10:PlaySound(v_u_7.Itadori.ManjiKick.Swing, v23, game.SoundService.Effect)
		end,
		["Slam"] = function(p24)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			v_u_10:PlaySound(v_u_7.Itadori.ManjiKick.Slam, v25, game.SoundService.Effect)
		end,
		["Wheel"] = function(p26)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v_u_28 = v_u_6.Gojo.HardHit:Clone()
				v_u_28.CFrame = v27.CFrame
				v_u_28.Ring.RotSpeed = NumberRange.new(300, 600)
				v_u_28.Ring.Speed = NumberRange.new(0.1, 20)
				v_u_28.Parent = workspace.Effects
				v_u_28.Ring.Enabled = true
				task.delay(0.4, function()
					-- upvalues: (copy) v_u_28, (ref) v_u_2
					v_u_28.Ring.Enabled = false
					v_u_2:AddItem(v_u_28, 0.5)
				end)
				v_u_10:PlaySound(v_u_7.Itadori.CursedStrikes.Spin, v27, game.SoundService.Effect)
			end
		end,
		["Crush"] = function(p29)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8
			local v30 = v_u_6.Megumi.Mahoraga.Earthquake:Clone()
			v30.Position = p29
			v30.Parent = workspace.Effects
			v30.Air:Destroy()
			v_u_3:Create(v30.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v_u_3:Create(v30.Floor.Ring2, TweenInfo.new(0.4), {
				["TimeScale"] = 0.5
			}):Play()
			v30.Floor.Ring2:Emit(10)
			v30.Floor.Wind2:Emit(15)
			v30.Floor.Dust:Emit(100)
			v_u_2:AddItem(v30, 3)
			local v31 = v_u_6.Megumi.Mahoraga.WorldSlash.mesh:Clone()
			v31.Position = p29
			v31.Decal.Transparency = 0
			v31.Mesh.Scale = Vector3.new(1, 50, 1)
			v31.Parent = v30
			v_u_3:Create(v31, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Size"] = Vector3.new(30, 40, 30),
				["CFrame"] = v31.CFrame * CFrame.Angles(0, -3.12413936106985, 0)
			}):Play()
			v_u_3:Create(v31.Mesh, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(25, 10, 25)
			}):Play()
			v_u_3:Create(v31.Decal, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v_u_2:AddItem(v31, 1)
			v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v30, game.SoundService.Effect)
			v_u_10:PlaySound(v_u_7.Mahito.WideSPStrike.Crush, v30, game.SoundService.Effect)
			v_u_10:PlaySound(v_u_7.Mahito.WideSPStrike.Crush2, v30, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p29).Magnitude < 180 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end
	}
	v_u_9.Effects:Connect(function(p33, ...)
		-- upvalues: (copy) v_u_32
		local v34 = v_u_32[p33]
		if v34 then
			v34(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("ManjiKickService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11