-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "BodyRepelController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_6, (copy) v_u_7, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (ref) v_u_10
	local v_u_63 = {
		["Start"] = function(p13, p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_6
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:PlaySound(v_u_8.Mahito.BodyRepel.Start, v15, game.SoundService.Effect)
				for _, v16 in v_u_6.Utils.Mahito.BodyRepel.BodyRepelStart:GetChildren() do
					local v17 = v16:Clone()
					v17[v16.Name].Part0 = v15
					v17.Parent = p14
					task.wait(0.03)
				end
			end
		end,
		["Clap"] = function(p18, p19)
			-- upvalues: (ref) v_u_7, (ref) v_u_5, (ref) v_u_9, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v20 = p18:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v_u_21 = v_u_7.Mahito.BodyRepel.BodyCreate:Clone()
				v_u_21.CFrame = v20.CFrame * CFrame.new(0, 0, -3)
				v_u_21.Weld.C0 = CFrame.new(0, 0, -3)
				v_u_21.Color = v_u_7.Mahito.BodyRepel.BodyRepel.Body1.Color
				v_u_21.Weld.Part0 = v20
				v_u_21.Parent = p19
				if v_u_5.Character == p18 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
				v_u_21.Attachment.Glow:Emit(1)
				v_u_21.Attachment.Wind:Emit(8)
				v_u_21.Attachment.Wind2:Emit(8)
				v_u_11:PlaySound(v_u_8.Mahito.BodyRepel.Clap, v20, game.SoundService.Effect)
				v_u_4:Create(v_u_21.Weld, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
					["C0"] = CFrame.new(0, 0, -10)
				}):Play()
				v_u_4:Create(v_u_21.Weld, TweenInfo.new(0.4, Enum.EasingStyle.Linear), {
					["C1"] = CFrame.Angles(3.141592653589793, 3.141592653589793, 0)
				}):Play()
				v_u_4:Create(v_u_21, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(3, 3, 3)
				}):Play()
				task.wait(0.2)
				v_u_4:Create(v_u_21, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
					["Size"] = Vector3.new(10, 10, 25)
				}):Play()
				p19.Destroying:Connect(function()
					-- upvalues: (copy) v_u_21, (ref) v_u_4, (ref) v_u_3, (ref) v_u_7
					v_u_21.Size = Vector3.new(15, 15, 25)
					v_u_21.Parent = workspace.Effects
					v_u_4:Create(v_u_21, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_3:AddItem(v_u_21, 0.1)
					for _ = 1, 20 do
						local v22 = v_u_7.Mahito.Morph:Clone()
						v22.Color = v_u_21.Color
						v22.CFrame = v_u_21.CFrame * CFrame.new(math.random(-v_u_21.Size.X, v_u_21.Size.X) / 2, math.random(-v_u_21.Size.Y, v_u_21.Size.Y) / 2, math.random(-v_u_21.Size.Z, v_u_21.Size.Z) / 2)
						v22.Parent = workspace.Effects
						v22.Size = Vector3.new(1, 1, 1) * (math.random(20, 40) / 10)
						local v23 = math.random(-60, 60)
						local v24 = math.random(-20, 60)
						local v25 = math.random
						v22.Velocity = Vector3.new(v23, v24, v25(-60, 60))
						v_u_4:Create(v22, TweenInfo.new(math.random(40, 60) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_3:AddItem(v22, 0.6)
					end
				end)
			end
		end,
		["Fire"] = function(p26, p_u_27, p_u_28)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_7, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_2, (ref) v_u_4
			local v_u_29 = p26:FindFirstChild("HumanoidRootPart")
			if v_u_29 then
				local v30 = v_u_6.Utils.Itadori.RushWind:Clone()
				v30.CFrame = v_u_29.CFrame
				v30.Parent = workspace.Effects
				v30.Dust:Emit(7)
				v30.Ring:Emit(7)
				v30.Dash1.Dash:Emit(1)
				v30.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v30, 2)
				local v_u_31 = v_u_7.Mahito.BodyRepel.BodyRepel:Clone()
				v_u_31:PivotTo(v_u_29.CFrame)
				v_u_31.Parent = workspace.Effects
				v_u_11:PlaySound(v_u_8.Mahito.BodyRepel.Fire, v_u_31.Head, game.SoundService.Effect)
				if v_u_5.Character == p26 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				local v_u_32 = {
					v_u_31.Body1,
					v_u_31.Body2,
					v_u_31.Body3,
					v_u_31.Body4,
					v_u_31.Body5
				}
				for v33, v34 in v_u_32 do
					v34.CFrame = v_u_31.Head.CFrame - v_u_31.Head.CFrame.LookVector * v33
				end
				task.spawn(function()
					-- upvalues: (copy) p_u_28, (copy) v_u_29, (copy) v_u_31, (copy) p_u_27
					if p_u_28 then
						repeat
							v_u_29.CFrame = v_u_29.CFrame - v_u_29.Position + v_u_31.Head.Position
							task.wait()
						until not (v_u_29.Parent and p_u_27.Parent)
					end
				end)
				local v_u_35 = false
				local v_u_36 = tick()
				local v_u_37 = p_u_27.Position
				local v_u_38 = tick()
				local v_u_39 = nil
				v_u_39 = v_u_2.Stepped:Connect(function(_, p40)
					-- upvalues: (copy) v_u_31, (ref) v_u_39, (copy) p_u_27, (ref) v_u_37, (ref) v_u_38, (copy) v_u_32, (ref) v_u_36, (ref) v_u_35, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (copy) v_u_29
					if v_u_31.Parent then
						if p_u_27.Parent then
							if v_u_37 == p_u_27.Position then
								v_u_31.Head.CFrame = p_u_27.CFrame + p_u_27.CFrame.LookVector * (120 * (tick() - v_u_38))
							else
								v_u_37 = p_u_27.Position
								v_u_38 = tick()
								v_u_31.Head.CFrame = p_u_27.CFrame
							end
						else
							local v41 = v_u_31.Head
							v41.CFrame = v41.CFrame + v_u_31.Head.CFrame.LookVector * (60 * p40)
						end
						for v42, v43 in v_u_32 do
							local v44 = v42 == 1 and v_u_31.Head or v_u_32[v42 - 1]
							local v45 = CFrame.new(v44.Position, v43.Position)
							v43.CFrame = (v45 + v45.LookVector * 7) * CFrame.Angles(0, 3.141592653589793, 0)
						end
						if v_u_36 < tick() and v_u_35 == false then
							local v46 = v_u_32[math.random(1, #v_u_32)]
							v_u_36 = tick() + math.random(2, 6) / 100
							local v_u_47 = v_u_7.Mahito.BodyRepel["Wind" .. math.random(1, 5)]:Clone()
							local v48 = v46.CFrame
							local v49 = CFrame.Angles
							local v50 = math.random(0, 360)
							v_u_47.CFrame = v48 * v49(1.5707963267948966, math.rad(v50), 0)
							v_u_4:Create(v_u_47, TweenInfo.new(0.3, Enum.EasingStyle.Quad), {
								["CFrame"] = v_u_47.CFrame + v46.CFrame.LookVector * 10,
								["Size"] = Vector3.new(12, 0, 12)
							}):Play()
							v_u_3:AddItem(v_u_47, 0.3)
							v_u_47.Parent = workspace.Effects
							v_u_4:Create(v_u_47, TweenInfo.new(0.15), {
								["Transparency"] = 0
							}):Play()
							task.delay(0.15, function()
								-- upvalues: (ref) v_u_4, (copy) v_u_47
								v_u_4:Create(v_u_47, TweenInfo.new(0.15), {
									["Transparency"] = 1
								}):Play()
							end)
						end
						if not p_u_27.Parent and v_u_35 == false then
							v_u_35 = true
							local v51 = {
								v_u_31.Head,
								v_u_31.Body1,
								v_u_31.Body2,
								v_u_31.Body3,
								v_u_31.Body4,
								v_u_31.Body5
							}
							v_u_3:AddItem(v_u_31, 1.4)
							for _, v52 in v51 do
								if (workspace.CurrentCamera.CFrame.Position - v_u_29.Position).Magnitude < 300 then
									for _ = 1, 7 do
										local v_u_53 = v_u_7.Mahito.Morph:Clone()
										v_u_53.Weld.Part0 = v52
										v_u_53.Color = v52.Color
										v_u_53.Weld.C1 = CFrame.new(math.random(-v52.Size.X, v52.Size.X) / 2, math.random(-v52.Size.Y, v52.Size.Y) / 2, math.random(-v52.Size.Z, v52.Size.Z) / 2)
										v_u_53.Parent = workspace.Effects
										v_u_53.Size = Vector3.new(1, 1, 1) * (math.random(40, 80) / 10)
										v_u_4:Create(v_u_53, TweenInfo.new(math.random(20, 40) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
											["Size"] = Vector3.new(0, 0, 0)
										}):Play()
										v_u_3:AddItem(v_u_53, 0.4)
										task.delay(0.2, function()
											-- upvalues: (copy) v_u_53
											v_u_53.Weld:Destroy()
											local v54 = v_u_53
											local v55 = math.random(-40, 40)
											local v56 = math.random(-20, 40)
											local v57 = math.random
											v54.Velocity = Vector3.new(v55, v56, v57(-40, 40))
										end)
									end
								end
								v52.Transparency = 1
								for _, v58 in v52:GetDescendants() do
									if v58:IsA("BasePart") or v58:IsA("Decal") then
										v58.Transparency = 1
									end
								end
								task.wait(0.1)
							end
						end
					else
						v_u_39:Disconnect()
					end
				end)
			end
		end,
		["Hit"] = function(p59, p60)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v61 = p60:FindFirstChild("HumanoidRootPart")
			if v61 then
				local v62 = v_u_7.Megumi.DivineAttack:Clone()
				v62.CFrame = v61.CFrame
				v62.Parent = workspace.Effects
				v62.Bite:Emit(1)
				v_u_3:AddItem(v62, 0.2)
				v_u_11:Flash(p60, Color3.fromRGB(255, 255, 255))
				v_u_11:PlaySound(v_u_8.Hakari.EnergySurge.Hit2, v61, game.SoundService.Effect)
				if v_u_5.Character == p60 or v_u_5 == p59 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p64, ...)
		-- upvalues: (copy) v_u_63
		local v65 = v_u_63[p64]
		if v65 then
			v65(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("BodyRepelService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12