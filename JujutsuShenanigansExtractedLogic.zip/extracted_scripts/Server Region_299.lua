-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 3,
	["Val"] = "Region",
	["Desc"] = "See what region the server is currently located in"
}
local v_u_2 = nil
local v_u_3 = require(game.ReplicatedStorage.Modules.Icon)
function v1.Callback(p4)
	-- upvalues: (ref) v_u_2, (copy) v_u_3
	if p4 == true and not v_u_2 then
		v_u_2 = v_u_3.new()
		v_u_2:lock()
		v_u_2:setRight()
		workspace:GetAttributeChangedSignal("ServerRegion"):Connect(function()
			-- upvalues: (ref) v_u_2
			v_u_2:setLabel(workspace:GetAttribute("ServerRegion"))
		end)
		v_u_2:setLabel(workspace:GetAttribute("ServerRegion"))
	elseif p4 == false and v_u_2 then
		v_u_2:destroy()
		v_u_2 = nil
	end
end
return v1