-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local _ = script.Parent.MoneyDestroyer5000.RemoteEvent
local v_u_1 = game.Players.LocalPlayer
local function v_u_5(p_u_2)
	-- upvalues: (copy) v_u_1
	p_u_2.Triggered:Connect(function()
		-- upvalues: (ref) v_u_1, (copy) p_u_2
		if not v_u_1.PlayerGui:FindFirstChild("BillboardEditUI") then
			local v3 = script.BillboardEditUI:Clone()
			v3.Promptobj.Value = p_u_2.Parent.Parent
			v3.Parent = v_u_1.PlayerGui
		end
	end)
	p_u_2.PromptHidden:Connect(function()
		-- upvalues: (ref) v_u_1
		local v4 = v_u_1.PlayerGui:FindFirstChild("BillboardEditUI")
		if v4 then
			v4:Destroy()
		end
	end)
end
for _, v6 in script.Parent:GetDescendants() do
	if v6.Name == "Screen" then
		v6.Parent.SurfaceGui.Adornee = v6
	elseif v6:IsA("ProximityPrompt") then
		v_u_5(v6)
	end
end
script.Parent.DescendantAdded:Connect(function(p7)
	-- upvalues: (copy) v_u_5
	if p7.Name == "Screen" then
		p7.Parent.SurfaceGui.Adornee = p7
		return
	elseif p7:IsA("ProximityPrompt") then
		v_u_5(p7)
	end
end)