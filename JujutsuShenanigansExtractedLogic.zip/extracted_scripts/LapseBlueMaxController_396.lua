-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "LapseBlueMaxController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_2, (ref) v_u_9
	local v_u_50 = {
		["Aerial"] = function(p13, p14)
			-- upvalues: (ref) v_u_11
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = p13:FindFirstChild("Humanoid")
				if v16 then
					local v17 = Instance.new("BodyGyro", v15)
					v17.P = 10000
					v17.MaxTorque = Vector3.new(40000, 40000, 40000)
					p14.Position = v15.Position + Vector3.new(0, 6, 0)
					v16.PlatformStand = true
					repeat
						local v18 = v_u_11:GetMouseTarget()
						v17.CFrame = CFrame.new(v15.Position, v18)
						task.wait()
					until not p14.Parent
					v17:Destroy()
					v16.PlatformStand = false
				end
			else
				return
			end
		end,
		["BlueGrab"] = function(p19)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_10:Flash(p19, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v20, game.SoundService.Effect)
			end
		end,
		["Blue"] = function(p_u_21, p_u_22)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_2
			local v23 = p_u_21:FindFirstChild("HumanoidRootPart")
			if v23 then
				local v_u_24 = v_u_6.Gojo.LapseBlue.LapseBlueMax:Clone()
				v_u_24.AlignPosition.Attachment1 = p_u_22
				v_u_24.Position = v23.Position + v23.CFrame.LookVector * 5
				v_u_24.Parent = workspace.Effects
				v_u_3:Create(v_u_24.PointLight, TweenInfo.new(0.5), {
					["Brightness"] = 5
				}):Play()
				v_u_3:Create(v_u_24.Startup.Paint, TweenInfo.new(0.4), {
					["TimeScale"] = 1
				}):Play()
				v_u_3:Create(v_u_24.Startup.Charge, TweenInfo.new(0.4), {
					["TimeScale"] = 1
				}):Play()
				v_u_3:Create(v_u_24, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["Size"] = Vector3.new(5, 5, 5)
				}):Play()
				local v_u_25 = v_u_10:PlaySound(v_u_7.Gojo.LapseBlue.Wind, v_u_24, game.SoundService.Effect, true)
				v_u_3:Create(v_u_25, TweenInfo.new(0.5), {
					["Volume"] = 3
				}):Play()
				v_u_3:Create(v_u_25, TweenInfo.new(1.25), {
					["Pitch"] = 2
				}):Play()
				p_u_22:GetAttributeChangedSignal("Grab"):Connect(function()
					-- upvalues: (copy) p_u_22, (copy) v_u_24, (ref) v_u_3, (ref) v_u_4, (copy) p_u_21, (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (copy) v_u_25
					if p_u_22:GetAttribute("Grab") == true then
						v_u_24.Startup.Paint.Enabled = false
						v_u_24.Startup.Charge.Enabled = false
						v_u_24.Transparency = 0
						v_u_3:Create(v_u_24, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
							["Size"] = Vector3.new(10, 10, 10)
						}):Play()
						if v_u_4.Character == p_u_21 then
							v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
							v_u_24.AlignPosition.Responsiveness = 20
						else
							v_u_24.AlignPosition.Responsiveness = 70
						end
						v_u_3:Create(v_u_24.PointLight, TweenInfo.new(0.5), {
							["Brightness"] = 15
						}):Play()
						v_u_3:Create(v_u_24, TweenInfo.new(1.5, Enum.EasingStyle.Back), {
							["Size"] = Vector3.new(10, 10, 10)
						}):Play()
						for _, v26 in v_u_24.Center:GetChildren() do
							if v26:IsA("ParticleEmitter") then
								v26.Enabled = true
							end
						end
						v_u_10:PlaySound(v_u_7.Gojo.LapseBlue.Absorb, v_u_24, game.SoundService.Effect)
					else
						v_u_24.Startup.Smoke.Enabled = false
						v_u_3:Create(v_u_25, TweenInfo.new(0.5), {
							["Volume"] = 0
						}):Play()
						v_u_3:Create(v_u_24.Center.Aura, TweenInfo.new(1), {
							["TimeScale"] = 0.4
						}):Play()
					end
				end)
				local v_u_27 = true
				p_u_22:GetAttributeChangedSignal("Purple"):Connect(function()
					-- upvalues: (copy) v_u_24, (ref) v_u_27, (ref) v_u_3, (ref) v_u_2, (ref) v_u_6, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8
					v_u_24.Anchored = true
					v_u_27 = false
					for _, v28 in v_u_24:GetDescendants() do
						if v28:IsA("ParticleEmitter") then
							v28.Enabled = false
						end
					end
					v_u_3:Create(v_u_24.PointLight, TweenInfo.new(0.4), {
						["Brightness"] = 0
					}):Play()
					v_u_2:AddItem(v_u_24, 1)
					local v29 = v_u_6.Gojo.HollowPurple.PurpleMax:Clone()
					v29.Position = v_u_24.Position
					v29.Parent = workspace.Effects
					v_u_3:Create(v29, TweenInfo.new(2.5, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
						["Size"] = Vector3.new(15, 15, 15)
					}):Play()
					v_u_3:Create(v29.PointLight, TweenInfo.new(2.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["Brightness"] = 40
					}):Play()
					v_u_10:PlaySound(v_u_7.Gojo.HollowPurple.Smash, v29, game.SoundService.Effect)
					v_u_10:PlaySound(v_u_7.Gojo.HollowPurple.Music2, v29, game.SoundService.Music)
					if (workspace.CurrentCamera.CFrame.Position - v_u_24.Position).Magnitude < 300 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
					v29.Center.Glow:Emit(1)
					task.wait(0.5)
					v29.Lightning.Enabled = true
					v_u_10:PlaySound(v_u_7.Gojo.HollowPurple.Summon, v29, game.SoundService.Effect)
					v_u_10:PlaySound(v_u_7.Gojo.HollowPurple.MaxCharge, v29, game.SoundService.Music)
					task.wait(1)
					v_u_10:PlaySound(v_u_7.Gojo.HollowPurple.Explode, v29, game.SoundService.Effect)
					task.wait(0.7)
					v29.Explode.Ring:Emit(1)
					v_u_3:Create(v29, TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Color"] = Color3.fromRGB(255, 170, 255),
						["Size"] = Vector3.new(150, 150, 150)
					}):Play()
					local v30 = Instance.new("Highlight", v29.Warp)
					v30.FillTransparency = 1
					v30.OutlineTransparency = 1
					v_u_3:Create(v29.Warp, TweenInfo.new(0.3), {
						["Transparency"] = 40
					}):Play()
					task.wait(0.3)
					v29.PointLight:Destroy()
					v29.Warp:Destroy()
					v29.Lightning.Enabled = false
					v29.Transparency = 1
					for _, v31 in v29.Center:GetChildren() do
						if v31:IsA("ParticleEmitter") then
							v31.Enabled = false
						end
					end
					v29.Explode.Hit:Emit(30)
					v29.Explode.Wind:Emit(30)
					v29.Explode.Ring2:Emit(10)
					v29.Explode.Star:Emit(80)
					v_u_2:AddItem(v29, 20)
					if (workspace.CurrentCamera.CFrame.Position - v_u_24.Position).Magnitude < 150 then
						game.Lighting.ExposureCompensation = 10
						v_u_3:Create(game.Lighting, TweenInfo.new(2), {
							["ExposureCompensation"] = 0
						}):Play()
						v_u_8.CurrentShaker:ShakeSustain(v_u_8.Presets.HeavyHit):StartFadeOut(4)
					end
				end)
				repeat
					task.wait()
				until v_u_27 == false or not p_u_22.Parent
				if v_u_27 == true then
					v_u_24.Anchored = true
					v_u_3:Create(v_u_24, TweenInfo.new(0.4, Enum.EasingStyle.Quad), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					for _, v32 in v_u_24:GetDescendants() do
						if v32:IsA("ParticleEmitter") then
							v32.Enabled = false
						end
					end
					v_u_3:Create(v_u_24.PointLight, TweenInfo.new(0.4), {
						["Brightness"] = 0
					}):Play()
					v_u_2:AddItem(v_u_24, 1)
					v_u_3:Create(v_u_25, TweenInfo.new(0.5), {
						["Volume"] = 0
					}):Play()
					v_u_3:Create(v_u_24, TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
						["Position"] = v_u_24.Position + v_u_24.Velocity / 4
					}):Play()
				end
			end
		end,
		["PurpleHit"] = function(p33)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v34 = p33:FindFirstChild("HumanoidRootPart")
			if v34 then
				v_u_10:Flash(p33, Color3.fromRGB(255, 85, 255), 2)
				v_u_10:PlaySound(v_u_7.Gojo.HollowPurple.Hit, v34, game.SoundService.Effect)
			end
		end,
		["Finisher"] = function(p35, p_u_36)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v37 = p35.HumanoidRootPart
			if v37 then
				v_u_10:PlaySound(v_u_7.Itadori.Dismantle.Explode, v37, game.SoundService.Effect)
				for _, v38 in p35:GetDescendants() do
					if v38:IsA("BasePart") or v38:IsA("Decal") then
						v38.Transparency = 1
					end
				end
				for _, v39 in p35:GetChildren() do
					if v39:IsA("BasePart") then
						for _ = 1, 2 do
							local v_u_40 = v_u_6.Damage.Chunk:Clone()
							v_u_40.CFrame = v39.CFrame
							local v41 = math.random(-80, 80)
							local v42 = math.random(-80, 80)
							local v43 = math.random
							v_u_40.Velocity = Vector3.new(v41, v42, v43(-80, 80))
							local v44 = math.random(-200, 200)
							local v45 = math.random(-200, 200)
							local v46 = math.random
							v_u_40.RotVelocity = Vector3.new(v44, v45, v46(-200, 200))
							v_u_40.Parent = p_u_36
							v_u_2:AddItem(v_u_40, 1)
							if _G.Settings.Gore == false then
								v_u_40.Color = Color3.fromRGB(255, 85, 255)
								v_u_40.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
								v_u_40.Blood.Color = v_u_40.Trail.Color
							end
							task.delay(0.2, function()
								-- upvalues: (copy) v_u_40, (copy) p_u_36, (ref) v_u_3
								local v47 = Instance.new("Attachment", v_u_40)
								local v48 = Instance.new("AlignPosition", v47)
								v48.Responsiveness = 0
								v48.Attachment0 = v47
								v48.Attachment1 = p_u_36.Parent
								v_u_3:Create(v48, TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
									["Responsiveness"] = 200
								}):Play()
							end)
						end
					end
				end
			end
		end,
		["Finisher2"] = function(p49)
			-- upvalues: (ref) v_u_10
			if p49.HumanoidRootPart then
				v_u_10:Burn(p49)
			end
		end
	}
	v_u_9.Effects:Connect(function(p51, ...)
		-- upvalues: (copy) v_u_50
		local v52 = v_u_50[p51]
		if v52 then
			v52(...)
		end
	end)
	local v_u_53 = Random.new()
	v_u_9.Debree:Connect(function(p54, p_u_55)
		-- upvalues: (copy) v_u_53, (ref) v_u_2, (ref) v_u_10, (ref) v_u_3
		if (workspace.CurrentCamera.CFrame.Position - p_u_55.Parent.WorldPosition).Magnitude > 75 then
			return
		elseif _G.Settings.DesPHY then
			for _, v56 in p54 do
				local v_u_57 = Instance.new("Part")
				v_u_57.CanCollide = false
				v_u_57.Massless = true
				v_u_57.Position = v56[1]
				v_u_57.Orientation = v56[2]
				v_u_57.Color = v56[3]
				v_u_57.Material = v56[4]
				v_u_57.Size = v56[5]
				v_u_57.Velocity = v_u_53:NextUnitVector() * v_u_53:NextInteger(60, 100)
				local v58 = math.random(-40, 40)
				local v59 = math.random(-40, 40)
				local v60 = math.random
				v_u_57.RotVelocity = Vector3.new(v58, v59, v60(-40, 40))
				v_u_57.Parent = p_u_55
				v_u_2:AddItem(v_u_57, 0.8)
				if math.random(1, 10) == 1 then
					v_u_10:DebreeSound(v_u_57)
				end
				task.delay(0.2, function()
					-- upvalues: (copy) v_u_57, (ref) v_u_3, (copy) p_u_55
					local v61 = Instance.new("Attachment", v_u_57)
					v61.Name = "BlueGrab"
					local v62 = Instance.new("AlignPosition", v61)
					v62.Responsiveness = 0
					v_u_3:Create(v62, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Responsiveness"] = 100
					}):Play()
					v62.Attachment0 = v61
					if p_u_55.Parent:IsA("Attachment") then
						v61 = p_u_55.Parent or v61
					end
					v62.Attachment1 = v61
				end)
			end
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("LapseBlueMaxService")
	v_u_10 = v_u_1.GetController("FXController")
	v_u_11 = v_u_1.GetController("ToolController")
end
return v12