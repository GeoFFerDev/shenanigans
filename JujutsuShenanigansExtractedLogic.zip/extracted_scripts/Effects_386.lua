-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("SoundService")
local v_u_7 = v1.LocalPlayer
local v_u_8 = v_u_2:WaitForChild("Utils", (1 / 0))
local v9 = v_u_2:WaitForChild("Modules", (1 / 0))
local v_u_10 = v_u_8:WaitForChild("Misc", (1 / 0))
local v_u_11 = require(v9.CameraShaker)
local v_u_12 = require(v9.BloodyZee)
local v13 = require(v_u_2.Knit.Knit)
local v_u_14 = Random.new()
local v_u_15 = workspace.Effects
local v_u_16 = workspace.CurrentCamera
local function v_u_26(p17, p18, p19)
	-- upvalues: (copy) v_u_10, (copy) v_u_15, (copy) v_u_4
	local v20 = typeof(p18)
	local v21 = v_u_10.Sounds:FindFirstChild(p17)
	if not v21 then
		local v22 = print
		local v23 = "Failed to find sound for [%s]: %s"
		if v20 == "Instance" then
			v20 = p18.Name or v20
		end
		return v22(v23:format(v20, v21))
	end
	local v24 = v21:Clone()
	local v25
	if v20 == "Instance" then
		v25 = p18
	else
		if v20 == "Vector3" then
			p18 = CFrame.new(p18) or p18
		end
		v25 = Instance.new("Part")
		v25.Anchored = true
		v25.CanCollide = false
		v25.Transparency = 1
		v25.CanCollide = false
		v25.CanQuery = false
		v25.CanTouch = false
		v25.CFrame = p18
		v25.Parent = v_u_15.CamIgnore
		v_u_4:AddItem(v25, (p19 or v24.TimeLength / v24.PlaybackSpeed) + 2)
	end
	v24.Parent = v25
	v24:Play()
	if p19 then
		v_u_4:AddItem(v24, p19)
	end
end
local function v_u_32(p27)
	local v28 = next
	local v29, v30 = p27:GetDescendants()
	for _, v31 in v28, v29, v30 do
		if v31:IsA("ParticleEmitter") then
			v31:Emit(v31:GetAttribute("EmitCount"))
		end
	end
end
local function v_u_39(p33, p34)
	local v35 = next
	local v36, v37 = p33:GetDescendants()
	for _, v38 in v35, v36, v37 do
		if v38:IsA("ParticleEmitter") then
			v38.Enabled = p34
		end
	end
end
local v_u_40 = v13.GetController("FXController")
local v_u_41 = RaycastParams.new()
v_u_41.FilterType = Enum.RaycastFilterType.Include
v_u_41.FilterDescendantsInstances = { workspace:WaitForChild("Map") }
local v_u_42 = nil
v_u_42 = {
	["UltraCoinUse"] = function(p43)
		-- upvalues: (copy) v_u_26
		local v44 = p43:FindFirstChild("HumanoidRootPart")
		if v44 then
			v_u_26("UltraCoin Use", v44)
		end
	end,
	["UltraCoinThrow"] = function(p45)
		-- upvalues: (copy) v_u_32, (copy) v_u_41, (copy) v_u_3, (copy) v_u_26, (copy) v_u_5
		v_u_32(p45)
		while p45.Parent and p45.Transparency == 0 do
			if workspace:Raycast(p45.Position + Vector3.new(0, 1, 0), Vector3.new(0, -3, 0), v_u_41) then
				local v46 = v_u_3:Create(p45.Light.PointLight, TweenInfo.new(0.25), {
					["Brightness"] = 0
				})
				v46:Play()
				v46:Destroy()
				v_u_26("UltraCoin Coin Land", p45)
				return
			end
			v_u_5.Heartbeat:Wait()
		end
	end,
	["CameraShake"] = function(p47, p48, p49)
		-- upvalues: (copy) v_u_16, (copy) v_u_11
		if p48 then
			if typeof(p48) == "CFrame" then
				p48 = p48.Position
			end
			if (p49 or 200) < (v_u_16.CFrame.Position - p48).Magnitude then
				return
			end
		end
		v_u_11.CurrentShaker:Shake(v_u_11.Presets[p47])
	end,
	["UltraCoinPiercerShoot"] = function(p50)
		-- upvalues: (copy) v_u_32, (copy) v_u_26, (copy) v_u_3
		if p50.Parent then
			v_u_32(p50)
			v_u_26("UltraCoin Shoot", p50.Handle.CFrame)
			local v51 = v_u_3:Create(p50.Handle.Light.PointLight, TweenInfo.new(0.25), {
				["Brightness"] = 0
			})
			v51:Play()
			v51:Destroy()
			p50.Handle.Light.PointLight.Enabled = true
		end
	end,
	["UltraCoinShoot"] = function(p52, _, p53, p54, p55)
		-- upvalues: (copy) v_u_15, (copy) v_u_4, (copy) v_u_3, (copy) v_u_26, (copy) v_u_10, (copy) v_u_39, (copy) v_u_32
		local v56 = p54 and (typeof(p54) == "Vector3" and p54 or p54.Position) or p52.Handle.ShootPoint.WorldCFrame.Position
		local v57 = (v56 - p53.Position).Magnitude
		local v58 = Instance.new("Part")
		v58.Parent = v_u_15
		v_u_4:AddItem(v58, 0.41)
		v58.Anchored = true
		v58.CanCollide = false
		v58.CollisionGroup = "NoCollision"
		v58.Material = Enum.Material.Neon
		v58.Size = vector.create(0.35, 0.35, v57)
		v58.CFrame = CFrame.lookAt(v56, p53.Position) * CFrame.new(0, 0, -v57 / 2)
		local v59 = v_u_3:Create(v58, TweenInfo.new(p54 and 0.6 or 0.28), {
			["Size"] = vector.create(0, 0, v57)
		})
		v59:Play()
		v59:Destroy()
		v_u_26("UltraCoin Coin Hit", p53.CFrame)
		if p54 then
			v58.Color = Color3.fromRGB(147, 130, 3)
			if typeof(p54) == "Vector3" or (not p54.Parent:FindFirstChild("Torso") or (not p54.Parent:FindFirstChild("Head") or p54.Parent.Torso:FindFirstChild("DecapitateBlood"))) then
				if typeof(p54) == "Vector3" and (p55 and p55:IsDescendantOf(workspace.Map)) then
					local v60 = v_u_10.SparksGround:Clone()
					v60.CFrame = CFrame.new(p54)
					v60.Parent = v_u_15
					v_u_4:AddItem(v60, 7)
					v_u_32(v60)
					v_u_26("UltraCoin Debris", p54)
					local v61 = v_u_3:Create(v60.Attachment.Light, TweenInfo.new(0.3), {
						["Brightness"] = 0
					})
					v61:Play()
					v61:Destroy()
					for _ = 1, math.random(4, 5) do
						local v_u_62 = Instance.new("Part")
						v_u_62.CFrame = CFrame.new(p54)
						v_u_62.Size = Vector3.new(0.01, 0.01, 0.01)
						v_u_62.CanCollide = false
						v_u_62.CanTouch = false
						v_u_62.CollisionGroup = "Effects"
						v_u_62.Color = p55.Color
						v_u_62.Material = p55.Material
						v_u_62.MaterialVariant = p55.MaterialVariant
						v_u_62.Parent = v_u_15
						v_u_4:AddItem(v_u_62, 4.5)
						local v63 = Instance.new("BodyVelocity")
						v63.MaxForce = Vector3.new(50000, 50000, 50000)
						v63.Velocity = Vector3.new(1, 0, 0) * math.random(-13, 13) + Vector3.new(0, 0, 1) * math.random(-13, 13) + Vector3.new(0, 1, 0) * math.random(6, 30)
						v63.Parent = v_u_62
						v_u_4:AddItem(v63, 0.15)
						local v64 = Instance.new("BodyAngularVelocity")
						v64.MaxTorque = Vector3.new(50000, 50000, 50000)
						local v65 = math.random(-10, 10)
						local v66 = math.random(-10, 10)
						local v67 = math.random
						v64.AngularVelocity = vector.create(v65, v66, v67(-10, 10))
						v64.Parent = v_u_62
						v_u_4:AddItem(v64, 0.2)
						task.delay(0.1, function()
							-- upvalues: (copy) v_u_62
							v_u_62.CanCollide = true
						end)
						local v68 = math.random(2, 6) / 10
						local v69 = math.random(2, 6) / 10
						local v70 = math.random(2, 6) / 10
						local v71 = {
							["Size"] = vector.create(v68, v69, v70)
						}
						local v72 = v_u_3:Create(v_u_62, TweenInfo.new(math.random(1, 5) / 10, Enum.EasingStyle.Back, Enum.EasingDirection.Out), v71)
						v72:Play()
						v72:Destroy()
						task.delay(math.random(25, 32) / 10, function()
							-- upvalues: (ref) v_u_3, (copy) v_u_62
							local v73 = v_u_3
							local v74 = v_u_62
							local v75 = TweenInfo.new(math.random(3, 11) / 10)
							local v76 = {}
							local v77 = v_u_62.Position
							local v78 = math.random(1, 15) / 10
							v76.Position = v77 + vector.create(0, v78, 0)
							v76.Size = Vector3.new(0.01, 0.01, 0.01)
							v76.Color = Color3.new(0.07, 0.07, 0.07)
							local v79 = v73:Create(v74, v75, v76)
							v79:Play()
							v79:Destroy()
						end)
					end
				end
			else
				local v80 = p54.Parent
				local v81 = v80.Torso
				local v82 = {
					Enum.AccessoryType.Face,
					Enum.AccessoryType.Hat,
					Enum.AccessoryType.Hair,
					Enum.AccessoryType.Eyebrow,
					Enum.AccessoryType.Eyelash
				}
				p54.Transparency = 1
				for _, v83 in pairs(v80:GetChildren()) do
					if v83:IsA("Accessory") and table.find(v82, v83.AccessoryType) then
						local v84 = v83:FindFirstChild("Handle", true)
						if v84 then
							v84.Transparency = 1
						end
					end
				end
				if _G.Settings.Gore then
					local v85 = v_u_10.DecapitateBlood:Clone()
					v85.Parent = v81
					task.delay(5, v_u_39, v85, false)
					v_u_4:AddItem(v85, 7)
				end
				while v80.Parent and p54.Parent do
					BloodyZee:Blood(v81.CFrame * CFrame.new(0, 0.3, 0), math.random(5, 30), 360, 360)
					task.wait(math.random(5, 15) / 100)
				end
			end
		end
	end,
	["UltraCoinHitDead"] = function(p86, p87, p88, p_u_89)
		-- upvalues: (ref) v_u_42, (copy) v_u_10, (copy) v_u_4, (copy) v_u_32, (copy) v_u_26
		task.spawn(v_u_42.UltraCoinShoot, p86, p87, p88, p_u_89.Head)
		if _G.Settings.Gore then
			local v90 = v_u_10.BloodBurst:Clone()
			v90.Parent = p_u_89.Head
			v_u_4:AddItem(v90, 5)
			v_u_32(v90)
		end
		local v_u_91 = p_u_89.Head.CFrame
		local v_u_92 = math.random(30, 32)
		local v_u_93 = 10
		local v_u_94 = 180
		local v_u_95 = 180
		local v_u_96 = 0.08
		task.spawn(function()
			-- upvalues: (copy) v_u_92, (copy) p_u_89, (copy) v_u_91, (copy) v_u_93, (copy) v_u_94, (copy) v_u_95, (copy) v_u_96
			for _ = 1, v_u_92 or 1 do
				if p_u_89 and not p_u_89.Parent then
					break
				end
				BloodyZee:Blood(v_u_91, v_u_93, v_u_94, v_u_95)
				if v_u_96 then
					task.wait(v_u_96)
				end
			end
		end)
		v_u_42.CameraShake("ViolenterBump", p_u_89.Head.Position, 60)
		v_u_26("UltraCoin Headshot", p_u_89.Head)
	end,
	["UltraCoinHitEnemy"] = function(p_u_97, p98, _)
		-- upvalues: (copy) v_u_26, (ref) v_u_42
		v_u_26("UltraCoin Hit", p98)
		local v_u_99 = CFrame.new(p98)
		local v_u_100 = math.random(10, 14)
		local v_u_101 = 15
		local v_u_102 = 180
		local v_u_103 = 180
		local v_u_104 = 0.08
		task.spawn(function()
			-- upvalues: (copy) v_u_100, (copy) p_u_97, (copy) v_u_99, (copy) v_u_101, (copy) v_u_102, (copy) v_u_103, (copy) v_u_104
			for _ = 1, v_u_100 or 1 do
				if p_u_97 and not p_u_97.Parent then
					break
				end
				BloodyZee:Blood(v_u_99, v_u_101, v_u_102, v_u_103)
				if v_u_104 then
					task.wait(v_u_104)
				end
			end
		end)
		v_u_42.CameraShake("SmallBump", p98, 60)
	end,
	["AfterImageJevil"] = function(p105, p106, p107)
		-- upvalues: (copy) v_u_14, (copy) v_u_3, (copy) v_u_15, (copy) v_u_4
		if p105:FindFirstChild("HumanoidRootPart") then
			local v108 = p105:Clone()
			v108.Humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			local v109 = v108.HumanoidRootPart.CFrame * (p106 == "Left" and CFrame.new(5, 0, 0) or CFrame.new(-5, 0, 0))
			local v110 = v_u_14:NextInteger(-0.5, 0.5)
			local v111 = v_u_14:NextInteger(-0.5, 0.5)
			local v112 = v_u_14
			local v113 = vector.create(v110, v111, v112:NextInteger(-0.5, 0.5))
			local v114 = next
			local v115, v116 = v108:GetDescendants()
			for _, v117 in v114, v115, v116 do
				if v117:IsA("BasePart") then
					v117.CanCollide = false
					v117.CanQuery = false
					v117.Anchored = true
					v117.CollisionGroup = "Effects"
					if v117.Transparency < 1 then
						v117.Transparency = 0.5
						local v118 = v_u_3:Create(v117, TweenInfo.new(0.2 / p107, Enum.EasingStyle.Linear), {
							["Transparency"] = 1,
							["CFrame"] = v109 * v108.HumanoidRootPart.CFrame:ToObjectSpace(v117.CFrame) + v113
						})
						v118:Play()
						v118:Destroy()
					end
				elseif v117:IsA("Sound") or (v117:IsA("Highlight") or v117:IsA("LuaSourceContainer")) then
					v117:Destroy()
				elseif v117:IsA("Decal") and v117.Transparency < 1 then
					local v119 = v_u_3:Create(v117, TweenInfo.new(0.2 / p107, Enum.EasingStyle.Linear), {
						["Transparency"] = 1
					})
					v119:Play()
					v119:Destroy()
				end
			end
			v108.Parent = v_u_15
			v_u_4:AddItem(v108, 0.3 / p107)
		end
	end,
	["TeleportEffect"] = function(p_u_120)
		-- upvalues: (copy) v_u_8, (copy) v_u_15, (copy) v_u_4, (copy) v_u_40, (copy) v_u_2, (copy) v_u_6, (copy) v_u_11, (copy) v_u_7, (copy) v_u_3, (copy) v_u_16, (copy) v_u_5
		local v_u_121 = v_u_8.Gojo.Teleport:Clone()
		v_u_121.CFrame = p_u_120.HumanoidRootPart.CFrame
		v_u_121.Parent = v_u_15
		v_u_4:AddItem(v_u_121, 1.1)
		v_u_121.Center.Flash:Emit(1)
		v_u_40:PlaySound(v_u_2.Sounds.Gojo.Teleport2, p_u_120.HumanoidRootPart, v_u_6.Effect)
		task.delay(0.1, function()
			-- upvalues: (copy) v_u_121, (copy) p_u_120
			v_u_121.Floor.Dust:Emit(30)
			task.wait(0.05)
			v_u_121.CFrame = p_u_120.HumanoidRootPart.CFrame
			v_u_121.Lines:Emit(30)
			v_u_121.Floor.Dust:Emit(30)
		end)
		v_u_11.CurrentShaker:Shake(v_u_11.Presets.LightHit)
		v_u_40:PlaySound(v_u_2.Sounds.Gojo.Teleport, p_u_120.HumanoidRootPart, v_u_6.Effect)
		if v_u_7.Character and v_u_7.Character == p_u_120 then
			local v122 = v_u_8.Gojo.TeleportBreak:Clone()
			v122.Parent = v_u_15
			v_u_4:AddItem(v122, 0.8)
			local v123 = Instance.new("Highlight")
			v123.OutlineTransparency = 1
			v123.FillColor = Color3.new(1, 1, 1)
			v123.FillTransparency = 0.8
			v123.Parent = v122
			for _ = 1, 30 do
				local v124 = v_u_8.Gojo.Shard:Clone()
				v124.CFrame = v122.Part.CFrame * CFrame.new(math.random(-40, 40) / 10, math.random(-20, 20) / 10, 0)
				v124.CFrame = v124.CFrame * CFrame.Angles(math.random(0, 360), math.random(0, 360), math.random(0, 360))
				v124.Parent = v122.Shards
				local v125 = v_u_3:Create(v124, TweenInfo.new(math.random(4, 7) / 10), {
					["Size"] = Vector3.new(0, 0, 0)
				})
				v125:Play()
				v125:Destroy()
				local v126 = v122.Part.CFrame * CFrame.Angles(math.random(0, 30), math.random(-30, 30), 0)
				local v127 = math.random(-5, 5)
				local v128 = math.random(-5, 5)
				local v129 = math.random
				v124.RotVelocity = vector.create(v127, v128, v129(-5, 5))
				local v130 = Instance.new("BodyVelocity")
				v130.Archivable = false
				v130.Velocity = v126.LookVector * math.random(1, 80) / 10
				v130.Parent = v124
			end
			while true do
				v122:SetPrimaryPartCFrame(v_u_16.CFrame * CFrame.new(0, 0, -2))
				for _, v131 in v122.Shards:GetChildren() do
					local v132 = v131.BodyVelocity
					v132.Velocity = v132.Velocity - Vector3.new(0, 0.25, 0)
				end
				v_u_5.RenderStepped:Wait()
				if not v122.Parent then
					goto l2
				end
			end
		else
			::l2::
			return
		end
	end,
	["Kaboom"] = function(p133)
		-- upvalues: (copy) v_u_40, (copy) v_u_2, (copy) v_u_6, (copy) v_u_11, (copy) v_u_12, (copy) v_u_8
		local v134 = p133:FindFirstChild("HumanoidRootPart")
		if v134 then
			v_u_40:PlaySound(v_u_2.Sounds.Impact.Players.MostExplodeSoundEverToGoWithMostGoreSoundEver, v134, v_u_6.Effect)
			v_u_40:PlaySound(v_u_2.Sounds.Impact.Players.MostGoreSoundEver, v134, v_u_6.Effect)
			if (workspace.CurrentCamera.CFrame.Position - v134.Position).Magnitude < 50 then
				v_u_11.CurrentShaker:Shake(v_u_11.Presets.SnapOh)
			end
			v_u_40:Bleed(p133)
			for _ = 1, 40 do
				v_u_12:Blood(p133.Torso.CFrame, 50, 360, 360)
			end
			if _G.Settings.Gore then
				local v135 = v_u_8.Heian.BloodSpread:Clone()
				v135.Parent = v134
				v135:Emit(80)
				game:GetService("Debris"):AddItem(v135, 2)
			end
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v134.Position).Magnitude > 150 then
					return
				end
				local v136 = {}
				for _, v137 in p133:GetChildren() do
					if v137:IsA("BasePart") and (v137 ~= v134 and v137.Transparency ~= 1) then
						local v138 = v137.Color
						table.insert(v136, v138)
					end
				end
				Random.new()
				TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 35 do
					local v139 = math.random(50, 200) / 100
					local v140 = v136[math.random(1, #v136)]
					local v_u_141 = v_u_8.Hiromi.GavelShard:Clone()
					v_u_141.CollisionGroup = "Effects"
					v_u_141.Position = v134.Position
					v_u_141.Size = Vector3.new(v139, 0.1, v139)
					local v142 = math.random(-90, 90)
					local v143 = math.random(-30, 90)
					local v144 = math.random
					v_u_141.Velocity = Vector3.new(v142, v143, v144(-90, 90))
					local v145 = math.random(-120, 120)
					local v146 = math.random(-120, 120)
					local v147 = math.random
					v_u_141.RotVelocity = Vector3.new(v145, v146, v147(-120, 120))
					v_u_141.Color = v140
					v_u_141.Parent = workspace.Effects
					game:GetService("Debris"):AddItem(v_u_141, 5)
					task.delay(4, function()
						-- upvalues: (copy) v_u_141
						game:GetService("TweenService"):Create(v_u_141, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
			end
		end
	end
}
return v_u_42