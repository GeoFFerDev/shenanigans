-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = Random.new()
local function v_u_25(p5, p6, p7)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_2
	local v8 = v_u_4:NextNumber(3, 4)
	local v_u_9 = v_u_4:NextNumber(0.8, 1.4)
	local v10 = p7 or (p5 == "Anchored" and 1 or v_u_4:NextNumber(0.35, 0.7))
	local v11 = v_u_4:NextNumber(0.7 * v10, 2 * v10)
	local v_u_12 = Instance.new("Part")
	v_u_3:AddItem(v_u_12, v8 + v_u_9)
	v_u_12.CollisionGroup = "NoCollision"
	local v13 = v_u_4:NextNumber(-180, 180)
	local v14 = v_u_4:NextNumber(-180, 180)
	local v15 = v_u_4
	v_u_12.Orientation = vector.create(v13, v14, v15:NextNumber(-180, 180))
	v_u_12.Position = p6.Position
	v_u_12.Size = vector.create(v11, v11, v11)
	v_u_12.Color = p6.Instance.Color
	v_u_12.Material = p6.Instance.Material
	v_u_12.MaterialVariant = p6.Instance.MaterialVariant
	if p5 == "Anchored" then
		v_u_12.Anchored = true
	else
		v_u_12.Position = v_u_12.Position + Vector3.new(0, 1, 0)
		local v16 = Instance.new("BodyVelocity")
		v_u_3:AddItem(v16, 0.125)
		local v17 = v_u_4:NextNumber(-21, 21)
		local v18 = v_u_4:NextNumber(10, 40)
		local v19 = v_u_4
		v16.Velocity = vector.create(v17, v18, v19:NextNumber(-21, 21))
		v16.Parent = v_u_12
		local v20 = Instance.new("BodyAngularVelocity")
		v_u_3:AddItem(v20, 0.5)
		local v21 = v_u_4:NextNumber(-15, 15)
		local v22 = v_u_4:NextNumber(-15, 15)
		local v23 = v_u_4
		v20.AngularVelocity = vector.create(v21, v22, v23:NextNumber(-15, 15))
		v20.Parent = v_u_12
	end
	v_u_12.Parent = workspace.Effects
	task.delay(v8, function()
		-- upvalues: (ref) v_u_2, (copy) v_u_12, (copy) v_u_9
		local v24 = v_u_2:Create(v_u_12, TweenInfo.new(v_u_9, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
			["Size"] = Vector3.new(0, 0, 0)
		})
		v24:Play()
		v24:Destroy()
	end)
end
function v1.Rocks(p26, p27, p28)
	-- upvalues: (copy) v_u_25
	local v29 = workspace:Raycast(p26, Vector3.new(-0, -5, -0), _G.MapParams)
	if v29 then
		v_u_25("Anchored", v29, p28)
		if p27 then
			v_u_25("Fling", v29, p28)
		end
	end
end
return v1