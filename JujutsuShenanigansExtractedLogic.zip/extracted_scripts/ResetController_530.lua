-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Lighting")
game:GetService("StarterGui")
local v4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v6 = v5.Animations
local _ = v5.Utils
local _ = v5.Sounds
local v_u_7 = v4:WaitForChild("PlayerGui")
require(v5.Modules.CameraShaker)
local v8 = require(v5.Modules.SraikoVFX)
require(v5.TEMP_CHARA_STUFF.VelocityHandler)
local v_u_9 = require(v5.TEMP_CHARA_STUFF.AnimationRetriever)
local v_u_10 = require(v5.TEMP_CHARA_STUFF.EffectUtility)
local v_u_11 = require(v5.TEMP_CHARA_STUFF.CameraShake)
local v_u_12 = require(v5.TEMP_CHARA_STUFF.Vignette)
require(v5.TEMP_CHARA_STUFF.RockHandler)
require(v5.TEMP_CHARA_STUFF.Smoke)
require(v5.TEMP_CHARA_STUFF.Afterimage)
require(v5.TEMP_CHARA_STUFF.MoonUtil)
local v_u_13 = require(v5.TEMP_CHARA_STUFF.RunCameraRig)
require(v5.TEMP_CHARA_STUFF.Create_Clone)
require(v5.TEMP_CHARA_STUFF.VelocityUtil)
require(v5.TEMP_CHARA_STUFF.Utility)
local v_u_14 = require(v5.TEMP_CHARA_STUFF.Yuki_FOV)
local _ = v8.Enabled
local _ = v8.Emit
local _ = v8.EmitMesh
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v18 = v_u_1.CreateController({
	["Name"] = "ResetController"
})
local v_u_19 = v6.Misc.C.Reset
local v_u_20 = game:GetService("Players").LocalPlayer
function v18.KnitStart(_)
	-- upvalues: (copy) v_u_9, (copy) v_u_19, (copy) v_u_2, (copy) v_u_10, (copy) v_u_3, (copy) v_u_20, (copy) v_u_7, (copy) v_u_2, (copy) v_u_13, (copy) v_u_14, (copy) v_u_11, (copy) v_u_12, (ref) v_u_15
	local v_u_48 = {
		["Start"] = function(p21)
			-- upvalues: (ref) v_u_9, (ref) v_u_19
			local v22 = v_u_9.new(p21, v_u_19.Windup)
			if v22 ~= nil then
				local v23 = v22.Job
				local v24 = v22.Animation
				local v_u_25 = Instance.new("Highlight")
				v_u_25.OutlineColor = Color3.new(1, 0, 0)
				v_u_25.OutlineTransparency = 0
				v_u_25.FillTransparency = 1
				v_u_25.DepthMode = Enum.HighlightDepthMode.Occluded
				v_u_25.Parent = p21
				v23:Task(v_u_25)
				v23:Task(v24:GetMarkerReachedSignal("counter"):Connect(function(p26)
					-- upvalues: (copy) v_u_25
					if p26 == "false" then
						v_u_25.OutlineTransparency = 1
					end
				end))
			end
		end,
		["Counter"] = function(p27)
			-- upvalues: (ref) v_u_9, (ref) v_u_19, (ref) v_u_2, (ref) v_u_10, (ref) v_u_3, (ref) v_u_20, (ref) v_u_7, (ref) v_u_2, (ref) v_u_13, (ref) v_u_14
			local v28 = v_u_9.new(p27, v_u_19.Windup)
			if v28 ~= nil then
				local v29 = v28.Job
				local _ = v28.Animation
				local v_u_30 = workspace:FindFirstChild("Music")
				if v_u_30 then
					v_u_30:Pause()
					v29:Task(function()
						-- upvalues: (copy) v_u_30, (ref) v_u_2
						v_u_30:Resume()
						local v31 = v_u_30.Volume
						v_u_30.Volume = 0
						v_u_2:Create(v_u_30, TweenInfo.new(5, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
							["Volume"] = v31
						}):Play()
					end)
				end
				v29:Task(v_u_10.AddSFX(script.SFX.Main, workspace.Effects))
				local v32 = CFrame.new(-20000, 0, 0)
				local v33 = script.Sky:Clone()
				v33.Parent = v_u_3
				v29:Task(v33)
				local v_u_34 = {}
				for _, v35 in ipairs({
					"Ambient",
					"Brightness",
					"ClockTime",
					"ColorShift_Top",
					"ColorShift_Bottom",
					"OutdoorAmbient"
				}) do
					v_u_34[v35] = v_u_3[v35]
				end
				v_u_3.Ambient = Color3.fromRGB(70, 70, 70)
				v_u_3.Brightness = 4.9
				v_u_3.ClockTime = 14.5
				v_u_3.ColorShift_Top = Color3.new(0, 0, 0)
				v_u_3.ColorShift_Bottom = Color3.new(0, 0, 0)
				v_u_3.OutdoorAmbient = Color3.fromRGB(197, 127, 127)
				v29:Task(function()
					-- upvalues: (copy) v_u_34, (ref) v_u_3
					for v36, v37 in pairs(v_u_34) do
						v_u_3[v36] = v37
					end
				end)
				local v38 = script.BlackBox:Clone()
				v38.CFrame = v32
				v38.Parent = workspace.Effects
				v29:Task(v38)
				local v39 = script.ScreenCover:Clone()
				v39.Enabled = true
				v39.Frame.BackgroundTransparency = 0
				v39.Parent = v_u_20.PlayerGui
				v29:Task(v39)
				local v_u_40 = script.Videos:Clone()
				v_u_40.Name = "CharaVideos"
				v_u_40.Parent = v_u_7
				v29:Task(v_u_40)
				local v_u_41 = script.Chara:Clone()
				v_u_41:PivotTo(v32)
				v_u_41.Parent = workspace.Effects
				v29:Task(v_u_41)
				local v42 = v_u_41:WaitForChild("Humanoid")
				local v43 = v42:WaitForChild("Animator"):LoadAnimation(v_u_19.Start)
				v_u_2:Create(v39.Frame, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
					["BackgroundTransparency"] = 1
				}):Play()
				local v44 = script.Camera:Clone()
				v44:PivotTo(v_u_41:GetPivot() - Vector3.new(0, 3, 0))
				v44.Parent = workspace.Effects
				v29:Task(v44)
				v29:Task(v_u_13(v42.RootPart, v44, CFrame.new(0, -3, 0)))
				v29:Task((v_u_14.AnimateWithMoonFile(script.FOV)))
				v44.Humanoid.Animator:LoadAnimation(v_u_19.Camera):Play(0)
				v29:Task(v43:GetMarkerReachedSignal("end"):Connect(function()
					-- upvalues: (copy) v_u_40
					v_u_40.Frame.BackgroundTransparency = 0
				end))
				v29:Task(task.delay(9.35, function()
					-- upvalues: (copy) v_u_41
					v_u_41.Head.Face.Decal.Transparency = 1
					v_u_41.scaryface.Transparency = 0
				end))
				v29:Task(task.delay(10.666666666666666, function()
					-- upvalues: (copy) v_u_40
					v_u_40.Frame.Slash.Visible = true
					v_u_40.Frame.Slash:Play()
					v_u_40.Frame.Slash.Ended:Once(function()
						-- upvalues: (ref) v_u_40
						v_u_40.Frame.Slash.Visible = false
					end)
				end))
				v29:Task(task.delay(11.833333333333334, function()
					-- upvalues: (copy) v_u_40
					v_u_40.Frame.Slash.Visible = false
					v_u_40.Frame.Slash:Pause()
					v_u_40.Frame["999"].Visible = true
					v_u_40.Frame["999"]:Play()
					v_u_40.Frame["999"].Ended:Once(function()
						-- upvalues: (ref) v_u_40
						v_u_40.Frame["999"].Visible = false
					end)
				end))
				v43:Play(0)
				task.wait(13)
				v29:Clean()
			end
		end,
		["Explosion"] = function(p45)
			-- upvalues: (ref) v_u_20, (ref) v_u_11, (ref) v_u_12, (ref) v_u_10
			if v_u_20:DistanceFromCharacter(p45) <= 100 then
				v_u_11(6, 60, 0.01, 2, Vector3.new(1, 1, 1), Vector3.new(0.5, 0.5, 0.5))
				v_u_12(Color3.fromRGB(255, 0, 0), 0.5, 1)
			end
			local v46 = Instance.new("Attachment")
			v46.WorldPosition = p45
			v46.Parent = workspace.Effects
			task.delay(6, v46.Destroy, v46)
			v_u_10.AddSFX(script.SFX.Explosion.Second, v46)
			v_u_10.AddSFX(script.SFX.Explosion.Second_2, v46)
			local v47 = script.Explosion.Boom:Clone()
			v47:PivotTo(CFrame.new(p45) + Vector3.new(0, 10, 0))
			v47.Parent = workspace.Effects
			v_u_10.Emit(v47)
		end
	}
	v_u_15.Effects:Connect(function(p49, ...)
		-- upvalues: (ref) v_u_48
		local v50 = v_u_48[p49]
		if v50 then
			v50(...)
		end
	end)
end
function v18.KnitInit(_)
	-- upvalues: (ref) v_u_15, (copy) v_u_1, (ref) v_u_16, (ref) v_u_17
	v_u_15 = v_u_1.GetService("ResetService")
	v_u_16 = v_u_1.GetController("HitboxController")
	v_u_17 = v_u_1.GetController("FXController")
end
return v18