-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "AbsoluteDestructionController"
})
function v12.KnitStart(_)
	-- upvalues: (copy) v_u_7, (ref) v_u_11, (copy) v_u_3, (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_38 = {
		["Start"] = function(p13, p14, p_u_15)
			-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_3
			local v16 = p13:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v_u_17 = v_u_11:PlaySound(p14 and v_u_7.Mechamaru.AbsoluteDestruction.Jump or v_u_7.Mechamaru.AbsoluteDestruction.Run, v16, game.SoundService.Effect)
				if not p14 and p_u_15 then
					local v_u_18 = nil
					v_u_18 = p_u_15:GetAttributeChangedSignal("Footsteps"):Connect(function()
						-- upvalues: (copy) p_u_15, (ref) v_u_18, (ref) v_u_3, (ref) v_u_17
						if not p_u_15:GetAttribute("Footsteps") then
							v_u_18:Disconnect()
							v_u_3:Create(v_u_17, TweenInfo.new(0.5), {
								["Volume"] = 0
							}):Play()
						end
					end)
				end
			end
		end,
		["Step"] = function(p19, p20)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			if p20 then
				local v21 = v_u_6.Mechamaru.Dust:Clone()
				v21.bigimpact:Destroy()
				v21.Smoke2:Destroy()
				v21.Position = p20
				v21.Parent = workspace.Effects
				v_u_2:AddItem(v21, 1)
				for _, v22 in v21:GetChildren() do
					v22:Emit(v22:GetAttribute("EmitCount") / 4)
				end
			end
			if v_u_4.Character == p19 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Jump"] = function(p23, p24)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v25 = p23:FindFirstChild("HumanoidRootPart")
			if v25 then
				v_u_11:PlaySound(v_u_7.Mechamaru.AbsoluteDestruction.Jump, v25, game.SoundService.Effect)
			end
			if p24 then
				local v26 = workspace:Raycast(p24 + Vector3.new(0, 3, 0), Vector3.new(0, -10, 0), _G.MapParams)
				if v26 then
					local v27 = v_u_6.Mechamaru.Dust:Clone()
					v27.bigimpact:Destroy()
					v27.Position = p24
					v27.Parent = workspace.Effects
					v_u_2:AddItem(v27, 2)
					for _, v28 in v27:GetDescendants() do
						if v28.Name == "Smoke2" then
							v28.Color = ColorSequence.new(v26.Instance.Color)
							v28:Emit(20)
						else
							v28:Emit(v28:GetAttribute("EmitCount") / 2)
						end
					end
				end
			end
			if v_u_4.Character == p23 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Slam"] = function(p29, p30)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			if p30 then
				local v31 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v31.Transparency = 0
				v31.Size = Vector3.new(30, 60, 30)
				v31.Position = p30
				v31.Parent = workspace.Effects
				v_u_2:AddItem(v31, 0.4)
				v_u_3:Create(v31, TweenInfo.new(0.4), {
					["Transparency"] = 1,
					["Size"] = Vector3.new(70, 0, 70),
					["Position"] = v31.Position - Vector3.new(0, 30, 0)
				}):Play()
				local v32 = v_u_6.Mechamaru.BigSlam:Clone()
				v32.Position = p30
				v32.Parent = workspace.Effects
				v_u_2:AddItem(v32, 3)
				for _, v33 in v32:GetDescendants() do
					v33:Emit(v33:GetAttribute("EmitCount"))
				end
				v_u_11:PlaySound(v_u_7.Mechamaru.AbsoluteDestruction.Slam, v32, game.SoundService.Effect)
			end
			if v_u_4.Character == p29 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Hit2"] = function(p34, p35)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v36 = p34:FindFirstChild("HumanoidRootPart")
			if v36 then
				v_u_11:Flash(p34, p35 or Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Hakari.EnergySurge.Hit1, v36, game.SoundService.Effect)
				local v37 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v37.Position = v36.Position
				v37.Parent = workspace.Effects
				v_u_2:AddItem(v37, 1)
				v37.Sparks.Color = ColorSequence.new(p35 or Color3.new(1, 1, 1))
				v37.Wind.Color = v37.Sparks.Color
				v37.Wind2.Color = v37.Sparks.Color
				v37.Sparks:Emit(50)
				v37.Wind:Emit(7)
				v37.Wind2:Emit(7)
			end
		end
	}
	v_u_9.Effects:Connect(function(p39, ...)
		-- upvalues: (copy) v_u_38
		local v40 = v_u_38[p39]
		if v40 then
			v40(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("AbsoluteDestructionService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12