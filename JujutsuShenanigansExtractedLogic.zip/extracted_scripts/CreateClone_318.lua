-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.TEMP_CHARA_STUFF.EffectUtility)
return function(p3, p4)
	-- upvalues: (copy) v_u_2
	local v5 = script.Model:Clone()
	v5.Archivable = false
	v5.Name = "CHARACTER_CLONE"
	local v6 = v5:FindFirstChild("Humanoid")
	local v7 = v5:FindFirstChild("HumanoidRootPart")
	if not p4 then
		local v8 = Instance.new("Highlight")
		v8.DepthMode = Enum.HighlightDepthMode.Occluded
		v8.FillColor = Color3.fromRGB(42, 136, 150)
		v8.FillTransparency = 13
		v8.OutlineColor = Color3.fromRGB(255, 0, 0)
		v8.OutlineTransparency = 0.6
		v8.Parent = v5
	end
	local v9 = next
	local v10, v11 = v5:QueryDescendants("BasePart")
	for _, v12 in v9, v10, v11 do
		v12.CollisionGroup = "NoCollision"
		v12.CanCollide = false
		v12.CanTouch = false
		v12.CanQuery = false
		v12.Massless = true
		v12.CastShadow = false
	end
	v_u_2.Weld(v5, p3.PrimaryPart)
	v5:PivotTo(p3:GetPivot())
	return v5, v6, v7
end