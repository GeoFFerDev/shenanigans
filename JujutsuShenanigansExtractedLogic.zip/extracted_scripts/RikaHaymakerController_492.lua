-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v2 = game.ReplicatedStorage
local _ = v2.Animations
local _ = v2.Utils
local v_u_3 = v2.Sounds
require(v2.Modules.CameraShaker)
require(v2.Modules.BloodyZee)
local v_u_4 = nil
local v_u_5 = nil
local v6 = v_u_1.CreateController({
	["Name"] = "RikaHaymakerController"
})
function v6.KnitStart(_)
	-- upvalues: (ref) v_u_5, (copy) v_u_3
	local v_u_8 = {
		["StartSound"] = function(p7)
			-- upvalues: (ref) v_u_5, (ref) v_u_3
			v_u_5:PlaySound(v_u_3.Yuta.Rika.Haymaker, p7, game.SoundService.Effect)
		end
	}
	RikaHaymakerService.Effects:Connect(function(p9, ...)
		-- upvalues: (copy) v_u_8
		local v10 = v_u_8[p9]
		if v10 then
			v10(...)
		end
	end)
end
function v6.KnitInit(_)
	-- upvalues: (copy) v_u_1, (ref) v_u_4, (ref) v_u_5
	RikaHaymakerService = v_u_1.GetService("RikaHaymakerService")
	v_u_4 = v_u_1.GetController("HitboxController")
	v_u_5 = v_u_1.GetController("FXController")
end
return v6