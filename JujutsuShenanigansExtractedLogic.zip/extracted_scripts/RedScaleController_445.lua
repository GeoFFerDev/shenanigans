-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "RedScaleController"
})
function v12.KnitStart(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (ref) v_u_11, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_5, (copy) v_u_3, (ref) v_u_9
	local v_u_52 = {
		["Leap"] = function(p13, p14)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v_u_16 = v_u_6.Gojo.HardHit.Ring:Clone()
				v_u_16.RotSpeed = NumberRange.new(300, 600)
				v_u_16.Speed = NumberRange.new(0.1, 20)
				v_u_16.Enabled = true
				v_u_16.Parent = p13.Torso
				task.delay(0.3, function()
					-- upvalues: (copy) v_u_16, (ref) v_u_2
					v_u_16.Enabled = false
					v_u_2:AddItem(v_u_16, 0.5)
				end)
				p14.Position = v15.Position + Vector3.new(0, 12, 0)
				v_u_11:PlaySound(v_u_7.Itadori.CursedStrikes.Spin, v15, game.SoundService.Effect)
				v_u_11:ArmFlash(p13["Right Leg"], Color3.fromRGB(170, 0, 0), 0.9)
			end
		end,
		["Crush"] = function(p17, p18)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v19 = v_u_6.Itadori.CrushingBlow:Clone()
			v19.Position = p18
			v19.PointLight:Destroy()
			v19.Air:Destroy()
			v19.Parent = workspace.Effects
			v19.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 0, 0))
			v19.Floor.Sparks.Color = ColorSequence.new(Color3.new(1, 0, 0))
			v19.Floor.Ring:Emit(10)
			v19.Floor.Sparks:Emit(10)
			v19.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v19, 1.5)
			v_u_11:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v19, game.SoundService.Effect)
			if v_u_4 == p17 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Launch"] = function(p20, p21)
			local v22 = p20:FindFirstChild("HumanoidRootPart")
			if v22 then
				if p21 then
					local v23 = v22.Position - p21.Position
					local v24 = (1 - v23.Magnitude / 20) * 200
					local v25 = v23.Unit * v24
					local v26 = v25.X
					local v27 = v25.Y
					local v28 = math.clamp(v27, -100, 100)
					local v29 = v25.Z
					local v30 = Vector3.new(v26, v28, v29)
					v22.Velocity = v22.Velocity + v30
				else
					v22.Velocity = Vector3.new(0, 150, 0)
				end
			else
				return
			end
		end,
		["Swing"] = function(p31)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v32 = p31:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_11:PlaySound(v_u_7.Itadori.CursedStrikes.Startup, v32, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p33, p_u_34)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3, (ref) v_u_11, (ref) v_u_7
			local v_u_35 = p33:FindFirstChild("HumanoidRootPart")
			if v_u_35 then
				local v36 = Instance.new("Model")
				local v37 = v_u_5.Utils.Itadori.RushWind:Clone()
				v37.CFrame = p_u_34 * CFrame.new(0, -1, 0)
				v37.Parent = v36
				v36.Parent = workspace.Effects
				v36:ScaleTo(0.6)
				v37.Ring:Emit(7)
				v37.Dash1.Dash:Emit(1)
				v37.Dash2.Dash:Emit(1)
				v_u_2:AddItem(v36, 2)
				local v38 = v_u_6.Itadori.Shock:Clone()
				v38.CFrame = p_u_34 * CFrame.Angles(1.5707963267948966, 0, 0)
				v38.Parent = workspace.Effects
				v_u_3:Create(v38, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v38, 0.2)
				task.delay(0.1, function()
					-- upvalues: (ref) v_u_6, (copy) p_u_34, (copy) v_u_35, (ref) v_u_3, (ref) v_u_2
					local v39 = v_u_6.Itadori.Shock:Clone()
					v39.CFrame = (p_u_34 - p_u_34.Position + v_u_35.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
					v39.Parent = workspace.Effects
					v_u_3:Create(v39, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v39, 0.2)
				end)
				v_u_11:ArmFlash(p33["Left Arm"], Color3.fromRGB(170, 0, 0), 0.3)
				v_u_11:PlaySound(v_u_7.Itadori.Rush.Rush, v_u_35, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Gojo.ReversalRed.Aim, v_u_35, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p40, p41, p42, p43)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v44 = p41:FindFirstChild("HumanoidRootPart")
			if v44 then
				v_u_11:Flash(p41, Color3.new(1, 1, 1))
				if p42 then
					v_u_11:PlaySound(v_u_7.Itadori.CursedStrikes.Hit, v44, game.SoundService.Effect)
				else
					v_u_11:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit" .. math.random(1, 4)), v44, game.SoundService.Effect)
				end
				if v_u_4.Character == p40 or v_u_4.Character == p41 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
				if p40 then
					if p42 then
						v_u_11:ArmFlash(p40["Right Arm"], Color3.fromRGB(170, 0, 0), 0.4)
						v_u_11:ArmFlash(p40["Left Arm"], Color3.fromRGB(170, 0, 0), 0.4)
						return
					elseif p43 == 1 then
						v_u_11:ArmFlash(p40["Left Leg"], Color3.fromRGB(170, 0, 0), 0.4)
						local v45 = v_u_6.Mahito.BodyRepel.Wind5:Clone()
						v45.CFrame = v44.CFrame * CFrame.Angles(0.7853981633974483, 0, 0)
						v45.Size = Vector3.new(2, 5, 2)
						v45.Transparency = 0
						v45.Parent = workspace.Effects
						v_u_3:Create(v45, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(12, 0, 12),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v45, 0.2)
					elseif p43 == 2 then
						v_u_11:ArmFlash(p40["Right Leg"], Color3.fromRGB(170, 0, 0), 0.8)
					end
				else
					return
				end
			else
				return
			end
		end,
		["FinalHit"] = function(p46, p47, p48)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2
			local v49 = p46:FindFirstChild("HumanoidRootPart")
			local v50 = p47:FindFirstChild("HumanoidRootPart")
			v_u_11:Flash(p47, Color3.new(1, 1, 1))
			v_u_11:PlaySound(v_u_7.Itadori.CursedStrikes.Hit, v50, game.SoundService.Effect)
			if v_u_4.Character == p46 or v_u_4.Character == p47 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
			if p48 then
				v_u_11:PlaySound(v_u_7.Choso.BloodBurst2, v49, game.SoundService.Effect)
				local v51 = v_u_6.Choso.BloodExplode:Clone()
				v51.Position = v50.Position
				v51.Parent = workspace.Effects
				v51.Blood:Emit(30)
				v51.Burst:Emit(1)
				v51.Wind:Emit(6)
				v_u_2:AddItem(v51, 2)
			end
		end
	}
	v_u_9.Effects:Connect(function(p53, ...)
		-- upvalues: (copy) v_u_52
		local v54 = v_u_52[p53]
		if v54 then
			v54(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("RedScaleService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12