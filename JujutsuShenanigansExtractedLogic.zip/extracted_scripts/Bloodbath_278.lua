-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 7,
	["Desc"] = "paint the world red"
}
local v_u_2 = require(game.ReplicatedStorage.Modules.BloodyZee)
function v1.Callback(p3)
	-- upvalues: (copy) v_u_2
	v_u_2.PermBlood = p3
	if p3 ~= true then
		for _, v4 in workspace.Effects.Blood:GetChildren() do
			if v4.Name == "Pool" then
				v4:Destroy()
			end
		end
	end
end
return v1