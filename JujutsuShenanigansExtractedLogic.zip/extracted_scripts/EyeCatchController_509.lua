-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "EyeCatchController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (ref) v_u_9
	local v_u_20 = {
		["Hit"] = function(p12, p13)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			v_u_10:Flash(p13, Color3.new(1, 1, 1))
			v_u_10:PlaySound(v_u_7.Charles.EyeCatch.Hit, v14, game.SoundService.Effect)
			if v_u_4 == p12 or v_u_4.Character == p13 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Fade"] = function(p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = v_u_6.Damage.HitGlow:Clone()
				if p15:GetScale() ~= 1 then
					v17:ScaleTo(p15:GetScale())
				end
				v17.Parent = workspace.Effects
				v_u_2:AddItem(v17, 0.5)
				for _, v18 in v17:GetChildren() do
					local v19 = p15:FindFirstChild(v18.Name)
					if v19 then
						v18.CFrame = v19.CFrame
					end
					v18.Color = Color3.new(0, 0, 0)
					v18.Anchored = true
					v18.Transparency = 0.1
					v_u_3:Create(v18, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
				v_u_10:PlaySound(v_u_7.Itadori.ManjiKick.Dodge, v16, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Charles.EyeCatch.Dodge, v16, game.SoundService.Effect)
			end
		end
	}
	v_u_9.Effects:Connect(function(p21, ...)
		-- upvalues: (copy) v_u_20
		local v22 = v_u_20[p21]
		if v22 then
			v22(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("EyeCatchService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11