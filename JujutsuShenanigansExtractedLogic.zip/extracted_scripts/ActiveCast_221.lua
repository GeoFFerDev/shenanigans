-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

require(script.Parent.TypeDefinitions)
local v_u_1 = require(script.Parent.TypeMarshaller)
local v_u_2 = {}
v_u_2.__index = v_u_2
v_u_2.__type = "ActiveCast"
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(script.Parent.Table)
local v_u_5 = nil
function DbgVisualizeSegment(p6, p7)
	-- upvalues: (ref) v_u_5
	if v_u_5.VisualizeCasts ~= true then
		return nil
	end
	local v8 = Instance.new("ConeHandleAdornment")
	v8.Adornee = workspace.Terrain
	v8.CFrame = p6
	v8.Height = p7
	v8.Color3 = Color3.new()
	v8.Radius = 0.25
	v8.Transparency = 0.5
	local v9 = workspace.Terrain:FindFirstChild("FastCastVisualizationObjects")
	if v9 == nil then
		v9 = Instance.new("Folder")
		v9.Name = "FastCastVisualizationObjects"
		v9.Archivable = false
		v9.Parent = workspace.Terrain
	end
	v8.Parent = v9
	return v8
end
function DbgVisualizeHit(p10, p11)
	-- upvalues: (ref) v_u_5
	if v_u_5.VisualizeCasts ~= true then
		return nil
	end
	local v12 = Instance.new("SphereHandleAdornment")
	v12.Adornee = workspace.Terrain
	v12.CFrame = p10
	v12.Radius = 0.4
	v12.Transparency = 0.25
	v12.Color3 = p11 == false and Color3.new(0.2, 1, 0.5) or Color3.new(1, 0.2, 0.2)
	local v13 = workspace.Terrain:FindFirstChild("FastCastVisualizationObjects")
	if v13 == nil then
		v13 = Instance.new("Folder")
		v13.Name = "FastCastVisualizationObjects"
		v13.Archivable = false
		v13.Parent = workspace.Terrain
	end
	v12.Parent = v13
	return v12
end
local function v_u_27(p14, p15)
	local v16 = p14.StateInfo.UpdateConnection ~= nil
	assert(v16, "This ActiveCast has been terminated. It can no longer be used.")
	local v17 = p14.StateInfo.Trajectories[p15]
	local v18 = v17.EndTime - v17.StartTime
	local v19 = v17.Origin
	local v20 = v17.InitialVelocity
	local v21 = v17.Acceleration
	local v22 = {}
	local v23 = v21.X * v18 ^ 2 / 2
	local v24 = v21.Y * v18 ^ 2 / 2
	local v25 = v21.Z * v18 ^ 2 / 2
	local v26 = Vector3.new(v23, v24, v25)
	__set_list(v22, 1, {v19 + v20 * v18 + v26, v20 + v21 * v18})
	return v22
end
local function v_u_94(p28, p29, p30)
	-- upvalues: (ref) v_u_5, (copy) v_u_4
	local v31 = p28.StateInfo.UpdateConnection ~= nil
	assert(v31, "This ActiveCast has been terminated. It can no longer be used.")
	if v_u_5.DebugLogging == true then
		print("Casting for frame.")
	end
	local v32 = p28.StateInfo.Trajectories[#p28.StateInfo.Trajectories]
	local v33 = v32.Origin
	local v34 = p28.StateInfo.TotalRuntime - v32.StartTime
	local v35 = v32.InitialVelocity
	local v36 = v32.Acceleration
	local v37 = v36.X * v34 ^ 2 / 2
	local v38 = v36.Y * v34 ^ 2 / 2
	local v39 = v36.Z * v34 ^ 2 / 2
	local v40 = Vector3.new(v37, v38, v39)
	local v41 = v33 + v35 * v34 + v40
	local _ = v35 + v36 * v34
	local v42 = p28.StateInfo.TotalRuntime - v32.StartTime
	local v43 = p28.StateInfo
	v43.TotalRuntime = v43.TotalRuntime + p29
	local v44 = p28.StateInfo.TotalRuntime - v32.StartTime
	local v45 = v36.X * v44 ^ 2 / 2
	local v46 = v36.Y * v44 ^ 2 / 2
	local v47 = v36.Z * v44 ^ 2 / 2
	local v48 = Vector3.new(v45, v46, v47)
	local v49 = v33 + v35 * v44 + v48
	local v50 = v35 + v36 * v44
	local v51 = (v49 - v41).Unit * v50.Magnitude * p29
	local v52 = p28.RayInfo.WorldRoot
	local v53 = v52:Raycast(v41, v51, p28.RayInfo.Parameters)
	local v54 = Enum.Material.Air
	Vector3.new()
	local v55, v56
	if v53 == nil then
		v55 = v49
		v56 = nil
	else
		v55 = v53.Position
		v56 = v53.Instance
		v54 = v53.Material
		local _ = v53.Normal
	end
	local v57 = (v55 - v41).Magnitude
	local v58 = v51.Unit
	local v59 = p28.RayInfo.CosmeticBulletObject
	p28.Caster.LengthChanged:Fire(p28, v41, v58, v57, v50, v59)
	local v60 = p28.StateInfo
	v60.DistanceCovered = v60.DistanceCovered + v57
	local v61
	if p29 > 0 then
		v61 = DbgVisualizeSegment(CFrame.new(v41, v41 + v51), v57)
	else
		v61 = nil
	end
	if v56 and v56 ~= p28.RayInfo.CosmeticBulletObject then
		tick()
		if v_u_5.DebugLogging == true then
			print("Hit something, testing now.")
		end
		if p28.RayInfo.CanPierceCallback ~= nil then
			if p30 == false and p28.StateInfo.IsActivelySimulatingPierce then
				p28:Terminate()
				error("ERROR: The latest call to CanPierceCallback took too long to complete! This cast is going to suffer desyncs which WILL cause unexpected behavior and errors. Please fix your performance problems, or remove statements that yield (e.g. wait() calls)")
			end
			p28.StateInfo.IsActivelySimulatingPierce = true
		end
		if p28.RayInfo.CanPierceCallback == nil or p28.RayInfo.CanPierceCallback ~= nil and p28.RayInfo.CanPierceCallback(p28, v53, v50, p28.RayInfo.CosmeticBulletObject) == false then
			if v_u_5.DebugLogging == true then
				print("Piercing function is nil or it returned FALSE to not pierce this hit.")
			end
			p28.StateInfo.IsActivelySimulatingPierce = false
			if p28.StateInfo.HighFidelityBehavior == 2 and (v32.Acceleration ~= Vector3.new() and p28.StateInfo.HighFidelitySegmentSize ~= 0) then
				p28.StateInfo.CancelHighResCast = false
				if p28.StateInfo.IsActivelyResimulating then
					p28:Terminate()
					error("Cascading cast lag encountered! The caster attempted to perform a high fidelity cast before the previous one completed, resulting in exponential cast lag. Consider increasing HighFidelitySegmentSize.")
				end
				p28.StateInfo.IsActivelyResimulating = true
				if v_u_5.DebugLogging == true then
					print("Hit was registered, but recalculation is on for physics based casts. Recalculating to verify a real hit...")
				end
				local v62 = v57 / p28.StateInfo.HighFidelitySegmentSize
				local v63 = math.floor(v62)
				local _ = v57 / v63
				local v64 = p29 / v63
				for v65 = 1, v63 do
					if p28.StateInfo.CancelHighResCast then
						p28.StateInfo.CancelHighResCast = false
						break
					end
					local v66 = v42 + v64 * v65
					local v67 = v36.X * v66 ^ 2 / 2
					local v68 = v36.Y * v66 ^ 2 / 2
					local v69 = v36.Z * v66 ^ 2 / 2
					local v70 = Vector3.new(v67, v68, v69)
					local v71 = v33 + v35 * v66 + v70
					local v72 = v35 + v36 * (v42 + v64 * v65)
					local v73 = v52:Raycast(v71, v72 * p29, p28.RayInfo.Parameters)
					local v74 = (v71 - (v71 + v72)).Magnitude
					if v73 == nil then
						local v75 = DbgVisualizeSegment(CFrame.new(v71, v71 + v72), v74)
						if v75 ~= nil then
							v75.Color3 = Color3.new(0.286275, 0.329412, 0.247059)
						end
					else
						local v76 = (v71 - v73.Position).Magnitude
						local v77 = DbgVisualizeSegment(CFrame.new(v71, v71 + v72), v76)
						if v77 ~= nil then
							v77.Color3 = Color3.new(0.286275, 0.329412, 0.247059)
						end
						if p28.RayInfo.CanPierceCallback == nil or p28.RayInfo.CanPierceCallback ~= nil and p28.RayInfo.CanPierceCallback(p28, v73, v72, p28.RayInfo.CosmeticBulletObject) == false then
							p28.StateInfo.IsActivelyResimulating = false
							local v78 = p28.RayInfo.CosmeticBulletObject
							p28.Caster.RayHit:Fire(p28, v73, v72, v78)
							p28:Terminate()
							local v79 = DbgVisualizeHit(CFrame.new(v55), false)
							if v79 ~= nil then
								v79.Color3 = Color3.new(0.0588235, 0.87451, 1)
							end
							return
						end
						local v80 = p28.RayInfo.CosmeticBulletObject
						p28.Caster.RayPierced:Fire(p28, v73, v72, v80)
						local v81 = DbgVisualizeHit(CFrame.new(v55), true)
						if v81 ~= nil then
							v81.Color3 = Color3.new(1, 0.113725, 0.588235)
						end
						if v77 ~= nil then
							v77.Color3 = Color3.new(0.305882, 0.243137, 0.329412)
						end
					end
				end
				p28.StateInfo.IsActivelyResimulating = false
			else
				if p28.StateInfo.HighFidelityBehavior == 1 or p28.StateInfo.HighFidelityBehavior == 3 then
					if v_u_5.DebugLogging == true then
						print("Hit was successful. Terminating.")
					end
					local v82 = p28.RayInfo.CosmeticBulletObject
					p28.Caster.RayHit:Fire(p28, v53, v50, v82)
					p28:Terminate()
					DbgVisualizeHit(CFrame.new(v55), false)
					return
				end
				p28:Terminate()
				error("Invalid value " .. p28.StateInfo.HighFidelityBehavior .. " for HighFidelityBehavior.")
			end
		else
			if v_u_5.DebugLogging == true then
				print("Piercing function returned TRUE to pierce this part.")
			end
			if v61 ~= nil then
				v61.Color3 = Color3.new(0.4, 0.05, 0.05)
			end
			DbgVisualizeHit(CFrame.new(v55), true)
			local v83 = p28.RayInfo.Parameters
			local v84 = v83.FilterDescendantsInstances
			local v85 = {}
			local v86 = false
			local v87 = 0
			while true do
				if v53.Instance:IsA("Terrain") then
					if v54 == Enum.Material.Water then
						p28:Terminate()
						error("Do not add Water as a piercable material. If you need to pierce water, set cast.RayInfo.Parameters.IgnoreWater = true instead", 0)
					end
					warn("WARNING: The pierce callback for this cast returned TRUE on Terrain! This can cause severely adverse effects.")
				end
				if v83.FilterType == Enum.RaycastFilterType.Blacklist then
					local v88 = v83.FilterDescendantsInstances
					v_u_4.insert(v88, v53.Instance)
					v_u_4.insert(v85, v53.Instance)
					v83.FilterDescendantsInstances = v88
				else
					local v89 = v83.FilterDescendantsInstances
					v_u_4.removeObject(v89, v53.Instance)
					v_u_4.insert(v85, v53.Instance)
					v83.FilterDescendantsInstances = v89
				end
				local v90 = p28.RayInfo.CosmeticBulletObject
				p28.Caster.RayPierced:Fire(p28, v53, v50, v90)
				v53 = v52:Raycast(v41, v51, v83)
				if v53 == nil then
					break
				end
				if v87 >= 100 then
					warn("WARNING: Exceeded maximum pierce test budget for a single ray segment (attempted to test the same segment " .. 100 .. " times!)")
					break
				end
				v87 = v87 + 1
				if p28.RayInfo.CanPierceCallback(p28, v53, v50, p28.RayInfo.CosmeticBulletObject) == false then
					v86 = true
					break
				end
			end
			p28.RayInfo.Parameters.FilterDescendantsInstances = v84
			p28.StateInfo.IsActivelySimulatingPierce = false
			if v86 then
				local v91 = v53.Instance
				local v92 = "Broke because the ray hit something solid (" .. tostring(v91) .. ") while testing for a pierce. Terminating the cast."
				if v_u_5.DebugLogging == true then
					print(v92)
				end
				local v93 = p28.RayInfo.CosmeticBulletObject
				p28.Caster.RayHit:Fire(p28, v53, v50, v93)
				p28:Terminate()
				DbgVisualizeHit(CFrame.new(v53.Position), false)
				return
			end
		end
	end
	if p28.StateInfo.DistanceCovered >= p28.RayInfo.MaxDistance then
		p28:Terminate()
		DbgVisualizeHit(CFrame.new(v49), false)
	end
end
function v_u_2.new(p95, p96, p97, p98, p99)
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_2, (ref) v_u_5, (copy) v_u_94
	if v_u_1(p98) == "number" then
		p98 = p97.Unit * p98
	end
	if p99.HighFidelitySegmentSize <= 0 then
		error("Cannot set FastCastBehavior.HighFidelitySegmentSize <= 0!", 0)
	end
	local v_u_100 = {
		["Caster"] = p95,
		["StateInfo"] = {
			["UpdateConnection"] = nil,
			["Paused"] = false,
			["TotalRuntime"] = 0,
			["DistanceCovered"] = 0,
			["HighFidelitySegmentSize"] = p99.HighFidelitySegmentSize,
			["HighFidelityBehavior"] = p99.HighFidelityBehavior,
			["IsActivelySimulatingPierce"] = false,
			["IsActivelyResimulating"] = false,
			["CancelHighResCast"] = false,
			["Trajectories"] = {
				{
					["StartTime"] = 0,
					["EndTime"] = -1,
					["Origin"] = p96,
					["InitialVelocity"] = p98,
					["Acceleration"] = p99.Acceleration
				}
			}
		},
		["RayInfo"] = {
			["Parameters"] = p99.RaycastParams,
			["WorldRoot"] = workspace,
			["MaxDistance"] = p99.MaxDistance or 1000,
			["CosmeticBulletObject"] = p99.CosmeticBulletTemplate,
			["CanPierceCallback"] = p99.CanPierceFunction
		},
		["UserData"] = {}
	}
	if v_u_100.StateInfo.HighFidelityBehavior == 2 then
		v_u_100.StateInfo.HighFidelityBehavior = 3
	end
	if v_u_100.RayInfo.Parameters == nil then
		v_u_100.RayInfo.Parameters = RaycastParams.new()
	else
		local v101 = v_u_100.RayInfo
		local v102 = v_u_100.RayInfo.Parameters
		local v103 = RaycastParams.new()
		v103.CollisionGroup = v102.CollisionGroup
		v103.FilterType = v102.FilterType
		v103.FilterDescendantsInstances = v102.FilterDescendantsInstances
		v103.RespectCanCollide = v102.RespectCanCollide
		v103.IgnoreWater = v102.IgnoreWater
		v101.Parameters = v103
	end
	if p99.CosmeticBulletProvider == nil then
		if v_u_100.RayInfo.CosmeticBulletObject ~= nil then
			v_u_100.RayInfo.CosmeticBulletObject = v_u_100.RayInfo.CosmeticBulletObject:Clone()
			v_u_100.RayInfo.CosmeticBulletObject.CFrame = CFrame.new(p96, p96 + p97)
			v_u_100.RayInfo.CosmeticBulletObject.Parent = p99.CosmeticBulletContainer
		end
	elseif v_u_1(p99.CosmeticBulletProvider) == "PartCache" then
		if v_u_100.RayInfo.CosmeticBulletObject ~= nil then
			warn("Do not define FastCastBehavior.CosmeticBulletTemplate and FastCastBehavior.CosmeticBulletProvider at the same time! The provider will be used, and CosmeticBulletTemplate will be set to nil.")
			v_u_100.RayInfo.CosmeticBulletObject = nil
			p99.CosmeticBulletTemplate = nil
		end
		v_u_100.RayInfo.CosmeticBulletObject = p99.CosmeticBulletProvider:GetPart()
		v_u_100.RayInfo.CosmeticBulletObject.CFrame = CFrame.new(p96, p96 + p97)
	else
		warn("FastCastBehavior.CosmeticBulletProvider was not an instance of the PartCache module (an external/separate model)! Are you inputting an instance created via PartCache.new? If so, are you on the latest version of PartCache? Setting FastCastBehavior.CosmeticBulletProvider to nil.")
		p99.CosmeticBulletProvider = nil
	end
	local v104
	if v_u_3:IsClient() then
		v104 = v_u_3.RenderStepped
	else
		v104 = v_u_3.Heartbeat
	end
	local v105 = v_u_2
	setmetatable(v_u_100, v105)
	v_u_100.StateInfo.UpdateConnection = v104:Connect(function(p106)
		-- upvalues: (copy) v_u_100, (ref) v_u_5, (ref) v_u_94
		if v_u_100.StateInfo.Paused then
			return
		end
		if v_u_5.DebugLogging == true then
			print("Casting for frame.")
		end
		local v107 = v_u_100.StateInfo.Trajectories[#v_u_100.StateInfo.Trajectories]
		if v_u_100.StateInfo.HighFidelityBehavior == 3 and (v107.Acceleration ~= Vector3.new() and v_u_100.StateInfo.HighFidelitySegmentSize > 0) then
			local v108 = tick()
			if v_u_100.StateInfo.IsActivelyResimulating then
				v_u_100:Terminate()
				error("Cascading cast lag encountered! The caster attempted to perform a high fidelity cast before the previous one completed, resulting in exponential cast lag. Consider increasing HighFidelitySegmentSize.")
			end
			v_u_100.StateInfo.IsActivelyResimulating = true
			local v109 = v107.Origin
			local v110 = v_u_100.StateInfo.TotalRuntime - v107.StartTime
			local v111 = v107.InitialVelocity
			local v112 = v107.Acceleration
			local v113 = v112.X * v110 ^ 2 / 2
			local v114 = v112.Y * v110 ^ 2 / 2
			local v115 = v112.Z * v110 ^ 2 / 2
			local v116 = Vector3.new(v113, v114, v115)
			local v117 = v109 + v111 * v110 + v116
			local _ = v111 + v112 * v110
			local _ = v_u_100.StateInfo.TotalRuntime - v107.StartTime
			local v118 = v_u_100.StateInfo
			v118.TotalRuntime = v118.TotalRuntime + p106
			local v119 = v_u_100.StateInfo.TotalRuntime - v107.StartTime
			local v120 = v112.X * v119 ^ 2 / 2
			local v121 = v112.Y * v119 ^ 2 / 2
			local v122 = v112.Z * v119 ^ 2 / 2
			local v123 = Vector3.new(v120, v121, v122)
			local v124 = v109 + v111 * v119 + v123
			local v125 = v111 + v112 * v119
			local v126 = (v124 - v117).Unit * v125.Magnitude * p106
			local v127 = v_u_100.RayInfo.WorldRoot:Raycast(v117, v126, v_u_100.RayInfo.Parameters)
			if v127 ~= nil then
				v124 = v127.Position
			end
			local v128 = (v124 - v117).Magnitude
			local v129 = v_u_100.StateInfo
			v129.TotalRuntime = v129.TotalRuntime - p106
			local v130 = v128 / v_u_100.StateInfo.HighFidelitySegmentSize
			local v131 = math.floor(v130)
			local v132 = v131 == 0 and 1 or v131
			local v133 = p106 / v132
			for v134 = 1, v132 do
				local v135 = v_u_100
				if getmetatable(v135) == nil then
					return
				end
				if v_u_100.StateInfo.CancelHighResCast then
					v_u_100.StateInfo.CancelHighResCast = false
					break
				end
				local v136 = "[" .. v134 .. "] Subcast of time increment " .. v133
				if v_u_5.DebugLogging == true then
					print(v136)
				end
				v_u_94(v_u_100, v133, true)
			end
			local v137 = v_u_100
			if getmetatable(v137) == nil then
				return
			end
			v_u_100.StateInfo.IsActivelyResimulating = false
			if tick() - v108 > 0.08 then
				warn("Extreme cast lag encountered! Consider increasing HighFidelitySegmentSize.")
				return
			end
		else
			v_u_94(v_u_100, p106, false)
		end
	end)
	return v_u_100
end
function v_u_2.SetStaticFastCastReference(p138)
	-- upvalues: (ref) v_u_5
	v_u_5 = p138
end
local function v_u_149(p139, p140, p141, p142)
	-- upvalues: (copy) v_u_27, (copy) v_u_4
	local v143 = p139.StateInfo.Trajectories
	local v144 = v143[#v143]
	if v144.StartTime == p139.StateInfo.TotalRuntime then
		if p140 == nil then
			p140 = v144.InitialVelocity
		end
		if p141 == nil then
			p141 = v144.Acceleration
		end
		if p142 == nil then
			p142 = v144.Origin
		end
		v144.Origin = p142
		v144.InitialVelocity = p140
		v144.Acceleration = p141
	else
		v144.EndTime = p139.StateInfo.TotalRuntime
		local v145 = p139.StateInfo.UpdateConnection ~= nil
		assert(v145, "This ActiveCast has been terminated. It can no longer be used.")
		local v146 = v_u_27(p139, #p139.StateInfo.Trajectories)
		local v147, v148 = unpack(v146)
		if p140 == nil then
			p140 = v148
		end
		if p141 == nil then
			p141 = v144.Acceleration
		end
		if p142 ~= nil then
			v147 = p142
		end
		v_u_4.insert(p139.StateInfo.Trajectories, {
			["StartTime"] = p139.StateInfo.TotalRuntime,
			["EndTime"] = -1,
			["Origin"] = v147,
			["InitialVelocity"] = p140,
			["Acceleration"] = p141
		})
		p139.StateInfo.CancelHighResCast = true
	end
end
function v_u_2.SetVelocity(p150, p151)
	-- upvalues: (copy) v_u_2, (copy) v_u_149
	local v152 = getmetatable(p150) == v_u_2
	assert(v152, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("SetVelocity", "ActiveCast.new(...)"))
	local v153 = p150.StateInfo.UpdateConnection ~= nil
	assert(v153, "This ActiveCast has been terminated. It can no longer be used.")
	v_u_149(p150, p151, nil, nil)
end
function v_u_2.SetAcceleration(p154, p155)
	-- upvalues: (copy) v_u_2, (copy) v_u_149
	local v156 = getmetatable(p154) == v_u_2
	assert(v156, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("SetAcceleration", "ActiveCast.new(...)"))
	local v157 = p154.StateInfo.UpdateConnection ~= nil
	assert(v157, "This ActiveCast has been terminated. It can no longer be used.")
	v_u_149(p154, nil, p155, nil)
end
function v_u_2.SetPosition(p158, p159)
	-- upvalues: (copy) v_u_2, (copy) v_u_149
	local v160 = getmetatable(p158) == v_u_2
	assert(v160, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("SetPosition", "ActiveCast.new(...)"))
	local v161 = p158.StateInfo.UpdateConnection ~= nil
	assert(v161, "This ActiveCast has been terminated. It can no longer be used.")
	v_u_149(p158, nil, nil, p159)
end
function v_u_2.GetVelocity(p162)
	-- upvalues: (copy) v_u_2
	local v163 = getmetatable(p162) == v_u_2
	assert(v163, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("GetVelocity", "ActiveCast.new(...)"))
	local v164 = p162.StateInfo.UpdateConnection ~= nil
	assert(v164, "This ActiveCast has been terminated. It can no longer be used.")
	local v165 = p162.StateInfo.Trajectories[#p162.StateInfo.Trajectories]
	local v166 = p162.StateInfo.TotalRuntime - v165.StartTime
	return v165.InitialVelocity + v165.Acceleration * v166
end
function v_u_2.GetAcceleration(p167)
	-- upvalues: (copy) v_u_2
	local v168 = getmetatable(p167) == v_u_2
	assert(v168, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("GetAcceleration", "ActiveCast.new(...)"))
	local v169 = p167.StateInfo.UpdateConnection ~= nil
	assert(v169, "This ActiveCast has been terminated. It can no longer be used.")
	return p167.StateInfo.Trajectories[#p167.StateInfo.Trajectories].Acceleration
end
function v_u_2.GetPosition(p170)
	-- upvalues: (copy) v_u_2
	local v171 = getmetatable(p170) == v_u_2
	assert(v171, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("GetPosition", "ActiveCast.new(...)"))
	local v172 = p170.StateInfo.UpdateConnection ~= nil
	assert(v172, "This ActiveCast has been terminated. It can no longer be used.")
	local v173 = p170.StateInfo.Trajectories[#p170.StateInfo.Trajectories]
	local v174 = p170.StateInfo.TotalRuntime - v173.StartTime
	local v175 = v173.Origin
	local v176 = v173.InitialVelocity
	local v177 = v173.Acceleration
	local v178 = v177.X * v174 ^ 2 / 2
	local v179 = v177.Y * v174 ^ 2 / 2
	local v180 = v177.Z * v174 ^ 2 / 2
	local v181 = Vector3.new(v178, v179, v180)
	return v175 + v176 * v174 + v181
end
function v_u_2.AddVelocity(p182, p183)
	-- upvalues: (copy) v_u_2
	local v184 = getmetatable(p182) == v_u_2
	assert(v184, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("AddVelocity", "ActiveCast.new(...)"))
	local v185 = p182.StateInfo.UpdateConnection ~= nil
	assert(v185, "This ActiveCast has been terminated. It can no longer be used.")
	p182:SetVelocity(p182:GetVelocity() + p183)
end
function v_u_2.AddAcceleration(p186, p187)
	-- upvalues: (copy) v_u_2
	local v188 = getmetatable(p186) == v_u_2
	assert(v188, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("AddAcceleration", "ActiveCast.new(...)"))
	local v189 = p186.StateInfo.UpdateConnection ~= nil
	assert(v189, "This ActiveCast has been terminated. It can no longer be used.")
	p186:SetAcceleration(p186:GetAcceleration() + p187)
end
function v_u_2.AddPosition(p190, p191)
	-- upvalues: (copy) v_u_2
	local v192 = getmetatable(p190) == v_u_2
	assert(v192, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("AddPosition", "ActiveCast.new(...)"))
	local v193 = p190.StateInfo.UpdateConnection ~= nil
	assert(v193, "This ActiveCast has been terminated. It can no longer be used.")
	p190:SetPosition(p190:GetPosition() + p191)
end
function v_u_2.Pause(p194)
	-- upvalues: (copy) v_u_2
	local v195 = getmetatable(p194) == v_u_2
	assert(v195, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Pause", "ActiveCast.new(...)"))
	local v196 = p194.StateInfo.UpdateConnection ~= nil
	assert(v196, "This ActiveCast has been terminated. It can no longer be used.")
	p194.StateInfo.Paused = true
end
function v_u_2.Resume(p197)
	-- upvalues: (copy) v_u_2
	local v198 = getmetatable(p197) == v_u_2
	assert(v198, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Resume", "ActiveCast.new(...)"))
	local v199 = p197.StateInfo.UpdateConnection ~= nil
	assert(v199, "This ActiveCast has been terminated. It can no longer be used.")
	p197.StateInfo.Paused = false
end
function v_u_2.Terminate(p200)
	-- upvalues: (copy) v_u_2
	local v201 = getmetatable(p200) == v_u_2
	assert(v201, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Terminate", "ActiveCast.new(...)"))
	local v202 = p200.StateInfo.UpdateConnection ~= nil
	assert(v202, "This ActiveCast has been terminated. It can no longer be used.")
	local v203 = p200.StateInfo.Trajectories
	v203[#v203].EndTime = p200.StateInfo.TotalRuntime
	p200.StateInfo.UpdateConnection:Disconnect()
	p200.Caster.CastTerminating:FireSync(p200)
	p200.StateInfo.UpdateConnection = nil
	p200.Caster = nil
	p200.StateInfo = nil
	p200.RayInfo = nil
	p200.UserData = nil
	setmetatable(p200, nil)
end
return v_u_2