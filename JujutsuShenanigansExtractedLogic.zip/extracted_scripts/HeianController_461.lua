-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "HeianController"
})
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_10, (copy) v_u_7, (copy) v_u_2, (ref) v_u_11, (ref) v_u_12
	local v_u_98 = {
		["Hit"] = function(p15, p16)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_13:Flash(p15, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. p16), v17, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p18, p19)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v20 = p18:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = p19:FindFirstChild("HumanoidRootPart")
				if v21 then
					v_u_13:Flash(p19, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit3"), v21, game.SoundService.Effect)
					local v22 = v_u_8.ChaseHit:Clone()
					local v23 = CFrame.new
					local v24 = v21.Position
					local v25 = v20.Position.X
					local v26 = v21.Position.Y
					local v27 = v20.Position.Z
					v22.CFrame = v23(v24, (Vector3.new(v25, v26, v27))) * CFrame.Angles(0, 3.141592653589793, 0)
					v22.Parent = workspace.Effects
					v22.Ring:Emit(7)
					v22.Sparks:Emit(12)
					v_u_3:AddItem(v22, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p28)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			local v29 = p28.HumanoidRootPart
			if v29 then
				local v30 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v30.CFrame = v29.CFrame * CFrame.new(0, 1, -4)
				v30.Size = Vector3.new(0, 0, 2)
				v30.Parent = workspace.Effects
				v_u_4:Create(v30, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v30, 0.3)
				v_u_13:PlaySound(v_u_9.Misc.Chase, v29, game.SoundService.Effect)
				v_u_13:DustTrail(p28, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p31)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v32 = p31:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v32, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p33, p34, p35)
			-- upvalues: (ref) v_u_13
			if p34 == 1 or (p34 == 3 or p35 == "Up") then
				v_u_13:ArmFlash(p33["Right Arm"], Color3.fromRGB(85, 0, 0))
				return
			elseif p34 == 2 then
				v_u_13:ArmFlash(p33["Left Arm"], Color3.fromRGB(85, 0, 0))
			elseif p34 == 4 then
				v_u_13:ArmFlash(p33["Right Leg"], Color3.fromRGB(85, 0, 0), p35 == "Down" and 0.4 or false)
			end
		end,
		["Launch"] = function(p36, p37)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v38 = p36:FindFirstChild("HumanoidRootPart")
			if v38 then
				local v39 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v39.CFrame = CFrame.new(v38.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v39.Size = Vector3.new(0, 0, 5)
				v39.Parent = workspace.Effects
				v_u_4:Create(v39, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v39.Position + Vector3.new(0, p37, 0)
				}):Play()
				v_u_3:AddItem(v39, 0.3)
				if p37 < 0 then
					v_u_13:PlaySound(v_u_9.Megumi.Mahoraga.Throw.Break, v38, game.SoundService.Effect)
					v_u_13:DustBreak(v38.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v38.Position) < 20 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
				end
			end
		end,
		["Startup"] = function(p40)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4
			local v41 = p40:FindFirstChild("HumanoidRootPart")
			if v41 then
				v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Voice, v41, game.SoundService.Voice)
				v_u_13:DomainBurst(v41)
				v_u_13:Domain(p40, function(p42, p43)
					-- upvalues: (ref) v_u_7, (ref) v_u_4
					p43.Humanoid:LoadAnimation(v_u_7.Heian.DomainWarn):Play(0)
					p42.Panel.ImageLabel.Image = "rbxassetid://17668583842"
					local v44 = p43.HumanoidRootPart
					v44.CFrame = v44.CFrame * CFrame.Angles(0, 0, 0.17453292519943295)
					v_u_4:Create(p43.HumanoidRootPart, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["CFrame"] = p43.HumanoidRootPart.CFrame * CFrame.Angles(0, -0.3490658503988659, 0.3490658503988659)
					}):Play()
					p42.Panel.Viewport.LightColor = Color3.fromRGB(255, 155, 155)
					p42.Panel.Viewport.Ambient = Color3.fromRGB(0, 0, 0)
					p42.Panel.Viewport.LightDirection = Vector3.new(1, 0, 1)
				end)
			end
		end,
		["Chant"] = function(p45, p46)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_7, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v47 = p45:FindFirstChild("HumanoidRootPart")
			if v47 then
				local v48 = v_u_8.Heian.Chant.Attachment:Clone()
				v48.Parent = v47
				v_u_3:AddItem(v48, 2)
				v48.Dust:Emit(50)
				v48.Ring:Emit(10)
				v48.Attachment.Burst:Emit(1)
				v48.Attachment.Ring:Emit(1)
				local v_u_49 = v_u_8.Heian.Chant.Chant:Clone()
				v_u_49.Parent = v47
				v_u_3:AddItem(v_u_49, 1)
				v_u_4:Create(v_u_49, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
					["StudsOffset"] = Vector3.new(2, 4, 2)
				}):Play()
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_49
					v_u_4:Create(v_u_49.Chat, TweenInfo.new(0.5), {
						["ImageTransparency"] = 1
					}):Play()
					v_u_4:Create(v_u_49.Chat.Sub, TweenInfo.new(0.5), {
						["TextTransparency"] = 1
					}):Play()
				end)
				local v50 = p45.SetAssets:FindFirstChild("HeianArms")
				if v50 then
					local v51 = v50:FindFirstChild("HeianArmsModel")
					if not v51 then
						return
					end
					v51.Humanoid:LoadAnimation(v_u_7.Heian.ChantArms):Play(0)
				end
				if p46 == 1 then
					v_u_13:Flash(p45, Color3.fromRGB(255, 255, 255), 2)
					v_u_13:PlaySound(v_u_9.Itadori.Dismantle.WorldSlash1, v47, game.SoundService.Effect)
					return
				elseif p46 == 2 then
					v_u_13:Flash(p45, Color3.fromRGB(255, 255, 127), 2)
					v_u_13:PlaySound(v_u_9.Itadori.Dismantle.WorldSlash2, v47, game.SoundService.Effect)
					v_u_49.Chat.Sub.Text = "RECOIL..."
					return
				elseif p46 == 3 then
					v_u_13:Flash(p45, Color3.fromRGB(255, 85, 0), 2)
					v_u_13:PlaySound(v_u_9.Itadori.Dismantle.WorldSlash1, v47, game.SoundService.Effect)
					v_u_49.Chat.Sub.Text = "TWIN METEORS."
				elseif p46 == 4 then
					v_u_13:Flash(p45, Color3.fromRGB(255, 0, 0), 2)
					v_u_13:PlaySound(v_u_9.Heian.WorldSlash3, v47, game.SoundService.Effect)
					v_u_49:Destroy()
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					v_u_13:PlaySound(v_u_9.Heian.Dismantle.WCSCharge, v47, game.SoundService.Effect)
					task.wait(0.3)
					v_u_13:PlaySound(v_u_9.Heian.Dismantle.Start, v47, game.SoundService.Effect)
					v_u_13:PlaySound(v_u_9.Heian.Dismantle4, v47, game.SoundService.Voice)
				end
			else
				return
			end
		end,
		["Interp"] = function(p_u_52)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_10, (ref) v_u_2
			local v_u_53 = p_u_52.CFrame
			local v_u_54 = tick()
			local v_u_55 = p_u_52:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_53, (copy) p_u_52, (ref) v_u_54
				v_u_53 = p_u_52.CFrame
				v_u_54 = tick()
			end)
			v_u_13:PlaySound(v_u_9.Heian.Dismantle.FireWCS, p_u_52, game.SoundService.Effect)
			v_u_13:PlaySound(v_u_9.Heian.Dismantle.Fire, p_u_52, game.SoundService.Effect)
			v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
			local v_u_56 = nil
			v_u_56 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_52, (ref) v_u_56, (copy) v_u_55, (ref) v_u_53, (ref) v_u_54
				if p_u_52.Parent then
					workspace:BulkMoveTo({ p_u_52 }, { v_u_53 + v_u_53.LookVector * (300 * (tick() - v_u_54)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_56:Disconnect()
					v_u_55:Disconnect()
				end
			end)
		end,
		["DebreeOverlay"] = function(p_u_57, _, p58)
			-- upvalues: (ref) v_u_8, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10, (ref) v_u_3, (ref) v_u_4
			local v59 = {}
			for v60, _ in p58 do
				local v61 = Color3.fromHex
				table.insert(v59, v61(v60))
			end
			local v62 = workspace.CurrentCamera
			local v63 = tick() + 20
			local v64 = v_u_8.Heian.Slashes:Clone()
			v64.Parent = workspace.Effects
			v64.Position = v62.CFrame.Position
			local v65 = {}
			local v_u_66 = true
			local function v70(p67)
				-- upvalues: (ref) v_u_8, (ref) v_u_13, (ref) v_u_9, (ref) v_u_66, (copy) p_u_57
				local v68 = p67.HumanoidRootPart
				local v69 = v_u_8.Itadori.MalevolantShrine.Hit:Clone()
				v69.Parent = workspace.Effects
				v69.Weld.Part1 = v68
				while true do
					task.wait(math.random(10, 20) / 100)
					if not v68.Parent then
						break
					end
					v_u_13:PlaySound(v_u_9.Itadori.Dismantle.Slash, v68, game.SoundService.Effect)
					if not v_u_66 or (p67:GetAttribute("Dead") or (p_u_57:GetAttribute("Dead") or not (p_u_57.Parent and v68.Parent))) then
						break
					end
				end
				v69:Destroy()
				if p67:GetAttribute("Dead") and v68.Parent then
					v_u_13:PlaySound(v_u_9.Itadori.Dismantle.Explode, v68, game.SoundService.Effect)
					v_u_13:Bleed(p67)
				end
			end
			local v71 = v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.HeavyHit)
			local v72 = v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Slashes, workspace, game.SoundService.Effect)
			v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Voice3, workspace, game.SoundService.Voice)
			while true do
				v64.Position = v62.CFrame.Position + v62.CFrame.LookVector * 100
				for _, v73 in workspace.Characters:GetChildren() do
					if v73:FindFirstChild("HumanoidRootPart") and (not v65[v73] and v73 ~= p_u_57) then
						v65[v73] = true
						task.spawn(v70, v73)
					end
				end
				if _G.Settings.DesPHY then
					for _ = 1, 8 do
						local v_u_74 = v_u_8.Damage.DebreeRef:Clone()
						local v75 = math.random(5, 80) / 10
						local v76 = math.random(5, 80) / 10
						v_u_74.Size = Vector3.new(v75, 2, v76)
						v_u_74.CFrame = v62.CFrame * CFrame.new(math.random(-120, 120) / 10, math.random(-80, 80) / 10, 10)
						v_u_74.CollisionGroup = "Effects"
						v_u_74.Anchored = false
						local v77 = v62.CFrame * CFrame.Angles(math.random(-90, 90), math.random(-90, 90), math.random(-90, 90))
						v_u_74.Color = v59[math.random(1, #v59)]
						task.delay(1.4, function()
							-- upvalues: (copy) v_u_74
							if v_u_74.Parent then
								v_u_74:Destroy()
							end
						end)
						v_u_74.Velocity = v77.LookVector * math.random(100, 400)
						local v78 = math.random(-300, 300)
						local v79 = math.random(-300, 300)
						local v80 = math.random
						v_u_74.RotVelocity = Vector3.new(v78, v79, v80(-300, 300))
						v_u_74.Parent = workspace.Effects
					end
				end
				task.wait(0.025)
				if v63 < tick() or (not p_u_57.Parent or p_u_57:GetAttribute("Dead")) then
					v_u_66 = false
					v64.Slash1.Enabled = false
					v64.Slash2.Enabled = false
					v64.Sparks.Enabled = false
					v_u_3:AddItem(v64, 1)
					if v71 then
						v71:StartFadeOut(1)
					end
					if v72 then
						v_u_4:Create(v72, TweenInfo.new(1.5), {
							["Volume"] = 0
						}):Play()
					end
					return
				end
			end
		end,
		["DomainOpen"] = function(p_u_81, _)
			-- upvalues: (ref) v_u_8, (ref) v_u_5, (ref) v_u_13, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10, (ref) v_u_3
			local v_u_82 = p_u_81:FindFirstChild("HumanoidRootPart")
			if v_u_82 then
				local v_u_83 = tick() + 25.5
				local v_u_84 = v_u_8.Heian.DomainFade:Clone()
				v_u_84.Parent = v_u_5.PlayerGui
				v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.UhohStart, workspace, game.SoundService.Effect)
				local v_u_85 = v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Music, workspace, game.SoundService.Music, true)
				v_u_84.BG.BackgroundTransparency = 1
				v_u_4:Create(v_u_84.BG, TweenInfo.new(0.2), {
					["BackgroundTransparency"] = 0
				}):Play()
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_84, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (copy) p_u_81, (copy) v_u_82, (ref) v_u_8, (ref) v_u_3, (copy) v_u_83, (copy) v_u_85
					v_u_4:Create(v_u_84.BG.Bubble, TweenInfo.new(1.2), {
						["ImageTransparency"] = 1
					}):Play()
					v_u_4:Create(v_u_84.BG.Bubble.Texta, TweenInfo.new(1.2), {
						["TextTransparency"] = 1
					}):Play()
					v_u_13:PlaySound(v_u_9.Itadori.MalevolantShrine.Ring, workspace, game.SoundService.Effect)
					task.wait(1.2)
					v_u_84.BG.Visible = false
					v_u_84.Frame1.Visible = true
					v_u_84.Frame2.Visible = true
					v_u_5.PlayerGui.Main.Enabled = false
					local v_u_86 = Instance.new("ColorCorrectionEffect", game.Lighting)
					v_u_86.Brightness = -1
					v_u_13:DomainMapFade(Color3.new(1, 0, 0), 0, 0.5)
					task.delay(0.5, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_86
						v_u_4:Create(v_u_86, TweenInfo.new(0.5), {
							["Brightness"] = 0,
							["Saturation"] = -0.5
						}):Play()
					end)
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
					v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Uhoh, workspace, game.SoundService.Effect)
					if p_u_81:GetAttribute("Moveset") == "Heian" then
						v_u_13:PlaySound(v_u_9.Heian.MalevolentShrine.Voice2, v_u_82, game.SoundService.Voice)
					end
					local v87 = v_u_8.Heian.Shrine:Clone()
					v87:PivotTo(v_u_82.CFrame * CFrame.new(0, 11, 20))
					v87.Parent = workspace.Effects
					local v88 = TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
					for _, v89 in v87:GetDescendants() do
						if v89:IsA("BasePart") then
							local v90 = v89.CFrame
							local v91 = v89.CFrame * CFrame.new(math.random(-30, 30), math.random(-30, 30), math.random(-30, 30))
							local v92 = CFrame.Angles
							local v93 = math.random(0, 360)
							local v94 = math.rad(v93)
							local v95 = math.random(0, 360)
							local v96 = math.rad(v95)
							local v97 = math.random(0, 360)
							v89.CFrame = v91 * v92(v94, v96, (math.rad(v97)))
							v_u_4:Create(v89, v88, {
								["CFrame"] = v90
							}):Play()
						end
					end
					task.delay(3, function()
						-- upvalues: (copy) v_u_86, (ref) v_u_4, (ref) v_u_3, (ref) v_u_84, (ref) v_u_5, (ref) v_u_10
						if v_u_86 then
							v_u_4:Create(v_u_86, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
								["Brightness"] = 1
							}):Play()
							task.wait(0.5)
							v_u_86.TintColor = Color3.new(1, 0, 0)
							v_u_4:Create(v_u_86, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
								["Brightness"] = 0,
								["Saturation"] = 0
							}):Play()
							v_u_4:Create(v_u_86, TweenInfo.new(2, Enum.EasingStyle.Sine), {
								["TintColor"] = Color3.new(1, 1, 1)
							}):Play()
							v_u_3:AddItem(v_u_86, 2)
						end
						if v_u_84 then
							v_u_5.PlayerGui.Main.Enabled = true
							v_u_4:Create(v_u_84.Frame1, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
								["Position"] = UDim2.new(0, 0, -0.15, 0)
							}):Play()
							v_u_4:Create(v_u_84.Frame2, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
								["Position"] = UDim2.new(0, 0, 1.15, 0)
							}):Play()
							v_u_3:AddItem(v_u_84, 1)
							v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
						end
					end)
					repeat
						task.wait()
					until v_u_83 < tick() or (not p_u_81.Parent or p_u_81:GetAttribute("Dead"))
					v87:Destroy()
					if v_u_85 then
						v_u_4:Create(v_u_85, TweenInfo.new(2), {
							["Volume"] = 0
						}):Play()
						v_u_3:AddItem(v_u_85, 2)
					end
				end)
			end
		end
	}
	v_u_11.Effects:Connect(function(p99, ...)
		-- upvalues: (copy) v_u_98
		local v100 = v_u_98[p99]
		if v100 then
			v100(...)
		end
	end)
	v_u_11.Hitbox:Connect(function(p101, p102, p103)
		-- upvalues: (ref) v_u_12, (ref) v_u_4
		local v104 = p102.HumanoidRootPart
		if not v104 then
			return
		end
		local v105 = nil
		while true do
			local v106 = v_u_12:SphereHitbox(p102, CFrame.new(0, 0, -4), 8)
			for _, v107 in v106 do
				local v108 = v107:FindFirstChild("Info")
				if v108 then
					local v109 = v108:FindFirstChild("Knockback")
					if not v109 or v109.Value ~= false then
						v105 = v106
						break
					end
				end
			end
			if v105 then
				local v110 = p101:FindFirstChildWhichIsA("NumberValue")
				if v110 then
					v_u_4:Create(v110, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p101.Parent then
				break
			end
		end
		p103:FireServer(v105, v104.CFrame)
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("HeianService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14