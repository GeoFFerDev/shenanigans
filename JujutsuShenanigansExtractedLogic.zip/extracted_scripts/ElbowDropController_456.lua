-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v9 = RaycastParams.new()
v9.FilterType = Enum.RaycastFilterType.Include
v9.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "ElbowDropController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (copy) v_u_6, (copy) v_u_2, (ref) v_u_10
	local v_u_27 = {
		["Hit"] = function(p13, p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:Flash(p14, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit2"), v15, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Itadori.Rush.RushBreak, v15, game.SoundService.Effect)
				if v_u_4 == p13 or v_u_4.Character == p14 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Jump"] = function(p16, p17)
			-- upvalues: (ref) v_u_4, (ref) v_u_3
			local v18 = p17.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v18.CFrame.LookVector * 3 - Vector3.new(0, 5, 0)
				if v_u_4.Character == v18.Parent then
					v_u_3:Create(p17, TweenInfo.new(0.5), {
						["P"] = 100000
					}):Play()
					repeat
						p17.Position = p16.Position - v19
						task.wait()
					until not (p17.Parent and p16)
				else
					repeat
						local v20 = v18.CFrame - v18.Position + p16.Position - v19
						v18.CFrame = v18.CFrame:Lerp(v20, 0.15)
						task.wait()
					until not (p17.Parent and p16)
				end
				v_u_3:Create(p17, TweenInfo.new(0.5), {
					["P"] = 100000
				}):Play()
				repeat
					p17.Position = p16.Position - v19
					task.wait()
				until not (p17.Parent and p16)
			end
		end,
		["Crush"] = function(p21, p22)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v23 = v_u_6.Itadori.CrushingBlow:Clone()
			v23.Position = p22
			v23.Parent = workspace.Effects
			v23.Floor.Wind2.Color = ColorSequence.new(Color3.new(0.333333, 0.666667, 1))
			v23.Floor.Sparks.Color = ColorSequence.new(Color3.new(0.333333, 0.666667, 1))
			v_u_3:Create(v23.Air, TweenInfo.new(0.2), {
				["Position"] = Vector3.new(0, 0, 0)
			}):Play()
			v_u_3:Create(v23.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v23.Floor.Ring:Emit(10)
			v23.Floor.Sparks:Emit(10)
			v23.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v23, 1.5)
			v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v23, game.SoundService.Effect)
			v_u_11:DustBreak(p22 + Vector3.new(0, 1, 0), Vector3.new(0, 1, 0), 13, 15, 0.4, 1)
			v_u_11:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v23, game.SoundService.Effect)
			if v_u_4 == p21 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end,
		["Woah"] = function(p24, p25)
			-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			if v_u_4.Character == p24 or v_u_4.Character == p25 then
				v_u_11:PlaySound(v_u_7.Todo.Boom, workspace, game.SoundService.Effect)
				local v26 = v_u_6.Todo.Woah:Clone()
				v26.ImageLabel.Image = "rbxassetid://73458769859093"
				v26.Parent = v_u_4.PlayerGui
				v_u_2:AddItem(v26, 1)
				v_u_3:Create(v26.ImageLabel, TweenInfo.new(1), {
					["ImageTransparency"] = 1
				}):Play()
			end
		end
	}
	v_u_10.Effects:Connect(function(p28, ...)
		-- upvalues: (copy) v_u_27
		local v29 = v_u_27[p28]
		if v29 then
			v29(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("ElbowDropService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12