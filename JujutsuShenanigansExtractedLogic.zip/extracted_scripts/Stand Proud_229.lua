-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_3 = game.Players.LocalPlayer
function v1.Start(_, p_u_4, p5)
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	if p_u_4.Character then
		local v_u_6 = script.Meteor:Clone()
		v_u_6.Parent = workspace.Effects
		table.insert(p5, v_u_6)
		task.spawn(function()
			-- upvalues: (copy) p_u_4, (copy) v_u_6
			local v7
			if p_u_4.Character then
				v7 = p_u_4.Character.Humanoid:GetAppliedDescription()
			else
				v7 = game.Players:GetHumanoidDescriptionFromUserId(p_u_4.UserId)
			end
			v_u_6.Rig.Humanoid:ApplyDescriptionReset(v7)
		end)
		local v8 = script.SFX:Clone()
		v8.SoundGroup = game.SoundService.Effect
		v8.Parent = workspace
		table.insert(p5, v8)
		local v9 = script.Voice:Clone()
		v9.SoundGroup = game.SoundService.Voice
		v9.Parent = workspace
		table.insert(p5, v9)
		local v10 = v_u_6.Rig.Humanoid:LoadAnimation(script.Character)
		local v11 = v_u_6.Camera.Humanoid:LoadAnimation(script.Camera)
		v10:Play(0, nil, 0)
		table.insert(p5, v10)
		v11:Play(0, nil, 0)
		table.insert(p5, v11)
		task.wait(2.5)
		v_u_3.PlayerGui.Main.Enabled = false
		local v_u_12 = workspace.CurrentCamera
		v_u_12.CameraType = Enum.CameraType.Scriptable
		local v13 = v_u_2.RenderStepped
		table.insert(p5, v13:Connect(function()
			-- upvalues: (copy) v_u_12, (copy) v_u_6
			v_u_12.CFrame = v_u_6.Camera.Torso.CFrame
		end))
		local v14 = tick() + 0.25
		repeat
			task.wait()
		until v10.Length > 0 and (v11.Length > 0 and v8.IsLoaded) or v14 < tick()
		v10:AdjustSpeed(1)
		v11:AdjustSpeed(1)
		v8:Play()
		v9:Play()
		task.wait(3.533)
		local v15 = script.ColorCorrection:Clone()
		v15.Parent = game.Lighting
		table.insert(p5, v15)
		local v16 = script.DepthOfField:Clone()
		v16.Parent = game.Lighting
		table.insert(p5, v16)
		v_u_6.BG.Transparency = 1
		v_u_6.Meteor.BG.Transparency = 0
		v_u_6.Meteor.Meteor.Transparency = 0
		v_u_6.Meteor.BG.Beam.Enabled = true
		v_u_6.Meteor.BG.Beam2.Enabled = true
		v_u_6.Meteor.BG.Beam3.Enabled = true
		v_u_6.Meteor.Sparks.Hit:Emit(200)
		v_u_6.Meteor.Meteor.Dust:Emit(75)
		v_u_6.Camera.Torso.Flames.Enabled = true
		task.wait(2.967)
		v10:AdjustSpeed(0)
		v11:AdjustSpeed(0)
		v_u_6.Meteor.BG.Beam.TextureSpeed = 0
		v_u_6.Meteor.BG.Beam2.TextureSpeed = 0
		v_u_6.Meteor.BG.Beam3.TextureSpeed = 0
		v_u_6.Meteor.Sparks.Hit.TimeScale = 0
		v_u_6.Camera.Torso.Flames.TimeScale = 0
		v_u_6.Meteor.Meteor.Dust.TimeScale = 0
	end
end
return v1