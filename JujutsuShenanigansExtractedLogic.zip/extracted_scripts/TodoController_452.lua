-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "TodoController"
})
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_10, (copy) v_u_5, (copy) v_u_7, (copy) v_u_2, (ref) v_u_11, (ref) v_u_12
	local v_u_123 = {
		["Hit"] = function(p15, p16)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_13:Flash(p15, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Todo.M1:FindFirstChild("Hit" .. p16), v17, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p18, p19)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v20 = p18:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = p19:FindFirstChild("HumanoidRootPart")
				if v21 then
					v_u_13:Flash(p19, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_9.Todo.M1:FindFirstChild("Hit3"), v21, game.SoundService.Effect)
					local v22 = v_u_8.ChaseHit:Clone()
					local v23 = CFrame.new
					local v24 = v21.Position
					local v25 = v20.Position.X
					local v26 = v21.Position.Y
					local v27 = v20.Position.Z
					v22.CFrame = v23(v24, (Vector3.new(v25, v26, v27))) * CFrame.Angles(0, 3.141592653589793, 0)
					v22.Parent = workspace.Effects
					v22.Ring:Emit(7)
					v22.Sparks:Emit(12)
					v_u_3:AddItem(v22, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p28)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			local v29 = p28.HumanoidRootPart
			if v29 then
				local v30 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v30.CFrame = v29.CFrame * CFrame.new(0, 1, -4)
				v30.Size = Vector3.new(0, 0, 2)
				v30.Parent = workspace.Effects
				v_u_4:Create(v30, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v30, 0.3)
				v_u_13:PlaySound(v_u_9.Misc.Chase, v29, game.SoundService.Effect)
				v_u_13:DustTrail(p28, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p31)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v32 = p31:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v32, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p33, p34, p35)
			-- upvalues: (ref) v_u_13
			if p35 == "Down" then
				v_u_13:ArmFlash(p33["Right Leg"], Color3.fromRGB(0, 170, 255), 0.4)
				return
			elseif p34 == 2 or p34 == 4 then
				v_u_13:ArmFlash(p33["Right Arm"], Color3.fromRGB(0, 170, 255), 0.3)
			else
				v_u_13:ArmFlash(p33["Left Arm"], Color3.fromRGB(0, 170, 255), 0.3)
			end
		end,
		["Swap"] = function(p36, p37, p38, p39, p40)
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5
			local v41 = p36:FindFirstChild("HumanoidRootPart")
			if v41 then
				local v42 = p37:FindFirstChild("HumanoidRootPart")
				if v42 then
					local v43 = false
					for v44 = 1, 2 do
						local v45 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
						v45.Position = v44 == 1 and v41.Position or v42.Position
						v45.Parent = workspace.Effects
						v_u_3:AddItem(v45, 1.5)
						v45.Attachment.Sparks:Emit(20)
						v_u_4:Create(v45, TweenInfo.new(0.3), {
							["Size"] = Vector3.new(0, 0, 0),
							["Transparency"] = 1
						}):Play()
						v_u_13:PlaySound(v_u_9.Todo.Clap, v45, game.SoundService.Effect)
						if v43 == false and (v45.Position - workspace.CurrentCamera.CFrame.Position).Magnitude < 50 then
							v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
							v43 = true
						end
					end
					if p37 and p37:GetAttribute("Ragdoll") > 0 then
						return
					elseif p40 == true or not _G.Shift then
						return
					elseif v_u_5.Character == p36 then
						local v46 = v41.CFrame:ToObjectSpace(workspace.CurrentCamera.CFrame)
						v41.CFrame = p38
						workspace.CurrentCamera.CFrame = p38:ToWorldSpace(v46)
					elseif v_u_5.Character == p37 then
						local v47 = v42.CFrame:ToObjectSpace(workspace.CurrentCamera.CFrame)
						v41.CFrame = p39
						workspace.CurrentCamera.CFrame = p39:ToWorldSpace(v47)
					end
				else
					return
				end
			else
				return
			end
		end,
		["Swap2"] = function(p48, p49)
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v50 = p48:FindFirstChild("HumanoidRootPart")
			if v50 then
				local v51 = false
				for v52 = 1, 2 do
					local v53 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
					v53.Position = v52 == 1 and v50.Position or p49.PrimaryPart.Position
					v53.Parent = workspace.Effects
					v_u_3:AddItem(v53, 1.5)
					v53.Attachment.Sparks:Emit(20)
					v_u_4:Create(v53, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(0, 0, 0),
						["Transparency"] = 1
					}):Play()
					v_u_13:PlaySound(v_u_9.Todo.Clap, v53, game.SoundService.Effect)
					if v51 == false and (v53.Position - workspace.CurrentCamera.CFrame.Position).Magnitude < 50 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
						v51 = true
					end
				end
			end
		end,
		["Fakeout"] = function(p54, p55)
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
			local v56 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
			v56.Position = p55 or p54.HumanoidRootPart.Position
			v56.Parent = workspace.Effects
			v_u_3:AddItem(v56, 1.5)
			v56.Attachment.Sparks:Emit(20)
			v_u_4:Create(v56, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(0, 0, 0),
				["Transparency"] = 1
			}):Play()
			v_u_13:PlaySound(v_u_9.Todo.Clap, v56, game.SoundService.Effect)
			if (v56.Position - workspace.CurrentCamera.CFrame.Position).Magnitude < 130 then
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
			end
		end,
		["Perfect"] = function(p57)
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9
			local v58 = p57:FindFirstChild("HumanoidRootPart")
			if v58 then
				local v59 = Instance.new("Highlight")
				v59.OutlineColor = Color3.fromRGB(85, 255, 255)
				v59.FillColor = Color3.fromRGB(170, 255, 255)
				v59.DepthMode = Enum.HighlightDepthMode.Occluded
				v59.Parent = p57
				v_u_3:AddItem(v59, 0.5)
				v_u_4:Create(v59, TweenInfo.new(0.5), {
					["FillTransparency"] = 1,
					["OutlineTransparency"] = 1
				}):Play()
				v_u_13:PlaySound(v_u_9.Todo.Perfect, v58, game.SoundService.Effect)
			end
		end,
		["Woosh"] = function(p60)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
			local v61 = p60:FindFirstChild("HumanoidRootPart")
			if v61 then
				local v62 = v_u_8.Todo.Woosh:Clone()
				v62.Weld.Part0 = v61
				v62.Parent = workspace.Effects
				v_u_3:AddItem(v62, 2.7)
				v62.Attachment.Glow:Emit(1)
				for _, v63 in v62:GetDescendants() do
					if v63:IsA("ParticleEmitter") then
						v_u_4:Create(v63, TweenInfo.new(0.7), {
							["Rate"] = 0
						}):Play()
					end
				end
			end
		end,
		["GrabHit"] = function(p64, p65, p66)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3, (ref) v_u_5, (ref) v_u_10
			local v67 = p65:FindFirstChild("HumanoidRootPart")
			if v67 then
				v_u_13:Flash(p65, Color3.new(1, 1, 1))
				if p66 == 1 then
					v_u_13:PlaySound(v_u_9.Hakari.OverLuck.Hit2, v67, game.SoundService.Effect)
					local v68 = v_u_8.Gojo.HardHit:Clone()
					v68.CFrame = v67.CFrame
					v68.Parent = workspace.Effects
					v68.Dust:Emit(5)
					v68.Ring:Emit(5)
					v68.Sparks:Emit(10)
					v_u_3:AddItem(v68, 0.5)
					if v_u_5 == p64 or v_u_5.Character == p65 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
						return
					end
				else
					if p66 == 2 then
						v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 4)), v67, game.SoundService.Effect)
						return
					end
					if p66 == 3 then
						v_u_13:PlaySound(v_u_9.Gojo.M1.Hit4, v67, game.SoundService.Effect)
						if v_u_5 == p64 or v_u_5.Character == p65 then
							v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
						end
					end
				end
			end
		end,
		["Launch"] = function(p69, p70)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v71 = p69:FindFirstChild("HumanoidRootPart")
			if v71 then
				local v72 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v72.CFrame = CFrame.new(v71.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v72.Size = Vector3.new(0, 0, 5)
				v72.Parent = workspace.Effects
				v_u_4:Create(v72, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v72.Position + Vector3.new(0, p70, 0)
				}):Play()
				v_u_3:AddItem(v72, 0.3)
				if p70 < 0 then
					v_u_13:PlaySound(v_u_9.Megumi.Mahoraga.Throw.Break, v71, game.SoundService.Effect)
					v_u_13:DustBreak(v71.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v71.Position) < 20 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
				end
			end
		end,
		["BlueGrab2"] = function(p73)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
			local v74 = v_u_8.Itadori.CounterHit.Feint:Clone()
			for _, v75 in v74:GetChildren() do
				v75.Color = ColorSequence.new(Color3.fromRGB(85, 170, 255))
			end
			v74.Parent = p73.PrimaryPart
			v74.Sparks:Emit(10)
			v74.Ring:Emit(3)
			v_u_3:AddItem(v74, 0.5)
			local v76 = Instance.new("Highlight")
			v76.FillTransparency = 0.5
			v76.OutlineTransparency = 0.5
			v76.FillColor = Color3.fromRGB(85, 170, 255)
			v76.OutlineColor = Color3.fromRGB(85, 170, 255)
			v76.DepthMode = Enum.HighlightDepthMode.Occluded
			v76.Parent = p73
			v_u_3:AddItem(v76, 0.5)
			v_u_4:Create(v76, TweenInfo.new(0.5), {
				["FillTransparency"] = 1,
				["OutlineTransparency"] = 1
			}):Play()
		end,
		["Chat"] = function(p_u_77)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2, (ref) v_u_4, (ref) v_u_3
			local v_u_78 = p_u_77:FindFirstChild("HumanoidRootPart")
			if v_u_78 then
				v_u_13:PlaySound(v_u_9.Todo.Awaken.SFX, v_u_78, game.SoundService.Effect)
				if v_u_5.Character == p_u_77 then
					local v_u_79 = v_u_8.Todo.Awakening.Flash:Clone()
					local v_u_80 = Instance.new("Camera", v_u_79.Main)
					local v81 = Instance.new("Camera", v_u_79.Chain)
					v_u_79.Main.CurrentCamera = v_u_80
					v_u_79.Chain.CurrentCamera = v81
					v_u_79.Parent = v_u_5.PlayerGui
					local v_u_82 = v_u_8.DomainWarn.Panel.Viewport.Display:Clone()
					v_u_82["Left Arm"].FingersL:Destroy()
					v_u_82["Right Arm"].FingersR:Destroy()
					v_u_82.Parent = v_u_79.Main
					pcall(function()
						-- upvalues: (ref) v_u_13, (copy) p_u_77, (copy) v_u_82
						v_u_13:ApplyCopyOutfit(p_u_77, v_u_82)
					end)
					v_u_82.Humanoid:LoadAnimation(v_u_7.Todo.Ultimate):Play(0)
					local v_u_83 = v_u_8.Todo.Awakening.Takada:Clone()
					v_u_83.Parent = v_u_79.Main
					v_u_83.Humanoid:LoadAnimation(v_u_79.Main.TakadaSummon):Play(0)
					v_u_83.HumanoidRootPart.CFrame = v_u_82.HumanoidRootPart.CFrame
					task.spawn(function()
						-- upvalues: (copy) v_u_83, (ref) v_u_8
						if _G.Settings.Outfit then
							local v84 = game.Players:GetHumanoidDescriptionFromOutfitId(_G.Settings.Outfit)
							v_u_83.Humanoid:ApplyDescriptionReset(v84)
							local v85 = v_u_83:Clone()
							v_u_8.Todo.Awakening.Takada:Destroy()
							v85.Parent = v_u_8.Todo.Awakening
						end
					end)
					local v_u_86 = 0
					local v_u_87 = nil
					local v_u_88 = v_u_8.Todo.Awakening.CameraData
					v_u_87 = v_u_2.RenderStepped:Connect(function(p89)
						-- upvalues: (ref) v_u_86, (copy) v_u_88, (copy) v_u_80, (copy) v_u_82, (ref) v_u_87
						v_u_86 = v_u_86 + p89 * 60
						local v90 = v_u_88.Frames
						local v91 = v_u_86
						local v92 = math.ceil(v91)
						local v93 = v90:FindFirstChild((tonumber(v92)))
						local v94 = v_u_88.FOV
						local v95 = v_u_86
						local v96 = math.ceil(v95)
						local v97 = v94:FindFirstChild((tonumber(v96)))
						if v93 and v97 then
							v_u_80.CFrame = v_u_82.HumanoidRootPart.CFrame * v93.Value
							v_u_80.FieldOfView = v97.Value
						else
							v_u_87:Disconnect()
						end
					end)
					local v_u_98 = v_u_8.Todo.Awakening.Aura:Clone()
					v_u_98.Parent = workspace.Effects
					local v_u_99 = v_u_8.Todo.Awakening.CC:Clone()
					v_u_99.Parent = game.Lighting
					local v_u_100 = v_u_8.Todo.Awakening.Imagination:Clone()
					v_u_100.Label.Text = "\226\128\187 THIS IS " .. string.upper(v_u_5.DisplayName or v_u_5.Name) .. "\'S IMAGINATION"
					v_u_100.Label.Label.Text = v_u_100.Label.Text
					v_u_4:Create(v_u_100.Label, TweenInfo.new(0.5), {
						["TextTransparency"] = 0.5
					}):Play()
					v_u_4:Create(v_u_100.Label.Label, TweenInfo.new(0.5), {
						["TextTransparency"] = 0
					}):Play()
					v_u_100.Parent = v_u_5.PlayerGui
					local v_u_101 = v_u_13:PlaySound(v_u_9.Todo.Awaken.Music, workspace, game.SoundService.Music, true)
					task.spawn(function()
						-- upvalues: (copy) v_u_98, (copy) p_u_77, (copy) v_u_101, (ref) v_u_4, (ref) v_u_3, (copy) v_u_99, (copy) v_u_100
						repeat
							v_u_98.Position = workspace.CurrentCamera.CFrame.Position
							task.wait()
						until not (p_u_77.Parent and p_u_77:GetAttribute("InUlt"))
						if v_u_101 then
							v_u_4:Create(v_u_101, TweenInfo.new(1.5), {
								["Volume"] = 0
							}):Play()
							v_u_3:AddItem(v_u_101, 1.5)
						end
						if v_u_98 then
							for _, v102 in v_u_98:GetChildren() do
								v102.Enabled = false
							end
							v_u_3:AddItem(v_u_98, 2)
						end
						if v_u_99 then
							v_u_4:Create(v_u_99, TweenInfo.new(1), {
								["TintColor"] = Color3.new(1, 1, 1),
								["Brightness"] = 0
							}):Play()
							v_u_3:AddItem(v_u_99, 1)
						end
						if v_u_100 then
							v_u_4:Create(v_u_100.Label, TweenInfo.new(0.5), {
								["TextTransparency"] = 1
							}):Play()
							v_u_4:Create(v_u_100.Label.Label, TweenInfo.new(0.5), {
								["TextTransparency"] = 1
							}):Play()
							v_u_3:AddItem(v_u_100, 0.5)
						end
					end)
					local v103 = v_u_79.Chain.Necklace.Ctrl:LoadAnimation(v_u_79.Chain.Chain)
					v81.CFrame = v_u_79.Chain.Necklace.RootPart.CFrame * CFrame.new(0, 0, 8)
					v81.FieldOfView = 40
					v103:Play(0)
					task.delay(0.4, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_79, (ref) v_u_8, (copy) v_u_83
						v_u_4:Create(v_u_79.Chain, TweenInfo.new(0.3), {
							["ImageTransparency"] = 1
						}):Play()
						for _, v104 in v_u_8.Todo:GetDescendants() do
							if v104:IsA("Animation") then
								local v105 = v_u_83.Humanoid:LoadAnimation(v104)
								v105:Play(0)
								v105:Stop(0)
							end
						end
					end)
					v_u_4:Create(v_u_79.Swipe, TweenInfo.new(0.15), {
						["Position"] = UDim2.new(0, 0, 1, 0)
					}):Play()
					task.delay(0.05, function()
						-- upvalues: (copy) v_u_79, (ref) v_u_4
						v_u_79.BG.Visible = true
						v_u_79.Main.Visible = true
						task.wait(1.5)
						local v106 = TweenInfo.new(0.75, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
						v_u_79.BG.BG.Visible = true
						for _, v107 in v_u_79.BG.BG:GetChildren() do
							if v107:IsA("ImageLabel") then
								local v108 = 1 + math.random(5, 20) / 100
								v_u_4:Create(v107, v106, {
									["Size"] = UDim2.new(v107.Size.X.Scale * v108, 0, v107.Size.Y.Scale * v108, 0),
									["Position"] = UDim2.new(v107.Position.X.Scale * v108, 0, v107.Position.Y.Scale * v108, 0)
								}):Play()
							end
						end
					end)
					task.delay(2.25, function()
						-- upvalues: (copy) v_u_79, (ref) v_u_4, (ref) v_u_8, (copy) v_u_78, (ref) v_u_7, (copy) p_u_77, (ref) v_u_3
						v_u_79.Swipe.Position = UDim2.new(0, 0, -1, 0)
						v_u_4:Create(v_u_79.Swipe, TweenInfo.new(0.2), {
							["Position"] = UDim2.new(0, 0, 1, 0)
						}):Play()
						task.wait(0.075)
						v_u_79.Chain.Visible = false
						v_u_79.Main.Visible = false
						v_u_79.BG.Visible = false
						task.spawn(function()
							-- upvalues: (ref) v_u_8, (ref) v_u_78, (ref) v_u_7, (ref) p_u_77, (ref) v_u_4, (ref) v_u_3
							local v109 = v_u_8.Todo.Awakening.Takada:Clone()
							v109.HumanoidRootPart.CFrame = v_u_78.CFrame
							v109.Name = "FollowTakada"
							for _, v110 in v109:GetDescendants() do
								if v110:IsA("BasePart") then
									v110.CollisionGroup = "NoCollision"
								end
							end
							v109.HumanoidRootPart.Anchored = true
							v109.Parent = workspace.Effects
							local v111 = v109.Humanoid:LoadAnimation(v_u_7.Todo.TakadaJoint.TakadaIdle)
							v111:Play(0)
							v111.Priority = Enum.AnimationPriority.Idle
							local v112 = v109.HumanoidRootPart
							local v113 = true
							while true do
								local v114 = v_u_78.CFrame * CFrame.new(-2, 2, 2)
								if v109:GetAttribute("A") then
									v114 = v_u_78.CFrame * v109:GetAttribute("A")
								end
								v112.CFrame = v112.CFrame:Lerp(v114, 0.1)
								local v115 = not p_u_77:GetAttribute("Stun") and p_u_77:GetAttribute("Ragdoll") <= 0 and true or false
								if v115 == true and v113 == false then
									v113 = true
									for _, v116 in v109:GetDescendants() do
										if v116.Name ~= "HumanoidRootPart" and (v116:IsA("BasePart") or v116:IsA("Decal")) then
											v_u_4:Create(v116, TweenInfo.new(0.3), {
												["Transparency"] = 0
											}):Play()
										end
									end
								elseif v115 == false and v113 == true then
									v113 = false
									for _, v117 in v109:GetDescendants() do
										if v117.Name ~= "HumanoidRootPart" and (v117:IsA("BasePart") or v117:IsA("Decal")) then
											v_u_4:Create(v117, TweenInfo.new(0.3), {
												["Transparency"] = 1
											}):Play()
										end
									end
								end
								task.wait()
								if not (v_u_78.Parent and (p_u_77.Parent and p_u_77:GetAttribute("InUlt"))) then
									v_u_3:AddItem(v109, 0.5)
									for _, v118 in v109:GetDescendants() do
										if v118:IsA("BasePart") or v118:IsA("Decal") then
											v_u_4:Create(v118, TweenInfo.new(0.5), {
												["Transparency"] = 1
											}):Play()
										end
									end
									return
								end
							end
						end)
					end)
				end
			end
		end,
		["Applause"] = function(p119)
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_7, (ref) v_u_10
			local v120 = p119:FindFirstChild("HumanoidRootPart")
			if v120 then
				local v121 = game.ReplicatedStorage.Utils.Todo.Clap:Clone()
				v121.Position = v120.Position
				v121.Parent = workspace.Effects
				v_u_3:AddItem(v121, 1.5)
				v121.Attachment.Sparks:Emit(20)
				v_u_4:Create(v121, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(0, 0, 0),
					["Transparency"] = 1
				}):Play()
				v_u_13:PlaySound(v_u_9.Todo.Clap, v121, game.SoundService.Effect)
				local v122 = Instance.new("Highlight")
				v122.FillTransparency = 0.5
				v122.OutlineTransparency = 0.5
				v122.FillColor = Color3.fromRGB(255, 255, 255)
				v122.OutlineColor = Color3.fromRGB(255, 255, 255)
				v122.DepthMode = Enum.HighlightDepthMode.Occluded
				v122.Parent = p119
				v_u_3:AddItem(v122, 2)
				v_u_4:Create(v122, TweenInfo.new(2), {
					["FillTransparency"] = 1,
					["OutlineTransparency"] = 1
				}):Play()
				v_u_13:PlaySound(v_u_9.Todo.OST, v120, game.SoundService.Music)
				v_u_13:PlaySound(v_u_9.Todo.Voice, v120, game.SoundService.Voice)
				p119.Humanoid:LoadAnimation(v_u_7.Todo.Summon):Play(0)
				if (v121.Position - workspace.CurrentCamera.CFrame.Position).Magnitude < 130 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p124, ...)
		-- upvalues: (copy) v_u_123
		local v125 = v_u_123[p124]
		if v125 then
			v125(...)
		end
	end)
	v_u_11.Hitbox:Connect(function(p126, p127, p128)
		-- upvalues: (ref) v_u_12, (ref) v_u_4
		local v129 = p127.HumanoidRootPart
		if not v129 then
			return
		end
		local v130 = nil
		while true do
			local v131 = v_u_12:SphereHitbox(p127, CFrame.new(0, 0, -4), 8)
			for _, v132 in v131 do
				local v133 = v132:FindFirstChild("Info")
				if v133 then
					local v134 = v133:FindFirstChild("Knockback")
					if not v134 or v134.Value ~= false then
						v130 = v131
						break
					end
				end
			end
			if v130 then
				local v135 = p126:FindFirstChildWhichIsA("NumberValue")
				if v135 then
					v_u_4:Create(v135, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p126.Parent then
				break
			end
		end
		p128:FireServer(v130, v129.CFrame)
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("TodoService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14