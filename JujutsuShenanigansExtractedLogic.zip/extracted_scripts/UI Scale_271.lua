-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 3,
	["SortOrder"] = 3,
	["Val"] = "UIS",
	["Desc"] = "Change the scale of some user interfaces",
	["Max"] = 2,
	["Callback"] = function(p1)
		local _ = game.ReplicatedStorage
		local v2 = game.Players.LocalPlayer.PlayerGui
		v2.Main.UIScale.Scale = p1
		v2.Controls.Xbox.UIScale.Scale = p1
		v2.Controls.Playstation.UIScale.Scale = p1
		v2.Emotes.UIScale.Scale = p1
		if v2:FindFirstChild("Miracles") then
			v2.Miracles.UIScale.Scale = p1
		end
		if v2:FindFirstChild("Adaptation") then
			v2.Adaptation.UIScale.Scale = p1
		end
	end
}