-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 2,
	["SortOrder"] = 7,
	["Val"] = "Killsound",
	["Desc"] = "Changes your Kill Sound",
	["Gamepass"] = "718699461"
}