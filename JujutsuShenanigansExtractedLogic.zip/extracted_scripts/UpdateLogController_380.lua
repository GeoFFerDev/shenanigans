-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_2 = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local _ = v3.Utils
local _ = v3.Sounds
local v_u_4 = nil
local v5 = v_u_1.CreateController({
	["Name"] = "UpdateLogController"
})
v5.Ver = "1.73"
local v_u_6 = "V" .. v5.Ver .. " \n THE NOTHING UPDATE"
v5.Updates = {
	{
		"SALARYMAN",
		{
			"SALARYMAN HAS BEEN RELEASED TO THE PUBLIC",
			"ADDED NEW AWAKENING SKILL TO SALARYMAN (Sharpen)",
			"ADDED NEW AWAKENING SKILL TO SALARYMAN (Interrogate)",
			"Reduced the volume of Collapse\'s debris when it crashes",
			"Collapse now deals the damage of all debris combined when hit (Max cap of 40)"
		}
	},
	{
		"LUCKY COWARD",
		{
			"LUCKY COWARD HAS BEEN RELEASED TO THE PUBLIC",
			"ADDED NEW AWAKENING TO LUCKY COWARD (Jawbreaker)",
			"ADDED NEW SPECIAL TO LUCKY COWARD (Helping Hand)",
			"ADDED NEW SKILL TO LUCKY COWARD (Ambush)",
			"ADDED NEW SKILL TO LUCKY COWARD (Backstab)",
			"ADDED NEW SKILL TO LUCKY COWARD (Trip)",
			"ADDED NEW SKILL TO LUCKY COWARD (Cheap Shot)",
			"ADDED NEW VARIANT TO LUCKY COWARD (Ankle Cutter)",
			"ADDED NEW VARIANT TO LUCKY COWARD (High Time)",
			"ADDED NEW VARIANT TO LUCKY COWARD (Dirty Play)"
		}
	},
	{
		"CREATOR CLASH & WORKSHOP",
		{
			"Added value caps to all visual effects and certain blocks when in Creator Clash",
			"Added a warning when reporting workshop creations to prevent spam",
			"Improved the look of the killfeed",
			"Gave votekicking an user interace to vote easier",
			"Spawning into Creator Clash now gives you short invincibility",
			"Added an option to toggle Creator Clash changes in PS+",
			"Added a kill requirement to uploading and Creator Clash"
		}
	},
	{
		"PUPPET MASTER",
		{
			"Added new variant to Miracle Cannon",
			"Miracle Cannon gets camera tilt option on max curse energy output",
			"Made it easier to stomp players with Absolute Destruction",
			"Absolute Destruction can now run through walls at 3+ years",
			"Added a finisher to Absolute Destruction",
			"Puppet Barrage now uses the same puppet system as other offload skills",
			"Removed ubercharge mechanic",
			"Decreased the time needed to lock on per year used on Technique Charge",
			"Increased the vertical hitbox size for Ultra Spin and Heat Emission (offloaded)",
			"Fixed offloaded Ultra Spin causing the puppet to trip over"
		}
	},
	{
		"CURSED CHILD",
		{
			"Moved Cursed Child to its own gamemode, disabling it in every other gamemode (Can still be used in PS+ with OP characters enabled)",
			"Increased the speed of Lethal Wound\'s hits",
			"Disabled the finishers for Bloody Mary and Fight",
			"Disabled Cursed Child in Duels and Roulette",
			"Being in jackpot now increases your awakening meter drain",
			"Defeating boss Cursed Child now grants you the badge",
			"Decreased spawn timer to 20m",
			"Worn Dagger now spawns in on server creation",
			"Increased the drain rate of awakening as the boss",
			"Improved the indicator of the boss"
		}
	},
	{
		"SKILL BUILDER",
		{
			"Added Scale to STATE block",
			"Added RELATIVE FROM BRANCH to VISUAL block, applies visuals to the original user (can be used to make same camera visual for both players)",
			"Added EASING STYLE to VISUAL block",
			"Added EASING DIRECTION to VISUAL block",
			"Added GLOBAL to SOUND block (plays the sound globally)"
		}
	},
	{
		"SHOP",
		{ "Added 11 new emotes (Sanitizer, Turron, Big Shoe, Train, Low Cortisol, Pitchfork Protest, Bubble Blower, Envelope, Jolly, Lob, Burnice)", "Added 1 new victory flash (Meditation)" }
	},
	{
		"GENERAL CHANGES",
		{ "Improved ragdoll influence to include rotational velocity (you can rotate yourself)", "Added a new building to the map", "Chara\'s Knife now spawns every 10 minutes instead of 1 hour" }
	},
	{
		"BUG FIXES",
		{
			"Fixed not being able to upload creations in Roblox\'s VIP/Private servers instead of Custom Servers",
			"Fixed character blocks needing to be unpowered to work",
			"Fixed character blocks breaking randomly",
			"Fixed Absolute Destruction not having hit visual effects",
			"Fixed new players failing to load their data when first joining the game",
			"Fixed Field of View effect not working",
			"Fixed certain effects disappearing if too many were spawned",
			"Fixed NPCs not being able to use Time Cell Moon Palace",
			"Fixed aerial Onslaught not applying cooldown when the skill ends quickly enough",
			"Fixed the TTS dictionary being loaded on the client while not needed (enjoy 30% faster loading)",
			"Fixed Technique Charge draining the same amount of years for all charges",
			"Fixed Puppet Barrage having infinite range",
			"Fixed Decisive Strikes invincibility",
			"Fixed being able to keep Restless Gambler\'s buffs after becoming Chara",
			"Fixed Lethal Wound soft-locking the player if it\'s used on the Mech"
		}
	}
}
function v5.KnitStart(p7)
	-- upvalues: (copy) v_u_2, (copy) v_u_6
	local v8 = v_u_2.PlayerGui:WaitForChild("Menus").Group.Logs
	local v9 = v8.ScrollingFrame.UpdateTitle
	local v10 = v8.ScrollingFrame.UpdateInfo
	if v_u_6 then
		v9.Text = v_u_6
	end
	local v11 = "\n "
	local v12 = ""
	for _, v13 in p7.Updates do
		v10.Text = v10.Text .. v11 .. "<b>[ " .. v13[1] .. " ]</b>"
		v12 = v12 .. ("\n \n**[ %* ]**"):format(v13[1])
		local v14 = v13[2][1]
		if typeof(v14) ~= "table" then
			for _, v15 in v13[2] do
				v10.Text = v10.Text .. "\n\226\128\162 " .. v15
				v12 = v12 .. ("\n- %*"):format(v15)
			end
		end
		v11 = "\n \n "
	end
	print(v12)
	v8:SetAttribute("Loaded", true)
end
function v5.KnitInit(_)
	-- upvalues: (ref) v_u_4, (copy) v_u_1
	v_u_4 = v_u_1.GetController("FXController")
end
return v5