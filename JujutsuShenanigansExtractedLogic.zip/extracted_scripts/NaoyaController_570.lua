-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "NaoyaController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10
	local v_u_173 = {
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				if not (p14:FindFirstChild("Info") and p14.Info:FindFirstChild("NaoyaFrame")) then
					v_u_12:Flash(p14, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. p15), v16, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Chase"] = function(p17)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v18 = p17.HumanoidRootPart
			if v18 then
				local v19 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v19.CFrame = v18.CFrame * CFrame.new(0, 1, -4)
				v19.Size = Vector3.new(0, 0, 2)
				v19.Parent = workspace.Effects
				v_u_4:Create(v19, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v19, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v18, game.SoundService.Effect)
				v_u_12:DustTrail(p17, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p20, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v21, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p22, p23, _)
			-- upvalues: (ref) v_u_12
			if p23 == 1 or p23 == 2 then
				v_u_12:ArmFlash(p22["Left Arm"], Color3.fromRGB(128, 126, 255), 0.4)
				return
			elseif p23 == 3 then
				v_u_12:ArmFlash(p22["Right Arm"], Color3.fromRGB(128, 126, 255), 0.4)
			else
				v_u_12:ArmFlash(p22["Right Leg"], Color3.fromRGB(128, 126, 255), 0.4)
			end
		end,
		["Swing3"] = function(p24, p25, p26)
			-- upvalues: (ref) v_u_12
			if p25 == 1 or p25 == 3 then
				v_u_12:ArmFlash(p24["Right Arm"], Color3.fromRGB(128, 126, 255), 0.4)
				return
			elseif p25 == 2 or p26 == "Up" then
				v_u_12:ArmFlash(p24["Left Arm"], Color3.fromRGB(128, 126, 255), 0.4)
			else
				v_u_12:ArmFlash(p24["Left Arm"], Color3.fromRGB(128, 126, 255), 0.4)
				v_u_12:ArmFlash(p24["Right Arm"], Color3.fromRGB(128, 126, 255), 0.4)
			end
		end,
		["Launch"] = function(p27, p28)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v29 = p27:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v30.CFrame = CFrame.new(v29.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v30.Size = Vector3.new(0, 0, 5)
				v30.Parent = workspace.Effects
				v_u_4:Create(v30, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v30.Position + Vector3.new(0, p28, 0)
				}):Play()
				v_u_3:AddItem(v30, 0.3)
				if p28 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v29, game.SoundService.Effect)
					v_u_12:DustBreak(v29.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v29.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Frame"] = function(p_u_31, p_u_32)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9
			local v_u_33 = p_u_31:FindFirstChild("HumanoidRootPart")
			if v_u_33 then
				local v_u_34 = v_u_7.Naoya.NaoyaGlass:Clone()
				if p_u_31:GetScale() ~= 1 then
					v_u_34.Size = v_u_34.Size * p_u_31:GetScale()
					local v35 = v_u_34.Part
					v35.Size = v35.Size * p_u_31:GetScale()
				end
				v_u_34.CFrame = p_u_31.Torso.CFrame
				v_u_34.Parent = workspace.Effects
				v_u_34.Front.Transparency = 1
				v_u_34.Back.Transparency = 1
				v_u_3:AddItem(v_u_34, 4)
				local v_u_36 = {}
				task.spawn(function()
					-- upvalues: (ref) v_u_7, (copy) v_u_36, (ref) v_u_5, (copy) v_u_34, (copy) p_u_31
					for v37 = 1, 2 do
						local v38 = v_u_7.Naoya.NaoyaGlassUI:Clone()
						local v39 = v_u_36
						table.insert(v39, v38)
						v38.Parent = v_u_5.PlayerGui
						v38.Adornee = v_u_34
						local v40 = p_u_31:Clone()
						for _, v41 in pairs(v40:GetDescendants()) do
							if v41:IsA("LocalScript") or (v41:IsA("Script") or v41.Name == "Stunna") then
								v41:Destroy()
							end
						end
						for _, v42 in pairs(p_u_31:GetDescendants()) do
							if v42:IsA("Motor6D") then
								local v43 = v40:FindFirstChild(v42.Name, true)
								if v43 and v43:IsA("Motor6D") then
									v43.C0 = v42.C0
									v43.C1 = v42.C1
									v43.Transform = v42.Transform
								end
							end
						end
						v40.Parent = v38.ViewportFrame.WorldModel
						v40:PivotTo(CFrame.new())
						if v37 == 2 then
							v38.Face = Enum.NormalId.Back
						end
						local v44 = Instance.new("Camera", v38.ViewportFrame)
						local v45 = CFrame.new(0, 0, (v37 == 2 and 400 or -400) * p_u_31:GetScale())
						local v46 = CFrame.Angles
						local v47 = v37 == 2 and 0 or 180
						v44.CFrame = v45 * v46(0, math.rad(v47), 0)
						v44.FieldOfView = 1
						v38.ViewportFrame.CurrentCamera = v44
					end
				end)
				local v_u_48 = {}
				for _, v49 in p_u_31:GetDescendants() do
					if (v49:IsA("BasePart") or v49:IsA("Decal")) and v49.Transparency ~= 1 then
						local v50 = v49.Transparency
						v49.Transparency = 1
						v_u_48[v49] = v50
					end
				end
				v_u_34.Transparency = 0
				v_u_4:Create(v_u_34, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["Transparency"] = 0.5
				}):Play()
				v_u_12:PlaySound(v_u_8.Naoya.Frame, v_u_33, game.SoundService.Effect)
				task.delay(0.5, function()
					-- upvalues: (copy) v_u_34, (ref) v_u_4
					if v_u_34.Transparency ~= 1 then
						v_u_4:Create(v_u_34, TweenInfo.new(2.45, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["Transparency"] = 0
						}):Play()
					end
				end)
				task.spawn(function()
					-- upvalues: (copy) v_u_34, (copy) p_u_31, (copy) v_u_33, (copy) p_u_32, (copy) v_u_48, (copy) v_u_36, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3
					repeat
						v_u_34.CFrame = p_u_31.Torso.CFrame
						task.wait()
					until not (p_u_31.Parent and (v_u_33.Parent and p_u_32:IsDescendantOf(workspace.Characters)))
					for v51, v52 in v_u_48 do
						if v51.Parent then
							v51.Transparency = v52
						end
					end
					for _, v53 in v_u_36 do
						v53:Destroy()
					end
					v_u_4:Create(v_u_34, TweenInfo.new(0), {
						["Transparency"] = 1
					}):Play()
					v_u_34.Part.Transparency = 1
					v_u_34.Front.Transparency = 1
					v_u_34.Back.Transparency = 1
					v_u_34.Attachment.Flash:Emit(3)
					v_u_34.Attachment.Wind:Emit(5)
					v_u_34.Attachment.WindCircle:Emit(5)
					v_u_34.Attachment.Shockwave:Emit(4)
					v_u_34.Shatter:Emit(40)
					v_u_12:PlaySound(v_u_8.Naoya.FrameBreak, v_u_33, game.SoundService.Effect)
					if (workspace.CurrentCamera.CFrame.Position - v_u_34.Position).Magnitude < 40 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					end
					if _G.Settings.DesPHY then
						if (workspace.CurrentCamera.CFrame.Position - v_u_34.Position).Magnitude > 100 then
							return
						end
						task.wait(0.1)
						local v54 = Random.new()
						local v55 = TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
						for _ = 1, 20 do
							local v56 = v_u_7.Gojo.Shard:Clone()
							local v57 = v54:NextUnitVector().Unit
							local v58 = math.random(5, 20) / 10
							local v59 = math.random(5, 20) / 10
							v56.Size = Vector3.new(0.2, v58, v59)
							v56.CFrame = v_u_34.CFrame * CFrame.new(math.random(-2, 2), math.random(-4, 4), 0)
							v56.CFrame = v56.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
							v56.CanCollide = true
							v56.CollisionGroup = "Effects"
							v56.Parent = workspace.Effects
							v56.Transparency = 0.5
							v56.Color = v_u_34.Color
							v56.Material = Enum.Material.Neon
							local v60 = math.random(-50, 50)
							local v61 = math.random(-50, 50)
							local v62 = math.random
							v56.RotVelocity = Vector3.new(v60, v61, v62(-50, 50))
							v56.Velocity = v57 * math.random(30, 60) + v_u_33.Velocity
							v_u_4:Create(v56, v55, {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
							v_u_3:AddItem(v56, 3)
						end
					end
				end)
			end
		end,
		["Zwoosh"] = function(p63, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v64 = p63:FindFirstChild("HumanoidRootPart")
			if v64 then
				local v65 = TweenInfo.new(1.2)
				v_u_12:PlaySound(v_u_8.Naoya.Decisive.Startup, v64, game.SoundService.Effect)
				local v66 = v_u_7.Damage.HitGlow:Clone()
				v_u_3:AddItem(v66, 1.2)
				v66.Parent = workspace.Effects
				for _, v67 in v66:GetChildren() do
					v67.Color = Color3.fromRGB(128, 126, 255)
					v67.Anchored = true
					v67.CFrame = p63[v67.Name].CFrame
					v_u_4:Create(v67, v65, {
						["Transparency"] = 1,
						["Position"] = v67.Position
					}):Play()
				end
				local v68 = v_u_7.Naoya.Teleport:Clone()
				v68.CFrame = v64.CFrame
				v68.Parent = workspace.Effects
				v68.Lines:Emit(8)
				v68.Floor.Dust:Emit(30)
				v_u_3:AddItem(v68, 1)
				local v69 = {}
				for _, v70 in p63:GetDescendants() do
					if (v70:IsA("BasePart") or v70:IsA("Decal")) and v70.Transparency ~= 1 then
						local v71 = v70.Transparency
						v70.Transparency = 1
						v69[v70] = v71
					end
				end
				task.wait(0.25)
				v_u_12:PlaySound(v_u_8.Naoya.Decisive.Flicker2, v64, game.SoundService.Effect)
				for v72, v73 in v69 do
					if v72.Parent then
						v72.Transparency = v73
					end
				end
				local v74 = v_u_7.Naoya.Teleport:Clone()
				v74.CFrame = v64.CFrame
				v74.Parent = workspace.Effects
				v74.Lines:Emit(8)
				v74.Floor.Dust:Emit(30)
				v_u_3:AddItem(v74, 1)
			end
		end,
		["Trail"] = function(p75, p76, p77)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v78 = p75:FindFirstChild("HumanoidRootPart")
			if v78 then
				local v79 = TweenInfo.new(1.2)
				local v80 = (p77 - p76).Unit
				local v81 = (p76 - p77).Magnitude / 4
				for v82 = 0, math.floor(v81) do
					local v83 = v_u_7.Damage.HitGlow:Clone()
					v_u_3:AddItem(v83, 1.2)
					v83.Parent = workspace.Effects
					for _, v84 in v83:GetChildren() do
						v84.Color = Color3.fromRGB(128, 126, 255)
						v84.Anchored = true
						v84.CFrame = p75[v84.Name].CFrame - v78.Position + p76 + v80 * v82 * 4
						v_u_4:Create(v84, v79, {
							["Transparency"] = 1
						}):Play()
					end
				end
				local v85 = TweenInfo.new(0.2)
				for _ = 1, 10 do
					local v86 = v_u_7.Damage.HitGlow:Clone()
					v_u_3:AddItem(v86, 0.2)
					v86.Parent = workspace.Effects
					for _, v87 in v86:GetChildren() do
						v87.Color = Color3.fromRGB(128, 126, 255)
						v87.Anchored = true
						v87.CFrame = p75[v87.Name].CFrame
						v_u_4:Create(v87, v85, {
							["Transparency"] = 1
						}):Play()
					end
					task.wait(0.04)
				end
			end
		end,
		["Blink"] = function(p88, p89)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_3
			v_u_12:DomainMapFade(Color3.new(0, 0, 0), 0.2, 0.3)
			local v90 = p88:FindFirstChild("HumanoidRootPart")
			if v90 then
				local v91 = v90.Position
				TweenInfo.new(1.2)
				local v92 = (p89 - v91).Unit
				local v93 = (v91 - p89).Magnitude / 4
				for v94 = 0, math.floor(v93) do
					local v95 = v_u_7.Damage.HitGlow:Clone()
					v_u_3:AddItem(v95, 0.25)
					v95.Parent = workspace.Effects
					for _, v96 in v95:GetChildren() do
						v96.Color = Color3.fromRGB(128, 126, 255)
						v96.Anchored = true
						v96.Transparency = 0
						v96.CFrame = p88[v96.Name].CFrame - v90.Position + v91 + v92 * v94 * 4
					end
					task.wait(0.02)
				end
			end
		end,
		["Parry"] = function(p97, p98)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v99 = p97:FindFirstChild("HumanoidRootPart")
			if v99 then
				if v_u_5.Character == p98 or v_u_5.Character == p97 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1)
				end
				local v100 = v99:FindFirstChild("Startup")
				if v100 and v100:IsA("Sound") then
					v_u_4:Create(v100, TweenInfo.new(0.2), {
						["Volume"] = 0
					}):Play()
				end
				v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Parry, v99, game.SoundService.Effect)
				local v101 = v_u_7.Misc.C.M1.Hit1:Clone()
				v101.Parent = p97["Right Arm"]
				v101.Position = Vector3.new(0, -1, 0)
				for _, v102 in v101:GetDescendants() do
					if v102:IsA("ParticleEmitter") then
						v102:Emit(v102:GetAttribute("EmitCount"))
						v102.LockedToPart = true
					end
				end
				v_u_3:AddItem(v101, 0.5)
				for _ = 1, 7 do
					local v103 = v_u_7.Damage.HitGlow:Clone()
					v_u_3:AddItem(v103, 0.5)
					v103.Parent = workspace.Effects
					local v104 = TweenInfo.new(0.5)
					for _, v105 in v103:GetChildren() do
						v105.Color = Color3.fromRGB(128, 126, 255)
						v105.Transparency = 0.5
						v105.Anchored = true
						v105.CFrame = p97[v105.Name].CFrame
						v_u_4:Create(v105, v104, {
							["Transparency"] = 1
						}):Play()
					end
					task.wait(0.02)
				end
			end
		end,
		["Lost"] = function(p106, p107, p108)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v109 = p106:FindFirstChild("HumanoidRootPart")
			if v109 then
				if p108 then
					task.wait(0.45)
					v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Fall, v109, game.SoundService.Effect)
					task.wait(0.4)
					local v110 = v_u_7.Naoya.Fall:Clone()
					v110:PivotTo(v109.CFrame)
					v110.Parent = workspace.Effects
					v_u_3:AddItem(v110, 1.5)
					v_u_4:Create(v110.Mesh.Start, TweenInfo.new(0.7, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = v110.Mesh.End.Size,
						["Transparency"] = 1,
						["CFrame"] = v110.Mesh.End.CFrame
					}):Play()
					v_u_4:Create(v110.Mesh2.Start, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = v110.Mesh2.End.Size,
						["Transparency"] = 1,
						["CFrame"] = v110.Mesh2.End.CFrame
					}):Play()
					v_u_4:Create(v110.Mesh3.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = v110.Mesh3.End.Size,
						["Transparency"] = 1,
						["CFrame"] = v110.Mesh3.End.CFrame
					}):Play()
					v110.Mesh.End:Destroy()
					v110.Mesh2.End:Destroy()
					v110.Mesh3.End:Destroy()
					if v_u_5.Character == p106 or v_u_5.Character == p107 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						return
					end
				else
					v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Catch, v109, game.SoundService.Effect)
					task.wait(0.3)
					local v111 = v_u_7.Naoya.Dialogue:Clone()
					v111.Parent = p106.Head
					local v112 = v111.Chat1.Position
					v111.Chat1.Position = v112 - UDim2.new(0, 0, 0.15, 0)
					v_u_4:Create(v111.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v112
					}):Play()
					v_u_4:Create(v111.Chat1, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_4:Create(v111.Chat1.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(1.3)
					local v113 = v111.Chat2.Position
					v111.Chat2.Position = v113 - UDim2.new(0, 0, 0.15, 0)
					v_u_4:Create(v111.Chat2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v113
					}):Play()
					v_u_4:Create(v111.Chat2, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_4:Create(v111.Chat2.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(0.8)
					v_u_3:AddItem(v111, 0.6)
					for _, v114 in v111:GetDescendants() do
						if v114:IsA("Frame") then
							v_u_4:Create(v114, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["Position"] = v114.Position - UDim2.new(0, 0, 0.2, 0),
								["BackgroundTransparency"] = 1
							}):Play()
						elseif v114:IsA("TextLabel") then
							v_u_4:Create(v114, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["TextTransparency"] = 1
							}):Play()
						end
					end
				end
			end
		end,
		["Grip"] = function(p115, p116)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v_u_117 = p115:FindFirstChild("HumanoidRootPart")
			if v_u_117 then
				v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Grab, v_u_117, game.SoundService.Effect)
				task.delay(0.2, function()
					-- upvalues: (ref) v_u_12, (ref) v_u_8, (copy) v_u_117
					v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Grab2, v_u_117, game.SoundService.Effect)
				end)
				if v_u_5.Character == p116 or v_u_5.Character == p115 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Form"] = function(p118)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v119 = p118:FindFirstChild("HumanoidRootPart")
			if v119 then
				v_u_12:PlaySound(v_u_8.Naoya.Ultimate.Form, v119, game.SoundService.Effect)
				local v120 = {}
				for _, v121 in p118:GetChildren() do
					if v121:IsA("BasePart") and v121 ~= v119 then
						local v122 = v121.Color
						table.insert(v120, v122)
					end
				end
				local v_u_123 = v_u_7.Naoya.Form:Clone()
				v_u_123.Color = v120[math.random(1, #v120)]
				v_u_123.Weld.Part0 = p118.Torso
				v_u_123.Parent = workspace.Effects
				v_u_3:AddItem(v_u_123, 4)
				v_u_4:Create(v_u_123, TweenInfo.new(0.4), {
					["Size"] = Vector3.new(4, 4, 4)
				}):Play()
				if v_u_5.Character == p118 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
				local v124 = v_u_7.Misc.M.WingFly:Clone()
				v124.WHAT:Destroy()
				v124:PivotTo(v119.CFrame)
				v124:ScaleTo(2)
				v124.Parent = workspace.Effects
				v_u_3:AddItem(v124, 1.5)
				v_u_4:Create(v124.Mesh.Start, TweenInfo.new(0.7, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = v124.Mesh.End.Size,
					["Transparency"] = 1,
					["CFrame"] = v124.Mesh.End.CFrame
				}):Play()
				v_u_4:Create(v124.Mesh2.Start, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = v124.Mesh2.End.Size,
					["Transparency"] = 1,
					["CFrame"] = v124.Mesh2.End.CFrame
				}):Play()
				v_u_4:Create(v124.Mesh3.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = v124.Mesh3.End.Size,
					["Transparency"] = 1,
					["CFrame"] = v124.Mesh3.End.CFrame
				}):Play()
				v124.Mesh.End:Destroy()
				v124.Mesh2.End:Destroy()
				v124.Mesh3.End:Destroy()
				local v125 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
				v125.Position = v119.Position
				v125.Parent = workspace.Effects
				v_u_3:AddItem(v125, 1)
				v125.Sparks.Color = ColorSequence.new(p118.Torso.Color)
				v125.Wind.Color = v125.Sparks.Color
				v125.Wind2.Color = v125.Sparks.Color
				v125.Sparks:Emit(50)
				v125.Wind:Emit(7)
				v125.Wind2:Emit(7)
				local v126 = v_u_123.Attachment
				for _ = 1, 30 do
					local v_u_127 = v126:Clone()
					local v128 = v_u_127.CFrame
					local v129 = CFrame.Angles
					local v130 = math.random(0, 360)
					local v131 = math.rad(v130)
					local v132 = math.random(0, 360)
					local v133 = math.rad(v132)
					local v134 = math.random(0, 360)
					v_u_127.CFrame = v128 * v129(v131, v133, (math.rad(v134)))
					v_u_127.Beam.Color = ColorSequence.new(v_u_123.Color, v120[math.random(1, #v120)])
					v_u_127.Parent = v_u_123
					local v_u_135 = math.random(100, 200) / 100
					local v_u_136 = TweenInfo.new(0.4 * v_u_135, Enum.EasingStyle.Back, Enum.EasingDirection.InOut)
					local v137 = v_u_4
					local v138 = v_u_127.Attachment
					local v139 = v_u_136
					local v140 = {}
					local v141 = math.random(30, 50)
					v140.Position = Vector3.new(0, v141, 0)
					v137:Create(v138, v139, v140):Play()
					v_u_4:Create(v_u_127.Beam, v_u_136, {
						["CurveSize0"] = 0
					}):Play()
					v_u_4:Create(v_u_127.Attachment, TweenInfo.new(0.6 * v_u_135, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Orientation"] = Vector3.new(0, 0, -90)
					}):Play()
					task.delay(0.4 * v_u_135, function()
						-- upvalues: (ref) v_u_136, (copy) v_u_135, (ref) v_u_4, (copy) v_u_127
						v_u_136 = TweenInfo.new(0.4 * v_u_135, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
						v_u_4:Create(v_u_127.Attachment, v_u_136, {
							["Position"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_4:Create(v_u_127.Beam, v_u_136, {
							["CurveSize0"] = -15
						}):Play()
					end)
				end
				v126:Destroy()
				task.wait(0.4)
				v_u_123.Core.Wrap.Enabled = true
				v_u_4:Create(v_u_123, TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
					["Size"] = Vector3.new(16, 16, 16)
				}):Play()
				task.spawn(function()
					-- upvalues: (copy) v_u_123
					repeat
						v_u_123.Core.Wrap.Size = NumberSequence.new(v_u_123.Size.X / 2 + 0.1)
						task.wait()
					until not v_u_123.Parent
				end)
				task.wait(0.8)
				v_u_4:Create(v_u_123, TweenInfo.new(0.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
					["Size"] = Vector3.new(0, 0, 0)
				}):Play()
				local v_u_142 = TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				for v143 = 1, 15 do
					if (workspace.CurrentCamera.CFrame.Position - v119.Position).Magnitude > 300 then
						task.wait()
					else
						local v_u_144 = math.random(90, 130) / 100
						local v_u_145 = v_u_7.Mahito.Worms.Morph2:Clone()
						if v143 % 4 ~= 0 then
							v_u_145.Decal:Destroy()
						end
						v_u_145.Color = v120[math.random(1, #v120)]
						local v146 = v_u_145.Weld
						v146.C0 = v146.C0 * CFrame.Angles(math.random(0, 3.141592653589793), math.random(0, 3.141592653589793), math.random(0, 3.141592653589793))
						v_u_145.Weld.Part0 = v119
						v_u_145.Parent = workspace.Effects
						v_u_3:AddItem(v_u_145, 2)
						v_u_4:Create(v_u_145.Weld, TweenInfo.new(v_u_144 + 0.4, Enum.EasingStyle.Exponential), {
							["C0"] = v_u_145.Weld.C0 * CFrame.Angles(math.random(0, 3.141592653589793), math.random(0, 3.141592653589793), math.random(0, 3.141592653589793))
						}):Play()
						task.spawn(function()
							-- upvalues: (copy) v_u_144, (ref) v_u_4, (copy) v_u_145, (copy) v_u_142
							local v147 = v_u_144 / 5
							v_u_4:Create(v_u_145, TweenInfo.new(v_u_144 * 0.66, Enum.EasingStyle.Elastic), {
								["Size"] = Vector3.new(1, 1, 1) * math.random(80, 140) / 10
							}):Play()
							task.delay(v_u_144 * 0.33, function()
								-- upvalues: (ref) v_u_4, (ref) v_u_145, (ref) v_u_144
								v_u_4:Create(v_u_145, TweenInfo.new(v_u_144 * 0.33, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
									["Size"] = Vector3.new(0, 0, 10)
								}):Play()
							end)
							local v148 = TweenInfo.new(v147, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
							for v149 = 1, 5 do
								local v150 = CFrame.new(math.random(-40, 40) / 3, math.random(-10, 50) / 5, math.random(-20, 20) / 3)
								local v151 = v149 / 6
								local v152 = {
									["C1"] = v150:Lerp(CFrame.new(), v151)
								}
								v_u_4:Create(v_u_145.Weld, v148, v152):Play()
								task.wait(v147)
							end
							v_u_4:Create(v_u_145, v_u_142, {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
						end)
						task.wait()
					end
				end
				task.wait(0.5)
				v_u_123:Destroy()
			end
		end,
		["Spin"] = function(p153, p154)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9, (ref) v_u_3, (ref) v_u_2
			local v155 = p153:FindFirstChild("HumanoidRootPart")
			if not v155 then
				return
			end
			local v156 = v_u_7.Naoya.HitArea:Clone()
			v156.Parent = workspace.Effects
			v_u_4:Create(v156.groundwaveing.Spin, TweenInfo.new(1), {
				["TimeScale"] = 1
			}):Play()
			local _ = p153.Torso.Position
			local v157
			if v_u_5.Character == p153 then
				v157 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
			else
				v157 = nil
			end
			local v158 = tick()
			while true do
				v156.Position = v155.Position
				local _ = p153.Torso.Position
				if tick() > v158 + 0.1 then
					v158 = tick()
					local v159 = p153:FindFirstChild("Curse")
					if v159 then
						local v160 = v159:Clone()
						for _, v161 in v160:GetDescendants() do
							if v161:IsA("Decal") then
								v161.Transparency = 1
							elseif v161:IsA("BasePart") and v161.Transparency ~= 1 then
								v161.Transparency = 0.5
								v161.Material = Enum.Material.Neon
								v161.Anchored = true
								v161.Color = Color3.fromRGB(128, 126, 255)
								if v161:IsA("UnionOperation") then
									v161.UsePartColor = true
								end
								v_u_4:Create(v161, TweenInfo.new(1), {
									["Transparency"] = 1
								}):Play()
							elseif v161:IsA("Weld") or v161:IsA("Motor6D") then
								v161:Destroy()
							end
						end
						v160.Parent = workspace.Effects
						v_u_3:AddItem(v160, 1)
					end
				end
				v_u_2.Stepped:Wait()
				if not (p154:IsDescendantOf(workspace) and v155.Parent) then
					v156.groundwaveing.Spin.Enabled = false
					v_u_4:Create(v156.groundwaveing.Spin, TweenInfo.new(0.35, Enum.EasingStyle.Quad), {
						["TimeScale"] = 0.1
					}):Play()
					if v157 then
						v157:StartFadeOut(0.5)
					end
					local v162 = v_u_7.Misc.M.WingFly:Clone()
					v162.WHAT:Destroy()
					v162:PivotTo(v155.CFrame)
					v162:ScaleTo(2)
					v162.Parent = workspace.Effects
					v_u_3:AddItem(v162, 1.5)
					v_u_4:Create(v162.Mesh.Start, TweenInfo.new(0.7, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = v162.Mesh.End.Size,
						["Transparency"] = 1,
						["CFrame"] = v162.Mesh.End.CFrame
					}):Play()
					v_u_4:Create(v162.Mesh2.Start, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = v162.Mesh2.End.Size,
						["Transparency"] = 1,
						["CFrame"] = v162.Mesh2.End.CFrame
					}):Play()
					v_u_4:Create(v162.Mesh3.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
						["Size"] = v162.Mesh3.End.Size,
						["Transparency"] = 1,
						["CFrame"] = v162.Mesh3.End.CFrame
					}):Play()
					v162.Mesh.End:Destroy()
					v162.Mesh2.End:Destroy()
					v162.Mesh3.End:Destroy()
					return
				end
			end
		end,
		["SpinStart"] = function(p163)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v164 = p163:FindFirstChild("HumanoidRootPart")
			if v164 then
				v_u_12:PlaySound(v_u_8.Naoya.Acceleration, v164, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Naoya.Frames, v164, game.SoundService.Effect)
				local v_u_165 = v_u_7.Naoya.Air:Clone()
				v_u_165.Parent = p163.Torso
				for _, v166 in v_u_165:GetDescendants() do
					if v166:IsA("Beam") then
						v_u_4:Create(v166, TweenInfo.new(0.5), {
							["Width1"] = 8,
							["TextureSpeed"] = -4
						}):Play()
					end
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_165
					while true do
						for _, v167 in v_u_165:GetDescendants() do
							if v167:IsA("Beam") then
								v167.CurveSize1 = math.random(-60, 60) / 10
							end
						end
						task.wait(0.04)
						if not v_u_165.Parent then
							return
						end
					end
				end)
				task.wait(1)
				v_u_3:AddItem(v_u_165, 0.2)
				for _, v168 in v_u_165:GetDescendants() do
					if v168:IsA("Beam") then
						v_u_4:Create(v168, TweenInfo.new(0.2), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
					elseif v168:IsA("ParticleEmitter") then
						v168.Enabled = false
					end
				end
			end
		end,
		["Velocity"] = function(p169, p170)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			if p169:FindFirstChild("HumanoidRootPart") then
				local v171 = v_u_7.Yuki.Buildup:Clone()
				v171.Bar.Bar.UIGradient.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255), Color3.fromRGB(128, 126, 255))
				v171.Parent = p169.Torso
				v_u_4:Create(v171.BG, TweenInfo.new(0.2), {
					["BackgroundTransparency"] = 0.5
				}):Play()
				v_u_4:Create(v171.Bar.Bar, TweenInfo.new(0.2), {
					["BackgroundTransparency"] = 0
				}):Play()
				repeat
					local v172 = ((p169.Humanoid:GetAttribute("Speed") or 2) - 2) / 2
					v171.Bar.Size = UDim2.new(1, 0, v172, 0)
					v171.Bar.Bar.Size = UDim2.new(1, 0, 1 / v172, 0)
					task.wait()
				until not (p169.Parent and p170.Parent)
				v_u_4:Create(v171.BG, TweenInfo.new(0.4), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_4:Create(v171.Bar.Bar, TweenInfo.new(0.4), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_3:AddItem(v171, 0.4)
			end
		end
	}
	v_u_10.Effects:Connect(function(p174, ...)
		-- upvalues: (copy) v_u_173
		local v175 = v_u_173[p174]
		if v175 then
			v175(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("NaoyaService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13