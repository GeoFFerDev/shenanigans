-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "CrushingRushdownController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (copy) v_u_7, (copy) v_u_5, (copy) v_u_9, (ref) v_u_10
	local v_u_49 = {
		["Interp"] = function(p_u_14)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_2, (ref) v_u_4
			local v_u_15 = p_u_14.CFrame
			local v_u_16 = tick()
			local v_u_17 = p_u_14:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_15, (copy) p_u_14, (ref) v_u_16
				v_u_15 = p_u_14.CFrame
				v_u_16 = tick()
			end)
			v_u_12:PlaySound(v_u_8.Mahito.CrushingRushdown.HairPull, p_u_14, game.SoundService.Effect)
			local v_u_18 = nil
			v_u_18 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_14, (ref) v_u_18, (copy) v_u_17, (ref) v_u_15, (ref) v_u_16
				if p_u_14.Parent then
					workspace:BulkMoveTo({ p_u_14 }, { v_u_15 + v_u_15.LookVector * (200 * (tick() - v_u_16)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_18:Disconnect()
					v_u_17:Disconnect()
				end
			end)
			local v19 = TweenInfo.new(1, Enum.EasingStyle.Elastic)
			for _, v20 in p_u_14:GetChildren() do
				if v20:IsA("Beam") then
					local v21 = v20.CurveSize1
					v20.CurveSize1 = math.random(-20, 20)
					v_u_4:Create(v20, v19, {
						["CurveSize1"] = v21
					}):Play()
				end
			end
		end,
		["HairRetract"] = function(p22, p23)
			-- upvalues: (ref) v_u_3, (ref) v_u_4
			local v24 = p22:FindFirstChild("Head")
			if v24 then
				local v25 = p23:Clone()
				v25.Parent = workspace.Effects
				v_u_3:AddItem(v25, 1)
				local v26 = TweenInfo.new(1, Enum.EasingStyle.Elastic, Enum.EasingDirection.In)
				for _, v_u_27 in v25:GetChildren() do
					if v_u_27:IsA("Beam") then
						v_u_4:Create(v_u_27, v26, {
							["CurveSize1"] = math.random(-20, 20)
						}):Play()
					else
						v_u_4:Create(v_u_27, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Position"] = v_u_27.Position + Vector3.new(5, 0, 0)
						}):Play()
						task.delay(0.35, function()
							-- upvalues: (ref) v_u_4, (copy) v_u_27
							v_u_4:Create(v_u_27, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
								["Position"] = v_u_27.Position - Vector3.new(10, 0, 0)
							}):Play()
							task.wait(0.35)
							v_u_4:Create(v_u_27, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								["Position"] = v_u_27.Position + Vector3.new(5, 0, 0)
							}):Play()
						end)
					end
				end
				local v28 = tick()
				local _ = v25.CFrame
				repeat
					v25.CFrame = v25.CFrame:Lerp(v24.CFrame, (tick() - v28) / 1)
					task.wait()
				until tick() > v28 + 1 or not v24.Parent
			end
		end,
		["Hair"] = function(p29, p30, p31)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_4
			local v32 = p29:FindFirstChild("HumanoidRootPart")
			if v32 then
				local v33 = p30:FindFirstChild("Left Leg")
				if v33 then
					local v34 = v_u_7.Mahito.Worms.HairEnd:Clone()
					v34.Anchored = false
					v_u_3:AddItem(v34, 0.7)
					v34.Parent = workspace.Effects
					local v35 = Instance.new("Weld", v34)
					v35.Part1 = v34
					v35.Part0 = v33
					v_u_12:PlaySound(v_u_8.Mahito.CrushingRushdown.Leap, v32, game.SoundService.Effect)
					local v36 = v_u_7.Mahito.Worms.HairGrab:Clone()
					v36.Weld.Part0 = v33
					v36.Parent = workspace.Effects
					v_u_3:AddItem(v36, 0.7)
					local v37 = TweenInfo.new(0.7, Enum.EasingStyle.Elastic)
					for _, v38 in v34:GetChildren() do
						if v38:IsA("Beam") then
							v38.Attachment0 = p31
							local v39 = v38.CurveSize1
							v38.CurveSize1 = math.random(-50, 50)
							v_u_4:Create(v38, v37, {
								["CurveSize1"] = v39
							}):Play()
						end
					end
				end
			else
				return
			end
		end,
		["Hit"] = function(p40, p41)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v42 = p41:FindFirstChild("HumanoidRootPart")
			if v42 then
				v_u_12:Flash(p41, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Hakari.EnergySurge.Hit1, v42, game.SoundService.Effect)
				local v43 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
				v43.Position = v42.Position
				v43.Parent = workspace.Effects
				v_u_3:AddItem(v43, 1)
				v43.Sparks:Emit(50)
				v43.Wind:Emit(7)
				v43.Wind2:Emit(7)
				if v_u_5 == p40 or v_u_5.Character == p41 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Ram"] = function(p44, p45)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v46 = p44:FindFirstChild("HumanoidRootPart")
			if v46 then
				v_u_12:PlaySound(v_u_8.Mahito.CrushingRushdown.Leap, v46, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Mahito.WideSPStrike.Crush2, v46, game.SoundService.Effect)
				local v47 = v_u_7.Mahito.CrushingRushdown.Dash:Clone()
				v47.Weld.Part0 = v46
				v47.Parent = workspace.Effects
				v_u_3:AddItem(v47, 3)
				repeat
					task.wait()
				until not p45.Parent
				if v47.Parent then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Wind, v46, game.SoundService.Effect)
					for _, v48 in v47:GetDescendants() do
						if v48:IsA("ParticleEmitter") then
							v48.Enabled = false
						end
					end
					task.wait(0.5)
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Throw, v46, game.SoundService.Effect)
					if v_u_5.Character == p44 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p50, ...)
		-- upvalues: (copy) v_u_49
		local v51 = v_u_49[p50]
		if v51 then
			v51(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("CrushingRushdownService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13