-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["AssetIds"] = {
		"14894840794",
		"14894840716",
		"14894840665",
		"14894840494",
		"14894840403",
		"14894840359",
		"14894840207",
		"14894840845",
		"14894840012",
		"14894839957",
		"14894839839",
		"14894839723",
		"14894839698",
		"14894839465",
		"14894839401",
		"14894839262",
		"14894839204",
		"14894839014",
		"14894838907",
		"14894838844",
		"14894838660",
		"14894838573",
		"14894838540",
		"14894838315",
		"14894838272",
		"14894838103",
		"14894838147",
		"14894837920",
		"14894837766",
		"14894838013",
		"14894837643"
	},
	["MaxLifetime"] = 7,
	["VolumeModifier"] = 1.6,
	["Offset"] = 0,
	["Fadeout"] = 0.4,
	["CustomFunction"] = function(p1, _)
		local v2
		if p1 < 1 then
			v2 = 1
		elseif p1 > 61 then
			v2 = 31
		else
			local v3 = p1 / 2
			v2 = math.ceil(v3)
		end
		local v4 = (p1 < 1 or p1 > 61) and 0 or (p1 - 1) % 2
		if v2 == 9 then
			v4 = v4 - 1
		end
		local v5
		if p1 > 61 then
			v5 = 1.059463 ^ (p1 - 61 + v4)
		elseif p1 < 1 then
			v5 = 1.059463 ^ (-(1 - p1 + v4))
		else
			v5 = 1.059463 ^ v4
		end
		return {
			["asset"] = v2,
			["timePosition"] = 0,
			["pitch"] = v5
		}
	end
}