-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "BloodRainController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_9, (ref) v_u_10
	local v_u_40 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_8.Choso.BloodRain.Start, v14, game.SoundService.Effect)
				v_u_11:DomainBurst(v14)
			end
		end,
		["Hit"] = function(p15)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Slash, v16, game.SoundService.Effect)
			end
		end,
		["Rain"] = function(p_u_17, p_u_18)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_2, (ref) v_u_3, (ref) v_u_9
			local v_u_19 = p_u_17:FindFirstChild("HumanoidRootPart")
			if v_u_19 then
				local v_u_20 = v_u_7.Choso.BloodRain:Clone()
				local v21 = v_u_20.End.Position
				v_u_20.End.Position = v_u_20.Start.Position
				v_u_20.Parent = workspace.Effects
				v_u_20.Start.Sparks:Emit(60)
				v_u_20.Start.Flash:Emit(20)
				v_u_4:Create(v_u_20.Beam, TweenInfo.new(0.3), {
					["Width1"] = 100
				}):Play()
				v_u_4:Create(v_u_20.End, TweenInfo.new(0.3), {
					["Position"] = v21
				}):Play()
				local v_u_22 = 0
				local v_u_23 = TweenInfo.new(0.1)
				local v_u_24 = nil
				local v_u_25 = v_u_11:PlaySound(v_u_8.Choso.BloodRain.Loop, v_u_20, game.SoundService.Effect, true)
				local v_u_26
				if v_u_5.Character == p_u_17 then
					v_u_26 = Instance.new("ColorCorrectionEffect", game.Lighting)
				else
					v_u_26 = nil
				end
				local v_u_27 = nil
				v_u_27 = v_u_2.Stepped:Connect(function()
					-- upvalues: (copy) p_u_18, (copy) p_u_17, (ref) v_u_27, (ref) v_u_3, (copy) v_u_20, (ref) v_u_4, (ref) v_u_26, (ref) v_u_24, (ref) v_u_11, (ref) v_u_8, (copy) v_u_19, (copy) v_u_25, (ref) v_u_22, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (copy) v_u_23
					if p_u_18.Parent and p_u_17.Parent then
						v_u_22 = v_u_22 + 1
						v_u_20.CFrame = v_u_19.CFrame - v_u_19.Position + p_u_17.Torso.Position
						local v28 = v_u_5:GetAttribute("Ultimate") / 100
						if v_u_26 then
							local v29 = v_u_26
							local v30 = v_u_26.Saturation
							v29.Saturation = v30 + (-(1 - v28) - v30) * 0.1
						end
						v_u_20.Start.Flow.Rate = 400 * v28
						local v31 = (workspace.CurrentCamera.CFrame.Position - v_u_20.Position).Magnitude
						if v31 < 120 and v_u_24 == nil then
							v_u_24 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
						elseif v31 >= 120 and v_u_24 ~= nil then
							v_u_24:StartFadeOut(0.5)
							v_u_24 = nil
						end
						if v31 < 300 and v_u_22 % 2 == 0 then
							for _ = 1, 4 do
								local v32 = workspace
								local v33 = v_u_20.Rain.Position
								local v34 = math.random(-35, 35)
								local v35 = math.random
								local v36 = v32:Raycast(v33 + Vector3.new(v34, 0, v35(-35, 35)), Vector3.new(0, -100, 0), _G.MapParams)
								if v36 then
									local v37 = v_u_7.Choso.RainDrop:Clone()
									local v38 = CFrame.lookAlong(v36.Position, v36.Normal) * CFrame.Angles(1.5707963267948966, 0, 0)
									local v39 = math.random(0, 25) / 10 - 50
									v37.CFrame = v38 - Vector3.new(0, v39, 0)
									v_u_4:Create(v37, v_u_23, {
										["CFrame"] = v37.CFrame - Vector3.new(0, 50, 0)
									}):Play()
									v37.Parent = workspace.Effects
									v_u_3:AddItem(v37, 0.75)
								end
							end
						end
					else
						v_u_27:Disconnect()
						task.spawn(function()
							-- upvalues: (ref) v_u_3, (ref) v_u_20, (ref) v_u_4, (ref) v_u_26, (ref) v_u_24, (ref) v_u_11, (ref) v_u_8, (ref) v_u_19, (ref) v_u_25
							v_u_3:AddItem(v_u_20, 1)
							v_u_20.Rain.Rain.Enabled = false
							v_u_20.Start.Flow.Enabled = false
							v_u_4:Create(v_u_20.Beam, TweenInfo.new(0.3), {
								["Width0"] = 0,
								["Width1"] = 0
							}):Play()
							if v_u_26 then
								v_u_3:AddItem(v_u_26, 0.5)
								v_u_4:Create(v_u_26, TweenInfo.new(0.5), {
									["Saturation"] = 0
								}):Play()
							end
							if v_u_24 ~= nil then
								v_u_24:StartFadeOut(0.5)
							end
							v_u_11:PlaySound(v_u_8.Choso.BloodRain.End, v_u_19, game.SoundService.Effect)
							if v_u_25 then
								v_u_4:Create(v_u_25, TweenInfo.new(0.4), {
									["Volume"] = 0
								}):Play()
							end
						end)
					end
				end)
				if (workspace.CurrentCamera.CFrame.Position - v_u_19.Position).Magnitude < 120 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p41, ...)
		-- upvalues: (copy) v_u_40
		local v42 = v_u_40[p41]
		if v42 then
			v42(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("BloodRainService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12