-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v_u_4.PlayerScripts.PlayerModule)
require(v5.Modules.BloodyZee)
local v10 = RaycastParams.new()
v10.FilterType = Enum.RaycastFilterType.Include
v10.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "Mokou3Controller"
})
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_8, (copy) v_u_4, (copy) v_u_9, (ref) v_u_11
	local v_u_43 = {
		["Startup"] = function(p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:PlaySound(v_u_7.Misc.M.Scorchrise, v16, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Misc.M.Mokou3Voice, v16, game.SoundService.Effect)
			end
		end,
		["Pillar"] = function(p_u_17, p_u_18)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9, (ref) v_u_12, (ref) v_u_7
			local v_u_19 = p_u_17:FindFirstChild("HumanoidRootPart")
			if v_u_19 then
				local v20 = v_u_6.Hiromi.Shockwave:Clone()
				v20.Position = v_u_19.Position - Vector3.new(0, 3, 0)
				v20.Parent = workspace.Effects
				local v21 = v_u_6.Misc.M.Slash.PointLight:Clone()
				v21.Parent = v20
				v_u_3:Create(v21, TweenInfo.new(1), {
					["Brightness"] = 0,
					["Color"] = Color3.new(1, 0, 0)
				}):Play()
				local v22 = v20.CFrame
				local v23 = CFrame.Angles
				local v24 = math.random(-179, 179)
				v20.CFrame = v22 * v23(0, math.rad(v24), 0)
				v_u_3:Create(v20.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
					["Scale"] = Vector3.new(35, 0, 35)
				}):Play()
				v_u_3:Create(v20.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
					["Transparency"] = 1
				}):Play()
				v20.Floor.Glow:Emit(1)
				v20.Floor.Ring:Emit(10)
				v_u_2:AddItem(v20, 1.5)
				local v25 = v_u_6.Misc.M.FirePilla:Clone()
				v25.CFrame = v_u_19.CFrame + Vector3.new(0, 10.5, 0)
				v25.Part.CFrame = v_u_19.CFrame + Vector3.new(0, 10.5, 0)
				v25.Parent = workspace.Effects
				v_u_2:AddItem(v25, 2)
				v25.Tornado.CFrame = v20.CFrame - Vector3.new(0, 3, 0)
				v_u_3:Create(v25.Tornado, TweenInfo.new(0.3, Enum.EasingStyle.Quad), {
					["CFrame"] = (v20.CFrame + Vector3.new(0, 8, 0)) * CFrame.Angles(0, 3.12413936106985, 0),
					["Size"] = Vector3.new(40, 25.418, 40),
					["Transparency"] = 1
				}):Play()
				task.spawn(function()
					-- upvalues: (copy) v_u_19, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2, (copy) p_u_17, (ref) v_u_4, (ref) v_u_9, (copy) p_u_18, (ref) v_u_12, (ref) v_u_7
					if (workspace.CurrentCamera.CFrame.Position - v_u_19.Position).Magnitude < 150 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
					local v26 = v_u_6.Misc.M.fireballstartup:Clone()
					v26.Parent = workspace.Effects
					v_u_2:AddItem(v26, 10)
					local v27 = {}
					for _, v28 in p_u_17:GetDescendants() do
						if (v28:IsA("BasePart") or v28:IsA("Decal")) and v28.Transparency ~= 1 then
							local v29 = v28.Transparency
							v28.Transparency = 1
							v27[v28] = v29
						end
					end
					while true do
						local v30 = task.wait()
						v26.Position = v_u_19.Position
						if v_u_4.Character == p_u_17 then
							local v31 = workspace.CurrentCamera.CFrame
							local v32 = v_u_9:GetControls():GetMoveVector()
							p_u_18.Position = p_u_18.Position + (v31.RightVector * v32.X + -v31.LookVector * v32.Z) * v30 * 70
						end
						if not (p_u_18.Parent and p_u_17.Parent) then
							v_u_12:PlaySound(v_u_7.Misc.M.Scorchrise2, v_u_19, game.SoundService.Effect)
							for _, v33 in v26:GetDescendants() do
								if v33:IsA("ParticleEmitter") then
									v33.Enabled = false
								end
							end
							for _, v34 in v26.Explode:GetChildren() do
								v34:Emit(v34:GetAttribute("EmitCount"))
							end
							v_u_2:AddItem(v26, 1)
							for v35, v36 in v27 do
								if v35.Parent then
									v35.Transparency = v36
								end
							end
							return
						end
					end
				end)
				v_u_3:Create(v25["2"], TweenInfo.new(0.075), {
					["Position"] = Vector3.new(0, 12, 0)
				}):Play()
				task.wait(0.3)
				for _, v37 in v25:GetDescendants() do
					if v37:IsA("ParticleEmitter") then
						v37.Enabled = false
					end
				end
				local v38 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				v_u_3:Create(v25["1"]["1"], v38, {
					["Width0"] = 0,
					["Width1"] = 0
				}):Play()
				v_u_3:Create(v25["1"]["2"], v38, {
					["Width0"] = 0,
					["Width1"] = 0
				}):Play()
				v_u_3:Create(v25["1"]["3"], v38, {
					["Width0"] = 0,
					["Width1"] = 0
				}):Play()
			end
		end,
		["Hit"] = function(p39, p40)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v41 = p40:FindFirstChild("HumanoidRootPart")
			if v41 then
				v_u_12:Flash(p40, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Hiromi.Grapple.Energy, v41, game.SoundService.Effect)
				local v42 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v42.Parent = v41.RootAttachment
				v42:Emit(20)
				v_u_2:AddItem(v42, 0.4)
				if v_u_4.Character == p40 or v_u_4 == p39 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p44, ...)
		-- upvalues: (copy) v_u_43
		local v45 = v_u_43[p44]
		if v45 then
			v45(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("Mokou3Service")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetController("HitboxController")
end
return v14