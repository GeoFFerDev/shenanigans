-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
local v_u_2 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v_u_3 = game.ReplicatedStorage
local _ = v_u_3.Animations
local _ = v_u_3.Utils
local v_u_4 = v_u_3.Sounds
require(v_u_3.Modules.CameraShaker)
require(v_u_3.Modules.EffectUtils)
require(v_u_3.Modules.BloodyZee)
require(v_u_3.Knit.Trove)
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v8 = v_u_1.CreateController({
	["Name"] = "PuppetBarrageController"
})
function v8.KnitStart(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_4, (copy) v_u_3, (ref) v_u_5, (ref) v_u_6, (copy) v_u_2
	local v_u_100 = {
		["StartFly"] = function(p9)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v10 = p9:FindFirstChild("HumanoidRootPart")
			if v10 then
				v_u_7:PlaySound(v_u_4.Mechamaru.PuppetBarrage.FlyUp, v10, game.SoundService.Effect)
				local v11 = v_u_3.Utils.Mechamaru.BoosterL:Clone()
				v11.Parent = p9
				local v12 = v_u_3.Utils.Mechamaru.BoosterR:Clone()
				v12.Parent = p9
				local function v16(p13, p14)
					local v_u_15 = Instance.new("Motor6D")
					v_u_15.C0 = CFrame.new(0, 0.75, 0.625) * CFrame.Angles(0.7853981633974483, 0, 0)
					v_u_15.Part0 = p14
					v_u_15.Part1 = p13
					v_u_15.Name = p13.Name
					v_u_15.Parent = p14
					p13.Parent.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_15
						v_u_15:Destroy()
					end)
				end
				v16(v12["Arm BoostterrrrR"], p9["Right Arm"])
				v16(v11["Arm BoostterrrrL"], p9["Left Arm"])
				local v17 = v12["Arm BoostterrrrR"].Stage1
				local v18 = next
				local v19, v20 = v17:GetDescendants()
				for _, v21 in v18, v19, v20 do
					if v21:IsA("ParticleEmitter") then
						v21.Enabled = true
					end
				end
				local v22 = v11["Arm BoostterrrrL"].Stage1
				local v23 = next
				local v24, v25 = v22:GetDescendants()
				for _, v26 in v23, v24, v25 do
					if v26:IsA("ParticleEmitter") then
						v26.Enabled = true
					end
				end
				task.wait(3)
				v11:Destroy()
				v12:Destroy()
			end
		end,
		["PowerFly"] = function(p27)
			local v28 = p27:FindFirstChild("BoosterR", true)
			local v29 = p27:FindFirstChild("BoosterL", true)
			if v28 and v29 then
				local v30 = v28["Arm BoostterrrrR"].Stage2
				local v31 = next
				local v32, v33 = v30:GetDescendants()
				for _, v34 in v31, v32, v33 do
					if v34:IsA("ParticleEmitter") then
						v34.Enabled = true
					end
				end
				local v35 = v29["Arm BoostterrrrL"].Stage2
				local v36 = next
				local v37, v38 = v35:GetDescendants()
				for _, v39 in v36, v37, v38 do
					if v39:IsA("ParticleEmitter") then
						v39.Enabled = true
					end
				end
				task.wait(0.5)
				local v40 = v28["Arm BoostterrrrR"].Stage2
				local v41 = next
				local v42, v43 = v40:GetDescendants()
				for _, v44 in v41, v42, v43 do
					if v44:IsA("ParticleEmitter") then
						v44.Enabled = false
					end
				end
				local v45 = v29["Arm BoostterrrrL"].Stage2
				local v46 = next
				local v47, v48 = v45:GetDescendants()
				for _, v49 in v46, v47, v48 do
					if v49:IsA("ParticleEmitter") then
						v49.Enabled = false
					end
				end
				task.wait(0.3)
				local v50 = v28["Arm BoostterrrrR"].Stage2
				local v51 = next
				local v52, v53 = v50:GetDescendants()
				for _, v54 in v51, v52, v53 do
					if v54:IsA("ParticleEmitter") then
						v54.Enabled = true
					end
				end
				local v55 = v29["Arm BoostterrrrL"].Stage2
				local v56 = next
				local v57, v58 = v55:GetDescendants()
				for _, v59 in v56, v57, v58 do
					if v59:IsA("ParticleEmitter") then
						v59.Enabled = true
					end
				end
			end
		end,
		["Dive"] = function(p60)
			local v61 = p60:FindFirstChild("BoosterR", true)
			local v62 = p60:FindFirstChild("BoosterL", true)
			if v61 and v62 then
				local v63 = v61["Arm BoostterrrrR"].Stage2
				local v64 = next
				local v65, v66 = v63:GetDescendants()
				for _, v67 in v64, v65, v66 do
					if v67:IsA("ParticleEmitter") then
						v67.Enabled = true
					end
				end
				local v68 = v62["Arm BoostterrrrL"].Stage2
				local v69 = next
				local v70, v71 = v68:GetDescendants()
				for _, v72 in v69, v70, v71 do
					if v72:IsA("ParticleEmitter") then
						v72.Enabled = true
					end
				end
			end
		end,
		["DiveHit"] = function(p73)
			local v74 = p73:FindFirstChild("BoosterR", true)
			local v75 = p73:FindFirstChild("BoosterL", true)
			if v74 and v75 then
				task.wait(0.3)
				local v76 = v74["Arm BoostterrrrR"].Stage2
				local v77 = next
				local v78, v79 = v76:GetDescendants()
				for _, v80 in v77, v78, v79 do
					if v80:IsA("ParticleEmitter") then
						v80.Enabled = false
					end
				end
				local v81 = v75["Arm BoostterrrrL"].Stage2
				local v82 = next
				local v83, v84 = v81:GetDescendants()
				for _, v85 in v82, v83, v84 do
					if v85:IsA("ParticleEmitter") then
						v85.Enabled = false
					end
				end
				local v86 = v74["Arm BoostterrrrR"].Stage1
				local v87 = next
				local v88, v89 = v86:GetDescendants()
				for _, v90 in v87, v88, v89 do
					if v90:IsA("ParticleEmitter") then
						v90.Enabled = false
					end
				end
				local v91 = v75["Arm BoostterrrrL"].Stage1
				local v92 = next
				local v93, v94 = v91:GetDescendants()
				for _, v95 in v92, v93, v94 do
					if v95:IsA("ParticleEmitter") then
						v95.Enabled = false
					end
				end
				v75.PrimaryPart.Transparency = 1
				v74.PrimaryPart.Transparency = 1
			end
		end,
		["Grab"] = function(p96)
			-- upvalues: (ref) v_u_7, (ref) v_u_4
			local v97 = p96:FindFirstChild("HumanoidRootPart")
			if v97 then
				v_u_7:PlaySound(v_u_4.Mechamaru.PuppetBarrage.Grab, v97, game.SoundService.Effect)
				v_u_7:Flash(p96, Color3.new(1, 1, 1))
			end
		end,
		["Kickup"] = function(p98)
			-- upvalues: (ref) v_u_7, (ref) v_u_4
			local v99 = p98:FindFirstChild("HumanoidRootPart")
			if v99 then
				v_u_7:PlaySound(v_u_4.Mechamaru.PuppetBarrage.Kick, v99, game.SoundService.Effect)
			end
		end
	}
	v_u_5.Effects:Connect(function(p101, ...)
		-- upvalues: (copy) v_u_100
		local v102 = v_u_100[p101]
		if v102 then
			v102(...)
		end
	end)
	v_u_5.Hitbox:Connect(function(p103, p104, p105)
		-- upvalues: (ref) v_u_6, (ref) v_u_2
		local v106 = p104.HumanoidRootPart
		if not v106 then
			return
		end
		local v107 = p104.Owner.Value
		local v108 = p104.User.Value
		local v109 = p104.Friend.Value
		local v110 = nil
		while true do
			local v111 = v_u_6:SphereHitbox(p104, CFrame.new(0, 0, -4), 8)
			for _, v112 in v111 do
				if v112 ~= v107 and (v112 ~= v108 and v112 ~= v109) then
					local v113 = v112:FindFirstChild("Info")
					if v113 then
						local v114 = v113:FindFirstChild("Knockback")
						if not v114 or v114.Value ~= false then
							v110 = v111
							break
						end
					end
				end
			end
			if v110 then
				local v115 = p103:FindFirstChildWhichIsA("NumberValue")
				if v115 then
					v_u_2:Create(v115, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p103.Parent then
				break
			end
		end
		p105:FireServer(v110, v106.CFrame)
	end)
end
function v8.KnitInit(_)
	-- upvalues: (ref) v_u_5, (copy) v_u_1, (ref) v_u_6, (ref) v_u_7
	v_u_5 = v_u_1.GetService("PuppetBarrageService")
	v_u_6 = v_u_1.GetController("HitboxController")
	v_u_7 = v_u_1.GetController("FXController")
end
return v8