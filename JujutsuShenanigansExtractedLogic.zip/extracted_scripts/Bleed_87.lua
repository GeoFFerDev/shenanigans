-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = script.Parent
local v2 = v1.Parent
local v3 = require(game.ReplicatedStorage.Modules.BloodyZee)
local v4 = script:WaitForChild("Blood")
local v5 = script:WaitForChild("Attachment")
if game.Players.LocalPlayer.Character == v2 then
	script:ClearAllChildren()
else
	v4.Parent = v1.FaceFrontAttachment
	v5.Parent = v1
	repeat
		v5.Blood.Enabled = _G.Settings.Gore
		v4.Enabled = v5.Blood.Enabled
		v3:Blood(v1.CFrame * CFrame.Angles(-1.5707963267948966, 0, 0), math.random(10, 40), 80, 80)
		task.wait(math.random(5, 100) / 100)
	until not (v1.Parent and v2:GetAttribute("InUlt"))
	v4.Enabled = false
	v5.Blood.Enabled = false
end