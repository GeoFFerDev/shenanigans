-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

script.Parent.Speakers.ChildAdded:Connect(function(p1)
	p1:WaitForChild("Wire", 1).SourceInstance = script.Parent.Mic.AudioEqualizer
end)
for _, v2 in script.Parent.Speakers:GetChildren() do
	v2:WaitForChild("Wire", 1).SourceInstance = script.Parent.Mic.AudioEqualizer
end
script.Parent.Mic.ChildAdded:Connect(function(p3)
	if p3.Name == "Head" then
		p3:WaitForChild("Wire", 1).TargetInstance = script.Parent.Mic.AudioFader
	end
end)
script.Mic_Air.OnClientEvent:Connect(function(p4)
	local v5 = script.Parent.Mic
	if p4 == 1 then
		v5.JingleAir:Play()
		return
	elseif p4 == 2 then
		v5.JingleOff:Play()
	else
		v5.Train:Play()
	end
end)
local function v_u_8(p_u_6)
	local v_u_7 = p_u_6:WaitForChild("Button", 1)
	v_u_7.Enabled = not p_u_6:WaitForChild("Status", 1).Enabled
	p_u_6:WaitForChild("Status", 1):GetPropertyChangedSignal("Enabled"):Connect(function()
		-- upvalues: (copy) v_u_7, (copy) p_u_6
		v_u_7.Enabled = not p_u_6:WaitForChild("Status", 1).Enabled
	end)
	v_u_7.Triggered:Connect(function()
		-- upvalues: (copy) p_u_6
		if p_u_6.Parent.Name == "ButtonAir" then
			script.Mic_Air:FireServer()
		else
			script.Train:FireServer()
		end
	end)
end
script.Parent.ButtonTrain.ChildAdded:Connect(function(p9)
	-- upvalues: (copy) v_u_8
	if p9.Name == "Button" then
		v_u_8(p9)
	end
end)
v_u_8(script.Parent.ButtonTrain.Button)
local v_u_10 = RaycastParams.new()
v_u_10.FilterType = Enum.RaycastFilterType.Include
v_u_10.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_11 = game:GetService("TweenService")
script.Train.OnClientEvent:Connect(function()
	-- upvalues: (copy) v_u_11
	task.wait(0.25)
	local v12 = game.ReplicatedStorage.Utils.Misc.Train:Clone()
	v12.Parent = workspace.Effects
	v_u_11:Create(v12, TweenInfo.new(3, Enum.EasingStyle.Linear), {
		["CFrame"] = v12.CFrame + v12.CFrame.LookVector * 1200
	}):Play()
	for _, v13 in v12:GetChildren() do
		if v13:IsA("Sound") then
			v13.SoundGroup = game.SoundService.Effect
			v13:Play()
		end
	end
	task.wait(5)
	v12:Destroy()
end)
local v_u_14 = script.Parent.Mic.AudioEqualizer
v_u_14:GetPropertyChangedSignal("Bypass"):Connect(function()
	-- upvalues: (copy) v_u_14, (copy) v_u_11
	if v_u_14.Bypass == false then
		v_u_14.HighGain = 0
		v_u_14.LowGain = 0
		v_u_14.MidGain = 0
		v_u_11:Create(v_u_14, TweenInfo.new(0.5), {
			["HighGain"] = -80,
			["LowGain"] = -20,
			["MidGain"] = -80
		}):Play()
	end
end)
while task.wait(0.1) do
	pcall(function()
		-- upvalues: (copy) v_u_10
		local v15 = workspace.CurrentCamera.CFrame.Position
		local v16 = false
		for _, v17 in script.Parent.Speakers:GetChildren() do
			if (v17.Position - v15).Magnitude <= 300 then
				local v18 = workspace:Raycast(v15, v17.Position - v15, v_u_10)
				if not v18 or v18.Instance.Name == "Speaker" then
					v16 = true
					break
				end
			end
		end
		script.Parent.Mic.AudioEqualizer.Bypass = v16
	end)
end