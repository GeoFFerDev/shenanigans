-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = require(v6.Modules.SraikoVFX)
require(v6.Modules.LightningBeams)
local v_u_11 = RaycastParams.new()
v_u_11.FilterType = Enum.RaycastFilterType.Include
v_u_11.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
Random.new()
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "CollapseController"
})
function v15.KnitStart(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_7, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_8, (copy) v_u_11, (copy) v_u_10, (copy) v_u_4, (copy) v_u_2, (ref) v_u_12
	local v_u_91 = {
		["Hit"] = function(p16, p17)
			-- upvalues: (ref) v_u_13, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v18 = p17.HumanoidRootPart
			if v18 then
				v_u_13:Flash(p17, Color3.new(0.333333, 0.666667, 1), 0.2)
				local v19 = v_u_7.Nanami.Collapse.Slam.Emit.Strike.Hit:Clone()
				local v20 = Instance.new("Model")
				v19.Parent = v20
				v20:ScaleTo(0.75)
				v_u_3:AddItem(v20, 0.1)
				v19.Parent = v18
				for _, v_u_21 in pairs(v19:GetDescendants()) do
					if v_u_21:IsA("ParticleEmitter") then
						v_u_21:Emit(v_u_21:GetAttribute("EmitCount"))
						task.delay(0.05, function()
							-- upvalues: (copy) v_u_21
							v_u_21.TimeScale = 0.1
						end)
						task.delay(0.221, function()
							-- upvalues: (copy) v_u_21
							v_u_21.TimeScale = 1
						end)
					end
				end
				if p16 == v_u_5.Character or p17 == v_u_5.Character then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["Hit2"] = function(p22, p23)
			-- upvalues: (ref) v_u_13, (ref) v_u_5, (ref) v_u_9
			if p23.HumanoidRootPart then
				v_u_13:Flash(p23, Color3.new(0.333333, 0.666667, 1), 0.2)
				if p22 == v_u_5.Character or p23 == v_u_5.Character then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["Jump"] = function(p24, p25)
			-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_11, (ref) v_u_7, (ref) v_u_10, (ref) v_u_3
			local v26 = p24.HumanoidRootPart
			if v26 then
				if not p25 then
					v_u_13:PlaySound(v_u_8.Nanami.Collapse.Jump, v26, game.SoundService.Effect)
					local v27 = workspace:Raycast(v26.Position, Vector3.new(0, -10, 0), v_u_11)
					if v27 then
						for _, v28 in pairs(v_u_7.Nanami.Collapse.Jump.Meshes:GetChildren()) do
							local v29 = v28:Clone()
							local v30 = v_u_10.HandleMesh(v29, CFrame.new(v27.Position) * (p24.HumanoidRootPart.CFrame - p24.HumanoidRootPart.CFrame.Position) * CFrame.Angles(0.5235987755982988, 0, 0))
							v29.Parent = workspace.Effects
							v_u_3:AddItem(v29, v30)
						end
						v_u_10.Emit(v_u_7.Nanami.Collapse.Jump.Jump, CFrame.new(v27.Position, v27.Position + v27.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
					end
				end
			else
				return
			end
		end,
		["ArmEmit"] = function(p31)
			-- upvalues: (ref) v_u_7, (ref) v_u_10, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_8
			local v32 = p31.HumanoidRootPart
			if v32 then
				for _, v33 in pairs(v_u_7.Nanami.Collapse.ChargeEmit.Meshes:GetChildren()) do
					local v34 = v33:Clone()
					local v35 = v_u_10.HandleMesh(v34, v32.CFrame)
					v34.Parent = workspace.Effects
					v_u_3:AddItem(v34, v35)
				end
				local v36 = v_u_7.Nanami.Collapse.ChargeEmit.Emit.Strike:Clone()
				v36.CFrame = v32.CFrame
				v36.Parent = workspace.Effects
				v_u_3:AddItem(v36, 3)
				for _, v_u_37 in pairs(v36:GetDescendants()) do
					if v_u_37:IsA("ParticleEmitter") then
						v_u_37:Emit(v_u_37:GetAttribute("EmitCount"))
					end
					if v_u_37:IsA("Beam") then
						v_u_37.Enabled = true
						v_u_4:Create(v_u_37, TweenInfo.new(0.3), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
						task.delay(0.4, function()
							-- upvalues: (copy) v_u_37
							v_u_37.Enabled = false
							v_u_37.Width0 = 25
							v_u_37.Width1 = 25
						end)
					end
				end
				v_u_13:PlaySound(v_u_8.Nanami.Collapse.Charge, v32, game.SoundService.Effect)
			end
		end,
		["Leap"] = function(p38, p39, p40, _, _)
			-- upvalues: (ref) v_u_5, (ref) v_u_2
			local v41 = p38.HumanoidRootPart
			if not v41 then
				return
			end
			local v42 = p38:FindFirstChild("Humanoid")
			if not v42 then
				return
			end
			if v_u_5.Character == p38 then
				local v43 = v41.AssemblyLinearVelocity
				local _ = v43.Magnitude
				local v44 = v41.Position + v43 / 10
				local v45 = Instance.new("BodyGyro", v41)
				v45.P = 0
				v45.MaxTorque = Vector3.new(0, 0, 0)
				p39.Position = v44
				local v46 = tick()
				v42.PlatformStand = true
				local v47 = false
				while true do
					local v48 = v_u_2.Heartbeat:Wait()
					local v49 = v43.Unit
					local v50 = v45.MaxTorque.X
					local v51 = v50 + (40000 - v50) * 25 * v48
					v45.MaxTorque = Vector3.new(v51, v51, v51)
					v45.P = v45.P + (10000 - v45.P) * 25 * v48
					local v52 = v49:Lerp(workspace.CurrentCamera.CFrame.LookVector, 25 * v48).Unit
					local v53 = v43:Lerp(v52 * v43.Magnitude, 25 * v48)
					local v54 = -workspace.Gravity
					v43 = v53 + Vector3.new(0, v54, 0) * v48
					v44 = v44 + v43 * v48
					local v55 = workspace:Raycast(v41.Position, v43.Unit * 10, _G.MapParams)
					if v55 then
						v44 = v55.Position - v43.Unit * 5
						if not v47 and tick() - v46 > 0.3 then
							p40:FireServer(v55.Position, v55.Normal, v41.Position)
							v47 = true
						end
					end
					p39.Position = v44
					v45.CFrame = CFrame.lookAt(v41.Position, v41.Position + v52)
					task.wait()
					if not p39.Parent then
						v45:Destroy()
						repeat
							task.wait()
						until not v41:FindFirstChild("CollapseBG")
						v42.PlatformStand = false
						goto l6
					end
				end
			else
				::l6::
				return
			end
		end,
		["Collapse"] = function(p56, p57, p58)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10
			local v59 = p56.HumanoidRootPart
			if v59 then
				local v60 = v_u_7.Gojo.LapseBlue.LapseBlue.Grab:Clone()
				v60.Weld:Destroy()
				v60.Anchored = true
				v60.Position = p57
				v60.Size = Vector3.new(50, 50, 50)
				v60.Parent = workspace.Effects
				local v61 = Instance.new("Highlight", v60)
				v61.FillTransparency = 1
				v61.OutlineTransparency = 1
				v_u_4:Create(v60, TweenInfo.new(0.226, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["Size"] = Vector3.new(0, 0, 0),
					["Transparency"] = 50
				}):Play()
				v_u_3:AddItem(v60, 0.5)
				local v62 = v_u_7.Nanami.Collapse.OrbEmit.Strike:Clone()
				v62.CFrame = CFrame.new(p57, p57 + p58) * CFrame.new(0, 0, -2)
				v62.Parent = workspace.Effects
				v_u_3:AddItem(v62, 6)
				v62.Beams.WorldCFrame = CFrame.lookAt(p57, (v59.CFrame * CFrame.new(0, -4.5, 0)).Position) * CFrame.new(0, 0, -1) * CFrame.Angles(0, 3.141592653589793, 0)
				v62.Beams2.WorldCFrame = CFrame.lookAt(p57, (v59.CFrame * CFrame.new(0, -4.5, 0)).Position) * CFrame.new(0, 0, -1) * CFrame.Angles(0, 3.141592653589793, 0)
				for _, v63 in pairs(v62:GetDescendants()) do
					if v63:IsA("ParticleEmitter") then
						v63.Enabled = true
					end
				end
				for _, v64 in pairs(v62.Beams:GetDescendants()) do
					if v64:IsA("Beam") then
						v64.Enabled = true
					end
				end
				v_u_13:PlaySound(v_u_8.Nanami.Collapse.Impact, v62, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - p57).Magnitude < 100 then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(0.226)
				end
				task.wait(0.226)
				if (workspace.CurrentCamera.CFrame.Position - p57).Magnitude < 100 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				for _, v65 in pairs(v62:GetDescendants()) do
					if v65:IsA("ParticleEmitter") then
						v65.Enabled = false
					end
					if v65:IsA("Beam") then
						v65.Enabled = false
					end
				end
				for _, v66 in pairs(v_u_7.Nanami.Collapse.Slam.Meshes:GetChildren()) do
					local v67 = v66:Clone()
					local v68 = v_u_10.HandleMesh(v67, CFrame.new(p57, p57 + p58) * CFrame.new(0, 0, 7))
					v67.Parent = workspace.Effects
					v_u_3:AddItem(v67, v68)
				end
				v_u_10.Emit(v_u_7.Nanami.Collapse.Slam.Emit.Strike, CFrame.new(p57, p57 + p58))
				for _, v_u_69 in pairs(v62.Beams2:GetDescendants()) do
					if v_u_69:IsA("Beam") then
						v_u_69.Enabled = true
						v_u_4:Create(v_u_69, TweenInfo.new(0.2), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
						task.delay(0.30000000000000004, function()
							-- upvalues: (copy) v_u_69
							v_u_69.Enabled = false
							v_u_69.Width0 = 45
							v_u_69.Width1 = 45
						end)
					end
				end
			end
		end,
		["CollapseDebree"] = function(p70, p71, p72)
			-- upvalues: (ref) v_u_2, (ref) v_u_13, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v_u_73 = p70.HumanoidRootPart
			if v_u_73 then
				v_u_2.Heartbeat:Wait()
				local v_u_74 = {}
				p72.AncestryChanged:Once(function()
					-- upvalues: (ref) v_u_13, (ref) v_u_8, (copy) v_u_73, (copy) v_u_74
					v_u_13:PlaySound(v_u_8.Nanami.Collapse.Activate, v_u_73, game.SoundService.Effect)
					task.wait(0.5)
					for _, v75 in pairs(v_u_74) do
						v75:Destroy()
					end
				end)
				for v76 = 1, buffer.len(p71) / 2 do
					local v77 = (v76 - 1) * 2
					local v78 = buffer.readu16(p71, v77)
					local v79 = v_u_13.Voxels[v78]
					if v79[2] == nil or v79[2] ~= false then
						for _, v80 in pairs(v_u_7.Nanami.Collapse.Rock:GetChildren()) do
							local v81 = v80:Clone()
							table.insert(v_u_74, v81)
							v81.Parent = v79[1]
							v_u_3:AddItem(v81, 10)
						end
					end
				end
			end
		end,
		["Break"] = function(p82)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_9
			local v83 = v_u_7.Nanami.Collapse.Break:Clone()
			v83.CFrame = CFrame.new(p82)
			v83.Parent = workspace.Effects
			v_u_3:AddItem(v83, 3)
			v_u_13:PlaySound(v_u_8.Nanami.Collapse.DebreeDrop, v83, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
			for _, v84 in pairs(v83:GetDescendants()) do
				if v84:IsA("ParticleEmitter") then
					v84:Emit(v84:GetAttribute("EmitCount"))
				end
			end
			if (workspace.CurrentCamera.CFrame.Position - p82).Magnitude < 65 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
			end
		end,
		["Launch"] = function(p85, p86)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v87 = p85:FindFirstChild("HumanoidRootPart")
			if v87 then
				local v88 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v88.CFrame = CFrame.new(v87.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v88.Size = Vector3.new(0, 0, 5)
				v88.Parent = workspace.Effects
				v_u_4:Create(v88, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v88.Position + Vector3.new(0, p86, 0)
				}):Play()
				v_u_3:AddItem(v88, 0.3)
				if p86 < 0 then
					v_u_13:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v87, game.SoundService.Effect)
					v_u_13:DustBreak(v87.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v87.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Finisher"] = function(p89)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_13
			if p89.HumanoidRootPart then
				if _G.Settings.Gore then
					local v90 = v_u_7.Heian.BloodSpread:Clone()
					v90.Parent = p89.Head
					v90:Emit(20)
					v_u_3:AddItem(v90, 2)
				end
				v_u_13:Bleed(p89)
			end
		end
	}
	v_u_12.Effects:Connect(function(p92, ...)
		-- upvalues: (copy) v_u_91
		local v93 = v_u_91[p92]
		if v93 then
			v93(...)
		end
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_14, (ref) v_u_13
	v_u_12 = v_u_1.GetService("CollapseService")
	v_u_14 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v15