-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {}
local v_u_2 = game:GetService("EncodingService")
function v_u_1.to_base64raw(p3)
	return (p3:gsub(".", function(p4)
		local v5 = p4:byte()
		local v6 = ""
		for v7 = 8, 1, -1 do
			v6 = v6 .. (v5 % 2 ^ v7 - v5 % 2 ^ (v7 - 1) > 0 and "1" or "0")
		end
		return v6
	end) .. "0000"):gsub("%d%d%d?%d?%d?%d?", function(p8)
		if #p8 < 6 then
			return ""
		end
		local v9 = 0
		for v10 = 1, 6 do
			v9 = v9 + (p8:sub(v10, v10) == "1" and (2 ^ (6 - v10) or 0) or 0)
		end
		return ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"):sub(v9 + 1, v9 + 1)
	end) .. ({ "", "==", "=" })[#p3 % 3 + 1]
end
function v_u_1.from_base64raw(p11)
	return string.gsub(p11, "[^ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=]", ""):gsub(".", function(p12)
		if p12 == "=" then
			return ""
		end
		local v13 = ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"):find(p12) - 1
		local v14 = ""
		for v15 = 6, 1, -1 do
			v14 = v14 .. (v13 % 2 ^ v15 - v13 % 2 ^ (v15 - 1) > 0 and "1" or "0")
		end
		return v14
	end):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(p16)
		if #p16 ~= 8 then
			return ""
		end
		local v17 = 0
		for v18 = 1, 8 do
			v17 = v17 + (p16:sub(v18, v18) == "1" and (2 ^ (8 - v18) or 0) or 0)
		end
		return string.char(v17)
	end)
end
function v_u_1.to_base64(p_u_19)
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local _, v21 = pcall(function()
		-- upvalues: (ref) p_u_19, (ref) v_u_2
		local v20 = v_u_2:CompressBuffer(buffer.fromstring(p_u_19), Enum.CompressionAlgorithm.Zstd)
		p_u_19 = buffer.tostring(v20)
	end)
	if v21 then
		warn(v21)
	end
	return v_u_1.to_base64raw(p_u_19)
end
function v_u_1.from_base64(p22)
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v_u_23 = v_u_1.from_base64raw(p22)
	local _, v25 = pcall(function()
		-- upvalues: (ref) v_u_23, (ref) v_u_2
		local v24 = v_u_2:DecompressBuffer(buffer.fromstring(v_u_23), Enum.CompressionAlgorithm.Zstd)
		v_u_23 = buffer.tostring(v24)
	end)
	if v25 then
		warn(v25)
	end
	return v_u_23
end
return v_u_1