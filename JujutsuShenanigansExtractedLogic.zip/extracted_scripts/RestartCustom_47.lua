-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Name"] = "restartcustom",
	["Description"] = "Restarts all custom / private servers",
	["Group"] = { "Owner" },
	["Args"] = {}
}