-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.EffectUtils)
local v_u_10 = require(v5.Modules.BloodyZee)
local v_u_11 = require(v5.Knit.Trove)
local v12 = require(v5.Modules.SraikoVFX)
local v_u_13 = v12.Enabled
local v_u_14 = v12.Emit
local v_u_15 = v12.EmitMesh
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local v19 = v_u_1.CreateController({
	["Name"] = "UltraSpinController"
})
function v19.KnitStart(_)
	-- upvalues: (copy) v_u_11, (copy) v_u_6, (ref) v_u_18, (copy) v_u_7, (copy) v_u_3, (copy) v_u_9, (copy) v_u_2, (copy) v_u_10, (copy) v_u_4, (copy) v_u_8, (copy) v_u_14, (copy) v_u_15, (copy) v_u_13, (ref) v_u_16
	local v_u_96 = {
		["Start"] = function(p20, p21)
			-- upvalues: (ref) v_u_11, (ref) v_u_6, (ref) v_u_18, (ref) v_u_7, (ref) v_u_3
			local v22 = p20:FindFirstChild("HumanoidRootPart")
			local v23 = p20:FindFirstChild("Right Arm")
			if p21.Parent and (v22 and v23) then
				local v24 = v_u_11.new()
				v24:AttachToInstance(p21)
				local v25 = v24:Clone(v_u_6.Mechamaru.Drill)
				v25.Weld.Part0 = v23
				v25.B.Weld.Part0 = v23
				v25.F.Weld.Part0 = v23
				v25.L.Weld.Part0 = v23
				v25.R.Weld.Part0 = v23
				v25.Parent = p20
				local v26 = v_u_18:PlaySound(v_u_7.Mechamaru.UltraSpin.Start, v22, game.SoundService.Effect)
				task.wait(0.3)
				v_u_3:Create(v26, TweenInfo.new(0.5), {
					["Volume"] = 0
				}):Play()
				v_u_18:PlaySound(v_u_7.Mechamaru.UltraSpin.Dash, v22, game.SoundService.Effect)
			end
		end,
		["DrillAppear"] = function(p27, p_u_28)
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			local v_u_29 = p27:FindFirstChild("HumanoidRootPart")
			if p_u_28.Parent and v_u_29 then
				p27:FindFirstChild("Right Arm")
				p27:FindFirstChild("Left Arm")
				local v_u_30 = p27:FindFirstChild("Drill")
				if v_u_30 then
					v_u_9.Visibility(v_u_30, true)
					for _, v_u_31 in v_u_6.Mechamaru.UltraSpinVFX.DrillRepeat.Meshes:GetChildren() do
						task.spawn(function()
							-- upvalues: (copy) v_u_31, (copy) p_u_28, (copy) v_u_29, (ref) v_u_9, (copy) v_u_30
							for _ = 1, v_u_31:GetAttribute("RepeatCount") do
								if not p_u_28.Parent or v_u_29:FindFirstChild("GrabWeld") then
									break
								end
								v_u_9.AutoMeshes(v_u_31, v_u_30.Metalbit)
								task.wait(v_u_31:GetAttribute("RepeatDelay"))
							end
						end)
					end
				end
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraSpinVFX.DrillAppear, v_u_29)
			end
		end,
		["DrillWindup"] = function(p32, p33)
			-- upvalues: (ref) v_u_9
			local v34 = p32:FindFirstChild("Drill")
			if p33.Parent and v34 then
				v_u_9.Enable("ParticleEmitter", v34.Metalbit.Sparks)
			end
		end,
		["DrillSwing"] = function(p35, p36)
			-- upvalues: (ref) v_u_11, (ref) v_u_9, (ref) v_u_6
			local v37 = p35:FindFirstChild("HumanoidRootPart")
			if p36.Parent and v37 then
				local v_u_38 = v_u_11.new()
				v_u_38:AttachToInstance(p36)
				local v_u_39 = v_u_9.Enable("ParticleEmitter", v_u_6.Mechamaru.UltraSpinVFX.DrillSwing.WindEnable, v37, 0.65)
				v_u_38:Connect(v37.ChildAdded, function(p40)
					-- upvalues: (copy) v_u_38
					if p40.Name == "GrabWeld" then
						v_u_38:Clean()
					end
				end)
				v_u_38:Add(function()
					-- upvalues: (ref) v_u_9, (copy) v_u_39
					v_u_9.Enable("ParticleEmitter", v_u_39, nil, nil, true)
				end)
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraSpinVFX.DrillSwing, v37)
			end
		end,
		["DrillHide"] = function(p41)
			-- upvalues: (ref) v_u_9
			local v42 = p41:FindFirstChild("Drill")
			if v42 then
				v_u_9.Visibility(v42, false)
			end
		end,
		["DrillStop"] = function(p43)
			-- upvalues: (ref) v_u_9, (ref) v_u_18, (ref) v_u_7
			local v44 = p43:FindFirstChild("HumanoidRootPart")
			if v44 then
				local v45 = p43:FindFirstChild("Drill")
				if v45 then
					v_u_9.Enable("ParticleEmitter", v45, nil, nil, true)
				end
				v_u_18:PlaySound(v_u_7.Mechamaru.UltraSpin.End, v44, game.SoundService.Effect)
			end
		end,
		["HitSound"] = function(p46)
			-- upvalues: (ref) v_u_18, (ref) v_u_7
			if p46 then
				p46 = p46:FindFirstChild("HumanoidRootPart")
			end
			if p46 then
				v_u_18:PlaySound(v_u_7.Mechamaru.UltraSpin.Hit, p46, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p47, p_u_48, p_u_49, p50)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_11, (ref) v_u_2, (ref) v_u_18, (ref) v_u_7, (ref) v_u_10, (ref) v_u_4, (ref) v_u_8
			local v_u_51 = p47:FindFirstChild("HumanoidRootPart")
			if v_u_51 then
				local v_u_52
				if p_u_49 then
					v_u_52 = p_u_49:FindFirstChild("HumanoidRootPart")
				else
					v_u_52 = p_u_49
				end
				if v_u_52 then
					if p50 and p_u_48.Parent then
						local v_u_53 = p47:FindFirstChild("Drill")
						if v_u_53 then
							v_u_9.Enable("ParticleEmitter", v_u_53.Metalbit.Hits)
							for _, v_u_54 in v_u_6.Mechamaru.UltraSpinVFX.DrillRepeat.Meshes:GetChildren() do
								task.spawn(function()
									-- upvalues: (copy) v_u_54, (copy) p_u_48, (ref) v_u_9, (copy) v_u_53
									for _ = 1, v_u_54:GetAttribute("RepeatCount") do
										if not p_u_48.Parent then
											break
										end
										v_u_9.AutoMeshes(v_u_54, v_u_53.Metalbit)
										task.wait(v_u_54:GetAttribute("RepeatDelay"))
									end
								end)
							end
						end
						local v55 = v_u_11.new()
						v55:AttachToInstance(p_u_48)
						local v_u_56 = v_u_9.Enable("ParticleEmitter", v_u_6.Mechamaru.UltraSpinVFX.DrillSwing.WindEnable, v_u_51)
						v55:Add(function()
							-- upvalues: (ref) v_u_9, (copy) v_u_56
							v_u_9.Debris(v_u_56, 2)
							v_u_9.Enable("ParticleEmitter", v_u_56, nil, nil, true)
						end)
						task.spawn(function()
							-- upvalues: (ref) v_u_6, (copy) v_u_51, (ref) v_u_2, (ref) v_u_18, (copy) p_u_49, (ref) v_u_7, (copy) v_u_52, (ref) v_u_10, (copy) p_u_48
							local v57 = v_u_6.Mahito.Drill.DrillImpact:Clone()
							v57.Position = v_u_51.Position
							v57.Parent = workspace.Effects
							v_u_2:AddItem(v57, 1)
							if _G.Settings.Gore == true then
								v57.Blood.Enabled = true
								v57.Hit.Enabled = true
							end
							repeat
								v_u_18:Flash(p_u_49, Color3.new(1, 1, 1))
								v_u_18:PlaySound(v_u_7.Mahito.DrillSplit.DrillHit, v_u_52, game.SoundService.Effect)
								v_u_10:Blood(v_u_52.CFrame, 70, 180, 180)
								v57.Position = p_u_49.Torso.Position
								task.wait(0.075)
							until not p_u_48:IsDescendantOf(workspace.Characters) or p_u_48:GetAttribute("Finisher")
							v57.Blood.Enabled = false
							v57.Hit.Enabled = false
						end)
					end
					if v_u_4.Character == p47 or v_u_4.Character == p_u_49 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyLoop)
					end
				end
			else
				return
			end
		end,
		["FinalHit"] = function(p58, _, p59, _)
			-- upvalues: (ref) v_u_18, (ref) v_u_10, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v60
			if p59 then
				v60 = p59:FindFirstChild("HumanoidRootPart")
			else
				v60 = p59
			end
			if v60 then
				v_u_18:Flash(p59, Color3.new(0.8, 0, 0))
				local v61 = CFrame.lookAlong(v60.Position, Vector3.new(0, 1, 0))
				for _ = 1, 8 do
					v_u_10:Blood(v61, math.random(55, 70), 35, 35)
				end
				local v62 = p58:FindFirstChild("HumanoidRootPart")
				if v62 then
					v_u_9.AutoEffects(v_u_6.Mechamaru.UltraSpinVFX.DrillSlam, v62)
					local v63 = v60.Position - Vector3.new(0, 3, 0)
					local v64 = v_u_6.Hiromi.Shockwave:Clone()
					v64.Position = v63
					v64.Parent = workspace.Effects
					local v65 = v64.CFrame
					local v66 = CFrame.Angles
					local v67 = math.random(-179, 179)
					v64.CFrame = v65 * v66(0, math.rad(v67), 0)
					v_u_3:Create(v64.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
						["Scale"] = Vector3.new(15, 0, 15)
					}):Play()
					v_u_3:Create(v64.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
						["Transparency"] = 1
					}):Play()
					v64.Floor.Glow:Emit(1)
					v64.Floor.Ring:Emit(10)
					v_u_2:AddItem(v64, 1.5)
					local v68 = v_u_6.Choso.CounterSwing.Shock:Clone()
					v68.Size = Vector3.new(10, 30, 10)
					v68.CFrame = CFrame.new(v63)
					v68.Parent = workspace.Effects
					v_u_2:AddItem(v68, 0.3)
					v_u_3:Create(v68, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(36, 7, 36),
						["Transparency"] = 1,
						["Position"] = v68.Position - Vector3.new(0, 3, 0)
					}):Play()
					local v69 = v_u_6.Choso.CounterSwing.Shock:Clone()
					v69.Size = Vector3.new(20, 10, 20)
					v69.CFrame = CFrame.new(v63)
					v69.Parent = workspace.Effects
					v_u_2:AddItem(v69, 0.2)
					v_u_3:Create(v69, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(0, 36, 0),
						["Transparency"] = 1,
						["Position"] = v69.Position + Vector3.new(0, 10, 0)
					}):Play()
					v_u_18:DustBreak(v63 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					v_u_18:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v64, game.SoundService.Effect)
					v_u_18:PlaySound(v_u_7.Hakari.Impact, v64, game.SoundService.Effect)
					if v_u_4.Character == p58 or v_u_4.Character == p59 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end,
		["Finisher"] = function(p70)
			-- upvalues: (ref) v_u_18, (ref) v_u_7
			local v71 = p70:FindFirstChild("HumanoidRootPart")
			if v71 then
				v_u_18:PlaySound(v_u_7.Mechamaru.UltraSpin.Finisher, v71, game.SoundService.Effect)
			end
		end,
		["DrillClose"] = function(p72, _)
			-- upvalues: (ref) v_u_14, (ref) v_u_6, (ref) v_u_15
			local v73 = p72:FindFirstChild("HumanoidRootPart")
			if v73 then
				v_u_14(v_u_6.Mechamaru.UltraSpinVFX.DrillClose.Emit.Strike, v73, true, 5)
				v_u_15(v_u_6.Mechamaru.UltraSpinVFX.DrillClose.Meshes.Mesh, v73)
			end
		end,
		["BurstEnableTrue"] = function(p74)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_14, (ref) v_u_15
			local v75 = p74:FindFirstChild("Right Arm")
			local v76 = p74:FindFirstChild("HumanoidRootPart")
			if v75 and v76 then
				local v77 = v_u_6.Mechamaru["Hand blasterR"]:Clone()
				v77.Weld.Part0 = v75
				if p74:GetAttribute("Moveset") ~= "Mechamaru" then
					v77.BlasterR.Transparency = 1
					v77.Neon.Transparency = 1
				end
				v77.Parent = p74
				v_u_2:AddItem(v77, 4)
				v_u_14(v_u_6.Mechamaru.UltraSpinVFX.ShootReady.Emit.Strike, v76, true, 5)
				v_u_15(v_u_6.Mechamaru.UltraSpinVFX.ShootReady.Meshes.Mesh, v76)
			end
		end,
		["BurstEnableFalse"] = function(p78)
			-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_6
			local v79 = p78:FindFirstChild("Hand blasterR")
			local v80 = p78:FindFirstChild("HumanoidRootPart")
			if v79 and v80 then
				v_u_13(v79, false)
				v_u_14(v_u_6.Mechamaru.UltraSpinVFX.Shoot.Emit.Strike, v80, true, 5)
			end
		end,
		["Burn"] = function(p81, p82)
			-- upvalues: (ref) v_u_6, (ref) v_u_13, (ref) v_u_15
			local v83 = p81:FindFirstChild("HumanoidRootPart")
			if v83 then
				local v_u_84 = v_u_6.Mechamaru.UltraSpinVFX.Burn.Emit.Strike:Clone()
				v_u_13(v_u_84, true, v83, true, 4, { "Beam", "ParticleEmitter" })
				v_u_84.Parent = workspace.Effects
				v_u_15(v_u_6.Mechamaru.UltraSpinVFX.Burn.Meshes.Mesh, v83)
				p82:GetAttributeChangedSignal("Disable"):Once(function()
					-- upvalues: (ref) v_u_13, (copy) v_u_84
					v_u_13(v_u_84, false, nil, nil, nil, { "Beam", "ParticleEmitter" })
				end)
			end
		end,
		["Burn2"] = function(p85)
			-- upvalues: (ref) v_u_15, (ref) v_u_6
			local v86 = p85:FindFirstChild("HumanoidRootPart")
			if v86 then
				v_u_15(v_u_6.Mechamaru.UltraSpinVFX.Burn2.Meshes.Mesh, v86)
			end
		end,
		["Burn3"] = function(p87)
			-- upvalues: (ref) v_u_15, (ref) v_u_6
			local v88 = p87:FindFirstChild("HumanoidRootPart")
			if v88 then
				v_u_15(v_u_6.Mechamaru.UltraSpinVFX.Burn3.Meshes.Mesh, v88)
			end
		end,
		["Strike2"] = function(p89, p90)
			-- upvalues: (ref) v_u_15, (ref) v_u_6, (ref) v_u_13
			local v91 = p89:FindFirstChild("HumanoidRootPart")
			if v91 then
				v_u_15(v_u_6.Mechamaru.UltraSpinVFX.Burn4.Meshes.Mesh, v91)
				p90:SetAttribute("Disable", true)
				local v_u_92 = v_u_6.Mechamaru.UltraSpinVFX.Burn.Emit.Strike2:Clone()
				v_u_13(v_u_92, true, v91, true, 4, { "Beam", "ParticleEmitter" })
				v_u_92.Parent = workspace.Effects
				p90:GetAttributeChangedSignal("Disable"):Once(function()
					-- upvalues: (ref) v_u_13, (copy) v_u_92
					v_u_13(v_u_92, false, nil, nil, nil, { "Beam", "ParticleEmitter" })
				end)
			end
		end,
		["Burnt"] = function(p93)
			-- upvalues: (ref) v_u_14, (ref) v_u_6
			local v94 = p93:FindFirstChild("HumanoidRootPart")
			if v94 then
				v_u_14(v_u_6.Mechamaru.UltraSpinVFX.Burnt.Emit.Strike, v94, true, 5)
			end
		end,
		["BurnFalse"] = function(_, p95)
			p95:SetAttribute("Disable", nil)
		end
	}
	v_u_16.Effects:Connect(function(p97, ...)
		-- upvalues: (copy) v_u_96
		local v98 = v_u_96[p97]
		if v98 then
			v98(...)
		end
	end)
end
function v19.KnitInit(_)
	-- upvalues: (ref) v_u_16, (copy) v_u_1, (ref) v_u_17, (ref) v_u_18
	v_u_16 = v_u_1.GetService("UltraSpinService")
	v_u_17 = v_u_1.GetController("HitboxController")
	v_u_18 = v_u_1.GetController("FXController")
end
return v19