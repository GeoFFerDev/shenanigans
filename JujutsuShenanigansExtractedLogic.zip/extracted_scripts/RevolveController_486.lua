-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local v_u_4 = v3.Utils
local v_u_5 = v3.Sounds
require(v3.Modules.CameraShaker)
local v_u_6 = require(v3.Modules.BloodyZee)
local v_u_7 = RaycastParams.new()
v_u_7.FilterType = Enum.RaycastFilterType.Include
v_u_7.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "RevolveController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_5, (copy) v_u_4, (copy) v_u_2, (copy) v_u_6, (ref) v_u_8, (copy) v_u_7, (ref) v_u_9
	local v_u_25 = {
		["DiveSound"] = function(p12, p13)
			-- upvalues: (ref) v_u_10, (ref) v_u_5
			local v14 = p12:FindFirstChild("HumanoidRootPart")
			if v14 then
				if p13.Parent then
					v_u_10:PlaySound(v_u_5.Yuta.RevolveDive, v14, game.SoundService.Effect)
					local v_u_15 = v_u_10:PlaySound(v_u_5.Yuta.VeilstepDive, v14, game.SoundService.Effect)
					p13.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_15
						v_u_15:Destroy()
					end)
				end
			else
				return
			end
		end,
		["Land"] = function(p16)
			-- upvalues: (ref) v_u_4, (ref) v_u_2, (ref) v_u_10, (ref) v_u_5
			local v17 = v_u_4.Itadori.CrushingBlow:Clone()
			v17.PointLight:Destroy()
			v17.Beam:Destroy()
			v17.Position = p16
			v17.Parent = workspace.Effects
			v17.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 1, 1))
			v17.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v17, 1.5)
			v_u_10:PlaySound(v_u_5.Yuta.RevolveLand, v17, game.SoundService.Effect)
		end,
		["Spin"] = function(p18)
			-- upvalues: (ref) v_u_4, (ref) v_u_2
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = v_u_4.Yuta.Veilstep.Spin.SpinRing:Clone()
				v20.Parent = v19
				v_u_2:AddItem(v20, 0.5)
				v20.CFrame = v20.CFrame * CFrame.Angles(0, 0, 0.4363323129985824)
				v20.Ring:Emit(10)
			end
		end,
		["Impale"] = function(p21)
			-- upvalues: (ref) v_u_10, (ref) v_u_5
			local v22 = p21:FindFirstChild("HumanoidRootPart")
			if v22 then
				v_u_10:Flash(p21, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_5.Yuta.M1.Hit1, v22, game.SoundService.Effect)
			end
		end,
		["ImpaleFinisher"] = function(p23)
			-- upvalues: (ref) v_u_6
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				while true do
					task.wait(0.1)
					if not v24.Parent then
						break
					end
					v_u_6:Blood(v24.CFrame * CFrame.new(0, 0, -0.5), 50, 10, 10)
					if not v24.Parent then
						break
					end
				end
			end
		end
	}
	v_u_8.Effects:Connect(function(p26, ...)
		-- upvalues: (copy) v_u_25
		local v27 = v_u_25[p26]
		if v27 then
			v27(...)
		end
	end)
	v_u_8.Hitbox:Connect(function(p28, p29, p30)
		-- upvalues: (ref) v_u_7, (ref) v_u_9
		local v31 = p29.HumanoidRootPart
		if not v31 then
			return
		end
		while true do
			local v32 = workspace:Raycast(v31.Position, p28.Velocity.Unit * 7 + v31.CFrame.LookVector * 3, v_u_7)
			local v33 = v_u_9:SphereHitbox(p29, CFrame.new(0, -5, -5), 8)
			if #v33 > 0 or v32 then
				if #v33 <= 0 then
					v33 = false
				end
				local v34
				if v32 then
					v34 = v32.Position
				else
					v34 = v32
				end
				p30:FireServer(v33, v34)
				if v32 then
					p28:Destroy()
				end
			end
			task.wait(0.025)
			if not p28.Parent then
				return
			end
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9, (ref) v_u_10
	v_u_8 = v_u_1.GetService("RevolveService")
	v_u_9 = v_u_1.GetController("HitboxController")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11