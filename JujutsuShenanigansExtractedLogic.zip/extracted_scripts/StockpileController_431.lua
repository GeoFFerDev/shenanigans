-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "StockpileController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_3, (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10
	local v_u_44 = {
		["Create"] = function(p13, p_u_14, p_u_15)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_3, (ref) v_u_6, (ref) v_u_2
			local v16 = p13:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_11:PlaySound(v_u_7.Mahito.Stockpile.Create, v16, game.SoundService.Effect)
				local function v_u_19(p17)
					-- upvalues: (ref) v_u_3, (ref) v_u_6, (ref) v_u_2
					v_u_3:Create(p17, TweenInfo.new(0.2), {
						["Transparency"] = 0
					}):Play()
					for _ = 1, 10 do
						local v18 = v_u_6.Mahito.Morph:Clone()
						v18.Weld.Part0 = p17
						v18.Color = p17.Color
						v18.Material = p17.Material
						v18.Weld.C1 = CFrame.new(math.random(-p17.Size.X, p17.Size.X) / 2, math.random(-p17.Size.Y, p17.Size.Y) / 2, math.random(-p17.Size.Z, p17.Size.Z) / 2)
						v18.Parent = workspace.Effects
						v18.Size = Vector3.new(1, 1, 1) * (math.random(15, 35) / 10)
						v_u_3:Create(v18, TweenInfo.new(math.random(10, 40) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_2:AddItem(v18, 0.4)
					end
				end
				p_u_14.Transparency = 1
				p_u_14.Head.Transparency = 1
				p_u_15.Transparency = 1
				p_u_15.Head.Transparency = 1
				v_u_19(p_u_14)
				v_u_19(p_u_15)
				task.delay(0.2, function()
					-- upvalues: (copy) v_u_19, (copy) p_u_14, (copy) p_u_15
					v_u_19(p_u_14.Head)
					v_u_19(p_u_15.Head)
				end)
				p_u_14.Destroying:Connect(function()
					-- upvalues: (copy) p_u_14, (ref) v_u_2
					local v20 = p_u_14:Clone()
					v20.CanCollide = true
					v20.Weld:Destroy()
					v20.Parent = workspace.Effects
					v_u_2:AddItem(v20, 2)
				end)
				p_u_15.Destroying:Connect(function()
					-- upvalues: (copy) p_u_14, (copy) p_u_15, (ref) v_u_2
					if p_u_14 ~= p_u_15 then
						local v21 = p_u_15:Clone()
						v21.CanCollide = true
						v21.Weld:Destroy()
						v21.Parent = workspace.Effects
						v_u_2:AddItem(v21, 2)
					end
				end)
			end
		end,
		["Swing"] = function(p22, p23)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v24 = p22:FindFirstChild("HumanoidRootPart")
			if v24 then
				if p23 then
					v_u_11:PlaySound(v_u_7.Mahito.Stockpile.Swing, v24, game.SoundService.Effect)
				else
					v_u_11:PlaySound(v_u_7.Mahito.Stockpile.Swing2, v24, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Hit"] = function(_, p25)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v26 = p25:FindFirstChild("HumanoidRootPart")
			if v26 then
				v_u_11:Flash(p25, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.CraniumSmash.Hit1, v26, game.SoundService.Effect)
				local v27 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v27.Parent = v26.RootAttachment
				v27:Emit(20)
				v_u_2:AddItem(v27, 0.4)
			end
		end,
		["FinalHit"] = function(p28, p29)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_11:Flash(p29, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v30, game.SoundService.Effect)
				local v31 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v31.Parent = v30.RootAttachment
				v31:Emit(20)
				v31.TimeScale = 0.4
				v_u_2:AddItem(v31, 1)
				if v_u_4 == p28 or v_u_4.Character == p29 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Crush"] = function(p32, p33)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v34 = v_u_6.Itadori.CrushingBlow:Clone()
			v34.Position = p33
			v34.Parent = workspace.Effects
			v_u_3:Create(v34.Air, TweenInfo.new(0.2), {
				["Position"] = Vector3.new(0, 0, 0)
			}):Play()
			v_u_3:Create(v34.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v34.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 0, 1))
			v34.Floor.Sparks.Color = ColorSequence.new(Color3.new(1, 0, 1))
			v34.PointLight.Color = Color3.new(1, 0, 1)
			v34.Floor.Ring:Emit(10)
			v34.Floor.Sparks:Emit(10)
			v34.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v34, 1.5)
			v_u_11:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v34, game.SoundService.Effect)
			if v_u_4 == p32 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Finisher"] = function(_, p35)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v36 = p35:FindFirstChild("HumanoidRootPart")
			if v36 then
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, p35, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Megumi.Elephant.Explode, v36, game.SoundService.Effect)
				p35.Head.Transparency = 1
				local v37 = p35.Head:FindFirstChildWhichIsA("Decal")
				if v37 then
					v37.Transparency = 1
				end
				for _, v38 in p35:GetChildren() do
					if v38:IsA("Accessory") then
						local v39 = v38:FindFirstChild("Handle", true)
						if v39:FindFirstChild("HairAttachment") or (v39:FindFirstChild("HatAttachment") or (v39:FindFirstChild("FaceCenterAttachment") or (v39:FindFirstChild("FaceFrontAttachment") or v39:FindFirstChild("NeckAttachment")))) then
							v38:Destroy()
						end
					end
				end
				v_u_11:Bleed(p35)
				for _ = 1, 40 do
					v_u_9:Blood(p35.Head.CFrame, 50, 360, 360)
				end
				if _G.Settings.Gore then
					local v40 = v_u_6.Heian.BloodSpread:Clone()
					v40.Parent = p35.Head
					v40:Emit(20)
					v_u_2:AddItem(v40, 2)
				end
				local v41 = {
					"Torso",
					"Left Arm",
					"Right Arm",
					"Left Leg",
					"Right Leg",
					"Head"
				}
				for _, v42 in pairs(p35:GetChildren()) do
					if table.find(v41, v42.Name) then
						if v42.Name == "Head" then
							local v43 = v42.Mesh
							v43.Scale = v43.Scale * Vector3.new(1, 1, 0.05)
						else
							v42.Size = v42.Size * Vector3.new(1, 1, 0.05)
						end
					end
				end
				if v_u_4:DistanceFromCharacter(v36.Position) < 40 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p45, ...)
		-- upvalues: (copy) v_u_44
		local v46 = v_u_44[p45]
		if v46 then
			v46(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("StockpileService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12