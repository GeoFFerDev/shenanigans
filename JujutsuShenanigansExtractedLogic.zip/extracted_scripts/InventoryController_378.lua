-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_2 = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local _ = v3.Utils
local v_u_4 = v3.Sounds
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v8 = v_u_1.CreateController({
	["Name"] = "InventoryController"
})
function v8.KnitStart(_)
	-- upvalues: (copy) v_u_2, (ref) v_u_6, (copy) v_u_4, (ref) v_u_7, (ref) v_u_5
	local v_u_9 = v_u_2.PlayerGui:WaitForChild("Menus")
	local v_u_10 = v_u_9.Group.Inventory
	v_u_10:SetAttribute("Loaded", true)
	v_u_2:WaitForChild("leaderstats")
	local v_u_11 = nil
	for _, v_u_12 in v_u_10.Categories:GetChildren() do
		if v_u_12:IsA("TextButton") then
			v_u_12.MouseButton1Down:Connect(function()
				-- upvalues: (copy) v_u_10, (copy) v_u_12, (ref) v_u_6, (ref) v_u_4
				for _, v13 in v_u_10.Categories:GetChildren() do
					if v13:IsA("TextButton") then
						v13.Select.Visible = v13 == v_u_12
					end
				end
				v_u_6:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
				for _, v14 in v_u_10.Items:GetChildren() do
					v14.Visible = v14.Name == v_u_12.Name
				end
			end)
		end
	end
	local function v_u_19()
		-- upvalues: (copy) v_u_10
		local v15 = v_u_10.Items.Emotes.List
		local v16 = v15.UIListLayout.Padding.Offset
		local v17 = -v16
		for _, v18 in v_u_10.Items.Emotes.List:GetChildren() do
			if v18:IsA("Frame") and v18.Visible then
				v17 = v17 + (v18.AbsoluteSize.Y + v16)
			end
		end
		v15.CanvasSize = UDim2.fromOffset(0, v17)
	end
	local v_u_20 = v_u_10.Items.Emotes.TextBox
	v_u_20:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_10, (copy) v_u_20, (copy) v_u_19
		v_u_10.Items.Emotes.List.CanvasPosition = Vector2.zero
		for _, v21 in v_u_10.Items.Emotes.List:GetChildren() do
			if v21:IsA("Frame") then
				v21.Visible = v21.Name:lower():find(v_u_20.Text:lower())
			end
		end
		v_u_19()
	end)
	local v_u_22 = {
		[Enum.SortOrder.LayoutOrder] = Enum.SortOrder.Name,
		[Enum.SortOrder.Name] = Enum.SortOrder.LayoutOrder
	}
	local v_u_23 = {
		[Enum.SortOrder.Name] = "NEW",
		[Enum.SortOrder.LayoutOrder] = "A-Z"
	}
	local v_u_24 = v_u_10.Items.Emotes.List.UIListLayout
	v_u_20.SortAZ.MouseButton1Click:Connect(function()
		-- upvalues: (copy) v_u_24, (copy) v_u_22, (copy) v_u_20, (copy) v_u_23
		v_u_24.SortOrder = v_u_22[v_u_24.SortOrder]
		v_u_20.SortAZ.Text = v_u_23[v_u_24.SortOrder]
	end)
	local function v_u_38(p25)
		-- upvalues: (copy) v_u_10, (copy) v_u_9, (copy) v_u_20, (ref) v_u_6, (ref) v_u_4, (ref) v_u_11, (ref) v_u_7, (ref) v_u_5, (copy) v_u_19
		local v26 = v_u_10.Items.Emotes.List
		for _, v27 in v26:GetChildren() do
			if v27:IsA("Frame") and not table.find(p25, v27.Name) then
				v27:Destroy()
			end
		end
		for v28, v_u_29 in p25 do
			if not v26:FindFirstChild(v_u_29) then
				local v30 = v_u_9.Preset.Emote:Clone()
				v30.EmoteName.Text = v_u_29
				v30.Name = v_u_29
				v30.Visible = v_u_29:lower():find(v_u_20.Text:lower())
				v30.LayoutOrder = -v28
				v30.Parent = v26
				v30.EmoteName.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_11, (ref) v_u_7, (copy) v_u_29, (ref) v_u_5
					v_u_6:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
					if not v_u_11 then
						::l2::
						return
					end
					local v31 = v_u_7.EmoteCache
					local v32 = v_u_11.Name
					local v33 = v31[tonumber(v32)]
					if v33 == v_u_29 then
						v_u_11.Text = v33
						v_u_11 = nil
						return
					end
					local v34 = v_u_5.Equip
					if v_u_7.Page == 2 then
						local v35 = v_u_11.Name
						v37 = tonumber(v35) + 8
						if v37 then
							::l7::
							v34:Fire(v37, v_u_29)
							v_u_11 = nil
							goto l2
						end
					end
					local v36 = v_u_11.Name
					local v37 = tonumber(v36)
					goto l7
				end)
			end
		end
		v_u_19()
	end
	v_u_10.Items.Emotes.Equipped.Switch.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_11, (copy) v_u_10, (ref) v_u_6, (ref) v_u_4
		if v_u_7.Page == 1 then
			v_u_7.Page = 2
		else
			v_u_7.Page = 1
		end
		local v39 = 8 * (v_u_7.Page - 1)
		v_u_11 = nil
		for v40 = 1, 8 do
			v_u_10.Items.Emotes.Equipped:FindFirstChild(v40).Text = v_u_7.EmoteCache[v40 + v39]
		end
		v_u_6:PlaySound(v_u_4.Misc.UI.Switch, workspace, game.SoundService.Effect)
	end)
	local function v_u_46(p41)
		-- upvalues: (copy) v_u_10, (copy) v_u_9, (ref) v_u_2, (ref) v_u_6, (ref) v_u_4, (ref) v_u_5
		local v42 = v_u_10.Items.Titles.List
		for _, v43 in v42:GetChildren() do
			if v43:IsA("Frame") and not table.find(p41, v43.Name) then
				v43:Destroy()
			end
		end
		for _, v_u_44 in p41 do
			if v42:FindFirstChild(v_u_44) then
				v42:FindFirstChild(v_u_44).BackgroundColor3 = v_u_44 == v_u_2:GetAttribute("Title") and Color3.fromRGB(85, 170, 255) or Color3.new(1, 1, 1)
			else
				local v45 = v_u_9.Preset.Emote:Clone()
				v45.EmoteName.Text = v_u_44
				v45.Name = v_u_44
				v45.Size = UDim2.new(1, 0, 0.05, 15)
				v45.BackgroundColor3 = v_u_44 == v_u_2:GetAttribute("Title") and Color3.fromRGB(85, 170, 255) or Color3.new(1, 1, 1)
				v45.Parent = v42
				v45.EmoteName.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_5, (copy) v_u_44
					v_u_6:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_5.ChangeInv:Fire(v_u_44)
				end)
			end
		end
	end
	local function v_u_52(p47)
		-- upvalues: (copy) v_u_10, (copy) v_u_9, (ref) v_u_2, (ref) v_u_6, (ref) v_u_4, (ref) v_u_5
		local v48 = v_u_10.Items.MVP.List
		for _, v49 in v48:GetChildren() do
			if v49:IsA("Frame") and not table.find(p47, v49.Name) then
				v49:Destroy()
			end
		end
		for _, v_u_50 in p47 do
			if v48:FindFirstChild(v_u_50) then
				v48:FindFirstChild(v_u_50).BackgroundColor3 = v_u_50 == v_u_2:GetAttribute("MVP") and Color3.fromRGB(85, 170, 255) or Color3.new(1, 1, 1)
			else
				local v51 = v_u_9.Preset.Emote:Clone()
				v51.EmoteName.Text = v_u_50
				v51.Name = v_u_50
				v51.Size = UDim2.new(1, 0, 0.05, 15)
				v51.BackgroundColor3 = v_u_50 == v_u_2:GetAttribute("MVP") and Color3.fromRGB(85, 170, 255) or Color3.new(1, 1, 1)
				v51.Parent = v48
				v51.EmoteName.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_5, (copy) v_u_50
					v_u_6:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
					v_u_5.ChangeMVP:Fire(v_u_50)
				end)
			end
		end
	end
	v_u_5.ChangeInv:Connect(function(p53, p54)
		-- upvalues: (copy) v_u_38, (copy) v_u_52, (copy) v_u_46
		if p54 == 1 then
			v_u_38(p53)
			return
		elseif p54 == 2 then
			v_u_52(p53)
		else
			v_u_46(p53)
		end
	end)
	for _, v_u_55 in v_u_10.Items.Emotes.Equipped:GetChildren() do
		if v_u_55.Name ~= "Switch" then
			v_u_55.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_11, (copy) v_u_55, (ref) v_u_7
				v_u_6:PlaySound(v_u_4.Misc.UI.Click, workspace, game.SoundService.Effect)
				if v_u_11 == nil then
					v_u_11 = v_u_55
					v_u_55.Text = "..."
					return
				end
				if v_u_11 ~= v_u_55 then
					::l4::
					return
				end
				v_u_11 = nil
				local v56 = v_u_55
				local v57 = v_u_7.EmoteCache
				if v_u_7.Page == 2 then
					local v58 = v_u_55.Name
					v60 = tonumber(v58) + 8
					if v60 then
						::l7::
						v56.Text = v57[v60]
						goto l4
					end
				end
				local v59 = v_u_55.Name
				local v60 = tonumber(v59)
				goto l7
			end)
		end
	end
end
function v8.KnitInit(_)
	-- upvalues: (ref) v_u_5, (copy) v_u_1, (ref) v_u_6, (ref) v_u_7
	v_u_5 = v_u_1.GetService("EmoteService")
	v_u_6 = v_u_1.GetController("FXController")
	v_u_7 = v_u_1.GetController("EmoteController")
end
return v8