-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v2 = v_u_1.CreateController({
	["Name"] = "GokuController"
})
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = require(v6.Modules.BloodyZee)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = workspace.CurrentCamera
function v2.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_5, (copy) v_u_9, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_10, (copy) v_u_14, (ref) v_u_13, (ref) v_u_11
	local v_u_134 = {
		["Hit"] = function(p15, p16)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_12:Flash(p15, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Itadori.M1:FindFirstChild("Hit" .. p16), v17, game.SoundService.Effect)
			end
		end,
		["KickHit"] = function(p18, p19)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_12:Flash(p19, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Itadori.M1.Hit4, v20, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Hakari.EnergySurge.Hit1, v20, game.SoundService.Effect)
				if v_u_5.Character == p19 or v_u_5 == p18 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.SmallBump)
				end
			end
		end,
		["DownslamHit"] = function(p21, p22)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			if v23 then
				v_u_12:Flash(p22, Color3.new(1, 0, 0))
				v_u_12:PlaySound(v_u_8.Goku.M2DownslamHit, v23, game.SoundService.Effect)
				if v_u_5.Character == p22 or v_u_5 == p21 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["ChaseHit"] = function(p24, p25)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v26 = p24:FindFirstChild("HumanoidRootPart")
			if v26 then
				local v27 = p25:FindFirstChild("HumanoidRootPart")
				if v27 then
					v_u_12:Flash(p25, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit3"), v27, game.SoundService.Effect)
					local v28 = v_u_7.ChaseHit:Clone()
					local v29 = CFrame.new
					local v30 = v27.Position
					local v31 = v26.Position.X
					local v32 = v27.Position.Y
					local v33 = v26.Position.Z
					v28.CFrame = v29(v30, (Vector3.new(v31, v32, v33))) * CFrame.Angles(0, 3.141592653589793, 0)
					v28.Parent = workspace.Effects
					v28.Ring:Emit(7)
					v28.Sparks:Emit(12)
					v_u_3:AddItem(v28, 0.5)
				end
			else
				return
			end
		end,
		["DismantleHit"] = function(p34, p35, p36)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4
			local v37 = p34.Character:FindFirstChild("HumanoidRootPart")
			if v37 then
				v_u_12:PlaySound(v_u_8.Itadori.Dismantle.FinishSlash, v37, game.SoundService.Effect)
				local v38
				if typeof(p35) == "Vector3" then
					v38 = p35
				else
					v38 = p35.HumanoidRootPart.Position
					v_u_12:Flash(p35, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Itadori.Dismantle.Slash, p35.HumanoidRootPart, game.SoundService.Effect)
				end
				for _, v39 in ({
					{ CFrame.Angles(0, 0, -0.8726646259971648) },
					{ CFrame.Angles(0, 0, -0.7853981633974483) },
					{ CFrame.Angles(0, 0, 0) },
					{ CFrame.new(-3, 0, 0) * CFrame.Angles(0, 0, 1.0471975511965976), CFrame.new(3, 0, 0) * CFrame.Angles(0, 0, 0.8726646259971648), CFrame.Angles(0, 0, -0.5235987755982988) }
				})[p36] do
					local v_u_40 = CFrame.new(v37.Position, v38) * v39
					local v_u_41 = v_u_7.Itadori.Dismantle.DismantleFly:Clone()
					v_u_41.CFrame = v_u_40
					v_u_41.Parent = workspace.Effects
					local v_u_42 = Instance.new("Highlight", v_u_41)
					v_u_42.DepthMode = Enum.HighlightDepthMode.Occluded
					v_u_42.FillTransparency = 0
					v_u_42.FillColor = Color3.new(0, 0, 0)
					task.delay(0, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_41, (copy) v_u_40, (copy) v_u_42
						v_u_4:Create(v_u_41, TweenInfo.new(0.1), {
							["Size"] = Vector3.new(15, 0, 0),
							["CFrame"] = v_u_40 + v_u_40.LookVector * 30
						}):Play()
						task.wait(0.1)
						v_u_42:Destroy()
						v_u_41.Transparency = 1
						task.wait(0.05)
						v_u_41:Destroy()
					end)
				end
			end
		end,
		["CleaveGrab"] = function(p43)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v44 = p43:FindFirstChild("HumanoidRootPart")
			if v44 then
				v_u_12:Flash(p43, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Gojo.LapseBlue.Grab, v44, game.SoundService.Effect)
			end
		end,
		["CleaveHit"] = function(p45, p46)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7, (ref) v_u_9, (ref) v_u_3, (ref) v_u_10
			local v47 = p46:FindFirstChild("HumanoidRootPart")
			if v47 then
				v_u_12:Flash(p46, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Itadori.Dismantle.Explode, v47, game.SoundService.Effect)
				if v_u_5.Character == p45 or v_u_5.Character == p46 then
					task.delay(0.1, function()
						-- upvalues: (ref) v_u_7
						local v48 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v48.Parent = game.Lighting
						task.wait(0.05)
						v48.TintColor = Color3.new(1, 1, 1)
						v48.Brightness = 200
						v48.Contrast = -1000
						task.wait(0.05)
						v48:Destroy()
					end)
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				local v_u_49 = v_u_7.Itadori.Dismantle.Cleave:Clone()
				v_u_49.Weld.Part1 = v47
				v_u_49.Parent = workspace.Effects
				task.delay(0.1, function()
					-- upvalues: (copy) v_u_49, (ref) v_u_3
					v_u_49.Slashes.Enabled = false
					v_u_49.Slash2.Enabled = false
					v_u_49.PointLight:Destroy()
					v_u_3:AddItem(v_u_49, 0.08)
				end)
				v_u_12:PlaySound(v_u_8.Itadori.Dismantle.FinishSlash, v47, game.SoundService.Effect)
				for _ = 1, 10 do
					v_u_49.Slashes:Emit(1)
					v_u_12:PlaySound(v_u_8.Itadori.Dismantle.Slash, v47, game.SoundService.Effect)
					v_u_10:Blood(p45.Torso.CFrame, 50, 180, 180)
					task.wait()
				end
			end
		end,
		["StartScream"] = function(p50)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_4
			local v51 = p50:FindFirstChild("Head")
			if v51 then
				local v52 = v_u_12:PlaySound(v_u_8.Goku.MonkeyScream, v51, game.SoundService.Effect)
				task.wait(0.8)
				v_u_4:Create(v52, TweenInfo.new(1), {
					["Volume"] = 0
				}):Play()
				task.wait(1)
				v52:Destroy()
			end
		end,
		["ChestBeat"] = function(p53)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v54 = p53:FindFirstChild("HumanoidRootPart")
			if v54 then
				v_u_12:PlaySound(v_u_8.Goku.ChestBeat, v54, game.SoundService.Effect)
				local v55 = v_u_5.Character:FindFirstChild("HumanoidRootPart")
				if v55 then
					if v54 == v55 or (v54.Position - v55.Position).Magnitude < 300 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Finisher"] = function(p56)
			-- upvalues: (ref) v_u_12
			if p56.HumanoidRootPart then
				v_u_12:Bleed(p56)
			end
		end,
		["Feint"] = function(p57)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v58 = p57.HumanoidRootPart
			if v58 then
				local v59 = v_u_7.Itadori.CounterHit.Feint:Clone()
				v59.Parent = v58
				v59.Sparks:Emit(10)
				v59.Star:Emit(1)
				v59.Ring:Emit(1)
				v_u_3:AddItem(v59, 0.5)
			end
		end,
		["Chase"] = function(p60)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_14, (ref) v_u_5
			local v61 = p60.HumanoidRootPart
			if not v61 then
				return
			end
			local v62 = v_u_7.Gojo.LapseBlue.Throw:Clone()
			v62.CFrame = v61.CFrame * CFrame.new(0, 1, -4)
			v62.Size = Vector3.new(0, 0, 2)
			v62.Parent = workspace.Effects
			v_u_4:Create(v62, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(9, 9, 0),
				["Transparency"] = 1
			}):Play()
			v_u_3:AddItem(v62, 0.3)
			v_u_12:PlaySound(v_u_8.Misc.Chase, v61, game.SoundService.Effect)
			v_u_12:DustTrail(p60, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			local v63 = v_u_7.Goku.NimbusCloud:Clone()
			v63.Parent = p60
			p60:SetAttribute("CloudEnabled", true)
			local v64 = v61.CFrame * CFrame.new(0, 0, 20) * CFrame.Angles(0, 1.5707963267948966, 0)
			v63.CFrame = v64
			local v65 = tick()
			repeat
				task.wait()
				local v66 = v61.CFrame * CFrame.new(0, -2, 0) * CFrame.Angles(0, 1.5707963267948966, 0)
				local v67 = (tick() - v65) / 0.1
				v63.CFrame = v64:Lerp(v66, (math.clamp(v67, 0, 1)))
			until tick() - v65 > 0.1
			local v68 = RaycastParams.new()
			v68.FilterType = Enum.RaycastFilterType.Exclude
			v68.FilterDescendantsInstances = { p60 }
			while true do
				task.wait()
				local v69 = v_u_14.CFrame
				if p60 == v_u_5.Character and not workspace:Raycast(v61.Position, Vector3.new(0, -4, 0), v68) then
					v61.CFrame = CFrame.lookAlong(v61.Position, v69.LookVector, v69.UpVector)
				end
				v63.CFrame = v61.CFrame * CFrame.new(0, -2, 0) * CFrame.Angles(0, 1.5707963267948966, 0)
				if not p60:GetAttribute("CloudEnabled") then
					return
				end
			end
		end,
		["StopCloud"] = function(p70)
			-- upvalues: (ref) v_u_4
			if p70:GetAttribute("CloudEnabled") then
				p70:SetAttribute("CloudEnabled", nil)
				local v71 = p70:FindFirstChild("NimbusCloud")
				if v71 then
					v71.Trail.Enabled = false
					for _, v72 in v71:GetChildren() do
						if v72:IsA("BasePart") then
							v_u_4:Create(v72, TweenInfo.new(0.2), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
						end
					end
					task.wait(0.2)
					v71:Destroy()
				end
			else
				return
			end
		end,
		["Swing"] = function(p73)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v74 = p73:FindFirstChild("HumanoidRootPart")
			if v74 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v74, game.SoundService.Effect)
			end
		end,
		["Launch"] = function(p75, p76)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v77 = p75:FindFirstChild("HumanoidRootPart")
			if v77 then
				local v78 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v78.CFrame = CFrame.new(v77.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v78.Size = Vector3.new(0, 0, 5)
				v78.Parent = workspace.Effects
				v_u_4:Create(v78, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v78.Position + Vector3.new(0, p76, 0)
				}):Play()
				v_u_3:AddItem(v78, 0.3)
				if p76 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v77, game.SoundService.Effect)
					v_u_12:DustBreak(v77.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v77.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Switch"] = function(p79)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v80 = p79:FindFirstChild("HumanoidRootPart")
			if v80 then
				local v81 = v_u_7.Itadori.Switch.Fade:Clone()
				v81.Parent = v80.RootAttachment
				v81:Emit(1)
				v_u_3:AddItem(v81, 1)
				local v82 = v_u_7.Itadori.Switch.Switch:Clone()
				v82.Parent = v80
				v_u_3:AddItem(v82, 0.8)
				for _, v_u_83 in v82:GetChildren() do
					v_u_4:Create(v_u_83, TweenInfo.new(0.3, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
						["Size"] = v_u_83.Size + UDim2.new(0, 0, 0.1, 0)
					}):Play()
					task.delay(0.3, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_83
						v_u_4:Create(v_u_83, TweenInfo.new(0.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
							["Size"] = v_u_83.Size - UDim2.new(0, 0, 0.1, 0)
						}):Play()
					end)
				end
				local v84 = v_u_12:PlaySound(v_u_8.Itadori.FireArrow.Arrow, v80, game.SoundService.Effect)
				v84.PlaybackSpeed = 1.2
				v84.TimePosition = 0.7
				if v_u_5.Character == p79 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end,
		["Chat"] = function(p85)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3
			local v86 = p85:FindFirstChild("Torso")
			if v86 then
				local v87 = v_u_7.Itadori.Dialogue:Clone()
				v87.Parent = v86
				local v88 = v87.Chat1.Position
				v87.Chat1.Position = v88 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v87.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v88
				}):Play()
				v_u_4:Create(v87.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v87.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.4)
				v_u_12:PlaySound(v_u_8.Gojo.BlindsOff, v86, game.SoundService.Effect)
				task.wait(1.25)
				v_u_3:AddItem(v87, 0.6)
				for _, v89 in v87:GetDescendants() do
					if v89:IsA("Frame") then
						v_u_4:Create(v89, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = v89.Position - UDim2.new(0, 0, 0.2, 0),
							["BackgroundTransparency"] = 1
						}):Play()
					elseif v89:IsA("TextLabel") then
						v_u_4:Create(v89, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["Chat2"] = function(p90)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3
			local v91 = p90:FindFirstChild("Torso")
			if v91 then
				local v92 = v_u_7.Itadori.Dialogue:Clone()
				v92.Chat1.Sub.Text = "IT\'S A BINDING VOW I MADE WITH THAT BRAT."
				v92.Parent = v91
				local v93 = v92.Chat1.Position
				v92.Chat1.Position = v93 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v92.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v93
				}):Play()
				v_u_4:Create(v92.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v92.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.4)
				v_u_12:PlaySound(v_u_8.Gojo.BlindsOff, v91, game.SoundService.Effect)
				task.wait(1.25)
				v_u_3:AddItem(v92, 0.6)
				for _, v94 in v92:GetDescendants() do
					if v94:IsA("Frame") then
						v_u_4:Create(v94, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = v94.Position - UDim2.new(0, 0, 0.2, 0),
							["BackgroundTransparency"] = 1
						}):Play()
					elseif v94:IsA("TextLabel") then
						v_u_4:Create(v94, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["GokuVanish"] = function(p95, p96)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v97 = p95:FindFirstChild("HumanoidRootPart")
			if v97 then
				if p96.Parent then
					local v98 = v_u_7.Goku.Vanish
					local v99 = v98.Limb.Attachment
					local v100 = v98.Head.Attachment
					local v101 = v98.Torso.Attachment
					local v102 = v98.Limb2.Attachment
					local v103 = v98.Head2.Attachment
					local v104 = v98.Torso2.Attachment
					local v105 = p95.Torso
					local v106 = v101:Clone()
					v106.Parent = v105
					v106.Vanish:Emit(1)
					v_u_3:AddItem(v106, 1)
					local v107 = p95.Head
					local v108 = v100:Clone()
					v108.Parent = v107
					v108.Vanish:Emit(1)
					v_u_3:AddItem(v108, 1)
					local v109 = p95["Right Arm"]
					local v110 = v99:Clone()
					v110.Parent = v109
					v110.Vanish:Emit(1)
					v_u_3:AddItem(v110, 1)
					local v111 = p95["Left Arm"]
					local v112 = v99:Clone()
					v112.Parent = v111
					v112.Vanish:Emit(1)
					v_u_3:AddItem(v112, 1)
					local v113 = p95["Right Leg"]
					local v114 = v99:Clone()
					v114.Parent = v113
					v114.Vanish:Emit(1)
					v_u_3:AddItem(v114, 1)
					local v115 = p95["Left Leg"]
					local v116 = v99:Clone()
					v116.Parent = v115
					v116.Vanish:Emit(1)
					v_u_3:AddItem(v116, 1)
					v_u_12:PlaySound(v_u_8.Goku.Vanish, v97, game.SoundService.Effect)
					p96.AncestryChanged:Wait()
					v_u_12:PlaySound(v_u_8.Goku.Appear, v97, game.SoundService.Effect)
					local v117 = p95.Torso
					local v118 = v104:Clone()
					v118.Parent = v117
					v118.Vanish:Emit(1)
					v_u_3:AddItem(v118, 1)
					local v119 = p95.Head
					local v120 = v103:Clone()
					v120.Parent = v119
					v120.Vanish:Emit(1)
					v_u_3:AddItem(v120, 1)
					local v121 = p95["Right Arm"]
					local v122 = v102:Clone()
					v122.Parent = v121
					v122.Vanish:Emit(1)
					v_u_3:AddItem(v122, 1)
					local v123 = p95["Left Arm"]
					local v124 = v102:Clone()
					v124.Parent = v123
					v124.Vanish:Emit(1)
					v_u_3:AddItem(v124, 1)
					local v125 = p95["Right Leg"]
					local v126 = v102:Clone()
					v126.Parent = v125
					v126.Vanish:Emit(1)
					v_u_3:AddItem(v126, 1)
					local v127 = p95["Left Leg"]
					local v128 = v102:Clone()
					v128.Parent = v127
					v128.Vanish:Emit(1)
					v_u_3:AddItem(v128, 1)
				end
			else
				return
			end
		end,
		["Follow"] = function(p129, p130, p131, p132)
			local v133 = CFrame.lookAlong(Vector3.new(0, 0, 0), -p132)
			repeat
				task.wait()
				p129.Position = p131.Position + p132 * 3
				p130.CFrame = v133
			until not p129:GetAttribute("Track")
		end
	}
	v_u_13.Effects:Connect(function(p135, ...)
		-- upvalues: (copy) v_u_134
		local v136 = v_u_134[p135]
		if v136 then
			v136(...)
		end
	end)
	v_u_13.Hitbox:Connect(function(p137, p138, p139)
		-- upvalues: (ref) v_u_11, (ref) v_u_4
		local v140 = p138.HumanoidRootPart
		if not v140 then
			return
		end
		local v141 = nil
		while true do
			local v142 = v_u_11:SphereHitbox(p138, CFrame.new(0, 0, -4), 8)
			for _, v143 in v142 do
				local v144 = v143:FindFirstChild("Info")
				if v144 then
					local v145 = v144:FindFirstChild("Knockback")
					if not v145 or v145.Value ~= false then
						v141 = v142
						break
					end
				end
			end
			if v141 then
				local v146 = p137:FindFirstChildWhichIsA("NumberValue")
				if v146 then
					v_u_4:Create(v146, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p137.Parent then
				break
			end
		end
		p139:FireServer(v141, v140.CFrame)
	end)
end
function v2.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetService("GokuService")
end
return v2