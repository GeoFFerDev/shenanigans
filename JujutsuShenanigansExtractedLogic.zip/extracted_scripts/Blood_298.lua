-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 1,
	["SortOrder"] = 1,
	["Val"] = "Gore",
	["Desc"] = "Makes blood visible or recolored"
}