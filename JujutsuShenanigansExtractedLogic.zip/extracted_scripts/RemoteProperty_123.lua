-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("Players")
local v_u_2 = require(script.Parent.RemoteSignal)
require(script.Parent.Parent.Types)
local v_u_3 = require(script.Parent.Parent.Util).None
local v_u_4 = {}
v_u_4.__index = v_u_4
function v_u_4.new(p5, p6, p7, p8, p9)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_1, (copy) v_u_3
	local v10 = v_u_4
	local v_u_11 = setmetatable({}, v10)
	v_u_11._rs = v_u_2.new(p5, p6, false, p8, p9)
	v_u_11._value = p7
	v_u_11._perPlayer = {}
	v_u_11._playerRemoving = v_u_1.PlayerRemoving:Connect(function(p12)
		-- upvalues: (copy) v_u_11
		v_u_11._perPlayer[p12] = nil
	end)
	v_u_11._rs:Connect(function(p13)
		-- upvalues: (copy) v_u_11, (ref) v_u_3
		local v14 = v_u_11._perPlayer[p13]
		if v14 == nil then
			v14 = v_u_11._value
		elseif v14 == v_u_3 then
			v14 = nil
		end
		v_u_11._rs:Fire(p13, v14)
	end)
	return v_u_11
end
function v_u_4.Set(p15, p16)
	p15._value = p16
	table.clear(p15._perPlayer)
	p15._rs:FireAll(p16)
end
function v_u_4.SetTop(p17, p18)
	-- upvalues: (copy) v_u_1
	p17._value = p18
	for _, v19 in ipairs(v_u_1:GetPlayers()) do
		if p17._perPlayer[v19] == nil then
			p17._rs:Fire(v19, p18)
		end
	end
end
function v_u_4.SetFilter(p20, p21, p22)
	-- upvalues: (copy) v_u_1
	for _, v23 in ipairs(v_u_1:GetPlayers()) do
		if p21(v23, p22) then
			p20:SetFor(v23, p22)
		end
	end
end
function v_u_4.SetFor(p24, p25, p26)
	-- upvalues: (copy) v_u_3
	if p25.Parent then
		local v27 = p24._perPlayer
		local v28
		if p26 == nil then
			v28 = v_u_3
		else
			v28 = p26
		end
		v27[p25] = v28
	end
	p24._rs:Fire(p25, p26)
end
function v_u_4.SetForList(p29, p30, p31)
	for _, v32 in ipairs(p30) do
		p29:SetFor(v32, p31)
	end
end
function v_u_4.ClearFor(p33, p34)
	if p33._perPlayer[p34] ~= nil then
		p33._perPlayer[p34] = nil
		p33._rs:Fire(p34, p33._value)
	end
end
function v_u_4.ClearForList(p35, p36)
	for _, v37 in ipairs(p36) do
		p35:ClearFor(v37)
	end
end
function v_u_4.ClearFilter(p38, p39)
	-- upvalues: (copy) v_u_1
	for _, v40 in ipairs(v_u_1:GetPlayers()) do
		if p39(v40) then
			p38:ClearFor(v40)
		end
	end
end
function v_u_4.Get(p41)
	return p41._value
end
function v_u_4.GetFor(p42, p43)
	-- upvalues: (copy) v_u_3
	local v44 = p42._perPlayer[p43]
	if v44 == nil then
		return p42._value
	elseif v44 == v_u_3 then
		return nil
	else
		return v44
	end
end
function v_u_4.Destroy(p45)
	p45._rs:Destroy()
	p45._playerRemoving:Disconnect()
end
return v_u_4