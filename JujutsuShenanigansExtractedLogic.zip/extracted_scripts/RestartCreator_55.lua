-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Name"] = "restartcreator",
	["Description"] = "Restarts all custom / private servers",
	["Group"] = { "Owner" },
	["Args"] = {}
}