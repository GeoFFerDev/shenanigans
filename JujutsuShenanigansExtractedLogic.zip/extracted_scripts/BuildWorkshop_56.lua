-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "buildworkshop",
	["Description"] = "Loads a player\'s workshop upload into the game",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"Mod"
	},
	["Args"] = {
		{
			["Type"] = "string",
			["Name"] = "Entry ID"
		}
	}
}
return v1