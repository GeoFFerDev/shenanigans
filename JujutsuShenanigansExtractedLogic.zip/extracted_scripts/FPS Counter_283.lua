-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 1,
	["Val"] = "FPS",
	["Desc"] = "See your current framerate"
}
local v_u_2 = nil
local v_u_3 = game.Players.LocalPlayer
local v_u_4 = game:GetService("RunService")
function v1.Callback(p5)
	-- upvalues: (copy) v_u_3, (ref) v_u_2, (copy) v_u_4
	local v_u_6 = v_u_3.PlayerGui:WaitForChild("Main"):WaitForChild("FPS")
	v_u_6.Visible = p5
	if p5 == true and not v_u_2 then
		v_u_2 = v_u_4.RenderStepped:Connect(function(p7)
			-- upvalues: (copy) v_u_6
			local v8 = v_u_6
			local v9 = 1 / p7
			local v10 = math.ceil(v9)
			v8.Text = tostring(v10) .. " FPS"
		end)
	elseif v_u_2 then
		v_u_2:Disconnect()
		v_u_2 = nil
	end
end
return v1