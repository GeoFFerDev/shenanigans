-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("RunService")
if v1:IsServer() then
	return require(script.KnitServer)
end
local v2 = script:FindFirstChild("KnitServer")
if v2 and v1:IsRunning() then
	v2:Destroy()
end
return require(script.KnitClient)