-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "ChaosController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (copy) v_u_2, (ref) v_u_9
	local v_u_59 = {
		["Form"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_4, (ref) v_u_8
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				local v15 = TweenInfo.new(1.2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				local v_u_16 = TweenInfo.new(0.8, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				v_u_11:PlaySound(v_u_7.Misc.S.Form, v14, game.SoundService.Effect)
				local v17 = v_u_6.Misc.S.C:Clone()
				for v18, v_u_19 in v17:GetChildren() do
					v_u_19.Weld.Part0 = v14
					local v20 = v_u_19.Weld
					local v21 = v20.C0
					local v22 = CFrame.Angles
					local v23 = 51.42857142857143 * v18
					v20.C0 = v21 * v22(0, math.rad(v23), 0)
					v_u_4:Create(v_u_19.Weld, v15, {
						["C1"] = CFrame.new(0, 0, -8)
					}):Play()
					task.delay(1.2, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_19, (copy) v_u_16
						v_u_4:Create(v_u_19.Weld, v_u_16, {
							["C1"] = CFrame.new(0, 0, 0)
						}):Play()
					end)
				end
				v17.Parent = workspace.Effects
				local v24 = tick() + 2
				while true do
					task.wait()
					for _, v25 in v17:GetChildren() do
						local v26 = v25.Weld
						v26.C0 = v26.C0 * CFrame.Angles(0, 0.08726646259971647, 0)
					end
					if v24 < tick() then
						v17:Destroy()
						if (workspace.CurrentCamera.CFrame.Position - v14.Position).Magnitude < 100 then
							v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						end
						return
					end
				end
			else
				return
			end
		end,
		["Boost"] = function(p27)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_11, (ref) v_u_7, (ref) v_u_8
			local v_u_28 = p27:FindFirstChild("HumanoidRootPart")
			if v_u_28 then
				task.spawn(function()
					-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (copy) v_u_28
					local v_u_29 = v_u_6.Misc.S.Boost:Clone()
					v_u_29.Parent = workspace.Effects
					v_u_3:AddItem(v_u_29, 1.1)
					task.delay(0.7, function()
						-- upvalues: (copy) v_u_29, (ref) v_u_4
						for _, v30 in v_u_29:GetDescendants() do
							if v30:IsA("Beam") then
								v_u_4:Create(v30, TweenInfo.new(0.4), {
									["Width0"] = 0,
									["Width1"] = 0
								}):Play()
							elseif v30:IsA("ParticleEmitter") then
								v30.Enabled = false
							end
						end
					end)
					repeat
						v_u_29.CFrame = CFrame.lookAlong(v_u_28.Position, -v_u_28.Velocity) * CFrame.Angles(0, 0, math.random(0, 3.141592653589793))
						task.wait()
					until not v_u_29.Parent
				end)
				v_u_11:PlaySound(v_u_7.Misc.S.Dash, v_u_28, game.SoundService.Effect)
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				for _ = 1, 30 do
					local v_u_31 = v_u_6.Mahito.BodyRepel["Wind" .. math.random(1, 5)]:Clone()
					local v32 = CFrame.lookAlong(v_u_28.Position, v_u_28.Velocity)
					local v33 = CFrame.Angles
					local v34 = math.random(0, 360)
					v_u_31.CFrame = v32 * v33(1.5707963267948966, math.rad(v34), 0)
					v_u_31.Transparency = 0.5
					v_u_31.Size = Vector3.new(6, 6, 20)
					v_u_4:Create(v_u_31, TweenInfo.new(0.3, Enum.EasingStyle.Quad), {
						["CFrame"] = v_u_31.CFrame + v_u_28.CFrame.LookVector * 3,
						["Size"] = Vector3.new(40, 0, 40)
					}):Play()
					v_u_3:AddItem(v_u_31, 0.15)
					v_u_31.Parent = workspace.Effects
					v_u_4:Create(v_u_31, TweenInfo.new(0.15), {
						["Transparency"] = 0.5
					}):Play()
					task.delay(0.15, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_31
						v_u_4:Create(v_u_31, TweenInfo.new(0.15), {
							["Transparency"] = 1
						}):Play()
					end)
					task.wait(0.03)
				end
			end
		end,
		["Melee"] = function(p35, p36)
			-- upvalues: (ref) v_u_7, (ref) v_u_11
			local v37 = p35:FindFirstChild("HumanoidRootPart")
			if v37 then
				if p36 then
					v_u_7.Misc.S.Dash2.PlaybackSpeed = math.random(100, 200) / 100
					v_u_11:PlaySound(v_u_7.Misc.S.Dash2, v37, game.SoundService.Effect)
					local v38 = math.random(1, 4)
					local v39
					if v38 == 1 then
						v39 = p35["Left Arm"]
					elseif v38 == 2 then
						v39 = p35["Right Arm"]
					elseif v38 == 3 then
						v39 = p35["Left Leg"]
					else
						v39 = p35["Right Leg"]
					end
					v_u_11:ArmFlash(v39, Color3.fromRGB(255, 255, 127), 0.5)
					local v40 = tick() + 0.3
					repeat
						local v41 = task.wait()
						local v42 = p36.HumanoidRootPart.Position - v37.CFrame.LookVector * 3
						local v43 = v37.CFrame - v37.Position + v37.Position:Lerp(v42, 20 * v41)
						local v44 = math.random(-20, 20) / 10
						local v45 = math.random(-20, 20) / 10
						local v46 = math.random(-20, 20) / 10
						v37.CFrame = v43 + Vector3.new(v44, v45, v46)
					until v40 < tick()
				end
			else
				return
			end
		end,
		["MeleeHit"] = function(p47)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v48 = p47:FindFirstChild("HumanoidRootPart")
			if v48 then
				v_u_11:Flash(p47, Color3.new(1, 1, 1))
				local v49 = v_u_7.Misc.S.Hit["Hit" .. math.random(1, 2)]
				v49.PlaybackSpeed = math.random(100, 150) / 100
				v_u_11:PlaySound(v49, v48, game.SoundService.Effect)
				local v50 = v_u_6.Misc.S.HeavyHit:Clone()
				v50.Position = v48.Position
				v50.Parent = workspace.Effects
				v_u_3:AddItem(v50, 1)
				v_u_4:Create(v50.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v50.Glow:Emit(1)
				v50.Sparks:Emit(50)
				v50.Wind:Emit(7)
				v50.Wind2:Emit(7)
				if (workspace.CurrentCamera.CFrame.Position - v48.Position).Magnitude > 300 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				else
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			else
				return
			end
		end,
		["Interp"] = function(p_u_51)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_2
			local v_u_52 = p_u_51.CFrame
			local v_u_53 = tick()
			local v_u_54 = p_u_51:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_52, (copy) p_u_51, (ref) v_u_53
				v_u_52 = p_u_51.CFrame
				v_u_53 = tick()
			end)
			v_u_11:PlaySound(v_u_7.Choso.PiercingBlood.Fire, p_u_51, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_7.Choso.PiercingBlood.Pressure2, p_u_51, game.SoundService.Effect)
			local v_u_55 = nil
			v_u_55 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_51, (ref) v_u_55, (copy) v_u_54, (ref) v_u_52, (ref) v_u_53
				if p_u_51.Parent then
					workspace:BulkMoveTo({ p_u_51 }, { v_u_52 + v_u_52.LookVector * (p_u_51:GetAttribute("Speed") * (tick() - v_u_53)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_55:Disconnect()
					v_u_54:Disconnect()
				end
			end)
		end,
		["HomingHit"] = function(p56)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v57 = p56:FindFirstChild("HumanoidRootPart")
			if v57 then
				v_u_11:Flash(p56, Color3.new(1, 1, 1))
				v_u_7.Misc.S.OrbHit.PlaybackSpeed = math.random(100, 150) / 100
				v_u_11:PlaySound(v_u_7.Misc.S.OrbHit, v57, game.SoundService.Effect)
				local v58 = v_u_6.Misc.S.HeavyHit:Clone()
				v58.Position = v57.Position
				v58.Parent = workspace.Effects
				v_u_3:AddItem(v58, 0.4)
				v_u_4:Create(v58.PointLight, TweenInfo.new(0.4), {
					["Brightness"] = 0
				}):Play()
				v58.Sparks:Emit(50)
				v58.Wind2:Emit(7)
				if (workspace.CurrentCamera.CFrame.Position - v57.Position).Magnitude > 300 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				else
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			else
				return
			end
		end,
		["On"] = function()
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			v_u_11:PlaySound(v_u_7.Misc.S.On, workspace, game.SoundService.Effect)
		end
	}
	v_u_9.Effects:Connect(function(p60, ...)
		-- upvalues: (copy) v_u_59
		local v61 = v_u_59[p60]
		if v61 then
			v61(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("ChaosService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12