-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "chara",
	["Description"] = "Sets the player to chara",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"Mod",
		"Tester"
	},
	["Args"] = {
		{
			["Type"] = "player",
			["Name"] = "Player"
		}
	}
}
return v1