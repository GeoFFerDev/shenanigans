-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = require(v5.Modules.SraikoVFX)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "ProjectionBreakerController"
})
local function v_u_23(p13, p14, p15, p16)
	-- upvalues: (copy) v_u_2
	local v17 = p13:Clone()
	if p15 and p14 then
		local v18 = Instance.new("Weld")
		v18.Part0 = v17
		v18.Part1 = p14
		v18.Parent = v17
	else
		v17.CFrame = p14
	end
	v17.Parent = workspace.Effects
	local v19 = next
	local v20, v21 = v17:GetDescendants()
	for _, v22 in v19, v20, v21 do
		if v22:IsA("ParticleEmitter") then
			v22:Emit(v22:GetAttribute("EmitCount"))
		end
	end
	v_u_2:AddItem(v17, p16 or 5)
end
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_9, (copy) v_u_23, (copy) v_u_4, (copy) v_u_8, (ref) v_u_10
	local v_u_39 = {
		["Weave"] = function(p24)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				v_u_11:PlaySound(v_u_7.Itadori.ManjiKick.Dodge, v25, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Misc.M.Swing["1"], v25, game.SoundService.Effect)
				local v26 = TweenInfo.new(0.2)
				for _ = 1, 10 do
					local v27 = v_u_6.Damage.HitGlow:Clone()
					v_u_2:AddItem(v27, 0.2)
					v27.Parent = workspace.Effects
					for _, v28 in v27:GetChildren() do
						v28.Color = Color3.fromRGB(128, 126, 255)
						v28.Anchored = true
						v28.CFrame = p24[v28.Name].CFrame
						v_u_3:Create(v28, v26, {
							["Transparency"] = 1
						}):Play()
					end
					task.wait(0.04)
				end
			end
		end,
		["Spin"] = function(p29)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_11:PlaySound(v_u_7.Naoya.ProjectionBreaker.Spin, v30, game.SoundService.Effect)
				v_u_11:DustTrail(p29, 0.5, CFrame.Angles(0, -1.5707963267948966, 0))
				v_u_11:ArmFlash(p29["Right Leg"], Color3.fromRGB(128, 126, 255), 0.6)
				local v31 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v31.Size = Vector3.new(6, 30, 6)
				v31.CFrame = v30.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v31.Parent = workspace.Effects
				v_u_2:AddItem(v31, 0.2)
				v_u_3:Create(v31, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = v31.Position + v30.CFrame.LookVector * 10
				}):Play()
			end
		end,
		["Kick"] = function(p32)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_9, (ref) v_u_2, (ref) v_u_23, (ref) v_u_4, (ref) v_u_8
			local v33 = p32:FindFirstChild("HumanoidRootPart")
			if v33 then
				v_u_11:PlaySound(v_u_7.Naoya.ProjectionBreaker.Kick, v33, game.SoundService.Effect)
				local v34 = v_u_6.Mechamaru.BoostOnVFX.BoostHit.Meshes.Mesh:Clone()
				local v35 = v_u_9.HandleMesh(v34, v33.CFrame * v34.Offset.Value)
				v34.Parent = workspace.Effects
				v_u_2:AddItem(v34, v35)
				v_u_23(v_u_6.Mechamaru.BoostOnVFX.BoostHit.Emit.Strike, v33, true, 3)
				if v_u_4.Character == p32 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["Hit"] = function(p36, p37)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v38 = p37:FindFirstChild("HumanoidRootPart")
			if v38 then
				v_u_11:Flash(p37, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Mechamaru.BoostOn.Hit, v38, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Itadori.CursedStrikes.Hit, v38, game.SoundService.Effect)
				if v_u_4.Character == p37 or v_u_4 == p36 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p40, ...)
		-- upvalues: (copy) v_u_39
		local v41 = v_u_39[p40]
		if v41 then
			v41(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("ProjectionBreakerService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12