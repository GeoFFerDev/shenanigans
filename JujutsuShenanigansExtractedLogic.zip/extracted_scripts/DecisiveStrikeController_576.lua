-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "DecisiveStrikeController"
})
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (ref) v_u_13, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10, (ref) v_u_11
	local v_u_136 = {
		["Weave"] = function(p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = TweenInfo.new(1.2)
				v_u_12:DustTrail(p15, 0.5, CFrame.Angles(0, -1.5707963267948966, 0))
				v_u_12:PlaySound(v_u_7.Naoya.Decisive.Startup, v16, game.SoundService.Effect)
				for v18 = 1, 3 do
					local v19 = v_u_6.Damage.HitGlow:Clone()
					v_u_2:AddItem(v19, 1.2)
					v19.Parent = workspace.Effects
					for _, v20 in v19:GetChildren() do
						v20.Color = Color3.fromRGB(128, 126, 255)
						v20.Anchored = true
						v20.CFrame = p15[v20.Name].CFrame
						v_u_3:Create(v20, v17, {
							["Transparency"] = 1,
							["Position"] = v20.Position + v16.CFrame.LookVector * 4
						}):Play()
					end
					local v21 = {}
					for _, v22 in p15:GetDescendants() do
						if (v22:IsA("BasePart") or v22:IsA("Decal")) and v22.Transparency ~= 1 then
							local v23 = v22.Transparency
							v22.Transparency = 1
							v21[v22] = v23
						end
					end
					task.wait(0.1)
					for v24, v25 in v21 do
						if v24.Parent then
							v24.Transparency = v25
						end
					end
					local v26 = v_u_6.Damage.HitGlow:Clone()
					v_u_2:AddItem(v26, 1.2)
					v26.Parent = workspace.Effects
					for _, v27 in v26:GetChildren() do
						v27.Color = Color3.fromRGB(128, 126, 255)
						v27.Anchored = true
						v27.CFrame = p15[v27.Name].CFrame
						v_u_3:Create(v27, v17, {
							["Transparency"] = 1,
							["Position"] = v27.Position + v16.CFrame.LookVector * 4
						}):Play()
					end
					if v18 == 2 then
						v_u_12:PlaySound(v_u_7.Naoya.Decisive.Flicker1, v16, game.SoundService.Effect)
					elseif v18 == 3 then
						v_u_12:PlaySound(v_u_7.Naoya.Decisive.Flicker2, v16, game.SoundService.Effect)
					end
					local v28 = v_u_6.Naoya.Teleport:Clone()
					v28.CFrame = v16.CFrame
					v28.Parent = workspace.Effects
					v28.Lines:Emit(8)
					v28.Floor.Dust:Emit(30)
					v_u_2:AddItem(v28, 1)
					task.wait(0.1)
				end
			end
		end,
		["Flick"] = function(p29, p30, p31)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			local v_u_32 = p29:FindFirstChild("HumanoidRootPart")
			if v_u_32 then
				local v_u_33 = v_u_32.CFrame
				if p31 > 1 and p30 then
					local v34 = v_u_12:PlaySound(v_u_7.Naoya.Decisive.Boost, v_u_32, game.SoundService.Effect)
					v34.Volume = v34.Volume * (p31 / 3)
					local v35 = Instance.new("Model")
					local v36 = v_u_5.Utils.Itadori.RushWind:Clone()
					v36.CFrame = v_u_33 * CFrame.new(0, -1, 0)
					v36.Parent = v35
					v35.Parent = workspace.Effects
					v35:ScaleTo(0.25 * p31)
					v36.Ring:Emit(7)
					v_u_2:AddItem(v35, 2)
					local v37 = v_u_6.Itadori.Shock:Clone()
					local v38 = Instance.new("Model")
					v37.Parent = v38
					v38:ScaleTo(0.4 * p31)
					v_u_2:AddItem(v38, 0.2)
					v37.CFrame = v_u_33 * CFrame.Angles(1.5707963267948966, 0, 0)
					v37.Parent = workspace.Effects
					v_u_3:Create(v37, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v37, 0.2)
					task.delay(0.05, function()
						-- upvalues: (ref) v_u_6, (copy) v_u_33, (copy) v_u_32, (ref) v_u_3, (ref) v_u_2
						local v39 = v_u_6.Itadori.Shock:Clone()
						v39.CFrame = (v_u_33 - v_u_33.Position + v_u_32.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
						v39.Parent = workspace.Effects
						v_u_3:Create(v39, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v39, 0.2)
					end)
				end
				local v40 = TweenInfo.new(1.2)
				v_u_12:DustTrail(p29, 0.5, CFrame.Angles(0, -1.5707963267948966, 0))
				local v41 = v_u_6.Damage.HitGlow:Clone()
				v_u_2:AddItem(v41, 1.2)
				v41.Parent = workspace.Effects
				for _, v42 in v41:GetChildren() do
					v42.Color = Color3.fromRGB(128, 126, 255)
					v42.Anchored = true
					v42.CFrame = p29[v42.Name].CFrame
					v_u_3:Create(v42, v40, {
						["Transparency"] = 1,
						["Position"] = v42.Position + v_u_32.CFrame.LookVector * 4
					}):Play()
				end
				local v43 = {}
				for _, v44 in p29:GetDescendants() do
					if (v44:IsA("BasePart") or v44:IsA("Decal")) and v44.Transparency ~= 1 then
						local v45 = v44.Transparency
						v44.Transparency = 1
						v43[v44] = v45
					end
				end
				task.wait(0.1)
				for v46, v47 in v43 do
					if v46.Parent then
						v46.Transparency = v47
					end
				end
				local v48 = v_u_6.Damage.HitGlow:Clone()
				v_u_2:AddItem(v48, 1.2)
				v48.Parent = workspace.Effects
				for _, v49 in v48:GetChildren() do
					v49.Color = Color3.fromRGB(128, 126, 255)
					v49.Anchored = true
					v49.CFrame = p29[v49.Name].CFrame
					v_u_3:Create(v49, v40, {
						["Transparency"] = 1,
						["Position"] = v49.Position + v_u_32.CFrame.LookVector * 4
					}):Play()
				end
				local v50 = math.random(1, 3)
				v_u_12:PlaySound(v_u_7.Naoya.Decisive["Flicker" .. v50], v_u_32, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
				local v51 = v_u_6.Naoya.Teleport:Clone()
				v51.CFrame = v_u_32.CFrame
				v51.Parent = workspace.Effects
				v51.Lines:Emit(8)
				v51.Floor.Dust:Emit(30)
				v_u_2:AddItem(v51, 1)
			end
		end,
		["ClearForce"] = function(p52)
			-- upvalues: (ref) v_u_13
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				v_u_13:ClearForce(v53)
				v_u_13:ClearForce(p52.Torso)
			end
		end,
		["Windup"] = function(p54)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v55 = p54:FindFirstChild("HumanoidRootPart")
			if v55 then
				v_u_12:ArmFlash(p54["Right Arm"], Color3.fromRGB(128, 126, 255), 0.65)
				task.wait(0.2)
				v_u_12:PlaySound(v_u_7.Naoya.Decisive.Swing, v55, game.SoundService.Effect)
			end
		end,
		["Hit1"] = function(p56, p57)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v58 = p57:FindFirstChild("HumanoidRootPart")
			if v58 then
				local v59 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v59.Position = v58.Position
				v59.Parent = workspace.Effects
				v_u_2:AddItem(v59, 1)
				v59.Sparks.Color = ColorSequence.new(Color3.new(0.666667, 0.666667, 1))
				v59.Wind.Color = v59.Sparks.Color
				v59.Wind2.Color = v59.Sparks.Color
				v59.Sparks:Emit(50)
				v59.Wind:Emit(7)
				v59.Wind2:Emit(7)
				v_u_12:Flash(p57, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Naoya.Decisive.FirstHit, v58, game.SoundService.Effect)
				v_u_12:ArmFlash(p56["Right Arm"], Color3.fromRGB(128, 126, 255), 0.3)
				if v_u_4.Character == p56 or v_u_4.Character == p57 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Hit2"] = function(p60, p61)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v62 = p60:FindFirstChild("HumanoidRootPart")
			if v62 then
				local v63 = p61:FindFirstChild("HumanoidRootPart")
				if v63 then
					v_u_12:Flash(p61, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Naoya.Decisive.SecondHit, v63, game.SoundService.Effect)
					v_u_12:ArmFlash(p60["Left Arm"], Color3.fromRGB(128, 126, 255), 0.3)
					v_u_12:PlaySound(v_u_7.Naoya.Decisive.Swing2, v62, game.SoundService.Effect)
					if v_u_4.Character == p60 or v_u_4.Character == p61 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Hit"] = function(p64, p65)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v66 = p64:FindFirstChild("HumanoidRootPart")
			if v66 then
				local v67 = p65:FindFirstChild("HumanoidRootPart")
				if v67 then
					v_u_12:Flash(p65, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Naoya.Decisive:FindFirstChild("Hit" .. math.random(1, 4)), v67, game.SoundService.Effect)
					local v68 = math.random(140, 200) / 10
					local v69 = v_u_6.Gojo.LapseBlue.Throw:Clone()
					v69.Transparency = 0.7
					v69.Position = p65.Head.Position
					local v70 = math.random(-180, 180)
					local v71 = math.random(-180, 180)
					local v72 = math.random
					v69.Orientation = Vector3.new(v70, v71, v72(-180, 180))
					v69.Size = Vector3.new(0, 0, 7)
					v69.Parent = workspace.Effects
					v_u_3:Create(v69, TweenInfo.new(0.1, Enum.EasingStyle.Quad), {
						["Size"] = Vector3.new(v68, v68, 0),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v69, 0.1)
					if v_u_4.Character == p64 or v_u_4.Character == p65 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightLoop)
					end
					local v73 = TweenInfo.new(0.075, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
					local v74 = TweenInfo.new(0.075, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
					for _ = 1, 2 do
						local v75 = v_u_6.Naoya.Barrage:Clone()
						v75.Parent = workspace.Effects
						v_u_2:AddItem(v75, 0.075)
						local v76 = v75.Arm1
						local v77 = v66.CFrame * CFrame.new(math.random(15, 35) / 10, math.random(-5, 15) / 10, math.random(-10, 30) / 10)
						local v78 = CFrame.Angles
						local v79 = math.random(-5, 5)
						local v80 = math.rad(v79)
						local v81 = math.random(10, 25)
						v76.CFrame = v77 * v78(v80, math.rad(v81), math.random(0, 3.141592653589793))
						local v82 = v75.Arm2
						local v83 = v66.CFrame * CFrame.new(-math.random(15, 35) / 10, math.random(-5, 15) / 10, math.random(-10, 30) / 10)
						local v84 = CFrame.Angles
						local v85 = math.random(-5, 5)
						local v86 = math.rad(v85)
						local v87 = math.random(-25, -10)
						v82.CFrame = v83 * v84(v86, math.rad(v87), math.random(0, 3.141592653589793))
						local v88 = v_u_3
						local v89 = v75.Arm1
						local v90 = {}
						local v91 = v75.Arm1.CFrame * CFrame.new(0, 0, -4)
						local v92 = CFrame.Angles
						local v93 = math.random(30, 60)
						v90.CFrame = v91 * v92(0, math.rad(v93), 0)
						v88:Create(v89, v73, v90):Play()
						local v94 = v_u_3
						local v95 = v75.Arm2
						local v96 = {}
						local v97 = v75.Arm2.CFrame * CFrame.new(0, 0, -4)
						local v98 = CFrame.Angles
						local v99 = math.random(30, 60)
						v96.CFrame = v97 * v98(0, math.rad(v99), 0)
						v94:Create(v95, v73, v96):Play()
						v_u_3:Create(v75.Arm1, v74, {
							["Transparency"] = 1
						}):Play()
						v_u_3:Create(v75.Arm2, v74, {
							["Transparency"] = 1
						}):Play()
						task.wait(0.05)
					end
				end
			else
				return
			end
		end,
		["Hit3"] = function(p100, p101)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			local v102 = p100:FindFirstChild("HumanoidRootPart")
			if v102 then
				local v103 = p101:FindFirstChild("HumanoidRootPart")
				if v103 then
					v_u_12:Flash(p101, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Naoya.Decisive:FindFirstChild("Hit" .. math.random(1, 4)), v103, game.SoundService.Effect)
					local v104 = math.random(140, 200) / 10
					local v105 = v_u_6.Gojo.LapseBlue.Throw:Clone()
					v105.Transparency = 0.7
					v105.Position = p101.Head.Position
					local v106 = math.random(-180, 180)
					local v107 = math.random(-180, 180)
					local v108 = math.random
					v105.Orientation = Vector3.new(v106, v107, v108(-180, 180))
					v105.Size = Vector3.new(0, 0, 7)
					v105.Parent = workspace.Effects
					v_u_3:Create(v105, TweenInfo.new(0.1, Enum.EasingStyle.Quad), {
						["Size"] = Vector3.new(v104, v104, 0),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v105, 0.1)
					v_u_9:Blood(p101.Head.CFrame, math.random(25, 55), 80, 15)
					if v_u_4.Character == p100 or v_u_4.Character == p101 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightLoop)
					end
					local v109 = TweenInfo.new(0.075, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
					local v110 = TweenInfo.new(0.075, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
					for _ = 1, 2 do
						local v111 = v_u_6.Naoya.Barrage:Clone()
						v111.Parent = workspace.Effects
						v_u_2:AddItem(v111, 0.075)
						local v112 = v111.Arm1
						local v113 = v102.CFrame * CFrame.new(math.random(5, 15) / 10, math.random(-5, 15) / 10, math.random(-10, 30) / 10)
						local v114 = CFrame.Angles
						local v115 = math.random(-5, 5)
						local v116 = math.rad(v115)
						local v117 = math.random(-15, 15)
						v112.CFrame = v113 * v114(v116, math.rad(v117), math.random(0, 3.141592653589793))
						local v118 = v111.Arm2
						local v119 = v102.CFrame * CFrame.new(math.random(5, 15) / 10, math.random(-5, 15) / 10, math.random(-10, 30) / 10)
						local v120 = CFrame.Angles
						local v121 = math.random(-5, 5)
						local v122 = math.rad(v121)
						local v123 = math.random(-15, 15)
						v118.CFrame = v119 * v120(v122, math.rad(v123), math.random(0, 3.141592653589793))
						local v124 = v_u_3
						local v125 = v111.Arm1
						local v126 = {}
						local v127 = v111.Arm1.CFrame * CFrame.new(0, 0, -4)
						local v128 = CFrame.Angles
						local v129 = math.random(30, 60)
						v126.CFrame = v127 * v128(0, math.rad(v129), 0)
						v124:Create(v125, v109, v126):Play()
						local v130 = v_u_3
						local v131 = v111.Arm2
						local v132 = {}
						local v133 = v111.Arm2.CFrame * CFrame.new(0, 0, -4)
						local v134 = CFrame.Angles
						local v135 = math.random(30, 60)
						v132.CFrame = v133 * v134(0, math.rad(v135), 0)
						v130:Create(v131, v109, v132):Play()
						v_u_3:Create(v111.Arm1, v110, {
							["Transparency"] = 1
						}):Play()
						v_u_3:Create(v111.Arm2, v110, {
							["Transparency"] = 1
						}):Play()
						task.wait(0.05)
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p137, ...)
		-- upvalues: (copy) v_u_136
		local v138 = v_u_136[p137]
		if v138 then
			v138(...)
		end
	end)
	v_u_11.Effects:Connect(function(p139, ...)
		-- upvalues: (copy) v_u_136
		local v140 = v_u_136[p139]
		if v140 then
			v140(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
	v_u_10 = v_u_1.GetService("DecisiveStrikeService")
	v_u_11 = v_u_1.GetService("DecisiveStrike2Service")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetController("HandicapController")
end
return v14