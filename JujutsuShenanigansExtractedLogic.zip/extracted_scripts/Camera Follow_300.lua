-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 1,
	["SortOrder"] = 4,
	["Val"] = "Follow",
	["Desc"] = "Keeps the camera focused on your peanut head ;)"
}