-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
require(v4.Modules.CameraShaker)
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "SpikeWrathController"
})
function v10.KnitStart(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_6, (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (ref) v_u_7
	local v_u_57 = {
		["Startup"] = function(p11, _)
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			local v12 = p11:FindFirstChild("HumanoidRootPart")
			if v12 then
				v_u_9:Flash(p11, Color3.fromRGB(170, 85, 255), 1)
				v_u_9:PlaySound(v_u_6.Mahito.ForceGrab.Retract, v12, game.SoundService.Effect)
			end
		end,
		["Start"] = function(p13, p14)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_5, (ref) v_u_2, (ref) v_u_3
			local v_u_15 = p13:FindFirstChild("HumanoidRootPart")
			if not v_u_15 then
				return
			end
			v_u_9:PlaySound(v_u_6.Mahito.Roll, v_u_15, game.SoundService.Effect)
			local v_u_16 = {}
			for _, v17 in p13:GetChildren() do
				if v17:IsA("BasePart") and v17 ~= v_u_15 then
					local v18 = v17.Color
					table.insert(v_u_16, v18)
				end
			end
			local v_u_19 = p13.Torso.BodyFrontAttachment
			local v_u_20 = v_u_19.Parent
			local v_u_21 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			while true do
				if (workspace.CurrentCamera.CFrame.Position - v_u_15.Position).Magnitude > 300 then
					task.wait(0.1)
				else
					task.spawn(function()
						-- upvalues: (ref) v_u_5, (copy) v_u_15, (copy) v_u_20, (copy) v_u_19, (copy) v_u_16, (ref) v_u_2, (ref) v_u_3
						local v22 = v_u_5.Mahito.Pierce:Clone()
						local v23 = v_u_15.Position
						local v24 = math.random(-35, 35)
						local v25 = math.random
						v22.Position = v23 - Vector3.new(v24, 6, v25(-35, 35)) + v_u_15.CFrame.LookVector * 20
						v22.Attachment.WorldPosition = v_u_20.Position
						v22.Pierce.Attachment0 = v_u_19
						v22.Pierce.Color = ColorSequence.new(v_u_16[math.random(1, #v_u_16)])
						v22.Pierce.CurveSize0 = math.random(-25, 25)
						v22.Parent = workspace.Effects
						v_u_2:AddItem(v22, 0.7)
						local v26 = v22.Attachment
						v_u_3:Create(v26, TweenInfo.new(0.2), {
							["Position"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_3:Create(v22.Pierce, TweenInfo.new(0.6, Enum.EasingStyle.Back), {
							["CurveSize0"] = 0
						}):Play()
						task.wait(0.5)
						local v27 = v26.WorldPosition
						v26.Parent = v_u_20
						v26.WorldPosition = v27
						v_u_3:Create(v26, TweenInfo.new(0.2), {
							["Position"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_2:AddItem(v26, 0.2)
					end)
					local v_u_28 = math.random(90, 130) / 100
					local v_u_29 = v_u_5.Mahito.Worms.Morph2:Clone()
					v_u_29.Decal:Destroy()
					v_u_29.Color = v_u_16[math.random(1, #v_u_16)]
					local v30 = v_u_29.Weld
					v30.C0 = v30.C0 * CFrame.Angles(math.random(0, 3.141592653589793), math.random(0, 3.141592653589793), math.random(0, 3.141592653589793))
					v_u_29.Weld.Part0 = v_u_15
					v_u_29.Size = Vector3.new(0, 0, 0)
					v_u_29.Parent = workspace.Effects
					v_u_2:AddItem(v_u_29, 1.7)
					v_u_3:Create(v_u_29.Weld, TweenInfo.new(v_u_28 + 0.4, Enum.EasingStyle.Exponential), {
						["C0"] = v_u_29.Weld.C0 * CFrame.Angles(math.random(0, 3.141592653589793), math.random(0, 3.141592653589793), math.random(0, 3.141592653589793))
					}):Play()
					task.spawn(function()
						-- upvalues: (copy) v_u_28, (ref) v_u_3, (copy) v_u_29, (copy) v_u_21
						local v31 = v_u_28 / 5
						v_u_3:Create(v_u_29, TweenInfo.new(v_u_28, Enum.EasingStyle.Elastic), {
							["Size"] = Vector3.new(1, 1, 1) * math.random(40, 90) / 10
						}):Play()
						local v32 = TweenInfo.new(v31, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
						for v33 = 1, 4 do
							local v34 = CFrame.new(math.random(-20, 20) / 3, math.random(-10, 20) / 5, math.random(-20, 20) / 3)
							local v35 = v33 / 6
							local v36 = {
								["C1"] = v34:Lerp(CFrame.new(), v35)
							}
							v_u_3:Create(v_u_29.Weld, v32, v36):Play()
							task.wait(v31)
						end
						v_u_3:Create(v_u_29, v_u_21, {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
					task.wait(0.075)
				end
				if not (p14 and (p14.Parent and p14.Parent.Parent)) then
					return
				end
			end
		end,
		["Grab"] = function(p37, p38, p39)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_3
			local v40 = p37:FindFirstChild("HumanoidRootPart")
			if v40 then
				local v41 = {}
				for _, v42 in p38.Attachment0.Parent.Parent:GetChildren() do
					if v42:IsA("BasePart") and v42 ~= v40 then
						local v43 = v42.Color
						table.insert(v41, v43)
					end
				end
				local v44 = math.random(1, 2)
				if v44 == 1 then
					v_u_9:PlaySound(v_u_6.Mahito.DrillSplit.Morph, v40, game.SoundService.Effect)
				elseif v44 == 2 then
					v_u_9:PlaySound(v_u_6.Mahito.DrillSplit.Unmorph, v40, game.SoundService.Effect)
				end
				p38.Color = ColorSequence.new(v41[math.random(1, #v41)])
				p38.CurveSize1 = 45
				p38.CurveSize0 = -45
				v_u_3:Create(p38, TweenInfo.new(p39, Enum.EasingStyle.Elastic), {
					["CurveSize0"] = 0,
					["CurveSize1"] = 0
				}):Play()
				task.wait(p39)
				v_u_3:Create(p38, TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
					["CurveSize1"] = 15
				}):Play()
				task.wait(0.8)
				v_u_3:Create(p38, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["CurveSize1"] = 0
				}):Play()
				task.wait(0.7)
				local v45 = Instance.new("Attachment", p38.Attachment0.Parent)
				v45.WorldPosition = p38.Attachment1.WorldPosition
				p38.Attachment1 = v45
				local v46 = math.random(40, 70) / 100
				v_u_3:Create(v45, TweenInfo.new(v46, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["Position"] = Vector3.new(0, 0, 0)
				}):Play()
			end
		end,
		["Grab2"] = function(p47, p48)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_5, (ref) v_u_3, (ref) v_u_2
			local v49 = p47:FindFirstChild("HumanoidRootPart")
			if v49 then
				local v50 = p48:FindFirstChild("HumanoidRootPart")
				if v50 then
					local v51 = {}
					for _, v52 in p47:GetChildren() do
						if v52:IsA("BasePart") and v52 ~= v49 then
							local v53 = v52.Color
							table.insert(v51, v53)
						end
					end
					local v54 = math.random(1, 2)
					if v54 == 1 then
						v_u_9:PlaySound(v_u_6.Mahito.DrillSplit.Morph, v49, game.SoundService.Effect)
					elseif v54 == 2 then
						v_u_9:PlaySound(v_u_6.Mahito.DrillSplit.Unmorph, v49, game.SoundService.Effect)
					end
					local v55 = Instance.new("Attachment")
					local v56 = v_u_5.Mahito.Pierce.Pierce:Clone()
					v56.Attachment1 = v55
					v56.Attachment0 = v49.RootAttachment
					v56.Color = ColorSequence.new(v51[math.random(1, #v51)])
					v56.CurveSize1 = 45
					v56.CurveSize0 = -45
					v56.Width0 = 3
					v56.Parent = v55
					v55.Parent = v49
					v_u_3:Create(v56, TweenInfo.new(0.4, Enum.EasingStyle.Elastic), {
						["CurveSize0"] = 0,
						["CurveSize1"] = 0
					}):Play()
					v_u_3:Create(v55, TweenInfo.new(0.1), {
						["WorldPosition"] = v50.Position
					}):Play()
					task.wait(0.1)
					v_u_3:Create(v55, TweenInfo.new(0.3), {
						["Position"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v55, 0.3)
				end
			else
				return
			end
		end
	}
	v_u_7.Effects:Connect(function(p58, ...)
		-- upvalues: (copy) v_u_57
		local v59 = v_u_57[p58]
		if v59 then
			v59(...)
		end
	end)
end
function v10.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8, (ref) v_u_9
	v_u_7 = v_u_1.GetService("SpikeWrathService")
	v_u_8 = v_u_1.GetController("HitboxController")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10