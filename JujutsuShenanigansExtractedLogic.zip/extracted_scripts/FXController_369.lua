-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = v_u_6.Remotes
local v_u_8 = v_u_6.Utils
local v_u_9 = v_u_6.Sounds
local v_u_10 = require(v_u_6.Modules.BloodyZee)
local v11 = v_u_6.Sounds.Impact.Enviroment
local v_u_12 = {
	[Enum.Material.Brick] = { 1.3, v11.BrickImpact },
	[Enum.Material.Cobblestone] = { 1.2, v11.BrickImpact },
	[Enum.Material.Slate] = { 1.1, v11.BrickImpact },
	[Enum.Material.Glass] = { 0.2, v11.GlassImpact },
	[Enum.Material.Concrete] = { 0.8, v11.StoneImpact },
	[Enum.Material.Plastic] = { 1, v11.StoneImpact },
	[Enum.Material.SmoothPlastic] = { 1, v11.StoneImpact },
	[Enum.Material.Wood] = { 0.8, v11.WoodImpact },
	[Enum.Material.WoodPlanks] = { 0.75, v11.WoodImpact },
	[Enum.Material.Grass] = { 0.6, v11.GrassImpact },
	[Enum.Material.Sand] = { 0.5, v11.GrassImpact },
	[Enum.Material.Metal] = { 0.5, v11.MetalImpact },
	[Enum.Material.DiamondPlate] = { 0.5, v11.MetalImpact },
	[Enum.Material.Neon] = { 0.5, v11.NeonImpact }
}
local v_u_13 = require(game.ReplicatedStorage.Modules.PartCache).new(v_u_8.Damage.DebreeRef, 2000, workspace.Map.Data)
v_u_13.ExpansionSize = 20
local v_u_14 = math.abs
local v15 = v_u_1.CreateController({
	["Name"] = "FXController"
})
function v15.PlaySound(_, p16, p17, p18, p19)
	local v_u_20 = p16:Clone()
	v_u_20.Parent = p17
	v_u_20.SoundGroup = p18
	v_u_20:Play()
	if p16.PlayOnRemove ~= true then
		if not p19 then
			v_u_20.Ended:Connect(function()
				-- upvalues: (copy) v_u_20
				v_u_20:Destroy()
			end)
		end
		return v_u_20
	end
	v_u_20:Destroy()
end
function v15.PlayParticles(_, p21)
	local v22 = p21:GetDescendants()
	table.insert(v22, p21)
	for _, v_u_23 in v22 do
		if v_u_23:IsA("ParticleEmitter") then
			local v24 = v_u_23:GetAttribute("EmitDelay")
			if v24 and v24 ~= 0 then
				task.delay(v24, function()
					-- upvalues: (copy) v_u_23
					v_u_23:Emit(v_u_23:GetAttribute("EmitCount"))
				end)
			else
				v_u_23:Emit(v_u_23:GetAttribute("EmitCount"))
			end
		end
	end
end
function v15.ResizeParticle(_, p25, p26)
	local v27 = {}
	for _, v28 in pairs(p25.Size.Keypoints) do
		local v29 = NumberSequenceKeypoint.new
		local v30 = v28.Time
		local v31 = v28.Value * p26
		local v32 = v28.Envelope * p26
		table.insert(v27, v29(v30, v31, v32))
	end
	p25.Size = NumberSequence.new(v27)
end
function v15.Flash(_, p33, p34, p35)
	-- upvalues: (copy) v_u_14, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4
	local v36 = workspace.CurrentCamera.CFrame.Position
	local v37 = p33.PrimaryPart.Position
	if v_u_14(v36.X - v37.X) + v_u_14(v36.Y - v37.Y) + v_u_14(v36.Z - v37.Z) <= 200 then
		local v38 = v_u_8.Damage.HitGlow:Clone()
		if p33:GetScale() ~= 1 then
			v38:ScaleTo(p33:GetScale())
		end
		v38.Parent = workspace.Effects
		v_u_3:AddItem(v38, p35 or 0.15)
		for _, v39 in v38:GetChildren() do
			local v40 = p33:FindFirstChild(v39.Name)
			if v40 then
				local v41 = Instance.new("Weld", v39)
				v41.Part0 = v39
				v41.Part1 = v40
			end
			v39.Color = p34
			if p35 then
				v_u_4:Create(v39, TweenInfo.new(p35), {
					["Transparency"] = 1
				}):Play()
			end
		end
		return v38
	end
end
function v15.ArmFlash(_, p42, p43, p44)
	-- upvalues: (copy) v_u_14, (copy) v_u_8, (copy) v_u_4, (copy) v_u_3
	local v45 = workspace.CurrentCamera.CFrame.Position
	local v46 = p42.Position
	if v_u_14(v45.X - v46.X) + v_u_14(v45.Y - v46.Y) + v_u_14(v45.Z - v46.Z) <= 200 then
		local v_u_47 = v_u_8.Damage.CombatTrail:Clone()
		v_u_47.Size = p42.Size * 1.1
		v_u_47.Color = p43
		v_u_47.Trail.Color = ColorSequence.new(p43)
		v_u_47.Weld.Part0 = p42
		v_u_47.Parent = workspace.Effects
		task.delay(p44 or 0.2, function()
			-- upvalues: (copy) v_u_47, (ref) v_u_4, (ref) v_u_3
			v_u_47.Trail.Enabled = false
			v_u_4:Create(v_u_47, TweenInfo.new(0.1), {
				["Transparency"] = 1
			}):Play()
			v_u_3:AddItem(v_u_47, 0.2)
		end)
	end
end
function v15.Notification(_, p48, p49, p50)
	-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_4
	local v51 = p50 or 3
	local v52 = v_u_5.PlayerGui:WaitForChild("Menus")
	local v53 = v52.Preset.Notification:Clone()
	v53.Noti.Text = p48
	v53.Noti.UIGradient.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, p49),
		ColorSequenceKeypoint.new(0.4, p49),
		ColorSequenceKeypoint.new(0.45, Color3.new(1, 1, 1)),
		ColorSequenceKeypoint.new(0.55, Color3.new(1, 1, 1)),
		ColorSequenceKeypoint.new(0.6, p49),
		ColorSequenceKeypoint.new(1, p49)
	})
	v53.Parent = v52.Notif
	v_u_3:AddItem(v53, v51 + 0.5)
	local v54 = v53.Noti
	v_u_4:Create(v54, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["Position"] = UDim2.new(0, 0, 0, 0),
		["TextTransparency"] = 0
	}):Play()
	v_u_4:Create(v54.UIStroke, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["Transparency"] = 0
	}):Play()
	v_u_4:Create(v54.UIGradient, TweenInfo.new(2), {
		["Offset"] = Vector2.new(1, 0)
	}):Play()
	v_u_4:Create(v54.UIStroke.UIGradient, TweenInfo.new(3.5), {
		["Offset"] = Vector2.new(1, 0)
	}):Play()
	task.wait(v51)
	v_u_4:Create(v54, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		["Position"] = UDim2.new(0, 0, 0, -35),
		["TextTransparency"] = 1
	}):Play()
	v_u_4:Create(v54.UIStroke, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		["Transparency"] = 1
	}):Play()
end
function v15.DustBreak(_, p55, p56, p57, p58, p59, p60, p61)
	-- upvalues: (copy) v_u_14, (copy) v_u_8, (copy) v_u_4, (copy) v_u_3
	local v62 = workspace.CurrentCamera.CFrame.Position
	if v_u_14(v62.X - p55.X) + v_u_14(v62.Y - p55.Y) + v_u_14(v62.Z - p55.Z) > 200 then
		return
	elseif _G.Settings.DesPHY then
		local v63 = CFrame.new(p55, p55 + p56)
		for _ = 1, p58 do
			local v64 = (v63 * CFrame.Angles(0, 0, math.random(0, 3.141592653589793)) * CFrame.new(math.random(0, p57 * 10) / 10, 0, 0)).Position
			local v65 = workspace:Raycast(v64, v63.LookVector * -(p61 or 8), _G.MapParams)
			if v65 then
				local v_u_66 = v_u_8.Damage.DebreeRef:Clone()
				v_u_66.Color = v65.Instance.Color
				v_u_66.Material = v65.Instance.Material
				v_u_66.Transparency = v65.Instance.Transparency
				local v67 = math.random(p59 * 10, p60 * 10) / 10
				local v68 = math.random(p59 * 10, p60 * 10) / 10
				local v69 = math.random(p59 * 10, p60 * 10) / 10
				v_u_66.Size = Vector3.new(v67, v68, v69)
				v_u_66.Position = v65.Position
				v_u_66.CollisionGroup = "Effects"
				v_u_66.Anchored = false
				local v70 = math.random(-20, 20)
				local v71 = math.random(20, 40)
				local v72 = math.random
				v_u_66.Velocity = Vector3.new(v70, v71, v72(-20, 20))
				local v73 = math.random(-200, 200)
				local v74 = math.random(-200, 200)
				local v75 = math.random
				v_u_66.RotVelocity = Vector3.new(v73, v74, v75(-200, 200))
				v_u_66.Parent = workspace.Effects
				task.delay(3, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_66, (ref) v_u_3
					v_u_4:Create(v_u_66, TweenInfo.new(1), {
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v_u_66, 1)
				end)
			end
		end
	end
end
function v15.DustTrail(_, p76, p77, p_u_78)
	-- upvalues: (copy) v_u_14, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	local v79 = workspace.CurrentCamera.CFrame.Position
	local v80 = p76.PrimaryPart.Position
	if v_u_14(v79.X - v80.X) + v_u_14(v79.Y - v80.Y) + v_u_14(v79.Z - v80.Z) > 200 then
		return
	else
		local v_u_81 = p76.HumanoidRootPart
		if v_u_81 then
			local v_u_82 = v_u_8.Misc.SmokeTrail:Clone()
			v_u_82.Parent = workspace.Effects
			v_u_82.CFrame = v_u_81.CFrame * (p_u_78 or CFrame.new())
			v_u_3:AddItem(v_u_82, p77 + 0.6)
			if p_u_78 then
				v_u_82.Dash.Smoke.Enabled = true
				v_u_4:Create(v_u_82.Dash.Smoke, TweenInfo.new(p77), {
					["Rate"] = 0
				}):Play()
				local v83 = workspace
				local v84 = v_u_81.Position
				local v85 = -v_u_81.Size.Y * 1.6
				local v86 = v83:Raycast(v84, Vector3.new(0, v85, 0), _G.MapParams)
				if v86 then
					v_u_82.Position = v86.Position
					v_u_82.Dash.Smoke:Emit(15)
				end
			end
			local v_u_87 = nil
			local v_u_92 = v_u_2.RenderStepped:Connect(function()
				-- upvalues: (copy) v_u_81, (copy) p_u_78, (copy) v_u_82, (ref) v_u_87
				local v88 = workspace
				local v89 = v_u_81.Position
				local v90 = -v_u_81.Size.Y * 1.6
				local v91 = v88:Raycast(v89, Vector3.new(0, v90, 0), _G.MapParams)
				if v91 then
					if p_u_78 then
						v_u_82.Dash.Smoke.Enabled = true
					end
					v_u_82.CFrame = v_u_81.CFrame * (p_u_78 or CFrame.new()) - v_u_81.Position + v91.Position
					v_u_82.Velocity = v_u_81.Velocity
					if not v_u_87 then
						v_u_87 = v_u_82.Smoke
						v_u_87.Color = ColorSequence.new(v91.Instance.Color)
						v_u_87.Enabled = true
						return
					end
					if v_u_87.Color.Keypoints[1].Value ~= v91.Instance.Color then
						v_u_87.Enabled = false
						v_u_87 = v_u_87:Clone()
						v_u_87.Color = ColorSequence.new(v91.Instance.Color)
						v_u_87.Enabled = true
						v_u_87.Parent = v_u_82
						return
					end
				else
					v_u_82.Dash.Smoke.Enabled = false
					if v_u_87 then
						v_u_87.Enabled = false
					end
				end
			end)
			task.delay(p77, function()
				-- upvalues: (copy) v_u_92, (ref) v_u_87, (copy) v_u_82
				v_u_92:Disconnect()
				if v_u_87 then
					v_u_87.Enabled = false
				end
				v_u_82.Dash.Smoke.Enabled = false
			end)
		end
	end
end
function v15.Bleed(_, p_u_93)
	-- upvalues: (copy) v_u_8, (copy) v_u_10
	if _G.Settings.Gore == true then
		for _, v94 in v_u_8.Damage.Explode:GetDescendants() do
			if v94:IsA("Attachment") then
				v94:Clone().Parent = p_u_93:FindFirstChild(v94.Parent.Name)
			end
		end
		if not p_u_93:GetAttribute("Bleeding") then
			p_u_93:SetAttribute("Bleeding", true)
			task.spawn(function()
				-- upvalues: (ref) v_u_10, (copy) p_u_93
				repeat
					v_u_10:Blood(p_u_93.Torso.CFrame, 50, 180, 180)
					task.wait(0.1)
				until not p_u_93.Parent
			end)
		end
	else
		return
	end
end
function v15.Burn(_, p95)
	-- upvalues: (copy) v_u_8
	for _, v96 in p95:GetChildren() do
		if v96:IsA("BasePart") then
			v96.Color = Color3.new(0.1, 0.1, 0.1)
			v_u_8.Damage.LegBurn.Smoke:Clone().Parent = v96
		elseif v96:IsA("Shirt") or (v96:IsA("Pants") or v96:IsA("TShirt")) then
			v96.Color3 = Color3.new(0.1, 0.1, 0.1)
		elseif v96:IsA("Accessory") then
			local v97 = v96:FindFirstChild("Handle", true)
			v97.Color = Color3.new(0.1, 0.1, 0.1)
			v97:FindFirstChildWhichIsA("SpecialMesh").TextureId = ""
		end
	end
end
function v15.DomainMapFade(_, p98, p99, p100)
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v_u_101 = Instance.new("Highlight", workspace.Map)
	v_u_101.FillColor = p98
	v_u_101.OutlineColor = p98
	v_u_101.DepthMode = Enum.HighlightDepthMode.Occluded
	v_u_101.OutlineTransparency = 1
	v_u_101.FillTransparency = 1
	v_u_4:Create(v_u_101, TweenInfo.new(p99), {
		["FillTransparency"] = 0,
		["OutlineTransparency"] = 0
	}):Play()
	v_u_3:AddItem(v_u_101, p100 + 0.5)
	task.delay(p100, function()
		-- upvalues: (ref) v_u_4, (copy) v_u_101
		v_u_4:Create(v_u_101, TweenInfo.new(0.5), {
			["FillTransparency"] = 1,
			["OutlineTransparency"] = 1
		}):Play()
	end)
end
function v15.DomainBurst(p102, p103)
	-- upvalues: (copy) v_u_8, (copy) v_u_4, (copy) v_u_3, (copy) v_u_6
	local v104 = v_u_8.DomainBurst:Clone()
	v104.Position = p103.Position
	v104.Parent = workspace.Effects
	v_u_4:Create(v104, TweenInfo.new(0.3), {
		["Size"] = Vector3.new(75, 75, 75),
		["Transparency"] = 1
	}):Play()
	v104.Attachment.Spark:Emit(1)
	v_u_3:AddItem(v104, 0.4)
	p102:PlaySound(v_u_6.Sounds.Misc.Domain.DomainOpen, p103, game.SoundService.Effect)
end
local v_u_105 = nil
local v_u_106 = nil
local v_u_107 = { 0.3, 0.7, 0.5 }
local v_u_108 = {}
for _, v109 in v_u_6.Animations:GetDescendants() do
	if v109.Name == "DomainWarn" then
		v_u_8.DomainWarn.Panel.Viewport.Display.Humanoid:LoadAnimation(v109)
	end
end
function v15.ApplyCopyOutfit(_, p110, p111)
	-- upvalues: (copy) v_u_8
	p111:ScaleTo(p110:GetScale())
	local v112 = {
		"Head",
		"Left Arm",
		"Left Leg",
		"Right Arm",
		"Right Leg",
		"Torso"
	}
	for _, v113 in p110:GetChildren() do
		if v113:IsA("Shirt") or (v113:IsA("TShirt") or (v113:IsA("Pants") or v113:IsA("BodyColors"))) then
			v113:Clone().Parent = p111
		elseif v113:IsA("Accessory") then
			local v114 = v113:Clone()
			v114.Parent = p111
			local v115 = v114:FindFirstChild("AccessoryWeld", true)
			v115.Part1 = p111:FindFirstChild(v115.Part1.Name)
		elseif v113:IsA("CharacterMesh") then
			v113:Clone().Parent = p111
		end
	end
	p111:ScaleTo(1)
	local v116 = p110.Head:FindFirstChild("face")
	if v116 then
		p111.Head.face.Texture = v116.Texture
	end
	if p110:FindFirstChild("Outfit") then
		local v117 = v_u_8.Megumi.Mahoraga.Mahoraga.Outfit:Clone()
		v117.Head.Beard:Destroy()
		v117.Head.Hat:Destroy()
		v117:ScaleTo(0.6666666666666666)
		for _, v118 in v117:GetDescendants() do
			if v118:IsA("Weld") or v118:IsA("Motor6D") then
				if table.find(v112, v118.Part0.Name) then
					v118.Part0 = p111:FindFirstChild(v118.Part0.Name)
				end
				if table.find(v112, v118.Part1.Name) then
					v118.Part1 = p111:FindFirstChild(v118.Part1.Name)
				end
			end
		end
		v117.Parent = p111
	end
	if p111["Left Arm"]:FindFirstChild("FingersL") then
		for _, v119 in p111["Left Arm"].FingersL:GetChildren() do
			if v119:IsA("BasePart") then
				v119.Color = p110["Left Arm"].Color
			end
		end
		for _, v120 in p111["Right Arm"].FingersR:GetChildren() do
			if v120:IsA("BasePart") then
				v120.Color = p110["Right Arm"].Color
			end
		end
	end
end
function v15.WorldModelChar(_, p_u_121, p_u_122)
	-- upvalues: (copy) v_u_2
	local v123 = p_u_121:Clone()
	local v_u_124 = Instance.new("WorldModel")
	for _, v125 in v123:GetChildren() do
		v125.Parent = v_u_124
	end
	v_u_124.PrimaryPart = v_u_124.Humanoid.RootPart
	for _, v126 in v_u_124:GetDescendants() do
		if v126:IsA("Sound") or v126:IsA("Script") then
			v126:Destroy()
		end
	end
	v123:Destroy()
	v_u_124.Parent = p_u_122
	for _, v127 in v_u_124:GetChildren() do
		if v127:IsA("BasePart") then
			v127.Anchored = true
		end
	end
	local v_u_128 = nil
	v_u_128 = v_u_2.Stepped:Connect(function()
		-- upvalues: (copy) p_u_121, (copy) p_u_122, (ref) v_u_128, (copy) v_u_124
		if p_u_121.Parent and p_u_122.Parent then
			for _, v129 in v_u_124:GetChildren() do
				if v129:IsA("BasePart") then
					local v130 = p_u_121:FindFirstChild(v129.Name)
					if v130 then
						v129.CFrame = v130.CFrame
					end
				end
			end
		else
			v_u_128:Disconnect()
			v_u_124:Destroy()
		end
	end)
	return v_u_124
end
function v15.Domain(p_u_131, p_u_132, p133)
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_4, (copy) v_u_107, (copy) v_u_3
	local v_u_134 = v_u_8.DomainWarn:Clone()
	v_u_134.Parent = v_u_5.PlayerGui
	local v_u_135 = v_u_134.Panel.Viewport.Display
	pcall(function()
		-- upvalues: (copy) p_u_131, (copy) p_u_132, (copy) v_u_135
		p_u_131:ApplyCopyOutfit(p_u_132, v_u_135)
	end)
	local v136 = Instance.new("Camera", v_u_134.Panel)
	v136.FieldOfView = 40
	v136.CFrame = v_u_135.HumanoidRootPart.CFrame * CFrame.new(0, 1, -5) * CFrame.Angles(0, 3.141592653589793, 0)
	v_u_134.Panel.Viewport.CurrentCamera = v136
	p133(v_u_134, v_u_135)
	v_u_4:Create(v_u_134.FlashText, TweenInfo.new(1.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		["Size"] = UDim2.new(1.5, 0, 0.43, 0)
	}):Play()
	task.delay(0.625, function()
		-- upvalues: (ref) v_u_4, (copy) v_u_134
		v_u_4:Create(v_u_134.FlashText.Text1, TweenInfo.new(0.625), {
			["TextTransparency"] = 1
		}):Play()
		v_u_4:Create(v_u_134.FlashText.Text1.UIStroke, TweenInfo.new(0.625), {
			["Transparency"] = 1
		}):Play()
		v_u_4:Create(v_u_134.FlashText.Text2, TweenInfo.new(0.625), {
			["TextTransparency"] = 1
		}):Play()
		v_u_4:Create(v_u_134.FlashText.Text2.UIStroke, TweenInfo.new(0.625), {
			["Transparency"] = 1
		}):Play()
	end)
	local v137 = 0
	for _, v138 in v_u_5.PlayerGui:GetChildren() do
		if v138.Name == "DomainWarn" and v138 ~= v_u_134 then
			v137 = v137 + 1
		end
	end
	local v139 = UDim2.new(0.5, 0, v_u_107[v137 % 3 + 1], 0)
	for _, v140 in v_u_134:GetChildren() do
		v_u_4:Create(v140, TweenInfo.new(1.25, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
			["Position"] = v139
		}):Play()
	end
	v_u_4:Create(v_u_134.Panel, TweenInfo.new(0.625, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
		["Size"] = UDim2.new(1.5, 0, 0.4, 0)
	}):Play()
	v_u_4:Create(v_u_134.PanelBack, TweenInfo.new(0.625, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
		["Size"] = UDim2.new(1.5, 0, 0.43, 0)
	}):Play()
	task.wait(0.625)
	v_u_4:Create(v_u_134.Panel, TweenInfo.new(0.625, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
		["Size"] = UDim2.new(1.5, 0, 0, 0)
	}):Play()
	v_u_4:Create(v_u_134.PanelBack, TweenInfo.new(0.625, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
		["Size"] = UDim2.new(1.5, 0, 0.03, 0)
	}):Play()
	v_u_3:AddItem(v_u_134, 0.625)
end
function v15.DebreeSound(p141, p142)
	-- upvalues: (copy) v_u_14, (copy) v_u_12
	local v143 = workspace.CurrentCamera.CFrame.Position
	local v144 = p142.Position
	if v_u_14(v143.X - v144.X) + v_u_14(v143.Y - v144.Y) + v_u_14(v143.Z - v144.Z) <= 300 then
		local v145 = v_u_12[p142.Material]
		if v145 then
			local v146 = v145[2]:GetChildren()
			p141:PlaySound(v146[math.random(1, #v146)], p142, game.SoundService.Effect)
		end
	end
end
v15.Voxels = {}
function v15.KnitStart(p_u_147)
	-- upvalues: (ref) v_u_105, (copy) v_u_9, (ref) v_u_106, (copy) v_u_5, (copy) v_u_13, (copy) v_u_14, (copy) v_u_4, (copy) v_u_3, (copy) v_u_108, (copy) v_u_8, (copy) v_u_2, (copy) v_u_7
	v_u_105.Sound:Connect(function(p148)
		-- upvalues: (copy) p_u_147
		if p148 then
			if typeof(p148) == "buffer" then
				for v149 = 1, buffer.len(p148) / 2 do
					local v150 = (v149 - 1) * 2
					local v151 = buffer.readi16(p148, v150)
					local v152 = p_u_147.Voxels[v151]
					if v152 then
						p_u_147:DebreeSound(v152[1])
					end
				end
				return
			elseif typeof(p148) == "number" then
				local v153 = p_u_147.Voxels[p148]
				if v153 then
					p_u_147:DebreeSound(v153[1])
				end
			else
				p_u_147:DebreeSound(p148)
				return
			end
		else
			return
		end
	end)
	v_u_105.Domain:Connect(function(p154)
		-- upvalues: (copy) p_u_147, (ref) v_u_9
		p_u_147:PlaySound(v_u_9.Misc.Domain.DomainHit, p154, game.SoundService.Effect)
		local v155 = p154:FindFirstChild("DomainCollider")
		if v155 then
			p_u_147:PlaySound(v_u_9.Misc.Domain.DomainHit, v155, game.SoundService.Effect)
		end
	end)
	v_u_106.CFix:Connect(function(p156)
		-- upvalues: (ref) v_u_5
		local v157 = v_u_5.Character
		if v157 then
			local v158 = v_u_5.PlayerGui:FindFirstChild("Freecam")
			if v158 then
				v158:SetAttribute("ow", workspace.CurrentCamera.CFrame.Position + p156)
			end
			for _, v159 in v157:GetDescendants() do
				if v159:IsA("BodyPosition") or v159:IsA("AlignPosition") and v159.Mode == Enum.PositionAlignmentMode.OneAttachment then
					v159.Position = v159.Position + p156
				end
			end
		end
	end)
	local v_u_160 = {}
	for v161, v162 in Enum.Material:GetEnumItems() do
		v_u_160[tostring(v161)] = v162
	end
	v_u_105.Create:Connect(function(p163, p164)
		-- upvalues: (copy) v_u_160, (copy) p_u_147, (ref) v_u_13, (ref) v_u_14, (ref) v_u_4, (ref) v_u_3, (ref) v_u_108, (ref) v_u_8
		local _ = workspace.CurrentCamera
		local v165 = workspace.CurrentCamera.CFrame.Position
		local v166 = {}
		local v167 = {}
		local v168 = false
		for v169, v170 in p163 do
			for v171, v172 in v170 do
				for v173, v174 in v172 do
					local v175 = tonumber(v169)
					local v176 = v_u_160[v171]
					local v177 = Color3.fromRGB
					local v178 = string.split
					local v179 = v177(table.unpack(v178(v173, ",")))
					local v180 = v174[1]
					local v181 = v174[2]
					local v182 = v174[3]
					local v183 = false
					if v180 ~= nil then
						for v184 = 1, buffer.len(v180) / 32 do
							local v185 = (v184 - 1) * 32
							local v186 = v185 + 0
							local v187 = buffer.readf32(v180, v186)
							local v188 = v185 + 4
							local v189 = buffer.readf32(v180, v188)
							local v190 = v185 + 8
							local v191 = buffer.readf32(v180, v190)
							local v192 = v185 + 12
							local v193 = buffer.readi16(v180, v192) / 100
							local v194 = v185 + 14
							local v195 = buffer.readi16(v180, v194) / 100
							local v196 = v185 + 16
							local v197 = buffer.readi16(v180, v196) / 100
							local v198 = v185 + 18
							local v199 = buffer.readf32(v180, v198)
							local v200 = v185 + 22
							local v201 = buffer.readf32(v180, v200)
							local v202 = v185 + 26
							local v203 = buffer.readf32(v180, v202)
							local v204 = v185 + 30
							local v205 = buffer.readu16(v180, v204)
							if not p_u_147.Voxels[v205] then
								local v206 = v_u_13:GetPart()
								v206.Color = v179
								v206.Material = v176
								v206.Size = Vector3.new(v199, v201, v203)
								v206.Transparency = v175
								v206.Locked = false
								v206.CastShadow = true
								p_u_147.Voxels[v205] = { v206 }
								table.insert(v166, v206)
								local v207 = CFrame.new((Vector3.new(v187, v189, v191))) * CFrame.fromOrientation(math.rad(v193), math.rad(v195), (math.rad(v197)))
								table.insert(v167, v207)
							end
						end
					end
					if v181 ~= nil then
						for v208 = 1, buffer.len(v181) / 32 do
							local v209 = (v208 - 1) * 32
							local v210 = v209 + 0
							local v211 = buffer.readf32(v181, v210)
							local v212 = v209 + 4
							local v213 = buffer.readf32(v181, v212)
							local v214 = v209 + 8
							local v215 = buffer.readf32(v181, v214)
							local v216 = v209 + 12
							local v217 = buffer.readi16(v181, v216) / 100
							local v218 = v209 + 14
							local v219 = buffer.readi16(v181, v218) / 100
							local v220 = v209 + 16
							local v221 = buffer.readi16(v181, v220) / 100
							local v222 = v209 + 18
							local v223 = buffer.readf32(v181, v222)
							local v224 = v209 + 22
							local v225 = buffer.readf32(v181, v224)
							local v226 = v209 + 26
							local v227 = buffer.readf32(v181, v226)
							local v228 = v209 + 30
							local v229 = buffer.readu16(v181, v228)
							if not p_u_147.Voxels[v229] then
								if v208 == 1 then
									local v230 = {
										["X"] = v211,
										["Y"] = v213,
										["Z"] = v215
									}
									v183 = v_u_14(v165.X - v230.X) + v_u_14(v165.Y - v230.Y) + v_u_14(v165.Z - v230.Z) < 100
								end
								local v231 = v_u_13:GetPart()
								v231.Color = v179
								v231.Material = v176
								v231.Size = Vector3.new(v223, v225, v227)
								v231.Transparency = v175
								v231.Locked = true
								v231.CastShadow = false
								p_u_147.Voxels[v229] = { v231, v183 }
								table.insert(v166, v231)
								local v232 = CFrame.new((Vector3.new(v211, v213, v215))) * CFrame.fromOrientation(math.rad(v217), math.rad(v219), (math.rad(v221)))
								table.insert(v167, v232)
							end
						end
					end
					if v168 == false then
						v168 = v183 == true
					end
					if v182 ~= nil then
						local v233 = false
						for v234 = 1, buffer.len(v182) / 44 do
							local v235 = (v234 - 1) * 44
							local v236 = v235 + 0
							local v237 = buffer.readf32(v182, v236)
							local v238 = v235 + 4
							local v239 = buffer.readf32(v182, v238)
							local v240 = v235 + 8
							local v241 = buffer.readf32(v182, v240)
							local v242 = v235 + 12
							local v243 = buffer.readi16(v182, v242) / 100
							local v244 = v235 + 14
							local v245 = buffer.readi16(v182, v244) / 100
							local v246 = v235 + 16
							local v247 = buffer.readi16(v182, v246) / 100
							local v248 = v235 + 18
							local v249 = buffer.readf32(v182, v248)
							local v250 = v235 + 22
							local v251 = buffer.readf32(v182, v250)
							local v252 = v235 + 26
							local v253 = buffer.readf32(v182, v252)
							local v254 = v235 + 30
							local v_u_255 = buffer.readu16(v182, v254)
							local v256 = v235 + 32
							local v257 = buffer.readi16(v182, v256) / 100
							local v258 = v235 + 34
							local v259 = buffer.readi16(v182, v258) / 100
							local v260 = v235 + 36
							local v261 = buffer.readi16(v182, v260) / 100
							local v262 = v235 + 38
							local v263 = buffer.readi16(v182, v262) / 100
							local v264 = v235 + 40
							local v265 = buffer.readi16(v182, v264) / 100
							local v266 = v235 + 42
							local v267 = buffer.readi16(v182, v266) / 100
							if not p_u_147.Voxels[v_u_255] then
								if v234 == 1 then
									local v268 = {
										["X"] = v237,
										["Y"] = v239,
										["Z"] = v241
									}
									v233 = v_u_14(v165.X - v268.X) + v_u_14(v165.Y - v268.Y) + v_u_14(v165.Z - v268.Z) < 150
								end
								if v233 ~= false then
									local v_u_269 = v_u_13:GetPart()
									v_u_269.Color = v179
									v_u_269.Material = v176
									v_u_269.Size = Vector3.new(v249, v251, v253)
									v_u_269.Transparency = v175
									v_u_269.Anchored = false
									v_u_269.Locked = true
									v_u_269.CastShadow = false
									v_u_269.AssemblyLinearVelocity = Vector3.new(v257, v259, v261)
									v_u_269.AssemblyAngularVelocity = Vector3.new(v263, v265, v267)
									p_u_147.Voxels[v_u_255] = { v_u_269, false }
									table.insert(v166, v_u_269)
									local v270 = CFrame.new((Vector3.new(v237, v239, v241))) * CFrame.fromOrientation(math.rad(v243), math.rad(v245), (math.rad(v247)))
									table.insert(v167, v270)
									task.delay(3, function()
										-- upvalues: (ref) p_u_147, (copy) v_u_255, (ref) v_u_4, (copy) v_u_269, (ref) v_u_3
										if p_u_147.Voxels[v_u_255] then
											local v271 = v_u_4:Create(v_u_269, TweenInfo.new(1), {
												["Transparency"] = 1
											})
											v271:Play()
											v_u_3:AddItem(v271, 1)
											p_u_147.Voxels[v_u_255][3] = v271
										end
									end)
								end
							end
						end
					end
				end
			end
		end
		workspace:BulkMoveTo(v166, v167, Enum.BulkMoveMode.FireCFrameChanged)
		if v168 and (p164 == nil and _G.Settings.DesVFX == true) then
			for _, v272 in v166 do
				if v272.Locked ~= false then
					local v273 = #v_u_108
					local v_u_274
					if v_u_108[v273] then
						v_u_274 = v_u_108[v273]
						v_u_108[v273] = nil
					else
						v_u_274 = v_u_8.Damage.Break:Clone()
					end
					v_u_274.Color = ColorSequence.new(v272.Color)
					v_u_274.Parent = v272
					v_u_274:Emit(1)
					task.delay(1.5, function()
						-- upvalues: (ref) v_u_274, (ref) v_u_108
						v_u_274.Parent = nil
						local v275 = v_u_108
						local v276 = v_u_274
						table.insert(v275, v276)
					end)
				end
			end
		end
	end)
	local v_u_277 = TweenInfo.new(0.2, Enum.EasingStyle.Linear)
	local v_u_278 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	v_u_105.Physics:Connect(function(p279)
		-- upvalues: (copy) p_u_147, (ref) v_u_4, (copy) v_u_278, (copy) v_u_277
		local v280 = buffer.len(p279) / 21
		if _G.Settings.DesINT == true then
			for v281 = 1, v280 do
				local v282 = (v281 - 1) * 21
				local v283 = v282 + 0
				local v284 = buffer.readf32(p279, v283)
				local v285 = v282 + 4
				local v286 = buffer.readf32(p279, v285)
				local v287 = v282 + 8
				local v288 = buffer.readf32(p279, v287)
				local v289 = v282 + 12
				local v290 = buffer.readi16(p279, v289) / 100
				local v291 = v282 + 14
				local v292 = buffer.readi16(p279, v291) / 100
				local v293 = v282 + 16
				local v294 = buffer.readi16(p279, v293) / 100
				local v295 = v282 + 18
				local v296 = buffer.readu16(p279, v295)
				local v297 = v282 + 20
				local v298 = buffer.readu8(p279, v297)
				local v299 = p_u_147.Voxels[v296]
				if v299 then
					local v300 = v299[1]
					if v300 and v300.Locked ~= false then
						local v301 = CFrame.new((Vector3.new(v284, v286, v288))) * CFrame.fromOrientation(math.rad(v290), math.rad(v292), (math.rad(v294)))
						if v299[2] == true then
							if v299[3] then
								v299[3]:Destroy()
							end
							if v298 == 1 then
								local v302 = v_u_4:Create(v300, v_u_278, {
									["CFrame"] = v301
								})
								v302:Play()
								v299[3] = v302
							else
								local v303 = v_u_4:Create(v300, v_u_277, {
									["CFrame"] = v300.CFrame:Lerp(v301, 1.5)
								})
								v303:Play()
								v299[3] = v303
							end
						else
							v300.CFrame = v301
						end
					end
				end
			end
		else
			local v304 = {}
			local v305 = {}
			for v306 = 1, v280 do
				local v307 = (v306 - 1) * 21
				local v308 = v307 + 0
				local v309 = buffer.readf32(p279, v308)
				local v310 = v307 + 4
				local v311 = buffer.readf32(p279, v310)
				local v312 = v307 + 8
				local v313 = buffer.readf32(p279, v312)
				local v314 = v307 + 12
				local v315 = buffer.readi16(p279, v314) / 100
				local v316 = v307 + 14
				local v317 = buffer.readi16(p279, v316) / 100
				local v318 = v307 + 16
				local v319 = buffer.readi16(p279, v318) / 100
				local v320 = v307 + 18
				local v321 = buffer.readu16(p279, v320)
				local v322 = p_u_147.Voxels[v321]
				if v322 then
					local v323 = v322[1]
					if v323 then
						table.insert(v305, v323)
						local v324 = CFrame.new((Vector3.new(v309, v311, v313))) * CFrame.fromOrientation(math.rad(v315), math.rad(v317), (math.rad(v319)))
						table.insert(v304, v324)
					end
				end
			end
			workspace:BulkMoveTo(v305, v304, Enum.BulkMoveMode.FireCFrameChanged)
		end
	end)
	local v_u_325 = false
	local v_u_326 = v_u_5.PlayerGui:WaitForChild("Main").DomainFade
	v_u_2.RenderStepped:Connect(function(_)
		-- upvalues: (ref) v_u_5, (ref) v_u_325, (copy) v_u_326, (ref) v_u_4
		local v327 = workspace.CurrentCamera.CFrame.Position
		local v328 = nil
		for _, v329 in workspace.Domains:GetChildren() do
			if v329:GetAttribute("Health") and (v329:GetAttribute("Fade") and (v329.Position - v327).Magnitude < v329.Size.Y / 2) then
				v328 = v329
				break
			end
		end
		local v330 = nil
		local v331 = v_u_5.Character
		if v331 then
			v331 = v_u_5.Character.Parent
		end
		if v331 and v331:FindFirstChild("Info") then
			v330 = v331.Info:FindFirstChild("DomainTag")
		end
		if v328 and (not v330 and v_u_325 == false) then
			v_u_325 = true
			v_u_326.BackgroundColor3 = v328.Color
			v_u_4:Create(v_u_326, TweenInfo.new(0), {
				["BackgroundTransparency"] = 0
			}):Play()
		elseif not v328 and v_u_325 == true then
			v_u_325 = false
			v_u_4:Create(v_u_326, TweenInfo.new(0.2), {
				["BackgroundTransparency"] = 1
			}):Play()
		end
	end)
	task.spawn(function()
		-- upvalues: (copy) p_u_147, (ref) v_u_14
		while task.wait() do
			if _G.Settings.DesINT ~= false then
				local v332 = workspace.CurrentCamera.CFrame.Position
				local v333 = 0
				for v334, v335 in p_u_147.Voxels do
					if v335[1].Locked ~= false and v335[1].Anchored ~= false then
						local v336 = v335[1].Position
						if v_u_14(v332.X - v336.X) + v_u_14(v332.Y - v336.Y) + v_u_14(v332.Z - v336.Z) < 100 then
							p_u_147.Voxels[v334][2] = true
						else
							p_u_147.Voxels[v334][2] = true
						end
						v333 = v333 + 1
						if v333 > 20 then
							task.wait()
							v333 = 0
						end
					end
				end
			end
		end
	end)
	v_u_105.Prop:Connect(function(p337)
		-- upvalues: (copy) p_u_147, (ref) v_u_13
		for _, v338 in p337 do
			local v339 = p_u_147.Voxels[v338]
			if v339 then
				p_u_147.Voxels[v338] = nil
				if v339[3] then
					v339[3]:Cancel()
				end
				v_u_13:ReturnPart(v339[1])
			end
		end
	end)
	v_u_7.Message.OnClientEvent:Connect(function(p340)
		game.TextChatService.TextChannels.RBXGeneral:DisplaySystemMessage(p340)
	end)
	pcall(function()
		local v341 = Instance.new("Humanoid")
		v341.Parent = workspace.Effects
		local v342 = next
		local v343, v344 = game:GetService("ReplicatedStorage").Utils.Preload:GetChildren()
		for _, v345 in v342, v343, v344 do
			if v345:IsA("Animation") then
				pcall(v341.LoadAnimation, v341, v345)
			end
		end
		task.delay(10, v341.Destroy, v341)
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_105, (copy) v_u_1, (ref) v_u_106
	v_u_105 = v_u_1.GetService("DebreeService")
	v_u_106 = v_u_1.GetService("DomainService")
end
return v15