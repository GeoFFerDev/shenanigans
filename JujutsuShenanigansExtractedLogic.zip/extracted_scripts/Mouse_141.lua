-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(script.Parent.Parent.Signal)
local v_u_2 = require(script.Parent.Parent.Trove)
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = {}
v_u_4.__index = v_u_4
function v_u_4.new()
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_1, (copy) v_u_3
	local v5 = v_u_4
	local v_u_6 = setmetatable({}, v5)
	v_u_6._trove = v_u_2.new()
	v_u_6.LeftDown = v_u_6._trove:Construct(v_u_1)
	v_u_6.LeftUp = v_u_6._trove:Construct(v_u_1)
	v_u_6.RightDown = v_u_6._trove:Construct(v_u_1)
	v_u_6.RightUp = v_u_6._trove:Construct(v_u_1)
	v_u_6.MiddleDown = v_u_6._trove:Construct(v_u_1)
	v_u_6.MiddleUp = v_u_6._trove:Construct(v_u_1)
	v_u_6.Scrolled = v_u_6._trove:Construct(v_u_1)
	v_u_6.Moved = v_u_6._trove:Construct(v_u_1)
	v_u_6._trove:Connect(v_u_3.InputBegan, function(p7, p8)
		-- upvalues: (copy) v_u_6
		if p8 then
			return
		elseif p7.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_6.LeftDown:Fire()
			return
		elseif p7.UserInputType == Enum.UserInputType.MouseButton2 then
			v_u_6.RightDown:Fire()
		elseif p7.UserInputType == Enum.UserInputType.MouseButton3 then
			v_u_6.MiddleDown:Fire()
		end
	end)
	v_u_6._trove:Connect(v_u_3.InputEnded, function(p9, p10)
		-- upvalues: (copy) v_u_6
		if p10 then
			return
		elseif p9.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_6.LeftUp:Fire()
			return
		elseif p9.UserInputType == Enum.UserInputType.MouseButton2 then
			v_u_6.RightUp:Fire()
		elseif p9.UserInputType == Enum.UserInputType.MouseButton3 then
			v_u_6.MiddleUp:Fire()
		end
	end)
	v_u_6._trove:Connect(v_u_3.InputChanged, function(p11, p12)
		-- upvalues: (copy) v_u_6
		if p12 then
			return
		elseif p11.UserInputType == Enum.UserInputType.MouseMovement then
			local v13 = p11.Position
			v_u_6.Moved:Fire(Vector2.new(v13.X, v13.Y))
		elseif p11.UserInputType == Enum.UserInputType.MouseWheel then
			v_u_6.Scrolled:Fire(p11.Position.Z)
		end
	end)
	return v_u_6
end
function v_u_4.IsLeftDown(_)
	-- upvalues: (copy) v_u_3
	return v_u_3:IsMouseButtonPressed(Enum.UserInputType.MouseButton1)
end
function v_u_4.IsRightDown(_)
	-- upvalues: (copy) v_u_3
	return v_u_3:IsMouseButtonPressed(Enum.UserInputType.MouseButton2)
end
function v_u_4.IsMiddleDown(_)
	-- upvalues: (copy) v_u_3
	return v_u_3:IsMouseButtonPressed(Enum.UserInputType.MouseButton3)
end
function v_u_4.GetPosition(_)
	-- upvalues: (copy) v_u_3
	return v_u_3:GetMouseLocation()
end
function v_u_4.GetDelta(_)
	-- upvalues: (copy) v_u_3
	return v_u_3:GetMouseDelta()
end
function v_u_4.GetRay(_, p14)
	-- upvalues: (copy) v_u_3
	local v15 = p14 or v_u_3:GetMouseLocation()
	return workspace.CurrentCamera:ViewportPointToRay(v15.X, v15.Y)
end
function v_u_4.Raycast(p16, p17, p18, p19)
	local v20 = p16:GetRay(p19)
	return workspace:Raycast(v20.Origin, v20.Direction * (p18 or 1000), p17)
end
function v_u_4.Project(p21, p22, p23)
	local v24 = p21:GetRay(p23)
	return v24.Origin + v24.Direction.Unit * (p22 or 1000)
end
function v_u_4.Lock(_)
	-- upvalues: (copy) v_u_3
	v_u_3.MouseBehavior = Enum.MouseBehavior.LockCurrentPosition
end
function v_u_4.LockCenter(_)
	-- upvalues: (copy) v_u_3
	v_u_3.MouseBehavior = Enum.MouseBehavior.LockCenter
end
function v_u_4.Unlock(_)
	-- upvalues: (copy) v_u_3
	v_u_3.MouseBehavior = Enum.MouseBehavior.Default
end
function v_u_4.Destroy(p25)
	p25._trove:Destroy()
end
return v_u_4