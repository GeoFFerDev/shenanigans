-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "BleedoutController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_9, (copy) v_u_4, (copy) v_u_8, (ref) v_u_10
	local v_u_40 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_7.Naoya.Bleedout.Startup, v14, game.SoundService.Effect)
			end
		end,
		["Stab"] = function(p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = v_u_6.Choso.CounterSwing:Clone()
				v17:PivotTo(v16.CFrame * CFrame.new(1, -1, -4) * CFrame.Angles(0, 0.2617993877991494, 0))
				v17.Parent = workspace.Effects
				v_u_2:AddItem(v17, 0.3)
				v17.Shock.Size = Vector3.new(10, 2, 10)
				v_u_3:Create(v17.Shock, TweenInfo.new(0.15), {
					["Size"] = Vector3.new(0, 15, 0),
					["Transparency"] = 1,
					["Position"] = v17.Shock2.Position + v16.CFrame.LookVector * 3
				}):Play()
				v_u_3:Create(v17.Shock2, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1,
					["Position"] = v17.Shock2.Position + v16.CFrame.LookVector * 3
				}):Play()
				v_u_3:Create(v17.Shockwave, TweenInfo.new(0.15), {
					["Size"] = Vector3.new(0, 10, 0),
					["Transparency"] = 1,
					["CFrame"] = v17.Shockwave.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
				}):Play()
			end
		end,
		["Hit"] = function(p18, p19)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_11:Flash(p19, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Naoya.Bleedout.Hit, v20, game.SoundService.Effect)
				for _ = 1, 5 do
					v_u_9:Blood(p19.Torso.CFrame, math.random(5, 20), 25, 25)
				end
				if v_u_4.Character == p19 or v_u_4 == p18 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Hit2"] = function(p21, p22)
			-- upvalues: (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			if p22:FindFirstChild("HumanoidRootPart") then
				for _ = 1, 20 do
					v_u_9:Blood(p22.Torso.CFrame, math.random(5, 80), 25, 25)
				end
				if v_u_4.Character == p22 or v_u_4 == p21 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Hit2Freeze"] = function(p23, p24)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			if p24:FindFirstChild("HumanoidRootPart") then
				local v_u_25 = v_u_6.Naoya.BleedFreeze.Attachment:Clone()
				v_u_25.Parent = p24.Torso
				v_u_25.Blood:Emit(100)
				task.delay(0.3, function()
					-- upvalues: (copy) v_u_25, (ref) v_u_3
					v_u_25.Blood.TimeScale = 0.01
					task.wait(0.75)
					v_u_3:Create(v_u_25.Blood, TweenInfo.new(0.2), {
						["TimeScale"] = 0.5
					}):Play()
				end)
				if v_u_4.Character == p24 or v_u_4 == p23 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Throw"] = function(p26)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				v_u_11:PlaySound(v_u_7.Naoya.Bleedout.Throw, v27, game.SoundService.Effect)
			end
		end,
		["FinishingStab"] = function(p28, p29)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_11:PlaySound(v_u_7.Naoya.Bleedout.FinisherStab, v30, game.SoundService.Effect)
				for _ = 1, 20 do
					v_u_9:Blood(p29.Torso.CFrame, math.random(5, 80), 25, 25)
				end
				if v_u_4.Character == p29 or v_u_4 == p28 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Afterimages"] = function(p31, p32)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_6
			local v33 = p31:FindFirstChild("HumanoidRootPart")
			if v33 then
				if v_u_4.Character == p32 or v_u_4.Character == p31 then
					v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(0.75, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["FieldOfView"] = 60
					}):Play()
					local v_u_34 = Instance.new("ColorCorrectionEffect", game.Lighting)
					v_u_2:AddItem(v_u_34, 2.2)
					v_u_34.TintColor = Color3.fromRGB(0, 0, 0)
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_34, (ref) v_u_3
						v_u_34.TintColor = Color3.fromRGB(135, 167, 255)
						v_u_34.Saturation = -0.5
						v_u_34.Brightness = 0.2
						task.wait(0.65)
						v_u_3:Create(v_u_34, TweenInfo.new(0.2), {
							["TintColor"] = Color3.fromRGB(255, 255, 255),
							["Saturation"] = 0,
							["Brightness"] = 0
						}):Play()
						v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
							["FieldOfView"] = 70
						}):Play()
					end)
					v_u_11:PlaySound(v_u_7.Naoya.Bleedout.Afterimages, workspace, game.SoundService.Effect)
				else
					v_u_11:PlaySound(v_u_7.Naoya.Bleedout.Afterimages, v33, game.SoundService.Effect)
				end
				for v35 = 1, 7 do
					local v36 = v_u_6.Damage.HitGlow:Clone()
					v_u_2:AddItem(v36, 1)
					v36.Parent = workspace.Effects
					local v37 = TweenInfo.new(1 - v35 * 0.1)
					for _, v38 in v36:GetChildren() do
						v38.Color = Color3.fromRGB(128, 126, 255)
						v38.Transparency = 0.2
						v38.Anchored = true
						v38.CFrame = p31[v38.Name].CFrame
						v_u_3:Create(v38, v37, {
							["Transparency"] = 1
						}):Play()
					end
					task.wait(0.1)
				end
			end
		end,
		["Flash"] = function(p39)
			-- upvalues: (ref) v_u_11
			if p39:FindFirstChild("HumanoidRootPart") then
				v_u_11:Flash(p39, Color3.new(1, 1, 1), 0.5)
			end
		end
	}
	v_u_10.Effects:Connect(function(p41, ...)
		-- upvalues: (copy) v_u_40
		local v42 = v_u_40[p41]
		if v42 then
			v42(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("BleedoutService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12