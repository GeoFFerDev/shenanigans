-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_3 = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
local v8 = v_u_1.CreateController({
	["Name"] = "StaffUppercutController"
})
local v_u_9 = nil
local v_u_10 = nil
local _ = workspace.CurrentCamera
function v8.KnitStart(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_6, (copy) v_u_3, (copy) v_u_7, (copy) v_u_5, (copy) v_u_2, (ref) v_u_10
	local v_u_22 = {
		["Start"] = function(p11)
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			local v12 = p11:FindFirstChild("HumanoidRootPart")
			if v12 then
				v_u_9:PlaySound(v_u_6.Goku.StaffUppercut.Swing, v12, game.SoundService.Effect)
			end
		end,
		["StaffTrail"] = function(p13)
			local v14 = p13.SetAssets:FindFirstChild("GokuStick")
			if v14 then
				v14.Extention.Trail.Enabled = true
			end
		end,
		["StopTrail"] = function(p15)
			local v16 = p15.SetAssets:FindFirstChild("GokuStick")
			if v16 then
				v16.Extention.Trail.Enabled = false
			end
		end,
		["Hit"] = function(p17, p18)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_9:Flash(p18, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_6.Goku.StaffUppercut.Hit, v19, game.SoundService.Effect)
				if v_u_3.Character == p17 or v_u_3.Character == p18 then
					local v20 = p18:GetAttribute("Dead") and v_u_7.Presets.SnapOh or v_u_7.Presets.HeavyHit
					v_u_7.CurrentShaker:Shake(v20)
				end
				task.wait(2)
				if p18:GetAttribute("Dead") and (v19.Parent and v19.Position.Y > 275) then
					if v_u_3.Character == p17 or v_u_3.Character == p18 then
						v_u_9:PlaySound(v_u_6.Goku.StaffUppercut.Twinkle, v19, game.SoundService.Effect)
					end
					local v21 = v_u_5.Goku.Star:Clone()
					v21.Star.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.5, 50), NumberSequenceKeypoint.new(1, 0) })
					v21.Parent = v19
					v_u_2:AddItem(v21, 1)
					v21.Star:Emit(1)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p23, ...)
		-- upvalues: (copy) v_u_22
		local v24 = v_u_22[p23]
		if v24 then
			v24(...)
		end
	end)
end
function v8.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_9
	v_u_10 = v_u_1.GetService("StaffUppercutService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v8