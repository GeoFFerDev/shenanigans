-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v8 = {
	["_sounds"] = {},
	["CreateSound"] = function(_)
		return Instance.new("Sound")
	end,
	["GetSound"] = function(p1)
		if #p1._sounds == 0 then
			for _ = 1, 5 do
				local v2 = p1._sounds
				table.insert(v2, p1:CreateSound())
			end
		end
		local v3 = p1._sounds[#p1._sounds]
		p1._sounds[#p1._sounds] = nil
		return v3
	end,
	["ReturnSound"] = function(p_u_4, p_u_5)
		if p_u_5.Playing then
			p_u_5:Stop()
		end
		p_u_5.SoundGroup = nil
		p_u_5.Parent = nil
		task.delay(0.03333333333333333, function()
			-- upvalues: (copy) p_u_4, (copy) p_u_5
			local v6 = p_u_4._sounds
			local v7 = p_u_5
			table.insert(v6, v7)
		end)
	end
}
for _ = 1, 50 do
	local v9 = v8._sounds
	table.insert(v9, v8:CreateSound())
end
return v8