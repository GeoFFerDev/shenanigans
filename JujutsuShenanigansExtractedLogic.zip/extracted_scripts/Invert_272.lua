-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 1,
	["SortOrder"] = 2,
	["Desc"] = "Reverse the colors and see the world in a new view",
	["Callback"] = function(p1)
		if p1 == true then
			local v2 = Instance.new("ColorCorrectionEffect")
			v2.Saturation = -2
			v2.Name = "InvertCC"
			v2.Parent = game.Lighting
		else
			local v3 = game.Lighting:FindFirstChild("InvertCC")
			if v3 then
				v3:Destroy()
			end
		end
	end
}