-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("TweenService")
return function(p_u_2, p3, p_u_4, p5, p6, ...)
	-- upvalues: (copy) v_u_1
	local v_u_7 = p_u_2.HumanoidRootPart.Position
	local v8 = Instance.new("Model")
	v8.Name = "Afterimage"
	local v9 = Instance.new("Humanoid")
	v9.DisplayDistanceType = "None"
	v9.HealthDisplayType = "AlwaysOff"
	v9.BreakJointsOnDeath = false
	v9.EvaluateStateMachine = false
	v9.RequiresNeck = false
	v9.AutomaticScalingEnabled = false
	local v10 = p_u_2:FindFirstChildOfClass("Shirt")
	local v11 = p_u_2:FindFirstChildOfClass("Pants")
	if v10 ~= nil then
		v10:Clone().Parent = v8
	end
	if v11 ~= nil then
		v11:Clone().Parent = v8
	end
	for _, v_u_12 in ipairs(p_u_2:GetDescendants()) do
		if v_u_12:IsA("BasePart") and (v_u_12.Name ~= "HumanoidRootPart" and (v_u_12.Name ~= "Bone" and v_u_12.Transparency < 1)) then
			local v_u_13 = v_u_12:Clone()
			for _, v14 in ipairs(v_u_13:GetChildren()) do
				if not v14:IsA("SpecialMesh") then
					v14:Destroy()
				end
			end
			v_u_13.CollisionGroup = "NoCollision"
			v_u_13.Anchored = true
			v_u_13.CanCollide = false
			v_u_13.CanTouch = false
			v_u_13.CanQuery = false
			v_u_13.Massless = true
			v_u_13.CastShadow = false
			v_u_13.Archivable = true
			v_u_13.Transparency = 0
			v_u_13.Parent = v8
			v_u_1:Create(v_u_13, TweenInfo.new(table.unpack(p3)), {
				["Transparency"] = 1
			}):Play()
			if p5 and p_u_4 then
				task.delay(p5 / 60, function()
					-- upvalues: (ref) v_u_1, (copy) v_u_13, (copy) p_u_4, (copy) v_u_12, (copy) p_u_2, (copy) v_u_7
					local v15 = p_u_4
					v_u_1:Create(v_u_13, TweenInfo.new(table.unpack(v15)), {
						["CFrame"] = v_u_12.CFrame - (p_u_2.HumanoidRootPart.Position - v_u_7)
					}):Play()
				end)
			end
		elseif v_u_12:IsA("CharacterMesh") then
			v_u_12:Clone().Parent = v8
		end
	end
	if p6 then
		task.spawn(p6, v8, ...)
	end
	v9.Parent = v8
	v8.Parent = workspace.Effects
	task.delay(p3[1], v8.Destroy, v8)
end