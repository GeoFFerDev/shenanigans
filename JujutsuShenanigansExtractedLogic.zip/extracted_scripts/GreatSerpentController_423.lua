-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "GreatSerpentController"
})
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Include
v_u_12.FilterDescendantsInstances = { workspace.Map, workspace.Spawns, workspace.Domains }
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_12, (copy) v_u_2, (copy) v_u_5, (ref) v_u_9
	local v_u_73 = {
		["Start"] = function(p13)
			-- upvalues: (ref) v_u_10, (ref) v_u_8
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_10:PlaySound(v_u_8.Megumi.Serpent.Start, v14, game.SoundService.Effect)
			end
		end,
		["Leap"] = function(p15)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_10, (ref) v_u_8
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = v_u_7.Gojo.HardHit:Clone()
				v17.CFrame = v16.CFrame * CFrame.Angles(1.5707963267948966, 0, 0) - Vector3.new(0, 3, 0)
				v17.Ring.RotSpeed = NumberRange.new(300, 600)
				v17.Ring.Speed = NumberRange.new(0.1, 20)
				v17.Parent = workspace.Effects
				v17.Ring:Emit(15)
				v17.Dust:Emit(6)
				v_u_3:AddItem(v17, 0.5)
				v_u_10:PlaySound(v_u_8.Itadori.CursedStrikes.Spin, v16, game.SoundService.Effect)
			end
		end,
		["Spawn"] = function(p_u_18, p_u_19)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_10, (ref) v_u_8, (ref) v_u_3, (ref) v_u_12, (ref) v_u_2, (ref) v_u_5
			local v_u_20 = p_u_18:FindFirstChild("HumanoidRootPart")
			if not v_u_20 then
				return
			end
			local v21 = p_u_18:FindFirstChild("Humanoid")
			if not v21 then
				return
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_7, (copy) v_u_20, (ref) v_u_4, (ref) v_u_10, (ref) v_u_8, (ref) v_u_3, (ref) v_u_12, (copy) p_u_18, (ref) v_u_2, (copy) p_u_19
				local v_u_22 = v_u_7.Megumi.Serpent:Clone()
				v_u_22:SetPrimaryPartCFrame(v_u_20.CFrame * CFrame.Angles(-0.7853981633974483, 0, 0))
				v_u_22.Parent = workspace.Effects
				local v23 = Instance.new("Highlight")
				v23.FillTransparency = 0
				v23.OutlineTransparency = 0
				v23.FillColor = Color3.new(0, 0, 0)
				v23.OutlineColor = Color3.new(0, 0, 0)
				v23.DepthMode = Enum.HighlightDepthMode.Occluded
				v23.Parent = v_u_22
				v_u_4:Create(v23, TweenInfo.new(0.4), {
					["FillTransparency"] = 1,
					["OutlineTransparency"] = 1
				}):Play()
				v_u_10:PlaySound(v_u_8.Megumi.Serpent.Spawn, v_u_20, game.SoundService.Effect)
				local v_u_24 = v_u_10:PlaySound(v_u_8.Megumi.Serpent.Fly, v_u_20, game.SoundService.Effect, true)
				v_u_3:AddItem(v_u_24, 10)
				local v_u_25 = {
					v_u_22.Torso1,
					v_u_22.Torso2,
					v_u_22.Torso3,
					v_u_22.Torso4,
					v_u_22.Torso5,
					v_u_22.Torso6,
					v_u_22.Tail
				}
				local v26 = v_u_7.Megumi.Spawn:Clone()
				v26.Parent = workspace.Effects
				v_u_3:AddItem(v26, 1)
				local v27 = workspace:Raycast(v_u_20.Position, Vector3.new(0, -30, 0), v_u_12)
				if v27 then
					v26.CFrame = CFrame.new(v27.Position, v27.Position + v27.Normal)
					v26.Shadow:Emit(12)
					v26.Dive:Emit(6)
				else
					v26.Position = v_u_20.Position
					v26.Shadow.Orientation = Enum.ParticleOrientation.FacingCamera
					v26.Shadow:Emit(6)
				end
				for _, v28 in v_u_25 do
					v28.Joint.Enabled = false
					if not v27 then
						v28.CFrame = v_u_22.Neck.CFrame + v_u_22.Neck.CFrame.LookVector * math.random(-10, 10) + v_u_22.Neck.CFrame.RightVector * math.random(-10, 10)
					end
				end
				local v_u_29 = {}
				for _, v30 in p_u_18:GetDescendants() do
					if v30:IsA("BasePart") and v30.Transparency == 0 then
						v_u_29[v30] = v30.Transparency
						v30.Transparency = 1
					end
				end
				v_u_20:FindFirstChild("RootJoint")
				local v_u_31 = Instance.new("NumberValue", p_u_18)
				v_u_31.Name = "Offset"
				local v_u_32 = false
				local v_u_33 = nil
				local v_u_34 = nil
				v_u_34 = v_u_2.Stepped:Connect(function(_, p35)
					-- upvalues: (copy) v_u_22, (ref) v_u_34, (ref) v_u_33, (copy) v_u_31, (ref) v_u_20, (copy) v_u_25, (ref) p_u_19, (ref) v_u_32, (ref) v_u_4, (ref) v_u_10, (ref) v_u_8, (copy) v_u_24, (copy) v_u_29, (ref) v_u_3, (ref) v_u_7
					if v_u_22.Parent then
						if v_u_33 then
							v_u_33 = v_u_33 + v_u_33.LookVector * (120 * p35)
						end
						local v36 = v_u_31
						v36.Value = v36.Value + 8 * p35
						local v37 = v_u_33 and v_u_33 or v_u_20.CFrame * CFrame.Angles(0, 3.141592653589793, 0)
						local v38 = CFrame.new
						local v39 = v_u_31.Value
						local v40 = v38(math.sin(v39) * 5, 0, 0)
						local v41 = CFrame.Angles
						local v42 = v_u_31.Value
						local v43 = math.cos(v42) * 25
						local v44 = v40 * v41(0, math.rad(v43), 0)
						v_u_22.Neck.CFrame = v37 * v44
						for _, v45 in v_u_25 do
							local v46 = v45.Joint
							local v47 = v46.Part0.CFrame * v46.C0
							local v48 = v46.Part1
							local v49 = CFrame.new(v47.Position, v48.Position)
							v48.CFrame = v49 + v49.LookVector * 4.619999999999999
						end
						if not (p_u_19 and p_u_19:IsDescendantOf(workspace)) and v_u_32 == false then
							v_u_32 = true
							v_u_33 = v_u_20.CFrame
							local v50 = Instance.new("Highlight")
							v50.FillTransparency = 1
							v50.OutlineTransparency = 1
							v50.FillColor = Color3.new(0, 0, 0)
							v50.OutlineColor = Color3.new(0, 0, 0)
							v50.DepthMode = Enum.HighlightDepthMode.Occluded
							v50.Parent = v_u_22
							v_u_4:Create(v50, TweenInfo.new(0.2), {
								["FillTransparency"] = 0,
								["OutlineTransparency"] = 0
							}):Play()
							v_u_10:PlaySound(v_u_8.Megumi.Serpent.Despawn, v_u_20, game.SoundService.Effect)
							v_u_4:Create(v_u_24, TweenInfo.new(1), {
								["Volume"] = 0
							}):Play()
							v_u_31:Destroy()
							for v51, v52 in v_u_29 do
								if v51 and v51.Parent then
									v51.Transparency = v52
								end
							end
							local v53 = {
								v_u_22.Head,
								v_u_22.Jaw,
								v_u_22.Neck,
								v_u_22.Torso1,
								v_u_22.Torso2,
								v_u_22.Torso3,
								v_u_22.Torso4,
								v_u_22.Torso5,
								v_u_22.Torso6,
								v_u_22.Tail
							}
							v_u_3:AddItem(v_u_22, 2)
							for _, v54 in v53 do
								v_u_10:PlaySound(v_u_8.Megumi.DivineDog.Despawn, v54, game.SoundService.Effect)
								local v55 = v_u_7.Megumi.Spawn.Shadow:Clone()
								v55.Parent = v54
								v55.Orientation = Enum.ParticleOrientation.FacingCamera
								v55.EmissionDirection = Enum.NormalId.Right
								v55.Lifetime = NumberRange.new(0.25, 0.5)
								v55:Emit(10)
								v54.Transparency = 1
								for _, v56 in v54:GetDescendants() do
									if v56:IsA("BasePart") or v56:IsA("Decal") then
										v56.Transparency = 1
									end
								end
								task.wait(0.1)
							end
						end
					else
						v_u_34:Disconnect()
					end
				end)
			end)
			if v_u_5.Character == p_u_18 then
				local v57 = Instance.new("BodyGyro", v_u_20)
				v57.P = 40000
				v57.MaxTorque = Vector3.new(40000, 40000, 40000)
				v21.PlatformStand = true
				v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(0.4, Enum.EasingStyle.Exponential), {
					["FieldOfView"] = 120
				}):Play()
				local v58 = v_u_20.Position + Vector3.new(0, 40, 0) + v_u_20.CFrame.LookVector * 40
				local v59 = Instance.new("NumberValue", p_u_19)
				v59.Value = 50
				v_u_4:Create(v59, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Value"] = 25
				}):Play()
				while true do
					p_u_19.Position = v_u_20.Position + workspace.CurrentCamera.CFrame.LookVector * v59.Value
					if v59.Value ~= 25 then
						local v60 = (v59.Value - 25) / 25
						p_u_19.Position = p_u_19.Position:Lerp(v58, v60)
					end
					v57.CFrame = CFrame.new(v_u_20.Position, p_u_19.Position)
					v_u_2.Stepped:Wait()
					if not (p_u_19:IsDescendantOf(workspace) and v_u_20.Parent) then
						v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(0.4, Enum.EasingStyle.Exponential), {
							["FieldOfView"] = 70
						}):Play()
						v21.PlatformStand = false
						v57:Destroy()
						goto l6
					end
				end
			else
				::l6::
				return
			end
		end,
		["Hit"] = function(p_u_61, p_u_62, p_u_63)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_10, (ref) v_u_8
			local v64 = p_u_62:FindFirstChild("HumanoidRootPart")
			if v64 then
				task.spawn(function()
					-- upvalues: (copy) p_u_61, (copy) p_u_63, (copy) p_u_62
					while true do
						local v65 = p_u_61:FindFirstChild("Offset")
						if v65 then
							local v66 = CFrame.new
							local v67 = -v65.Value
							local v68 = v66(0, math.sin(v67) * 5, 0)
							local v69 = CFrame.Angles
							local v70 = v65.Value
							local v71 = math.cos(v70) * 25
							p_u_63.C0 = v68 * v69(math.rad(v71), 0, 0)
							task.wait()
						else
							task.wait()
						end
						if not (p_u_61.Parent and (p_u_62.Parent and p_u_63.Parent)) then
							return
						end
					end
				end)
				local v72 = v_u_7.Megumi.DivineAttack.Bite:Clone()
				v72.Color = ColorSequence.new(Color3.fromRGB(85, 0, 127))
				v72.Parent = v64.RootAttachment
				v72:Emit(5)
				v_u_3:AddItem(v72, 0.15)
				v_u_10:PlaySound(v_u_8.Megumi.Serpent.Hit, v64, game.SoundService.Effect)
			end
		end
	}
	v_u_9.Effects:Connect(function(p74, ...)
		-- upvalues: (copy) v_u_73
		local v75 = v_u_73[p74]
		if v75 then
			v75(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("GreatSerpentService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11