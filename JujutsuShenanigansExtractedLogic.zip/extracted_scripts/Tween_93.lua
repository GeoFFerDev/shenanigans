-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("TweenService")
return {
	["new"] = function(p2, p3, p4)
		-- upvalues: (copy) v_u_1
		return v_u_1:Create(p2, p3, p4)
	end,
	["Play"] = function(_, p5, p6, p7, p8)
		-- upvalues: (copy) v_u_1
		local v9 = v_u_1:Create(p5, p6, p7)
		v9:Play()
		if p8 then
			v9.Completed:Wait()
		end
	end,
	["PlayTween"] = function(_, p10, p11)
		p10:Play()
		if p11 then
			p10.Completed:Wait()
		end
	end
}