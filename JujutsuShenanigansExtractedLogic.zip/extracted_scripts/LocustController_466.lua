-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "LocustController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (ref) v_u_9, (ref) v_u_10
	local v_u_59 = {
		["Hit"] = function(p13, p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:Flash(p13, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit" .. p14), v15, game.SoundService.Effect)
				if p14 == 3 then
					v_u_11:PlaySound(v_u_7.Locust.Slash.Punch, v15, game.SoundService.Effect)
				elseif p14 ~= 4 then
					v_u_11:PlaySound(v_u_7.Locust.Slash.Slash, v15, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["ChaseHit"] = function(p16, p17)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = p17:FindFirstChild("HumanoidRootPart")
				if v19 then
					v_u_11:Flash(p17, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit3"), v19, game.SoundService.Effect)
					local v20 = v_u_6.ChaseHit:Clone()
					local v21 = CFrame.new
					local v22 = v19.Position
					local v23 = v18.Position.X
					local v24 = v19.Position.Y
					local v25 = v18.Position.Z
					v20.CFrame = v21(v22, (Vector3.new(v23, v24, v25))) * CFrame.Angles(0, 3.141592653589793, 0)
					v20.Parent = workspace.Effects
					v20.Ring:Emit(7)
					v20.Sparks:Emit(12)
					v_u_2:AddItem(v20, 0.5)
				end
			else
				return
			end
		end,
		["AerialHit"] = function(p26, p27)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2
			local v28 = p26:FindFirstChild("HumanoidRootPart")
			if v28 then
				local v29 = p27:FindFirstChild("HumanoidRootPart")
				if v29 then
					v_u_11:Flash(p27, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v29, game.SoundService.Effect)
					if v_u_4.Character == p26 or v_u_4.Character == p27 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
					local v30 = CFrame.new(v28.Position, v29.Position - Vector3.new(0, 4, 0))
					local v31 = v_u_6.Gojo.HardHit:Clone()
					v31.CFrame = v30 + v30.LookVector * 4
					v31.Parent = workspace.Effects
					v31.Dust:Emit(5)
					v31.Ring:Emit(5)
					v31.Sparks:Emit(10)
					v_u_2:AddItem(v31, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p32)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v33 = p32.HumanoidRootPart
			if v33 then
				local v34 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v34.CFrame = v33.CFrame * CFrame.new(0, 1, -4)
				v34.Size = Vector3.new(0, 0, 2)
				v34.Parent = workspace.Effects
				v_u_3:Create(v34, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v34, 0.3)
				v_u_11:PlaySound(v_u_7.Misc.Chase, v33, game.SoundService.Effect)
				v_u_11:DustTrail(p32, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p35)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v36 = p35:FindFirstChild("HumanoidRootPart")
			if v36 then
				v_u_11:PlaySound(v_u_7.Misc.Swing.Fist, v36, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p37, p38, p39)
			-- upvalues: (ref) v_u_11, (ref) v_u_6, (ref) v_u_2
			if p39 == "Down" then
				v_u_11:ArmFlash(p37["Right Leg"], Color3.fromRGB(85, 170, 0), 0.4)
				return
			elseif p38 == 1 then
				v_u_11:ArmFlash(p37["Right Arm"], Color3.fromRGB(85, 170, 0), 0.3)
				local v40 = v_u_6.Locust.Claws:Clone()
				v40.Parent = workspace.Effects
				v40.Weld.Part0 = p37["Right Arm"]
				task.wait(0.3)
				v_u_2:AddItem(v40, 0.7)
				v40.Trail1.Enabled = false
				v40.Trail2.Enabled = false
				v40.Trail3.Enabled = false
			else
				v_u_11:ArmFlash(p37["Left Arm"], Color3.fromRGB(85, 170, 0), 0.3)
				if p38 ~= 4 and p38 ~= 3 then
					local v41 = v_u_6.Locust.Claws:Clone()
					v41.Parent = workspace.Effects
					v41.Weld.Part0 = p37["Left Arm"]
					task.wait(0.3)
					v_u_2:AddItem(v41, 0.7)
					v41.Trail1.Enabled = false
					v41.Trail2.Enabled = false
					v41.Trail3.Enabled = false
				end
			end
		end,
		["Launch"] = function(p42, p43)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v44 = p42:FindFirstChild("HumanoidRootPart")
			if v44 then
				local v45 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v45.CFrame = CFrame.new(v44.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v45.Size = Vector3.new(0, 0, 5)
				v45.Parent = workspace.Effects
				v_u_3:Create(v45, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v45.Position + Vector3.new(0, p43, 0)
				}):Play()
				v_u_2:AddItem(v45, 0.3)
				if p43 < 0 then
					v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v44, game.SoundService.Effect)
					v_u_11:DustBreak(v44.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_4:DistanceFromCharacter(v44.Position) < 20 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					end
				end
			end
		end,
		["Flight"] = function(p46, p47, _)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4
			local v_u_48 = p46:FindFirstChild("HumanoidRootPart")
			if v_u_48 then
				v_u_11:PlaySound(v_u_7.Locust.Flight, v_u_48, game.SoundService.Effect)
				if not p47 then
					for v49 = 1, 5 do
						task.delay(0.075 * v49, function()
							-- upvalues: (ref) v_u_6, (copy) v_u_48, (ref) v_u_3, (ref) v_u_2
							local v50 = v_u_6.Itadori.Shock:Clone()
							v50.CFrame = CFrame.lookAlong(v_u_48.Position, v_u_48.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
							v50.Transparency = 0.3
							v50.Parent = workspace.Effects
							v_u_3:Create(v50, TweenInfo.new(0.15), {
								["Size"] = Vector3.new(20, 0, 20),
								["Transparency"] = 1
							}):Play()
							v_u_2:AddItem(v50, 0.15)
						end)
					end
				end
				if v_u_4.Character == p46 and (p47 and p47.Parent) then
					local v51 = workspace.CurrentCamera
					v_u_48.CFrame = CFrame.lookAlong(v_u_48.Position, v51.CFrame.LookVector, Vector3.new(0, 1, 0))
					p47.Position = v_u_48.Position + v51.CFrame.LookVector * 40 * Vector3.new(1, 0.5, 1)
				end
			end
		end,
		["StingerOut"] = function(p52)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				v_u_11:PlaySound(v_u_7.Mahito.ForceGrab.Retract, v53, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Mahito.Variants.Transform3, v53, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Locust.Victory, v53, game.SoundService.Voice)
				if v_u_4.Character == p52 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["StingerFire"] = function(p54)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v_u_55 = p54:FindFirstChild("HumanoidRootPart")
			if v_u_55 then
				local v56 = v_u_6.Locust.MucusFire:Clone()
				v56.CFrame = v_u_55.CFrame * CFrame.new(0, 0, -5)
				v56.Parent = workspace.Effects
				v56.Wind:Emit(20)
				v56.Back1.Back:Emit(1)
				v56.Back2.Back:Emit(1)
				v_u_3:Create(v56.Back1, TweenInfo.new(2), {
					["CFrame"] = v56.Back1.CFrame - v56.Back1.CFrame.LookVector * 10
				}):Play()
				v_u_3:Create(v56.Back2, TweenInfo.new(2), {
					["CFrame"] = v56.Back2.CFrame - v56.Back2.CFrame.LookVector * 10
				}):Play()
				v_u_2:AddItem(v56, 2)
				v_u_11:PlaySound(v_u_7.Mahito.ForceGrab.Swing, v_u_55, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Locust.Chomp.Dash, v_u_55, game.SoundService.Effect)
				task.delay(0.4, function()
					-- upvalues: (ref) v_u_11, (ref) v_u_7, (copy) v_u_55
					v_u_11:PlaySound(v_u_7.Mahito.Variants.Transform1, v_u_55, game.SoundService.Effect)
				end)
				if v_u_4.Character == p54 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["PoisonHit"] = function(p57)
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_11, (ref) v_u_7
			local v58 = p57:FindFirstChild("HumanoidRootPart")
			if v58 then
				if v_u_4.Character == p57 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				v_u_11:PlaySound(v_u_7.Mahito.Soulfire.Hit, v58, game.SoundService.Effect)
			end
		end
	}
	v_u_9.Effects:Connect(function(p60, ...)
		-- upvalues: (copy) v_u_59
		local v61 = v_u_59[p60]
		if v61 then
			v61(...)
		end
	end)
	v_u_9.Hitbox:Connect(function(p62, p63, p64)
		-- upvalues: (ref) v_u_10, (ref) v_u_3
		local v65 = p63.HumanoidRootPart
		if not v65 then
			return
		end
		local v66 = nil
		while true do
			local v67 = v_u_10:SphereHitbox(p63, CFrame.new(0, 0, -4), 8)
			for _, v68 in v67 do
				local v69 = v68:FindFirstChild("Info")
				if v69 then
					local v70 = v69:FindFirstChild("Knockback")
					if not v70 or v70.Value ~= false then
						v66 = v67
						break
					end
				end
			end
			if v66 then
				local v71 = p62:FindFirstChildWhichIsA("NumberValue")
				if v71 then
					v_u_3:Create(v71, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p62.Parent then
				break
			end
		end
		p64:FireServer(v66, v65.CFrame)
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("LocustService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12