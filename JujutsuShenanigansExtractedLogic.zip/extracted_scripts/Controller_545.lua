-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ContextActionService")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = require("@self/Thumbstick")
local v_u_4 = require("./Helper")
local v_u_5 = require("./Bits")
local v_u_6 = {
	["DMG"] = TweenInfo.new(0.25, Enum.EasingStyle.Cubic, Enum.EasingDirection.InOut),
	["BREAK_OUT"] = TweenInfo.new(0.18, Enum.EasingStyle.Back, Enum.EasingDirection.In),
	["BREAK_IN"] = TweenInfo.new(0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
}
local v_u_7 = script.Parent.Assets.Sprites.Slash
local v_u_8 = {
	["FRAMES"] = 6,
	["DELAY"] = 0.12
}
local v_u_9 = {}
v_u_9.__index = v_u_9
function v_u_9._flashDamage(p10)
	-- upvalues: (copy) v_u_2, (copy) v_u_6
	local v11 = v_u_2:Create(p10.Controller, v_u_6.DMG, {
		["ImageTransparency"] = 0.35
	})
	local v_u_12 = v_u_2:Create(p10.Controller, v_u_6.DMG, {
		["ImageTransparency"] = 0
	})
	v11:Play()
	v11.Completed:Once(function()
		-- upvalues: (copy) v_u_12
		v_u_12:Play()
	end)
end
function v_u_9._damage(p13, p14)
	-- upvalues: (copy) v_u_5
	if os.clock() - (p13._Tick or 0) >= 0.5 then
		p13._Tick = os.clock()
		v_u_5.new(p13.State, p13.Contents, "Red", 1, Vector2.zero, {
			["fromGui"] = p13.Controller,
			["visual"] = true
		})
		p13:_flashDamage()
		p13.Signals.onDamage:Fire(p14)
	end
end
function v_u_9._checkCollisions(p15)
	-- upvalues: (copy) v_u_4
	local v16 = p15.State.Player
	if v16._Locked then
		return
	elseif os.clock() - (p15._Tick or 0) >= 0.5 then
		local v17 = v16.Pos
		local v18 = v16.Size.X * 0.5
		local v19 = v16.Size.Y * 0.5
		local v20 = math.max(v18, v19)
		local v21 = v16.Vel.Magnitude > 0.01
		local v22 = p15.Contents
		local v23 = v22.AbsoluteSize.X
		local v24 = v22.AbsoluteSize.Y
		local v25 = v23 * v23 + v24 * v24
		local v26 = math.sqrt(v25)
		local v27 = math.ceil(v26)
		for _, v28 in pairs(p15.State.Attacks) do
			if v28 and v28.Pos then
				local v29 = v28.Dmg or 0
				if v29 > 0 then
					if v28.Kind == "Knife" then
						if (v28.Mode ~= "MovePunish" or v21) and (v28.Mode ~= "StillPunish" or not v21) then
							local v30 = not (v28.AbsSize and v28.AbsSize.X) and v28.Size
							if v30 then
								v30 = v28.Size.X
							end
							local v31 = not (v28.AbsSize and v28.AbsSize.Y) and v28.Size
							if v31 then
								v31 = v28.Size.Y
							end
							local v32 = v28._proxR
							if not v32 then
								if v30 and v31 then
									local v33 = (0.5 * v30) ^ 2 + (0.5 * v31) ^ 2
									v32 = math.sqrt(v33) + 14
								else
									v32 = v_u_4.computeBroadRadius(v28, v27) + 14
								end
								local v34 = v32 * v32
								v28._proxR = v32
								v28._proxR2 = v34
							end
							local v35 = v17.X - v28.Pos.X
							local v36 = v17.Y - v28.Pos.Y
							local v37 = v20 + v32
							if v35 * v35 + v36 * v36 <= v37 * v37 and (v30 and v31) then
								local v38 = 0.5 * v30
								local v39 = 0.5 * v31
								if v28.Rot and v28.Rot % 360 ~= 0 then
									if v28._rHx and v28._rHy then
										v38 = v28._rHx
										v39 = v28._rHy
									else
										v38, v39 = v_u_4.rotAabbHalf(v38, v39, v28.Rot)
									end
								end
								local v40 = math.abs(v35)
								local v41 = math.abs(v36)
								if v40 <= v18 + v38 and v41 <= v19 + v39 then
									p15:_damage(v29)
									return
								end
							end
						end
					elseif v28.Kind == "Bits" then
						local v42 = not (v28.AbsSize and v28.AbsSize.X) and v28.Size
						if v42 then
							v42 = v28.Size.X
						end
						local v43 = not (v28.AbsSize and v28.AbsSize.Y) and v28.Size
						if v43 then
							v43 = v28.Size.Y
						end
						local v44 = v28._proxR
						if not v44 then
							if v42 and v43 then
								local v45 = (0.5 * v42) ^ 2 + (0.5 * v43) ^ 2
								v44 = math.sqrt(v45) + 6
							else
								v44 = v_u_4.computeBroadRadius(v28, v27) + 6
							end
							local v46 = v44 * v44
							v28._proxR = v44
							v28._proxR2 = v46
						end
						local v47 = v17.X - v28.Pos.X
						local v48 = v17.Y - v28.Pos.Y
						local v49 = v20 + v44
						if v47 * v47 + v48 * v48 <= v49 * v49 and (v42 and v43) then
							local v50 = math.abs(v47)
							local v51 = math.abs(v48)
							if v50 <= v18 + 0.5 * v42 and v51 <= v19 + 0.5 * v43 then
								p15:_damage(v29)
								if v28.Destroy then
									v28.Destroy()
								end
								return
							end
						end
					elseif v28.Radius then
						if v_u_4.intersectsAabbCircle(v17, v18, v19, v28.Pos, v28.Radius) then
							p15:_damage(v29)
							return
						end
					elseif v28.Kind == "SpinSweep" and v28.Rot ~= nil then
						local v52, v53
						if v28.AbsSize then
							v52 = v28.AbsSize.X * 0.5
							v53 = v28.AbsSize.Y * 0.5
						else
							local v54 = 2 * v23
							local v55 = v27 - v54
							v52 = 0.5 * (v54 + (math.max(0, v55) + 8))
							local v56 = v28.Minor or 2
							v53 = math.max(2, v56) * 0.5
						end
						if v_u_4.intersectsAabbObb(v17, v18, v19, v28.Pos, v52, v53, v28.Rot) then
							p15:_damage(v29)
							return
						end
					elseif v28.Pos and (v28.Size or v28.AbsSize) then
						local v57 = v28.AbsSize and v28.AbsSize.X or v28.Size.X
						local v58 = v28.AbsSize and v28.AbsSize.Y or v28.Size.Y
						local v59 = v17.X - v28.Pos.X
						local v60 = math.abs(v59)
						local v61 = v17.Y - v28.Pos.Y
						local v62 = math.abs(v61)
						if v60 <= v18 + 0.5 * v57 and v62 <= v19 + 0.5 * v58 then
							p15:_damage(v29)
							return
						end
					end
				end
			end
		end
	end
end
function v_u_9._playSlashFlipbook(p63)
	-- upvalues: (copy) v_u_8, (copy) v_u_7
	for v64 = 1, v_u_8.FRAMES do
		local v65 = v_u_7[tostring(v64)]:Clone()
		v65.AnchorPoint = Vector2.new(0.5, 0.5)
		v65.Position = UDim2.fromScale(0.5, 0.5)
		v65.Parent = p63.Controller
		task.wait(v_u_8.DELAY)
		v65:Destroy()
	end
end
function v_u_9.Break(p_u_66)
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_4, (copy) v_u_5
	local v67 = p_u_66.State.Player
	v67.Vel = Vector2.zero
	v67._Locked = true
	p_u_66:_playSlashFlipbook()
	local v68 = p_u_66.Controller.Size
	local v69 = v_u_2:Create(p_u_66.Controller, v_u_6.BREAK_OUT, {
		["Size"] = v_u_4.scaleUDim2(v68, 0.2)
	})
	local v_u_70 = v_u_2:Create(p_u_66.Controller, v_u_6.BREAK_IN, {
		["Size"] = v_u_4.scaleUDim2(v68, 1.2)
	})
	v69:Play()
	v69.Completed:Once(function()
		-- upvalues: (copy) v_u_70, (copy) p_u_66, (ref) v_u_5
		v_u_70:Play()
		v_u_70.Completed:Once(function()
			-- upvalues: (ref) p_u_66, (ref) v_u_5
			p_u_66.Controller.Visible = false
			v_u_5.new(p_u_66.State, p_u_66.Contents, "Red", 10, Vector2.zero, {
				["fromGui"] = p_u_66.Controller,
				["visual"] = true
			})
			v_u_5.new(p_u_66.State, p_u_66.Contents, "Heart_Left", 1, Vector2.zero, {
				["fromGui"] = p_u_66.Controller,
				["visual"] = true
			})
			v_u_5.new(p_u_66.State, p_u_66.Contents, "Heart_Right", 1, Vector2.zero, {
				["fromGui"] = p_u_66.Controller,
				["visual"] = true
			})
		end)
	end)
end
function v_u_9.Clear(p71)
	local v72 = p71.State.Player
	v72.Req = Vector2.zero
	table.clear(v72._Held)
end
function v_u_9.Initialize(p_u_73)
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v_u_74 = p_u_73.State.Player
	p_u_73.Arena = p_u_73.GUI.Canvas.Contents.Arena
	p_u_73.Contents = p_u_73.Arena.Contents
	p_u_73.Attacks = p_u_73.Contents.Attacks
	p_u_73.Visuals = p_u_73.Contents.Visuals
	local v_u_75 = {
		["up"] = {
			["kb"] = false,
			["dpad"] = false,
			["touch"] = false
		},
		["down"] = {
			["kb"] = false,
			["dpad"] = false,
			["touch"] = false
		},
		["left"] = {
			["kb"] = false,
			["dpad"] = false,
			["touch"] = false
		},
		["right"] = {
			["kb"] = false,
			["dpad"] = false,
			["touch"] = false
		}
	}
	local v_u_76 = Vector2.zero
	local v_u_77 = false
	local function v_u_84()
		-- upvalues: (copy) v_u_74, (copy) v_u_75, (ref) v_u_77, (ref) v_u_76, (copy) p_u_73
		if v_u_74._Locked then
			v_u_74.Req = Vector2.zero
		else
			local v78 = v_u_75.up.kb or (v_u_75.up.dpad or v_u_75.up.touch)
			local v79 = v_u_75.down.kb or (v_u_75.down.dpad or v_u_75.down.touch)
			local v80 = v_u_75.left.kb or (v_u_75.left.dpad or v_u_75.left.touch)
			local v81 = ((v_u_75.right.kb or (v_u_75.right.dpad or v_u_75.right.touch)) and 1 or 0) + (v80 and -1 or 0)
			local v82 = (v79 and 1 or 0) + (v78 and -1 or 0)
			local v83 = Vector2.new(v81, v82)
			if v_u_77 then
				v83 = v_u_76
			end
			if p_u_73.State.Arena.Kind == "1D" then
				v83 = Vector2.new(v83.X, 0)
			end
			if v83.Magnitude > 1 then
				v83 = v83.Unit
			end
			v_u_74.Req = v83
		end
	end
	v_u_1:BindAction("CONTROLLER_MOVE_KEYS", function(p85, p86, p87)
		-- upvalues: (copy) v_u_74, (copy) v_u_75, (copy) p_u_73, (ref) v_u_77, (ref) v_u_76, (copy) v_u_84
		if v_u_74._Locked then
			v_u_74.Req = Vector2.zero
			return Enum.ContextActionResult.Sink
		end
		if p85 ~= "CONTROLLER_MOVE_KEYS" then
			return Enum.ContextActionResult.Pass
		end
		local v88 = p86 == Enum.UserInputState.Begin and true or p86 == Enum.UserInputState.Change
		local v89 = p87.KeyCode
		if v89 == Enum.KeyCode.W or v89 == Enum.KeyCode.Up then
			v_u_74._Held[v89] = v88
			v_u_75.up.kb = v88
		elseif v89 == Enum.KeyCode.S or v89 == Enum.KeyCode.Down then
			v_u_74._Held[v89] = v88
			v_u_75.down.kb = v88
		elseif v89 == Enum.KeyCode.A or v89 == Enum.KeyCode.Left then
			v_u_74._Held[v89] = v88
			v_u_75.left.kb = v88
		elseif v89 == Enum.KeyCode.D or v89 == Enum.KeyCode.Right then
			v_u_74._Held[v89] = v88
			v_u_75.right.kb = v88
		elseif v89 == Enum.KeyCode.DPadUp then
			v_u_75.up.dpad = v88
		elseif v89 == Enum.KeyCode.DPadDown then
			v_u_75.down.dpad = v88
		elseif v89 == Enum.KeyCode.DPadLeft then
			v_u_75.left.dpad = v88
		elseif v89 == Enum.KeyCode.DPadRight then
			v_u_75.right.dpad = v88
		end
		local v90 = (v_u_74._Held[Enum.KeyCode.D] or v_u_74._Held[Enum.KeyCode.Right]) and 1 or 0
		local v91 = (v_u_74._Held[Enum.KeyCode.A] or v_u_74._Held[Enum.KeyCode.Left]) and -1 or 0
		local v92 = (v_u_74._Held[Enum.KeyCode.S] or v_u_74._Held[Enum.KeyCode.Down]) and 1 or 0
		local v93 = (v_u_74._Held[Enum.KeyCode.W] or v_u_74._Held[Enum.KeyCode.Up]) and -1 or 0
		if p_u_73.State.Arena.Kind == "1D" then
			v92 = 0
			v93 = 0
		end
		local v94 = Vector2.new(v90 + v91, v92 + v93)
		if v94.Magnitude > 1 then
			v94 = v94.Unit
		end
		local v95 = v_u_74
		if v_u_77 then
			v94 = v_u_76 or v94
		end
		v95.Req = v94
		v_u_84()
		return Enum.ContextActionResult.Sink
	end, false, Enum.KeyCode.W, Enum.KeyCode.A, Enum.KeyCode.S, Enum.KeyCode.D, Enum.KeyCode.Up, Enum.KeyCode.Down, Enum.KeyCode.Left, Enum.KeyCode.Right, Enum.KeyCode.DPadUp, Enum.KeyCode.DPadDown, Enum.KeyCode.DPadLeft, Enum.KeyCode.DPadRight, Enum.KeyCode.LeftShift, Enum.KeyCode.RightShift)
	v_u_1:BindAction("CONTROLLER_MOVE_STICK", function(_, p96, p97)
		-- upvalues: (ref) v_u_77, (ref) v_u_76, (copy) v_u_84, (copy) p_u_73
		if p97.KeyCode == Enum.KeyCode.Thumbstick1 then
			local v98 = p97.Position.X
			local v99 = -p97.Position.Y
			local v100 = Vector2.new(v98, v99)
			if p96 == Enum.UserInputState.End or v100.Magnitude < 0.3 then
				v_u_77 = false
				v_u_76 = Vector2.zero
				v_u_84()
			else
				if v100.Magnitude > 1 then
					v100 = v100.Unit
				end
				if p_u_73.State.Arena.Kind == "1D" then
					v100 = Vector2.new(v100.X, 0)
				end
				v_u_77 = true
				v_u_76 = v100
				v_u_84()
			end
		else
			return
		end
	end, false, Enum.KeyCode.Thumbstick1)
	local v101 = v_u_3.new({
		["Position"] = UDim2.new(0.8, 0, 0.6, 0),
		["Theme"] = "Modern",
		["UiType"] = 1,
		["Deadzone"] = 2
	})
	p_u_73.Trove:Connect(v101.Changed, function(p102)
		-- upvalues: (ref) v_u_77, (ref) v_u_76, (copy) p_u_73, (copy) v_u_84
		if p102.Magnitude < 0.3 then
			v_u_77 = false
			v_u_76 = Vector2.zero
		else
			if p102.Magnitude > 1 then
				p102 = p102.Unit
			end
			if p_u_73.State.Arena.Kind == "1D" then
				p102 = Vector2.new(p102.X, 0)
			end
			v_u_77 = true
			v_u_76 = Vector2.new(p102.X, -p102.Y)
		end
		v_u_84()
	end)
	p_u_73.Trove:Connect(v101.Ended, function()
		-- upvalues: (ref) v_u_77, (ref) v_u_76, (copy) v_u_84
		v_u_77 = false
		v_u_76 = Vector2.zero
		v_u_84()
	end)
	p_u_73.Trove:Add(function()
		-- upvalues: (ref) v_u_1, (ref) v_u_3
		v_u_1:UnbindAction("CONTROLLER_MOVE_KEYS")
		v_u_1:UnbindAction("CONTROLLER_MOVE_STICK")
		v_u_3:ClearUis()
	end)
end
function v_u_9.Step(p103, p104)
	-- upvalues: (copy) v_u_4
	local v105 = p103.State.Player
	local v106 = p103.State.Arena
	local v107 = v105.Req
	if v107.Magnitude > 1 then
		v107 = v107.Unit
	end
	v105.Vel = v105.Vel:Lerp(v107, v105.Accel * p104)
	local v108 = v106.Size
	local v109 = v_u_4.unitScale(p103.Contents, p103.State.Arena.BaselineMin)
	local v110 = v105.Speed * v109
	local v111 = v105.Pos + v105.Vel * v110 * p104
	local v112 = (v108.X - v105.Size.X * 1.5) * 0.5
	local v113 = (v108.Y - v105.Size.Y * 1.5) * 0.5
	if v112 == 0 or v113 == 0 then
		return
	elseif v113 < -v113 then
		return
	elseif v112 >= -v112 then
		local v114 = Vector2.new
		local v115 = v111.X
		local v116 = -v112
		local v117 = math.clamp(v115, v116, v112)
		local v118 = v111.Y
		local v119 = -v113
		local v120 = v114(v117, (math.clamp(v118, v119, v113)))
		local v121 = v_u_4.roundpx(v120.X)
		local v122 = v_u_4.roundpx(v120.Y)
		v105.Pos = v120
		p103.Controller.Position = UDim2.new(0.5, v121, 0.5, v122)
		p103:_checkCollisions()
	end
end
function v_u_9.new(p123, p124, p125, p_u_126, p127)
	-- upvalues: (copy) v_u_9
	local v128 = v_u_9
	local v_u_129 = setmetatable({
		["Trove"] = p123,
		["Signals"] = p124,
		["State"] = p125,
		["Controller"] = p_u_126,
		["GUI"] = p127,
		["_Tick"] = 0
	}, v128)
	v_u_129:Initialize()
	v_u_129.State.Player.Size = p_u_126.AbsoluteSize
	v_u_129.Trove:Connect(p_u_126:GetPropertyChangedSignal("AbsoluteSize"), function()
		-- upvalues: (copy) v_u_129, (copy) p_u_126
		v_u_129.State.Player.Size = p_u_126.AbsoluteSize
	end)
	return v_u_129
end
function v_u_9.Destroy(p130)
	table.clear(p130)
	setmetatable(p130, nil)
end
return v_u_9