-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v3 = game:GetService("Players")
local v_u_4 = require(script.Parent.VelocityHandler)
local v_u_5 = require(script.Parent.EffectUtility)
local v_u_6 = require(script.Parent.RockHandler)
local v_u_7 = Random.new()
local v_u_8 = v3.LocalPlayer
local v_u_9 = v_u_1.Utils.Misc.C.Chara.Dashes
local function v_u_13(p10, p11)
	for _, v12 in p10:GetChildren() do
		if v12:IsA("BodyVelocity") and (not p11 or v12 ~= p11) and (v12.Name == "SwingForce" or v12.Name == "MovementForce") then
			v12:Destroy()
		end
	end
end
return function(p_u_14, p_u_15)
	-- upvalues: (copy) v_u_2, (copy) v_u_8, (copy) v_u_13, (copy) v_u_1, (copy) v_u_4, (copy) v_u_9, (copy) v_u_7, (copy) v_u_5, (copy) v_u_6
	local v_u_16 = p_u_14.HumanoidRootPart
	local v_u_17 = p_u_14.Humanoid
	local v18 = p_u_14.Torso
	if (not v_u_2:IsClient() or v_u_8.Character ~= p_u_14) and not v_u_2:IsServer() or (p_u_15 ~= "Left" and p_u_15 ~= "Right" or not p_u_14.Info:FindFirstChild("SidedashCooldown")) then
		local v_u_19
		if v_u_8.Character == p_u_14 and p_u_15 ~= "Back" then
			v_u_13(v18)
			v_u_13(v_u_16)
			local v_u_20 = v_u_17:LoadAnimation((v_u_1.Animations.Misc.C.Dashes:FindFirstChild(p_u_15)))
			v_u_20.Priority = Enum.AnimationPriority.Movement
			v_u_20:Play()
			local v21 = Instance.new("BoolValue")
			v21.Name = "SidedashCooldown"
			v21.Parent = p_u_14.Info
			task.delay(2, v21.Destroy, v21)
			local v22 = Instance.new("BoolValue")
			v22.Name = "BackdashCooldown"
			v22.Parent = p_u_14.Info
			task.delay(0.4, v22.Destroy, v22)
			v_u_19 = v_u_4:CreateVelocity(Vector3.new(80000, 0, 80000), v_u_16)
			v_u_4.new({
				["BodyVelocity"] = v_u_19,
				["RootPart"] = v_u_16,
				["Duration"] = 0.675,
				["RemoveTime"] = 0.3552631578947369,
				["Controllable"] = true,
				["X"] = (p_u_15 == "Left" and -185 or 185) / 1.15
			})
			local v_u_23 = p_u_14:GetAttributeChangedSignal("Stun"):Connect(function()
				-- upvalues: (copy) p_u_14, (ref) v_u_19, (copy) v_u_20
				if p_u_14:GetAttribute("Stun") and v_u_19.Parent then
					v_u_20:Stop()
					v_u_19:Destroy()
				end
			end)
			task.delay(0.3552631578947369, function()
				-- upvalues: (ref) v_u_23
				v_u_23:Disconnect()
			end)
		else
			v_u_19 = nil
		end
		if v_u_2:IsClient() then
			local v24
			if p_u_15 == "Back" then
				v24 = v_u_9.Back
			else
				v24 = v_u_9.Side:FindFirstChild(v_u_7:NextInteger(1, 2))
			end
			v_u_5.AddSFX(v24, v_u_16, 2)
			if not v_u_19 then
				v_u_19 = Instance.new("Configuration")
				v_u_19.Parent = workspace.Effects
				task.delay(p_u_15 == "Back" and 1.1 or 0.675, v_u_19.Destroy, v_u_19)
			end
			if v_u_8.Character == p_u_14 then
				local v_u_25 = nil
				v_u_25 = v_u_2.RenderStepped:Connect(function()
					-- upvalues: (ref) v_u_19, (ref) v_u_25, (copy) v_u_17, (copy) v_u_16
					if not v_u_19.Parent then
						v_u_25:Disconnect()
					end
					if v_u_17.AutoRotate ~= false then
						local v26 = workspace.CurrentCamera.CFrame.LookVector
						local v27 = v_u_16
						local v28 = CFrame.new
						local v29 = v_u_16.Position
						local v30 = v_u_16.Position
						local v31 = v26.X
						local v32 = v26.Z
						v27.CFrame = v28(v29, v30 + Vector3.new(v31, 0, v32))
					end
				end)
			end
			local v_u_33 = 0
			task.spawn(function()
				-- upvalues: (ref) v_u_33, (ref) v_u_19, (copy) p_u_15, (copy) v_u_16, (ref) v_u_7, (ref) v_u_6
				while true do
					v_u_33 = v_u_33 + task.wait(0.03)
					if not v_u_19.Parent then
						break
					end
					if v_u_33 > (p_u_15 == "Back" and 0.2 or 0.1) then
						v_u_33 = 0
						local v34 = workspace:Raycast(v_u_16.Position, Vector3.new(-0, -3.5, -0), _G.MapParams)
						if v34 then
							local v35 = script.Dust:Clone()
							v35.CFrame = CFrame.new(v34.Position) * (v_u_16.CFrame - v_u_16.Position)
							v35.Color = v34.Instance.Color
							v35.Parent = workspace.Effects
							task.delay(2.5, v35.Destroy, v35)
							v35.Smoke:Emit(10)
						end
					end
					if p_u_15 ~= "Back" then
						if v_u_7:NextInteger(1, 2) == 1 then
							v_u_6.Rocks(v_u_16.Position + v_u_16.CFrame.LookVector * v_u_7:NextNumber(-2, 2), false, v_u_7:NextNumber(0.45, 0.55))
						end
						if v_u_7:NextInteger(1, 2) == 1 then
							v_u_6.Rocks(v_u_16.Position + v_u_16.CFrame.LookVector * v_u_7:NextNumber(-2, 2), false, v_u_7:NextNumber(0.45, 0.55))
						end
					end
				end
			end)
		end
		return true
	end
end