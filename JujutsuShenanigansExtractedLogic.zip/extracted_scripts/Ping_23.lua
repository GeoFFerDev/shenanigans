-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "ping",
	["Description"] = "Returns the ping of the user",
	["Group"] = {
		"Owner",
		"Developer",
		"Contrib",
		"HeadMod",
		"Mod"
	},
	["Args"] = {
		{
			["Type"] = "player",
			["Name"] = "Player"
		}
	}
}
return v1