-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("TweenService")
local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = script.Parent:WaitForChild("RikaRig")
local v_u_3 = v_u_2:WaitForChild("RootPart")
local v4 = script.Parent:WaitForChild("Owner").Value
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = workspace.CurrentCamera
local v_u_7 = v_u_5.Character == v4
local v8 = script.Parent.Effects
v_u_3.CFrame = script.Parent.CFrame
local v9 = v_u_2.Control:LoadAnimation(script.Idle)
v9:Play()
v9.Priority = Enum.AnimationPriority.Idle
local v_u_10 = v1.Sounds
local v_u_11 = v_u_2.Control:LoadAnimation(script.Spawn)
v_u_11:Play(0)
local v12 = v_u_10.Yuta.Rika.Summon
local v_u_13 = v12:Clone()
v_u_13.Parent = script.Parent
v_u_13:Play()
task.delay(v12.TimeLength, function()
	-- upvalues: (copy) v_u_13
	v_u_13:Destroy()
end)
if v_u_7 then
	task.delay(0.4, function()
		-- upvalues: (copy) v_u_10
		local v14 = v_u_10.Yuta.Rika.SummonVL
		local v_u_15 = v14:Clone()
		v_u_15.Parent = script.Parent
		v_u_15:Play()
		task.delay(v14.TimeLength, function()
			-- upvalues: (copy) v_u_15
			v_u_15:Destroy()
		end)
	end)
end
local v_u_16 = {}
local v17 = script:WaitForChild("F")
local v18 = v_u_2.Control:LoadAnimation(v17)
v18:Play(nil, 0.01)
v_u_16[v17.Name] = v18
v18.Priority = Enum.AnimationPriority.Movement
local v19 = script:WaitForChild("B")
local v20 = v_u_2.Control:LoadAnimation(v19)
v20:Play(nil, 0.01)
v_u_16[v19.Name] = v20
v20.Priority = Enum.AnimationPriority.Movement
local v21 = script:WaitForChild("L")
local v22 = v_u_2.Control:LoadAnimation(v21)
v22:Play(nil, 0.01)
v_u_16[v21.Name] = v22
v22.Priority = Enum.AnimationPriority.Movement
local v23 = script:WaitForChild("R")
local v24 = v_u_2.Control:LoadAnimation(v23)
v24:Play(nil, 0.01)
v_u_16[v23.Name] = v24
v24.Priority = Enum.AnimationPriority.Movement
function isRikaObstructing()
	-- upvalues: (copy) v_u_5, (copy) v_u_6
	local v25 = v_u_5.Character
	if v25 then
		local v26 = v25:FindFirstChild("HumanoidRootPart")
		if v26 then
			if script.Parent.Info:FindFirstChild("Transparent") then
				return true
			end
			local v27 = v_u_6.CFrame
			local v28 = script.Parent.CFrame
			if (v28.Position - v27.Position).Unit:Dot(v27.LookVector) > 0.7 then
				return (v26.Position - v27.Position).Magnitude > (v28.Position - v27.Position).Magnitude
			end
		end
	else
		return
	end
end
function updateRikaTransparency()
	-- upvalues: (copy) v_u_2
	if isRikaObstructing() then
		if not v_u_2:GetAttribute("Translucent") then
			v_u_2:SetAttribute("Translucent", true)
			for _, v29 in v_u_2:GetDescendants() do
				if v29:IsA("BasePart") then
					v29.LocalTransparencyModifier = 0.7
				elseif v29:IsA("ParticleEmitter") then
					v29.LocalTransparencyModifier = 0.98
				end
			end
		end
	elseif v_u_2:GetAttribute("Translucent") then
		v_u_2:SetAttribute("Translucent", false)
		for _, v30 in v_u_2:GetDescendants() do
			if v30:IsA("BasePart") or v30:IsA("ParticleEmitter") then
				v30.LocalTransparencyModifier = 0
			end
		end
	end
end
local v_u_31 = nil
v_u_31 = game:GetService("RunService").RenderStepped:Connect(function(p32)
	-- upvalues: (ref) v_u_31, (copy) v_u_7, (copy) v_u_3, (copy) v_u_16
	if script.Parent:GetAttribute("Dead") then
		v_u_31:Disconnect()
	else
		if v_u_7 then
			script.Parent:GetAttribute("Move")
		end
		local v33 = v_u_3.Position
		if script.Parent.Info:FindFirstChild("SnapPosition") then
			v_u_3.CFrame = script.Parent.CFrame
		else
			v_u_3.CFrame = v_u_3.CFrame:Lerp(script.Parent.CFrame, 7 * p32)
		end
		local v34 = (v_u_3.Position - v33) * 4
		local v35 = v_u_3.CFrame:VectorToObjectSpace(v34)
		local v36 = v_u_16.F
		local v37 = -v35.Z * 1
		v36:AdjustWeight((math.clamp(v37, 0.01, 1)))
		local v38 = v_u_16.B
		local v39 = v35.Z * 1
		v38:AdjustWeight((math.clamp(v39, 0.01, 1)))
		local v40 = v_u_16.L
		local v41 = -v35.X * 1
		v40:AdjustWeight((math.clamp(v41, 0.01, 1)))
		local v42 = v_u_16.R
		local v43 = v35.X * 1
		v42:AdjustWeight((math.clamp(v43, 0.01, 1)))
		updateRikaTransparency()
	end
end)
script.Parent:GetAttributeChangedSignal("Dead"):Once(function()
	-- upvalues: (copy) v_u_10, (copy) v_u_11, (copy) v_u_2
	local v44 = v_u_10.Yuta.Rika.Desummon
	local v_u_45 = v44:Clone()
	v_u_45.Parent = script.Parent
	v_u_45:Play()
	task.delay(v44.TimeLength, function()
		-- upvalues: (copy) v_u_45
		v_u_45:Destroy()
	end)
	local v46 = v_u_45.Volume
	v_u_11:Play()
	v_u_11:AdjustSpeed(-1.2)
	v_u_11.TimePosition = v_u_11.Length - 0.2
	local v47 = tick()
	repeat
		task.wait()
		local v48 = (tick() - v47) / 0.5
		local v49 = 1 - math.clamp(v48, 0, 0.99)
		v_u_2:ScaleTo(v49)
		v_u_45.Volume = v46 * v49
	until tick() - v47 > 0.5
	v_u_2:Destroy()
end)
local v_u_50 = require(v1.Modules.CameraShaker)
local v_u_60 = {
	["UltimateStart"] = function()
		-- upvalues: (copy) v_u_10
		local v51 = v_u_10.Yuta.Rika.Ultimate.Start
		local v_u_52 = v51:Clone()
		v_u_52.Parent = script.Parent
		v_u_52:Play()
		task.delay(v51.TimeLength, function()
			-- upvalues: (copy) v_u_52
			v_u_52:Destroy()
		end)
		local v53 = v_u_10.Yuta.Rika.Ultimate.Voiceline
		local v_u_54 = v53:Clone()
		v_u_54.Parent = script.Parent
		v_u_54:Play()
		task.delay(v53.TimeLength, function()
			-- upvalues: (copy) v_u_54
			v_u_54:Destroy()
		end)
	end,
	["Break"] = function()
		-- upvalues: (copy) v_u_10
		local v55 = v_u_10.Yuta.Rika.Ultimate.Break
		local v_u_56 = v55:Clone()
		v_u_56.Parent = script.Parent
		v_u_56:Play()
		task.delay(v55.TimeLength, function()
			-- upvalues: (copy) v_u_56
			v_u_56:Destroy()
		end)
	end,
	["StartScream"] = function(p57)
		-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_50
		v_u_2.Head.Mouth.Out.Enabled = true
		local v58
		if v_u_7 then
			v_u_50.CurrentShaker:Shake(v_u_50.Presets.HeavyHit)
			v58 = v_u_50.CurrentShaker:ShakeSustain(v_u_50.Presets.LightHit)
		else
			v58 = nil
		end
		repeat
			task.wait(0.2)
		until not p57.Parent
		if v58 then
			v58:StartFadeOut(1)
		end
		v_u_2.Head.Mouth.Out.Enabled = false
	end,
	["Teleport"] = function(p59)
		-- upvalues: (copy) v_u_3
		v_u_3.CFrame = p59 or script.Parent.CFrame
	end
}
v8.OnClientEvent:Connect(function(p61, ...)
	-- upvalues: (copy) v_u_60
	local v62 = v_u_60[p61]
	if v62 then
		v62(...)
	end
end)
if v_u_7 then
	local v_u_63 = script:WaitForChild("Remote")
	local v_u_64 = v4:WaitForChild("Humanoid")
	v_u_64:GetPropertyChangedSignal("MoveDirection"):Connect(function()
		-- upvalues: (copy) v_u_63, (copy) v_u_64
		v_u_63:FireServer(v_u_64.MoveDirection)
	end)
end