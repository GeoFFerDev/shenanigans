-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v_u_7 = v6.Animations
local v_u_8 = v6.Utils
local v_u_9 = v6.Sounds
local v_u_10 = require(v6.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "InfiniteVoidController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_9, (copy) v_u_5, (copy) v_u_7, (copy) v_u_8, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (copy) v_u_10, (ref) v_u_11
	local v_u_44 = {
		["Startup"] = function(p14)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.Voice, v15, game.SoundService.Voice)
				v_u_12:DomainBurst(v15)
				local v16 = v_u_5.Character
				if v16 and v16:FindFirstChild("HumanoidRootPart") then
					local v17 = v16:FindFirstChild("HumanoidRootPart")
					if (v15.Position - v17.Position).Magnitude <= 37.5 then
						v_u_12:Domain(p14, function(p18, p19)
							-- upvalues: (ref) v_u_7
							p19.Humanoid:LoadAnimation(v_u_7.Gojo.DomainWarn):Play(0)
							p18.Panel.ImageLabel.Image = "rbxassetid://14591918380"
							p18.Panel.ImageLabel.Size = UDim2.new(0.8, 0, 0.4, 0)
						end)
					end
				end
			end
		end,
		["Opening"] = function(p20, p21, p_u_22, p23)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_9, (ref) v_u_2, (ref) v_u_10
			local v_u_24 = v_u_8.Gojo.InfiniteVoid.DomainTravel:Clone()
			v_u_24.CFrame = p20.CFrame
			v_u_24.Lines.CFrame = p20.CFrame
			v_u_24.Parent = p20
			local v_u_25 = v_u_8.Gojo.InfiniteVoid.DomainBG:Clone()
			v_u_25.CFrame = p20.CFrame
			task.spawn(function()
				-- upvalues: (copy) p_u_22, (copy) v_u_25, (copy) v_u_24
				repeat
					task.wait()
				until not (p_u_22.Parent and (p_u_22.Parent.Parent and p_u_22.Parent.Parent.Parent))
				v_u_25:Destroy()
				v_u_24:Destroy()
			end)
			if p23 then
				v_u_24.Transparency = 1
				v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.InfiniteVoid, workspace, game.SoundService.Effect).TimePosition = 1.5
			else
				local v_u_26 = p21.DomainGround
				v_u_26.Surround.Enabled = true
				v_u_4:Create(v_u_26.Surround, TweenInfo.new(0.8), {
					["ShapePartial"] = 1
				}):Play()
				v_u_3:AddItem(v_u_26, 2)
				v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.InfiniteVoid, workspace, game.SoundService.Effect)
				task.delay(0.8, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_26, (ref) v_u_12
					v_u_4:Create(v_u_26, TweenInfo.new(0.4), {
						["Transparency"] = 0
					}):Play()
					v_u_12:DomainMapFade(Color3.new(1, 1, 1), 0.4, 1.6)
				end)
				task.wait(1.5)
				v_u_24.Dissolve:Emit(100)
				v_u_24.Dissolve.Enabled = true
				v_u_4:Create(v_u_24, TweenInfo.new(0.2), {
					["Transparency"] = 1
				}):Play()
				v_u_4:Create(v_u_24.Dissolve, TweenInfo.new(0.5), {
					["ShapePartial"] = 0,
					["Rate"] = 50
				}):Play()
				task.delay(0.5, function()
					-- upvalues: (copy) v_u_24
					v_u_24.Dissolve.Enabled = false
				end)
			end
			local v_u_27 = v_u_24.Lines
			v_u_24.SpaceBG.Enabled = true
			v_u_3:AddItem(v_u_24, 2.4)
			local v_u_28 = nil
			v_u_28 = v_u_2.RenderStepped:Connect(function()
				-- upvalues: (copy) v_u_27, (ref) v_u_28
				if v_u_27.Parent then
					v_u_27.Position = (workspace.CurrentCamera.CFrame * CFrame.new(0, 0, -5)).Position
				else
					v_u_28:Disconnect()
				end
			end)
			if p_u_22 and p_u_22.Parent then
				local v_u_29 = v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.Music, workspace, game.SoundService.Music, true)
				game.SoundService.AmbientReverb = Enum.ReverbType.Arena
				task.spawn(function()
					-- upvalues: (copy) p_u_22, (ref) v_u_4, (copy) v_u_29, (ref) v_u_3
					repeat
						task.wait()
					until not (p_u_22.Parent and (p_u_22.Parent.Parent and p_u_22.Parent.Parent.Parent))
					game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
					v_u_4:Create(v_u_29, TweenInfo.new(2), {
						["Volume"] = 0
					}):Play()
					v_u_3:AddItem(v_u_29, 2)
				end)
				v_u_10.CurrentShaker:ShakeOnce(5, 25, 2.4, 0.5, Vector3.new(0.5, 0.5, 0), Vector3.new(0, 0, 0))
				v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(2.3, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
					["FieldOfView"] = 120
				}):Play()
				task.delay(2.4, function()
					-- upvalues: (ref) v_u_4
					workspace.CurrentCamera.FieldOfView = 0
					v_u_4:Create(workspace.CurrentCamera, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["FieldOfView"] = 70
					}):Play()
				end)
				task.delay(1, function()
					-- upvalues: (ref) v_u_4, (ref) v_u_3
					local v30 = Instance.new("ColorCorrectionEffect", game.Lighting)
					v_u_4:Create(v30, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Contrast"] = 3,
						["Brightness"] = 0.5
					}):Play()
					task.wait(1)
					v_u_4:Create(v30, TweenInfo.new(0.3), {
						["Contrast"] = 3.5,
						["Brightness"] = 4
					}):Play()
					task.wait(0.4)
					v30.Contrast = 0
					v_u_4:Create(v30, TweenInfo.new(0.4), {
						["Brightness"] = 0
					}):Play()
					v_u_3:AddItem(v30, 0.5)
				end)
				task.wait(2.4)
				if p_u_22 and p_u_22.Parent then
					v_u_25.Parent = p20
					v_u_25.Splatter1:Emit(70)
					v_u_25.Splatter2:Emit(70)
					v_u_25.Smoke1:Emit(20)
					local v_u_31 = nil
					v_u_31 = v_u_2.RenderStepped:Connect(function()
						-- upvalues: (copy) v_u_25, (ref) v_u_31
						if v_u_25.Parent then
							v_u_25.Position = workspace.CurrentCamera.CFrame.Position
						else
							v_u_31:Disconnect()
						end
					end)
				end
			else
				return
			end
		end,
		["Shatter"] = function(p32)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_12, (ref) v_u_9, (ref) v_u_4
			local v33 = v_u_8.Domain:Clone()
			v33.Transparency = 1
			v33.CanCollide = false
			v33.Position = p32
			v33.Parent = workspace.Effects
			v_u_3:AddItem(v33, 3)
			for _, v34 in v33:GetChildren() do
				if v34.Name == "Shatter" then
					v34:Emit(100)
				else
					v34:Destroy()
				end
			end
			v_u_12:PlaySound(v_u_9.Gojo.InfiniteVoid.Shatter, v33, game.SoundService.Effect)
			v33.Transparency = 0
			v_u_4:Create(v33, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v33.Position).Magnitude > 150 then
					return
				end
				local v35 = Random.new()
				local v36 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v37 = v_u_8.Gojo.Shard:Clone()
					local v38 = v35:NextUnitVector().Unit
					local v39 = math.random(1, 8)
					local v40 = math.random
					v37.Size = Vector3.new(0.1, v39, v40(1, 8))
					v37.CFrame = CFrame.lookAlong(p32, v38) * CFrame.Angles(1.5707963267948966, 0, 0) + v38 * 37.5
					v37.CFrame = v37.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v37.CanCollide = true
					v37.CollisionGroup = "Effects"
					v37.Parent = workspace.Effects
					local v41 = math.random(-50, 50)
					local v42 = math.random(-50, 50)
					local v43 = math.random
					v37.RotVelocity = Vector3.new(v41, v42, v43(-50, 50))
					v37.Transparency = 0
					v37.Material = Enum.Material.Neon
					v_u_4:Create(v37, v36, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_3:AddItem(v37, 4)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p45, ...)
		-- upvalues: (copy) v_u_44
		local v46 = v_u_44[p45]
		if v46 then
			v46(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("InfiniteVoidService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13