-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 1,
	["SortOrder"] = 2,
	["Val"] = "Shadows",
	["Desc"] = "Render shadows globally",
	["Callback"] = function(p1)
		game.Lighting.GlobalShadows = p1
	end
}