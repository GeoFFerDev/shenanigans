-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("ReplicatedStorage")
local v_u_1 = game:GetService("UserInputService")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("SoundService")
local v_u_4 = game:GetService("Players").LocalPlayer
local v_u_5 = script
local v_u_6 = Random.new()
return function(_, p_u_7, p8, p9)
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_2, (copy) v_u_6, (copy) v_u_3, (copy) v_u_1
	local v_u_10 = p9 or {}
	local v_u_11 = v_u_5.UI:Clone()
	if v_u_10.UI_Size then
		v_u_11.Bar.Size = v_u_10.UI_Size
	end
	v_u_11.Parent = v_u_4.PlayerGui
	v_u_2:Create(v_u_11.Bar, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
		["ImageTransparency"] = 0,
		["BackgroundTransparency"] = 0
	}):Play()
	v_u_2:Create(v_u_11.Bar.UIStroke, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
		["Transparency"] = 0
	}):Play()
	v_u_2:Create(v_u_11.Bar.Line, TweenInfo.new(0.1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
		["BackgroundTransparency"] = 0
	}):Play()
	v_u_2:Create(v_u_11.Bar.Line.UIStroke, TweenInfo.new(0.1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
		["Transparency"] = 0
	}):Play()
	local v12 = v_u_10.AttackTime or v_u_6:NextNumber(0.7, 1)
	local v_u_13 = v_u_10.MinRange or v12 / 2.2
	local v_u_14 = v_u_10.MaxRange or v12 / 1.8
	local v_u_15 = time()
	local v_u_16 = v_u_2:Create(v_u_11.Bar.Line, TweenInfo.new(v12, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
		["Position"] = UDim2.fromScale(1, 0.489)
	})
	local v_u_17 = {}
	local function v_u_20()
		-- upvalues: (copy) v_u_17, (copy) v_u_11, (ref) v_u_2
		for _, v18 in v_u_17 do
			v18:Disconnect()
		end
		if v_u_17[1] and (v_u_11 and v_u_11.Parent) then
			local v19 = TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
			v_u_2:Create(v_u_11.Bar, v19, {
				["ImageTransparency"] = 1,
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_2:Create(v_u_11.Bar.UIStroke, v19, {
				["Transparency"] = 1
			}):Play()
			v_u_2:Create(v_u_11.Bar.Line, v19, {
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_2:Create(v_u_11.Bar.Line.UIStroke, v19, {
				["Transparency"] = 1
			}):Play()
			task.delay(v19.Time, v_u_11.Destroy, v_u_11)
		end
		table.clear(v_u_17)
	end
	p8:Task(v_u_20)
	local function v_u_24()
		-- upvalues: (copy) v_u_20, (copy) v_u_16, (copy) v_u_11, (copy) v_u_15, (copy) v_u_13, (copy) v_u_14, (ref) v_u_2, (ref) v_u_3, (ref) v_u_5, (copy) v_u_10, (copy) p_u_7
		v_u_20()
		v_u_16:Pause()
		if v_u_11 == nil or v_u_11.Parent == nil then
			return
		else
			local v21 = time() - v_u_15
			local v22
			if v_u_13 < v21 then
				v22 = v21 < v_u_14
			else
				v22 = false
			end
			if v22 then
				v_u_2:Create(v_u_11.Bar, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, true), {
					["Size"] = v_u_11.Bar.Size + UDim2.fromScale(0.0085, 0.0085)
				}):Play()
				v_u_3:PlayLocalSound(v_u_5.UI_SFX.Success)
				v_u_11.Bar.Line.BackgroundColor3 = Color3.fromRGB(0, 255, 0)
			else
				v_u_3:PlayLocalSound(v_u_5.UI_SFX.Miss)
				v_u_11.Bar.Line.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
			end
			local v23 = v_u_11.Bar.Line
			v23.Size = v23.Size + UDim2.fromScale(0.01, 0.1)
			v_u_2:Create(v_u_11.Bar.Line, TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
				["BackgroundTransparency"] = 1,
				["Size"] = UDim2.fromScale(0, 0)
			}):Play()
			v_u_2:Create(v_u_11.Bar.Line.UIStroke, TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
				["Transparency"] = 1
			}):Play()
			if v_u_10.RemoteFire then
				task.spawn(v_u_10.RemoteFire, v22)
			else
				p_u_7:FireServer(v22)
			end
		end
	end
	local v25 = v_u_1.InputBegan
	table.insert(v_u_17, v25:Connect(function(p26)
		-- upvalues: (copy) v_u_24
		if p26.KeyCode == Enum.KeyCode.Four or (p26.KeyCode == Enum.KeyCode.ButtonR1 or p26.UserInputType == Enum.UserInputType.MouseButton1) then
			v_u_24()
		end
	end))
	local v27 = v_u_11.Bar.Hitbox.Activated
	table.insert(v_u_17, v27:Connect(v_u_24))
	task.delay(v12, v_u_20)
	v_u_16:Play()
	v_u_3:PlayLocalSound(v_u_5.UI_SFX.Appear)
end