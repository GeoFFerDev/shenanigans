-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game.Players.LocalPlayer
local v7 = game.ReplicatedStorage
local _ = v7.Animations
local v_u_8 = v7.Utils
local v_u_9 = v7.Sounds
local v_u_10 = require(v7.Modules.CameraShaker)
local v_u_11 = require(v7.Modules.BloodyZee)
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v15 = v_u_1.CreateController({
	["Name"] = "FinalJudgementController"
})
function v15.KnitStart(_)
	-- upvalues: (ref) v_u_14, (copy) v_u_9, (copy) v_u_6, (copy) v_u_10, (copy) v_u_5, (copy) v_u_3, (copy) v_u_8, (copy) v_u_4, (copy) v_u_11, (ref) v_u_13, (copy) v_u_2, (ref) v_u_12
	local v_u_76 = {
		["Charge"] = function(p16)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v17 = p16:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_14:Flash(p16, Color3.fromRGB(85, 255, 127), 1)
				v_u_14:PlaySound(v_u_9.Hakari.OverLuck.Charge, v17, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p18, p19)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_6, (ref) v_u_10, (ref) v_u_5, (ref) v_u_3
			local v20 = p18:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = v_u_14:PlaySound(v_u_9.Hiromi.Sprint, v20, game.SoundService.Effect)
				if v_u_6.Character == p18 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					local v_u_22 = Instance.new("NumberValue", p19)
					v_u_22.Value = 0
					v_u_5:Create(v_u_22, TweenInfo.new(1), {
						["Value"] = 65
					}):Play()
					p19:GetAttributeChangedSignal("Swing"):Connect(function()
						-- upvalues: (ref) v_u_5, (copy) v_u_22
						v_u_5:Create(v_u_22, TweenInfo.new(0.4, Enum.EasingStyle.Circular, Enum.EasingDirection.InOut), {
							["Value"] = 0
						}):Play()
					end)
					repeat
						p19.Velocity = v20.CFrame.LookVector * v_u_22.Value
						v_u_3.Stepped:Wait()
					until not (p19.Parent and v20.Parent)
					if v21 and v21.Playing then
						v21:Destroy()
					end
				end
			end
		end,
		["Swing"] = function(p23)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				v_u_14:PlaySound(v_u_9.Hiromi.Swing, v24, game.SoundService.Effect)
			end
		end,
		["Dodge"] = function(p25)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v26 = p25:FindFirstChild("HumanoidRootPart")
			if v26 then
				v_u_14:PlaySound(v_u_9.Hiromi.Dodges, v26, game.SoundService.Effect)
			end
		end,
		["Miss"] = function(p27)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_14, (ref) v_u_9
			local v28 = p27:FindFirstChild("HumanoidRootPart")
			if v28 then
				local v29 = v_u_8.Damage.HitGlow:Clone()
				if p27:GetScale() ~= 1 then
					v29:ScaleTo(p27:GetScale())
				end
				v29.Parent = workspace.Effects
				v_u_4:AddItem(v29, 0.5)
				for _, v30 in v29:GetChildren() do
					local v31 = p27:FindFirstChild(v30.Name)
					if v31 then
						v30.CFrame = v31.CFrame
					end
					v30.Color = Color3.new(0, 0, 0)
					v30.Anchored = true
					v_u_5:Create(v30, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
				v_u_14:PlaySound(v_u_9.Itadori.ManjiKick.Dodge, v28, game.SoundService.Effect)
			end
		end,
		["Parry"] = function(p32)
			-- upvalues: (ref) v_u_9, (ref) v_u_14, (ref) v_u_8, (ref) v_u_4, (ref) v_u_10
			local v33 = p32:FindFirstChild("HumanoidRootPart")
			if v33 then
				local v34 = v_u_9.Misc.Block["Block" .. math.random(1, 3)]
				v34.Pitch = math.random(90, 110) / 100
				v_u_14:PlaySound(v34, v33, game.SoundService.Effect)
				local v35 = v_u_8.Damage.BlockHit:Clone()
				v35.Parent = p32.Torso
				v35:Emit(1)
				v_u_4:AddItem(v35, 0.3)
				if (workspace.CurrentCamera.CFrame.Position - v33.Position).Magnitude < 70 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["Hit"] = function(p36)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_10
			local v37 = p36:FindFirstChild("HumanoidRootPart")
			if v37 then
				v_u_14:Flash(p36, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_9.Itadori.M1:FindFirstChild("Hit" .. math.random(1, 4)), v37, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v37.Position).Magnitude < 70 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
				end
			end
		end,
		["Grab"] = function(p38)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_10
			local v39 = p38:FindFirstChild("HumanoidRootPart")
			if v39 then
				v_u_14:Flash(p38, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_9.Gojo.LapseBlue.Grab, v39, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v39.Position).Magnitude < 70 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
			end
		end,
		["Charged"] = function(p40)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4
			local v41 = p40:FindFirstChild("HumanoidRootPart")
			if v41 then
				local v42 = p40.SetAssets:FindFirstChild("ExecSword")
				if v42 then
					v_u_14:PlaySound(v_u_9.Hiromi.Execution.Flash, v41, game.SoundService.Effect)
					local v43 = v_u_8.Hiromi.SwordBuild.ChargeEmit:Clone()
					v_u_4:AddItem(v43, 1)
					v43.Parent = v42
					for _, v44 in v43:GetChildren() do
						v44:Emit(v44:GetAttribute("EmitCount"))
					end
				end
			else
				return
			end
		end,
		["RealHit"] = function(_, p45)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_11, (ref) v_u_10
			local v46 = p45:FindFirstChild("HumanoidRootPart")
			if v46 then
				v_u_14:Flash(p45, Color3.new(1, 1, 0.498039), 1)
				v_u_14:PlaySound(v_u_9.Hiromi.Stab, v46, game.SoundService.Effect)
				for _ = 1, 40 do
					v_u_11:Blood(p45.Torso.CFrame, math.random(-150, -5), 25, 25)
				end
				if (workspace.CurrentCamera.CFrame.Position - v46.Position).Magnitude < 70 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.SnapOh)
				end
			end
		end,
		["Drag"] = function(p47)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_11
			local v48 = p47:FindFirstChild("HumanoidRootPart")
			if v48 then
				v_u_14:Flash(p47, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_9.Hiromi.SwordPull, v48, game.SoundService.Effect)
				for _ = 1, 8 do
					v_u_11:Blood(p47.Torso.CFrame, math.random(5, 25), 25, 25)
				end
			end
		end,
		["QTE"] = function(p_u_49)
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_5, (ref) v_u_13, (ref) v_u_14, (ref) v_u_9, (ref) v_u_2
			local v_u_50 = v_u_8.Hiromi.QTE:Clone()
			v_u_50.Parent = v_u_6.PlayerGui
			v_u_5:Create(v_u_50.Health, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 0.5
			}):Play()
			v_u_5:Create(v_u_50.Health.Bar1, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 0
			}):Play()
			v_u_5:Create(v_u_50.Health.Bar2, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 0
			}):Play()
			local v_u_51 = {
				Enum.KeyCode.W,
				Enum.KeyCode.A,
				Enum.KeyCode.D,
				Enum.KeyCode.ButtonX,
				Enum.KeyCode.ButtonY,
				Enum.KeyCode.ButtonB
			}
			local v_u_52 = { Enum.KeyCode.W, Enum.KeyCode.A, Enum.KeyCode.D }
			local v_u_53 = {
				{ Enum.KeyCode.ButtonX, "rbxassetid://8981031512" },
				{ Enum.KeyCode.ButtonY, "rbxassetid://8981031340" },
				{ Enum.KeyCode.ButtonB, "rbxassetid://8981032988" }
			}
			local v_u_54 = {
				{ Enum.KeyCode.ButtonX, "rbxassetid://126768975062846" },
				{ Enum.KeyCode.ButtonY, "rbxassetid://140161712330460" },
				{ Enum.KeyCode.ButtonB, "rbxassetid://137275294114393" }
			}
			local v_u_55 = nil
			local function v_u_58()
				-- upvalues: (ref) v_u_13, (ref) v_u_55, (copy) v_u_52, (copy) v_u_50, (copy) v_u_53, (copy) v_u_54
				local v56 = v_u_13.LastInput
				if v56 == "Keyboard" then
					v_u_55 = v_u_52[math.random(1, #v_u_52)]
					v_u_50.QTE_PC.Text = v_u_55.Name
				elseif v56 == "Xbox" or v56 == "Playstation" then
					local v57 = (v56 == "Xbox" and v_u_53 or v_u_54)[math.random(1, #v_u_53)]
					v_u_55 = v57[1]
					v_u_50.QTE_CONSOLE.ImageContent = Content.fromUri(v57[2])
				end
			end
			v_u_58()
			v_u_50.QTE_MOBILE.Position = UDim2.new(math.random(20, 70) / 100, 0, math.random(20, 70) / 100, 0)
			v_u_50.QTE_MOBILE.MouseButton1Down:Connect(function()
				-- upvalues: (copy) v_u_50, (ref) v_u_14, (ref) v_u_9, (copy) p_u_49
				v_u_50.QTE_MOBILE.Position = UDim2.new(math.random(20, 70) / 100, 0, math.random(20, 70) / 100, 0)
				v_u_14:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
				p_u_49:FireServer(true)
			end)
			local v61 = v_u_2.InputBegan:Connect(function(p59, p60)
				-- upvalues: (copy) v_u_51, (ref) v_u_55, (copy) p_u_49, (ref) v_u_14, (ref) v_u_9, (copy) v_u_50, (ref) v_u_5, (copy) v_u_58
				if p60 then
					return
				elseif table.find(v_u_51, p59.KeyCode) then
					if p59.KeyCode == v_u_55 then
						p_u_49:FireServer(true)
						v_u_14:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
						v_u_14:PlaySound(v_u_9.Misc.UI.Switch, workspace, game.SoundService.Effect)
						v_u_50.QTE_PC.BackgroundColor3 = Color3.fromRGB(0, 255, 127)
						v_u_50.QTE_PC.Size = UDim2.new(0, 65, 0, 65)
						v_u_5:Create(v_u_50.QTE_PC, TweenInfo.new(0.5), {
							["BackgroundColor3"] = Color3.new(1, 1, 1),
							["Size"] = UDim2.new(0, 75, 0, 75)
						}):Play()
						v_u_50.QTE_CONSOLE.ImageColor3 = Color3.fromRGB(0, 255, 127)
						v_u_50.QTE_CONSOLE.Size = UDim2.new(0, 65, 0, 65)
						v_u_5:Create(v_u_50.QTE_CONSOLE, TweenInfo.new(0.5), {
							["ImageColor3"] = Color3.new(1, 1, 1),
							["Size"] = UDim2.new(0, 75, 0, 75)
						}):Play()
					else
						p_u_49:FireServer()
						v_u_14:PlaySound(v_u_9.Misc.UI.Switch, workspace, game.SoundService.Effect)
						v_u_50.QTE_PC.BackgroundColor3 = Color3.fromRGB(170, 0, 0)
						v_u_50.QTE_PC.Size = UDim2.new(0, 65, 0, 65)
						v_u_5:Create(v_u_50.QTE_PC, TweenInfo.new(0.5), {
							["BackgroundColor3"] = Color3.new(1, 1, 1),
							["Size"] = UDim2.new(0, 75, 0, 75)
						}):Play()
						v_u_50.QTE_CONSOLE.ImageColor3 = Color3.fromRGB(170, 0, 0)
						v_u_50.QTE_CONSOLE.Size = UDim2.new(0, 65, 0, 65)
						v_u_5:Create(v_u_50.QTE_CONSOLE, TweenInfo.new(0.5), {
							["ImageColor3"] = Color3.new(1, 1, 1),
							["Size"] = UDim2.new(0, 75, 0, 75)
						}):Play()
					end
					v_u_58()
				end
			end)
			repeat
				task.wait()
			until not p_u_49.Parent
			v_u_50:Destroy()
			if v61 then
				v61:Disconnect()
			end
		end,
		["QTE2"] = function(p62, p63)
			-- upvalues: (ref) v_u_6
			local v64 = v_u_6.PlayerGui:FindFirstChild("QTE")
			if v64 then
				local v65
				if p62 < 0 then
					v65 = 1 / math.abs(p62)
				else
					v65 = p62 == 0 and 1 or p62
				end
				local v66
				if p63 < 0 then
					v66 = 1 / math.abs(p63)
				else
					v66 = p63 == 0 and 1 or p63
				end
				local v67 = v65 + v66
				v64.Health.Bar1.Size = UDim2.new(v65 / v67, 0, 1, 0)
			end
		end,
		["Haiyah"] = function(p68, p69)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9, (ref) v_u_6, (ref) v_u_10
			local v70 = p69:FindFirstChild("HumanoidRootPart")
			if v70 then
				local v71 = v_u_8.Mahito.CrushingRushdown.DrillImpact:Clone()
				v71.Position = v70.Position
				v71.Parent = workspace.Effects
				v_u_4:AddItem(v71, 1)
				v71.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v71.Wind.Color = v71.Sparks.Color
				v71.Wind2.Color = v71.Sparks.Color
				v71.Sparks:Emit(50)
				v71.Wind:Emit(7)
				v71.Wind2:Emit(7)
				v_u_14:Flash(p69, Color3.new(1, 1, 1))
				v_u_14:PlaySound(v_u_9.Hakari.EnergySurge.Hit1, v70, game.SoundService.Effect)
				if v_u_6 == p68 or v_u_6.Character == p69 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				end
			end
		end,
		["Feint"] = function(p72)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4
			local v73 = p72:FindFirstChild("HumanoidRootPart")
			if v73 then
				v_u_14:PlaySound(v_u_9.Hiromi.Grapple.Start, v73, game.SoundService.Effect)
				local v74 = v_u_8.Itadori.CounterHit.Feint:Clone()
				for _, v75 in v74:GetChildren() do
					v75.Color = ColorSequence.new(Color3.fromRGB(255, 195, 134))
					v75.TimeScale = 0.75
				end
				v74.Parent = v73
				v74.Sparks:Emit(10)
				v74.Ring:Emit(3)
				v_u_4:AddItem(v74, 1)
			end
		end
	}
	v_u_12.Effects:Connect(function(p77, ...)
		-- upvalues: (copy) v_u_76
		local v78 = v_u_76[p77]
		if v78 then
			v78(...)
		end
	end)
end
function v15.KnitInit(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14
	v_u_12 = v_u_1.GetService("FinalJudgementService")
	v_u_13 = v_u_1.GetController("ToolController")
	v_u_14 = v_u_1.GetController("FXController")
end
return v15