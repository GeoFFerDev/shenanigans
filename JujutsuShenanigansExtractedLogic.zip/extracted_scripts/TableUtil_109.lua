-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return require(script.Parent._Index["sleitnick_table-util@1.2.1"]["table-util"])