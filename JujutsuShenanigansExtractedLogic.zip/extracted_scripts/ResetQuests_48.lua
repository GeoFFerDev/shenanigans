-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "resetquests",
	["Description"] = "Removes all data of player\'s quests",
	["Group"] = {
		"Owner",
		"Developer",
		"Tester",
		"HeadMod",
		"Mod"
	},
	["Args"] = {
		{
			["Type"] = "player",
			["Name"] = "Player"
		}
	}
}
return v1