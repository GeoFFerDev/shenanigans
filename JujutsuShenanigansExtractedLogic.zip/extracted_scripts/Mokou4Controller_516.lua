-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game.Players.LocalPlayer
local v7 = game.ReplicatedStorage
local _ = v7.Animations
local v_u_8 = v7.Utils
local v_u_9 = v7.Sounds
require(v7.Modules.CameraShaker)
require(v7.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "Mokou4Controller"
})
function v14.KnitStart(_)
	-- upvalues: (copy) v_u_6, (ref) v_u_11, (copy) v_u_9, (ref) v_u_13, (copy) v_u_2, (copy) v_u_8, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5, (ref) v_u_10
	local v_u_44 = {
		["Startup"] = function(p15, p16)
			-- upvalues: (ref) v_u_6, (ref) v_u_11, (ref) v_u_9, (ref) v_u_13, (ref) v_u_2
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if not v17 then
				return
			end
			local v18 = RaycastParams.new()
			v18.FilterType = Enum.RaycastFilterType.Include
			v18.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
			for _, v19 in workspace.Characters:GetChildren() do
				if v19 ~= v_u_6.Character then
					local v20 = v18.FilterDescendantsInstances
					table.insert(v20, v19)
				end
			end
			v_u_11:PlaySound(v_u_9.Misc.M.Charm, v17, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_9.Misc.M.Mokou4Voice, v17, game.SoundService.Voice)
			while true do
				local v21 = v_u_13:GetTarget(100)
				if v21 then
					p16:FireServer(v21)
				else
					local v22 = v_u_2:GetMouseLocation()
					local v23 = workspace.CurrentCamera:ViewportPointToRay(v22.X, v22.Y)
					local v24 = workspace:Raycast(v23.Origin, v23.Direction * 300, v18)
					local v25
					if v24 then
						v25 = v24.Position
					else
						v25 = v23.Origin + v23.Direction * 300
					end
					p16:FireServer(v25)
				end
				task.wait(0.02)
				if not p16.Parent then
					return
				end
			end
		end,
		["Barrage"] = function(p26)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_11
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v28 = v_u_8.Misc.M.Barrage:Clone()
				v28.Weld.Part1 = v27
				v28.Parent = workspace.Effects
				v_u_4:AddItem(v28, 2)
				v_u_11:ArmFlash(p26["Left Arm"], Color3.fromRGB(255, 85, 0), 0.5)
				v_u_11:ArmFlash(p26["Right Arm"], Color3.fromRGB(255, 85, 0), 0.5)
				task.wait(0.35)
				v28.Ring.Enabled = false
				v28.Slash2.Enabled = false
				v28.Attachment.Ring:Emit(8)
				v28.Attachment.Dust:Emit(40)
				v28.Attachment.Attachment.Ring:Emit(1)
			end
		end,
		["Interp"] = function(p_u_29, p30)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_5, (ref) v_u_4
			local v_u_31 = v_u_8.Misc.M.Talisman:Clone()
			v_u_31.CFrame = p30 * CFrame.Angles(0, 0, math.random(0, 3.141592653589793))
			v_u_31.Parent = workspace.Effects
			local v_u_32 = tick()
			local v_u_33 = false
			local v_u_34 = false
			local v_u_35 = nil
			v_u_35 = v_u_3.Stepped:Connect(function(_, p36)
				-- upvalues: (copy) p_u_29, (ref) v_u_33, (copy) v_u_32, (ref) v_u_34, (copy) v_u_31, (ref) v_u_5, (ref) v_u_4, (ref) v_u_35
				if p_u_29.Parent and (v_u_33 ~= true and tick() - v_u_32 <= 0.4) then
					local v37 = 200 * p36
					local v38 = workspace:Raycast(v_u_31.Position, v_u_31.CFrame.LookVector * v37, _G.MapParams)
					if v38 then
						v_u_34 = true
						v_u_31.Position = v38.Position
						v_u_33 = true
					else
						local v39 = v_u_31
						v39.CFrame = v39.CFrame + v_u_31.CFrame.LookVector * v37
					end
				else
					if v_u_34 then
						local v40 = TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
						v_u_5:Create(v_u_31, v40, {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_5:Create(v_u_31.Flames, v40, {
							["Rate"] = 0
						}):Play()
						v_u_4:AddItem(v_u_31, 1.5)
					else
						v_u_31:Destroy()
					end
					v_u_35:Disconnect()
					return
				end
			end)
		end,
		["Hit"] = function(p41)
			-- upvalues: (ref) v_u_11, (ref) v_u_9, (ref) v_u_8, (ref) v_u_5, (ref) v_u_4
			local v42 = p41:FindFirstChild("HumanoidRootPart")
			if v42 then
				v_u_11:Flash(p41, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_9.Misc.M.M1:FindFirstChild("Hit" .. math.random(1, 4)), v42, game.SoundService.Effect)
				local v43 = v_u_8.Misc.M.Hit:Clone()
				v43.CFrame = v42.CFrame * CFrame.new(math.random(-30, 30) / 10, math.random(-30, 30) / 10, math.random(-30, 30) / 10)
				v43.Parent = workspace.Effects
				v43.Sparks:Emit(20)
				v_u_5:Create(v43, TweenInfo.new(0.15), {
					["Size"] = Vector3.new(7, 7, 7),
					["Transparency"] = 1,
					["Color"] = Color3.new(1, 0.333333, 0)
				}):Play()
				v_u_4:AddItem(v43, 0.6)
			end
		end
	}
	v_u_10.Effects:Connect(function(p45, ...)
		-- upvalues: (copy) v_u_44
		local v46 = v_u_44[p45]
		if v46 then
			v46(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
	v_u_10 = v_u_1.GetService("Mokou4Service")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("ToolController")
end
return v14