-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 3,
	["SortOrder"] = 3,
	["Val"] = "VolMS2",
	["Desc"] = "Change the volume for background music",
	["Max"] = 2,
	["Callback"] = function(p1)
		game.SoundService.Music2.Volume = p1
	end
}