-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = require(v_u_6.Modules.BloodyZee)
local v_u_11 = require(v_u_6.Modules.SraikoVFX)
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Include
v_u_12.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v16 = v_u_1.CreateController({
	["Name"] = "BluntCutController"
})
function v16.KnitStart(_)
	-- upvalues: (ref) v_u_14, (copy) v_u_8, (copy) v_u_5, (copy) v_u_9, (copy) v_u_10, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_12, (copy) v_u_11, (copy) v_u_2, (copy) v_u_6, (ref) v_u_13, (ref) v_u_15
	local v_u_113 = {
		["Start"] = function(p17)
			-- upvalues: (ref) v_u_14, (ref) v_u_8
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_14:PlaySound(v_u_8.Nanami.BluntCut.Start, v18, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p19, p20, p21, p22)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_10, (ref) v_u_14, (ref) v_u_8
			if p19:FindFirstChild("HumanoidRootPart") then
				local v23 = p20:FindFirstChild("HumanoidRootPart")
				if v23 then
					if v_u_5.Character == p19 or v_u_5.Character == p20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
					if p21 then
						for _ = 1, 10 do
							v_u_10:Blood(CFrame.lookAt(v23.Position, p22) * CFrame.Angles(0, 3.141592653589793, 0), math.random(40, 125), 25, 25)
						end
					end
					v_u_14:Flash(p20, Color3.new(1, 1, 1))
					v_u_14:PlaySound(p21 and v_u_8.Nanami.BluntCut.RatioHit or v_u_8.Nanami.BluntCut.Hit, v23, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Charge"] = function(p24, p_u_25)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_14, (ref) v_u_8, (ref) v_u_4, (ref) v_u_12, (ref) v_u_11
			local v26 = p24:FindFirstChild("HumanoidRootPart")
			if not v26 then
				return
			end
			local v27 = v_u_7.Nanami.BluntCut.Charge.Strike:Clone()
			v27.Parent = workspace.Effects
			v27.CFrame = v26.CFrame
			v27.Weld.Part0 = v26
			v_u_3:AddItem(v27, 3)
			local v28 = v_u_14:PlaySound(v_u_8.Nanami.BluntCut.Charge, v26, game.SoundService.Effect)
			for _, v_u_29 in pairs(v27:GetDescendants()) do
				if v_u_29:IsA("Beam") then
					task.spawn(function()
						-- upvalues: (copy) v_u_29, (ref) v_u_4, (copy) p_u_25
						v_u_29.Enabled = true
						local v30 = v_u_29
						v_u_29.Width0 = 0
						v30.Width1 = 0
						v_u_29.CurveSize0 = 0
						v_u_29.CurveSize1 = 0
						local v31 = v_u_29.Attachment0
						v31.Position = v31.Position * 0.5
						local v32 = v_u_29.Attachment1
						v32.Position = v32.Position * 0.5
						local v33 = v_u_29.Attachment0.Name == "A1" and -5 or 5
						local v34 = v_u_29.Attachment1.Name == "A2" and 5 or -5
						local v35 = v_u_29.Attachment0.Name == "A1" and 4 or -4
						local v36 = v_u_4:Create(v_u_29, TweenInfo.new(0.6), {
							["Width0"] = 4,
							["Width1"] = 4,
							["CurveSize0"] = v33,
							["CurveSize1"] = v34
						})
						v36:Play()
						local v37 = v_u_4:Create(v_u_29.Attachment0, TweenInfo.new(0.6), {
							["Position"] = Vector3.new(v35, 0, 0)
						})
						v37:Play()
						local v38 = v_u_4
						local v39 = v_u_29.Attachment1
						local v40 = TweenInfo.new(0.6)
						local v41 = {}
						local v42 = -v35
						v41.Position = Vector3.new(v42, 0, 0)
						local v43 = v38:Create(v39, v40, v41)
						v43:Play()
						repeat
							task.wait()
						until p_u_25.Parent == nil or p_u_25.Value == true
						v36:Cancel()
						v37:Cancel()
						v43:Cancel()
						if not p_u_25.Value then
							v_u_4:Create(v_u_29, TweenInfo.new(0.125), {
								["Width0"] = 0,
								["Width1"] = 0
							}):Play()
						end
					end)
				end
			end
			local v44 = tick() - 0.19
			local v45 = 0
			while true do
				task.wait()
				if tick() - v44 >= 0.2 then
					v44 = tick()
					v45 = v45 + 0.35
					local v46 = workspace:Raycast(v26.Position, Vector3.new(-0, -7.5, -0), v_u_12)
					if v46 then
						for _, v47 in pairs(v_u_7.Nanami.BluntCut.Charge:GetChildren()) do
							if v47:IsA("Model") then
								local v48 = v47:Clone()
								v48:ScaleTo(v45)
								local v49 = v_u_11.HandleMesh(v48, CFrame.new(v46.Position, v46.Position + v46.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
								v48.Parent = workspace.Effects
								v_u_3:AddItem(v48, v49)
							end
						end
					end
				end
				if p_u_25.Parent == nil or p_u_25.Value == true then
					v28:Stop()
					if p_u_25.Parent == nil then
						v_u_3:AddItem(v27, 0.125)
					else
						v_u_14:PlaySound(v_u_8.Nanami.BluntCut.ChargeFinish, v26, game.SoundService.Effect)
						for _, v_u_50 in pairs(v27:GetDescendants()) do
							if v_u_50:IsA("ParticleEmitter") then
								v_u_50:Emit(v_u_50:GetAttribute("EmitCount"))
							elseif v_u_50:IsA("Beam") then
								v_u_50.Enabled = true
								v_u_4:Create(v_u_50, TweenInfo.new(0.4), {
									["Width0"] = 0,
									["Width1"] = 0
								}):Play()
								task.delay(0.5, function()
									-- upvalues: (copy) v_u_50
									v_u_50.Enabled = false
									v_u_50.Width0 = 15
									v_u_50.Width1 = 15
								end)
							end
						end
						local v51 = workspace:Raycast(v26.Position, Vector3.new(-0, -7.5, -0), v_u_12)
						if v51 then
							for _, v52 in pairs(v_u_7.Nanami.BluntCut.Charge:GetChildren()) do
								if v52:IsA("Model") then
									local v53 = v52:Clone()
									local v54 = v_u_11.HandleMesh(v53, CFrame.new(v51.Position, v51.Position + v51.Normal) * CFrame.Angles(-1.5707963267948966, 0, 0))
									v53.Parent = workspace.Effects
									v_u_3:AddItem(v53, v54)
								end
							end
						end
					end
				end
			end
		end,
		["Dash"] = function(p55, p56)
			-- upvalues: (ref) v_u_2, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_6, (ref) v_u_14, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v_u_57 = p55.HumanoidRootPart
			if v_u_57 then
				v_u_2.Stepped:Wait()
				local v_u_58 = CFrame.new(p56, v_u_57.Position)
				local v59 = (p56 - v_u_57.Position).Magnitude
				local v60 = v_u_7.Mahito.Dash:Clone()
				v60.CFrame = v_u_58 + v_u_58.LookVector * v59 / 2
				v60.Size = Vector3.new(5, 5, v59)
				v60.Parent = workspace.Effects
				v_u_4:Create(v60, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(0, 0, v59),
					["CFrame"] = v60.CFrame * CFrame.Angles(0, 0, 3.141592653589793)
				}):Play()
				v_u_3:AddItem(v60, 0.2)
				local v61 = Instance.new("Model")
				local v62 = v_u_6.Utils.Itadori.RushWind:Clone()
				v62.CFrame = v_u_57.CFrame * CFrame.new(0, -1, 0)
				v62.Parent = v61
				v61.Parent = workspace.Effects
				v61:ScaleTo(0.6)
				v62.Ring:Emit(7)
				v62.Dash1.Dash:Emit(1)
				v62.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v61, 2)
				local v63 = v_u_7.Itadori.Shock:Clone()
				v63.CFrame = v_u_58 * CFrame.Angles(1.5707963267948966, 0, 0)
				v63.Parent = workspace.Effects
				v_u_4:Create(v63, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(10, 0, 10),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v63, 0.3)
				task.delay(0.075, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_58, (ref) v_u_4, (ref) v_u_3, (copy) v_u_57
					local v64 = v_u_7.Itadori.Shock:Clone()
					v64.CFrame = v_u_58 * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_58.LookVector * 3
					v64.Parent = workspace.Effects
					v_u_4:Create(v64, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v64, 0.2)
					task.wait(0.075)
					local v65 = v_u_7.Itadori.Shock:Clone()
					v65.CFrame = v_u_57.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v65.Parent = workspace.Effects
					v_u_4:Create(v65, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v65, 0.2)
				end)
				v_u_14:PlaySound(v_u_8.Nanami.BluntCut.Dash, v_u_57, game.SoundService.Effect)
				if v_u_5.Character == p55 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Hit2"] = function(p66, p67, p68)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_14, (ref) v_u_8
			if p66:FindFirstChild("HumanoidRootPart") then
				local v69 = p67:FindFirstChild("HumanoidRootPart")
				if v69 then
					if v_u_5.Character == p66 or v_u_5.Character == p67 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
					v_u_14:Flash(p67, Color3.new(0.333333, 0.666667, 1))
					v_u_14:PlaySound(p68 and v_u_8.Nanami.CrossCut.RatioHit or v_u_8.Nanami.CrossCut.Hit1, v69, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Hit3"] = function(p70, p71, p72)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3, (ref) v_u_14, (ref) v_u_8
			if p70:FindFirstChild("HumanoidRootPart") then
				local v73 = p71:FindFirstChild("HumanoidRootPart")
				if v73 then
					if v_u_5.Character == p70 or v_u_5.Character == p71 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.MediumHit)
					end
					local v74 = v_u_7.Gojo.Twofold.Sparks:Clone()
					v74.Parent = v73.RootAttachment
					v74:Emit(20)
					v_u_3:AddItem(v74, 0.4)
					v_u_14:Flash(p71, Color3.new(1, 1, 1))
					v_u_14:PlaySound(p72 and v_u_8.Nanami.CrossCut.RatioHit or v_u_8.Nanami.CrossCut.Hit2, v73, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Swing2"] = function(p75)
			-- upvalues: (ref) v_u_14, (ref) v_u_8
			local v76 = p75:FindFirstChild("HumanoidRootPart")
			if v76 then
				v_u_14:PlaySound(v_u_8.Nanami.CrossCut.Whoosh, v76, game.SoundService.Effect)
			end
		end,
		["Whoosh"] = function(p77)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v78 = p77:FindFirstChild("HumanoidRootPart")
			if v78 then
				local v79 = v_u_7.Todo.Swing:Clone()
				local v80 = Instance.new("Model")
				v79.Parent = v80
				v80:ScaleTo(1.3)
				v_u_3:AddItem(v80, 0.2)
				v79.Weld.C0 = v79.Weld.C0 * CFrame.new(0.5, -1, -0.5) * CFrame.Angles(0, 0, 0.17453292519943295) * CFrame.Angles(0, 0.08726646259971647, 1.1344640137963142)
				v79.Weld.Part0 = v78
				v79.Parent = workspace.Effects
				v_u_3:AddItem(v79, 0.6)
				v79.Core.Wind:Emit(7)
				v_u_4:Create(v79.Weld, TweenInfo.new(0.2), {
					["C1"] = v79.Weld.C1 * CFrame.Angles(0, -3.141592653589793, 0)
				}):Play()
				v_u_4:Create(v79.Beam, TweenInfo.new(0.2), {
					["Width0"] = 0
				}):Play()
			end
		end,
		["Endlag"] = function(p81)
			-- upvalues: (ref) v_u_14, (ref) v_u_8
			local v82 = p81:FindFirstChild("HumanoidRootPart")
			if v82 then
				v_u_14:PlaySound(v_u_8.Nanami.CrossCut.Endlag, v82, game.SoundService.Effect)
			end
		end,
		["Launch"] = function(p83, p84)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v85 = p83:FindFirstChild("HumanoidRootPart")
			if v85 then
				local v86 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v86.CFrame = CFrame.new(v85.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v86.Size = Vector3.new(0, 0, 5)
				v86.Parent = workspace.Effects
				v_u_4:Create(v86, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v86.Position + Vector3.new(0, p84, 0)
				}):Play()
				v_u_3:AddItem(v86, 0.3)
				if p84 < 0 then
					v_u_14:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v85, game.SoundService.Effect)
					v_u_14:DustBreak(v85.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v85.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Leap"] = function(p87, p88)
			-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_5
			local v89 = p87:FindFirstChild("HumanoidRootPart")
			if v89 then
				v_u_14:PlaySound(v_u_8.Nanami.CrossCut.Start, v89, game.SoundService.Effect)
				if p87 == v_u_5.Character then
					p88.Position = v89.Position + Vector3.new(0, 2, 0)
				end
			end
		end,
		["Slam"] = function(p90, p91, p92)
			-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_3, (ref) v_u_14, (ref) v_u_8
			local v93 = p90:FindFirstChild("HumanoidRootPart")
			if v93 then
				local v94 = v_u_7.Nanami.CrossCut.Slam.Cone:Clone()
				local v95 = v_u_11.HandleMesh(v94, CFrame.new(p91, p91 + p92) * CFrame.Angles(-1.5707963267948966, 0, 0))
				v94.Parent = workspace.Effects
				v_u_3:AddItem(v94, v95)
				local v96 = v_u_7.Nanami.CrossCut.Slam.NewSlash:Clone()
				local v97 = v_u_11.HandleMesh(v96, CFrame.new(p91, p91 + p92) * CFrame.Angles(-1.5707963267948966, 0, 0))
				v96.Parent = workspace.Effects
				v_u_3:AddItem(v96, v97)
				v_u_11.Emit(v_u_7.Nanami.CrossCut.Slam.Strike, CFrame.new(p91, p91 + p92) * CFrame.Angles(-1.5707963267948966, 0, 0))
				v_u_14:PlaySound(v_u_8.Nanami.CrossCut.Slam, v93, game.SoundService.Effect)
			end
		end,
		["LaunchDown"] = function(p98, _)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v99 = p98:FindFirstChild("HumanoidRootPart")
			if v99 then
				local v100 = v_u_7.Nanami.CrossCut.Dash.Strike:Clone()
				v100.Parent = workspace.Effects
				v100.Weld.Part0 = v99
				v100.Weld.C0 = CFrame.new(0, -2, 0)
				for _, v_u_101 in pairs(v100:GetDescendants()) do
					if v_u_101:IsA("Beam") then
						v_u_101.Enabled = true
						v_u_4:Create(v_u_101, TweenInfo.new(0.2), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
						task.delay(0.30000000000000004, function()
							-- upvalues: (copy) v_u_101
							v_u_101.Enabled = false
							v_u_101.Width0 = 12
							v_u_101.Width1 = 12
						end)
					end
					if v_u_101:IsA("ParticleEmitter") then
						v_u_101:Emit(v_u_101:GetAttribute("EmitCount"))
					end
				end
				v_u_3:AddItem(v100, 2)
			end
		end,
		["Finisher"] = function(p102, p103)
			-- upvalues: (ref) v_u_5, (ref) v_u_14, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9
			if p102:FindFirstChild("HumanoidRootPart") then
				local v_u_104 = p103:FindFirstChild("HumanoidRootPart")
				if v_u_104 then
					if v_u_5.Character ~= p102 and v_u_5.Character ~= p103 then
						task.delay(0.55, function()
							-- upvalues: (ref) v_u_14, (ref) v_u_8, (copy) v_u_104
							local v105 = v_u_14:PlaySound(v_u_8.Nanami.BluntCut.Finisher, v_u_104, game.SoundService.Effect)
							v105.TimePosition = 0.55
							v105.Volume = 4.5
						end)
					end
					if v_u_5.Character == p102 or v_u_5.Character == p103 then
						v_u_14:PlaySound(v_u_8.Nanami.BluntCut.Finisher, workspace, game.SoundService.Effect)
						local v106 = Instance.new("ScreenGui")
						v106.IgnoreGuiInset = true
						v106.Parent = v_u_5.PlayerGui
						local v107 = Instance.new("Frame")
						v107.BackgroundTransparency = 1
						v107.BackgroundColor3 = Color3.new(0, 0, 0)
						v107.AnchorPoint = Vector2.new(0.5, 0.5)
						v107.Size = UDim2.fromScale(1, 1)
						v107.Position = UDim2.fromScale(0.5, 0.5)
						v107.Parent = v106
						v_u_4:Create(v107, TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), {
							["BackgroundTransparency"] = 0
						}):Play()
						local v108 = Instance.new("ImageLabel")
						v108.BackgroundTransparency = 1
						v108.Image = "rbxassetid://93103077686592"
						v108.ImageTransparency = 1
						v108.ImageColor3 = Color3.fromRGB(150, 0, 0)
						v108.Size = UDim2.fromScale(1, 1)
						v108.AnchorPoint = Vector2.new(0.5, 0.5)
						v108.Position = UDim2.fromScale(0.5, 0.5)
						task.wait(0.15)
						local v109 = game.ReplicatedStorage.Utils.Nanami.Ratio.Bar:Clone()
						v109.Parent = v107
						local _ = v109.Cursor
						v109.Rotation = -180
						v109.Size = UDim2.fromScale(0.16, 2.4)
						v_u_4:Create(v109, TweenInfo.new(0.45, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
							["Rotation"] = 80,
							["Size"] = UDim2.fromScale(0.08, 1.2)
						}):Play()
						task.wait(0.25)
						if _G.Settings.Gore == false then
							v108.ImageColor3 = Color3.fromRGB(255, 85, 255)
							v109.Hit2.ImageColor3 = Color3.fromRGB(255, 85, 255)
						end
						v108.ImageTransparency = 0
						v109.Hit.Visible = true
						v109.Hit.ImageColor3 = Color3.new(0, 0, 0)
						v107.BackgroundColor3 = Color3.new(1, 1, 1)
						v109.Bar.ImageColor3 = Color3.new(0, 0, 0)
						task.wait(0.035)
						v107.BackgroundColor3 = Color3.new(0, 0, 0)
						v109.Bar.ImageColor3 = Color3.new(1, 1, 1)
						v109.Hit.Visible = false
						v109.Hit2.Visible = true
						v109.Hit2.Size = UDim2.fromScale(0.5, 0.1)
						v_u_4:Create(v109.Hit2, TweenInfo.new(0.125, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
							["ImageTransparency"] = 0.15,
							["Size"] = UDim2.fromScale(15, 3)
						}):Play()
						task.wait(0.05)
						v108.Parent = v107
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						task.wait(0.1)
						v106:Destroy()
					end
				end
			else
				return
			end
		end,
		["FinisherBleed"] = function(p110)
			-- upvalues: (ref) v_u_14
			if p110:FindFirstChild("HumanoidRootPart") then
				v_u_14:Bleed(p110)
			end
		end,
		["Finisher2"] = function(p111)
			-- upvalues: (ref) v_u_14, (ref) v_u_8
			local v112 = p111:FindFirstChild("HumanoidRootPart")
			if v112 then
				v_u_14:PlaySound(v_u_8.Yuta.ResoluteHit, v112, game.SoundService.Effect)
				v_u_14:Bleed(p111)
			end
		end
	}
	v_u_13.Effects:Connect(function(p114, ...)
		-- upvalues: (copy) v_u_113
		local v115 = v_u_113[p114]
		if v115 then
			v115(...)
		end
	end)
	v_u_13.Hitbox:Connect(function(p116, p117, p118)
		-- upvalues: (ref) v_u_12, (ref) v_u_15
		local v119 = p117.HumanoidRootPart
		if not v119 then
			return
		end
		while true do
			local v120 = workspace:Raycast((v119.CFrame * CFrame.new(0, 0, -2.5)).Position, p116.Velocity.Unit * 8, v_u_12)
			local v121 = v_u_15:SphereHitbox(p117, CFrame.new(0, -5, -5), 12)
			if v120 then
				local v122
				if v120 then
					v122 = v120.Position
				else
					v122 = v120
				end
				local v123
				if v120 then
					v123 = v120.Normal
				else
					v123 = v120
				end
				p118:FireServer(v121, v122, v123)
				if v120 then
					p116:Destroy()
				end
			end
			task.wait(0.025)
			if not p116.Parent then
				return
			end
		end
	end)
end
function v16.KnitInit(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_1, (ref) v_u_15, (ref) v_u_14
	v_u_13 = v_u_1.GetService("BluntCutService")
	v_u_15 = v_u_1.GetController("HitboxController")
	v_u_14 = v_u_1.GetController("FXController")
end
return v16