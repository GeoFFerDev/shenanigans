-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
local v_u_10 = require(v_u_5.Modules.LightningBeams)
Random.new()
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "CleaveRushController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_5, (copy) v_u_2, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (ref) v_u_11
	local v_u_48 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_12:PlaySound(v_u_7.Heian.CleaveStart, v15, game.SoundService.Voice)
			end
		end,
		["Warn"] = function(p16, p17)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_12:PlaySound(v_u_7.Mahito.Transfig.Eyes, v18, game.SoundService.Effect)
				if p17 then
					v_u_12:PlaySound(v_u_7.Heian.CleaveFlashVoice, v18, game.SoundService.Voice)
				else
					v_u_12:PlaySound(v_u_7.Heian.CleaveVoice, v18, game.SoundService.Voice)
				end
				local v19 = v_u_5.Utils.Itadori.EyeTrails:Clone()
				v19.Weld.Part0 = p16.Head
				v19.Parent = workspace.Effects
				v19.Glow:Emit(1)
				v_u_2:AddItem(v19, 2)
				task.wait(1)
				v19.Trail1.Trail.Enabled = false
				v19.Trail2.Trail.Enabled = false
				v19.Eye1.Glow.Enabled = false
				v19.Eye2.Glow.Enabled = false
			end
		end,
		["Dash"] = function(p20)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v_u_21 = p20:FindFirstChild("HumanoidRootPart")
			if v_u_21 then
				v_u_12:PlaySound(v_u_7.Itadori.Rush.Rush, v_u_21, game.SoundService.Effect)
				local v22 = v_u_5.Utils.Itadori.RushWind:Clone()
				v22.CFrame = v_u_21.CFrame
				v22.Parent = workspace.Effects
				v22.Dust:Emit(7)
				v22.Ring:Emit(7)
				v22.Dash1.Dash:Emit(1)
				v22.Dash2.Dash:Emit(1)
				v_u_2:AddItem(v22, 2)
				for v23 = 1, 5 do
					task.delay(0.075 * v23, function()
						-- upvalues: (ref) v_u_6, (copy) v_u_21, (ref) v_u_3, (ref) v_u_2
						local v24 = v_u_6.Itadori.Shock:Clone()
						v24.CFrame = v_u_21.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
						v24.Parent = workspace.Effects
						v_u_3:Create(v24, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v24, 0.2)
					end)
				end
				if v_u_4.Character == p20 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["CleaveGrab"] = function(p25, p26)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_8
			local v27 = p25:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v28 = p26:FindFirstChild("HumanoidRootPart")
				if v28 then
					v_u_12:Flash(p26, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v28, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_7.Heian.CleaveVoice2, v27, game.SoundService.Voice)
					if (workspace.CurrentCamera.CFrame.Position - v28.Position).Magnitude < 200 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Cleave"] = function(p29)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_12, (ref) v_u_7, (ref) v_u_8
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v_u_31 = v_u_6.Heian.Cleave:Clone()
				v_u_31.Weld.Part1 = v30
				v_u_31.Parent = workspace.Effects
				task.delay(0.35, function()
					-- upvalues: (copy) v_u_31, (ref) v_u_2
					v_u_31.Slashes.Enabled = false
					v_u_31.PointLight:Destroy()
					v_u_2:AddItem(v_u_31, 0.08)
				end)
				v_u_3:Create(v_u_31.PointLight, TweenInfo.new(0.3, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["Brightness"] = 40
				}):Play()
				v_u_3:Create(v_u_31.Slashes, TweenInfo.new(0.3, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["TimeScale"] = 1
				}):Play()
				for _ = 1, 20 do
					v_u_12:PlaySound(v_u_7.Itadori.Dismantle.Slash, v30, game.SoundService.Effect)
					if (workspace.CurrentCamera.CFrame.Position - v30.Position).Magnitude < 200 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					end
					task.wait()
				end
			end
		end,
		["CleaveHit"] = function(p32)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_8, (ref) v_u_2
			local v33 = p32:FindFirstChild("HumanoidRootPart")
			if v33 then
				v_u_12:Flash(p32, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Itadori.Dismantle.Explode, v33, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v33.Position).Magnitude < 200 then
					task.delay(0.1, function()
						-- upvalues: (ref) v_u_6
						local v34 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v34.Parent = game.Lighting
						task.wait(0.05)
						v34.TintColor = Color3.new(1, 1, 1)
						v34.Brightness = 200
						v34.Contrast = -1000
						task.wait(0.05)
						v34:Destroy()
					end)
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
				local v_u_35 = v_u_6.Itadori.Dismantle.Cleave:Clone()
				v_u_35.Weld.Part1 = v33
				v_u_35.Parent = workspace.Effects
				task.delay(0.1, function()
					-- upvalues: (copy) v_u_35, (ref) v_u_2
					v_u_35.Slashes.Enabled = false
					v_u_35.Slash2.Enabled = false
					v_u_35.PointLight:Destroy()
					v_u_2:AddItem(v_u_35, 0.08)
				end)
				v_u_12:PlaySound(v_u_7.Itadori.Dismantle.FinishSlash, v33, game.SoundService.Effect)
				for _ = 1, 10 do
					v_u_35.Slashes:Emit(1)
					v_u_12:PlaySound(v_u_7.Itadori.Dismantle.Slash, v33, game.SoundService.Effect)
					task.wait()
				end
			end
		end,
		["Finisher"] = function(p36)
			-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2
			local v37 = p36:FindFirstChild("HumanoidRootPart")
			if v37 then
				v_u_12:Bleed(p36)
				for _ = 1, 40 do
					v_u_9:Blood(p36.Torso.CFrame, 50, 360, 360)
				end
				if _G.Settings.Gore then
					local v38 = v_u_6.Heian.BloodSpread:Clone()
					v38.Parent = v37
					v38:Emit(80)
					v_u_2:AddItem(v38, 2)
				end
			end
		end,
		["BlackFlashFinisherHard"] = function(p39, p40)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_10, (ref) v_u_4, (ref) v_u_8
			local v41 = p39:FindFirstChild("HumanoidRootPart")
			if v41 then
				local v42 = p40:FindFirstChild("HumanoidRootPart")
				if v42 then
					local v43 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					v43.CFrame = v41.CFrame * CFrame.new(2, 1, -5)
					v43.Parent = workspace.Effects
					v43.Wind:Emit(20)
					v43.Sparks:Emit(20)
					v43.Flare:Emit(20)
					v43.Lightning:Emit(25)
					v43.Back1.Back:Emit(1)
					v43.Back2.Back:Emit(1)
					v_u_3:Create(v43.Back1, TweenInfo.new(2), {
						["CFrame"] = v43.Back1.CFrame - v43.Back1.CFrame.LookVector * 20
					}):Play()
					v_u_3:Create(v43.Back2, TweenInfo.new(2), {
						["CFrame"] = v43.Back2.CFrame - v43.Back2.CFrame.LookVector * 20
					}):Play()
					v_u_3:Create(v43.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					v_u_2:AddItem(v43, 3)
					v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlashHit, v42, game.SoundService.Effect)
					local v44 = Instance.new("Model", workspace.Effects.Bolt)
					local v45 = Instance.new("Highlight", v44)
					v45.DepthMode = Enum.HighlightDepthMode.Occluded
					v45.OutlineColor = Color3.new(1, 0, 0)
					v45.FillColor = Color3.new(0, 0, 0)
					v45.FillTransparency = 0
					v_u_2:AddItem(v44, 1.2)
					local v_u_46 = v_u_10.new(v43.Core, v42.RootAttachment, nil, v44)
					v_u_46.Color = Color3.new(1, 0, 0)
					v_u_46.PulseSpeed = 1000
					v_u_46.FadeLength = 0.35
					v_u_46.MaxRadius = 20
					v_u_46.MinRadius = 0
					v_u_46.AnimationSpeed = 300
					v_u_46.MinThicknessMultiplier = 0.5
					v_u_46.MaxThicknessMultiplier = 10
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_46
						v_u_46.MaxThicknessMultiplier = 5
						task.wait(0.1)
						v_u_46.MaxThicknessMultiplier = 3
						task.wait(0.1)
						v_u_46.MaxThicknessMultiplier = 2
						task.wait(0.1)
						v_u_46.MaxThicknessMultiplier = 1
						task.wait(0.4)
						v_u_46:Destroy()
					end)
					if v_u_4.Character == p39 or v_u_4.Character == p40 then
						v_u_8.CurrentShaker:ShakeSustain(v_u_8.Presets.Snap):StartFadeOut(1.5)
						local v47 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v47.Parent = game.Lighting
						task.wait(0.04)
						v47.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v47.Brightness = 200
						v47.Contrast = -1000
						task.wait(0.04)
						v47:Destroy()
						game.Lighting.ExposureCompensation = 3
						v_u_3:Create(game.Lighting, TweenInfo.new(1), {
							["ExposureCompensation"] = 0
						}):Play()
					end
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p49, ...)
		-- upvalues: (copy) v_u_48
		local v50 = v_u_48[p49]
		if v50 then
			v50(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("CleaveRushService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13