-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

script.Parent.ChildAdded:Connect(function(p1)
	if script.Parent.Mic:FindFirstChild("Head") then
		p1:WaitForChild("Wire").SourceInstance = script.Parent.Audio.AudioReverb
	end
end)
script.Parent.Mic.ChildAdded:Connect(function(p2)
	if p2.Name == "Head" then
		if script.Parent:FindFirstChild("Speaker1") then
			local v3 = script.Parent.Speaker1
			if script.Parent.Mic:FindFirstChild("Head") then
				v3:WaitForChild("Wire").SourceInstance = script.Parent.Audio.AudioReverb
			end
		end
		if script.Parent:FindFirstChild("Speaker2") then
			local v4 = script.Parent.Speaker2
			if script.Parent.Mic:FindFirstChild("Head") then
				v4:WaitForChild("Wire").SourceInstance = script.Parent.Audio.AudioReverb
			end
		end
		script.Parent.Audio.Wire.SourceInstance = p2:WaitForChild("AudioListener", 1)
	end
end)
local v5 = script.Parent.Speaker1
if script.Parent.Mic:FindFirstChild("Head") then
	v5:WaitForChild("Wire").SourceInstance = script.Parent.Audio.AudioReverb
end
local v6 = script.Parent.Speaker2
if script.Parent.Mic:FindFirstChild("Head") then
	v6:WaitForChild("Wire").SourceInstance = script.Parent.Audio.AudioReverb
end