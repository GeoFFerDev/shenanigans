-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Name"] = "restartroulette",
	["Description"] = "Restarts all roulette servers",
	["Group"] = { "Owner" },
	["Args"] = {}
}