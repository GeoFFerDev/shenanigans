-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return require(script.Parent._Index["sleitnick_timer@1.1.2"].timer)