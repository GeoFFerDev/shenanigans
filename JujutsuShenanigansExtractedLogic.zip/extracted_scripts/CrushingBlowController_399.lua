-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "CrushingBlowController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_22 = {
		["CurseBuild"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_7.Itadori.DivergentFist.Crack, v13, game.SoundService.Effect)
				task.wait(0.3)
				v_u_10:PlaySound(v_u_7.Misc.Swing.Fist, v13, game.SoundService.Effect)
			end
		end,
		["Crush"] = function(p14, p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v16 = v_u_6.Itadori.CrushingBlow:Clone()
			v16.Position = p15
			v16.Parent = workspace.Effects
			v_u_3:Create(v16.Air, TweenInfo.new(0.2), {
				["Position"] = Vector3.new(0, 0, 0)
			}):Play()
			v_u_3:Create(v16.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v16.Flames:Emit(20)
			v16.Floor.Glow:Emit(1)
			v16.Floor.Ring:Emit(10)
			v16.Floor.Sparks:Emit(10)
			v16.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v16, 1.5)
			v_u_10:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v16, game.SoundService.Effect)
			if v_u_4 == p14 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Burst"] = function(p17)
			-- upvalues: (ref) v_u_3, (ref) v_u_2
			p17.Ring.Enabled = false
			p17.Attachment.Dust:Emit(20)
			p17.Trail.Enabled = false
			p17.Transparency = 1
			p17.Attachment.Energy:Destroy()
			p17.Attachment.Sparks:Emit(10)
			v_u_3:Create(p17.Attachment.PointLight, TweenInfo.new(0.5), {
				["Brightness"] = 0
			}):Play()
			for _, v18 in p17.Rocks:GetChildren() do
				local v_u_19 = v18:Clone()
				v_u_19.Anchored = false
				v_u_19.WeldConstraint:Destroy()
				v_u_19.Velocity = p17.CFrame.LookVector * 60
				v_u_19.Parent = p17.Rocks
				task.delay(0.1, function()
					-- upvalues: (copy) v_u_19, (ref) v_u_3, (ref) v_u_2
					v_u_19.CanCollide = true
					v_u_3:Create(v_u_19, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v_u_19, 2)
				end)
				v18:Destroy()
			end
		end,
		["Hit"] = function(p20)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_10:Flash(p20, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Itadori.CrushingBlow.Hit1, v21, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Itadori.CrushingBlow.Hit2, v21, game.SoundService.Effect)
				if v_u_4.Character == p20 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p23, ...)
		-- upvalues: (copy) v_u_22
		local v24 = v_u_22[p23]
		if v24 then
			v24(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("CrushingBlowService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11