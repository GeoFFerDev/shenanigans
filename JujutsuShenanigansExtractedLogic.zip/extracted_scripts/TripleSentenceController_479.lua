-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = require(v6.Modules.BloodyZee)
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "TripleSentenceController"
})
function v13.KnitStart(_)
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_3, (ref) v_u_12, (copy) v_u_8, (copy) v_u_10, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (ref) v_u_11
	local v_u_59 = {
		["Interp"] = function(p_u_14)
			-- upvalues: (ref) v_u_2
			local v_u_15 = p_u_14.CFrame
			local v_u_16 = tick()
			local v_u_17 = p_u_14:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_15, (copy) p_u_14, (ref) v_u_16
				v_u_15 = p_u_14.CFrame
				v_u_16 = tick()
			end)
			local v_u_18 = nil
			v_u_18 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_14, (ref) v_u_18, (copy) v_u_17, (ref) v_u_15, (ref) v_u_16
				if p_u_14.Parent then
					workspace:BulkMoveTo({ p_u_14 }, { v_u_15 + v_u_15.LookVector * (250 * (tick() - v_u_16)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_18:Disconnect()
					v_u_17:Disconnect()
				end
			end)
		end,
		["Summon"] = function(p19, p20)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			if p19:FindFirstChild("HumanoidRootPart") then
				task.wait(0.3)
				local v21 = v_u_7.Hiromi.SwordBuild.Charge:Clone()
				v_u_3:AddItem(v21, 1)
				v21.Parent = p20
				task.wait(0.1)
				v21:Destroy()
				for _, v22 in v_u_7.Hiromi.SwordBuild.Create:GetChildren() do
					local v23 = v22:Clone()
					v23.Parent = p20
					v_u_3:AddItem(v23, 1.5)
					v23:Emit(v23:GetAttribute("EmitCount"))
				end
			end
		end,
		["Arm"] = function(p24, p_u_25, p_u_26)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v27 = p24:FindFirstChild("HumanoidRootPart")
			if v27 then
				if p_u_25:FindFirstChild("HumanoidRootPart") then
					v_u_12:PlaySound(v_u_8.Hiromi.Execution.Sever, v27, game.SoundService.Effect)
					for _ = 1, 20 do
						v_u_10:Blood(p_u_25["Left Arm"].CFrame * CFrame.Angles(1.5707963267948966, 0, 0), math.random(-150, -5), 25, 25)
					end
					task.spawn(function()
						-- upvalues: (ref) v_u_7, (copy) p_u_25, (ref) v_u_3, (copy) p_u_26
						local v28 = v_u_7.Hiromi.Limb:Clone()
						local v29 = p_u_25["Left Arm"]
						v29.CFrame = p_u_25["Left Arm"].CFrame - Vector3.new(0, 0.5, 0)
						v28["Left Arm"].Size = v29.Size
						v28["Left Arm"].Color = v29.Color
						if p_u_25:FindFirstChildWhichIsA("Shirt") then
							p_u_25:FindFirstChildWhichIsA("Shirt"):Clone().Parent = v28
						end
						v_u_3:AddItem(v28, 6)
						v28.Parent = workspace.Effects
						v28.HumanoidRootPart.Anchored = false
						v28.HumanoidRootPart.CanCollide = true
						v28.HumanoidRootPart.CollisionGroup = "Effects"
						v28.HumanoidRootPart.Velocity = p_u_26 * 50
					end)
					if v_u_5.Character == p24 or v_u_5.Character == p_u_25 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Leg"] = function(p30, p_u_31, p_u_32)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			local v33 = p30:FindFirstChild("HumanoidRootPart")
			if v33 then
				if p_u_31:FindFirstChild("HumanoidRootPart") then
					v_u_12:PlaySound(v_u_8.Hiromi.Execution.Sever2, v33, game.SoundService.Effect)
					for _ = 1, 20 do
						v_u_10:Blood(p_u_31["Right Leg"].CFrame * CFrame.Angles(1.5707963267948966, 0, 0), math.random(-150, -5), 25, 25)
					end
					task.spawn(function()
						-- upvalues: (ref) v_u_7, (copy) p_u_31, (ref) v_u_3, (copy) p_u_32
						local v34 = v_u_7.Hiromi.Limb:Clone()
						v34["Left Arm"].Transparency = 1
						v34["Right Leg"].Transparency = 0
						local v35 = p_u_31["Right Leg"]
						v35.CFrame = p_u_31["Right Leg"].CFrame - Vector3.new(0, 0.5, 0)
						v34["Right Leg"].Size = v35.Size
						v34["Right Leg"].Color = v35.Color
						if p_u_31:FindFirstChildWhichIsA("Pants") then
							p_u_31:FindFirstChildWhichIsA("Pants"):Clone().Parent = v34
						end
						v_u_3:AddItem(v34, 6)
						v34.Parent = workspace.Effects
						v34.HumanoidRootPart.Anchored = false
						v34.HumanoidRootPart.CanCollide = true
						v34.HumanoidRootPart.CollisionGroup = "Effects"
						v34.HumanoidRootPart.Velocity = p_u_32 * 50
					end)
					if v_u_5.Character == p30 or v_u_5.Character == p_u_31 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Teleport"] = function(p36)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v37 = p36:FindFirstChild("HumanoidRootPart")
			if v37 then
				local v38 = v_u_7.Gojo.Teleport:Clone()
				v38.CFrame = v37.CFrame
				v38.Parent = workspace.Effects
				v_u_3:AddItem(v38, 1.1)
				v38.Floor.Dust:Emit(30)
				v38.Lines:Emit(30)
				v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Takedown.Teleport, v37, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Hiromi.Sweep, v37, game.SoundService.Effect)
				if v_u_5.Character == p36 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end,
		["Stab"] = function(_, p39)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_10, (ref) v_u_9
			local v40 = p39:FindFirstChild("HumanoidRootPart")
			if v40 then
				v_u_12:Flash(p39, Color3.new(1, 1, 0.498039), 1)
				v_u_12:PlaySound(v_u_8.Hiromi.Stab, v40, game.SoundService.Effect)
				for _ = 1, 40 do
					v_u_10:Blood(p39.Torso.CFrame, math.random(-150, -5), 25, 25)
				end
				if (workspace.CurrentCamera.CFrame.Position - v40.Position).Magnitude < 70 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.SnapOh)
				end
			end
		end,
		["Toss"] = function(p41, p42)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v_u_43 = p42:FindFirstChild("HumanoidRootPart")
			if v_u_43 then
				v_u_12:PlaySound(v_u_8.Hiromi.SwordPull, v_u_43, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Hiromi.Swing, v_u_43, game.SoundService.Effect)
				task.delay(0.2, function()
					-- upvalues: (ref) v_u_12, (ref) v_u_8, (copy) v_u_43
					v_u_12:PlaySound(v_u_8.Hiromi.Sweep, v_u_43, game.SoundService.Effect)
				end)
				if v_u_5 == p41 or v_u_5.Character == p42 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end,
		["Hit1"] = function(p44, p45)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v46 = p45:FindFirstChild("HumanoidRootPart")
			if v46 then
				local v47 = v_u_7.Hiromi.Whack:Clone()
				v47.CFrame = v46.CFrame
				v47.Parent = workspace.Effects
				v_u_3:AddItem(v47, 1.5)
				for _, v48 in v47:GetDescendants() do
					if v48:IsA("ParticleEmitter") then
						v48:Emit(v48:GetAttribute("EmitCount"))
					end
				end
				v_u_12:Flash(p45, Color3.new(1, 1, 0.498039), 0.5)
				v_u_12:PlaySound(v_u_8.Hiromi.Verdict.Hit1, v46, game.SoundService.Effect)
				if v_u_5 == p44 or v_u_5.Character == p45 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Hit2"] = function(p49, p50)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v51 = p50:FindFirstChild("HumanoidRootPart")
			if v51 then
				local v52 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
				v52.Position = v51.Position
				v52.Parent = workspace.Effects
				v_u_3:AddItem(v52, 1)
				v52.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v52.Wind.Color = v52.Sparks.Color
				v52.Wind2.Color = v52.Sparks.Color
				v52.Sparks:Emit(30)
				v52.Wind2:Emit(7)
				v_u_12:Flash(p50, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Hiromi.Verdict.Hit2, v51, game.SoundService.Effect)
				if v_u_5 == p49 or v_u_5.Character == p50 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["ThrowStart"] = function(p53)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v54 = p53:FindFirstChild("HumanoidRootPart")
			if v54 then
				v_u_12:PlaySound(v_u_8.Hiromi.ThrowStart, v54, game.SoundService.Effect)
			end
		end,
		["Throw"] = function(p55, p56)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v57 = p55:FindFirstChild("HumanoidRootPart")
			if v57 then
				local v58 = v_u_7.Hiromi.Throw:Clone()
				v58.CFrame = v57.CFrame * CFrame.new(2, 1, -5)
				v58.Parent = workspace.Effects
				v58.Wind:Emit(20)
				v58.Back1.Back:Emit(1)
				v58.Back2.Back:Emit(1)
				v_u_4:Create(v58.Back1, TweenInfo.new(2), {
					["CFrame"] = v58.Back1.CFrame - v58.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_4:Create(v58.Back2, TweenInfo.new(2), {
					["CFrame"] = v58.Back2.CFrame - v58.Back2.CFrame.LookVector * 20
				}):Play()
				v_u_3:AddItem(v58, 2)
				if p56 == false then
					v_u_12:PlaySound(v_u_8.Hiromi.Throw, v57, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_8.Hiromi.Throw2, v57, game.SoundService.Effect)
				end
				v_u_4:Create(v58.Attachment, TweenInfo.new(0.2), {
					["Position"] = v58.Core.Position
				}):Play()
				if v_u_5.Character == p55 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p60, ...)
		-- upvalues: (copy) v_u_59
		local v61 = v_u_59[p60]
		if v61 then
			v61(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12
	v_u_11 = v_u_1.GetService("TripleSentenceService")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13