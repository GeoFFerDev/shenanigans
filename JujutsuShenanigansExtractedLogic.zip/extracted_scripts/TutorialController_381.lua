-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local _ = v5.Utils
local v_u_6 = v5.Sounds
local v_u_7 = nil
local v8 = v_u_1.CreateController({
	["Name"] = "TutorialController"
})
local v_u_9 = {
	{
		"Controls",
		"Basic Controls",
		"5608360493",
		{
			"M1 / B - <font color=\"rgb(0,85,255)\">Melee Attack</font>",
			"1,2,3,4 / LB,LT,RT,RB - <font color=\"rgb(0,85,255)\">Skills</font>",
			"Q / Y - <font color=\"rgb(0,85,255)\">Dash / Escape</font>",
			"F / X - <font color=\"rgb(0,85,255)\">Block</font>",
			"R / DPAD_LEFT - <font color=\"rgb(0,85,255)\">Special</font>",
			"G / DPAD_RIGHT - <font color=\"rgb(0,85,255)\">Awaken</font>",
			"LEFT_SHIFT / DPAD_DOWN - <font color=\"rgb(0,85,255)\">Shift Lock</font>",
			"LEFT_THUMBSTICK - <font color=\"rgb(0,85,255)\">Lock On</font>"
		}
	},
	{
		"Ragdolls",
		"Ragdoll cancels",
		"124674005293931",
		{ "Similar to being stunned, you <font color=\"rgb(0,85,255)\">cannot attack or move</font> during it. However, you can still do <font color=\"rgb(0,85,255)\">certain actions while ragdolled</font> that can help with escaping a player.", "You can cancel a ragdoll instantly by <font color=\"rgb(0,85,255)\">dashing</font> while your escape meter is filled. It can be used to escape attacks that could hit you while you\'re immobile.", "You can also <font color=\"rgb(0,85,255)\">affect the tragectory of your ragdoll by moving during it,</font> giving players a harder time predicting where you will land." }
	},
	{
		"Blocking",
		"Blocking",
		"93359191648570",
		{ "Your <font color=\"rgb(0,85,255)\">main defense</font> in any fight is your block. It can be used to <font color=\"rgb(0,85,255)\">negate certain attacks and defend against melee attacks.</font>", "However, some attacks require you to be <font color=\"rgb(0,85,255)\">facing the direction of the attack.</font> Failing to do so will result in your block being broken and the attack landing on you, <font color=\"rgb(0,85,255)\">so it is recommended to keep a good track of the enemy during fights.</font>" }
	},
	{
		"Parkour",
		"Parkour",
		"102306667240177",
		{
			"A good way of traversing the map is by <font color=\"rgb(0,85,255)\">using obstacles as a boost.</font> There are <font color=\"rgb(0,85,255)\">5 types of parkour</font> that are available while sprinting.",
			"<font color=\"rgb(0,85,255)\">Vaulting</font> lets you run over short obstacles while spriting, letting you keep your momentum.",
			"<font color=\"rgb(0,85,255)\">Sliding</font> lets you slide under obstacles that have a gap while spriting.",
			"<font color=\"rgb(0,85,255)\">Climbing</font> lets you climb over tall obstacles or ledges in exchange of your momentum.",
			"And <font color=\"rgb(0,85,255)\">Wall running (Run against a wall),</font> letting you scale walls, giving you a short boost of upward and forward momentum. You can only perform it <font color=\"rgb(0,85,255)\">3 times in a chain</font> after leaving the ground."
		}
	},
	{
		"Evasives",
		"Teaming and evasives",
		"119038955627224",
		{
			"During fights, you may be in a situation where you\'re <font color=\"rgb(0,85,255)\">facing multiple enemies.</font>",
			"Getting hit by 2 enemies in a short time window or having a combo interrupted enables you to <font color=\"rgb(0,85,255)\">evade out of stun and or ragdoll.</font>",
			"Evading also temporarily grants you <font color=\"rgb(0,85,255)\">invincibility frames and a small health bonus.</font>",
			"If hit immediately after evading, you <font color=\"rgb(0,85,255)\">instantly regain your evasion.</font>",
			"Note that <font color=\"rgb(0,85,255)\">having your combo interrupted does not restore your escape meter</font>"
		}
	},
	{
		"Throwables",
		"Throwing world objects",
		"5670799859",
		{ "Many objects spread around the map can be picked up by <font color=\"rgb(0,85,255)\">using your melee while in front of it.</font> After a short animation, you can carry it around and <font color=\"rgb(0,85,255)\">throw it with your melee again.</font>", "Some objects such as fire extinguishers, have <font color=\"rgb(0,85,255)\">different effects</font> that appear on impact that could help you in fights." }
	},
	{
		"Drinks",
		"Soda Delivery System",
		"5608321996",
		{ "Sodas are an amazing way to <font color=\"rgb(0,85,255)\">restore health and escape meter before entering another battle.</font>", "Sodas are available for purchase via <font color=\"rgb(0,85,255)\">vending machines around the map or through the shop.</font> Drinking a can provides you with <font color=\"rgb(0,85,255)\">3x regen</font> until you are healed or get combat tagged.", "Soda colors <font color=\"rgb(0,85,255)\">do not affect the properties of the drink.</font>" }
	},
	{
		"Items",
		"Item Delivery System",
		"5608359401",
		{ "Items are a fun way to spice up combat by <font color=\"rgb(0,85,255)\">changing how your basic skills work.</font>", "Items are available by <font color=\"rgb(0,85,255)\">finding one around the map</font> or <font color=\"rgb(0,85,255)\">via the shop.</font>", "Certain items may <font color=\"rgb(0,85,255)\">degrade after repeated use</font>" }
	},
	{
		"Status",
		"Status Effects",
		"5608359401",
		{ "Status effects will apply different effects onto enemies that may turn certain fights in your favor.", "Poison <font color=\"rgb(0,85,255)\">slowly drains your health until it ends.</font>", "Bleed <font color=\"rgb(0,85,255)\">makes you take damage when using a skill</font> until it runs out. Hemorredge (Inflict bleed twice) makes the enemy <font color=\"rgb(0,85,255)\">start draining health until it runs out.</font>" }
	}
}
function v8.KnitStart(_)
	-- upvalues: (copy) v_u_4, (ref) v_u_7, (copy) v_u_6, (copy) v_u_9, (copy) v_u_2, (copy) v_u_3
	local v_u_10 = v_u_4.PlayerGui:WaitForChild("Menus")
	local v_u_11 = v_u_10.Group.Tutorial_Info
	v_u_11:SetAttribute("Loaded", true)
	local function v_u_18(p12, p13)
		-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) v_u_11, (ref) v_u_9
		v_u_7:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7:PlaySound(v_u_6.Misc.UI.Switch, workspace, game.SoundService.Effect)
		for _, v14 in v_u_11.Items:GetChildren() do
			if v14:IsA("TextButton") then
				if v14 == p13 then
					v14.BackgroundTransparency = 0.5
				else
					v14.BackgroundTransparency = 1
				end
			end
		end
		local v15 = v_u_11.Description
		local v16 = v_u_9[p12]
		v15.CanvasPosition = Vector2.new(0, 0)
		v15.Title.Text = v16[2]
		v15.Video.Video = "rbxassetid://" .. v16[3]
		v15.Description.Text = ""
		for _, v17 in v16[4] do
			v15.Description.Text = v15.Description.Text .. v17 .. "\n\n"
		end
	end
	v_u_11.Return.MouseButton1Down:Connect(function()
		-- upvalues: (copy) v_u_11
		v_u_11.Visible = false
	end)
	v_u_11:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_11, (ref) v_u_9, (copy) v_u_10, (copy) v_u_18, (ref) v_u_2
		if v_u_11.Visible == true then
			for v_u_19, v20 in v_u_9 do
				local v_u_21 = v_u_10.Preset.ItemBox:Clone()
				v_u_21.Name = v20[1]
				v_u_21.LayoutOrder = v_u_19
				v_u_21.Text = v20[1]
				v_u_21.Parent = v_u_11.Items
				if v_u_19 == 1 then
					v_u_18(v_u_19, v_u_21)
				end
				v_u_21.MouseButton1Down:Connect(function()
					-- upvalues: (ref) v_u_18, (copy) v_u_19, (copy) v_u_21
					v_u_18(v_u_19, v_u_21)
				end)
			end
			local v_u_22 = nil
			v_u_22 = v_u_2.RenderStepped:Connect(function()
				-- upvalues: (ref) v_u_11, (ref) v_u_22
				if v_u_11.Visible == false then
					v_u_22:Disconnect()
				else
					v_u_11.Description.Video.Playing = false
					v_u_11.Description.Video.Playing = true
				end
			end)
		else
			for _, v23 in v_u_11.Items:GetChildren() do
				if v23:IsA("TextButton") then
					v23:Destroy()
				end
			end
			v_u_11.Description.Video.Video = ""
		end
	end)
	v_u_11.Description.Video:GetPropertyChangedSignal("IsLoaded"):Connect(function()
		-- upvalues: (copy) v_u_11, (ref) v_u_3
		if v_u_11.Description.Video.IsLoaded then
			v_u_3:Create(v_u_11.Description.Video.Fade, TweenInfo.new(0.4), {
				["BackgroundTransparency"] = 1
			}):Play()
		else
			v_u_3:Create(v_u_11.Description.Video.Fade, TweenInfo.new(0), {
				["BackgroundTransparency"] = 0
			}):Play()
		end
	end)
end
function v8.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1
	v_u_7 = v_u_1.GetController("FXController")
end
return v8