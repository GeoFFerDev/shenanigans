-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "FeverBreakerController"
})
function v10.KnitStart(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8
	local v_u_36 = {
		["Startup"] = function(p11)
			-- upvalues: (ref) v_u_9, (ref) v_u_7
			local v12 = p11:FindFirstChild("HumanoidRootPart")
			if v12 then
				v_u_9:PlaySound(v_u_7.Hakari.FeverBreak.Swing, v12, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p13)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				local v15 = v_u_6.Gojo.Twofold:Clone()
				v15.CFrame = v14.CFrame * CFrame.new(-1.25, -1, -3) * CFrame.Angles(-1.3962634015954636, 0, 0)
				v15.Transparency = 0.5
				v15.Parent = workspace.Effects
				v15.Swing2.Swing1:Emit(10)
				v_u_3:Create(v15, TweenInfo.new(0.3), {
					["CFrame"] = v15.CFrame + v15.CFrame.UpVector * 12,
					["Size"] = Vector3.new(0, 6, 0)
				}):Play()
				v_u_2:AddItem(v15, 0.4)
			end
		end,
		["Hit"] = function(p16, p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_6.Gojo.Twofold.Sparks:Clone()
				v19.Parent = v18.RootAttachment
				v19:Emit(20)
				v_u_2:AddItem(v19, 0.4)
				v_u_9:Flash(p17, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_7.Hakari.FeverBreak.Hit1, v18, game.SoundService.Effect)
				if v_u_4 == p16 or v_u_4.Character == p17 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Hit2"] = function(p20, p21)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v22 = p21:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = v_u_6.Hakari.RoughHit:Clone()
				v23.Position = v22.Position
				v23.Parent = workspace.Effects
				v_u_2:AddItem(v23, 1)
				v_u_3:Create(v23.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v23.Glow:Emit(1)
				v23.Sparks:Emit(50)
				v23.Wind:Emit(7)
				v23.Wind2:Emit(7)
				v_u_9:Flash(p21, Color3.new(1, 1, 1))
				v_u_9:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v22, game.SoundService.Effect)
				if v_u_4 == p20 or v_u_4.Character == p21 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Dash"] = function(p24)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				v_u_9:PlaySound(v_u_7.Hakari.FeverBreak.Dash, v25, game.SoundService.Effect)
				if v_u_4.Character == p24 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["Spawn"] = function(p26, p27)
			-- upvalues: (ref) v_u_3, (ref) v_u_9, (ref) v_u_7, (ref) v_u_2
			local v28 = Instance.new("Highlight")
			v28.FillTransparency = 0
			v28.FillColor = Color3.new(2, 2, 2)
			v28.OutlineColor = Color3.new(2, 2, 2)
			v28.DepthMode = Enum.HighlightDepthMode.Occluded
			v28.Parent = p26.Doors
			if p27 then
				p26.Doors.Door1.Color = p27
				p26.Doors.Door2.Color = p27
				p26.Doors.Door1.Stars.Color = ColorSequence.new(p27)
				p26.Doors.Door2.Stars.Color = ColorSequence.new(p27)
			end
			p26.Weld1.C1 = CFrame.new(-2, 0, 8) * CFrame.Angles(0, -1.5707963267948966, 0)
			p26.Weld2.C1 = CFrame.new(-2, 0, 8) * CFrame.Angles(0, -1.5707963267948966, 3.141592653589793)
			v_u_3:Create(p26.Weld1, TweenInfo.new(0.4, Enum.EasingStyle.Quad), {
				["C1"] = CFrame.new(-2, 0, 2.4) * CFrame.Angles(0, -1.5707963267948966, 0)
			}):Play()
			v_u_3:Create(p26.Weld2, TweenInfo.new(0.4, Enum.EasingStyle.Quad), {
				["C1"] = CFrame.new(-2, 0, 2.4) * CFrame.Angles(0, -1.5707963267948966, 3.141592653589793)
			}):Play()
			v_u_3:Create(v28, TweenInfo.new(0.4), {
				["FillTransparency"] = 1,
				["OutlineTransparency"] = 1
			}):Play()
			v_u_9:PlaySound(v_u_7.Hakari.ShutterDoors.Spawn, p26, game.SoundService.Effect)
			v_u_9:PlaySound(v_u_7.Hakari.ShutterDoors.Swing, p26, game.SoundService.Effect)
			v_u_2:AddItem(v28, 0.4)
			task.wait(0.2)
			p26.Doors.Door1.Stars.Enabled = false
			p26.Doors.Door2.Stars.Enabled = false
		end,
		["Break"] = function(p29, p30, _)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_3
			local v31 = p29.HumanoidRootPart
			if v31 then
				v_u_9:PlaySound(v_u_7.Hakari.Counter.Slam, v31, game.SoundService.Effect)
				local v32 = p30.Doors:Clone()
				v32.Parent = p30
				p30.Doors:Destroy()
				v32.Door1.Stars:Emit(20)
				v32.Door2.Stars:Emit(20)
				v32.Door1.CanCollide = true
				v32.Door2.CanCollide = true
				v32.Door1.Velocity = v31.CFrame.LookVector * 60 + v31.CFrame.RightVector * 20
				v32.Door2.Velocity = v31.CFrame.LookVector * 60 + v31.CFrame.RightVector * 20
				for _, v33 in v32:GetDescendants() do
					if v33:IsA("BasePart") or v33:IsA("Texture") then
						v_u_3:Create(v33, TweenInfo.new(0.6, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["Transparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["CrushSwing"] = function(p34)
			-- upvalues: (ref) v_u_9, (ref) v_u_7
			local v35 = p34:FindFirstChild("HumanoidRootPart")
			if v35 then
				v_u_9:PlaySound(v_u_7.Hakari.FeverBreak.CrushSwing, v35, game.SoundService.Effect)
			end
		end
	}
	FeverBreakerService.Effects:Connect(function(p37, ...)
		-- upvalues: (copy) v_u_36
		local v38 = v_u_36[p37]
		if v38 then
			v38(...)
		end
	end)
end
function v10.KnitInit(_)
	-- upvalues: (copy) v_u_1, (ref) v_u_9
	FeverBreakerService = v_u_1.GetService("FeverBreakerService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10