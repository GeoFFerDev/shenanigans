-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("Players").LocalPlayer
local v_u_3 = {}
v_u_3.__index = v_u_3
local v_u_4 = require(script.Instance)
local v_u_5 = v_u_4.CameraShakeState
v_u_3.CameraShakeInstance = v_u_4
function v_u_3.new(p6, p7)
	-- upvalues: (copy) v_u_3
	local v8 = type(p6) == "number"
	assert(v8, "RenderPriority must be a number")
	local v9 = type(p7) == "function"
	assert(v9, "Callback must be a function")
	local v10 = v_u_3
	return setmetatable({
		["_Running"] = false,
		["_RenderName"] = "CameraShaker",
		["_RenderPriority"] = p6,
		["_CamShakeInstances"] = {},
		["_RemoveInstances"] = {},
		["_Callback"] = p7
	}, v10)
end
function v_u_3.Start(p_u_11)
	-- upvalues: (copy) v_u_1
	if not p_u_11._Running then
		p_u_11._Running = true
		local v_u_12 = p_u_11._Callback
		v_u_1:BindToRenderStep(p_u_11._RenderName, p_u_11._RenderPriority, function(p13)
			-- upvalues: (copy) v_u_12, (copy) p_u_11
			v_u_12(p_u_11:Update(p13))
		end)
	end
end
function v_u_3.Stop(p14)
	-- upvalues: (copy) v_u_1
	if p14._Running then
		v_u_1:UnbindFromRenderStep(p14._RenderName)
		p14._running = false
	end
end
function v_u_3.Update(p15, p16)
	-- upvalues: (copy) v_u_5
	local v17 = p15._CamShakeInstances
	local v18 = Vector3.new(0, 0, 0)
	local v19 = Vector3.new(0, 0, 0)
	for v20 = 1, #v17 do
		local v21 = v17[v20]
		local v22 = v21:GetState()
		if v22 == v_u_5.Inactive and v21.DeleteOnInactive then
			p15._RemoveInstances[#p15._RemoveInstances + 1] = v20
		elseif v22 ~= v_u_5.Inactive then
			local v23 = v21:UpdateShake(p16)
			v18 = v18 + v23 * v21.PositionInfluence
			v19 = v19 + v23 * v21.RotationInfluence
		end
	end
	for v24 = #p15._RemoveInstances, 1, -1 do
		local v25 = p15._RemoveInstances[v24]
		table.remove(v17, v25)
		p15._RemoveInstances[v24] = nil
	end
	local v26 = CFrame.new(v18)
	local v27 = CFrame.Angles
	local v28 = v19.X
	local v29 = math.rad(v28)
	local v30 = v19.Y
	local v31 = math.rad(v30)
	local v32 = v19.Z
	return v26 * v27(v29, v31, (math.rad(v32)))
end
function v_u_3.Fire(p33, p34, p35, p36, p37, p38, p39)
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	if v_u_2:GetAttribute("Camera_Shake") then
		p34 = p34 * (v_u_2:GetAttribute("Camera_Shake") / 100)
	end
	local v40 = v_u_4.new(p34, p35, p36, p37)
	v40.PositionInfluence = typeof(p38) == "Vector3" and p38 and p38 or Vector3.new(0.8, 0.8, 0.8)
	v40.RotationInfluence = typeof(p39) == "Vector3" and p39 and p39 or Vector3.new(0, 0, 0)
	p33._CamShakeInstances[#p33._CamShakeInstances + 1] = v40
	return v40
end
return v_u_3