-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
require(v_u_5.Modules.EffectUtils)
local v_u_9 = require(v_u_5.Knit.Trove)
local v_u_10 = require(v_u_5.Modules.SraikoVFX)
local v_u_11 = v_u_10.Enabled
local v_u_12 = v_u_10.Emit
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v17 = v_u_1.CreateController({
	["Name"] = "BoostOnController"
})
function v17.KnitStart(_)
	-- upvalues: (copy) v_u_9, (copy) v_u_5, (ref) v_u_16, (copy) v_u_7, (copy) v_u_6, (copy) v_u_10, (copy) v_u_2, (copy) v_u_12, (copy) v_u_11, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (ref) v_u_13
	local v_u_58 = {
		["Start"] = function(p18, p19)
			-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_16, (ref) v_u_7
			local v20 = p18:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = v_u_9.new()
				v21:AttachToInstance(p19)
				local v22 = v21:Clone(v_u_5.Utils.Mechamaru.BoosterL)
				v22.Parent = p18
				local v23 = v21:Clone(v_u_5.Utils.Mechamaru.BoosterR)
				v23.Parent = p18
				local function v27(p24, p25)
					local v_u_26 = Instance.new("Motor6D")
					v_u_26.C0 = CFrame.new(0, 0.75, 0.625) * CFrame.Angles(0.7853981633974483, 0, 0)
					v_u_26.Part0 = p25
					v_u_26.Part1 = p24
					v_u_26.Name = p24.Name
					v_u_26.Parent = p25
					p24.Parent.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_26
						v_u_26:Destroy()
					end)
				end
				v27(v23["Arm BoostterrrrR"], p18["Right Arm"])
				v27(v22["Arm BoostterrrrL"], p18["Left Arm"])
				v_u_16:PlaySound(v_u_7.Mechamaru.BoostOn.PunchWoosh, v20, game.SoundService.Effect)
				task.wait(0.1)
				v_u_16:PlaySound(v_u_7.Mechamaru.BoostOn.Start, v20, game.SoundService.Effect)
			end
		end,
		["Boost"] = function(p28)
			-- upvalues: (ref) v_u_16, (ref) v_u_7, (ref) v_u_6, (ref) v_u_10, (ref) v_u_2, (ref) v_u_12, (ref) v_u_11
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				v_u_16:PlaySound(v_u_7.Mechamaru.BoostOn.Booster, v29, game.SoundService.Effect)
				local v30 = v_u_6.Mechamaru.BoostOnVFX.BoostHit.Meshes.Mesh:Clone()
				local v31 = v_u_10.HandleMesh(v30, v29.CFrame * CFrame.Angles(1.0471975511965976, 0, 0) * v30.Offset.Value)
				v30.Parent = workspace.Effects
				v_u_2:AddItem(v30, v31)
				v_u_12(v_u_6.Mechamaru.BoostOnVFX.BoostHit.Emit.Strike, v29, true, 3)
				local v32 = p28:FindFirstChild("BoosterR")
				local v33 = p28:FindFirstChild("BoosterL")
				if v32 and v33 then
					v_u_11(v32["Arm BoostterrrrR"].Stage1, false)
					v_u_11(v32["Arm BoostterrrrR"].Stage2, true)
					v_u_11(v33["Arm BoostterrrrL"].Stage1, false)
					v_u_11(v33["Arm BoostterrrrL"].Stage2, true)
					task.wait(0.4)
					v_u_11(v32["Arm BoostterrrrR"].Stage2, false)
					v_u_11(v33["Arm BoostterrrrL"].Stage2, false)
					v_u_16:PlaySound(v_u_7.Mechamaru.BoostOn.SecondPart, v29, game.SoundService.Effect)
				end
			end
		end,
		["Hit"] = function(p34, p35)
			-- upvalues: (ref) v_u_16, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v36 = p34:FindFirstChild("HumanoidRootPart")
			if v36 then
				local v37 = p35:FindFirstChild("HumanoidRootPart")
				if v37 then
					v_u_16:Flash(p35, Color3.new(1, 1, 1))
					v_u_16:PlaySound(v_u_7.Mechamaru.BoostOn.Hit, v37, game.SoundService.Effect)
					v_u_16:PlaySound(v_u_7.Mechamaru.PuppetBarrage.FlyUp, v36, game.SoundService.Effect)
					if v_u_4.Character == p34 or v_u_4.Character == p35 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
				end
			else
				return
			end
		end,
		["Touch"] = function(p38, p39, p40)
			-- upvalues: (ref) v_u_16, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6
			if p38:FindFirstChild("HumanoidRootPart") then
				local v41 = p39:FindFirstChild("HumanoidRootPart")
				if v41 then
					v_u_16:Flash(p39, Color3.new(1, 1, 1))
					v_u_16:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v41, game.SoundService.Effect)
					local v42 = v_u_9.new()
					v42:AttachToInstance(p40)
					local v43 = p38:FindFirstChild("Right Arm")
					if v43 then
						local v44 = v42:Clone(v_u_6.Mechamaru["Hand blasterR"])
						v44.Weld.Part0 = v43
						if p38:GetAttribute("Moveset") ~= "Mechamaru" then
							v44.BlasterL.Transparency = 1
							v44.Neon.Transparency = 1
						end
						v44.Parent = p38
					end
				else
					return
				end
			else
				return
			end
		end,
		["Blast"] = function(p45)
			-- upvalues: (ref) v_u_16, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_8
			local v46 = p45:FindFirstChild("HumanoidRootPart")
			if v46 then
				local v47 = (v46.CFrame - Vector3.new(0, 2, 0)) * CFrame.Angles(-0.8726646259971648, 0, 0)
				v_u_16:PlaySound(v_u_7.Mechamaru.UltraCannon.Shoot, v46, game.SoundService.Effect)
				v_u_16:PlaySound(v_u_7.Mechamaru.UltraCannon.Explode, v46, game.SoundService.Effect)
				local v48 = v_u_6.Mechamaru.Heat:Clone()
				v48.Parent = workspace.Effects
				v48.CFrame = v47
				v_u_2:AddItem(v48, 1.5)
				v48.Flames:Emit(30)
				v48.Attachment.Wind2:Emit(5)
				local v49 = v_u_6.Misc.M.DashHit:Clone()
				v49.Position = v46.Position
				v49.Parent = workspace.Effects
				for _, v50 in v49:GetDescendants() do
					if v50:IsA("ParticleEmitter") then
						v50:Emit(v50:GetAttribute("EmitCount"))
					end
				end
				v_u_2:AddItem(v49, 1)
				local v51 = v_u_6.Misc.M.Slash.PointLight:Clone()
				v51.Parent = v48
				v51.Brightness = 15
				v_u_3:Create(v51, TweenInfo.new(0.6), {
					["Brightness"] = 0,
					["Color"] = Color3.new(1, 0, 0)
				}):Play()
				local v52 = v_u_6.Mechamaru.CannonFire:Clone()
				v52:PivotTo(v46.CFrame * CFrame.Angles(-0.8726646259971648, 0, 0) * CFrame.new(0, 0, -34))
				v52.Parent = workspace.Effects
				v_u_2:AddItem(v52, 1)
				for _, v53 in v52:GetChildren() do
					v53.Size = v53.Size * Vector3.new(3, 3, 1)
					local v54 = v_u_3
					local v55 = TweenInfo.new(0.6)
					local v56 = {}
					local v57 = v53.Size.Z
					v56.Size = Vector3.new(0, 0, v57)
					v56.CFrame = v53.CFrame - v53.CFrame.LookVector * 5
					v54:Create(v53, v55, v56):Play()
					v_u_2:AddItem(v53, 0.6)
				end
				if (workspace.CurrentCamera.CFrame.Position - v46.Position).Magnitude < 150 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_13.Effects:Connect(function(p59, ...)
		-- upvalues: (copy) v_u_58
		local v60 = v_u_58[p59]
		if v60 then
			v60(...)
		end
	end)
end
function v17.KnitInit(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_1, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16
	v_u_13 = v_u_1.GetService("BoostOnService")
	v_u_14 = v_u_1.GetController("HitboxController")
	v_u_15 = v_u_1.GetController("ToolController")
	v_u_16 = v_u_1.GetController("FXController")
end
return v17