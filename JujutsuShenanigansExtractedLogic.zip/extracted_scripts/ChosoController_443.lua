-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "ChosoController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10, (ref) v_u_11
	local v_u_70 = {
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:Flash(p14, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Choso.M1:FindFirstChild("Hit" .. p15), v16, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p17, p18)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = p18:FindFirstChild("HumanoidRootPart")
				if v20 then
					v_u_12:Flash(p18, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit3"), v20, game.SoundService.Effect)
					local v21 = v_u_7.ChaseHit:Clone()
					local v22 = CFrame.new
					local v23 = v20.Position
					local v24 = v19.Position.X
					local v25 = v20.Position.Y
					local v26 = v19.Position.Z
					v21.CFrame = v22(v23, (Vector3.new(v24, v25, v26))) * CFrame.Angles(0, 3.141592653589793, 0)
					v21.Parent = workspace.Effects
					v21.Ring:Emit(7)
					v21.Sparks:Emit(12)
					v_u_3:AddItem(v21, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p27)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v28 = p27.HumanoidRootPart
			if v28 then
				local v29 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v29.CFrame = v28.CFrame * CFrame.new(0, 1, -4)
				v29.Size = Vector3.new(0, 0, 2)
				v29.Parent = workspace.Effects
				v_u_4:Create(v29, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v29, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v28, game.SoundService.Effect)
				v_u_12:DustTrail(p27, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p30)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v31, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p32, p33, p34)
			-- upvalues: (ref) v_u_12
			if p33 == 1 or p34 == "Up" then
				v_u_12:ArmFlash(p32["Right Arm"], Color3.fromRGB(255, 0, 0), 0.3)
				return
			elseif p33 == 2 then
				v_u_12:ArmFlash(p32["Left Arm"], Color3.fromRGB(255, 0, 0))
				return
			elseif p33 == 3 or p34 == "Down" then
				v_u_12:ArmFlash(p32["Right Leg"], Color3.fromRGB(255, 0, 0), p34 == "Down" and 0.4 or 0.3)
			elseif p33 == 4 then
				v_u_12:ArmFlash(p32["Left Leg"], Color3.fromRGB(255, 0, 0), 0.4)
			end
		end,
		["Launch"] = function(p35, p36)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v37 = p35:FindFirstChild("HumanoidRootPart")
			if v37 then
				local v38 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v38.CFrame = CFrame.new(v37.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v38.Size = Vector3.new(0, 0, 5)
				v38.Parent = workspace.Effects
				v_u_4:Create(v38, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v38.Position + Vector3.new(0, p36, 0)
				}):Play()
				v_u_3:AddItem(v38, 0.3)
				if p36 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v37, game.SoundService.Effect)
					v_u_12:DustBreak(v37.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v37.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["BloodStart"] = function(p39)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v40 = p39:FindFirstChild("HumanoidRootPart")
			if v40 then
				v_u_12:PlaySound(v_u_8.Gojo.BlindsOff, v40, game.SoundService.Effect)
				task.wait(0.4)
				v_u_12:PlaySound(v_u_8.Itadori.CursedStrikes.Spin, v40, game.SoundService.Effect)
			end
		end,
		["Convergence"] = function(p41, p42)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v43 = p41:FindFirstChild("HumanoidRootPart")
			if v43 then
				if p42 then
					v_u_12:PlaySound(v_u_8.Choso.BloodMerge, v43, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_8.Choso.Convergence, v43, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Interp"] = function(p_u_44)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_2
			local v_u_45 = p_u_44.CFrame
			local v_u_46 = tick()
			local v_u_47 = p_u_44:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_45, (copy) p_u_44, (ref) v_u_46
				v_u_45 = p_u_44.CFrame
				v_u_46 = tick()
			end)
			v_u_12:PlaySound(v_u_8.Choso.PiercingBlood.Fire, p_u_44, game.SoundService.Effect)
			v_u_12:PlaySound(v_u_8.Choso.PiercingBlood.Pressure2, p_u_44, game.SoundService.Effect)
			local v_u_48 = nil
			v_u_48 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_44, (ref) v_u_48, (copy) v_u_47, (ref) v_u_45, (ref) v_u_46
				if p_u_44.Parent then
					workspace:BulkMoveTo({ p_u_44 }, { v_u_45 + v_u_45.LookVector * (p_u_44:GetAttribute("Speed") * (tick() - v_u_46)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_48:Disconnect()
					v_u_47:Disconnect()
				end
			end)
		end,
		["HomingHit"] = function(p49)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v50 = p49:FindFirstChild("HumanoidRootPart")
			if v50 then
				v_u_12:Flash(p49, Color3.new(1, 0, 0))
				v_u_12:PlaySound(v_u_8.Choso.PiercingBlood.Hit, v50, game.SoundService.Effect)
				local v51 = v_u_7.Hakari.RoughHit:Clone()
				v51.Glow.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v51.Sparks.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v51.Wind.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v51.Wind2.Color = ColorSequence.new(Color3.fromRGB(150, 0, 0))
				v51.PointLight.Color = Color3.fromRGB(150, 0, 0)
				v51.Position = v50.Position
				v51.Parent = workspace.Effects
				v_u_3:AddItem(v51, 1)
				v_u_4:Create(v51.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v51.Glow:Emit(1)
				v51.Sparks:Emit(50)
				v51.Wind:Emit(7)
				v51.Wind2:Emit(7)
			end
		end,
		["Chat"] = function(p_u_52)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v53 = p_u_52:FindFirstChild("Torso")
			if v53 then
				v_u_12:PlaySound(v_u_8.Choso.Awaken, v53, game.SoundService.Effect)
				task.spawn(function()
					-- upvalues: (ref) v_u_5, (copy) p_u_52, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
					task.wait(0.7)
					if v_u_5.Character == p_u_52 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					end
					local v54 = v_u_7.Choso.Switch:Clone()
					v54.Parent = p_u_52.Head
					v_u_4:Create(v54, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
						["Size"] = UDim2.new(15, 0, 15, 0)
					}):Play()
					local v55 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					v_u_4:Create(v54.Eye1, v55, {
						["Size"] = UDim2.new(0.3, 0, 0, 0),
						["ImageTransparency"] = 1
					}):Play()
					v_u_4:Create(v54.Eye2, v55, {
						["Size"] = UDim2.new(0.6, 0, 0, 0),
						["ImageTransparency"] = 1
					}):Play()
					v_u_4:Create(v54.Eye3, v55, {
						["Size"] = UDim2.new(0.3, 0, 0, 0),
						["ImageTransparency"] = 1
					}):Play()
					v_u_3:AddItem(v54, 0.5)
					local v_u_56 = v_u_7.Choso.BloodSpread:Clone()
					v_u_56.Parent = p_u_52.Head
					v_u_56:Emit(80)
					v_u_3:AddItem(v_u_56, 3)
					task.delay(1.1, function()
						-- upvalues: (copy) v_u_56, (ref) v_u_5, (ref) p_u_52, (ref) v_u_9
						v_u_56.Drag = 0
						v_u_56.Acceleration = Vector3.new(0, -70, 0)
						v_u_56.Brightness = 0.5
						if v_u_5.Character == p_u_52 then
							v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						end
					end)
					for v57 = 1, 3 do
						local v_u_58 = v_u_7.Choso.Brother:Clone()
						v_u_58.HumanoidRootPart.Weld.Part0 = p_u_52.HumanoidRootPart
						v_u_58.Parent = workspace.Effects
						v_u_3:AddItem(v_u_58, 1)
						for _, v59 in v_u_58:GetDescendants() do
							if v59:IsA("BasePart") or v59:IsA("Decal") then
								local v60 = v59.Transparency
								v59.Transparency = 1
								v_u_4:Create(v59, TweenInfo.new(0.3), {
									["Transparency"] = v60
								}):Play()
							end
						end
						local v61 = v_u_58.HumanoidRootPart.Weld
						local v62 = v61.C0
						local v63 = CFrame.Angles
						local v64 = v57 == 1 and -35 or (v57 == 2 and 35 or 0)
						v61.C0 = v62 * v63(0, math.rad(v64), 0)
						v_u_58.AnimationController:LoadAnimation(v_u_58.AnimationController.Animation):Play()
						task.delay(0.6, function()
							-- upvalues: (copy) v_u_58, (ref) v_u_4
							for _, v65 in v_u_58:GetDescendants() do
								if v65:IsA("BasePart") or v65:IsA("Decal") then
									v_u_4:Create(v65, TweenInfo.new(0.4), {
										["Transparency"] = 1
									}):Play()
								end
							end
						end)
						task.wait(0.2)
					end
				end)
				local v66 = v_u_7.Choso.Dialogue:Clone()
				v66.Parent = v53
				local v67 = v66.Text1.Position
				v66.Text1.Position = v67 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v66.Text1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v67
				}):Play()
				v_u_4:Create(v66.Text1, TweenInfo.new(0.5), {
					["TextTransparency"] = 0
				}):Play()
				v_u_4:Create(v66.Text1.UIStroke, TweenInfo.new(0.5), {
					["Transparency"] = 0
				}):Play()
				task.wait(0.7)
				local v68 = v66.Chat1.Position
				v66.Chat1.Position = v68 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v66.Chat1, TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v68
				}):Play()
				v_u_4:Create(v66.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v66.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(1.25)
				v_u_3:AddItem(v66, 0.6)
				for _, v69 in v66:GetDescendants() do
					if v69:IsA("Frame") then
						v_u_4:Create(v69, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = v69.Position - UDim2.new(0, 0, 0.2, 0),
							["BackgroundTransparency"] = 1
						}):Play()
					elseif v69:IsA("TextLabel") then
						v_u_4:Create(v69, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
						if v69:FindFirstChild("UIStroke") then
							v_u_4:Create(v69:FindFirstChild("UIStroke"), TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["Transparency"] = 1
							}):Play()
						end
					end
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p71, ...)
		-- upvalues: (copy) v_u_70
		local v72 = v_u_70[p71]
		if v72 then
			v72(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p73, p74, p75)
		-- upvalues: (ref) v_u_11, (ref) v_u_4
		local v76 = p74.HumanoidRootPart
		if not v76 then
			return
		end
		local v77 = nil
		while true do
			local v78 = v_u_11:SphereHitbox(p74, CFrame.new(0, 0, -4), 8)
			for _, v79 in v78 do
				local v80 = v79:FindFirstChild("Info")
				if v80 then
					local v81 = v80:FindFirstChild("Knockback")
					if not v81 or v81.Value ~= false then
						v77 = v78
						break
					end
				end
			end
			if v77 then
				local v82 = p73:FindFirstChildWhichIsA("NumberValue")
				if v82 then
					v_u_4:Create(v82, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p73.Parent then
				break
			end
		end
		p75:FireServer(v77, v76.CFrame)
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("ChosoService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13