-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "kick",
	["Description"] = "Removes the player from the server",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"Mod"
	},
	["Args"] = {
		{
			["Type"] = "player",
			["Name"] = "Player"
		},
		{
			["Type"] = "string",
			["Name"] = "Reason",
			["Optional"] = true
		}
	}
}
return v1