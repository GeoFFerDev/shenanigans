-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "RabbitEscapeController"
})
local v_u_13 = RaycastParams.new()
v_u_13.FilterType = Enum.RaycastFilterType.Include
v_u_13.FilterDescendantsInstances = { workspace.Map, workspace.Spawns, workspace.Domains }
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_13, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (ref) v_u_10
	local v_u_57 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Start, v15, game.SoundService.Effect)
			end
		end,
		["Rab"] = function(p16, p_u_17, p_u_18)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_8, (ref) v_u_11, (ref) v_u_2
			local v_u_19 = p16:FindFirstChild("HumanoidRootPart")
			if v_u_19 then
				local v_u_20 = v_u_7.Megumi.Rabbit:Clone()
				v_u_20.Parent = workspace.Effects
				v_u_20.Size = Vector3.new(11, 2, 11)
				v_u_20.Color = Color3.new(0, 0, 0)
				v_u_4:Create(v_u_20, TweenInfo.new(0.1), {
					["Size"] = v_u_7.Megumi.Rabbit.Size,
					["Color"] = Color3.new(1, 1, 1)
				}):Play()
				local v21 = v_u_7.Megumi.Shadow:Clone()
				v21.Parent = workspace.Effects
				v21.Dive.Enabled = false
				v21.Shadow.Enabled = false
				v_u_3:AddItem(v21, 1)
				local v22 = workspace:Raycast(p_u_17 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0), v_u_13)
				if v22 then
					p_u_17 = v22.Position
					v21.CFrame = CFrame.new(p_u_17, p_u_17 + v22.Normal)
					v21.Shadow:Emit(4)
					v21.Dive:Emit(1)
				else
					v21.Position = p_u_17
					v21.ShadowAir:Emit(4)
				end
				local v_u_23 = tick()
				local v24 = math.random(-40, 40) / 10
				local v25 = math.random(-40, 40) / 10
				local v_u_26 = Vector3.new(v24, 0, v25)
				local v_u_27 = 1
				local v_u_28 = math.random(5, 13) / 10
				v_u_20.CFrame = CFrame.new(p_u_17, v_u_19.Position - Vector3.new(0, 3, 0))
				v_u_8.Megumi.Rabbit.Spawn.PlaybackSpeed = math.random(80, 120) / 100
				v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Spawn, v_u_20, game.SoundService.Effect)
				local v_u_29 = nil
				v_u_29 = v_u_2.Stepped:Connect(function(_, p30)
					-- upvalues: (copy) v_u_23, (copy) v_u_19, (copy) p_u_18, (ref) v_u_29, (ref) v_u_4, (copy) v_u_20, (ref) v_u_11, (ref) v_u_8, (ref) v_u_3, (copy) v_u_26, (ref) p_u_17, (ref) v_u_13, (ref) v_u_28, (ref) v_u_27
					local v31 = tick() - v_u_23
					if v_u_19.Parent and p_u_18 + 0.4 > v31 then
						local v32 = v_u_19.Position - Vector3.new(0, 3, 0) + v_u_26
						local v33 = CFrame.new(p_u_17, v32).LookVector
						local v34 = p_u_17:Lerp(v32, v31 / p_u_18)
						local v35 = workspace:Raycast(v34 + Vector3.new(0, 2, 0), Vector3.new(0, -8, 0), v_u_13)
						local v36 = CFrame.new
						local v37 = v34 + v33
						local v38 = v_u_28 / 2
						local v39 = v36(v34, v37 + Vector3.new(0, v38, 0))
						if v35 then
							v39 = v39 - v39.Position + v35.Position
						end
						v_u_28 = v_u_28 - 10 * p30
						v_u_27 = v_u_27 + v_u_28
						if v_u_27 <= 0 then
							v_u_27 = 1
							v_u_28 = math.random(5, 13) / 10
						end
						v_u_20.CFrame = v39
						if v35 then
							local v40 = v_u_20
							local v41 = v_u_27
							v40.CFrame = v40.CFrame + Vector3.new(0, v41, 0)
						end
					else
						v_u_29:Disconnect()
						v_u_4:Create(v_u_20, TweenInfo.new(0.1), {
							["Color"] = Color3.new(0, 0, 0)
						}):Play()
						v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Despawn, v_u_20, game.SoundService.Effect)
						task.wait(0.1)
						v_u_20.Decal:Destroy()
						v_u_20.Transparency = 1
						v_u_20.Despawn:Emit(3)
						v_u_3:AddItem(v_u_20, 0.6)
					end
				end)
			end
		end,
		["Hit"] = function(p42)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7
			local v43 = p42:FindFirstChild("HumanoidRootPart")
			if v43 then
				v_u_11:Flash(p42, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 4)), v43, game.SoundService.Effect)
				if p42:GetAttribute("Dead") then
					local v44 = nil
					for _, v45 in p42:GetChildren() do
						if v_u_7.Damage.Skeleton:FindFirstChild(v45.Name) and v45.Transparency == 0 then
							v44 = v45
						end
					end
					if not v44 then
						return
					end
					v44.Transparency = 1
					local v46 = v_u_7.Damage.Skeleton:FindFirstChild(v44.Name):Clone()
					local v47 = Instance.new("Weld", v46)
					v47.Part0 = v44
					v47.Part1 = v46
					v46.Parent = v44
					v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Eat, v43, game.SoundService.Effect)
				end
			end
		end,
		["Hit2"] = function(p48, p49)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v50 = p49:FindFirstChild("HumanoidRootPart")
			if v50 then
				v_u_11:Flash(p49, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Hakari.EnergySurge.Hit2, v50, game.SoundService.Effect)
				if v_u_5 == p48 or v_u_5.Character == p49 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Launch"] = function(p51)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v_u_52 = p51:FindFirstChild("HumanoidRootPart")
			if v_u_52 then
				v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Spawn, v_u_52, game.SoundService.Effect)
				local v53 = v_u_7.Megumi.RabbitLaunch:Clone()
				v53.CFrame = v_u_52.CFrame - Vector3.new(0, 2, 0)
				v53.Parent = workspace.Effects
				v_u_3:AddItem(v53, 3)
				v_u_4:Create(v53, TweenInfo.new(0.2), {
					["CFrame"] = v_u_52.CFrame + Vector3.new(0, 5, 0)
				}):Play()
				task.wait(0.2)
				for _, v_u_54 in v53:GetChildren() do
					local v55 = v_u_54:FindFirstChildWhichIsA("ManualWeld")
					if v55 then
						v55:Destroy()
					end
					v_u_54.CollisionGroup = "Effects"
					v_u_54.CanCollide = true
					local v56 = math.random(60, 80)
					v_u_54.Velocity = Vector3.new(0, v56, 0)
					task.delay(math.random(150, 200) / 100, function()
						-- upvalues: (ref) v_u_11, (ref) v_u_8, (copy) v_u_52, (ref) v_u_4, (copy) v_u_54
						v_u_11:PlaySound(v_u_8.Megumi.Rabbit.Despawn, v_u_52, game.SoundService.Effect)
						v_u_4:Create(v_u_54, TweenInfo.new(0.5), {
							["Size"] = v_u_54.Size * Vector3.new(0, 1, 1),
							["Color"] = Color3.new(0, 0, 0)
						}):Play()
						task.wait(0.5)
						v_u_4:Create(v_u_54, TweenInfo.new(0.5), {
							["Transparency"] = 1
						}):Play()
					end)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p58, ...)
		-- upvalues: (copy) v_u_57
		local v59 = v_u_57[p58]
		if v59 then
			v59(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("RabbitEscapeService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12