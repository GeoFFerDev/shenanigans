-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "RapidPunchesController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_21 = {
		["Hit"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:Flash(p12, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 4)), v13, game.SoundService.Effect)
			end
		end,
		["FinalHit"] = function(p14)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_10:Flash(p14, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit4"), v15, game.SoundService.Effect)
			end
		end,
		["BlackFlashHit"] = function(p16, p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			if p16:FindFirstChild("HumanoidRootPart") then
				local v18 = p17:FindFirstChild("HumanoidRootPart")
				if v18 then
					local v_u_19 = v_u_6.Itadori.DivergentFist.BlackFlashHit:Clone()
					v_u_19.Position = v18.Position
					v_u_19.Parent = workspace.Effects
					v_u_2:AddItem(v_u_19, 1)
					v_u_10:Flash(p17, Color3.new(1, 0, 0))
					v_u_10:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlashHit, v18, game.SoundService.Effect)
					v_u_19.Wind2:Emit(8)
					v_u_3:Create(v_u_19.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_19
						v_u_19.Blast:Emit(8)
						v_u_19.Sparks:Emit(15)
						v_u_19.Lightning:Emit(6)
						v_u_19.Wind:Emit(7)
					end)
					if v_u_4.Character == p16 or v_u_4.Character == p17 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						local v20 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v20.Parent = game.Lighting
						task.wait(0.04)
						v20.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v20.Brightness = 200
						v20.Contrast = -1000
						task.wait(0.04)
						v20:Destroy()
					end
				end
			else
				return
			end
		end
	}
	v_u_9.Effects:Connect(function(p22, ...)
		-- upvalues: (copy) v_u_21
		local v23 = v_u_21[p22]
		if v23 then
			v23(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("RapidPunchesService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11