-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
require(v6.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "DismantleV2Controller"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (ref) v_u_10
	local v_u_40 = {
		["Start"] = function(p14, p15)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_11:PlaySound(v_u_8.Heian.Dismantle.Start, v16, game.SoundService.Effect)
				if p14:GetAttribute("Moveset") == "Heian" then
					if p15 == 1 then
						v_u_11:PlaySound(v_u_8.Heian.Dismantle1, v16, game.SoundService.Voice)
					elseif p15 == 3 then
						v_u_11:PlaySound(v_u_8.Heian.Dismantle3, v16, game.SoundService.Voice)
					end
				else
					return
				end
			else
				return
			end
		end,
		["Interp"] = function(_, p_u_17)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_2
			local v_u_18 = p_u_17.CFrame
			local v_u_19 = tick()
			local v_u_20 = p_u_17:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_18, (copy) p_u_17, (ref) v_u_19
				v_u_18 = p_u_17.CFrame
				v_u_19 = tick()
			end)
			v_u_11:PlaySound(v_u_8.Heian.Dismantle.Fire, p_u_17, game.SoundService.Effect)
			local v_u_21 = nil
			v_u_21 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_17, (ref) v_u_21, (copy) v_u_20, (ref) v_u_18, (ref) v_u_19
				if p_u_17.Parent then
					workspace:BulkMoveTo({ p_u_17 }, { v_u_18 + v_u_18.LookVector * (300 * (tick() - v_u_19)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_21:Disconnect()
					v_u_20:Disconnect()
				end
			end)
		end,
		["Hit"] = function(p22)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			if v23 then
				v_u_11:Flash(p22, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Heian.Dismantle.Hit, v23, game.SoundService.Effect)
				if v_u_5.Character == p22 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Hit2"] = function(p24)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				v_u_11:Flash(p24, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Slash, v25, game.SoundService.Effect)
			end
		end,
		["DismantleSweep"] = function(p26)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v28 = v_u_7.Heian.Sweep:Clone()
				v28.CFrame = v27.CFrame
				v28.Weld.Part0 = v27
				v28.Parent = workspace.Effects
				v_u_3:AddItem(v28, 2.5)
				v_u_4:Create(v28.Attachment.Dust, TweenInfo.new(1), {
					["TimeScale"] = 1
				}):Play()
				v_u_4:Create(v28.Attachment.Ring, TweenInfo.new(1), {
					["TimeScale"] = 1
				}):Play()
				v_u_4:Create(v28.Slashes, TweenInfo.new(0.75, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
					["TimeScale"] = 1
				}):Play()
				if p26:GetAttribute("Moveset") == "Heian" then
					v_u_11:PlaySound(v_u_8.Heian.Dismantle2, v27, game.SoundService.Voice)
				end
				local v29
				if v_u_5.Character == p26 then
					v29 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
					v29:StartFadeIn(0.75)
				else
					v29 = nil
				end
				local v30 = v_u_11:PlaySound(v_u_8.Heian.Slashes2, v27, game.SoundService.Effect)
				v_u_4:Create(v30, TweenInfo.new(0.75), {
					["Volume"] = 2.5
				}):Play()
				local v31 = tick()
				repeat
					v_u_11:PlaySound(v_u_8.Heian.Dismantle.Fire, v27, game.SoundService.Effect)
					task.wait(0.075)
				until not v27.Parent or (tick() - v31 > 0.75 or p26:GetAttribute("Dead"))
				if v27.Parent and not p26:GetAttribute("Dead") then
					v28.Attachment.Dust.Enabled = false
					v28.Attachment.Ring.Enabled = false
					v28.Slashes.Enabled = false
					v28.Break:Emit(30)
					v28.Stars:Emit(20)
					if v30 then
						v_u_4:Create(v30, TweenInfo.new(0.5), {
							["Volume"] = 0
						}):Play()
					end
					if v29 then
						v29:StartFadeOut(0.5)
					end
					v_u_11:PlaySound(v_u_8.Itadori.Rush.RushLaunch, v27, game.SoundService.Effect)
					if (workspace.CurrentCamera.CFrame.Position - v27.Position).Magnitude < 100 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
						local v32 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v32.TintColor = Color3.new(1, 1, 1)
						v32.Parent = game.Lighting
						task.wait(0.04)
						v32.Brightness = 200
						v32.Contrast = -1000
						task.wait(0.04)
						v32:Destroy()
					end
				end
			else
				return
			end
		end,
		["Split"] = function(p33)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7
			local v34 = p33:FindFirstChild("HumanoidRootPart")
			if v34 then
				v_u_11:Flash(p33, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Slash, v34, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Explode, v34, game.SoundService.Effect)
				v_u_11:Bleed(p33)
				if v_u_5.Character == p33 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v35 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
					v35.TintColor = Color3.new(1, 1, 1)
					v35.Parent = game.Lighting
					task.wait(0.04)
					v35.Brightness = 200
					v35.Contrast = -1000
					task.wait(0.04)
					v35:Destroy()
				end
			end
		end,
		["WCS"] = function(p36)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4
			task.spawn(function()
				-- upvalues: (ref) v_u_9, (ref) v_u_7
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				if not workspace:GetAttribute("Creator") then
					local v37 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
					v37.TintColor = Color3.new(1, 1, 1)
					v37.Parent = game.Lighting
					task.wait(0.02)
					v37.Brightness = 200
					v37.Contrast = -1000
					task.wait(0.02)
					v37:Destroy()
				end
			end)
			local v38 = v_u_7.Heian.WorldSlash:Clone()
			v38.CFrame = p36
			v38.Parent = workspace.Effects
			local v39 = Instance.new("Highlight", v38.Slash)
			v39.DepthMode = Enum.HighlightDepthMode.Occluded
			v39.FillTransparency = 0
			v39.FillColor = Color3.new(0, 0, 0)
			v_u_3:AddItem(v38, 4.1)
			v_u_11:PlaySound(v_u_8.Heian.Dismantle.FireWCS, v38, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_8.Heian.Dismantle.Fire, v38, game.SoundService.Effect)
			v38.Smear:Emit(200)
			v38.Dust:Emit(200)
			v_u_4:Create(v38.Slash, TweenInfo.new(0.2), {
				["Size"] = Vector3.new(0, 0, 500)
			}):Play()
			v_u_4:Create(v38.Weld, TweenInfo.new(0.2), {
				["C1"] = CFrame.new(0, 0, 0)
			}):Play()
			task.wait(0.2)
			v38.slashenabled3.Enabled = false
			v38.slashenabled4.Enabled = false
			v38.Stars:Emit(100)
		end
	}
	v_u_10.Effects:Connect(function(p41, ...)
		-- upvalues: (copy) v_u_40
		local v42 = v_u_40[p41]
		if v42 then
			v42(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("DismantleV2Service")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("ToolController")
end
return v13