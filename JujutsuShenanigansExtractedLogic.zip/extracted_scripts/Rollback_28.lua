-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "rollback",
	["Description"] = "Rollback their build data by the specified versions",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"Mod"
	},
	["Args"] = {
		{
			["Type"] = "username",
			["Name"] = "Username"
		},
		{
			["Type"] = "number",
			["Name"] = "Slot"
		},
		{
			["Type"] = "number",
			["Name"] = "Versions"
		}
	}
}
return v1