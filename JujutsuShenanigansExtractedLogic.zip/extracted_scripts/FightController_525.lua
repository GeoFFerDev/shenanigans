-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v2 = game.ReplicatedStorage
local v3 = v2.Animations
local v4 = v2.Utils
local _ = v2.Sounds
require(v2.Modules.CameraShaker)
local v5 = require(v2.Modules.SraikoVFX)
require(v2.TEMP_CHARA_STUFF.VelocityHandler)
local v_u_6 = require(v2.TEMP_CHARA_STUFF.AnimationRetriever)
local v_u_7 = require(v2.TEMP_CHARA_STUFF.EffectUtility)
local v_u_8 = require(v2.TEMP_CHARA_STUFF.CameraShake)
local v_u_9 = require(v2.TEMP_CHARA_STUFF.Vignette)
require(v2.TEMP_CHARA_STUFF.RockHandler)
require(v2.TEMP_CHARA_STUFF.Smoke)
local v_u_10 = require(script.Fight_UI)
local v_u_11 = require(script.Finisher.quickutil)
local v_u_12 = require(v2.TEMP_CHARA_STUFF.RunCameraRig)
require(v2.TEMP_CHARA_STUFF.ColorCorrection)
local v_u_13 = require(v2.TEMP_CHARA_STUFF.Vignette2)
require(v2.TEMP_CHARA_STUFF.ViewportManager)
local v_u_14 = require(v2.TEMP_CHARA_STUFF.MoonUtil)
local _ = v5.Enabled
local _ = v5.Emit
local _ = v5.EmitMesh
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v18 = v_u_1.CreateController({
	["Name"] = "FightController"
})
local v_u_19 = v3.Misc.C.Fight
local v_u_20 = game:GetService("Players").LocalPlayer
local _ = v4.Misc.C.Chara
local v_u_21 = v_u_7.Distance_Far
local v_u_22 = v_u_7.Distance_Close
function v18.KnitStart(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_19, (copy) v_u_7, (copy) v_u_20, (copy) v_u_10, (copy) v_u_22, (copy) v_u_8, (copy) v_u_9, (copy) v_u_13, (copy) v_u_12, (copy) v_u_14, (copy) v_u_11, (copy) v_u_21, (ref) v_u_15
	local v_u_104 = {
		["Start"] = function(p23)
			-- upvalues: (ref) v_u_6, (ref) v_u_19, (ref) v_u_7
			local v24 = v_u_6.new(p23, v_u_19.Windup)
			if v24 ~= nil then
				script.StartupSFX.PlaybackSpeed = v24.Animation.Speed
				v24.Job:Task(v_u_7.AddSFX(script.StartupSFX, v24.Torso, 0.3))
			end
		end,
		["Hit"] = function(p_u_25)
			-- upvalues: (ref) v_u_6, (ref) v_u_19, (ref) v_u_7, (ref) v_u_20, (ref) v_u_10, (ref) v_u_22, (ref) v_u_8, (ref) v_u_9
			local v26 = v_u_6.new(p_u_25, v_u_19.Hit)
			if v26 ~= nil then
				local v27 = v26.Torso
				local v28 = v26.RootPart
				local v29 = v26.Animation
				local v_u_30 = v26.Job
				script.HitSFX.PlaybackSpeed = v29.Speed
				v_u_30:Task(v_u_7.AddSFX(script.HitSFX, v27, 0.3))
				if v_u_20.Character == p_u_25 then
					v_u_30:Task(v29:GetMarkerReachedSignal("attack"):Once(function()
						-- upvalues: (copy) p_u_25, (ref) v_u_10, (copy) v_u_30
						local v31 = p_u_25:FindFirstChild("CharaFightRemote")
						if v31 ~= nil then
							v_u_10(p_u_25, v31, v_u_30)
						end
					end))
				end
				v_u_30:Task(v29:GetMarkerReachedSignal("vfx"):Connect(function(p32)
					-- upvalues: (ref) v_u_7, (copy) p_u_25, (ref) v_u_22, (ref) v_u_8, (ref) v_u_9
					local v33 = script.Assets:FindFirstChild(p32)
					if v33 then
						v_u_7.CloneAndEmit(v33, p_u_25[v33:GetAttribute("attached")])
					end
					if v_u_22(p_u_25) then
						if p32 == "1" then
							v_u_8(1, 15, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.4, 0.4, 0.4))
							v_u_9(Color3.fromRGB(255, 0, 0), 0.8, 0.2)
							return
						end
						if p32 == "2" then
							v_u_8(1, 15, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.4, 0.4, 0.4))
							v_u_9(Color3.fromRGB(255, 0, 0), 0.8, 0.2)
						end
					end
				end))
				v_u_7.CloneAndEmit(script.Assets["1"], v28)
				if v_u_22(p_u_25) then
					v_u_8(1.25, 22.5, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
					v_u_9(Color3.fromRGB(255, 0, 0), 0.6, 0.25)
				end
			end
		end,
		["Finisher"] = function(p_u_34, p_u_35)
			-- upvalues: (ref) v_u_6, (ref) v_u_19, (ref) v_u_20, (ref) v_u_7, (ref) v_u_13, (ref) v_u_12, (ref) v_u_14, (ref) v_u_11
			local v36 = v_u_6.new(p_u_34, v_u_19.Finisher)
			if v36 ~= nil then
				local v_u_37 = v36.Torso
				local v_u_38 = v36.RootPart
				local v_u_39 = v36.Animation
				local v_u_40 = v36.Job
				local v_u_41 = table.find({ p_u_34, p_u_35 }, v_u_20.Character)
				local function v44(p42, p43, ...)
					-- upvalues: (copy) v_u_40, (copy) v_u_39
					return v_u_40:Task(task.delay(p42 / 60 - v_u_39.TimePosition, p43, ...))
				end
				if v_u_41 then
					local v_u_45 = {}
					local v_u_46 = script.Finisher.Camera:Clone()
					local v_u_47 = script.Finisher.Camera:GetPivot()
					v_u_46.Parent = workspace.Effects
					local v48 = v_u_46.Humanoid.Animator:LoadAnimation(v_u_19.FinisherCamera)
					v48:Play(0, nil, v_u_39.Speed)
					v_u_46.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_45
						for _, v49 in v_u_45 do
							v49:Disconnect()
						end
						task.defer(function()
							workspace.CurrentCamera.FieldOfView = 70
						end)
					end)
					local v50 = v48.Stopped
					table.insert(v_u_45, v50:Once(function()
						-- upvalues: (copy) v_u_46
						v_u_46:Destroy()
					end))
					v_u_40:Task(v_u_39:GetMarkerReachedSignal("cut"):Connect(function()
						-- upvalues: (copy) v_u_46
						v_u_46:Destroy()
					end))
					local v51 = p_u_34:GetAttributeChangedSignal("FightFinisherCamera")
					table.insert(v_u_45, v51:Connect(function()
						-- upvalues: (copy) v_u_46
						v_u_46:Destroy()
					end))
					local v_u_52 = v_u_40:Task(script.Finisher.Atmosphere:Clone())
					v44(164, function()
						-- upvalues: (ref) v_u_13
						v_u_13({
							["TweenIn"] = { 0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out },
							["TweenOut"] = { 0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out },
							["LifeTime"] = 0.35,
							["Size"] = UDim2.fromScale(1.25, 1.25),
							["Transparency"] = 0.5,
							["Color"] = Color3.new(1, 0.227451, 0.227451)
						})
					end)
					v44(167, function()
						-- upvalues: (copy) v_u_40, (ref) v_u_12, (copy) v_u_38, (copy) v_u_46, (copy) v_u_47, (copy) v_u_45, (ref) v_u_14, (ref) v_u_52
						v_u_40:Task(v_u_12(v_u_38, v_u_46, v_u_47))
						local v53 = v_u_45
						local v54 = v_u_14.AnimateValueWithMoonFile
						local v55 = workspace.CurrentCamera
						local v56 = script.Finisher.FOV
						table.insert(v53, v54(v55, "FieldOfView", v56))
						v_u_52.Parent = game.Lighting
					end)
					v44(260, function()
						-- upvalues: (ref) v_u_13
						v_u_13({
							["TweenIn"] = { 0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out },
							["TweenOut"] = { 0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out },
							["LifeTime"] = 1,
							["Size"] = UDim2.fromScale(1.45, 1.45),
							["Transparency"] = 0.5,
							["Color"] = Color3.new(1, 0.227451, 0.227451)
						})
					end)
					v44(420, function()
						-- upvalues: (ref) v_u_11, (ref) v_u_52, (ref) v_u_13, (copy) v_u_40, (copy) v_u_38
						v_u_11:tween_single(v_u_52, 0.5, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["Density"] = 0
						})
						v_u_13({
							["TweenIn"] = { 0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out },
							["TweenOut"] = { 0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out },
							["LifeTime"] = 1.8,
							["Size"] = UDim2.fromScale(1.25, 1.25),
							["Transparency"] = 0.25,
							["Color"] = Color3.new()
						})
						local v_u_57 = v_u_40:Task(script.Finisher.background:Clone())
						v_u_57.CFrame = v_u_38.CFrame * CFrame.new(0.000156668946, -0.000406742096, -81.9370956, 1, -1.77635684e-15, 1.32348898e-23, -1.77635684e-15, 1, -8.8817842e-16, 1.32348898e-23, -8.8817842e-16, 1)
						v_u_57.Parent = workspace.Effects
						task.delay(1.8, function()
							-- upvalues: (copy) v_u_57
							v_u_57:Destroy()
						end)
						task.wait(0.1)
						v_u_57.Transparency = 1
						v_u_57.floor.Transparency = 1
						task.wait(0.1)
						v_u_57.Transparency = 0
						v_u_57.floor.Transparency = 0
					end)
					v44(439, function()
						-- upvalues: (copy) v_u_40, (copy) v_u_38, (ref) v_u_11
						local v_u_58 = v_u_40:Task(script.Finisher.fightbar:Clone())
						v_u_58.CFrame = v_u_38.CFrame * CFrame.new(-0.0158433318, -12.9794064, -68.0022964, 1, -1.77635684e-15, 1.32348898e-23, -1.77635684e-15, 1, -8.8817842e-16, 1.32348898e-23, -8.8817842e-16, 1)
						v_u_58.Parent = workspace.Effects
						v_u_11:interact(v_u_58, "ImageLabel", "ImageTransparency", 1)
						v_u_11:tween_single(v_u_58, 1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["CFrame"] = v_u_58.CFrame * CFrame.new(0, 20, 0)
						})
						v_u_11:tween_descendant(v_u_58, "ImageLabel", 1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["ImageTransparency"] = 0
						})
						v_u_11:tween_single(v_u_58.lineweld, 0.85, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, {
							["C0"] = v_u_58.lineweld.C0 * CFrame.new(-22.19, 0, 0)
						})
						task.delay(0.87, function()
							-- upvalues: (copy) v_u_58
							v_u_58:Destroy()
						end)
					end)
					v44(490, function() end)
					v44(526, function()
						-- upvalues: (ref) v_u_13
						v_u_13({
							["TweenIn"] = { 0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out },
							["TweenOut"] = { 0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out },
							["LifeTime"] = 0.35,
							["Size"] = UDim2.fromScale(1.45, 1.45),
							["Transparency"] = 0.5,
							["Color"] = Color3.new(1, 0.227451, 0.227451)
						})
					end)
					v44(528, function()
						-- upvalues: (ref) v_u_52
						v_u_52.Density = 0.3
					end)
				end
				v44(164, function()
					-- upvalues: (copy) v_u_40, (copy) v_u_38, (ref) v_u_7
					local v59 = v_u_40
					local v60 = v_u_38
					local v61 = script.Finisher.yo:Clone()
					v61.Parent = v60
					v_u_7.Emit(v61)
					v59:Task(v61)
					local v62 = v_u_40
					local v63 = v_u_38
					local v64 = script.Finisher.cut:Clone()
					v64.Parent = v63
					v_u_7.Emit(v64)
					v62:Task(v64)
				end)
				v44(167, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_41, (copy) v_u_37
					local v65 = v_u_7.AddSFX
					local v66 = script.FinisherSFX
					local v67
					if v_u_41 then
						v67 = workspace
					else
						v67 = v_u_37
					end
					v65(v66, v67, 0.3)
				end)
				v44(195, function()
					-- upvalues: (copy) p_u_34, (copy) v_u_40
					local v68 = p_u_34.SetAssets:FindFirstChild("RealKnife")
					if v68 then
						local v_u_69 = v68.Handle.BladeAttachment.Trail
						v_u_69.Enabled = true
						v_u_40:Task(function()
							-- upvalues: (copy) v_u_69
							v_u_69.Enabled = false
						end)
					end
				end)
				v44(260, function()
					-- upvalues: (copy) v_u_40, (ref) v_u_11, (copy) p_u_34
					local v_u_70 = v_u_40:Task(script.Finisher.speed:Clone())
					v_u_70.Parent = workspace.Effects
					v_u_11:follow_cframe(p_u_34.Torso, v_u_70, 11)
					local v71 = v_u_40:Task(script.Finisher.meshes.speedblitz:Clone())
					v_u_11:follow_cframe(p_u_34.Torso, v71.RootPart, 11)
					v_u_11:mesh_enable(nil, v71, true, false, nil, nil, 3, 0.1, false)
					v_u_40:Task(task.delay(0.3, function()
						-- upvalues: (ref) v_u_11, (copy) v_u_70
						v_u_11:interact(v_u_70, "ParticleEmitter", "Enabled", false)
						task.wait(3)
						v_u_70:Destroy()
					end))
				end)
				v44(265, function()
					-- upvalues: (copy) p_u_34
					local v72 = p_u_34.SetAssets:FindFirstChild("RealKnife")
					if v72 then
						v72.Handle.BladeAttachment.Trail.Enabled = false
					end
				end)
				v44(270, function()
					-- upvalues: (copy) v_u_40, (copy) v_u_38, (ref) v_u_7, (ref) v_u_11
					local v73 = v_u_40
					local v74 = v_u_38
					local v75 = script.Finisher.dash:Clone()
					v75.Parent = v74
					v_u_7.Emit(v75)
					local v76 = v73:Task(v75)
					v_u_11:interact(v76, "PointLight", "Brightness", 1)
					v_u_11:tween_descendant(v76, "PointLight", 2.4, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["Brightness"] = 0
					})
					local v77 = v_u_40:Task(script.Finisher.dashbeam:Clone())
					v77.CFrame = v_u_38.CFrame * CFrame.new(0.000156549737, -0.719406605, -29.4539261, 1, -1.77635684e-15, 1.32348898e-23, -1.77635684e-15, 1, -8.8817842e-16, 1.32348898e-23, -8.8817842e-16, 1)
					v77.Parent = workspace.Effects
					v_u_11:tween_single(v77, 2, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out, {
						["CFrame"] = v77.CFrame * CFrame.new(0, 0, -28) * CFrame.Angles(0, 0, 3.141592653589793)
					})
					v_u_11:tween_descendant(v77, "Beam", 1.3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["TextureSpeed"] = 2,
						["Brightness"] = 0
					}, true)
					local v78 = v_u_40:Task(script.Finisher.reddashbeam:Clone())
					v78.CFrame = v_u_38.CFrame * CFrame.new(0.000156637281, 16.9526272, -29.4539261, 1, -1.77635684e-15, 1.32348898e-23, -1.77635684e-15, 1, -8.8817842e-16, 1.32348898e-23, -8.8817842e-16, 1)
					v78.Parent = workspace.Effects
					v_u_11:tween_single(v78, 1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out, {
						["CFrame"] = v78.CFrame * CFrame.new(0, 0, -30) * CFrame.Angles(0, 0, 3.141592653589793)
					})
					v_u_11:tween_descendant(v78, "Beam", 0.7, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["Width0"] = 0,
						["Width1"] = 0
					}, true)
				end)
				v44(317, function()
					-- upvalues: (copy) v_u_40, (copy) v_u_38, (ref) v_u_7
					local v79 = v_u_40
					local v80 = v_u_38
					local v81 = script.Finisher.throw:Clone()
					v81.Parent = v80
					v_u_7.Emit(v81)
					v79:Task(v81)
				end)
				v44(347, function()
					-- upvalues: (copy) v_u_40, (copy) v_u_38, (ref) v_u_7
					local v82 = v_u_40
					local v83 = v_u_38
					local v84 = script.Finisher.land:Clone()
					v84.Parent = v83
					v_u_7.Emit(v84)
					v82:Task(v84)
				end)
				v44(430, function()
					-- upvalues: (copy) p_u_34, (copy) p_u_35, (copy) v_u_40
					for _, v85 in { p_u_34, p_u_35 } do
						local v86 = v_u_40:Task(script.Finisher.highlight:Clone())
						v86.Parent = v85
						task.delay(1.6, v86.Destroy, v86)
					end
				end)
				local v_u_87 = nil
				local v_u_88 = nil
				v44(492, function()
					-- upvalues: (ref) v_u_87, (copy) v_u_40, (copy) p_u_35, (ref) v_u_7, (ref) v_u_11, (ref) v_u_88, (copy) v_u_38
					local v89 = v_u_40
					local v90 = script.Finisher.freezehit
					local v91 = p_u_35.HumanoidRootPart
					local v92 = v90:Clone()
					v92.Parent = v91
					v_u_7.Emit(v92)
					v_u_87 = v89:Task(v92)
					v_u_11:interact(v_u_87, "ParticleEmitter", "TimeScale", 1)
					v_u_11:tween_descendant(v_u_87, "ParticleEmitter", 0.04, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["TimeScale"] = 0
					})
					v_u_88 = v_u_40:Task(script.Finisher.freezehitstars:Clone())
					v_u_88.Join.Part0 = v_u_38
					v_u_88.Parent = workspace.Effects
					v_u_11:emit(v_u_88)
					v_u_11:interact(v_u_88, "ParticleEmitter", "TimeScale", 1)
					v_u_11:tween_descendant(v_u_88, "ParticleEmitter", 0.04, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["TimeScale"] = 0
					})
				end)
				v44(526, function()
					-- upvalues: (copy) v_u_40, (copy) v_u_38, (ref) v_u_7, (ref) v_u_87, (ref) v_u_11, (ref) v_u_88
					local v93 = v_u_40
					local v94 = v_u_38
					local v95 = script.Finisher.finalcut:Clone()
					v95.Parent = v94
					v_u_7.Emit(v95)
					v93:Task(v95)
					local v96 = v_u_40
					local v97 = v_u_38
					local v98 = script.Finisher.yofinal:Clone()
					v98.Parent = v97
					v_u_7.Emit(v98)
					v96:Task(v98)
					if v_u_87 then
						v_u_11:tween_descendant(v_u_87, "ParticleEmitter", 0.1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["TimeScale"] = 1
						})
					end
					if v_u_88 then
						v_u_11:tween_descendant(v_u_88, "ParticleEmitter", 0.04, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["TimeScale"] = 1
						})
					end
				end)
			end
		end,
		["Slash"] = function(p99, p100)
			-- upvalues: (ref) v_u_6, (ref) v_u_19, (ref) v_u_21, (ref) v_u_7, (ref) v_u_22, (ref) v_u_8, (ref) v_u_9
			local v101 = v_u_6.new(p99, v_u_19.Hit)
			if v101 ~= nil then
				local v102 = v101.Torso
				local v103 = v101.RootPart
				local _ = v101.Animation
				local _ = v101.Job
				if v_u_21(p99) then
					v_u_7.CloneAndEmit(script.Assets[p100 and "3_success" or "3_fail"], v103)
				end
				if v_u_22(p99) then
					if p100 then
						v_u_7.AddSFX(script.SuccessHitSFX, v102)
						v_u_8(2.5, 37.5, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
						v_u_9(Color3.fromRGB(255, 0, 0), 0.25, 0.4)
						return
					end
					v_u_7.AddSFX(script.MissHitSFX, v102)
					v_u_8(1.75, 27.5, 0.01, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
					v_u_9(Color3.fromRGB(255, 0, 0), 0.5, 0.4)
				end
			end
		end
	}
	v_u_15.Effects:Connect(function(p105, ...)
		-- upvalues: (ref) v_u_104
		local v106 = v_u_104[p105]
		if v106 then
			v106(...)
		end
	end)
end
function v18.KnitInit(_)
	-- upvalues: (ref) v_u_15, (copy) v_u_1, (ref) v_u_16, (ref) v_u_17
	v_u_15 = v_u_1.GetService("FightService")
	v_u_16 = v_u_1.GetController("HitboxController")
	v_u_17 = v_u_1.GetController("FXController")
end
return v18