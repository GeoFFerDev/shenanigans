-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 1,
	["SortOrder"] = 4,
	["Val"] = "DesINT",
	["Desc"] = "Interpolates the movement of destroyed parts"
}