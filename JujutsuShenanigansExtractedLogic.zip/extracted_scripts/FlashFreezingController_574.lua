-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "FlashFreezingController"
})
function v10.KnitStart(_)
	-- upvalues: (copy) v_u_3, (ref) v_u_9, (copy) v_u_6, (copy) v_u_5, (copy) v_u_2, (copy) v_u_7, (ref) v_u_8
	local v_u_25 = {
		["Frame"] = function(p11)
			-- upvalues: (ref) v_u_3, (ref) v_u_9, (ref) v_u_6
			local v12 = p11:FindFirstChild("HumanoidRootPart")
			if v12 then
				p11.Torso.Transparency = 0
				v_u_3:Create(p11.Torso, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["Transparency"] = 0.5
				}):Play()
				v_u_9:PlaySound(v_u_6.Naoya.Frame, v12, game.SoundService.Effect)
			end
		end,
		["Explode"] = function(p13)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_9, (ref) v_u_6, (ref) v_u_7, (ref) v_u_3
			local v14 = v_u_5.Naoya.NaoyaGlass:Clone()
			v14.Position = p13
			v14.Parent = workspace.Effects
			v_u_2:AddItem(v14, 2)
			v14.Transparency = 1
			v14.Part.Transparency = 1
			v14.Front.Transparency = 1
			v14.Back.Transparency = 1
			v14.Attachment.Flash:Emit(1)
			v14.Attachment.Wind:Emit(2)
			v14.Attachment.WindCircle:Emit(2)
			v14.Attachment.Shockwave:Emit(2)
			v14.Shatter:Emit(10)
			local v15 = v_u_9:PlaySound(v_u_6.Naoya.FrameBreak, v14, game.SoundService.Effect)
			v15.Volume = 0.5
			v15.PlaybackSpeed = math.random(100, 150) / 100
			if (workspace.CurrentCamera.CFrame.Position - v14.Position).Magnitude < 40 then
				v_u_7.CurrentShaker:Shake(v_u_7.Presets.Snap)
			end
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v14.Position).Magnitude > 100 then
					return
				end
				task.wait(0.1)
				local v16 = Random.new()
				local v17 = TweenInfo.new(3, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 2 do
					local v18 = v_u_5.Gojo.Shard:Clone()
					local v19 = v16:NextUnitVector().Unit
					local v20 = math.random(5, 20) / 10
					local v21 = math.random(5, 20) / 10
					v18.Size = Vector3.new(0.2, v20, v21)
					v18.CFrame = v14.CFrame * CFrame.new(math.random(-2, 2), math.random(-4, 4), 0)
					v18.CFrame = v18.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v18.CanCollide = true
					v18.CollisionGroup = "Effects"
					v18.Parent = workspace.Effects
					v18.Transparency = 0.5
					v18.Color = v14.Color
					v18.Material = Enum.Material.Neon
					local v22 = math.random(-50, 50)
					local v23 = math.random(-50, 50)
					local v24 = math.random
					v18.RotVelocity = Vector3.new(v22, v23, v24(-50, 50))
					v18.Velocity = v19 * math.random(50, 100)
					v_u_3:Create(v18, v17, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v18, 3)
				end
			end
		end
	}
	v_u_8.Effects:Connect(function(p26, ...)
		-- upvalues: (copy) v_u_25
		local v27 = v_u_25[p26]
		if v27 then
			v27(...)
		end
	end)
end
function v10.KnitInit(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_9
	v_u_8 = v_u_1.GetService("FlashFreezingService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10