-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 1,
	["SortOrder"] = 1,
	["Val"] = "AutoUse",
	["Desc"] = "Automatically use skills when pressing keys",
	["Callback"] = function(_)
		require(game.ReplicatedStorage.Knit.Knit).GetController("ToolController").Selected.Value = nil
	end
}