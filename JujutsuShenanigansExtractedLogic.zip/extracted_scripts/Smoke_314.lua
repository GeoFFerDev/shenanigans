-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("ReplicatedStorage")
local v_u_1 = Random.new()
return function(p2, p3, p4)
	-- upvalues: (copy) v_u_1
	local v5 = workspace:Raycast(p2.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0) * -(p3 or 8), _G.MapParams)
	if v5 then
		local v6 = script.Dust:Clone()
		v6.Smoke.Size = NumberSequence.new(v_u_1:NextNumber(1.45, 1.8))
		local v7 = v6.Smoke
		local v8 = ColorSequence.new
		local v9 = Color3.new
		local v10 = v5.Instance.Color.R * 0.95
		local v11 = math.clamp(v10, 0, 1)
		local v12 = v5.Instance.Color.G * 0.95
		local v13 = math.clamp(v12, 0, 1)
		local v14 = v5.Instance.Color.B * 0.95
		v7.Color = v8(v9(v11, v13, (math.clamp(v14, 0, 1))))
		v6.Position = v5.Position - Vector3.new(0, 1, 0)
		local v15 = math.random(-360, 360)
		v6.Orientation = vector.create(0, v15, 0)
		v6.Parent = workspace.Effects
		if p4 then
			v6.Size = vector.create(p4, 1, p4)
			v6.Smoke:Emit(p4 / 2 * 18)
		else
			v6.Smoke:Emit(18)
		end
		task.delay(v6.Smoke.Lifetime.Max, v6.Destroy, v6)
	end
end