-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Lighting")
game:GetService("StarterGui")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local v7 = v6.Animations
local _ = v6.Utils
local _ = v6.Sounds
v_u_5:WaitForChild("PlayerGui")
require(v6.Modules.CameraShaker)
local v8 = require(v6.Modules.SraikoVFX)
require(v6.TEMP_CHARA_STUFF.VelocityHandler)
local v_u_9 = require(v6.TEMP_CHARA_STUFF.AnimationRetriever)
local v_u_10 = require(v6.TEMP_CHARA_STUFF.EffectUtility)
local v_u_11 = require(v6.TEMP_CHARA_STUFF.CameraShake)
local v_u_12 = require(v6.TEMP_CHARA_STUFF.Vignette)
require(v6.TEMP_CHARA_STUFF.RockHandler)
require(v6.TEMP_CHARA_STUFF.Smoke)
require(v6.TEMP_CHARA_STUFF.Afterimage)
require(v6.TEMP_CHARA_STUFF.MoonUtil)
local v_u_13 = require(v6.TEMP_CHARA_STUFF.RunCameraRig)
require(v6.TEMP_CHARA_STUFF.Create_Clone)
local v_u_14 = require(v6.TEMP_CHARA_STUFF.VelocityUtil)
local v_u_15 = require(v6.TEMP_CHARA_STUFF.Utility)
local v_u_16 = require(v6.TEMP_CHARA_STUFF.Yuki_FOV)
local v_u_17 = require(v6.Modules.EffectUtils)
local v_u_18 = require(script.quickutil)
local v_u_19 = require(script.Minigame.Chara)
local _ = v8.Enabled
local _ = v8.Emit
local _ = v8.EmitMesh
local v_u_20 = {
	["Ambient"] = v_u_4.Ambient,
	["Brightness"] = v_u_4.Brightness,
	["ColorShift_Bottom"] = v_u_4.ColorShift_Bottom,
	["ColorShift_Top"] = v_u_4.ColorShift_Top,
	["ClockTime"] = v_u_4.ClockTime,
	["EnvironmentDiffuseScale"] = v_u_4.EnvironmentDiffuseScale,
	["EnvironmentSpecularScale"] = v_u_4.EnvironmentSpecularScale,
	["ExposureCompensation"] = v_u_4.ExposureCompensation,
	["FogColor"] = v_u_4.FogColor,
	["FogEnd"] = v_u_4.FogEnd,
	["FogStart"] = v_u_4.FogStart,
	["GeographicLatitude"] = v_u_4.GeographicLatitude,
	["GlobalShadows"] = v_u_4.GlobalShadows,
	["OutdoorAmbient"] = v_u_4.OutdoorAmbient,
	["ShadowSoftness"] = v_u_4.ShadowSoftness,
	["TimeOfDay"] = v_u_4.TimeOfDay
}
local function v_u_23(p21, p22)
	-- upvalues: (copy) v_u_17
	return v_u_17.AutoEffects(p21, p22)
end
local function v_u_30(p24, p_u_25, p26)
	-- upvalues: (copy) v_u_14, (copy) v_u_15, (copy) v_u_2
	local v27 = p_u_25:FindFirstChildOfClass("BodyVelocity")
	if v27 then
		v27:Destroy()
	end
	local v_u_28 = v_u_14.Create(p_u_25, p24)
	v_u_28.MaxForce = Vector3.new(80000, 0, 80000)
	v_u_28.Parent = p_u_25
	local v_u_29 = Instance.new("NumberValue")
	v_u_29.Value = p26
	v_u_29.Name = "Strength"
	v_u_29.Parent = v_u_28
	v_u_15.BindSignalDisconnectToInstanceDestroying(v_u_2.PostSimulation, v_u_28, function()
		-- upvalues: (copy) v_u_28, (copy) p_u_25, (copy) v_u_29
		v_u_28.Velocity = p_u_25.CFrame.LookVector * v_u_29.Value
	end)
	return v_u_28
end
local function v_u_34(p31, p32, p33)
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_20
	p31.ImageTransparency = 0.2
	v_u_3:Create(p31, TweenInfo.new(p33, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		["ImageTransparency"] = 1
	}):Play()
	v_u_4.Brightness = 0.45
	v_u_4.ExposureCompensation = 1
	v_u_3:Create(v_u_4, TweenInfo.new(p33, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		["Brightness"] = v_u_20.Brightness,
		["ExposureCompensation"] = v_u_20.ExposureCompensation
	}):Play()
	p32.TintColor = Color3.new(1, 0.741176, 0.741176)
	p32.Contrast = 3
	task.wait()
	p32.Contrast = 1
	v_u_3:Create(p32, TweenInfo.new(p33, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		["TintColor"] = Color3.new(1, 1, 1),
		["Contrast"] = 0
	}):Play()
end
local v_u_35 = nil
local v_u_36 = nil
local v_u_37 = nil
local v38 = v_u_1.CreateController({
	["Name"] = "AtonementController"
})
local v_u_39 = v7.Misc.C.Atonement
local v_u_40 = game:GetService("Players").LocalPlayer
local v_u_41 = script.Hit
function v38.KnitStart(_)
	-- upvalues: (copy) v_u_9, (copy) v_u_39, (copy) v_u_5, (copy) v_u_10, (copy) v_u_4, (copy) v_u_20, (copy) v_u_11, (copy) v_u_12, (copy) v_u_23, (copy) v_u_18, (copy) v_u_3, (copy) v_u_34, (copy) v_u_30, (copy) v_u_40, (copy) v_u_16, (copy) v_u_41, (copy) v_u_13, (copy) v_u_2, (copy) v_u_19, (ref) v_u_35
	local v_u_225 = {
		["Start"] = function(p_u_42)
			-- upvalues: (ref) v_u_9, (ref) v_u_39, (ref) v_u_5, (ref) v_u_10, (ref) v_u_4, (ref) v_u_20, (ref) v_u_11, (ref) v_u_12, (ref) v_u_23, (ref) v_u_18, (ref) v_u_3, (ref) v_u_34, (ref) v_u_30
			local v43 = v_u_9.new(p_u_42, v_u_39.Windup)
			if v43 ~= nil then
				local v_u_44 = v43.Torso
				local v_u_45 = v43.RootPart
				local v_u_46 = v43.Animation
				local v_u_47 = v43.Job
				local v_u_48 = p_u_42.SetAssets:FindFirstChild("RealKnife")
				local v_u_49 = script.Assets
				script.Windup.PlaybackSpeed = v_u_46.Speed
				v_u_47:Task(v_u_10.AddSFX(script.Windup, v_u_45, 0.5))
				local v_u_50 = v_u_47:Task(v_u_49.StuntKnife:Clone())
				for _, v51 in v_u_50:QueryDescendants("BasePart, Decal") do
					v51.Transparency = 1
				end
				v_u_50.Weld.Part0 = v_u_45
				v_u_50.Parent = p_u_42
				local v_u_52 = nil
				local v_u_53 = nil
				local function v54()
					-- upvalues: (copy) v_u_47, (ref) v_u_52, (ref) v_u_53, (ref) v_u_4
					v_u_52 = v_u_47:Task(script.Vignette:Clone()).Image
					v_u_53 = v_u_47:Task(Instance.new("ColorCorrectionEffect"))
					v_u_53.Parent = v_u_4
				end
				if v_u_5.Character == p_u_42 then
					task.spawn(v54)
				end
				v_u_47:Task(function()
					-- upvalues: (ref) v_u_4, (ref) v_u_20
					v_u_4.Brightness = v_u_20.Brightness
					v_u_4.ExposureCompensation = v_u_20.ExposureCompensation
				end)
				local v_u_76 = {
					["1"] = function()
						-- upvalues: (ref) v_u_10, (copy) v_u_50, (copy) v_u_48, (ref) v_u_11, (ref) v_u_12, (ref) v_u_5, (copy) p_u_42
						v_u_10.Emit(v_u_50.Handle.flick)
						for _, v55 in v_u_50:QueryDescendants("BasePart, Decal") do
							v55.Transparency = 0
						end
						if v_u_48 then
							for _, v56 in v_u_48:QueryDescendants("BasePart, Decal") do
								v56.Transparency = 1
							end
						end
						local function v57()
							-- upvalues: (ref) v_u_11, (ref) v_u_12
							v_u_11(1, 4, 0.01, 0.15, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.05, 0.05, 0.05))
							v_u_12(Color3.new(1, 0, 0), 0.92, 0.5)
						end
						if v_u_5.Character == p_u_42 then
							task.spawn(v57)
						end
					end,
					["2"] = function()
						-- upvalues: (copy) v_u_47, (copy) v_u_49, (copy) v_u_44, (ref) v_u_10, (ref) v_u_23, (copy) v_u_45, (copy) v_u_50, (copy) v_u_48, (ref) v_u_11, (ref) v_u_5, (copy) p_u_42
						local v_u_58 = v_u_47:Task(v_u_49.character.spin:Clone())
						v_u_58.Parent = v_u_44
						v_u_10.Toggle(v_u_58, true)
						v_u_47:Task(task.delay(0.19, function()
							-- upvalues: (ref) v_u_10, (copy) v_u_58
							v_u_10.Toggle(v_u_58, false)
						end))
						v_u_47:Task(task.delay(0.12, function()
							-- upvalues: (ref) v_u_47, (ref) v_u_23, (ref) v_u_49, (ref) v_u_45
							v_u_47:Task(v_u_23(v_u_49.meshes.spin1, v_u_45))
						end))
						for _, v59 in v_u_50:QueryDescendants("BasePart, Decal") do
							v59.Transparency = 1
						end
						if v_u_48 then
							for _, v60 in v_u_48:QueryDescendants("BasePart, Decal") do
								v60.Transparency = 0
							end
						end
						local function v61()
							-- upvalues: (ref) v_u_11
							v_u_11(1, 5, 0.01, 0.15, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
						end
						if v_u_5.Character == p_u_42 then
							task.spawn(v61)
						end
					end,
					["3"] = function()
						-- upvalues: (copy) v_u_47, (copy) v_u_49, (copy) v_u_45, (ref) v_u_10, (ref) v_u_23, (ref) v_u_11, (ref) v_u_5, (copy) p_u_42
						local v62 = v_u_47:Task(v_u_49.character.landspin1:Clone())
						v62.CFrame = v_u_45.CFrame
						v62.Parent = workspace.Effects
						v_u_10.EmitAttachment(v62)
						v_u_47:Task(v_u_23(v_u_49.meshes.spin2, v_u_45))
						local function v63()
							-- upvalues: (ref) v_u_11
							v_u_11(1.2, 6, 0.01, 0.15, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.35, 0.35, 0.35))
						end
						if v_u_5.Character == p_u_42 then
							task.spawn(v63)
						end
					end,
					["4"] = function()
						-- upvalues: (ref) v_u_10, (copy) v_u_49, (copy) v_u_45, (ref) v_u_18, (copy) v_u_47, (ref) v_u_23, (ref) v_u_3, (ref) v_u_11, (ref) v_u_34, (ref) v_u_52, (ref) v_u_53, (ref) v_u_5, (copy) p_u_42
						local v64 = v_u_10.CloneAndEmit(v_u_49.character.dash1, v_u_45)
						v_u_18:interact(v64, "PointLight", "Brightness", 3)
						v_u_18:tween_descendant(v64, "PointLight", 1.45, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["Brightness"] = 0
						}, false)
						v_u_47:Task(v_u_23(v_u_49.meshes.dash1, v_u_45))
						local v65 = v_u_47:Task(script.Assets.beams.normal:Clone())
						v65.Parent = v_u_45
						v_u_3:Create(v65, TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
							["CFrame"] = v65.CFrame * CFrame.new(0, 0, 2) * CFrame.Angles(0, 0, 3.141592653589793)
						}):Play()
						v_u_18:tween_descendant(v65, "Beam", 0.8, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["TextureSpeed"] = 3,
							["Brightness"] = 0
						}, true)
						local function v66()
							-- upvalues: (ref) v_u_11, (ref) v_u_34, (ref) v_u_52, (ref) v_u_53
							v_u_11(3, 7, 0.02, 0.3, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
							v_u_34(v_u_52, v_u_53, 1.6)
						end
						if v_u_5.Character == p_u_42 then
							task.spawn(v66)
						end
					end,
					["5"] = function()
						-- upvalues: (copy) v_u_47, (copy) v_u_49, (copy) v_u_45, (ref) v_u_10, (ref) v_u_23, (ref) v_u_11, (ref) v_u_5, (copy) p_u_42
						local v67 = v_u_47
						local v68 = v_u_49.land
						local v69 = v_u_45
						local v70 = v68:Clone()
						v70:PivotTo(v69.CFrame * v68.CFrame)
						v70.Parent = workspace.Effects
						v_u_10.Emit(v70)
						v67:Task(v70)
						v_u_47:Task(v_u_23(v_u_49.meshes.land, v_u_45))
						local function v71()
							-- upvalues: (ref) v_u_11
							v_u_11(1.2, 6, 0.01, 0.15, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.5, 0.5, 0.5))
						end
						if v_u_5.Character == p_u_42 then
							task.spawn(v71)
						end
					end,
					["6"] = function()
						-- upvalues: (ref) v_u_10, (copy) v_u_49, (copy) v_u_45, (copy) v_u_48, (ref) v_u_11, (ref) v_u_12, (ref) v_u_5, (copy) p_u_42
						v_u_10.CloneAndEmit(v_u_49.character.slash1, v_u_45)
						v_u_10.CloneAndEmit(v_u_49.knife.flick, v_u_48.Handle)
						local function v72()
							-- upvalues: (ref) v_u_11, (ref) v_u_12
							v_u_11(2, 6, 0.01, 0.15, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.5, 0.5, 0.5))
							v_u_12(Color3.new(1, 0, 0), 0.83, 0.3)
						end
						if v_u_5.Character == p_u_42 then
							task.spawn(v72)
						end
					end,
					["7"] = function()
						-- upvalues: (ref) v_u_10, (copy) v_u_49, (copy) v_u_45, (ref) v_u_18, (copy) v_u_47, (ref) v_u_23, (ref) v_u_3, (ref) v_u_11, (ref) v_u_34, (ref) v_u_52, (ref) v_u_53, (ref) v_u_5, (copy) p_u_42
						local v73 = v_u_10.CloneAndEmit(v_u_49.character.dash2, v_u_45)
						v_u_18:interact(v73, "PointLight", "Brightness", 3)
						v_u_18:tween_descendant(v73, "PointLight", 1.45, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["Brightness"] = 0
						}, false)
						v_u_47:Task(v_u_23(v_u_49.meshes.dash2, v_u_45))
						local v74 = v_u_47:Task(script.Assets.beams.normal:Clone())
						v74.Parent = v_u_45
						v_u_3:Create(v74, TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
							["CFrame"] = v74.CFrame * CFrame.new(0, 0, 2) * CFrame.Angles(0, 0, 3.141592653589793)
						}):Play()
						v_u_18:tween_descendant(v74, "Beam", 1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["TextureSpeed"] = 1,
							["Brightness"] = 0
						}, true)
						local function v75()
							-- upvalues: (ref) v_u_11, (ref) v_u_34, (ref) v_u_52, (ref) v_u_53
							v_u_11(3, 7, 0.02, 0.3, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
							v_u_34(v_u_52, v_u_53, 1.7)
						end
						if v_u_5.Character == p_u_42 then
							task.spawn(v75)
						end
					end
				}
				local v_u_80 = {
					["1"] = function()
						-- upvalues: (copy) v_u_47, (ref) v_u_30, (copy) v_u_45, (ref) v_u_3
						local v_u_77 = v_u_47:Task((v_u_30("Atonement Kick", v_u_45, 0)))
						v_u_3:Create(v_u_77.Strength, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Value"] = 95
						}):Play()
						v_u_47:Task(task.delay(0.2, function()
							-- upvalues: (ref) v_u_3, (copy) v_u_77
							v_u_3:Create(v_u_77.Strength, TweenInfo.new(1.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								["Value"] = 0
							}):Play()
						end))
						v_u_47:Task(task.delay(1.5, v_u_77.Destroy, v_u_77))
					end,
					["2"] = function()
						-- upvalues: (copy) v_u_47, (ref) v_u_30, (copy) v_u_45, (ref) v_u_3
						local v_u_78 = v_u_47:Task((v_u_30("Atonement Dash 1", v_u_45, 0)))
						v_u_3:Create(v_u_78.Strength, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Value"] = 110
						}):Play()
						v_u_47:Task(task.delay(0.3, function()
							-- upvalues: (ref) v_u_3, (copy) v_u_78
							v_u_3:Create(v_u_78.Strength, TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
								["Value"] = 14
							}):Play()
						end))
					end,
					["3"] = function()
						-- upvalues: (copy) v_u_47, (ref) v_u_30, (copy) v_u_45, (ref) v_u_3
						v_u_3:Create(v_u_47:Task((v_u_30("Atonement Slice", v_u_45, 55))).Strength, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
							["Value"] = 0
						}):Play()
					end,
					["4"] = function()
						-- upvalues: (copy) v_u_47, (ref) v_u_30, (copy) v_u_45, (ref) v_u_3
						local v_u_79 = v_u_47:Task((v_u_30("Atonement Dash 2", v_u_45, 0)))
						v_u_3:Create(v_u_79.Strength, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Value"] = 140
						}):Play()
						v_u_47:Task(task.delay(0.25, function()
							-- upvalues: (ref) v_u_3, (copy) v_u_79
							v_u_3:Create(v_u_79.Strength, TweenInfo.new(0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								["Value"] = 0
							}):Play()
						end))
					end
				}
				v_u_47:Task(v_u_46:GetMarkerReachedSignal("VFX"):Connect(function(p81)
					-- upvalues: (copy) v_u_76
					local v82 = v_u_76[p81]
					if v82 then
						v82()
					end
				end))
				local function v85()
					-- upvalues: (copy) v_u_47, (copy) v_u_46, (copy) v_u_80
					v_u_47:Task(v_u_46:GetMarkerReachedSignal("Velocity"):Connect(function(p83)
						-- upvalues: (ref) v_u_80
						local v84 = v_u_80[p83]
						if v84 then
							v84()
						end
					end))
				end
				if v_u_5.Character == p_u_42 then
					task.spawn(v85)
				end
			end
		end,
		["Hit"] = function(p_u_86, p_u_87)
			-- upvalues: (ref) v_u_9, (ref) v_u_39, (ref) v_u_5, (ref) v_u_40, (ref) v_u_10, (ref) v_u_4, (ref) v_u_11, (ref) v_u_18, (ref) v_u_12, (ref) v_u_16, (ref) v_u_23, (ref) v_u_20, (ref) v_u_3
			local v88 = v_u_9.new(p_u_86, v_u_39.Hit)
			if v88 ~= nil then
				local _ = v88.Torso
				local v_u_89 = v88.RootPart
				local v90 = v88.Animation
				local v_u_91 = v88.Job
				local v92 = v_u_40.Character == p_u_86
				local v_u_93 = p_u_86.SetAssets:FindFirstChild("RealKnife")
				local v_u_94 = script.HitAssets
				script.Start.PlaybackSpeed = v90.Speed
				v_u_91:Task(v_u_10.AddSFX(script.Start, v_u_89, 0.5))
				local v_u_95 = v_u_91:Task(v_u_94.StuntKnife2:Clone())
				for _, v96 in v_u_95:QueryDescendants("BasePart, Decal") do
					v96.Transparency = 1
				end
				v_u_95.Weld.Part0 = v_u_89
				v_u_95.Parent = p_u_86
				local v_u_97 = nil
				local function v98()
					-- upvalues: (ref) v_u_97, (ref) v_u_4
					v_u_97 = Instance.new("ColorCorrectionEffect")
					v_u_97.Parent = v_u_4
				end
				if v_u_5.Character == p_u_86 or v_u_5.Character == p_u_87 then
					task.spawn(v98)
				end
				local v_u_99 = script.Videos:Clone()
				v_u_99.Name = "AtonementImpactFrames"
				v_u_99.Parent = v_u_40.PlayerGui
				v_u_91:Task(function()
					-- upvalues: (copy) v_u_99
					task.delay(10, v_u_99.Destroy, v_u_99)
				end)
				v_u_91:Task(function()
					-- upvalues: (ref) v_u_40
					workspace.CurrentCamera.CameraSubject = v_u_40.Character.Humanoid
				end)
				local v_u_100 = {}
				local v_u_120 = {
					["1"] = function()
						-- upvalues: (ref) v_u_10, (copy) v_u_94, (copy) v_u_89, (ref) v_u_11, (ref) v_u_5, (copy) p_u_86, (copy) p_u_87
						v_u_10.CloneAndEmit(v_u_94.character.land, v_u_89)
						local function v101()
							-- upvalues: (ref) v_u_11
							v_u_11(3, 6, 0.03, 0.2, Vector3.new(0.5, 0.5, 0.5), Vector3.new(0.4, 0.4, 0.4))
						end
						if v_u_5.Character == p_u_86 or v_u_5.Character == p_u_87 then
							task.spawn(v101)
						end
					end,
					["2"] = function()
						-- upvalues: (copy) v_u_91, (copy) p_u_86, (ref) v_u_18, (ref) v_u_10, (copy) v_u_94, (copy) v_u_89, (copy) v_u_93, (ref) v_u_11, (ref) v_u_12, (ref) v_u_5, (copy) p_u_87
						local v102 = v_u_91:Task(Instance.new("Highlight"))
						v102.DepthMode = Enum.HighlightDepthMode.Occluded
						v102.FillColor = Color3.new(0, 0, 0)
						v102.FillTransparency = 0.2
						v102.OutlineTransparency = 1
						v102.Parent = p_u_86
						v_u_18:tween_single(v102, 1.45, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["FillTransparency"] = 1
						}, true)
						v_u_10.CloneAndEmit(v_u_94.character.slash1, v_u_89)
						if v_u_93 then
							v_u_10.CloneAndEmit(v_u_94.knife.flicknormal, v_u_93.Handle)
						end
						local function v103()
							-- upvalues: (ref) v_u_11, (ref) v_u_12
							v_u_11(3, 5, 0.04, 0.2, Vector3.new(0.5, 0.5, 0.5), Vector3.new(0.4, 0.4, 0.4))
							v_u_12(Color3.new(1, 0, 0), 0.8, 0.3)
						end
						if v_u_5.Character == p_u_86 or v_u_5.Character == p_u_87 then
							task.spawn(v103)
						end
					end,
					["3"] = function()
						-- upvalues: (ref) v_u_10, (copy) v_u_94, (copy) v_u_89, (copy) v_u_93, (ref) v_u_11, (ref) v_u_12, (ref) v_u_5, (copy) p_u_86, (copy) p_u_87
						v_u_10.CloneAndEmit(v_u_94.character.slash2, v_u_89)
						if v_u_93 then
							v_u_10.CloneAndEmit(v_u_94.knife.flicknormal, v_u_93.Handle)
						end
						local function v104()
							-- upvalues: (ref) v_u_11, (ref) v_u_12
							v_u_11(3, 5, 0.05, 0.3, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.6, 0.6, 0.6))
							v_u_12(Color3.new(1, 0, 0), 0.8, 0.3)
						end
						if v_u_5.Character == p_u_86 or v_u_5.Character == p_u_87 then
							task.spawn(v104)
						end
					end,
					["4"] = function()
						-- upvalues: (copy) v_u_100, (copy) v_u_91, (ref) v_u_10, (copy) v_u_94, (copy) v_u_89, (copy) v_u_93, (ref) v_u_18, (ref) v_u_12, (ref) v_u_16, (ref) v_u_5, (copy) p_u_86, (copy) p_u_87
						v_u_100.Slash3 = v_u_91:Task(v_u_10.CloneAndEmit(v_u_94.character.slash3, v_u_89, true))
						if v_u_93 then
							v_u_100.Flick = v_u_91:Task(v_u_10.CloneAndEmit(v_u_94.knife.flick, v_u_93.Handle, true))
						end
						v_u_18:interact(v_u_100.Slash3, "ParticleEmitter", "TimeScale", 1)
						if v_u_93 then
							v_u_18:interact(v_u_100.Flick, "ParticleEmitter", "TimeScale", 1)
						end
						v_u_18:tween_descendant(v_u_100.Slash3, "ParticleEmitter", 0.1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["TimeScale"] = 0.02
						})
						if v_u_93 then
							v_u_18:tween_descendant(v_u_100.Flick, "ParticleEmitter", 0.1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
								["TimeScale"] = 0.02
							})
						end
						v_u_91:Task(task.delay(0.784, function()
							-- upvalues: (ref) v_u_18, (ref) v_u_100, (ref) v_u_93
							v_u_18:tween_descendant(v_u_100.Slash3, "ParticleEmitter", 1.45, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
								["TimeScale"] = 1
							})
							if v_u_93 then
								v_u_18:tween_descendant(v_u_100.Flick, "ParticleEmitter", 1.45, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
									["TimeScale"] = 1
								})
							end
						end))
						local function v105()
							-- upvalues: (ref) v_u_12, (ref) v_u_91, (ref) v_u_16
							v_u_12(Color3.new(1, 0, 0), 0.7, 3)
							v_u_91:Task(v_u_16.Tween(60, { 0.684, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out }))
							v_u_91:Task(task.delay(0.684, function()
								-- upvalues: (ref) v_u_91, (ref) v_u_16
								v_u_91:Task(v_u_16.Tween(70, { 0.183, Enum.EasingStyle.Sine, Enum.EasingDirection.In }))
							end))
						end
						if v_u_5.Character == p_u_86 or v_u_5.Character == p_u_87 then
							task.spawn(v105)
						end
					end,
					["6"] = function()
						-- upvalues: (copy) v_u_91, (ref) v_u_10, (copy) v_u_95, (ref) v_u_11, (ref) v_u_12, (ref) v_u_5, (copy) p_u_86, (copy) p_u_87
						v_u_91:Task(v_u_10.Emit(v_u_95.Handle.flick, true))
						local function v106()
							-- upvalues: (ref) v_u_11, (ref) v_u_12
							v_u_11(5, 5, 0.05, 0.3, Vector3.new(0.4, 0.4, 0.4), Vector3.new(0.2, 0.2, 0.2))
							v_u_12(Color3.new(1, 0, 0), 0.92, 0.5)
						end
						if v_u_5.Character == p_u_86 or v_u_5.Character == p_u_87 then
							task.spawn(v106)
						end
					end,
					["7"] = function()
						-- upvalues: (ref) v_u_10, (copy) v_u_94, (copy) p_u_86
						v_u_10.CloneAndEmit(v_u_94.character.eye, p_u_86.Head)
					end,
					["8"] = function()
						-- upvalues: (copy) v_u_91, (copy) v_u_94, (copy) v_u_89, (ref) v_u_10, (ref) v_u_23, (ref) v_u_11, (ref) v_u_5, (copy) p_u_86, (copy) p_u_87
						local v107 = v_u_91
						local v108 = v_u_94.tp1
						local v109 = v_u_89
						local v110 = v108:Clone()
						v110:PivotTo(v109.CFrame * v108.CFrame)
						v110.Parent = workspace.Effects
						v_u_10.Emit(v110)
						v107:Task(v110)
						v_u_91:Task(v_u_23(v_u_94.meshes.tp, v_u_89))
						local function v111()
							-- upvalues: (ref) v_u_11
							v_u_11(3.5, 5, 0.05, 0.4, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.6, 0.6, 0.6))
						end
						if v_u_5.Character == p_u_86 or v_u_5.Character == p_u_87 then
							task.spawn(v111)
						end
					end,
					["9"] = function()
						-- upvalues: (copy) v_u_91, (copy) v_u_94, (copy) v_u_89, (ref) v_u_10, (ref) v_u_4, (ref) v_u_97, (ref) v_u_20, (ref) v_u_3, (ref) v_u_16, (ref) v_u_5, (copy) p_u_86, (copy) p_u_87
						local v112 = v_u_91
						local v113 = v_u_94.tp2start
						local v114 = v_u_89
						local v115 = v113:Clone()
						v115:PivotTo(v114.CFrame * v113.CFrame)
						v115.Parent = workspace.Effects
						v_u_10.Emit(v115)
						v112:Task(v115)
						local v116 = v_u_94.tp2:Clone()
						v116:PivotTo(v_u_89.CFrame * v_u_94.tp2.CFrame)
						v116.Parent = workspace.Effects
						v_u_10.Toggle(v116, true)
						task.delay(0.54, v_u_10.Toggle, v116, false)
						task.delay(3, v116.Destroy, v116)
						local function v119()
							-- upvalues: (ref) v_u_4, (ref) v_u_97, (ref) v_u_91, (ref) v_u_20, (ref) v_u_3, (ref) v_u_16
							v_u_4.Brightness = 1
							v_u_4.ExposureCompensation = 0.5
							v_u_97.TintColor = Color3.fromRGB(255, 91, 91)
							v_u_97.Contrast = 3
							v_u_91:Task(task.wait(0.03))
							v_u_4.Brightness = 1.325
							v_u_4.ExposureCompensation = 0.25
							v_u_97.TintColor = Color3.fromRGB(255, 0, 0)
							v_u_97.Contrast = 0
							v_u_91:Task(task.wait(0.03))
							v_u_4.Brightness = v_u_20.Brightness
							v_u_4.ExposureCompensation = v_u_20.ExposureCompensation
							v_u_97.TintColor = Color3.fromRGB(255, 255, 255)
							v_u_97.Contrast = 0
							v_u_91:Task(task.wait(0.03))
							local v_u_117 = v_u_3:Create(v_u_4, TweenInfo.new(1.05, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
								["Brightness"] = 1,
								["ExposureCompensation"] = -0.2
							})
							local v_u_118 = v_u_3:Create(v_u_97, TweenInfo.new(1.05, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
								["TintColor"] = Color3.fromRGB(255, 206, 206),
								["Contrast"] = 0.5
							})
							v_u_117:Play()
							v_u_118:Play()
							v_u_91:Task(v_u_16.Tween(55, { 1.184, Enum.EasingStyle.Quad, Enum.EasingDirection.Out }))
							v_u_91:Task(task.delay(1.184, v_u_16.Set, 70))
							v_u_91:Task(function()
								-- upvalues: (ref) v_u_16, (copy) v_u_117, (copy) v_u_118, (ref) v_u_3, (ref) v_u_4, (ref) v_u_20, (ref) v_u_97
								v_u_16.Reset()
								v_u_117:Destroy()
								v_u_118:Destroy()
								v_u_3:Create(v_u_4, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
									["Brightness"] = v_u_20.Brightness,
									["ExposureCompensation"] = v_u_20.ExposureCompensation
								}):Play()
								v_u_3:Create(v_u_97, TweenInfo.new(1.05, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
									["TintColor"] = Color3.fromRGB(255, 255, 255),
									["Contrast"] = 0
								}):Play()
								task.wait(1.05)
								v_u_97:Destroy()
							end)
						end
						if v_u_5.Character == p_u_86 or v_u_5.Character == p_u_87 then
							task.spawn(v119)
						end
					end
				}
				v_u_91:Task(v90:GetMarkerReachedSignal("VFX"):Connect(function(p121)
					-- upvalues: (copy) v_u_120
					local v122 = v_u_120[p121]
					if v122 then
						v122()
					end
				end))
				v_u_91:Task(v90:GetMarkerReachedSignal("KnifeTransparency"):Connect(function(p123)
					-- upvalues: (copy) v_u_93, (copy) v_u_95
					local v124 = tonumber(p123)
					if v_u_93 then
						for _, v125 in v_u_93:QueryDescendants("BasePart, Decal") do
							v125.Transparency = v124
						end
					end
					local v126 = v_u_95
					local v127 = v124 == 0 and 1 or 0
					for _, v128 in v126:QueryDescendants("BasePart, Decal") do
						v128.Transparency = v127
					end
				end))
				if v92 then
					v_u_91:Task(v90:GetMarkerReachedSignal("Teleport"):Connect(function(p129)
						-- upvalues: (copy) p_u_87
						if p129 == "Disappear" then
							workspace.CurrentCamera.CameraSubject = p_u_87.Head
						end
					end))
				end
				v_u_91:Task(function()
					-- upvalues: (copy) v_u_100, (copy) v_u_93
					for _, v130 in pairs(v_u_100) do
						v130:Destroy()
					end
					if v_u_93 then
						for _, v131 in v_u_93:QueryDescendants("BasePart, Decal") do
							v131.Transparency = 0
						end
					end
				end)
			end
		end,
		["Lose"] = function(p_u_132, p_u_133)
			-- upvalues: (ref) v_u_9, (ref) v_u_39, (ref) v_u_5, (ref) v_u_40, (ref) v_u_10, (ref) v_u_4, (ref) v_u_16, (ref) v_u_11, (ref) v_u_23, (ref) v_u_3, (ref) v_u_18, (ref) v_u_20
			local v134 = v_u_9.new(p_u_132, v_u_39.Lose)
			local _ = v134.Torso
			local v_u_135 = v134.RootPart
			local v136 = v134.Animation
			local v_u_137 = v134.Job
			local v138 = v_u_9.new(p_u_133, v_u_39.VictimLose)
			local _ = v138.Torso
			local v_u_139 = v138.RootPart
			local v140 = v138.Animation
			local _ = v138.Job
			local v141 = v_u_40.Character == p_u_132
			local v_u_142 = p_u_132.SetAssets:FindFirstChild("RealKnife")
			local v_u_143 = script.LoseAssets
			script.Lose.PlaybackSpeed = v136.Speed
			v_u_137:Task(v_u_10.AddSFX(script.Lose, v_u_135, 0.5))
			local v_u_144 = v_u_137:Task(script.HitAssets.StuntKnife2:Clone())
			for _, v145 in v_u_144:QueryDescendants("BasePart, Decal") do
				v145.Transparency = 1
			end
			v_u_144.Weld.Part0 = v_u_135
			v_u_144.Parent = p_u_132
			local v_u_146 = nil
			local v_u_147 = nil
			local function v148()
				-- upvalues: (copy) v_u_137, (ref) v_u_146, (ref) v_u_147, (ref) v_u_4
				v_u_146 = v_u_137:Task(script.Vignette:Clone()).Image
				v_u_147 = v_u_137:Task(Instance.new("ColorCorrectionEffect"))
				v_u_147.Parent = v_u_4
			end
			if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
				task.spawn(v148)
			end
			local function v149()
				-- upvalues: (copy) v_u_137, (ref) v_u_40
				v_u_137:Task(function()
					-- upvalues: (ref) v_u_40
					workspace.CurrentCamera.CameraSubject = v_u_40.Character.Humanoid
				end)
			end
			if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
				task.spawn(v149)
			end
			local function v150()
				-- upvalues: (copy) v_u_137, (ref) v_u_16
				v_u_137:Task(v_u_16.Reset())
			end
			if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
				task.spawn(v150)
			end
			local v_u_151 = {}
			local v_u_172 = {
				["1"] = function()
					-- upvalues: (ref) v_u_10, (copy) v_u_143, (copy) v_u_135, (ref) v_u_11, (ref) v_u_5, (copy) p_u_132, (copy) p_u_133
					v_u_10.CloneAndEmit(v_u_143.character.start, v_u_135)
					local function v152()
						-- upvalues: (ref) v_u_11
						v_u_11(3, 5, 0.1, 0.3, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
					end
					if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
						task.spawn(v152)
					end
				end,
				["2"] = function()
					-- upvalues: (copy) v_u_137, (copy) v_u_143, (copy) v_u_135, (ref) v_u_10, (ref) v_u_23, (ref) v_u_11, (ref) v_u_5, (copy) p_u_132, (copy) p_u_133
					local v153 = v_u_137
					local v154 = v_u_143.tp1
					local v155 = v_u_135
					local v156 = v154:Clone()
					v156:PivotTo(v155.CFrame * v154.CFrame)
					v156.Parent = workspace.Effects
					v_u_10.Emit(v156)
					v153:Task(v156)
					v_u_137:Task(v_u_23(v_u_143.meshes.tp, v_u_135))
					local function v157()
						-- upvalues: (ref) v_u_11
						v_u_11(3.4, 7, 0.05, 0.35, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.6, 0.6, 0.6))
					end
					if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
						task.spawn(v157)
					end
				end,
				["3"] = function()
					-- upvalues: (copy) v_u_137, (copy) v_u_143, (copy) v_u_135, (ref) v_u_10, (ref) v_u_11, (ref) v_u_16, (ref) v_u_5, (copy) p_u_132, (copy) p_u_133
					local v158 = v_u_137
					local v159 = v_u_143.tp2
					local v160 = v_u_135
					local v161 = v159:Clone()
					v161:PivotTo(v160.CFrame * v159.CFrame)
					v161.Parent = workspace.Effects
					v_u_10.Emit(v161)
					v158:Task(v161)
					local function v162()
						-- upvalues: (ref) v_u_11, (ref) v_u_137, (ref) v_u_16
						v_u_11(3.7, 7, 0.05, 0.35, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.6, 0.6, 0.6))
						v_u_137:Task(v_u_16.Tween(55, { 0.334, Enum.EasingStyle.Cubic, Enum.EasingDirection.In }))
						v_u_137:Task(task.delay(0.334, v_u_16.Reset))
					end
					if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
						task.spawn(v162)
					end
				end,
				["4"] = function()
					-- upvalues: (ref) v_u_10, (copy) v_u_143, (copy) v_u_135, (copy) v_u_137, (ref) v_u_23, (ref) v_u_3, (ref) v_u_18, (copy) p_u_132, (ref) v_u_146, (ref) v_u_4, (ref) v_u_20, (ref) v_u_5, (copy) p_u_133, (ref) v_u_11
					v_u_10.CloneAndEmit(v_u_143.character.kick, v_u_135)
					v_u_137:Task(v_u_23(v_u_143.meshes.kick, v_u_135))
					local v163 = v_u_137:Task(v_u_143.beams.kick:Clone())
					v163.Parent = v_u_135
					v_u_3:Create(v163, TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
						["CFrame"] = v163.CFrame * CFrame.new(0, 0, -3) * CFrame.Angles(0, 0, 2.6179938779914944)
					}):Play()
					v_u_18:tween_descendant(v163, "Beam", 0.71, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["TextureSpeed"] = 2,
						["Brightness"] = 0
					}, true)
					local v164 = v_u_137:Task(Instance.new("Highlight"))
					v164.DepthMode = Enum.HighlightDepthMode.Occluded
					v164.FillColor = Color3.new(0, 0, 0)
					v164.FillTransparency = 0.2
					v164.OutlineTransparency = 1
					v164.Parent = p_u_132
					v_u_18:tween_single(v164, 1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["FillTransparency"] = 1
					}, true)
					local function v167()
						-- upvalues: (ref) v_u_146, (ref) v_u_4, (ref) v_u_137, (ref) v_u_3, (ref) v_u_20
						v_u_146.ImageTransparency = 0.2
						v_u_4.Brightness = 0.3
						v_u_4.ExposureCompensation = -1
						v_u_137:Task(task.wait(0.02))
						v_u_4.ExposureCompensation = 0.5
						local v165 = v_u_137:Task(v_u_3:Create(v_u_146, TweenInfo.new(1.33, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
							["ImageTransparency"] = 1
						}))
						local v166 = v_u_137:Task(v_u_3:Create(v_u_4, TweenInfo.new(1.33, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
							["Brightness"] = v_u_20.Brightness,
							["ExposureCompensation"] = v_u_20.ExposureCompensation
						}))
						v165:Play()
						v166:Play()
					end
					if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
						task.spawn(v167)
					end
					local function v168()
						-- upvalues: (ref) v_u_11
						v_u_11(20, 20, 0.1, 0.2, Vector3.new(0.27, 0.27, 0.27))
					end
					if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
						task.spawn(v168)
					end
				end,
				["5"] = function()
					-- upvalues: (ref) v_u_10, (copy) v_u_143, (copy) p_u_132
					v_u_10.CloneAndEmit(v_u_143.character.nicetry, p_u_132.Head)
				end,
				["6"] = function()
					-- upvalues: (copy) v_u_137, (copy) v_u_143, (copy) v_u_135, (ref) v_u_10, (copy) v_u_151
					local v169 = v_u_137:Task(v_u_143.pull:Clone())
					v169:PivotTo(v_u_135.CFrame * v_u_143.pull.CFrame)
					v169.Parent = workspace.Effects
					v_u_10.Toggle(v169, true)
					v_u_151.Pull = v169
				end,
				["7"] = function()
					-- upvalues: (copy) v_u_151, (ref) v_u_10, (copy) v_u_137, (copy) p_u_132, (ref) v_u_18, (ref) v_u_11, (ref) v_u_5, (copy) p_u_133
					if v_u_151.Pull then
						v_u_10.Toggle(v_u_151.Pull, false)
					end
					local v170 = v_u_137:Task(Instance.new("Highlight"))
					v170.DepthMode = Enum.HighlightDepthMode.Occluded
					v170.FillColor = Color3.fromRGB(57, 0, 0)
					v170.FillTransparency = 0.2
					v170.OutlineColor = Color3.fromRGB(186, 37, 37)
					v170.OutlineTransparency = 0
					v170.Parent = p_u_132["Right Arm"]
					v_u_18:tween_single(v170, 1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["FillTransparency"] = 1,
						["OutlineTransparency"] = 1
					}, true)
					local function v171()
						-- upvalues: (ref) v_u_11
						v_u_11(1.5, 1.5, 0.04, 0.2, Vector3.new(0.4, 0.4, 0.4), Vector3.new(0.3, 0.3, 0.3))
					end
					if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
						task.spawn(v171)
					end
				end
			}
			local v_u_181 = {
				["1"] = function()
					-- upvalues: (ref) v_u_10, (copy) v_u_143, (copy) v_u_139, (ref) v_u_11, (ref) v_u_5, (copy) p_u_132, (copy) p_u_133
					v_u_10.CloneAndEmit(v_u_143.victimcharacter.roll, v_u_139)
					local function v173()
						-- upvalues: (ref) v_u_11
						v_u_11(3, 3, 0.01, 0.3, Vector3.new(0.5, 0.5, 0.5), Vector3.new(0.3, 0.3, 0.3))
					end
					if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
						task.spawn(v173)
					end
				end,
				["2"] = function()
					-- upvalues: (ref) v_u_10, (copy) v_u_143, (copy) v_u_135, (ref) v_u_18, (copy) v_u_144, (copy) v_u_137, (ref) v_u_3, (ref) v_u_23, (copy) p_u_132, (ref) v_u_146, (ref) v_u_4, (ref) v_u_20, (ref) v_u_5, (copy) p_u_133, (ref) v_u_11, (ref) v_u_16
					local v174 = v_u_10.CloneAndEmit(v_u_143.character.stab, v_u_135):FindFirstChild("PointLight")
					if v174 then
						v174.Brightness = 2
						v_u_18:tween_descendant(v174, "PointLight", 2, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["Brightness"] = 0
						})
					end
					v_u_10.Toggle(v_u_144.BladeInner.pulsing, true)
					local v175 = v_u_137:Task(v_u_143.beams.normal:Clone())
					v175.Parent = v_u_135
					v_u_3:Create(v175, TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
						["CFrame"] = v175.CFrame * CFrame.new(0, 0, -6) * CFrame.Angles(0, 0, 3.141592653589793)
					}):Play()
					v_u_18:tween_descendant(v175, "Beam", 0.65, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["TextureSpeed"] = 5,
						["Brightness"] = 0
					}, true)
					v_u_137:Task(v_u_23(v_u_143.meshes.stab, v_u_135))
					local v176 = v_u_137:Task(Instance.new("Highlight"))
					v176.DepthMode = Enum.HighlightDepthMode.Occluded
					v176.FillColor = Color3.fromRGB(42, 136, 150)
					v176.FillTransparency = 13
					v176.OutlineColor = Color3.fromRGB(255, 0, 0)
					v176.OutlineTransparency = 0.6
					v176.Parent = p_u_132
					v_u_18:tween_single(v176, 1.3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["FillTransparency"] = 1,
						["OutlineTransparency"] = 1
					}, true)
					local function v179()
						-- upvalues: (ref) v_u_146, (ref) v_u_4, (ref) v_u_137, (ref) v_u_3, (ref) v_u_20
						v_u_146.ImageTransparency = 0
						v_u_4.Brightness = 0.1
						v_u_4.ExposureCompensation = 1
						v_u_137:Task(task.wait(0.02))
						v_u_146.ImageTransparency = 0.5
						local v177 = v_u_137:Task(v_u_3:Create(v_u_146, TweenInfo.new(0.9, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
							["ImageTransparency"] = 1
						}))
						local v178 = v_u_137:Task(v_u_3:Create(v_u_4, TweenInfo.new(0.9, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
							["Brightness"] = v_u_20.Brightness,
							["ExposureCompensation"] = v_u_20.ExposureCompensation
						}))
						v177:Play()
						v178:Play()
					end
					if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
						task.spawn(v179)
					end
					local function v180()
						-- upvalues: (ref) v_u_11, (ref) v_u_16, (ref) v_u_137
						v_u_11(6, 20, 0.07, 0.25, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.8, 0.8, 0.8))
						v_u_16.Set(37)
						v_u_137:Task(v_u_16.Tween(70, { 0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out }))
					end
					if v_u_5.Character == p_u_132 or v_u_5.Character == p_u_133 then
						task.spawn(v180)
					end
				end,
				["3"] = function()
					-- upvalues: (ref) v_u_10, (copy) v_u_144
					v_u_10.Toggle(v_u_144.BladeInner.pulsing, false)
				end
			}
			v_u_137:Task(v136:GetMarkerReachedSignal("VFX"):Connect(function(p182)
				-- upvalues: (copy) v_u_172
				local v183 = v_u_172[p182]
				if v183 then
					v183()
				end
			end))
			v_u_137:Task(v140:GetMarkerReachedSignal("VFX"):Connect(function(p184)
				-- upvalues: (copy) v_u_181
				local v185 = v_u_181[p184]
				if v185 then
					v185()
				end
			end))
			if v141 then
				v_u_137:Task(v136:GetMarkerReachedSignal("Teleport"):Connect(function(p186)
					-- upvalues: (copy) p_u_133, (copy) p_u_132
					if p186 == "Disappear" then
						workspace.CurrentCamera.CameraSubject = p_u_133.Head
					else
						workspace.CurrentCamera.CameraSubject = p_u_132.Humanoid
					end
				end))
			end
			v_u_137:Task(v136:GetMarkerReachedSignal("KnifeTransparency"):Connect(function(p187)
				-- upvalues: (copy) v_u_142, (copy) v_u_144
				local v188 = tonumber(p187)
				if v_u_142 then
					for _, v189 in v_u_142:QueryDescendants("BasePart, Decal") do
						v189.Transparency = v188
					end
				end
				local v190 = v_u_144
				local v191 = v188 == 0 and 1 or 0
				for _, v192 in v190:QueryDescendants("BasePart, Decal") do
					v192.Transparency = v191
				end
			end))
			v_u_137:Task(function()
				-- upvalues: (copy) v_u_142
				if v_u_142 then
					for _, v193 in v_u_142:QueryDescendants("BasePart, Decal") do
						v193.Transparency = 0
					end
				end
			end)
		end,
		["Win"] = function(p_u_194, p_u_195)
			-- upvalues: (ref) v_u_9, (ref) v_u_39, (ref) v_u_40, (ref) v_u_10, (ref) v_u_41, (ref) v_u_13, (ref) v_u_16, (ref) v_u_2, (ref) v_u_4
			local v196 = v_u_9.new(p_u_194, v_u_39.Win)
			if v196 ~= nil then
				local v197 = v196.Torso
				local v_u_198 = v196.RootPart
				local v_u_199 = v196.Animation
				local v_u_200 = v196.Job
				local v201 = v_u_40.Character == p_u_194 and true or v_u_40.Character == p_u_195
				local v_u_202 = p_u_194:FindFirstChild("Knife")
				script.SFX.PlaybackSpeed = v_u_199.Speed
				local v203 = v_u_10.AddSFX
				local v204 = script.SFX
				if v201 then
					v197 = workspace
				end
				v_u_200:Task(v203(v204, v197, 0.5))
				local v_u_205 = v_u_200:Task(v_u_41.VictimHeadKnife:Clone())
				v_u_205.Parent = p_u_195
				v_u_205.Weld.Part0 = p_u_195:FindFirstChild("Head")
				if v201 then
					local v206 = v_u_40.PlayerGui:FindFirstChild("AtonementImpactFrames")
					if v206 and not v_u_40:GetAttribute("Epileptic_Mode") then
						local v_u_207 = v206.Frame.Part1
						v_u_207.Visible = true
						v_u_207:Play()
						v_u_200:Task(v_u_207.Ended:Once(function()
							-- upvalues: (copy) v_u_207
							v_u_207.Visible = false
							v_u_207:Destroy()
						end))
					end
				end
				if v201 then
					local v_u_208 = v_u_41.Camera:Clone()
					v_u_208:PivotTo(v_u_198.CFrame)
					v_u_208.Parent = workspace.Effects
					local v_u_209 = v_u_208.Humanoid.Animator:LoadAnimation(v_u_39.Camera)
					v_u_200:Task(v_u_209.Stopped:Once(function()
						-- upvalues: (copy) v_u_208
						v_u_208:Destroy()
					end))
					v_u_200:Task(v_u_208)
					v_u_209:Play(0, nil, v_u_199.Speed)
					v_u_200:Task(v_u_13(v_u_198, v_u_208))
					v_u_200:Task(v_u_16.AnimateWithMoonFileCustomFPS(script["Death Charge Hit"]), nil, nil, nil, 60 * v_u_199.Speed)
					v_u_200:Task(v_u_2.PreAnimation:Connect(function()
						-- upvalues: (copy) v_u_209, (copy) v_u_199
						v_u_209.TimePosition = v_u_199.TimePosition
					end))
				end
				if v201 then
					local v_u_210 = v_u_41.FightUI:Clone()
					local v_u_211 = v_u_41.BlackBox:Clone()
					local v_u_212 = v_u_41.ColorCorrection:Clone()
					local v_u_213 = script.Sky:Clone()
					v_u_200:Task(v_u_210)
					v_u_200:Task(v_u_211)
					v_u_200:Task(v_u_212)
					v_u_200:Task(v_u_213)
					v_u_200:Task(v_u_199:GetMarkerReachedSignal("room"):Connect(function()
						-- upvalues: (copy) v_u_213, (ref) v_u_4, (copy) p_u_194, (copy) v_u_200, (copy) v_u_212, (ref) v_u_10, (copy) v_u_211, (copy) v_u_198, (copy) v_u_210, (ref) v_u_41
						v_u_213.Parent = v_u_4
						local v214 = Instance.new("Highlight")
						v214.DepthMode = Enum.HighlightDepthMode.Occluded
						v214.FillColor = Color3.fromRGB(77, 77, 77)
						v214.FillTransparency = 25
						v214.OutlineColor = Color3.fromRGB(255, 255, 255)
						v214.OutlineTransparency = 0
						v214.Parent = p_u_194
						v_u_200:Task(v214)
						v_u_212.Enabled = true
						v_u_212.Parent = v_u_4
						v_u_10.Weld(v_u_211, v_u_198, CFrame.new(0, 14.75, 75))
						v_u_211.Parent = workspace.Effects
						v_u_10.Weld(v_u_210, v_u_198, v_u_41.FightUI.CFrame)
						v_u_210.Parent = workspace.Effects
						for _, v215 in ipairs(v_u_210:GetDescendants()) do
							if v215:IsA("ParticleEmitter") then
								v215:Emit(1)
								v215.Enabled = true
							end
						end
					end))
					v_u_200:Task(v_u_199:GetMarkerReachedSignal("break"):Connect(function()
						-- upvalues: (copy) v_u_213, (copy) v_u_210, (ref) v_u_41, (ref) v_u_10, (copy) v_u_198
						v_u_213:Destroy()
						v_u_210:Destroy()
						local v216 = v_u_41.FightBreak:Clone()
						v_u_10.Weld(v216, v_u_198, v_u_41.FightBreak.CFrame)
						v216.Parent = workspace.Effects
						v_u_10.Emit(v216)
					end))
					v_u_200:Task(v_u_199:GetMarkerReachedSignal("Kill"):Connect(function()
						-- upvalues: (copy) v_u_211
						v_u_211:Destroy()
					end))
				end
				local v_u_220 = {
					["e1"] = function()
						-- upvalues: (copy) v_u_202, (ref) v_u_10, (ref) v_u_41
						if v_u_202 then
							v_u_10.Arc.CloneAndEmit(v_u_41.CustomVFX.e1, v_u_202.BladeInner)
						end
					end,
					["11"] = function()
						-- upvalues: (ref) v_u_41, (ref) v_u_10, (copy) p_u_194, (copy) v_u_205
						local v217 = v_u_41.VFX["11"]
						v_u_10.Arc.CloneAndEmit(v217, p_u_194[v217:GetAttribute("attached")])
						v_u_10.Arc.EmitAttachment(v_u_205.BladeInner["1"])
						v_u_10.Arc.ToggleAttachment(v_u_205.BladeInner["1"], true, 1)
					end,
					["Drag"] = function()
						-- upvalues: (copy) v_u_200, (ref) v_u_41, (copy) p_u_195, (ref) v_u_10
						local v218 = v_u_200:Task(v_u_41.CustomVFX.drag:Clone())
						v218.Parent = p_u_195.Torso
						v_u_10.Arc.EmitAttachment(v218)
						v_u_10.Arc.ToggleAttachment(v218, true, 1)
					end,
					["67"] = function()
						-- upvalues: (copy) v_u_200, (ref) v_u_41, (copy) v_u_198, (ref) v_u_10
						local v219 = v_u_200:Task(v_u_41.CustomVFX["6"]:Clone())
						v219.Parent = v_u_198
						v_u_10.Arc.EmitAttachment(v219)
						v_u_10.Arc.ToggleAttachment(v219, true, 0.533)
					end
				}
				v_u_200:Task(v_u_199:GetMarkerReachedSignal("vfx"):Connect(function(p221)
					-- upvalues: (ref) v_u_10, (copy) p_u_194, (copy) v_u_220, (ref) v_u_41, (copy) p_u_195
					if v_u_10.Distance_Far(p_u_194, 100) then
						if v_u_220[p221] then
							v_u_220[p221]()
							return
						end
						local v222 = v_u_41.VFX:FindFirstChild(p221)
						if v222 then
							local v223 = v222:GetAttribute("on")
							if v223 and v223 == "Victim" then
								if p_u_195 and p_u_195.Parent ~= nil then
									v_u_10.Arc.CloneAndEmit(v222, p_u_195[v222:GetAttribute("attached")])
									return
								end
							else
								v_u_10.Arc.CloneAndEmit(v222, p_u_194[v222:GetAttribute("attached")])
							end
						end
					end
				end))
			end
		end,
		["Minigame"] = function(p224)
			-- upvalues: (ref) v_u_19
			if p224.Parent then
				v_u_19.DoEvent(p224)
			end
		end
	}
	v_u_35.Effects:Connect(function(p226, ...)
		-- upvalues: (ref) v_u_225
		local v227 = v_u_225[p226]
		if v227 then
			v227(...)
		end
	end)
end
function v38.KnitInit(_)
	-- upvalues: (ref) v_u_35, (copy) v_u_1, (ref) v_u_36, (ref) v_u_37
	v_u_35 = v_u_1.GetService("AtonementService")
	v_u_36 = v_u_1.GetController("HitboxController")
	v_u_37 = v_u_1.GetController("FXController")
end
return v38