-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "ReversalRedMaxController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (ref) v_u_10, (copy) v_u_7, (copy) v_u_3, (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_5, (ref) v_u_9
	local v_u_48 = {
		["Aerial"] = function(p13, p14)
			-- upvalues: (ref) v_u_11
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = p13:FindFirstChild("Humanoid")
				if v16 then
					local v17 = Instance.new("BodyGyro", v15)
					v17.P = 10000
					v17.MaxTorque = Vector3.new(40000, 40000, 40000)
					p14.Position = v15.Position + Vector3.new(0, 12, 0)
					v16.PlatformStand = true
					repeat
						local v18 = v_u_11:GetMouseTarget()
						v17.CFrame = CFrame.new(v15.Position, v18)
						task.wait()
					until not p14.Parent
					v17:Destroy()
					v16.PlatformStand = false
				end
			else
				return
			end
		end,
		["Swing"] = function(p19)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_10:PlaySound(v_u_7.Gojo.ReversalRed.Aim, v20, game.SoundService.Effect)
			end
		end,
		["Red"] = function(p21)
			-- upvalues: (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			v_u_3:Create(p21, TweenInfo.new(1), {
				["Size"] = Vector3.new(1, 1, 1)
			}):Play()
			v_u_3:Create(p21.Light, TweenInfo.new(1), {
				["Brightness"] = 15,
				["Range"] = 15
			}):Play()
			v_u_10:PlaySound(v_u_7.Gojo.ReversalRed.MaxCharge, p21, game.SoundService.Effect)
			p21.Glow:Emit(3)
			p21.Wind:Emit(20)
			v_u_3:Create(p21.Weld, TweenInfo.new(0.95, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
				["C1"] = p21.Weld.C1 * CFrame.new(0, 0, -4)
			}):Play()
			v_u_3:Create(p21.Charge, TweenInfo.new(0.4), {
				["TimeScale"] = 1
			}):Play()
			task.wait(0.3)
			v_u_3:Create(p21.Beam, TweenInfo.new(1), {
				["Width0"] = 10,
				["Width1"] = 40
			}):Play()
			v_u_3:Create(p21.Beam2, TweenInfo.new(0.75), {
				["Width1"] = 30
			}):Play()
			v_u_3:Create(p21.AttachmentEnd, TweenInfo.new(0.75), {
				["Position"] = Vector3.new(0, 0, 18)
			}):Play()
			task.wait(0.1)
			p21.Charge.Enabled = false
			task.wait(0.35)
			p21.Charging:Emit(5)
		end,
		["Fire"] = function(p22, p23)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v24 = p22:FindFirstChild("HumanoidRootPart")
			if v24 then
				v_u_10:PlaySound(v_u_7.Gojo.ReversalRed.MaxFire, v24, game.SoundService.Effect)
				local v25 = v_u_6.Gojo.ReversalRed.RedMaxFire:Clone()
				v25.Parent = workspace.Effects
				v25.CFrame = p23 * CFrame.new(0, 1, -55)
				v25.Sparks:Emit(75)
				v25.Attachment.ChargeFire:Emit(10)
				v_u_3:Create(v25, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(0, 0, 100),
					["Color"] = Color3.new(1, 0, 0)
				}):Play()
				v_u_2:AddItem(v25, 1)
				if v_u_4.Character == p22 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					local v26 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
					v26.Parent = game.Lighting
					task.wait(0.04)
					v26.TintColor = Color3.new(1, 1, 1)
					task.wait(0.04)
					v26.Brightness = 200
					v26.Contrast = -1000
					task.wait(0.04)
					v26:Destroy()
				end
			end
		end,
		["Explode"] = function(p27)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v28 = v_u_6.Gojo.ReversalRed.RedExplode:Clone()
			v28.Position = p27
			v28.Parent = workspace.Effects
			v_u_2:AddItem(v28, 2)
			v28.Burst:Emit(1)
			v28.Sparks:Emit(15)
			v28.Wind:Emit(6)
			v28.Dust:Emit(6)
			v_u_3:Create(v28.Light, TweenInfo.new(0.5), {
				["Brightness"] = 0
			}):Play()
			v_u_10:PlaySound(v_u_7.Gojo.ReversalRed.Explode, v28, game.SoundService.Effect)
		end,
		["Hit"] = function(p29)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_10:Flash(p29, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit" .. math.random(1, 4)), v30, game.SoundService.Effect)
				if v_u_4.Character == p29 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					local v31 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
					v31.Parent = game.Lighting
					task.wait(0.04)
					v31.TintColor = Color3.new(1, 1, 1)
					task.wait(0.04)
					v31.Brightness = 200
					v31.Contrast = -1000
					task.wait(0.04)
					v31:Destroy()
				end
			end
		end,
		["Music"] = function(p32)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v33 = p32:FindFirstChild("HumanoidRootPart")
			if v33 then
				task.wait(0.1)
				v_u_10:PlaySound(v_u_7.Gojo.Remember, v33, game.SoundService.Music)
			end
		end,
		["BlackFlashImpact"] = function(p34, p35)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3
			if p34:FindFirstChild("HumanoidRootPart") then
				local v36 = p35:FindFirstChild("HumanoidRootPart")
				if v36 then
					local v37 = v_u_5.Utils.Itadori.DivergentFist.FinisherDrag:Clone()
					v37.Parent = v36
					v_u_2:AddItem(v37, 0.8)
					v_u_10:Flash(p35, Color3.new(1, 0, 0), 0.8)
					v_u_10:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlashHit, v36, game.SoundService.Effect)
					v_u_10:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlash, v36, game.SoundService.Effect)
					if v_u_4.Character == p34 or v_u_4.Character == p35 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
						local v38 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v38.Brightness = -v38.Brightness
						v38.Contrast = -v38.Contrast
						v38.Parent = game.Lighting
						v_u_3:Create(v38, TweenInfo.new(1.2, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["TintColor"] = Color3.new(1, 1, 1)
						}):Play()
						v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(0.8, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
							["FieldOfView"] = 40
						}):Play()
						local v39 = v_u_8.CurrentShaker:ShakeSustain(v_u_8.Presets.HeavyHit)
						task.wait(0.8)
						v39:StartFadeOut(0.5)
						v38:Destroy()
						v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(0.8, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
							["FieldOfView"] = 70
						}):Play()
					end
				end
			else
				return
			end
		end,
		["BlackFlashHit"] = function(p40, p41)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v_u_42 = p40:FindFirstChild("HumanoidRootPart")
			if v_u_42 then
				local v43 = p41:FindFirstChild("HumanoidRootPart")
				if v43 then
					local v_u_44 = v_u_6.Gojo.BlackFlashHit:Clone()
					v_u_44.Position = v43.Position
					v_u_44.Parent = workspace.Effects
					v_u_2:AddItem(v_u_44, 2)
					v_u_10:Flash(p41, Color3.new(1, 0, 0), 2)
					v_u_10:PlaySound(v_u_7.Mahito.BlackFlash, v43, game.SoundService.Effect)
					v_u_44.Wind2:Emit(8)
					task.delay(0.2, function()
						-- upvalues: (copy) v_u_44, (ref) v_u_6, (copy) v_u_42, (ref) v_u_3, (ref) v_u_2
						v_u_44.Blast:Destroy()
						v_u_44.Sparks:Emit(30)
						v_u_44.Sparks2:Emit(30)
						v_u_44.Lightning:Emit(40)
						local v45 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
						v45.CFrame = v_u_42.CFrame * CFrame.new(2, 1, -5)
						v45.Parent = workspace.Effects
						v45.Wind:Emit(20)
						v45.Sparks:Emit(20)
						v45.Flare:Emit(20)
						v45.Lightning:Emit(25)
						v45.Back1.Back:Emit(1)
						v45.Back2.Back:Emit(1)
						v_u_3:Create(v45.Back1, TweenInfo.new(2), {
							["CFrame"] = v45.Back1.CFrame - v45.Back1.CFrame.LookVector * 20
						}):Play()
						v_u_3:Create(v45.Back2, TweenInfo.new(2), {
							["CFrame"] = v45.Back2.CFrame - v45.Back2.CFrame.LookVector * 20
						}):Play()
						v_u_3:Create(v45.PointLight, TweenInfo.new(1), {
							["Brightness"] = 0
						}):Play()
						v_u_2:AddItem(v45, 3)
					end)
					v_u_44.BillboardGui.Enabled = false
					if v_u_4.Character == p40 or v_u_4.Character == p41 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						local v46 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v46.Parent = game.Lighting
						task.wait(0.03)
						v46.Brightness = 200
						v46.Contrast = -1000
						task.wait(0.03)
						v46.TintColor = Color3.new(1, 1, 1)
						v46.Brightness = -200
						v46.Contrast = 1000
						task.wait(0.03)
						v46.Brightness = 200
						v46.Contrast = -1000
						task.wait(0.03)
						v46.Brightness = -200
						v46.Contrast = 1000
						task.wait(0.03)
						v46:Destroy()
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						game.Lighting.ExposureCompensation = 2
						v_u_3:Create(game.Lighting, TweenInfo.new(1), {
							["ExposureCompensation"] = 0
						}):Play()
					end
				end
			else
				return
			end
		end,
		["Finisher"] = function(p47)
			-- upvalues: (ref) v_u_10
			if p47.HumanoidRootPart then
				v_u_10:Bleed(p47)
			end
		end
	}
	v_u_9.Effects:Connect(function(p49, ...)
		-- upvalues: (copy) v_u_48
		local v50 = v_u_48[p49]
		if v50 then
			v50(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("ReversalRedMaxService")
	v_u_10 = v_u_1.GetController("FXController")
	v_u_11 = v_u_1.GetController("ToolController")
end
return v12