-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = require(v5.Modules.LightningBeams)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "JudgeReachController"
})
local function v_u_22(p14, p15)
	local v16 = {}
	for _, v17 in pairs(p14.Size.Keypoints) do
		local v18 = NumberSequenceKeypoint.new
		local v19 = v17.Time
		local v20 = v17.Value * p15
		local v21 = v17.Envelope * p15
		table.insert(v16, v18(v19, v20, v21))
	end
	p14.Size = NumberSequence.new(v16)
end
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_22, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (copy) v_u_3, (ref) v_u_12
	local v_u_68 = {
		["PunchHit"] = function(p23)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				v_u_11:Flash(p23, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Yuta.M1.Hit4, v24, game.SoundService.Effect)
			end
		end,
		["StartSound"] = function(p25)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v26 = p25:FindFirstChild("HumanoidRootPart")
			if v26 then
				v_u_11:PlaySound(v_u_7.Hiromi.JudgeReachStart, v26, game.SoundService.Effect)
			end
		end,
		["SwingSound"] = function(p27)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v28 = p27:FindFirstChild("HumanoidRootPart")
			if v28 then
				v_u_11:PlaySound(v_u_7.Hiromi.JudgeReachSwing, v28, game.SoundService.Effect)
			end
		end,
		["NormalSound"] = function(p29)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_11:PlaySound(v_u_7.Hiromi.JudgeReach, v30, game.SoundService.Effect)
			end
		end,
		["FinisherSound"] = function(p31)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v32 = p31:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_11:PlaySound(v_u_7.Hiromi.JudgeReachFinisher, v32, game.SoundService.Effect)
			end
		end,
		["PunchImpact"] = function(p33, p34)
			-- upvalues: (ref) v_u_6, (ref) v_u_22, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v35 = p33:FindFirstChild("HumanoidRootPart")
			if v35 then
				local v36 = v_u_6.Itadori.CrushingBlow:Clone()
				v36.PointLight:Destroy()
				v36.Beam:Destroy()
				v36.CFrame = CFrame.lookAlong(p34.Torso.Position, v35.CFrame.LookVector) * CFrame.Angles(1.5707963267948966, 0, 0)
				v36.Parent = workspace.Effects
				v36.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v_u_22(v36.Floor.Ring, 0.6)
				v36.Floor.Ring:Emit(10)
				v36.Floor.Wind2:Emit(8)
				v_u_2:AddItem(v36, 1.5)
				if v_u_4.Character == p33 or v_u_4.Character == p34 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["SpinRing"] = function(p37)
			-- upvalues: (ref) v_u_6, (ref) v_u_22, (ref) v_u_2
			local v38 = p37:FindFirstChild("HumanoidRootPart")
			if v38 then
				local v39 = v_u_6.Yuta.Veilstep.Spin.SpinRing:Clone()
				v_u_22(v39.Ring, 1.5)
				v39.Parent = v38
				v_u_2:AddItem(v39, 0.5)
				v39.CFrame = v39.CFrame * CFrame.Angles(0, 0, 1.5707963267948966)
				v39.Ring:Emit(10)
			end
		end,
		["Grapple"] = function(p40, p41, p42)
			-- upvalues: (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3
			local v43 = p40:FindFirstChild("HumanoidRootPart")
			if not v43 then
				return
			end
			local v44 = p40.SetAssets:FindFirstChild("Gavel")
			if not v44 then
				return
			end
			local v45 = Instance.new("Model", v44.Extensions)
			v_u_2:AddItem(v45, 3)
			for _, v46 in v44:GetChildren() do
				if v46:IsA("BasePart") then
					v46.Transparency = 1
				end
			end
			v_u_11:PlaySound(v_u_7.Hiromi.Grapple.Fire, v43, game.SoundService.Effect)
			local v47 = v_u_9.new(v44.A, p42.RootAttachment, 5, v45)
			v47.Color = Color3.fromRGB(90, 76, 66)
			v47.Material = Enum.Material.Wood
			v47.FadeLength = 0.01
			v47.PulseSpeed = 100
			v47.MaxRadius = 0
			v47.MinRadius = 0
			v47.AnimationSpeed = 10
			v47.MinThicknessMultiplier = 0.4
			v47.MaxThicknessMultiplier = 0.4
			local v48 = false
			while true do
				if p41.Value == 2 and v48 == false then
					v47.MaxRadius = 0.5
					task.wait(0.05)
					v47.MaxRadius = 1
					task.wait(0.05)
					v47.MaxRadius = 3
					task.wait(0.05)
					v47.MaxRadius = 5
					task.wait(0.05)
					v47.MaxRadius = 6.5
					task.wait(0.05)
					v47.MaxRadius = 6.75
					task.wait(0.05)
					v47.MaxRadius = 5.5
					task.wait(0.05)
					v47.MaxRadius = 3
					task.wait(0.05)
					v47.MaxRadius = 1
					task.wait(0.05)
					v47.MaxRadius = 0
					v48 = true
				end
				task.wait()
				if not (p41 and p41.Parent) then
					local v49 = v_u_6.Hiromi.GavelFire:Clone()
					v49.Position = p42.Position
					v49.Parent = workspace.Effects
					v_u_2:AddItem(v49, 0.1)
					v47.Attachment1 = v49.Attachment
					v_u_3:Create(v49, TweenInfo.new(0.1), {
						["Position"] = v44.Position
					}):Play()
					task.wait(0.1)
					v47:Destroy()
					for _, v50 in v44:GetChildren() do
						if v50:IsA("BasePart") then
							v50.Transparency = 0
						end
					end
					return
				end
			end
		end,
		["Hit"] = function(p51, p52)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v53 = p52:FindFirstChild("HumanoidRootPart")
			if v53 then
				local v54 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v54.Position = v53.Position
				v54.Parent = workspace.Effects
				v_u_2:AddItem(v54, 1)
				v54.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 0.498039))
				v54.Wind.Color = v54.Sparks.Color
				v54.Wind2.Color = v54.Sparks.Color
				v54.Sparks:Emit(50)
				v54.Wind:Emit(7)
				v54.Wind2:Emit(7)
				v_u_11:Flash(p52, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Hakari.EnergySurge.Hit1, v53, game.SoundService.Effect)
				if v_u_4 == p51 or v_u_4.Character == p52 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Jump"] = function(p55, p56, p57)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_12
			local v58 = p56.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if not v58 then
				return
			end
			local v59 = p57 * 5
			if v_u_4.Character == v58.Parent then
				v_u_3:Create(p56, TweenInfo.new(0.3), {
					["P"] = 50000
				}):Play()
				repeat
					p56.Position = p55.Position - v59
					v58.CFrame = CFrame.lookAlong(v58.Position, v59)
					task.wait()
				until not (p56.Parent and p55)
				::l6::
				return
			else
				while true do
					if v_u_12.lastRecvServer[v58.Parent] ~= nil then
						v_u_12.lastRecvServer[v58.Parent] = false
					end
					local v60 = CFrame.lookAlong(p55.Position, v59) - v59
					v58.CFrame = v58.CFrame:Lerp(v60, 0.075)
					task.wait()
					if not (p56.Parent and p55) then
						goto l6
					end
				end
			end
		end,
		["FlashBack"] = function(p61, p62)
			-- upvalues: (ref) v_u_11
			if p61:FindFirstChild("HumanoidRootPart") then
				local v63 = v_u_11:Flash(p61, Color3.fromRGB(255, 170, 0), p62 or 0.5)
				for _, v64 in pairs(v63:GetChildren()) do
					local v65 = v64.Size.X
					local v66 = v64.Size.Y
					v64.Size = Vector3.new(v65, v66, 0.1)
					local v67 = v64.Weld
					v67.C0 = v67.C0 * CFrame.new(0, 0, -0.5 * v63:GetScale())
				end
			end
		end
	}
	JudgeReachService.Effects:Connect(function(p69, ...)
		-- upvalues: (copy) v_u_68
		local v70 = v_u_68[p69]
		if v70 then
			v70(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (copy) v_u_1, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12
	JudgeReachService = v_u_1.GetService("JudgeReachService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("JoinController")
end
return v13