-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {}
local v_u_2 = game:GetService("TweenService")
game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Debris")
local v_u_4 = task.spawn
local v_u_5 = task.wait
local v_u_6 = table.clear
local v_u_7 = table.find
local v_u_8 = CFrame.new
local _ = vector.create
local v_u_9 = Instance.new
local v_u_10 = TweenInfo.new
local v_u_11 = workspace.Effects
function v_u_1.Enabled(p12, p13, p14, p15, p16, p17)
	-- upvalues: (copy) v_u_7, (copy) v_u_3
	local v18 = next
	local v19, v20 = p12:GetDescendants()
	for _, v21 in v18, v19, v20 do
		if p17 and v_u_7(p17, v21.ClassName) or v21:IsA("ParticleEmitter") then
			v21.Enabled = p13
		end
	end
	if p15 and p14 then
		local v22 = Instance.new("Weld")
		v22.Part0 = p12
		v22.Part1 = p14
		v22.Parent = p12
	end
	if p16 then
		v_u_3:AddItem(p12, p16)
	end
end
function v_u_1.Emit(p23, p24, p25, p26, p27)
	-- upvalues: (copy) v_u_11, (copy) v_u_3
	local v28 = p23:Clone()
	if p25 and p24 then
		local v29 = Instance.new("Weld")
		v29.Part0 = v28
		v29.Part1 = p24
		if p27 then
			v29.C0 = p27
		end
		v29.Parent = v28
	else
		v28.CFrame = p24
	end
	v28.Parent = v_u_11
	local v30 = next
	local v31, v32 = v28:GetDescendants()
	for _, v33 in v30, v31, v32 do
		if v33:IsA("ParticleEmitter") then
			v33:Emit(v33:GetAttribute("EmitCount"))
		end
	end
	v_u_3:AddItem(v28, p26 or 5)
end
function v_u_1.EmitMesh(p34, p35)
	-- upvalues: (copy) v_u_1, (copy) v_u_11, (copy) v_u_3
	local v36 = p34:Clone()
	local v37 = v_u_1.HandleMesh
	if typeof(p35) == "Instance" then
		p35 = p35.CFrame or p35
	end
	local v38 = v37(v36, p35)
	v36.Parent = v_u_11
	v_u_3:AddItem(v36, v38)
end
local function v_u_46(p39, p40)
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_46
	local v41 = next
	local v42, v43 = p40:GetChildren()
	for _, v44 in v41, v42, v43 do
		if v44:IsA("BasePart") then
			local v45 = v_u_9("Weld")
			v45.Part0 = v44
			v45.Part1 = p39
			v45.C0 = v_u_8()
			v45.C1 = p39.CFrame:ToObjectSpace(v44.CFrame)
			v45.Parent = v44
		elseif v44:IsA("Model") then
			v_u_46(p39, v44)
		end
	end
end
function v_u_1.TweenMesh(p_u_47, p_u_48, p_u_49, p_u_50)
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_11, (copy) v_u_1, (copy) v_u_3, (copy) v_u_5, (copy) v_u_2, (copy) v_u_10, (copy) v_u_8, (copy) v_u_46
	local v_u_51 = p_u_47:FindFirstChild("Start")
	local v_u_52 = p_u_47:FindFirstChild("End")
	if v_u_51 and v_u_52 then
		local v_u_53 = p_u_47:GetAttribute("RepeatCount")
		local v_u_54 = p_u_47:GetAttribute("RepeatDelay")
		if v_u_53 and v_u_53 > 0 then
			local v_u_55 = p_u_47:Clone()
			v_u_55:SetAttribute("RepeatCount", nil)
			local v_u_56 = p_u_47.Parent
			if v_u_56 then
				v_u_56 = p_u_47.Parent:FindFirstChild("Primary")
			end
			local v_u_57 = v_u_56 and v_u_56.CFrame or v_u_55:GetAttribute("PrimaryCFrame")
			if v_u_56 then
				v_u_55:SetAttribute("PrimaryCFrame", v_u_57)
			end
			local v_u_58 = nil
			local v_u_59 = v_u_55:GetPivot()
			if p_u_48 then
				p_u_49 = p_u_48.RootPart or p_u_49
			end
			v_u_4(function()
				-- upvalues: (copy) v_u_53, (copy) p_u_49, (copy) v_u_56, (ref) v_u_58, (copy) v_u_57, (copy) v_u_59, (copy) v_u_55, (ref) v_u_9, (copy) p_u_48, (ref) v_u_11, (ref) v_u_1, (copy) p_u_50, (ref) v_u_3, (copy) v_u_54, (ref) v_u_5
				for _ = 1, v_u_53 do
					local v60 = p_u_49
					local v61 = typeof(v60) == "Instance" and p_u_49.CFrame or p_u_49
					if v_u_56 then
						if not v_u_58 then
							local v62 = v_u_57:ToObjectSpace(v_u_59)
							v_u_58 = v61:ToObjectSpace(v_u_57) * v62
						end
						v61 = v61 * v_u_58
					end
					if not v61 then
						break
					end
					local v63 = v_u_55:Clone()
					if not v63.PrimaryPart then
						local v64 = v_u_9("Part")
						v64.Name = "Primary"
						v64.CFrame = v_u_59
						v64.Anchored = not p_u_48
						v64.Size = Vector3.new(1, 1, 1)
						v64.CanCollide = false
						v64.CanTouch = false
						v64.CanQuery = false
						v64.Transparency = 1
						v64.Parent = v63
						v63.PrimaryPart = v64
						if p_u_48 then
							p_u_48.Primary = v64
						end
					end
					v63:SetPrimaryPartCFrame(v61)
					v63.Parent = v_u_11
					v_u_3:AddItem(v63, (v_u_1.TweenMesh(v63, p_u_48, nil, p_u_50)))
					if v_u_54 then
						v_u_5(v_u_54)
					end
				end
				v_u_55:Destroy()
			end)
		end
		local v_u_65 = v_u_51:FindFirstChildOfClass("Decal")
		local v_u_66 = v_u_52:FindFirstChildOfClass("Decal")
		local v_u_67 = v_u_51:FindFirstChildOfClass("SpecialMesh")
		local v_u_68 = v_u_52:FindFirstChildOfClass("SpecialMesh")
		local v_u_69, v_u_70
		if v_u_65 then
			v_u_69 = p_u_47:GetAttribute("Decal_TweenParams")
			if v_u_69 then
				v_u_69 = tostring(p_u_47:GetAttribute("Decal_TweenParams")):split(",")
			end
			if v_u_69 then
				v_u_70 = v_u_69[1]
			end
			if v_u_69 then
				v_u_69 = v_u_69[2]
			end
		else
			v_u_70 = nil
			v_u_69 = nil
		end
		local v_u_71, v_u_72
		if v_u_67 then
			v_u_71 = p_u_47:GetAttribute("Mesh_TweenParams")
			if v_u_71 then
				v_u_71 = tostring(p_u_47:GetAttribute("Mesh_TweenParams")):split(",")
			end
			if v_u_71 then
				v_u_72 = v_u_71[1]
			end
			if v_u_71 then
				v_u_71 = v_u_71[2]
			end
		else
			v_u_72 = nil
			v_u_71 = nil
		end
		local v_u_73 = p_u_47:GetAttribute("Part_TweenParams")
		if v_u_73 then
			v_u_73 = tostring(p_u_47:GetAttribute("Part_TweenParams")):split(",")
		end
		if v_u_73 then
			local v_u_74 = v_u_73[1]
		end
		if v_u_73 then
			v_u_73 = v_u_73[2]
		end
		local v_u_75 = tonumber(p_u_47:GetAttribute("Duration")) or tonumber(p_u_47:GetAttribute("Lifetime")) or (p_u_47:GetAttribute("EffectDuration") and (p_u_47:GetAttribute("EffectDuration").Max or 1) or 1)
		local v76 = tonumber(p_u_47:GetAttribute("StartTransparency")) or 1
		local v_u_77
		if v_u_65 then
			v_u_77 = tonumber(p_u_47:GetAttribute("Decal_StartTransparency")) or v76
			v_u_65.Transparency = v_u_77
		else
			v_u_77 = nil
		end
		v_u_51.Transparency = v_u_65 and 1 or v76
		local v_u_78 = {}
		local v_u_79 = 0
		local function v_u_109(p80)
			-- upvalues: (copy) p_u_48, (ref) v_u_79, (copy) v_u_78, (ref) v_u_2, (copy) v_u_51, (ref) v_u_10, (ref) v_u_74, (ref) v_u_73, (copy) v_u_52, (ref) v_u_4, (ref) v_u_9, (ref) v_u_8, (ref) v_u_46, (copy) p_u_47, (copy) v_u_65, (ref) v_u_77, (ref) v_u_70, (ref) v_u_69, (copy) v_u_66, (copy) v_u_67, (ref) v_u_72, (ref) v_u_71, (copy) v_u_68
			if p_u_48 then
				local v81 = p_u_48.Weld
				local v82 = p_u_48.Primary
				local v83 = v_u_9("Weld")
				v83.Part0 = v82
				v83.Part1 = v81
				v83.C0 = v_u_8()
				v83.C1 = v81.CFrame:ToObjectSpace(v82.CFrame)
				v83.Parent = v82
				v_u_46(p_u_48.Primary, p_u_47)
				v_u_74 = v_u_74 and Enum.EasingStyle[v_u_74] or Enum.EasingStyle.Quad
				v_u_73 = v_u_73 and Enum.EasingDirection[v_u_73] or Enum.EasingDirection.Out
				v_u_79 = v_u_79 + 1
				local v84 = v_u_78
				local v85 = v_u_79
				local v_u_86 = v_u_2:Create(v_u_51, v_u_10(p80, v_u_74, v_u_73), {
					["Size"] = v_u_52.Size,
					["Transparency"] = 1
				})
				local v_u_87 = v_u_78
				local v_u_88 = v_u_79
				v_u_86:Play()
				v_u_86:Destroy()
				v_u_4(function()
					-- upvalues: (copy) v_u_86, (copy) v_u_87, (copy) v_u_88
					v_u_86.Completed:Wait()
					if v_u_87.Callback and v_u_87[v_u_88] == v_u_86 then
						v_u_87.Callback()
						v_u_87.Callback = nil
					end
					v_u_87[v_u_88] = nil
				end)
				v84[v85] = nil
				v_u_79 = v_u_79 + 1
				local v89 = v_u_78
				local v90 = v_u_79
				local v_u_91 = v_u_2:Create(v_u_51.Weld, v_u_10(p80, v_u_74, v_u_73), {
					["C1"] = v_u_52.Weld.C1
				})
				local v_u_92 = v_u_78
				local v_u_93 = v_u_79
				v_u_91:Play()
				v_u_91:Destroy()
				v_u_4(function()
					-- upvalues: (copy) v_u_91, (copy) v_u_92, (copy) v_u_93
					v_u_91.Completed:Wait()
					if v_u_92.Callback and v_u_92[v_u_93] == v_u_91 then
						v_u_92.Callback()
						v_u_92.Callback = nil
					end
					v_u_92[v_u_93] = nil
				end)
				v89[v90] = nil
			else
				v_u_79 = v_u_79 + 1
				local v94 = v_u_78
				local v95 = v_u_79
				local v_u_96 = v_u_2:Create(v_u_51, v_u_10(p80, v_u_74 and Enum.EasingStyle[v_u_74] or Enum.EasingStyle.Quad, v_u_73 and Enum.EasingDirection[v_u_73] or Enum.EasingDirection.Out), {
					["CFrame"] = v_u_52.CFrame,
					["Transparency"] = 1,
					["Size"] = v_u_52.Size
				})
				local v_u_97 = v_u_78
				local v_u_98 = v_u_79
				v_u_96:Play()
				v_u_96:Destroy()
				v_u_4(function()
					-- upvalues: (copy) v_u_96, (copy) v_u_97, (copy) v_u_98
					v_u_96.Completed:Wait()
					if v_u_97.Callback and v_u_97[v_u_98] == v_u_96 then
						v_u_97.Callback()
						v_u_97.Callback = nil
					end
					v_u_97[v_u_98] = nil
				end)
				v94[v95] = nil
			end
			if v_u_65 then
				v_u_65.Transparency = v_u_77
				v_u_79 = v_u_79 + 1
				local v99 = v_u_78
				local v100 = v_u_79
				local v_u_101 = v_u_2:Create(v_u_65, v_u_10(p80, v_u_70 and Enum.EasingStyle[v_u_70] or Enum.EasingStyle.Quad, v_u_69 and Enum.EasingDirection[v_u_69] or Enum.EasingDirection.Out), {
					["Transparency"] = v_u_66.Transparency,
					["Color3"] = v_u_66.Color3
				})
				local v_u_102 = v_u_78
				local v_u_103 = v_u_79
				v_u_101:Play()
				v_u_101:Destroy()
				v_u_4(function()
					-- upvalues: (copy) v_u_101, (copy) v_u_102, (copy) v_u_103
					v_u_101.Completed:Wait()
					if v_u_102.Callback and v_u_102[v_u_103] == v_u_101 then
						v_u_102.Callback()
						v_u_102.Callback = nil
					end
					v_u_102[v_u_103] = nil
				end)
				v99[v100] = nil
				v_u_66.Transparency = 1
			end
			if v_u_67 then
				v_u_79 = v_u_79 + 1
				local v104 = v_u_78
				local v105 = v_u_79
				local v_u_106 = v_u_2:Create(v_u_67, v_u_10(p80, v_u_72 and Enum.EasingStyle[v_u_72] or Enum.EasingStyle.Quad, v_u_71 and Enum.EasingDirection[v_u_71] or Enum.EasingDirection.Out), {
					["Scale"] = v_u_68.Scale
				})
				local v_u_107 = v_u_78
				local v_u_108 = v_u_79
				v_u_106:Play()
				v_u_106:Destroy()
				v_u_4(function()
					-- upvalues: (copy) v_u_106, (copy) v_u_107, (copy) v_u_108
					v_u_106.Completed:Wait()
					if v_u_107.Callback and v_u_107[v_u_108] == v_u_106 then
						v_u_107.Callback()
						v_u_107.Callback = nil
					end
					v_u_107[v_u_108] = nil
				end)
				v104[v105] = nil
			end
		end
		v_u_109(v_u_75 / (p_u_50 and (p_u_50.Value or 1) or 1))
		if not p_u_50 then
			return v_u_75
		end
		local v_u_110 = time()
		local v_u_113 = p_u_50:GetPropertyChangedSignal("Value"):Connect(function()
			-- upvalues: (copy) v_u_78, (copy) v_u_109, (ref) v_u_75, (copy) v_u_110, (copy) p_u_50
			for v111, v112 in next, v_u_78 do
				v112:Cancel()
				v_u_78[v111] = nil
			end
			v_u_109((v_u_75 - (time() - v_u_110)) / p_u_50.Value)
		end)
		function v_u_78.Callback()
			-- upvalues: (copy) v_u_113
			v_u_113:Disconnect()
		end
		return v_u_75
	end
end
function v_u_1.HandleMesh(p114, p115, p116, ...)
	-- upvalues: (copy) v_u_1
	if not p114:IsA("Model") then
		return 0
	end
	local v117 = 2
	if p114.PrimaryPart then
		p114:SetPrimaryPartCFrame(p115)
		if p116 then
			p116.Primary = p114.PrimaryPart
		end
		local v118 = p114:GetChildren()
		local v119 = 0
		for _, v120 in next, v118 do
			if v120:IsA("Model") then
				v119 = v119 + 1
				local v121 = v_u_1.TweenMesh(v120, p116, p115, ...)
				if v117 < v121 then
					v117 = v121 + 2
				end
			end
		end
		if v119 == 0 then
			local v122 = v_u_1.TweenMesh(p114, p116, p115, ...)
			if v117 < v122 then
				return v122 + 2
			end
		end
	else
		p114:PivotTo(p115)
		local v123 = v_u_1.TweenMesh(p114, nil, p115)
		if v117 < v123 then
			v117 = v123 + 2
		end
	end
	return v117
end
function v_u_1.HandleVFXFromString(p124, p125, p126, p127, p128)
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_11, (copy) v_u_7, (copy) v_u_9, (copy) v_u_3, (copy) v_u_1, (copy) v_u_6
	local v129 = typeof(p126)
	if v129 == "Vector3" then
		p126 = v_u_8(p126)
	end
	local v130 = next
	local v131, v132 = p124:split("\n")
	local v133 = p126
	local v134 = {}
	local v135 = 0
	for _, v136 in v130, v131, v132 do
		local v137 = v136:split(" ")
		if v137 and #v137 > 0 then
			local v138 = v137[1]
			if v138 ~= "" then
				local v139 = #v138 - 1
				local v140 = tonumber(v138:sub(1, v139))
				local v141 = v137[4]
				local v142 = v141 and v141 ~= "Empty" and { unpack(v141:split(",", "")) } or v141
				local v143 = v137[2]
				local v144 = p125:FindFirstChild(v143)
				if v144 then
					local v145 = #v134 + 1
					local v146 = {
						["Wait"] = v140 - v135,
						["VFX"] = v144,
						["Command"] = v137[3],
						["Classes"] = v142
					}
					local v147
					if p127 then
						v147 = p127[v143] or nil
					else
						v147 = nil
					end
					v146.Function = v147
					v146.Weld = v137[5] and v137[5] == "Weld" and true or nil
					v134[v145] = v146
					v135 = v140
				else
					print(("Failed to find this VFX under the Assets (%s): [%s]"):format(v137[2], p125:GetFullName()))
				end
			end
		end
	end
	for v148, v149 in next, v134 do
		local v150 = p127 and (p127.AdjustSpeed or 1) or 1
		local v151 = v149.Wait / v150
		if v151 < 0 then
			print("Theres something wrong with these timestamps but it\'ll continue working anyway | SraikoVFX", v149)
		elseif v151 > 0 then
			v_u_5(v151)
		end
		local v152 = v149.VFX
		local v153 = v149.Command
		local v154 = v149.Classes
		local v155 = v149.Function
		if not v155 then
			if p127 then
				v155 = p127[v148]
			else
				v155 = p127
			end
		end
		local v156 = v149.Weld
		local v157 = v153 == "Emit" and "GetChildren" or (v153 == "EmitAll" and "GetDescendants" or (v153 == "Enable" and "GetChildren" or (v153 == "EnableAll" and "GetDescendants" or nil)))
		local v158 = v153 == "Emit" and v153 and v153 or (v153 == "EmitAll" and "Emit" or ((v153 == "Enable" or v153 == "EnableAll") and "Enabled" or (v153 == "Mesh" and "Meshes" or nil)))
		if v158 then
			local v159 = v153 == "Mesh"
			local v160 = v153 == "Emit" and true or v153 == "EmitAll"
			if v157 or v159 then
				local v161 = next
				local v162, v163 = v152[v158]:GetChildren()
				local v164 = v155 and {} or nil
				for _, v165 in v161, v162, v163 do
					local v166
					if v129 == "Instance" then
						v166 = v133.CFrame or v133
					else
						v166 = v133
					end
					local v167 = v165:Clone()
					if p128 then
						p128[#p128 + 1] = {
							["Object"] = v167,
							["Method"] = "Destroy",
							["Args"] = {}
						}
					end
					if v159 then
						local v168 = v167:FindFirstChild("Offset")
						if v168 then
							v168 = v167.Offset.Value
						end
						local v169 = v_u_1.HandleMesh
						if v168 then
							v166 = v166 * v168 or v166
						end
						v_u_3:AddItem(v167, (v169(v167, v166, v156 and ({
							["Weld"] = p126,
							["RootPart"] = v129 == "Instance" and v133 and v133 or nil
						} or nil) or nil)))
						v167.Parent = v_u_11
					else
						v167.CFrame = v166
						v167.Parent = v_u_11
						local v170 = next
						local v171, v172 = v167[v157](v167)
						local v173 = 2
						for _, v174 in v170, v171, v172 do
							local v175 = v174.ClassName
							if (not v154 or (v154 == "Empty" or v_u_7(v154, v175))) and (not v160 or v175 == "ParticleEmitter") then
								if v160 then
									v174[v158](v174, v174:GetAttribute("EmitCount"))
								else
									v174[v158] = true
								end
								if v175 ~= "Beam" then
									local v176 = v174.Lifetime
									local v177 = typeof(v176) == "NumberRange" and v174.Lifetime.Max or v174.Lifetime
									if v173 < v177 then
										v173 = v177 or v173
									end
								end
							end
						end
						if v156 then
							local v178 = v_u_9("Weld")
							v178.Part0 = v167
							v178.Part1 = v133
							v178.Parent = v167
						end
						v_u_3:AddItem(v167, v173)
					end
					if v164 then
						v164[#v164 + 1] = v167
					end
				end
				if v155 then
					v155(v164)
					v_u_6(v164)
				end
			else
				print("Failed to get style for (" .. v151 .. "s " .. v152.Name .. " " .. v153 .. ") so not handling the vfx for it! Available styles: [Emit, EmitAll, Enable, EnableAll, Mesh]")
			end
		else
			print("Failed to get path method for (" .. v151 .. "s " .. v152.Name .. " " .. v153 .. ") so not handling the vfx for it! Available path methods: [Emit, EmitAll, Enable, EnableAll, Mesh]")
		end
	end
	return true
end
return v_u_1