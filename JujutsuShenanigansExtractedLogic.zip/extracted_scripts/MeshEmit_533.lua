-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("TweenService")
local function v_u_16(p2, p3, p4, p5)
	local v6 = p2:GetAttribute(p4 .. "_TweenParams")
	local v7 = {
		{ "TweenStyle", p5 },
		{ "TweenDirection", Enum.EasingDirection.Out }
	}
	local v_u_8 = {}
	if typeof(v6) == "string" then
		local v9 = { v6:match("(%a+),(%a+)") }
		for v10 = 1, 2 do
			local v_u_11 = v9[v10]
			local v12 = v7[v10]
			local v_u_13 = v12[1]
			local v_u_14 = v12[2]
			if v_u_11 then
				if not pcall(function()
					-- upvalues: (copy) v_u_8, (copy) v_u_13, (copy) v_u_14, (copy) v_u_11
					v_u_8[v_u_13] = v_u_14.EnumType[v_u_11]
				end) then
					v_u_8[v_u_13] = v_u_14
				end
				local _ = v10 + 1
			else
				v_u_8[v_u_13] = v_u_14
			end
		end
	else
		for _, v15 in v7 do
			v_u_8[v15[1]] = v15[2]
		end
	end
	return TweenInfo.new(p3, v_u_8.TweenStyle, v_u_8.TweenDirection)
end
return function(p17, p18, p19, p_u_20, _)
	-- upvalues: (copy) v_u_1, (copy) v_u_16
	local v21 = p17.Parent:FindFirstChild("End")
	if v21 then
		local v22 = p17:Clone()
		local v23 = p17.Parent
		local v24 = tonumber(v23:GetAttribute("StartTransparency")) or 0
		if v22:IsA("MeshPart") then
			v22.Transparency = v24
		elseif v22:IsA("BasePart") and v22:FindFirstChildOfClass("Decal") then
			v22.Transparency = 1
		end
		v22.Parent = workspace.CurrentCamera
		local v25 = p17.Parent
		local v26 = tonumber(v25:GetAttribute("Duration")) or 0.1
		if v22:FindFirstChildOfClass("Decal") then
			v_u_1:Create(v22, v_u_16(p17.Parent, v26, "Part", Enum.EasingStyle.Cubic), {
				["Size"] = v21.Size,
				["CFrame"] = v21.CFrame
			}):Play()
		else
			v_u_1:Create(v22, v_u_16(p17.Parent, v26, "Part", Enum.EasingStyle.Cubic), {
				["Size"] = v21.Size,
				["CFrame"] = v21.CFrame,
				["Color"] = v21.Color
			}):Play()
			if p18 then
				v_u_1:Create(v22, v_u_16(p17.Parent, v26, "Part", Enum.EasingStyle.Cubic), {
					["Transparency"] = 1
				}):Play()
			else
				p17.Parent:GetAttribute("StartTransparency")
			end
		end
		local v27 = v22:FindFirstChildOfClass("SpecialMesh")
		local v28 = v21:FindFirstChildOfClass("SpecialMesh")
		if v27 and v28 then
			v_u_1:Create(v27, v_u_16(p17.Parent, v26, "Mesh", Enum.EasingStyle.Sine), {
				["Scale"] = v28.Scale
			}):Play()
		end
		local v29 = v22:FindFirstChildOfClass("Decal")
		local v30 = v21:FindFirstChildOfClass("Decal")
		if v29 and v30 then
			v29.Transparency = v24
			v_u_1:Create(v29, v_u_16(p17.Parent, v26, "Decal", Enum.EasingStyle.Cubic), {
				["Color3"] = v30.Color3
			}):Play()
			if p18 then
				v_u_1:Create(v29, v_u_16(p17.Parent, v26, "Decal", Enum.EasingStyle.Cubic), {
					["Transparency"] = 1
				}):Play()
			else
				p17.Parent:GetAttribute("StartTransparency")
			end
			if p19 then
				for _, v_u_31 in ipairs(v22:GetDescendants()) do
					if v_u_31:IsA("Decal") then
						task.spawn(function()
							-- upvalues: (copy) p_u_20, (copy) v_u_31
							for v32 = 1, #p_u_20 do
								v_u_31.Texture = p_u_20[v32]
								task.wait(0.016666666666666666)
							end
						end)
					end
				end
			end
		end
		task.delay(v26, v22.Destroy, v22)
		return v26
	end
	warn("Goal is not defined.")
end