-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("TextService")
local v_u_3 = game.Players.LocalPlayer
local v4 = {}
function getColor(p5, p6)
	local v7 = p6[1]
	local _ = p6[#p6]
	local v8 = v7.Value
	for v9 = 1, #p6 - 1 do
		if p6[v9].Time <= p5 and p5 <= p6[v9 + 1].Time then
			local v10 = p6[v9]
			local v11 = p6[v9 + 1]
			local v12 = (p5 - v10.Time) / (v11.Time - v10.Time)
			return v10.Value:lerp(v11.Value, v12)
		end
	end
	return v8
end
local function v_u_15(p13)
	for _, v14 in p13:GetChildren() do
		if v14.Name == "letter" then
			v14:SetAttribute("Ending", true)
			game.TweenService:Create(v14, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				["Position"] = v14.Position + UDim2.new(0, 0, 0, 50),
				["TextTransparency"] = 1,
				["TextStrokeTransparency"] = 1
			}):Play()
			game.Debris:AddItem(v14, 0.5)
		end
	end
end
local function v_u_51(p16, p17)
	-- upvalues: (copy) v_u_3, (copy) v_u_1, (copy) v_u_15, (copy) v_u_2
	local v18 = p17 or v_u_3
	local v_u_19 = v_u_3.PlayerGui:FindFirstChild(v18.Name .. "KJUI") or script.KJDialogue:Clone()
	local v20 = ""
	local v_u_21 = 0
	local v_u_22 = 0
	local v23 = 0
	if v_u_19:GetAttribute("Created") then
		v_u_19:SetAttribute("Created", os.clock())
	else
		local v_u_24 = v_u_19:WaitForChild("Holder"):WaitForChild("Template")
		local v25 = v_u_19.Holder
		v25.Position = v25.Position - UDim2.new(0, 0, 0, #v_u_1:GetTagged("KJUI") * 100)
		local v26 = v_u_24:WaitForChild("ImageLabel")
		v26.Position = v26.Position - UDim2.new(0, 0, 0, 100)
		v_u_24:WaitForChild("ImageLabel").ImageTransparency = 1
		local v27 = v_u_24:WaitForChild("Name")
		v27.Position = v27.Position - UDim2.new(0, 0, 0, 100)
		v_u_24:WaitForChild("Name").TextTransparency = 1
		v_u_24:WaitForChild("Name").TextStrokeTransparency = 1
		game.TweenService:Create(v_u_24:WaitForChild("ImageLabel"), TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["Position"] = v_u_24:WaitForChild("ImageLabel").Position + UDim2.new(0, 0, 0, 100),
			["ImageTransparency"] = 0
		}):Play()
		game.TweenService:Create(v_u_24:WaitForChild("Name"), TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["Position"] = v_u_24:WaitForChild("Name").Position + UDim2.new(0, 0, 0, 100),
			["TextTransparency"] = 0,
			["TextStrokeTransparency"] = 0
		}):Play()
		task.spawn(function()
			-- upvalues: (copy) v_u_19, (ref) v_u_15, (copy) v_u_24
			v_u_19:SetAttribute("Created", os.clock())
			repeat
				task.wait()
			until os.clock() - v_u_19:GetAttribute("Created") > 5 or not v_u_19.Parent
			v_u_19.Name = "deleting"
			v_u_15(v_u_19.Holder.Template)
			game.TweenService:Create(v_u_24:WaitForChild("ImageLabel"), TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
				["Position"] = v_u_24:WaitForChild("ImageLabel").Position - UDim2.new(0, 0, 0, 100),
				["ImageTransparency"] = 1
			}):Play()
			game.TweenService:Create(v_u_24:WaitForChild("Name"), TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
				["Position"] = v_u_24:WaitForChild("Name").Position - UDim2.new(0, 0, 0, 100),
				["TextTransparency"] = 1,
				["TextStrokeTransparency"] = 1
			}):Play()
			task.delay(1, function()
				-- upvalues: (ref) v_u_19
				v_u_19:Destroy()
			end)
		end)
	end
	v_u_19.Parent = v_u_3.PlayerGui
	v_u_19.Enabled = true
	v_u_19.Name = v18.Name .. "KJUI"
	v_u_19:AddTag("KJUI")
	v_u_19:WaitForChild("Holder"):WaitForChild("Template"):WaitForChild("Name").Text = v18.Name
	for _, v28 in p16 do
		v20 = v20 .. v28.Text
	end
	v_u_15(v_u_19.Holder.Template)
	for _, v29 in p16 do
		local v30 = string.split(v29.Text, "")
		local v31 = v29.Bold and Enum.Font.SourceSansBold or (v29.Italic and Enum.Font.SourceSansItalic or Enum.Font.SourceSans)
		for _, v32 in v30 do
			v_u_21 = v_u_21 + v_u_2:GetTextSize(v32, 25, v31, Vector2.new(100, 100)).X
		end
	end
	for _, v_u_33 in p16 do
		local v34 = string.split(v_u_33.Text, "")
		local v35 = v_u_33.Bold and Enum.Font.SourceSansBold or (v_u_33.Italic and Enum.Font.SourceSansItalic or Enum.Font.SourceSans)
		for _, v36 in v34 do
			local v37 = v_u_2:GetTextSize(v36, 25, v35, Vector2.new(100, 100))
			local v_u_38 = Instance.new("TextLabel")
			UDim2.new(0.5, v_u_22 - v_u_21 / 2 // 1, 0.5, 0)
			v_u_38.AnchorPoint = Vector2.new(0, 0.5)
			v_u_38.Position = UDim2.new(0.5, v_u_22 - v_u_21 / 2 // 1, 0.5, 10)
			v_u_38.Size = UDim2.new(0, v37.X, 0, v37.Y)
			v_u_38.Text = v36
			v_u_38.Name = "letter"
			v_u_38.Font = v35
			v_u_38.TextSize = 25
			v_u_38.Parent = v_u_19.Holder.Template
			v_u_38.BackgroundTransparency = 1
			v_u_38.TextStrokeColor3 = v_u_33.TextStrokeColor
			v_u_38.TextStrokeTransparency = 0
			v_u_38.TextStrokeTransparency = 1
			v_u_38.TextTransparency = 1
			task.delay(v23, function()
				-- upvalues: (copy) v_u_33, (copy) v_u_38, (copy) v_u_22, (copy) v_u_21, (copy) v_u_19
				local v39 = os.clock()
				repeat
					local v40 = (os.clock() - v39) / 0.35
					local v41 = math.min(v40, 1)
					local v42 = (os.clock() - v39) / v_u_33.Shake.Lifetime
					local v43 = math.min(v42, 1)
					local v44 = not v_u_33.Shake.Enabled and UDim2.new(0, 0, 0, 0) or UDim2.new(0, math.random(-v_u_33.Shake.Intensity, v_u_33.Shake.Intensity) * (1 - v43), 0, math.random(-v_u_33.Shake.Intensity, v_u_33.Shake.Intensity) * (1 - v43))
					local v45 = v41 - 1
					local v46 = math.pow(v45, 3) * 2.70158 + 1
					local v47 = v41 - 1
					local v48 = 1 - (v46 + math.pow(v47, 2) * 1.70158)
					v_u_38.TextStrokeTransparency = (1 - v41) ^ 10
					v_u_38.TextTransparency = v48
					v_u_38.TextSize = 25 + 25 * v48
					v_u_38.TextColor3 = getColor(v41, v_u_33.Color.Keypoints)
					v_u_38.Position = UDim2.new(0.5, v_u_22 - v_u_21 / 2 // 1, 0.5, 0) + v44
					task.wait()
					local v49 = os.clock() - v39
					local v50 = v_u_33.Shake.Lifetime
				until math.max(0.35, v50) < v49 or (not v_u_38 or (not v_u_38:IsDescendantOf(v_u_19) or v_u_38:GetAttribute("Ending")))
				if v_u_38 then
					v_u_38.TextStrokeTransparency = 0
					v_u_38.TextTransparency = 0
					v_u_38.TextSize = 25
					v_u_38.TextColor3 = v_u_33.Color.Keypoints[#v_u_33.Color.Keypoints].Value
					v_u_38.Position = UDim2.new(0.5, v_u_22 - v_u_21 / 2 // 1, 0.5, 0)
				end
			end)
			v23 = v23 + v_u_33.TypeSpeed
			v_u_22 = v_u_22 + v37.X
		end
	end
end
function v4.Speak(p52, p53)
	-- upvalues: (copy) v_u_51
	v_u_51(p53, p52)
end
return v4