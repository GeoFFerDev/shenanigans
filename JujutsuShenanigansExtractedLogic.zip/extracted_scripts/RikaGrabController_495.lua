-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v2 = game.ReplicatedStorage
local _ = v2.Animations
local _ = v2.Utils
local v_u_3 = v2.Sounds
require(v2.Modules.CameraShaker)
require(v2.Modules.BloodyZee)
local v_u_4 = nil
local v_u_5 = nil
local v6 = v_u_1.CreateController({
	["Name"] = "RikaGrabController"
})
function v6.KnitStart(_)
	-- upvalues: (ref) v_u_5, (copy) v_u_3
	local v_u_10 = {
		["GrabSound"] = function(p7, p8)
			-- upvalues: (ref) v_u_5, (ref) v_u_3
			v_u_5:PlaySound(v_u_3.Yuta.Rika.GrabStart, p7, game.SoundService.Effect)
			local v_u_9 = v_u_5:PlaySound(v_u_3.Yuta.Rika.GrabHold, p7, game.SoundService.Effect)
			p8.AncestryChanged:Once(function()
				-- upvalues: (copy) v_u_9
				v_u_9:Destroy()
			end)
		end
	}
	RikaGrabService.Effects:Connect(function(p11, ...)
		-- upvalues: (copy) v_u_10
		local v12 = v_u_10[p11]
		if v12 then
			v12(...)
		end
	end)
end
function v6.KnitInit(_)
	-- upvalues: (copy) v_u_1, (ref) v_u_4, (ref) v_u_5
	RikaGrabService = v_u_1.GetService("RikaGrabService")
	v_u_4 = v_u_1.GetController("HitboxController")
	v_u_5 = v_u_1.GetController("FXController")
end
return v6