-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "SlicingExorcismController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_4, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (copy) v_u_7, (copy) v_u_3, (copy) v_u_6, (ref) v_u_10
	local v_u_46 = {
		["Saw"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_8.Choso.SlicingExorcism.Saw1, v14, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_8.Choso.Convergence, v14, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_8.Choso.BloodBurst, v14, game.SoundService.Effect)
				task.wait(0.4)
				v_u_11:PlaySound(v_u_8.Itadori.CursedStrikes.Spin, v14, game.SoundService.Effect)
			end
		end,
		["Interp"] = function(p_u_15)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_2
			local v_u_16 = p_u_15.CFrame
			local v_u_17 = tick()
			local v_u_18 = p_u_15:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_16, (copy) p_u_15, (ref) v_u_17
				v_u_16 = p_u_15.CFrame
				v_u_17 = tick()
			end)
			v_u_11:PlaySound(v_u_8.Mahito.CrushingRushdown.HairPull, p_u_15, game.SoundService.Effect)
			local v_u_19 = v_u_11:PlaySound(v_u_8.Choso.SlicingExorcism.Saw, p_u_15, game.SoundService.Effect, true)
			v_u_4:Create(v_u_19, TweenInfo.new(0.3), {
				["Volume"] = 1
			}):Play()
			local v_u_20 = nil
			v_u_20 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_15, (ref) v_u_20, (copy) v_u_18, (ref) v_u_4, (copy) v_u_19, (ref) v_u_16, (ref) v_u_17
				if p_u_15.Position and p_u_15.Transparency ~= 1 then
					workspace:BulkMoveTo({ p_u_15 }, { v_u_16 + v_u_16.LookVector * (150 * (tick() - v_u_17)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_20:Disconnect()
					v_u_18:Disconnect()
					v_u_4:Create(v_u_19, TweenInfo.new(0.3), {
						["Volume"] = 0
					}):Play()
				end
			end)
		end,
		["Hit"] = function(p21, p22)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			if v23 then
				v_u_11:Flash(p22, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Mahito.DrillSplit.Drill, v23, game.SoundService.Effect)
				if v_u_5.Character == p21 or v_u_5.Character == p22 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Hit2"] = function(p24)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				v_u_11:Flash(p24, Color3.new(1, 0, 0))
				v_u_11:PlaySound(v_u_8.Choso.PiercingBlood.Hit, v25, game.SoundService.Effect)
			end
		end,
		["Reflect"] = function(p26)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_9
			p26.Center.Sparks:Emit(10)
			v_u_11:PlaySound(v_u_8.Choso.SlicingExorcism.Reflect, p26, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p26.Position).Magnitude < 140 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
			end
		end,
		["Finisher"] = function(p27)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v28 = p27:FindFirstChild("HumanoidRootPart")
			if v28 then
				v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Explode, v28, game.SoundService.Effect)
				v_u_11:Bleed(p27)
			end
		end,
		["Flashup"] = function(p29, p30)
			-- upvalues: (ref) v_u_7
			if p29:FindFirstChild("HumanoidRootPart") then
				if p30 then
					for _, v31 in p30:GetChildren() do
						if v31:IsA("Attachment") and v31.ParticleEmitter.Enabled ~= false then
							v31.ParticleEmitter.Enabled = false
							v31.ParticleEmitter.Name = "Out"
							v_u_7.Choso.Supernova.Blood1.ParticleEmitter:Clone().Parent = v31
						end
					end
				end
			end
		end,
		["Blood"] = function(p32, p_u_33, p_u_34)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6, (ref) v_u_5, (ref) v_u_9
			local v_u_35 = p32:FindFirstChild("HumanoidRootPart")
			if v_u_35 then
				local v_u_36 = {
					0,
					0.5,
					1,
					1.5
				}
				local v_u_37 = v_u_7.Choso.PiercingBlood:Clone()
				v_u_37.CFrame = v_u_35.CFrame * CFrame.new(0, 0, -9)
				v_u_37.Parent = workspace.Effects
				v_u_3:AddItem(v_u_37, v_u_36[p_u_34] + 1)
				v_u_37.Start.Blood.Speed = NumberRange.new(10, 400)
				v_u_11:PlaySound(v_u_8.Choso.PiercingBlood.Fire, v_u_35, game.SoundService.Effect)
				v_u_37.Start.Blood.Enabled = true
				v_u_37.Start.Burst.Enabled = true
				v_u_4:Create(v_u_37.End, TweenInfo.new(0.1), {
					["Position"] = Vector3.new(0, 0, -60)
				}):Play()
				v_u_4:Create(v_u_37.Beam, TweenInfo.new(0.3), {
					["Width0"] = 0.5,
					["Width1"] = 0.5
				}):Play()
				v_u_3:AddItem(v_u_37.Beam, v_u_36[p_u_34] + 0.3)
				task.delay(v_u_36[p_u_34], function()
					-- upvalues: (ref) v_u_4, (copy) v_u_37
					v_u_4:Create(v_u_37.Beam, TweenInfo.new(0.3), {
						["Width0"] = 0,
						["Width1"] = 0
					}):Play()
					v_u_37.Start.Blood.Enabled = false
					v_u_37.Start.Burst.Enabled = false
				end)
				local v38 = Instance.new("Model")
				local v39 = v_u_6.Utils.Itadori.RushWind:Clone()
				v39.CFrame = v_u_37.CFrame * CFrame.new(0, -1, 0)
				v39.Parent = v38
				v38.Parent = workspace.Effects
				v38:ScaleTo(0.6)
				v39.Ring:Emit(7)
				v39.Dash1.Dash:Emit(1)
				v39.Dash2.Dash:Emit(1)
				v_u_4:Create(v39, TweenInfo.new(1, Enum.EasingStyle.Quad), {
					["CFrame"] = v39.CFrame - v39.CFrame.LookVector * 16
				}):Play()
				v_u_3:AddItem(v38, 2)
				if v_u_5.Character == p32 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_37, (copy) v_u_35, (copy) v_u_36, (copy) p_u_34
					local v40 = tick()
					repeat
						v_u_37.CFrame = v_u_35.CFrame * CFrame.new(0, 0, -9)
						task.wait()
					until not v_u_35.Parent or tick() > v40 + v_u_36[p_u_34]
				end)
				if p_u_33 then
					for _, v41 in p_u_33:GetChildren() do
						if v41:IsA("Attachment") and v41.ParticleEmitter.Enabled ~= false then
							local v42 = v_u_7.Choso.PiercingBlood.Beam:Clone()
							v42.Attachment0 = v41
							v42.Attachment1 = v_u_37.Start
							v42.Parent = v41
							v_u_4:Create(v42, TweenInfo.new(v_u_36[p_u_34] + 0.3), {
								["Width0"] = 0,
								["Width1"] = 0
							}):Play()
						end
					end
					task.delay(v_u_36[p_u_34], function()
						-- upvalues: (copy) p_u_33
						for _, v43 in p_u_33:GetDescendants() do
							if v43:IsA("ParticleEmitter") or v43:IsA("Trail") then
								v43.Enabled = false
							end
						end
					end)
				end
				for v44 = 1, 4 do
					local v45 = v_u_7.Itadori.Shock:Clone()
					v45.CFrame = v_u_37.CFrame * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_37.CFrame.LookVector * (14 * v44)
					v45.Parent = workspace.Effects
					v_u_4:Create(v45, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v45, 0.15)
					task.wait(0.02)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p47, ...)
		-- upvalues: (copy) v_u_46
		local v48 = v_u_46[p47]
		if v48 then
			v48(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("SlicingExorcismService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12