-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.SraikoVFX)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "MechamaruController"
})
local function v_u_24(p14, p15, p16, p17)
	-- upvalues: (copy) v_u_2
	local v18 = p14:Clone()
	if p16 and p15 then
		local v19 = Instance.new("Weld")
		v19.Part0 = v18
		v19.Part1 = p15
		v19.Parent = v18
	else
		v18.CFrame = p15
	end
	v18.Parent = workspace.Effects
	local v20 = next
	local v21, v22 = v18:GetDescendants()
	for _, v23 in v20, v21, v22 do
		if v23:IsA("ParticleEmitter") then
			v23:Emit(v23:GetAttribute("EmitCount"))
		end
	end
	v_u_2:AddItem(v18, p17 or 5)
end
local function v_u_35(p25, p26, p27, p28, p29)
	-- upvalues: (copy) v_u_2
	local v30 = next
	local v31, v32 = p25:GetDescendants()
	for _, v33 in v30, v31, v32 do
		if v33:IsA("ParticleEmitter") then
			v33.Enabled = p26
		end
	end
	if p28 and p27 then
		local v34 = Instance.new("Weld")
		v34.Part0 = p25
		v34.Part1 = p27
		v34.Parent = p25
	end
	if p29 then
		v_u_2:AddItem(p25, p29)
	end
end
function v13.KnitStart(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (ref) v_u_12, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_24, (copy) v_u_9, (copy) v_u_35, (copy) v_u_5, (ref) v_u_10, (ref) v_u_11
	Random.new()
	local function v_u_42(p36, p37)
		-- upvalues: (ref) v_u_6, (ref) v_u_2
		local v38 = p36:FindFirstChild("HumanoidRootPart")
		if v38 then
			local v39 = v_u_6.Mechamaru.Offload.Burst:Clone()
			v39.Parent = p36
			v39.RigidConstraint.Attachment0 = v38.RootAttachment
			if p37 then
				for _, v40 in pairs(v39:GetDescendants()) do
					if v40:IsA("ParticleEmitter") then
						v40.Color = ColorSequence.new(Color3.fromRGB(250, 75, 75))
					end
				end
			end
			v_u_2:AddItem(v39, 0.35)
			for _, v41 in v39:GetDescendants() do
				if v41:IsA("ParticleEmitter") then
					v41:Emit(v41:GetAttribute("EmitCount"))
				end
			end
		end
	end
	local v_u_209 = {
		["Hit"] = function(p43, p44)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v45 = p43:FindFirstChild("HumanoidRootPart")
			if v45 then
				v_u_12:Flash(p43, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit" .. p44), v45, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p46, p47)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v48 = p46:FindFirstChild("HumanoidRootPart")
			if v48 then
				local v49 = p47:FindFirstChild("HumanoidRootPart")
				if v49 then
					v_u_12:Flash(p47, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit3"), v49, game.SoundService.Effect)
					local v50 = v_u_6.ChaseHit:Clone()
					local v51 = CFrame.new
					local v52 = v49.Position
					local v53 = v48.Position.X
					local v54 = v49.Position.Y
					local v55 = v48.Position.Z
					v50.CFrame = v51(v52, (Vector3.new(v53, v54, v55))) * CFrame.Angles(0, 3.141592653589793, 0)
					v50.Parent = workspace.Effects
					v50.Ring:Emit(7)
					v50.Sparks:Emit(12)
					v_u_2:AddItem(v50, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p56)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7
			local v57 = p56.HumanoidRootPart
			if v57 then
				local v58 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v58.CFrame = v57.CFrame * CFrame.new(0, 1, -4)
				v58.Size = Vector3.new(0, 0, 2)
				v58.Parent = workspace.Effects
				v_u_3:Create(v58, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v58, 0.3)
				v_u_12:PlaySound(v_u_7.Misc.Chase, v57, game.SoundService.Effect)
				v_u_12:DustTrail(p56, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p59)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v60 = p59:FindFirstChild("HumanoidRootPart")
			if v60 then
				v_u_12:PlaySound(v_u_7.Misc.Swing.Fist, v60, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p61, p62, p63)
			-- upvalues: (ref) v_u_12
			if p63 == "Down" then
				v_u_12:ArmFlash(p61["Right Leg"], Color3.fromRGB(225, 10, 75), 0.4)
				return
			elseif p62 == 1 or (p62 == 2 or p62 == 4) then
				v_u_12:ArmFlash(p61["Right Arm"], Color3.fromRGB(225, 10, 75), 0.3)
			else
				v_u_12:ArmFlash(p61["Left Arm"], Color3.fromRGB(225, 10, 75), 0.3)
			end
		end,
		["Swing3"] = function(p64, p65, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v66 = p64:FindFirstChild("HumanoidRootPart")
			if v66 then
				v_u_12:PlaySound(v_u_7.Mechamaru.Absolute.M1Swing["Swing" .. p65], v66, game.SoundService.Effect)
			end
		end,
		["Hit2"] = function(p67, p68)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v69 = p67:FindFirstChild("HumanoidRootPart")
			if v69 then
				v_u_12:Flash(p67, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Mechamaru.Absolute.M1:FindFirstChild("Hit" .. p68), v69, game.SoundService.Effect)
			end
		end,
		["Launch"] = function(p70, p71)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v72 = p70:FindFirstChild("HumanoidRootPart")
			if v72 then
				local v73 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v73.CFrame = CFrame.new(v72.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v73.Size = Vector3.new(0, 0, 5)
				v73.Parent = workspace.Effects
				v_u_3:Create(v73, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v73.Position + Vector3.new(0, p71, 0)
				}):Play()
				v_u_2:AddItem(v73, 0.3)
				if p71 < 0 then
					v_u_12:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v72, game.SoundService.Effect)
					v_u_12:DustBreak(v72.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_4:DistanceFromCharacter(v72.Position) < 20 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					end
				end
			end
		end,
		["OffloadCharge"] = function(p_u_74, p75, p_u_76)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (copy) v_u_42
			local v77 = p_u_74:FindFirstChild("HumanoidRootPart")
			if v77 then
				if p75.Parent then
					v_u_12:PlaySound(v_u_7.Mechamaru.Offload.Charge, v77, game.SoundService.Effect)
					local v_u_78 = v_u_6.Mechamaru.Offload.ChargeEffect:Clone()
					v_u_78.Parent = p_u_74
					v_u_78.RigidConstraint.Attachment0 = v77.RootAttachment
					if p_u_76 then
						for _, v79 in pairs(v_u_78:GetDescendants()) do
							if v79:IsA("ParticleEmitter") then
								v79.Color = ColorSequence.new(Color3.fromRGB(250, 75, 75))
							end
						end
					end
					p75.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_78, (ref) v_u_2, (ref) v_u_42, (copy) p_u_74, (copy) p_u_76
						for _, v80 in pairs(v_u_78:GetDescendants()) do
							if v80:IsA("ParticleEmitter") then
								v80.Enabled = false
							end
						end
						v_u_2:AddItem(v_u_78, 1.5)
						v_u_42(p_u_74, p_u_76)
					end)
				end
			else
				return
			end
		end,
		["OffloadAura"] = function(p81, p82, p83)
			-- upvalues: (ref) v_u_6, (ref) v_u_12, (ref) v_u_7, (ref) v_u_2
			local v_u_84 = p81:FindFirstChild("HumanoidRootPart")
			if v_u_84 then
				if p82.Parent then
					local v_u_85 = v_u_6.Mechamaru.Offload.Aura:Clone()
					v_u_85.Parent = p81
					v_u_85.RigidConstraint.Attachment0 = v_u_84.RootAttachment
					if p83 then
						for _, v86 in pairs(v_u_85:GetDescendants()) do
							if v86:IsA("ParticleEmitter") then
								v86.Color = ColorSequence.new(Color3.fromRGB(250, 75, 75))
							end
						end
					end
					v_u_12:PlaySound(v_u_7.Mechamaru.Offload.Burst, v_u_84, game.SoundService.Effect)
					p82.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_85, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (copy) v_u_84
						for _, v87 in pairs(v_u_85:GetDescendants()) do
							if v87:IsA("ParticleEmitter") then
								v87.Enabled = false
							end
						end
						v_u_2:AddItem(v_u_85, 1.5)
						v_u_12:PlaySound(v_u_7.Mechamaru.Offload.StopSound, v_u_84, game.SoundService.Effect)
					end)
				end
			else
				return
			end
		end,
		["SupermanLanding"] = function(p88)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_24, (ref) v_u_6, (ref) v_u_9, (ref) v_u_2
			local v89 = p88:FindFirstChild("HumanoidRootPart")
			if v89 then
				v_u_12:PlaySound(v_u_7.Mechamaru.Offload.SupermanLand, v89, game.SoundService.Effect)
				task.wait(0.11857142857142859)
				v_u_24(v_u_6.Mechamaru.Offload.SupermanLanding.Emit.Strike, v89, true, 1)
				local v90 = v_u_6.Mechamaru.Offload.SupermanLanding.Meshes.Mesh:Clone()
				local v91 = v_u_9.HandleMesh(v90, v89.CFrame * v90.Offset.Value)
				v90.Parent = workspace.Effects
				v_u_2:AddItem(v90, v91)
			end
		end,
		["BackSlide"] = function(p92)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_24, (ref) v_u_6, (ref) v_u_9, (ref) v_u_35, (ref) v_u_2
			local v93 = p92:FindFirstChild("HumanoidRootPart")
			if v93 then
				v_u_12:PlaySound(v_u_7.Mechamaru.Offload.BackSlide, v93, game.SoundService.Effect)
				v_u_24(v_u_6.Mechamaru.Offload.Backslide.ArriveDashBurst.Emit.Strike, v93, true, 1)
				local v94 = v_u_6.Mechamaru.Offload.Backslide.ArriveDashBurst.Meshes.Mesh:Clone()
				v_u_9.HandleMesh(v94, v93.CFrame * v94.Offset.Value)
				v94.Parent = workspace.Effects
				local v95 = v_u_6.Mechamaru.Offload.Backslide.ArriveDash.Strike:Clone()
				v_u_35(v95, true, p92.Torso, true)
				v95.Parent = workspace.Effects
				task.wait(0.37)
				local v96 = next
				local v97, v98 = v95:GetDescendants()
				for _, v99 in v96, v97, v98 do
					if v99:IsA("ParticleEmitter") then
						v99.Enabled = false
					end
				end
				v_u_2:AddItem(v95, 1)
			end
		end,
		["ArmsFlyIn"] = function(p100)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_24, (ref) v_u_6, (ref) v_u_9, (ref) v_u_2
			local v101 = p100:FindFirstChild("HumanoidRootPart")
			if v101 then
				v_u_12:PlaySound(v_u_7.Mechamaru.Offload.ArmsFlyIn, v101, game.SoundService.Effect)
				v_u_24(v_u_6.Mechamaru.Offload.ArmsFlyIn.ArriveBoost.Emit.Strike, v101, true, 3)
				local v102 = v_u_6.Mechamaru.Offload.ArmsFlyIn.ArriveBoost.Meshes.Mesh:Clone()
				local v103 = v_u_9.HandleMesh(v102, v101.CFrame * v102.Offset.Value)
				v102.Parent = workspace.Effects
				v_u_2:AddItem(v102, v103)
				task.wait(0.119)
				v_u_24(v_u_6.Mechamaru.Offload.ArmsFlyIn.ArriveLand.Emit.Strike, v101, true, 3)
				local v104 = v_u_6.Mechamaru.Offload.ArmsFlyIn.ArriveLand.Meshes.Mesh:Clone()
				local v105 = v_u_9.HandleMesh(v104, v101.CFrame * v104.Offset.Value)
				v104.Parent = workspace.Effects
				v_u_2:AddItem(v104, v105)
				task.wait(0.285)
				v_u_24(v_u_6.Mechamaru.Offload.ArmsFlyIn.ArriveArmRightLand.Emit.Strike, v101, true, 3)
				task.wait(0.38)
				v_u_24(v_u_6.Mechamaru.Offload.ArmsFlyIn.ArriveArmLeftLand.Emit.Strike, v101, true, 3)
			end
		end,
		["FunnyFall"] = function(p106)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_9, (ref) v_u_2, (ref) v_u_24
			local v107 = p106:FindFirstChild("HumanoidRootPart")
			if v107 then
				v_u_12:PlaySound(v_u_7.Mechamaru.Offload.FunnyFall, v107, game.SoundService.Effect)
				task.wait(0.0952)
				local v108 = v_u_6.Mechamaru.Offload.FunnyFall.ArriveLand.Meshes.Mesh:Clone()
				local v109 = v_u_9.HandleMesh(v108, v107.CFrame * v108.Offset.Value)
				v108.Parent = workspace.Effects
				v_u_2:AddItem(v108, v109)
				v_u_24(v_u_6.Mechamaru.Offload.FunnyFall.ArriveLand.Emit.Strike, v107, true, 3)
				task.wait(0.523)
				local v110 = v_u_6.Mechamaru.Offload.FunnyFall.Twirl1.Meshes.Mesh:Clone()
				local v111 = v_u_9.HandleMesh(v110, v107.CFrame * v110.Offset.Value)
				v110.Parent = workspace.Effects
				v_u_2:AddItem(v110, v111)
				task.wait(0.214)
				local v112 = v_u_6.Mechamaru.Offload.FunnyFall.Twirl2.Meshes.Mesh:Clone()
				local v113 = v_u_9.HandleMesh(v112, v107.CFrame * v112.Offset.Value)
				v112.Parent = workspace.Effects
				v_u_2:AddItem(v112, v113)
			end
		end,
		["SmoothLanding1"] = function(p114)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_24, (ref) v_u_6, (ref) v_u_9, (ref) v_u_2, (ref) v_u_5, (ref) v_u_35
			local v115 = p114:FindFirstChild("HumanoidRootPart")
			if v115 then
				v_u_12:PlaySound(v_u_7.Mechamaru.Offload.SmoothLanding, v115, game.SoundService.Effect)
				v_u_24(v_u_6.Mechamaru.Offload.SmoothLanding1.ArriveBoost.Emit.Strike, v115, true, 1)
				local v116 = v_u_6.Mechamaru.Offload.SmoothLanding1.ArriveBoost.Meshes.Mesh:Clone()
				local v117 = v_u_9.HandleMesh(v116, v115.CFrame * v116.Offset.Value)
				v116.Parent = workspace.Effects
				v_u_2:AddItem(v116, v117)
				local v118 = v_u_5.Utils.Mechamaru.BoosterL:Clone()
				v118.Parent = p114
				local v119 = v_u_5.Utils.Mechamaru.BoosterR:Clone()
				v119.Parent = p114
				local function v123(p120, p121)
					local v_u_122 = Instance.new("Motor6D")
					v_u_122.C0 = CFrame.new(0, 0.75, 0.625) * CFrame.Angles(0.7853981633974483, 0, 0)
					v_u_122.Part0 = p121
					v_u_122.Part1 = p120
					v_u_122.Name = p120.Name
					v_u_122.Parent = p121
					p120.Parent.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_122
						v_u_122:Destroy()
					end)
				end
				v123(v119["Arm BoostterrrrR"], p114["Right Arm"])
				v123(v118["Arm BoostterrrrL"], p114["Left Arm"])
				local v124 = v119["Arm BoostterrrrR"].Stage2
				local v125 = next
				local v126, v127 = v124:GetDescendants()
				for _, v128 in v125, v126, v127 do
					if v128:IsA("ParticleEmitter") then
						v128.Enabled = true
					end
				end
				local v129 = v118["Arm BoostterrrrL"].Stage2
				local v130 = next
				local v131, v132 = v129:GetDescendants()
				for _, v133 in v130, v131, v132 do
					if v133:IsA("ParticleEmitter") then
						v133.Enabled = true
					end
				end
				task.wait(0.07)
				local v134 = v_u_6.Mechamaru.Offload.SmoothLanding1.ArriveLand.Meshes.Mesh:Clone()
				local v135 = v_u_9.HandleMesh(v134, v115.CFrame * v134.Offset.Value)
				v134.Parent = workspace.Effects
				v_u_2:AddItem(v134, v135)
				local v136 = v_u_6.Mechamaru.Offload.SmoothLanding1.ArriveSmokeEnable.Strike:Clone()
				v_u_35(v136, true, v115, true)
				task.delay(0.7, v_u_35, v136, false)
				v136.Parent = workspace.Effects
				task.wait(0.07)
				local v137 = v_u_6.Mechamaru.Offload.SmoothLanding1.ArriveLandEnable.Meshes.Mesh:Clone()
				local v138 = v_u_9.HandleMesh(v116, v115.CFrame * v137.Offset.Value)
				v137.Parent = workspace.Effects
				v_u_2:AddItem(v137, v138)
				task.wait(0.34)
				local v139 = v119["Arm BoostterrrrR"].Stage2
				local v140 = next
				local v141, v142 = v139:GetDescendants()
				for _, v143 in v140, v141, v142 do
					if v143:IsA("ParticleEmitter") then
						v143.Enabled = false
					end
				end
				local v144 = v118["Arm BoostterrrrL"].Stage2
				local v145 = next
				local v146, v147 = v144:GetDescendants()
				for _, v148 in v145, v146, v147 do
					if v148:IsA("ParticleEmitter") then
						v148.Enabled = false
					end
				end
				task.wait(0.3)
				v118:Destroy()
				v119:Destroy()
			end
		end,
		["SmoothLanding2"] = function(p149)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_5, (ref) v_u_6, (ref) v_u_35, (ref) v_u_9, (ref) v_u_2
			local v150 = p149:FindFirstChild("HumanoidRootPart")
			if v150 then
				v_u_12:PlaySound(v_u_7.Mechamaru.Offload.SmoothLanding2, v150, game.SoundService.Effect)
				local v151 = v_u_5.Utils.Mechamaru.BoosterL:Clone()
				v151.Parent = p149
				local v152 = v_u_5.Utils.Mechamaru.BoosterR:Clone()
				v152.Parent = p149
				local function v156(p153, p154)
					local v_u_155 = Instance.new("Motor6D")
					v_u_155.C0 = CFrame.new(0, 0.75, 0.625) * CFrame.Angles(0.7853981633974483, 0, 0)
					v_u_155.Part0 = p154
					v_u_155.Part1 = p153
					v_u_155.Name = p153.Name
					v_u_155.Parent = p154
					p153.Parent.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_155
						v_u_155:Destroy()
					end)
				end
				v156(v152["Arm BoostterrrrR"], p149["Right Arm"])
				v156(v151["Arm BoostterrrrL"], p149["Left Arm"])
				local v157 = v152["Arm BoostterrrrR"].Stage2
				local v158 = next
				local v159, v160 = v157:GetDescendants()
				for _, v161 in v158, v159, v160 do
					if v161:IsA("ParticleEmitter") then
						v161.Enabled = true
					end
				end
				local v162 = v151["Arm BoostterrrrL"].Stage2
				local v163 = next
				local v164, v165 = v162:GetDescendants()
				for _, v166 in v163, v164, v165 do
					if v166:IsA("ParticleEmitter") then
						v166.Enabled = true
					end
				end
				task.wait(0.266)
				local v167 = v_u_6.Mechamaru.Offload.SmoothLanding1.ArriveSmokeEnable.Strike:Clone()
				v_u_35(v167, true, v150, true)
				v167.Parent = v150
				local v168 = v_u_6.Mechamaru.Offload.SmoothLanding2.ArriveLandEnable.Meshes.Mesh:Clone()
				local v169 = v_u_9.HandleMesh(v168, v150.CFrame * v168.Offset.Value)
				v168.Parent = workspace.Effects
				v_u_2:AddItem(v168, v169)
				task.wait(0.383)
				local v170 = v152["Arm BoostterrrrR"].Stage2
				local v171 = next
				local v172, v173 = v170:GetDescendants()
				for _, v174 in v171, v172, v173 do
					if v174:IsA("ParticleEmitter") then
						v174.Enabled = false
					end
				end
				local v175 = v151["Arm BoostterrrrL"].Stage2
				local v176 = next
				local v177, v178 = v175:GetDescendants()
				for _, v179 in v176, v177, v178 do
					if v179:IsA("ParticleEmitter") then
						v179.Enabled = false
					end
				end
				task.wait(0.15)
				local v180 = next
				local v181, v182 = v167:GetDescendants()
				for _, v183 in v180, v181, v182 do
					if v183:IsA("ParticleEmitter") then
						v183.Enabled = false
					end
				end
				v_u_2:AddItem(v167, 2)
				local v184 = v152["Arm BoostterrrrR"].Stage1
				local v185 = next
				local v186, v187 = v184:GetDescendants()
				for _, v188 in v185, v186, v187 do
					if v188:IsA("ParticleEmitter") then
						v188.Enabled = false
					end
				end
				local v189 = v151["Arm BoostterrrrL"].Stage1
				local v190 = next
				local v191, v192 = v189:GetDescendants()
				for _, v193 in v190, v191, v192 do
					if v193:IsA("ParticleEmitter") then
						v193.Enabled = false
					end
				end
				task.wait(0.3)
				v151:Destroy()
				v152:Destroy()
			end
		end,
		["Sparks"] = function(p194)
			-- upvalues: (ref) v_u_6, (ref) v_u_12, (ref) v_u_7, (ref) v_u_3
			local v195 = v_u_6.Mechamaru.Detonate:Clone()
			v195.PointLight.Brightness = 0
			v195.PointLight.Range = 0
			v195.Parent = p194
			v_u_12:PlaySound(v_u_7.Mechamaru.Offload.Sparks, v195, game.SoundService.Effect)
			task.wait(0.2)
			v_u_3:Create(v195.PointLight, TweenInfo.new(0.8), {
				["Brightness"] = 5,
				["Range"] = 20
			}):Play()
			task.wait(0.8)
			v195:Destroy()
		end,
		["Explosion"] = function(p196, p197)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_3
			local v198
			if p197 then
				local v199 = v_u_6.Mechamaru.DetonateUltScaled:Clone()
				v199.Detonate.WorldPosition = p196
				v199.Parent = workspace.Effects
				v198 = v199.Detonate
			else
				v198 = v_u_6.Mechamaru.Detonate:Clone()
				v198.Lightning:Destroy()
				v198.PointLight:Destroy()
				v198.WorldPosition = p196
				v198.Parent = workspace.Effects
			end
			for _, v200 in v198:GetDescendants() do
				if v200:IsA("ParticleEmitter") then
					v200:Emit(v200:GetAttribute("EmitCount"))
				end
			end
			v_u_2:AddItem(v198, 3)
			v_u_12:PlaySound(v_u_7.Mechamaru.Offload.Explode, v198, game.SoundService.Effect)
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - p196).Magnitude > 150 then
					return
				end
				Random.new()
				TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				local v201 = p197 and 2 or 1
				for _ = 1, p197 and 35 or 10 do
					local v_u_202 = v_u_6.Hiromi.GavelShard:Clone()
					v_u_202.Position = p196
					v_u_202.Size = v_u_202.Size * (math.random(150, 220) / 100 * v201)
					local v203 = math.random(-80, 80)
					local v204 = math.random(30, 60)
					local v205 = math.random
					v_u_202.Velocity = Vector3.new(v203, v204, v205(-80, 80)) * v201
					local v206 = math.random(-50, 50)
					local v207 = math.random(-50, 50)
					local v208 = math.random
					v_u_202.RotVelocity = Vector3.new(v206, v207, v208(-50, 50))
					v_u_202.Color = p197 and Color3.fromRGB(138, 153, 179) or v_u_202.Color
					v_u_202.Parent = workspace.Effects
					v_u_2:AddItem(v_u_202, 2)
					task.delay(1, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_202
						v_u_3:Create(v_u_202, TweenInfo.new(1), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
					end)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p210, ...)
		-- upvalues: (copy) v_u_209
		local v211 = v_u_209[p210]
		if v211 then
			v211(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p212, p213, p214)
		-- upvalues: (ref) v_u_11, (ref) v_u_3
		local v215 = p213.HumanoidRootPart
		if not v215 then
			return
		end
		local v216 = nil
		while true do
			local v217 = v_u_11:SphereHitbox(p213, CFrame.new(0, 0, -4), 8)
			for _, v218 in v217 do
				local v219 = v218:FindFirstChild("Info")
				if v219 then
					local v220 = v219:FindFirstChild("Knockback")
					if not v220 or v220.Value ~= false then
						v216 = v217
						break
					end
				end
			end
			if v216 then
				local v221 = p212:FindFirstChildWhichIsA("NumberValue")
				if v221 then
					v_u_3:Create(v221, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p212.Parent then
				break
			end
		end
		p214:FireServer(v216, v215.CFrame)
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("MechamaruService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13