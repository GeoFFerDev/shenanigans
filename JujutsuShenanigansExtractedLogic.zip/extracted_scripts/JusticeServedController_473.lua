-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "JusticeServedController"
})
function v12.KnitStart(_)
	-- upvalues: (copy) v_u_6, (ref) v_u_11, (copy) v_u_7, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10
	local v_u_78 = {
		["Expand"] = function(p13, p14, p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_11, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2
			local v16 = p13:FindFirstChild("HumanoidRootPart")
			if not v16 then
				return
			end
			local v_u_17 = v_u_6.Hiromi.GavelExpand:Clone()
			v_u_17.Weld.Part0 = p14
			v_u_17.Parent = p14.Extensions
			for v18 = 1, 20 do
				task.delay(0.0375 * v18, function()
					-- upvalues: (copy) v_u_17
					local v19 = v_u_17
					local v20 = v_u_17:GetScale()
					v19:ScaleTo((math.lerp(v20, 4.75, 0.2)))
				end)
			end
			task.wait(0.3)
			v_u_11:PlaySound(v_u_7.Hiromi.HeavySwing, v16, game.SoundService.Effect)
			local v21 = tick()
			while true do
				if tick() > v21 + 0.05 then
					local v22 = v_u_6.Itadori.Shock:Clone()
					v22.CFrame = p14.CFrame
					v22.Transparency = 0.3
					v22.Parent = workspace.Effects
					v_u_3:Create(v22, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(20, 0, 20),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v22, 0.15)
					v21 = tick()
				end
				task.wait()
				if not (p15 and p15.Parent) then
					for v23 = 1, 20 do
						task.delay(0.015 * v23, function()
							-- upvalues: (copy) v_u_17
							local v24 = v_u_17
							local v25 = v_u_17:GetScale()
							v24:ScaleTo((math.lerp(v25, 0.5, 0.15)))
						end)
					end
					v_u_2:AddItem(v_u_17, 0.3)
					return
				end
			end
		end,
		["Crush"] = function(p26, p27, p28)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v29 = v_u_6.Hiromi.Shockwave:Clone()
			v29.Position = p27
			v29.Parent = workspace.Effects
			local v30 = v29.CFrame
			local v31 = CFrame.Angles
			local v32 = math.random(-179, 179)
			v29.CFrame = v30 * v31(0, math.rad(v32), 0)
			v_u_3:Create(v29.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(15, 0, 15)
			}):Play()
			v_u_3:Create(v29.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v29.Floor.Glow:Emit(1)
			v29.Floor.Ring:Emit(10)
			v_u_2:AddItem(v29, 1.5)
			local v33 = v_u_6.Choso.CounterSwing.Shock:Clone()
			v33.Size = Vector3.new(10, 30, 10)
			v33.CFrame = CFrame.new(p27)
			v33.Parent = workspace.Effects
			v_u_2:AddItem(v33, 0.3)
			v_u_3:Create(v33, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(36, 7, 36),
				["Transparency"] = 1,
				["Position"] = v33.Position - Vector3.new(0, 3, 0)
			}):Play()
			local v34 = v_u_6.Choso.CounterSwing.Shock:Clone()
			v34.Size = Vector3.new(20, 10, 20)
			v34.CFrame = CFrame.new(p27)
			v34.Parent = workspace.Effects
			v_u_2:AddItem(v34, 0.2)
			v_u_3:Create(v34, TweenInfo.new(0.2), {
				["Size"] = Vector3.new(0, 36, 0),
				["Transparency"] = 1,
				["Position"] = v34.Position + Vector3.new(0, 10, 0)
			}):Play()
			v_u_11:DustBreak(p27 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
			v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v29, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_7.Hakari.Impact, v29, game.SoundService.Effect)
			if p28 and v_u_4 == p26 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end,
		["Hit2"] = function(p35, p36)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v37 = p36:FindFirstChild("HumanoidRootPart")
			if v37 then
				v_u_11:Flash(p36, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Megumi.Elephant.Hit, v37, game.SoundService.Effect)
				if v_u_4 == p35 or v_u_4.Character == p36 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["FinalHit"] = function(p38, p39)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v40 = p39:FindFirstChild("HumanoidRootPart")
			if v40 then
				v_u_11:Flash(p39, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Megumi.Elephant.Hit, v40, game.SoundService.Effect)
				if v_u_4 == p38 or v_u_4.Character == p39 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Jump"] = function(p41, p42, p43)
			-- upvalues: (ref) v_u_4, (ref) v_u_3
			local v44 = p42.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if v44 then
				local v45 = p43 * 5
				if v_u_4.Character == v44.Parent then
					local v46 = v45 - Vector3.new(0, 1.5, 0)
					v_u_3:Create(p42, TweenInfo.new(0.5), {
						["P"] = 50000
					}):Play()
					repeat
						p42.Position = p41.Position - v46
						v44.CFrame = CFrame.lookAlong(v44.Position, v46)
						task.wait()
					until not (p42.Parent and p41)
				else
					repeat
						local v47 = CFrame.lookAlong(p41.Position, v45) - v45
						v44.CFrame = v44.CFrame:Lerp(v47, 0.075)
						task.wait()
					until not (p42.Parent and p41)
				end
			end
		end,
		["Finisher"] = function(p48, p49)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v50 = p49:FindFirstChild("HumanoidRootPart")
			if v50 then
				if p49.Parent then
					local v51
					if p49.Torso.Transparency == 0 and p49.Head.Transparency == 1 then
						v51 = not p49:GetAttribute("Woah")
					else
						v51 = false
					end
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, v50, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_7.Megumi.Elephant.Explode, v50, game.SoundService.Effect)
					for _, v52 in p49:GetDescendants() do
						if v52:IsA("BasePart") or v52:IsA("Decal") then
							v52.Transparency = 1
						end
					end
					for _ = 1, 50 do
						v_u_9:Blood(v50.CFrame, 200, 360, 360)
					end
					if _G.Settings.Gore then
						local v53 = v_u_6.Heian.BloodSpread:Clone()
						v53.Parent = p49.Head
						v53:Emit(20)
						v_u_2:AddItem(v53, 2)
					end
					for _ = 1, 20 do
						local v_u_54 = v_u_6.Damage.Chunk:Clone()
						v_u_54.CFrame = v50.CFrame
						v_u_54.CollisionGroup = "Effects"
						local v55 = math.random(-90, 90)
						local v56 = math.random(20, 50)
						local v57 = math.random
						v_u_54.Velocity = Vector3.new(v55, v56, v57(-90, 90))
						local v58 = math.random(-200, 200)
						local v59 = math.random(-200, 200)
						local v60 = math.random
						v_u_54.RotVelocity = Vector3.new(v58, v59, v60(-200, 200))
						v_u_54.Parent = workspace.Effects
						v_u_2:AddItem(v_u_54, 3)
						task.delay(0.1, function()
							-- upvalues: (copy) v_u_54, (ref) v_u_3
							v_u_54.CanCollide = true
							task.wait(1.9)
							v_u_3:Create(v_u_54, TweenInfo.new(1), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
							v_u_54.Blood.Enabled = false
							v_u_54.Trail.Enabled = false
						end)
						if _G.Settings.Gore == false then
							v_u_54.Color = Color3.fromRGB(255, 85, 255)
							v_u_54.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
							v_u_54.Blood.Color = v_u_54.Trail.Color
						end
					end
					if v_u_4:DistanceFromCharacter(v50.Position) < 40 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					end
					p49:SetAttribute("Woah", true)
					if v51 and (v_u_4.Character == p49 or v_u_4 == p48) then
						v_u_11:PlaySound(v_u_7.Todo.Boom, workspace, game.SoundService.Effect)
						local v61 = v_u_6.Todo.Woah:Clone()
						v61.ImageLabel.Image = "rbxassetid://16726446989"
						v61.Parent = v_u_4.PlayerGui
						v_u_2:AddItem(v61, 1)
						v_u_3:Create(v61.ImageLabel, TweenInfo.new(1), {
							["ImageTransparency"] = 1
						}):Play()
					end
				end
			else
				return
			end
		end,
		["BangEmoteFinisher"] = function(p62, p63)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v64 = p62:FindFirstChild("HumanoidRootPart")
			if not v64 then
				return
			end
			v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, v64, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_7.Megumi.Elephant.Explode, v64, game.SoundService.Effect)
			local v65 = { "Torso", "Left Arm", "Right Arm" }
			for _, v66 in pairs(p62:GetDescendants()) do
				if table.find(v65, v66.Name) then
					v66.Transparency = 1
				end
				if v66:IsA("Accessory") then
					local v67 = v66:FindFirstChild("Handle")
					if v67 then
						v67 = v67:FindFirstChildOfClass("Attachment")
					end
					if v67 then
						for _, v68 in pairs({
							"Neck",
							"Back",
							"Front",
							"Shoulder",
							"Waist"
						}) do
							if string.find(v67.Name, v68) then
								v68:Destroy()
								break
							end
						end
					end
				end
			end
			for _ = 1, 50 do
				v_u_9:Blood(CFrame.lookAt(v64.Position, v64.Position + p63), 200, 40, 40)
			end
			if _G.Settings.Gore then
				local v69 = v_u_6.Heian.BloodSpread:Clone()
				v69.Parent = p62.Head
				v69:Emit(20)
				v_u_2:AddItem(v69, 2)
			end
			for _ = 1, 20 do
				local v_u_70 = v_u_6.Damage.Chunk:Clone()
				v_u_70.CFrame = v64.CFrame
				v_u_70.CollisionGroup = "Effects"
				local v71 = p63 * 10
				local v72 = math.random(-5, 5)
				local v73 = math.random(5, 15)
				local v74 = math.random
				v_u_70.Velocity = v71 + Vector3.new(v72, v73, v74(-5, 5))
				local v75 = math.random(-200, 200)
				local v76 = math.random(-200, 200)
				local v77 = math.random
				v_u_70.RotVelocity = Vector3.new(v75, v76, v77(-200, 200))
				v_u_70.Parent = workspace.Effects
				v_u_2:AddItem(v_u_70, 3)
				task.delay(0.1, function()
					-- upvalues: (copy) v_u_70, (ref) v_u_3
					v_u_70.CanCollide = true
					task.wait(1.9)
					v_u_3:Create(v_u_70, TweenInfo.new(1), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_70.Blood.Enabled = false
					v_u_70.Trail.Enabled = false
				end)
				if _G.Settings.Gore == false then
					v_u_70.Color = Color3.fromRGB(255, 85, 255)
					v_u_70.Trail.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
					v_u_70.Blood.Color = v_u_70.Trail.Color
				end
			end
			if v_u_4:DistanceFromCharacter(v64.Position) < 40 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end
	}
	v_u_10.Effects:Connect(function(p79, ...)
		-- upvalues: (copy) v_u_78
		local v80 = v_u_78[p79]
		if v80 then
			v80(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("JusticeServedService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12