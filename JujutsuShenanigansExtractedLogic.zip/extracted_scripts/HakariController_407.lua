-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = v5.Animations
local v_u_7 = v5.Utils
local v_u_8 = v5.Sounds
local v_u_9 = require(v5.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "HakariController"
})
local v_u_14 = {
	"rbxassetid://17207807777",
	"rbxassetid://17207806991",
	"rbxassetid://17207806413",
	"rbxassetid://17207805758",
	"rbxassetid://17207805299",
	"rbxassetid://17207804676",
	"rbxassetid://17207804009"
}
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_9, (copy) v_u_6, (copy) v_u_14, (ref) v_u_10, (ref) v_u_11
	local v_u_139 = {
		["Hit"] = function(p15, p16)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_12:Flash(p15, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Hakari.M1:FindFirstChild("Hit" .. p16), v17, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p18, p19)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2
			local v20 = p18:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = p19:FindFirstChild("HumanoidRootPart")
				if v21 then
					v_u_12:Flash(p19, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Hakari.M1:FindFirstChild("Hit3"), v21, game.SoundService.Effect)
					local v22 = v_u_7.ChaseHit:Clone()
					local v23 = CFrame.new
					local v24 = v21.Position
					local v25 = v20.Position.X
					local v26 = v21.Position.Y
					local v27 = v20.Position.Z
					v22.CFrame = v23(v24, (Vector3.new(v25, v26, v27))) * CFrame.Angles(0, 3.141592653589793, 0)
					v22.Parent = workspace.Effects
					v22.Ring:Emit(7)
					v22.Sparks:Emit(12)
					v_u_2:AddItem(v22, 0.5)
				end
			else
				return
			end
		end,
		["Counter"] = function(p28, p29, p30)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_3, (ref) v_u_2
			local v31 = p28.HumanoidRootPart
			if v31 then
				v_u_12:PlaySound(v_u_8.Hakari.Counter.Startup, v31, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Hakari.ShutterDoors.Spawn, v31, game.SoundService.Effect)
				local v32 = Instance.new("Highlight")
				v32.FillTransparency = 0
				v32.FillColor = Color3.new(2, 2, 2)
				v32.OutlineColor = Color3.new(2, 2, 2)
				v32.DepthMode = Enum.HighlightDepthMode.Occluded
				v32.Parent = p29.Doors
				if p30 then
					p29.Doors.Door1.Color = p30
					p29.Doors.Door2.Color = p30
					p29.Doors.Door1.Stars.Color = ColorSequence.new(p30)
					p29.Doors.Door2.Stars.Color = ColorSequence.new(p30)
				end
				v_u_3:Create(v32, TweenInfo.new(0.4), {
					["FillTransparency"] = 1,
					["OutlineTransparency"] = 1
				}):Play()
				v_u_2:AddItem(v32, 0.4)
				task.wait(0.2)
				p29.Doors.Door1.Stars.Enabled = false
				p29.Doors.Door2.Stars.Enabled = false
			end
		end,
		["Fade"] = function(p33)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v34 = p33:FindFirstChild("HumanoidRootPart")
			v_u_12:Flash(p33, Color3.new(0, 0, 0), 0.3)
			v_u_12:PlaySound(v_u_8.Hakari.ShutterDoors.Slam, v34, game.SoundService.Effect)
		end,
		["CounterHit"] = function(p35, p36)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9
			local v37 = p36:FindFirstChild("HumanoidRootPart")
			v_u_12:Flash(p36, Color3.new(1, 1, 1))
			v_u_12:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v37, game.SoundService.Effect)
			if v_u_4 == p35 or v_u_4.Character == p36 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
			end
		end,
		["CounterEnd"] = function(_, p38)
			-- upvalues: (ref) v_u_3
			v_u_3:Create(p38.Weld1, TweenInfo.new(0.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
				["C1"] = CFrame.new(0, 0, 8) * CFrame.Angles(0, -1.5707963267948966, 0)
			}):Play()
			v_u_3:Create(p38.Weld2, TweenInfo.new(0.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
				["C1"] = CFrame.new(0, 0, 8) * CFrame.Angles(0, -1.5707963267948966, 3.141592653589793)
			}):Play()
			for _, v39 in p38.Doors:GetDescendants() do
				if v39:IsA("BasePart") or v39:IsA("Texture") then
					v_u_3:Create(v39, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
			end
		end,
		["CounterSwing"] = function(p40, p41, p42)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_3
			local v43 = p40.HumanoidRootPart
			if v43 then
				v_u_12:PlaySound(v_u_8.Hakari.Counter.Swing, v43, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_8.Hakari.Counter.Slam, v43, game.SoundService.Effect)
				local v44 = p41.Doors:Clone()
				v44.Parent = p41
				p41.Doors:Destroy()
				v44.Door1.Stars:Emit(20)
				v44.Door2.Stars:Emit(20)
				v44.Door1.CanCollide = true
				v44.Door2.CanCollide = true
				v44.Door1.Velocity = v43.CFrame.LookVector * (p42 and -60 or 60) + v43.CFrame.RightVector * 20
				v44.Door2.Velocity = v43.CFrame.LookVector * (p42 and -60 or 60) + v43.CFrame.RightVector * 20
				for _, v45 in v44:GetDescendants() do
					if v45:IsA("BasePart") or v45:IsA("Texture") then
						v_u_3:Create(v45, TweenInfo.new(0.6, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["Transparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["Chase"] = function(p46)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8
			local v47 = p46.HumanoidRootPart
			if v47 then
				local v48 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v48.CFrame = v47.CFrame * CFrame.new(0, 1, -4)
				v48.Size = Vector3.new(0, 0, 2)
				v48.Parent = workspace.Effects
				v_u_3:Create(v48, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v48, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v47, game.SoundService.Effect)
				v_u_12:DustTrail(p46, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p49)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v50 = p49:FindFirstChild("HumanoidRootPart")
			if v50 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v50, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p51, p52, p53)
			-- upvalues: (ref) v_u_12
			if p51:GetAttribute("InUlt") then
				if p53 == "Down" then
					v_u_12:ArmFlash(p51["Right Leg"], Color3.fromRGB(85, 255, 127), 0.4)
					return
				elseif p52 == 1 or p52 == 4 then
					v_u_12:ArmFlash(p51["Right Arm"], Color3.fromRGB(85, 255, 127), 0.3)
				else
					v_u_12:ArmFlash(p51["Left Arm"], Color3.fromRGB(85, 255, 127), 0.3)
				end
			elseif p53 == "Up" then
				v_u_12:ArmFlash(p51["Left Leg"], Color3.fromRGB(85, 255, 127), 0.4)
				return
			elseif p53 == "Down" then
				v_u_12:ArmFlash(p51["Right Leg"], Color3.fromRGB(85, 255, 127), 0.4)
				return
			elseif p52 == 4 then
				v_u_12:ArmFlash(p51["Left Leg"], Color3.fromRGB(85, 255, 127))
			else
				v_u_12:ArmFlash(p51["Right Leg"], Color3.fromRGB(85, 255, 127), 0.3)
			end
		end,
		["Launch"] = function(p54, p55)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9
			local v56 = p54:FindFirstChild("HumanoidRootPart")
			if v56 then
				local v57 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v57.CFrame = CFrame.new(v56.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v57.Size = Vector3.new(0, 0, 5)
				v57.Parent = workspace.Effects
				v_u_3:Create(v57, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v57.Position + Vector3.new(0, p55, 0)
				}):Play()
				v_u_2:AddItem(v57, 0.3)
				if p55 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v56, game.SoundService.Effect)
					v_u_12:DustBreak(v56.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_4:DistanceFromCharacter(v56.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Surge"] = function(p58, p59)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9
			local v60 = p58:FindFirstChild("HumanoidRootPart")
			if v60 then
				p59.EnergyBurst:Emit(20)
				v_u_12:Flash(p58, Color3.fromRGB(85, 255, 127), 1)
				v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Charge, v60, game.SoundService.Effect)
				if v_u_4.Character == p58 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v61 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.LightHit)
					repeat
						task.wait()
					until not p59.Parent or p59.Surge.Enabled == false
					v61:StartFadeOut(1)
				end
			end
		end,
		["Startup"] = function(p62)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6
			local v63 = p62:FindFirstChild("HumanoidRootPart")
			if v63 then
				v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Voice, v63, game.SoundService.Voice)
				v_u_12:DomainBurst(v63)
				local v64 = v_u_4.Character
				if v64 and v64:FindFirstChild("HumanoidRootPart") then
					local v65 = v64:FindFirstChild("HumanoidRootPart")
					if (v63.Position - v65.Position).Magnitude <= 37.5 then
						v_u_12:Domain(p62, function(p66, p67)
							-- upvalues: (ref) v_u_6
							p67.Humanoid:LoadAnimation(v_u_6.Hakari.DomainWarn):Play(0)
							p66.Panel.ImageLabel.Image = "rbxassetid://16069822951"
						end)
					end
				end
			end
		end,
		["Opening"] = function(p68, p69, p_u_70, p71)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9
			local v_u_72 = v_u_7.Hakari.IdleDeath.DomainBG:Clone()
			v_u_72.Parent = p68
			v_u_72.CFrame = p68.CFrame
			task.spawn(function()
				-- upvalues: (copy) p_u_70, (copy) v_u_72
				repeat
					task.wait()
				until not (p_u_70.Parent and (p_u_70.Parent.Parent and p_u_70.Parent.Parent.Parent))
				v_u_72:Destroy()
			end)
			local v_u_73
			if p71 then
				v_u_73 = nil
			else
				local v_u_74 = p69.DomainGround
				v_u_74.Surround.ShapePartial = 1
				v_u_74.Surround.Enabled = true
				v_u_2:AddItem(v_u_74, 2)
				v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.IdleDeath, workspace, game.SoundService.Effect)
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_74, (ref) v_u_12
					v_u_3:Create(v_u_74, TweenInfo.new(0.25), {
						["Transparency"] = 0
					}):Play()
					v_u_12:DomainMapFade(Color3.new(1, 1, 1), 0.25, 1)
				end)
				task.wait(1)
				if not (p_u_70 and p_u_70.Parent) then
					return
				end
				local v_u_75 = v_u_7.Hakari.IdleDeath.DomainInfo:Clone()
				v_u_75.Scenario1.Text = "Transit Card Richii (\226\152\134 \226\152\134 \226\152\133)"
				v_u_75.Scenario2.Text = "Travel Emergency Richii (\226\152\134 \226\152\133 \226\152\133)"
				v_u_75.Parent = v_u_4.PlayerGui
				v_u_2:AddItem(v_u_75, 15)
				task.spawn(function()
					-- upvalues: (ref) v_u_75, (ref) v_u_3
					local v76 = 0
					for _, v77 in v_u_75:GetChildren() do
						if v77:IsA("TextLabel") then
							v_u_3:Create(v77, TweenInfo.new(15, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
								["TextTransparency"] = 1,
								["TextStrokeTransparency"] = 1
							}):Play()
							local v78 = v77.Position
							v77.Position = v78 + UDim2.new(v77.AnchorPoint.X == 1 and 0.5 or -0.5, 0, 0, 0)
							v_u_3:Create(v77, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["Position"] = v78
							}):Play()
						end
					end
					while true do
						for _, v79 in v_u_75:GetChildren() do
							if v79:IsA("TextLabel") then
								v79.TextColor3 = Color3.fromHSV(v76, 1, 1)
							end
						end
						task.wait()
						v76 = (v76 + 0.01) % 1
						if not v_u_75.Parent then
							return
						end
					end
				end)
				v_u_73 = v_u_75
				for _, v80 in v_u_14 do
					local v81 = Instance.new("ImageLabel")
					v81.Size = UDim2.new(0, 0, 0, 0)
					v81.Image = v80
					v81.Parent = v_u_73
				end
			end
			local v_u_82 = v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Music, workspace, game.SoundService.Music, true)
			local v_u_83 = v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Travel, workspace, game.SoundService.Effect, true)
			game.SoundService.AmbientReverb = Enum.ReverbType.Alley
			task.spawn(function()
				-- upvalues: (copy) p_u_70, (ref) v_u_3, (copy) v_u_82, (ref) v_u_2, (copy) v_u_83, (ref) v_u_73
				repeat
					task.wait()
				until not (p_u_70.Parent and (p_u_70.Parent.Parent and p_u_70.Parent.Parent.Parent))
				game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
				v_u_3:Create(v_u_82, TweenInfo.new(2), {
					["PlaybackSpeed"] = 0
				}):Play()
				v_u_2:AddItem(v_u_82, 2)
				if v_u_83 then
					v_u_83:Destroy()
				end
				if v_u_73 and v_u_73.Parent then
					v_u_73:Destroy()
				end
			end)
			v_u_72.Speedlines.Enabled = true
			local v84 = v_u_7.Hakari.IdleDeath.Segment:Clone()
			local v85 = v_u_7.Hakari.IdleDeath.Segment:Clone()
			v84.CFrame = p68.CFrame * CFrame.new(40, 0, 400) * CFrame.Angles(0, 3.141592653589793, 0)
			v85.CFrame = p68.CFrame * CFrame.new(-40, 0, 400)
			for v86 = 1, 50 do
				local v87 = v_u_7.Hakari.IdleDeath.Segment:Clone()
				v87.CFrame = v84.CFrame * CFrame.new(0, 0, -8 * v86)
				v87.Anchored = false
				v87.WeldConstraint.Part1 = v84
				v87.Parent = v84
				local v88 = v87:Clone()
				v88.CFrame = v85.CFrame * CFrame.new(0, 0, 8 * v86)
				v88.WeldConstraint.Part1 = v85
				v88.Parent = v85
			end
			v84.Parent = p68
			v85.Parent = p68
			v_u_3:Create(v84, TweenInfo.new(0.5), {
				["CFrame"] = p68.CFrame * CFrame.new(40, 0, -200) * CFrame.Angles(0, 3.141592653589793, 0)
			}):Play()
			v_u_3:Create(v85, TweenInfo.new(0.5), {
				["CFrame"] = p68.CFrame * CFrame.new(-40, 0, -200)
			}):Play()
			local v89 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
			task.wait(0.5)
			local v90 = Instance.new("NumberValue", v_u_72)
			v90.Value = 0
			v_u_3:Create(v90, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
				["Value"] = 90
			}):Play()
			v_u_2:AddItem(v90, 1.5)
			repeat
				local v91 = p68.CFrame
				local v92 = CFrame.Angles
				local v93 = v90.Value
				local v94 = math.rad(v93)
				local v95 = v90.Value * 2
				v_u_72.CFrame = v91 * v92(v94, 0, (math.rad(v95)))
				v84.CFrame = v_u_72.CFrame * CFrame.new(40, 0, -200 + math.random(-200, 200) / 100) * CFrame.Angles(0, 3.141592653589793, 0)
				v85.CFrame = v_u_72.CFrame * CFrame.new(-40, 0, -200 + math.random(-200, 200) / 100)
				task.wait()
			until not (v90.Parent and v84.Parent)
			v89:StartFadeOut(1)
			if v_u_72.Parent then
				v_u_72.Speedlines:Destroy()
				v_u_3:Create(v_u_72, TweenInfo.new(0.5), {
					["Color"] = Color3.fromRGB(160, 160, 160)
				}):Play()
				v_u_3:Create(v84, TweenInfo.new(0.5), {
					["CFrame"] = v_u_72.CFrame * CFrame.new(40, 0, -800) * CFrame.Angles(0, 3.141592653589793, 0)
				}):Play()
				v_u_3:Create(v85, TweenInfo.new(0.5), {
					["CFrame"] = v_u_72.CFrame * CFrame.new(-40, 0, -800)
				}):Play()
				v_u_2:AddItem(v84, 0.5)
				v_u_2:AddItem(v85, 0.5)
				v_u_72.CFrame = p68.CFrame
				local v96 = v_u_7.Hakari.IdleDeath.Normal:Clone()
				v96.CFrame = p68.CFrame * CFrame.new(0, -150, 0)
				v96.Parent = v_u_72
				v_u_3:Create(v96, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["CFrame"] = p68.CFrame
				}):Play()
				local v97 = v96:GetChildren()
				for v98 = 1, 16 do
					local v99 = CFrame.new()
					local v100 = CFrame.Angles
					local v101 = 22.5 * (v98 - 1)
					local v102 = v99 * v100(0, math.rad(v101), 0)
					v97[v98].Weld.C1 = v102 * CFrame.new(0, 0, 50) * CFrame.Angles(0, 1.5707963267948966, 0)
				end
			end
		end,
		["Richii"] = function(_, p103, p104, p105, p106)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v107 = p103:FindFirstChild("DomainBG")
			if v107 then
				local v108 = v107:FindFirstChild("Normal")
				if v108 then
					local v109 = p106 and p106 == 2 and 1.667 or 1
					local v110 = { v_u_7.Hakari.IdleDeath.Scenarios.IC, v_u_7.Hakari.IdleDeath.Scenarios.P }
					v_u_3:Create(v108, TweenInfo.new(0), {
						["CFrame"] = p103.CFrame * CFrame.new(0, -250, 0)
					}):Play()
					local v111 = v110[p105]:Clone()
					v111:SetAttribute("Jackpot", p104)
					v111:SetAttribute("Speed", v109)
					v111:PivotTo(p103.CFrame)
					v111.Parent = v107.Scenario
					v111.ScenarioPlay.Enabled = true
					game.Lighting.ExposureCompensation = 15
					v_u_3:Create(game.Lighting, TweenInfo.new(1), {
						["ExposureCompensation"] = 0
					}):Play()
					task.wait(6 / v109)
					if p103.Parent then
						if not p104 then
							v107.Scenario:ClearAllChildren()
							v_u_3:Create(v108, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["CFrame"] = p103.CFrame
							}):Play()
							game.Lighting.ExposureCompensation = -15
							v_u_3:Create(game.Lighting, TweenInfo.new(1), {
								["ExposureCompensation"] = 0
							}):Play()
						end
					else
						return
					end
				else
					return
				end
			else
				return
			end
		end,
		["Roll"] = function(p112, p113)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_2, (ref) v_u_14, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3, (ref) v_u_9
			local v114 = v_u_7.Hakari.IdleDeath.Roll:Clone()
			v114.Parent = v_u_4.PlayerGui
			v_u_2:AddItem(v114, 3)
			if p112 then
				v114.Number1.Image = v_u_14[p112]
				v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Roll, workspace, game.SoundService.Effect)
				v_u_3:Create(v114.Number1, TweenInfo.new(0.75, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					["Position"] = UDim2.new(0.225, 0, 0.5, 0)
				}):Play()
				v_u_3:Create(v114.Number1, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["ImageTransparency"] = 1
				}):Play()
				task.wait(0.15)
				v114.Number3.Image = v_u_14[p112]
				v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Roll, workspace, game.SoundService.Effect)
				v_u_3:Create(v114.Number3, TweenInfo.new(0.75, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					["Position"] = UDim2.new(0.775, 0, 0.5, 0)
				}):Play()
				v_u_3:Create(v114.Number3, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["ImageTransparency"] = 1
				}):Play()
				task.wait(0.15)
			end
			if p113 then
				v114.Number2.Image = v_u_14[p113]
				v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Roll, workspace, game.SoundService.Effect)
				v_u_3:Create(v114.Number2, TweenInfo.new(0.75, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					["Position"] = UDim2.new(0.5, 0, 0.5, 0)
				}):Play()
				v_u_3:Create(v114.Number2, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["ImageTransparency"] = 1
				}):Play()
				if p113 == p112 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Jackpot, workspace, game.SoundService.Effect)
				end
			end
		end,
		["Jackpot"] = function(p_u_115, p116, p_u_117)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_9
			local v118 = p_u_115:FindFirstChild("HumanoidRootPart")
			if v118 then
				local v119 = v_u_7.Hakari.IdleDeath.Jackpot:Clone()
				v119.Parent = workspace.Effects
				v119.CFrame = v118.CFrame
				v119.EnergyBurst:Emit(7)
				v119.Ring:Emit(7)
				v119.Sparks:Emit(21)
				v_u_2:AddItem(v119, 1)
				task.spawn(function()
					-- upvalues: (ref) v_u_7, (copy) p_u_115, (copy) p_u_117, (ref) v_u_3, (ref) v_u_2
					local v120 = v_u_7.Hakari.Dialogue:Clone()
					v120.Parent = p_u_115.Torso
					if p_u_117 then
						v120.Chat1.Sub.Text = "IN THE NEXT 50 SECONDS..."
					end
					local v121 = v120.Chat1.Position
					v120.Chat1.Position = v121 - UDim2.new(0, 0, 0.15, 0)
					v_u_3:Create(v120.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v121
					}):Play()
					v_u_3:Create(v120.Chat1, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_3:Create(v120.Chat1.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(0.5)
					local v122 = v120.Chat2.Position
					v120.Chat2.Position = v122 - UDim2.new(0, 0, 0.15, 0)
					v_u_3:Create(v120.Chat2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v122
					}):Play()
					v_u_3:Create(v120.Chat2, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_3:Create(v120.Chat2.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(2)
					v_u_2:AddItem(v120, 0.6)
					for _, v123 in v120:GetDescendants() do
						if v123:IsA("Frame") then
							v_u_3:Create(v123, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["Position"] = v123.Position - UDim2.new(0, 0, 0.2, 0),
								["BackgroundTransparency"] = 1
							}):Play()
						elseif v123:IsA("TextLabel") then
							v_u_3:Create(v123, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["TextTransparency"] = 1
							}):Play()
						end
					end
				end)
				if v_u_4.Character == p_u_115 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v124 = v_u_7.Hakari.IdleDeath.AudioVis:Clone()
					v124.Parent = v_u_4.PlayerGui
					repeat
						local v125 = 2 - p116.PlaybackLoudness / 330
						local v126 = math.clamp(v125, 1, (1 / 0))
						v124.Beat.Size = v124.Beat.Size:Lerp(UDim2.new(v126, 0, v126, 0), 0.5)
						task.wait()
					until not p116.Parent or p116.Volume ~= 1
					v_u_3:Create(v124.Beat, TweenInfo.new(0.25), {
						["ImageTransparency"] = 1
					}):Play()
					v_u_2:AddItem(v124, 0.25)
				end
			end
		end,
		["Shatter"] = function(p127)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3
			local v128 = v_u_7.Domain:Clone()
			v128.Transparency = 1
			v128.CanCollide = false
			v128.Position = p127
			v128.Parent = workspace.Effects
			v_u_2:AddItem(v128, 3)
			for _, v129 in v128:GetChildren() do
				if v129.Name == "Shatter" then
					v129:Emit(100)
				else
					v129:Destroy()
				end
			end
			v_u_12:PlaySound(v_u_8.Hakari.IdleDeath.Shatter, v128, game.SoundService.Effect)
			v128.Transparency = 0
			v_u_3:Create(v128, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v128.Position).Magnitude > 150 then
					return
				end
				local v130 = Random.new()
				local v131 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v132 = v_u_7.Gojo.Shard:Clone()
					local v133 = v130:NextUnitVector().Unit
					local v134 = math.random(1, 8)
					local v135 = math.random
					v132.Size = Vector3.new(0.1, v134, v135(1, 8))
					v132.CFrame = CFrame.lookAlong(p127, v133) * CFrame.Angles(1.5707963267948966, 0, 0) + v133 * 37.5
					v132.CFrame = v132.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v132.CanCollide = true
					v132.CollisionGroup = "Effects"
					v132.Parent = workspace.Effects
					local v136 = math.random(-50, 50)
					local v137 = math.random(-50, 50)
					local v138 = math.random
					v132.RotVelocity = Vector3.new(v136, v137, v138(-50, 50))
					v132.Transparency = 0
					v132.Material = Enum.Material.Neon
					v_u_3:Create(v132, v131, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v132, 4)
				end
			end
		end
	}
	task.spawn(function()
		-- upvalues: (ref) v_u_14
		game:GetService("ContentProvider"):PreloadAsync(v_u_14)
	end)
	v_u_10.Effects:Connect(function(p140, ...)
		-- upvalues: (copy) v_u_139
		local v141 = v_u_139[p140]
		if v141 then
			v141(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p142, p143, p144)
		-- upvalues: (ref) v_u_11, (ref) v_u_3
		local v145 = p143.HumanoidRootPart
		if not v145 then
			return
		end
		local v146 = nil
		while true do
			local v147 = v_u_11:SphereHitbox(p143, CFrame.new(0, 0, -4), 8)
			for _, v148 in v147 do
				local v149 = v148:FindFirstChild("Info")
				if v149 then
					local v150 = v149:FindFirstChild("Knockback")
					if not v150 or v150.Value ~= false then
						v146 = v147
						break
					end
				end
			end
			if v146 then
				local v151 = p142:FindFirstChildWhichIsA("NumberValue")
				if v151 then
					v_u_3:Create(v151, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p142.Parent then
				break
			end
		end
		p144:FireServer(v146, v145.CFrame)
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("HakariService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13