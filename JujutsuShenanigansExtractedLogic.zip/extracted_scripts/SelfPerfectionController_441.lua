-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = v5.Animations
local v_u_7 = v5.Utils
local v_u_8 = v5.Sounds
require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "SelfPerfectionController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_8, (copy) v_u_4, (copy) v_u_6, (copy) v_u_3, (copy) v_u_7, (copy) v_u_2, (ref) v_u_9
	local v_u_64 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_8.Mahito.SelfPerfection.Voice, v13, game.SoundService.Voice)
				v_u_10:DomainBurst(v13)
				local v14 = v_u_4.Character
				if v14 and v14:FindFirstChild("HumanoidRootPart") then
					local v15 = v14:FindFirstChild("HumanoidRootPart")
					if (v13.Position - v15.Position).Magnitude <= 37.5 then
						v_u_10:Domain(p12, function(p16, p17)
							-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_7
							p17.Humanoid:LoadAnimation(v_u_6.Mahito.DomainWarn):Play(0)
							p16.Panel.ImageLabel.Image = "rbxassetid://15049595421"
							p16.Panel.ImageLabel.Size = UDim2.new(0.8, 0, 0.8, 0)
							p16.Panel.Viewport.LightColor = Color3.fromRGB(255, 170, 255)
							p16.Panel.Viewport.Ambient = Color3.fromRGB(50, 30, 50)
							p16.Panel.Viewport.LightDirection = Vector3.new(0, -1, 0)
							v_u_3:Create(p16.Panel.Viewport, TweenInfo.new(1.5), {
								["LightColor"] = Color3.fromRGB(170, 255, 255),
								["Ambient"] = Color3.fromRGB(0, 55, 85)
							}):Play()
							local v18 = v_u_7.Mahito.SelfPerfection.Head:Clone()
							v18.Head.Weld.Part0 = p17.Head
							v18.Mouth.Weld.Part0 = p17.Head
							v18.Head.Transparency = 1
							v18.Mouth.Transparency = 1
							v18.Mouth.Hands.Color = p17.Head.Color
							v18.Parent = p17
						end)
					end
				end
			end
		end,
		["Opening"] = function(p19, p20, p_u_21, p22)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_8
			local v_u_23 = v_u_7.Mahito.SelfPerfection.DomainBG:Clone()
			v_u_23.Parent = p19
			v_u_23.CFrame = p19.CFrame
			task.spawn(function()
				-- upvalues: (copy) p_u_21, (copy) v_u_23
				repeat
					task.wait()
				until not (p_u_21.Parent and (p_u_21.Parent.Parent and p_u_21.Parent.Parent.Parent))
				v_u_23:Destroy()
			end)
			local v24 = v_u_23.Hands
			local v_u_25 = v24.AnimationController:LoadAnimation(v24.AnimationController.Animation)
			local v26 = TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.InOut)
			for _, v27 in v24:GetDescendants() do
				if v27:IsA("BasePart") then
					v27.Size = Vector3.new(0, 0, 0)
				end
			end
			if p22 then
				local v_u_28 = v_u_10:PlaySound(v_u_8.Mahito.SelfPerfection.Music, workspace, game.SoundService.Music, true)
				game.SoundService.AmbientReverb = Enum.ReverbType.Arena
				task.spawn(function()
					-- upvalues: (copy) p_u_21, (ref) v_u_3, (copy) v_u_28, (ref) v_u_2
					repeat
						task.wait()
					until not (p_u_21.Parent and (p_u_21.Parent.Parent and p_u_21.Parent.Parent.Parent))
					game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
					v_u_3:Create(v_u_28, TweenInfo.new(3), {
						["Volume"] = 0
					}):Play()
					v_u_2:AddItem(v_u_28, 3)
				end)
			else
				local v_u_29 = p20.DomainGround
				v_u_29.Surround.Enabled = true
				v_u_3:Create(v_u_29.Surround, TweenInfo.new(0.8), {
					["ShapePartial"] = 1
				}):Play()
				v_u_2:AddItem(v_u_29, 2)
				task.delay(0.8, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_29, (ref) v_u_10
					v_u_3:Create(v_u_29, TweenInfo.new(0.4), {
						["Transparency"] = 0
					}):Play()
					v_u_10:DomainMapFade(Color3.fromRGB(0, 0, 0), 0.4, 1.6)
				end)
				local v_u_30 = nil
				game.SoundService.AmbientReverb = Enum.ReverbType.Arena
				task.spawn(function()
					-- upvalues: (copy) p_u_21, (ref) v_u_30, (ref) v_u_3, (ref) v_u_2
					repeat
						task.wait()
					until not (p_u_21.Parent and (p_u_21.Parent.Parent and p_u_21.Parent.Parent.Parent))
					game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
					if v_u_30 then
						v_u_3:Create(v_u_30, TweenInfo.new(3), {
							["Volume"] = 0
						}):Play()
						v_u_2:AddItem(v_u_30, 3)
					end
				end)
				task.wait(1)
				v_u_30 = v_u_10:PlaySound(v_u_8.Mahito.SelfPerfection.Music, workspace, game.SoundService.Music, true)
				task.wait(0.5)
			end
			v_u_23.Stars.Enabled = true
			v_u_23.Rays.Enabled = true
			for _, v31 in v24:GetDescendants() do
				if v31:IsA("BasePart") then
					v_u_3:Create(v31, v26, {
						["Size"] = Vector3.new(20, 80, 20)
					}):Play()
				end
			end
			v_u_10:PlaySound(v_u_8.Mahito.SelfPerfection.Perfection, workspace, game.SoundService.Effect)
			v24:SetPrimaryPartCFrame(v_u_23.CFrame * CFrame.new(0, 10, 120))
			v_u_25:Play(0)
			v_u_25:GetMarkerReachedSignal("Loop"):Connect(function()
				-- upvalues: (copy) v_u_25
				v_u_25.TimePosition = 1.5
			end)
			for v32 = 1, 10 do
				local v_u_33 = 36 * v32
				local v_u_34 = CFrame.Angles(0, 0, (math.rad(v_u_33)))
				local v_u_35 = (v_u_23.CFrame * v_u_34 - (v_u_23.CFrame * v_u_34).LookVector * 120).Position
				task.delay(v32 % 2 == 0 and 0 or 0.2, function()
					-- upvalues: (ref) v_u_33, (copy) v_u_34, (copy) v_u_23, (ref) v_u_35, (ref) v_u_7, (ref) v_u_3
					for v36 = 1, 15 do
						v_u_33 = 12 * v36
						local v37 = v_u_33
						local v38 = v_u_34 * CFrame.Angles(math.rad(v37), 0, 0)
						local v39 = (v_u_23.CFrame * v38 - (v_u_23.CFrame * v38).LookVector * 120).Position
						local v40 = CFrame.new(v_u_35, v39)
						local v41 = v_u_7.Mahito.SelfPerfection.Hand:Clone()
						v41.CFrame = v40
						v41.Parent = v_u_23.HandFolder
						v_u_35 = v39
						local v42 = v_u_3
						local v43 = TweenInfo.new(0.4, Enum.EasingStyle.Back)
						local v44 = {
							["Size"] = Vector3.new(10, 10, 30)
						}
						local v45 = v40 + v40.LookVector * 5
						local v46 = CFrame.Angles
						local v47 = math.random(-10, 10)
						local v48 = math.rad(v47)
						local v49 = math.random(-10, 10)
						local v50 = math.rad(v49)
						local v51 = math.random(0, 360)
						v44.CFrame = v45 * v46(v48, v50, (math.rad(v51)))
						v42:Create(v41, v43, v44):Play()
						task.wait(0.2)
						if not v_u_23.Parent then
							break
						end
					end
				end)
			end
		end,
		["Shatter"] = function(p52)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_10, (ref) v_u_8, (ref) v_u_3
			local v53 = v_u_7.Domain:Clone()
			v53.Transparency = 1
			v53.CanCollide = false
			v53.Position = p52
			v53.Shatter.Color = ColorSequence.new(Color3.new(0, 0, 0))
			v53.Parent = workspace.Effects
			v_u_2:AddItem(v53, 3)
			for _, v54 in v53:GetChildren() do
				if v54.Name == "Shatter" then
					v54:Emit(100)
				else
					v54:Destroy()
				end
			end
			v_u_10:PlaySound(v_u_8.Itadori.MalevolantShrine.Shatter, v53, game.SoundService.Effect)
			v53.Transparency = 0
			v53.Color = Color3.new(0, 0, 0)
			v_u_3:Create(v53, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v53.Position).Magnitude > 150 then
					return
				end
				local v55 = Random.new()
				local v56 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v57 = v_u_7.Gojo.Shard:Clone()
					local v58 = v55:NextUnitVector().Unit
					local v59 = math.random(1, 8)
					local v60 = math.random
					v57.Size = Vector3.new(0.1, v59, v60(1, 8))
					v57.CFrame = CFrame.lookAlong(p52, v58) * CFrame.Angles(1.5707963267948966, 0, 0) + v58 * 37.5
					v57.CFrame = v57.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v57.Color = Color3.new(0, 0, 0)
					v57.CanCollide = true
					v57.CollisionGroup = "Effects"
					v57.Parent = workspace.Effects
					local v61 = math.random(-50, 50)
					local v62 = math.random(-50, 50)
					local v63 = math.random
					v57.RotVelocity = Vector3.new(v61, v62, v63(-50, 50))
					v57.Transparency = 0
					v57.Material = Enum.Material.Neon
					v_u_3:Create(v57, v56, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v57, 4)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p65, ...)
		-- upvalues: (copy) v_u_64
		local v66 = v_u_64[p65]
		if v66 then
			v66(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("SelfPerfectionService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11