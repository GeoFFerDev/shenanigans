-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "AdaptationController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_6, (copy) v_u_7, (copy) v_u_2, (ref) v_u_10
	local v_u_74 = {
		["Glow"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				local v15 = p13:FindFirstChild("Outfit")
				if v15 then
					v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.AdaptGlow, v14, game.SoundService.Effect)
					local v16 = v15.Head.DivineWheel
					local v17 = v16:Clone()
					v17.Color = Color3.fromRGB(188, 155, 93)
					v17.Material = Enum.Material.Neon
					v17.Size = v17.Size + Vector3.new(0.1, 0.1, 0.1)
					local v18 = Instance.new("Weld", v17)
					v18.Part0 = v16
					v18.Part1 = v17
					v17.Parent = workspace.Effects
					v_u_4:Create(v17, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v17, 0.6)
				end
			end
		end,
		["Adapt"] = function(p19, p20, p21)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3
			local v22 = p19:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = p19:FindFirstChild("Outfit")
				if v23 then
					v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.Adapt2, v22, game.SoundService.Effect)
					local v24 = v23.Head.DivineWheelWeld
					v24.C1 = CFrame.new() * CFrame.Angles(0, -90, 0)
					v_u_4:Create(v24, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
						["C1"] = CFrame.new()
					}):Play()
				end
				if v_u_5.Character == p19 or v_u_5.Character == p20 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					if not p21 then
						local v25 = v_u_6.Utils.Megumi.Mahoraga.Adapt:Clone()
						v25.Type.Text = (p19:GetAttribute("A1") or "Melee") .. " Attacks"
						if p19:GetAttribute("A2") == 1.1 then
							v25.Effect.Text = "-10% DMG"
						elseif p19:GetAttribute("A2") == 1.3 then
							v25.Effect.Text = "-30% DMG"
						elseif p19:GetAttribute("A2") == 1.5 then
							v25.Effect.Text = "-50% DMG"
						elseif p19:GetAttribute("A2") == 1.7 then
							v25.Effect.Text = "-70% DMG"
						else
							v25.Effect.Text = "FULL ADAPTATION"
						end
						v25.Parent = v_u_5.PlayerGui
						v_u_3:AddItem(v25, 1)
						v_u_4:Create(v25.Fade, TweenInfo.new(0.4), {
							["Size"] = UDim2.new(3, 0, 3, 0),
							["ImageTransparency"] = 1
						}):Play()
						v_u_4:Create(v25.Wheel, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
							["Rotation"] = 90
						}):Play()
						v_u_4:Create(v25.Wheel.UIGradient, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
							["Rotation"] = 0
						}):Play()
						v_u_4:Create(v25.Wheel, TweenInfo.new(1), {
							["ImageTransparency"] = 1
						}):Play()
						v_u_4:Create(v25.Type, TweenInfo.new(1), {
							["TextTransparency"] = 1
						}):Play()
						v_u_4:Create(v25.Effect, TweenInfo.new(1), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["Start"] = function(p26)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.Takedown.Startup, v27, game.SoundService.Effect)
			end
		end,
		["Teleport"] = function(p_u_28)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v_u_29 = p_u_28:FindFirstChild("HumanoidRootPart")
			if v_u_29 then
				local v30 = Instance.new("Model")
				local v_u_31 = v_u_7.Gojo.Teleport:Clone()
				v_u_31.CFrame = v_u_29.CFrame + Vector3.new(0, 2, 0)
				v_u_31.Parent = v30
				v30:ScaleTo(2)
				v_u_31.Parent = workspace.Effects
				v30:Destroy()
				v_u_3:AddItem(v_u_31, 1.1)
				v_u_31.Floor.Dust:Emit(30)
				v_u_31.Lines:Emit(30)
				v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.Takedown.Teleport, v_u_29, game.SoundService.Effect)
				task.delay(0.02, function()
					-- upvalues: (copy) v_u_31, (copy) v_u_29, (ref) v_u_4, (copy) p_u_28
					v_u_31.CFrame = v_u_29.CFrame
					v_u_31.Lines:Emit(30)
					v_u_31.Floor.Dust:Emit(30)
					local v32 = v_u_29:FindFirstChild("RootJoint")
					if v32 then
						local v33 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0)
						v32.C0 = v33 * CFrame.new(7, 0, 0)
						v_u_4:Create(v32, TweenInfo.new(0.5, Enum.EasingStyle.Elastic), {
							["C0"] = v33
						}):Play()
					end
					local v34 = p_u_28:FindFirstChild("Outfit")
					if v34 then
						local v35 = TweenInfo.new(0.15, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
						for _, v36 in v34:GetDescendants() do
							if v36:IsA("BasePart") then
								local v37 = v36.Transparency
								v36.Transparency = 1
								v_u_4:Create(v36, v35, {
									["Transparency"] = v37
								}):Play()
							end
						end
					end
				end)
				if v_u_5.Character == p_u_28 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end,
		["Hit"] = function(p38, p39)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_9
			local v40 = p38:FindFirstChild("HumanoidRootPart")
			if v40 then
				local v41 = p39:FindFirstChild("HumanoidRootPart")
				if v41 then
					local v42 = v_u_7.Gojo.HardHit:Clone()
					v42.CFrame = v40.CFrame * CFrame.Angles(0.5235987755982988, 0, 0) + v40.CFrame.LookVector * 3.5
					v42.Position = v41.Position
					v42.Parent = workspace.Effects
					v42.Dust:Emit(5)
					v42.Ring:Emit(5)
					v42.Sparks:Emit(10)
					v_u_3:AddItem(v42, 0.5)
					v_u_11:Flash(p39, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_8.Megumi.Elephant.Hit, v41, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_8.Itadori.Rush.RushLaunch, v41, game.SoundService.Effect)
					if (workspace.CurrentCamera.CFrame.Position - v41.Position).Magnitude < 150 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
					end
				end
			else
				return
			end
		end,
		["WorldSlash"] = function(p43)
			-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9
			local v44 = p43:FindFirstChild("HumanoidRootPart")
			if v44 then
				local v_u_45 = v_u_7.Megumi.Mahoraga.WorldSlash:Clone()
				v_u_45:ScaleTo(2)
				v_u_45:PivotTo(v44.CFrame * CFrame.new(0, -6, 0) * CFrame.Angles(0, -1.5707963267948966, 0))
				v_u_45.Char.Value = p43
				v_u_45.Parent = workspace.Effects
				v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.WorldSlash.Startup, v44, game.SoundService.Effect)
				local v46 = TweenInfo.new(0.7, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
				for _, v47 in v_u_45.groundwavepart.windbeamburst:GetDescendants() do
					if v47:IsA("Beam") then
						v_u_4:Create(v47, v46, {
							["Brightness"] = 0,
							["TextureSpeed"] = 0
						}):Play()
					end
				end
				local v48 = TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				v_u_4:Create(v_u_45.mesh.Decal, v48, {
					["Transparency"] = 1
				}):Play()
				v_u_4:Create(v_u_45.mesh.Mesh, v48, {
					["Scale"] = Vector3.new(16, 0, 16)
				}):Play()
				v_u_4:Create(v_u_45.mesh, v48, {
					["CFrame"] = v_u_45.mesh.CFrame * CFrame.new(0, -12, 0) * CFrame.Angles(0, -3.12413936106985, 0)
				}):Play()
				v_u_45.groundwavepart.speedlines1:Emit(10)
				v_u_45.groundwavepart.speedlines2:Emit(10)
				v_u_45.groundwavepart.groundwave.groundwave1:Emit(10)
				v_u_45.groundwavepart.groundwave.groundwave2:Emit(4)
				v_u_45.groundwavepart.groundwave.groundwave3:Emit(8)
				v_u_45.groundwavepart.groundwave.groundwave4:Emit(8)
				v_u_45.groundwavepart.groundwave.groundwave5:Emit(4)
				v_u_45.groundwavepart.groundwave.groundwave6:Emit(4)
				v_u_45.groundwavepart.groundwave.groundwave7:Emit(4)
				v_u_45.groundwavepart.groundwave.groundwave8:Emit(6)
				v_u_45.groundwavepart.groundwave.groundwave9:Emit(10)
				v_u_45.groundwavepart.groundwave.groundwave10:Emit(5)
				v_u_45.groundwavepart.groundwave.groundwave11:Emit(1)
				v_u_3:AddItem(v_u_45, 3)
				local v49 = p43.Info:FindFirstChild("WorldSlash")
				if v49 then
					if (workspace.CurrentCamera.CFrame.Position - v_u_45.PrimaryPart.Position).Magnitude < 150 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
					v49.Destroying:Connect(function()
						-- upvalues: (copy) v_u_45
						for _, v50 in v_u_45:GetDescendants() do
							if v50:IsA("ParticleEmitter") or v50:IsA("Beam") then
								v50.Enabled = false
							end
						end
					end)
				end
			end
		end,
		["WorldSparkle"] = function(p51)
			-- upvalues: (ref) v_u_7, (ref) v_u_9
			local v52 = nil
			for _, v53 in workspace.Effects:GetChildren() do
				if v53.Name == "WorldSlash" then
					local v54 = v53:FindFirstChild("Char")
					if v54 and v54.Value == p51 then
						v52 = v53
					end
				end
			end
			if v52 then
				if v52.groundwavepart.chargespeedlines1.Enabled == false then
					return
				else
					v52.groundwavepart.sparklelines1.Enabled = true
					v52.groundwavepart.sparklelines2.Enabled = true
					task.wait(0.25)
					if v52.groundwavepart.chargespeedlines1.Enabled ~= false then
						v52.groundwavepart.sparklelines1.Enabled = false
						v52.groundwavepart.sparklelines2.Enabled = false
						if (workspace.CurrentCamera.CFrame.Position - v52.PrimaryPart.Position).Magnitude < 150 then
							local v_u_55 = v_u_7.Megumi.Mahoraga.ImpactFrames:Clone()
							v_u_55.Parent = game.Lighting
							task.delay(0.05, function()
								-- upvalues: (copy) v_u_55, (ref) v_u_9
								v_u_55.Contrast = 0
								v_u_55.Saturation = 64
								task.wait(0.05)
								v_u_55.Contrast = 8
								v_u_55.Saturation = -1
								task.wait(0.05)
								v_u_55.Contrast = -8
								task.wait(0.05)
								v_u_55:Destroy()
								v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
							end)
						end
						for _, v_u_56 in v52.groundwavepart.impactframes["1"]:GetChildren() do
							v_u_56.Enabled = true
							task.delay(0.167, function()
								-- upvalues: (copy) v_u_56
								v_u_56.Enabled = false
							end)
						end
					end
				end
			else
				return
			end
		end,
		["Interp"] = function(p57, p_u_58)
			-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_11, (ref) v_u_8
			local v_u_59 = p_u_58.CFrame
			local v_u_60 = tick()
			local v_u_61 = p_u_58:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_59, (copy) p_u_58, (ref) v_u_60
				v_u_59 = p_u_58.CFrame
				v_u_60 = tick()
			end)
			local v_u_62 = nil
			v_u_62 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_58, (ref) v_u_62, (copy) v_u_61, (ref) v_u_59, (ref) v_u_60
				if p_u_58.Parent then
					workspace:BulkMoveTo({ p_u_58 }, { v_u_59 + v_u_59.LookVector * (250 * (tick() - v_u_60)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_62:Disconnect()
					v_u_61:Disconnect()
				end
			end)
			local v63 = TweenInfo.new(0.7, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
			v_u_4:Create(p_u_58.slash.a, v63, {
				["Width1"] = 0
			}):Play()
			v_u_4:Create(p_u_58.slash.a2, v63, {
				["Width1"] = 0
			}):Play()
			v_u_4:Create(p_u_58.slash.b, v63, {
				["Width1"] = 0
			}):Play()
			v_u_4:Create(p_u_58.slash.b2, v63, {
				["Width1"] = 0
			}):Play()
			task.delay(0.5, function()
				-- upvalues: (copy) p_u_58
				for _, v64 in p_u_58:GetDescendants() do
					if v64:IsA("ParticleEmitter") then
						v64.Enabled = false
					end
				end
			end)
			local v65 = p57:FindFirstChild("HumanoidRootPart")
			if v65 then
				v_u_11:PlaySound(v_u_8.Megumi.Mahoraga.WorldSlash.Swing, v65, game.SoundService.Effect)
				local v66 = nil
				for _, v67 in workspace.Effects:GetChildren() do
					if v67.Name == "WorldSlash" then
						local v68 = v67:FindFirstChild("Char")
						if v68 and v68.Value == p57 then
							v66 = v67
						end
					end
				end
				if v66 then
					for _, v69 in v66:GetDescendants() do
						if v69:IsA("ParticleEmitter") or v69:IsA("Beam") then
							v69.Enabled = false
						end
					end
					v66.groundwavepart.slash.slash1:Emit(8)
					v66.groundwavepart.slash.slash2:Emit(4)
					v66.groundwavepart.slash.slash3:Emit(8)
					v66.groundwavepart.slash.slash4:Emit(8)
				end
			else
				return
			end
		end,
		["WorldHit"] = function(p70, p71)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7
			local v72 = p70:FindFirstChild("HumanoidRootPart")
			if v72 then
				v_u_11:Flash(p70, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Slash, v72, game.SoundService.Effect)
				if p71 then
					v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Explode, v72, game.SoundService.Effect)
					v_u_11:Bleed(p70)
					if v_u_5.Character == p70 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						local v73 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v73.TintColor = Color3.new(1, 1, 1)
						v73.Parent = game.Lighting
						task.wait(0.04)
						v73.Brightness = 200
						v73.Contrast = -1000
						task.wait(0.04)
						v73:Destroy()
					end
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p75, ...)
		-- upvalues: (copy) v_u_74
		local v76 = v_u_74[p75]
		if v76 then
			v76(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("AdaptationService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12