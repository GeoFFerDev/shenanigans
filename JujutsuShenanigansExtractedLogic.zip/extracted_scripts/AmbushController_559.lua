-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v10 = RaycastParams.new()
v10.FilterType = Enum.RaycastFilterType.Include
v10.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "StingerController"
})
function v14.KnitStart(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (ref) v_u_12, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_11
	local v_u_31 = {
		["Start"] = function(p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_3
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = p15.SetAssets:FindFirstChild("HarutaSword")
				local v18 = v_u_6.Haruta.CombatTrail:Clone()
				v18.Weld.Part0 = v17.Blade
				v18.Parent = workspace.Effects
				v_u_2:AddItem(v18, 0.7)
				v_u_12:PlaySound(v_u_7.Haruta.AmbushSwing, v16, game.SoundService.Effect)
				task.wait(0.2)
				task.wait(0.3)
				v18.Trail.Enabled = false
				v_u_3:Create(v18, TweenInfo.new(0.1), {
					["Transparency"] = 1
				}):Play()
			end
		end,
		["Whoosh"] = function(p19)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_12:PlaySound(v_u_7.Haruta.Backstab, v20, game.SoundService.Effect)
				local v21 = v_u_6.Choso.CounterSwing:Clone()
				v21:PivotTo(v20.CFrame * CFrame.new(0, -6, -6) * CFrame.Angles(-0.7853981633974483, 0.17453292519943295, 0))
				v21.Parent = workspace.Effects
				v21.Shockwave:Destroy()
				v_u_2:AddItem(v21, 0.3)
				v21.Shock.Size = Vector3.new(10, 2, 10)
				v_u_3:Create(v21.Shock, TweenInfo.new(0.125), {
					["Size"] = Vector3.new(2, 15, 2),
					["Transparency"] = 1,
					["Position"] = v21.Shock2.Position + v20.CFrame.LookVector * 3
				}):Play()
				v_u_3:Create(v21.Shock2, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1,
					["Position"] = v21.Shock2.Position + v20.CFrame.LookVector * 3
				}):Play()
			end
		end,
		["Hit"] = function(p22, p23, p24)
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7
			local v25 = p22:FindFirstChild("HumanoidRootPart")
			if v25 then
				local v26 = p23:FindFirstChild("HumanoidRootPart")
				if v26 then
					if p22 == v_u_4.Character or p23 == v_u_4.Character then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
					end
					local v27 = v_u_6.Yuta.SlashHit:Clone()
					v27.CFrame = CFrame.lookAlong(v26.Position, v25.CFrame.LookVector)
					if p24 then
						v27.CFrame = CFrame.lookAlong((p23.Torso.CFrame * CFrame.new(0, 1, 0)).Position, v25.CFrame.LookVector)
						v27.CFrame = v27.CFrame * CFrame.Angles(0, 0, -0.4363323129985824)
					else
						v27.CFrame = v27.CFrame * CFrame.Angles(0, 0, -0.7853981633974483)
					end
					v27.Parent = workspace.Effects
					v_u_2:AddItem(v27, 0.5)
					v27.Slash:Emit(5)
					v_u_12:Flash(p23, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Haruta.AmbushHit, v26, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Stab"] = function(p28, p29, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_4, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9
			if p28:FindFirstChild("HumanoidRootPart") then
				local v30 = p29:FindFirstChild("HumanoidRootPart")
				if v30 then
					v_u_12:Flash(p29, Color3.new(0.745098, 0, 0.0117647))
					if p28 == v_u_4.Character or p29 == v_u_4.Character then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
					end
					v_u_12:PlaySound(v_u_7.Choso.BloodEdge.StabHit, v30, game.SoundService.Effect).PlaybackSpeed = math.random(90, 110) / 100
					for _ = 1, 8 do
						v_u_9:Blood(CFrame.lookAt(p29.Torso.Position, p29.Torso.Position + Vector3.new(0, 10, 0)), math.random(20, 40), math.random(20, 40), math.random(20, 40))
					end
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p32, ...)
		-- upvalues: (copy) v_u_31
		local v33 = v_u_31[p32]
		if v33 then
			v33(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_13, (ref) v_u_12
	v_u_11 = v_u_1.GetService("AmbushService")
	v_u_13 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v14