-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local v_u_4 = v3.Utils
local v_u_5 = v3.Sounds
require(v3.Modules.CameraShaker)
require(v3.Modules.BloodyZee)
local v_u_6 = nil
local v_u_7 = nil
local v8 = v_u_1.CreateController({
	["Name"] = "RikaLaunchController"
})
function v8.KnitStart(_)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (ref) v_u_7, (copy) v_u_5
	local v_u_14 = {
		["Feint"] = function(p9)
			-- upvalues: (ref) v_u_4, (ref) v_u_2
			local v10 = p9:FindFirstChild("HumanoidRootPart")
			if v10 then
				local v11 = v_u_4.Itadori.CounterHit.Feint:Clone()
				for _, v12 in v11:GetChildren() do
					v12.Color = ColorSequence.new(Color3.fromRGB(255, 170, 255))
				end
				v11.Parent = v10
				v11.Sparks:Emit(10)
				v11.Star:Emit(1)
				v11.Ring:Emit(1)
				v_u_2:AddItem(v11, 0.5)
			end
		end,
		["StartSound"] = function(p13)
			-- upvalues: (ref) v_u_7, (ref) v_u_5
			v_u_7:PlaySound(v_u_5.Yuta.Rika.Launch, p13, game.SoundService.Effect)
		end
	}
	RikaLaunchService.Effects:Connect(function(p15, ...)
		-- upvalues: (copy) v_u_14
		local v16 = v_u_14[p15]
		if v16 then
			v16(...)
		end
	end)
end
function v8.KnitInit(_)
	-- upvalues: (copy) v_u_1, (ref) v_u_6, (ref) v_u_7
	RikaLaunchService = v_u_1.GetService("RikaLaunchService")
	v_u_6 = v_u_1.GetController("HitboxController")
	v_u_7 = v_u_1.GetController("FXController")
end
return v8