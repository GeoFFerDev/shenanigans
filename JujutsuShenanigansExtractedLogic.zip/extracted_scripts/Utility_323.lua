-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {}
v_u_1.__index = v_u_1
v_u_1.Seed = Random.new()
function v_u_1.Destroy(p2)
	if p2.Connection then
		p2:Clean()
		p2.Connection = nil
		table.clear(p2)
	end
end
function v_u_1.Clean(p3)
	if p3.Connection then
		p3.Connection:Disconnect()
		p3.DestroyConnection:Disconnect()
	end
end
function v_u_1.Disconnect(p4)
	if p4.Connection then
		p4.Connection:Disconnect()
		p4.DestroyConnection:Disconnect()
	end
end
function v_u_1.BindSignalDisconnectToInstanceDestroying(p5, p6, p7)
	-- upvalues: (copy) v_u_1
	local v_u_8 = p5:Connect(p7)
	local v9 = {
		["Connection"] = v_u_8,
		["DestroyConnection"] = p6.Destroying:Once(function()
			-- upvalues: (ref) v_u_8
			v_u_8:Disconnect()
		end),
		["Instance"] = p6
	}
	local v10 = v_u_1
	return setmetatable(v9, v10)
end
v_u_1.ShiftlockRenderPriority = Enum.RenderPriority.Character.Value
return v_u_1