-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "code",
	["Description"] = "Adds / Remove a code from a player\'s data",
	["Group"] = { "Owner", "Developer" },
	["Args"] = {
		{
			["Type"] = "player",
			["Name"] = "Player"
		},
		{
			["Type"] = "string",
			["Name"] = "Code"
		},
		{
			["Type"] = "boolean",
			["Name"] = "Clear"
		}
	}
}
return v1