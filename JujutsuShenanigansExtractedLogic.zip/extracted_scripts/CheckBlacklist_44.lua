-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "checkblacklist",
	["Description"] = "Check if an ID is blacklisted anywhere",
	["Group"] = { "Owner", "Developer", "HeadMod" },
	["Args"] = {
		{
			["Type"] = "number",
			["Name"] = "ID"
		}
	}
}
return v1