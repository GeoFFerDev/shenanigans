-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "ItadoriController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10, (ref) v_u_11
	local v_u_87 = {
		["Hit"] = function(p14, p15, p16)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v17 = p14:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_12:Flash(p14, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit" .. (p15 or 1)), v17, game.SoundService.Effect)
				if p16 then
					local v18 = v_u_6.Itadori.CounterHit:Clone()
					v18.Position = v17.Position
					v18.Parent = workspace.Effects
					v18.Glow:Emit(1)
					v18.Sparks:Emit(20)
					v_u_2:AddItem(v18, 0.5)
				end
			end
		end,
		["ChaseHit"] = function(p19, p20)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2
			local v21 = p19:FindFirstChild("HumanoidRootPart")
			if v21 then
				local v22 = p20:FindFirstChild("HumanoidRootPart")
				if v22 then
					v_u_12:Flash(p20, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Gojo.M1:FindFirstChild("Hit3"), v22, game.SoundService.Effect)
					local v23 = v_u_6.ChaseHit:Clone()
					local v24 = CFrame.new
					local v25 = v22.Position
					local v26 = v21.Position.X
					local v27 = v22.Position.Y
					local v28 = v21.Position.Z
					v23.CFrame = v24(v25, (Vector3.new(v26, v27, v28))) * CFrame.Angles(0, 3.141592653589793, 0)
					v23.Parent = workspace.Effects
					v23.Ring:Emit(7)
					v23.Sparks:Emit(12)
					v_u_2:AddItem(v23, 0.5)
				end
			else
				return
			end
		end,
		["DismantleHit"] = function(p29, p30, p31)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3
			local v32 = p29.Character:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_12:PlaySound(v_u_7.Itadori.Dismantle.FinishSlash, v32, game.SoundService.Effect)
				local v33
				if typeof(p30) == "Vector3" then
					v33 = p30
				else
					v33 = p30.HumanoidRootPart.Position
					v_u_12:Flash(p30, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_7.Itadori.Dismantle.Slash, p30.HumanoidRootPart, game.SoundService.Effect)
				end
				for _, v34 in ({
					{ CFrame.Angles(0, 0, -0.8726646259971648) },
					{ CFrame.Angles(0, 0, -0.7853981633974483) },
					{ CFrame.Angles(0, 0, 0) },
					{ CFrame.new(-3, 0, 0) * CFrame.Angles(0, 0, 1.0471975511965976), CFrame.new(3, 0, 0) * CFrame.Angles(0, 0, 0.8726646259971648), CFrame.Angles(0, 0, -0.5235987755982988) }
				})[p31] do
					local v_u_35 = CFrame.new(v32.Position, v33) * v34
					local v_u_36 = v_u_6.Itadori.Dismantle.DismantleFly:Clone()
					v_u_36.CFrame = v_u_35
					v_u_36.Parent = workspace.Effects
					local v_u_37 = Instance.new("Highlight", v_u_36)
					v_u_37.DepthMode = Enum.HighlightDepthMode.Occluded
					v_u_37.FillTransparency = 0
					v_u_37.FillColor = Color3.new(0, 0, 0)
					task.delay(0, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_36, (copy) v_u_35, (copy) v_u_37
						v_u_3:Create(v_u_36, TweenInfo.new(0.1), {
							["Size"] = Vector3.new(15, 0, 0),
							["CFrame"] = v_u_35 + v_u_35.LookVector * 30
						}):Play()
						task.wait(0.1)
						v_u_37:Destroy()
						v_u_36.Transparency = 1
						task.wait(0.05)
						v_u_36:Destroy()
					end)
				end
			end
		end,
		["CleaveGrab"] = function(p38)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v39 = p38:FindFirstChild("HumanoidRootPart")
			if v39 then
				v_u_12:Flash(p38, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v39, game.SoundService.Effect)
			end
		end,
		["CleaveHit"] = function(p40, p41)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_6, (ref) v_u_8, (ref) v_u_2, (ref) v_u_9
			local v42 = p41:FindFirstChild("HumanoidRootPart")
			if v42 then
				v_u_12:Flash(p41, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Itadori.Dismantle.Explode, v42, game.SoundService.Effect)
				if v_u_4.Character == p40 or v_u_4.Character == p41 then
					task.delay(0.1, function()
						-- upvalues: (ref) v_u_6
						local v43 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v43.Parent = game.Lighting
						task.wait(0.05)
						v43.TintColor = Color3.new(1, 1, 1)
						v43.Brightness = 200
						v43.Contrast = -1000
						task.wait(0.05)
						v43:Destroy()
					end)
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				local v_u_44 = v_u_6.Itadori.Dismantle.Cleave:Clone()
				v_u_44.Weld.Part1 = v42
				v_u_44.Parent = workspace.Effects
				task.delay(0.1, function()
					-- upvalues: (copy) v_u_44, (ref) v_u_2
					v_u_44.Slashes.Enabled = false
					v_u_44.Slash2.Enabled = false
					v_u_44.PointLight:Destroy()
					v_u_2:AddItem(v_u_44, 0.08)
				end)
				v_u_12:PlaySound(v_u_7.Itadori.Dismantle.FinishSlash, v42, game.SoundService.Effect)
				for _ = 1, 10 do
					v_u_44.Slashes:Emit(1)
					v_u_12:PlaySound(v_u_7.Itadori.Dismantle.Slash, v42, game.SoundService.Effect)
					v_u_9:Blood(p40.Torso.CFrame, 50, 180, 180)
					task.wait()
				end
			end
		end,
		["BlackFlashHit"] = function(p45, p46)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			if p45:FindFirstChild("HumanoidRootPart") then
				local v47 = p46:FindFirstChild("HumanoidRootPart")
				if v47 then
					local v48 = v_u_6.Itadori.PerfectHit:Clone()
					v48.Position = v47.Position
					v48.Parent = workspace.Effects
					v_u_2:AddItem(v48, 1)
					v_u_12:Flash(p46, Color3.new(1, 0, 0))
					v_u_12:PlaySound(v_u_7.Itadori.PerfectHit, v47, game.SoundService.Effect)
					v48.Wind2:Emit(8)
					v48.Lightning:Emit(6)
					v48.Sparks:Emit(15)
					v48.Sparks2:Emit(20)
					v_u_3:Create(v48.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					if v_u_4.Character == p45 or v_u_4.Character == p46 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
				end
			else
				return
			end
		end,
		["Finisher"] = function(p49)
			-- upvalues: (ref) v_u_12
			if p49.HumanoidRootPart then
				v_u_12:Bleed(p49)
			end
		end,
		["Feint"] = function(p50)
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			local v51 = p50.HumanoidRootPart
			if v51 then
				local v52 = v_u_6.Itadori.CounterHit.Feint:Clone()
				v52.Parent = v51
				v52.Sparks:Emit(10)
				v52.Star:Emit(1)
				v52.Ring:Emit(1)
				v_u_2:AddItem(v52, 0.5)
			end
		end,
		["Chase"] = function(p53)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7
			local v54 = p53.HumanoidRootPart
			if v54 then
				local v55 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v55.CFrame = v54.CFrame * CFrame.new(0, 1, -4)
				v55.Size = Vector3.new(0, 0, 2)
				v55.Parent = workspace.Effects
				v_u_3:Create(v55, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v55, 0.3)
				v_u_12:PlaySound(v_u_7.Misc.Chase, v54, game.SoundService.Effect)
				v_u_12:DustTrail(p53, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p56)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v57 = p56:FindFirstChild("HumanoidRootPart")
			if v57 then
				v_u_12:PlaySound(v_u_7.Misc.Swing.Fist, v57, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p58, p59, p60)
			-- upvalues: (ref) v_u_12
			if p58:GetAttribute("InUlt") then
				if p59 == 4 then
					v_u_12:ArmFlash(p58["Left Arm"], Color3.fromRGB(255, 255, 255), 0.3)
					v_u_12:ArmFlash(p58["Right Arm"], Color3.fromRGB(255, 255, 255), 0.3)
				else
					v_u_12:ArmFlash(p58["Right Arm"], Color3.fromRGB(255, 255, 255), 0.3)
				end
			elseif p59 == 1 or (p59 == 3 or p60 == "Up") then
				v_u_12:ArmFlash(p58["Right Arm"], Color3.fromRGB(255, 0, 0))
				return
			elseif p59 == 2 then
				v_u_12:ArmFlash(p58["Left Arm"], Color3.fromRGB(255, 0, 0))
			elseif p59 == 4 then
				v_u_12:ArmFlash(p58["Right Leg"], Color3.fromRGB(255, 0, 0), p60 == "Down" and 0.4 or false)
			end
		end,
		["Launch"] = function(p61, p62)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v63 = p61:FindFirstChild("HumanoidRootPart")
			if v63 then
				local v64 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v64.CFrame = CFrame.new(v63.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v64.Size = Vector3.new(0, 0, 5)
				v64.Parent = workspace.Effects
				v_u_3:Create(v64, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v64.Position + Vector3.new(0, p62, 0)
				}):Play()
				v_u_2:AddItem(v64, 0.3)
				if p62 < 0 then
					v_u_12:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v63, game.SoundService.Effect)
					v_u_12:DustBreak(v63.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 15, 25, 0.7, 1.4)
					if v_u_4:DistanceFromCharacter(v63.Position) < 20 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					end
				end
			end
		end,
		["Switch"] = function(p65)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v66 = p65:FindFirstChild("HumanoidRootPart")
			if v66 then
				local v67 = v_u_6.Itadori.Switch.Fade:Clone()
				v67.Parent = v66.RootAttachment
				v67:Emit(1)
				v_u_2:AddItem(v67, 1)
				local v68 = v_u_6.Itadori.Switch.Switch:Clone()
				v68.Parent = v66
				v_u_2:AddItem(v68, 0.8)
				for _, v_u_69 in v68:GetChildren() do
					v_u_3:Create(v_u_69, TweenInfo.new(0.3, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
						["Size"] = v_u_69.Size + UDim2.new(0, 0, 0.1, 0)
					}):Play()
					task.delay(0.3, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_69
						v_u_3:Create(v_u_69, TweenInfo.new(0.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
							["Size"] = v_u_69.Size - UDim2.new(0, 0, 0.1, 0)
						}):Play()
					end)
				end
				local v70 = v_u_12:PlaySound(v_u_7.Itadori.FireArrow.Arrow, v66, game.SoundService.Effect)
				v70.PlaybackSpeed = 1.2
				v70.TimePosition = 0.7
				if v_u_4.Character == p65 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["Chat"] = function(p71)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_12, (ref) v_u_7, (ref) v_u_2
			local v72 = p71:FindFirstChild("Torso")
			if v72 then
				local v73 = v_u_6.Itadori.Dialogue:Clone()
				v73.Parent = v72
				local v74 = v73.Chat1.Position
				v73.Chat1.Position = v74 - UDim2.new(0, 0, 0.15, 0)
				v_u_3:Create(v73.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v74
				}):Play()
				v_u_3:Create(v73.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_3:Create(v73.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.4)
				v_u_12:PlaySound(v_u_7.Gojo.BlindsOff, v72, game.SoundService.Effect)
				task.wait(1.25)
				v_u_2:AddItem(v73, 0.6)
				for _, v75 in v73:GetDescendants() do
					if v75:IsA("Frame") then
						v_u_3:Create(v75, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = v75.Position - UDim2.new(0, 0, 0.2, 0),
							["BackgroundTransparency"] = 1
						}):Play()
					elseif v75:IsA("TextLabel") then
						v_u_3:Create(v75, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["Chat2"] = function(p76)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_12, (ref) v_u_7, (ref) v_u_2
			local v77 = p76:FindFirstChild("Torso")
			if v77 then
				local v78 = v_u_6.Itadori.Dialogue:Clone()
				v78.Chat1.Sub.Text = "IT\'S A BINDING VOW I MADE WITH THAT BRAT."
				v78.Parent = v77
				local v79 = v78.Chat1.Position
				v78.Chat1.Position = v79 - UDim2.new(0, 0, 0.15, 0)
				v_u_3:Create(v78.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v79
				}):Play()
				v_u_3:Create(v78.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_3:Create(v78.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.4)
				v_u_12:PlaySound(v_u_7.Gojo.BlindsOff, v77, game.SoundService.Effect)
				task.wait(1.25)
				v_u_2:AddItem(v78, 0.6)
				for _, v80 in v78:GetDescendants() do
					if v80:IsA("Frame") then
						v_u_3:Create(v80, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = v80.Position - UDim2.new(0, 0, 0.2, 0),
							["BackgroundTransparency"] = 1
						}):Play()
					elseif v80:IsA("TextLabel") then
						v_u_3:Create(v80, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["ThrowableWind"] = function(p81)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v82 = p81:FindFirstChild("HumanoidRootPart")
			if v82 then
				v_u_12:PlaySound(v_u_7.Yuta.PunchSwing, v82, game.SoundService.Effect)
			end
		end,
		["ThrowableHit"] = function(p83, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_8
			local v84 = p83:FindFirstChild("HumanoidRootPart")
			if v84 then
				v_u_12:PlaySound(v_u_7.Yuta.MetalHit, v84, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Hakari.Impact, v84, game.SoundService.Effect)
				local v85 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v85.CFrame = v84.CFrame * CFrame.new(2, 1, -5)
				v85.Parent = workspace.Effects
				v85.Wind:Emit(20)
				v85.PointLight:Destroy()
				v85.Back1.Back:Emit(1)
				v85.Back2.Back:Emit(1)
				v_u_3:Create(v85.Back1, TweenInfo.new(2), {
					["CFrame"] = v85.Back1.CFrame - v85.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_3:Create(v85.Back2, TweenInfo.new(2), {
					["CFrame"] = v85.Back2.CFrame - v85.Back2.CFrame.LookVector * 20
				}):Play()
				v_u_2:AddItem(v85, 3)
				local v86 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v86.Size = Vector3.new(6, 30, 6)
				v86.CFrame = v84.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v86.Parent = workspace.Effects
				v_u_2:AddItem(v86, 0.2)
				v_u_3:Create(v86, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = v86.Position + v84.CFrame.LookVector * 10
				}):Play()
				if (workspace.CurrentCamera.CFrame.Position - v84.Position).Magnitude < 150 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p88, ...)
		-- upvalues: (copy) v_u_87
		local v89 = v_u_87[p88]
		if v89 then
			v89(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p90, p91, p92)
		-- upvalues: (ref) v_u_11, (ref) v_u_3
		local v93 = p91.HumanoidRootPart
		if not v93 then
			return
		end
		local v94 = nil
		while true do
			local v95 = v_u_11:SphereHitbox(p91, CFrame.new(0, 0, -4), 8)
			for _, v96 in v95 do
				local v97 = v96:FindFirstChild("Info")
				if v97 then
					local v98 = v97:FindFirstChild("Knockback")
					if not v98 or v98.Value ~= false then
						v94 = v95
						break
					end
				end
			end
			if v94 then
				local v99 = p90:FindFirstChildWhichIsA("NumberValue")
				if v99 then
					v_u_3:Create(v99, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p90.Parent then
				break
			end
		end
		p92:FireServer(v94, v93.CFrame)
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("ItadoriService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13