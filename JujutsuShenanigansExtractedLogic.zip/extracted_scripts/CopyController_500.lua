-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local v_u_4 = v3.Utils
local v_u_5 = v3.Sounds
local v_u_6 = require(v3.Modules.CameraShaker)
require(v3.Modules.BloodyZee)
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "CopyController"
})
function v9.KnitStart(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_5, (copy) v_u_4, (copy) v_u_2, (copy) v_u_6
	local v_u_21 = {
		["Start"] = function(p10, _)
			-- upvalues: (ref) v_u_8, (ref) v_u_5
			local v11 = p10:FindFirstChild("HumanoidRootPart")
			if v11 then
				v_u_8:PlaySound(v_u_5.Yuta.CursedSpeechStart, v11, game.SoundService.Effect)
			end
		end,
		["MouthSpeech"] = function(p12)
			-- upvalues: (ref) v_u_4, (ref) v_u_2
			local v13 = v_u_4.Yuta.RikaHandTrail.CSVfx:Clone()
			v13.Parent = p12.Head
			v13.CursedSpeech:Emit(1)
			v13.L.Ring:Emit(2)
			v13.R.Ring:Emit(2)
			v13.M.Ring:Emit(2)
			v_u_2:AddItem(v13, 4)
		end,
		["MouthGlitch"] = function(p14)
			local v15 = p14.Head:FindFirstChild("CSVfx")
			if v15 then
				v15.M.Glitch:Emit(10)
			end
		end,
		["DontMove"] = function(p16)
			-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_2, (ref) v_u_8, (ref) v_u_5
			if (workspace.CurrentCamera.CFrame.Position - p16.Head.Position).Magnitude < 100 then
				v_u_6.CurrentShaker:Shake(v_u_6.Presets.HeavyHit)
			end
			local v17 = v_u_4.Misc.Items.Voice:Clone()
			local v18 = Instance.new("Model")
			v_u_2:AddItem(v18, 0.2)
			v17.Parent = v18
			v18:ScaleTo(1.8)
			v17.Anchored = false
			local v19 = Instance.new("Motor6D")
			v19.Parent = v17
			v19.Part0 = p16.Head
			v19.Part1 = v17
			v17.Parent = workspace.Effects
			v_u_2:AddItem(v17, 4)
			for _, v20 in v17:GetChildren() do
				if v20:IsA("ParticleEmitter") and v20.Name ~= "WindCircle" then
					v20.LockedToPart = true
					v20:Emit(v20:GetAttribute("EmitCount"))
				end
			end
			v_u_8:PlaySound(v_u_5.Misc.Items.Voice, p16.HumanoidRootPart, game.SoundService.Effect)
			v_u_8:PlaySound(v_u_5.Yuta.VoiceDontMove, p16.HumanoidRootPart, game.SoundService.Voice)
		end
	}
	CopyService.Effects:Connect(function(p22, ...)
		-- upvalues: (copy) v_u_21
		local v23 = v_u_21[p22]
		if v23 then
			v23(...)
		end
	end)
end
function v9.KnitInit(_)
	-- upvalues: (copy) v_u_1, (ref) v_u_7, (ref) v_u_8
	CopyService = v_u_1.GetService("CopyService")
	v_u_7 = v_u_1.GetController("HitboxController")
	v_u_8 = v_u_1.GetController("FXController")
end
return v9