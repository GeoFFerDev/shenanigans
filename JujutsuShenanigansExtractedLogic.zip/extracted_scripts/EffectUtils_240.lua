-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {}
local v_u_2 = game:GetService("TweenService")
local v_u_3 = workspace.Effects
local v_u_4 = RaycastParams.new()
v_u_4.FilterType = Enum.RaycastFilterType.Include
v_u_4.FilterDescendantsInstances = { workspace.Map }
function v_u_1.Debris(p_u_5, p6)
	task.delay(p6, function()
		-- upvalues: (copy) p_u_5
		local v7 = p_u_5
		if typeof(v7) == "Instance" and p_u_5.Destroy then
			p_u_5:Destroy()
		end
	end)
	return p_u_5
end
function v_u_1.Visibility(p8, p9, p10)
	-- upvalues: (copy) v_u_1
	for _, v11 in p8:GetDescendants() do
		if v11:IsA("BasePart") and not v11:GetAttribute("Invisible") then
			if p10 then
				v_u_1.Tween(v11, p10, "Sine", "InOut", {
					["Transparency"] = p9 and 0 or 1
				})
			else
				v11.Transparency = p9 and 0 or 1
			end
		elseif v11:IsA("ParticleEmitter") and not p9 then
			v11.Enabled = false
		end
	end
end
function v_u_1.EmitParticle(p12, p13)
	p12:Emit(p12:GetAttribute("EmitCount") or p12.Rate)
	if p13 < p12.Lifetime.Max then
		p13 = p12.Lifetime.Max or p13
	end
	return p13
end
function v_u_1.Emit(p_u_14, p15, p16)
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	if p15 then
		p_u_14 = p_u_14:Clone()
		if p_u_14:IsA("Attachment") then
			p_u_14.Parent = p15
		else
			if typeof(p15) == "CFrame" then
				if p_u_14:IsA("Model") then
					p_u_14:PivotTo(p15)
				else
					p_u_14.CFrame = p15
				end
			else
				if p_u_14:IsA("Model") then
					p_u_14 = p_u_14.PrimaryPart or p_u_14
				end
				local v17 = Instance.new("Weld")
				v17.Part0 = p15
				v17.Part1 = p_u_14
				v17.Parent = p_u_14
			end
			p_u_14.Parent = v_u_3
		end
	end
	local v_u_18 = 0
	for _, v_u_19 in p_u_14:GetDescendants() do
		if v_u_19:IsA("ParticleEmitter") then
			local v20 = v_u_19:GetAttribute("EmitDelay")
			if v20 and v20 ~= 0 then
				task.delay(v20, function()
					-- upvalues: (ref) p_u_14, (ref) v_u_18, (ref) v_u_1, (copy) v_u_19
					if p_u_14 then
						v_u_18 = v_u_1.EmitParticle(v_u_19, v_u_18)
					end
				end)
			else
				v_u_18 = v_u_1.EmitParticle(v_u_19, v_u_18)
			end
		end
	end
	task.delay(p16 or v_u_18, function()
		-- upvalues: (ref) p_u_14
		if p_u_14 then
			p_u_14:Destroy()
		end
	end)
	return p_u_14
end
function v_u_1.Enable(p21, p_u_22, p23, p24, p_u_25)
	-- upvalues: (copy) v_u_3
	if p23 then
		p_u_22 = p_u_22:Clone()
		if typeof(p23) == "CFrame" then
			p_u_22.CFrame = p23
			p_u_22.Parent = v_u_3
		elseif p_u_22:IsA("BasePart") then
			local v26 = Instance.new("Weld")
			v26.Part0 = p23
			v26.Part1 = p_u_22
			v26.Parent = p_u_22
			p_u_22.Parent = p23
		elseif p_u_22:IsA("Attachment") then
			p_u_22.Parent = p23
		end
	end
	local v_u_27 = {}
	local v_u_28 = 0
	for _, v29 in p_u_22:GetDescendants() do
		if (typeof(p21) ~= "string" or v29:IsA(p21)) and (typeof(p21) ~= "table" or table.find(p21, v29.ClassName)) then
			v29.Enabled = not p_u_25
			if p24 then
				if not v29:IsA("Beam") then
					local v30 = v29.Lifetime
					local v31 = typeof(v30) == "NumberRange" and v29.Lifetime.Max or v29.Lifetime
					v_u_28 = v_u_28 < v31 and v31 and v31 or v_u_28
				end
				table.insert(v_u_27, v29)
			end
		end
	end
	if p24 then
		task.delay(p24, function()
			-- upvalues: (copy) v_u_27, (copy) p_u_25, (ref) v_u_28, (ref) p_u_22
			for _, v32 in v_u_27 do
				v32.Enabled = p_u_25 and true or false
			end
			task.wait(v_u_28)
			if p_u_22 then
				p_u_22:Destroy()
			end
		end)
	end
	return p_u_22
end
function v_u_1.Mesh(p33, p34, p35)
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v36 = p33:Clone()
	v36.Parent = v_u_3
	if typeof(p34) == "CFrame" then
		v36.CFrame = p34
	elseif typeof(p34) == "Vector3" then
		v36.Position = p34
	else
		v36.Anchored = false
		local v37 = Instance.new("Weld")
		v37.Part0 = p34
		v37.Part1 = v36
		v37.Parent = v36
	end
	if p35 then
		v_u_1.Debris(v36, p35)
	end
	return v36
end
function v_u_1.Tween(p38, p39, p40, p41, p42)
	-- upvalues: (copy) v_u_2
	local v43 = v_u_2:Create(p38, TweenInfo.new(tonumber(p39), Enum.EasingStyle[p40], Enum.EasingDirection[p41]), p42)
	v43:Play()
	return v43
end
function v_u_1.AutoMeshes(p44, p45, _)
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v46 = p45.CFrame
	local v47 = p44.Start
	local v48 = p44.End
	local v49 = p44:GetAttribute("StartTransparency")
	local v50 = p44:GetAttribute("Distortion")
	local v51 = p44:GetAttribute("Duration")
	local v52 = p44:GetAttribute("Welded")
	local v53 = p44:GetAttribute("Part_TweenParams"):split(",")
	local v54 = v53[1]
	local v55 = v53[2]
	local v56 = v_u_1.Debris(v47:Clone(), v51)
	if v50 then
		local v57 = Instance.new("Highlight")
		v57.Enabled = false
		v57.Parent = v56
	end
	if v52 then
		local v58 = Instance.new("Weld")
		v58.Part0 = p45
		v58.Part1 = v56
		v58.C0 = v47.CFrame
		v58.Parent = v56
		v_u_1.Tween(v58, v51, v54, v55, {
			["C0"] = v48.CFrame
		})
	else
		v56.CFrame = v46 * v47.CFrame
	end
	local v59 = v56:IsA("Part")
	if v59 then
		local v60 = p44:GetAttribute("Mesh_TweenParams"):split(",")
		local v61 = v60[1]
		local v62 = v60[2]
		local v63 = p44:GetAttribute("Decal_TweenParams"):split(",")
		local v64 = v63[1]
		local v65 = v63[2]
		v56.Decal.Transparency = v49
		v_u_1.Tween(v56.Decal, v51, v64, v65, {
			["Transparency"] = tonumber(p44:GetAttribute("EndTransparency")) or 1
		})
		v_u_1.Tween(v56.Mesh, v51, v61, v62, {
			["Scale"] = v48.Mesh.Scale
		})
	else
		v56.Transparency = v49
	end
	local v66 = v_u_1.Tween
	local v67 = {}
	local v68
	if v52 then
		v68 = nil
	else
		v68 = v46 * v48.CFrame or nil
	end
	v67.CFrame = v68
	v67.Size = v48.Size
	v67.Transparency = v59 and 1 or (p44:GetAttribute("EndTransparency") or 1)
	v66(v56, v51, v54, v55, v67)
	v56.Parent = v_u_3
end
function v_u_1.AutoEmit(p69, p70)
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v71 = p69:GetAttribute("Parent")
	local v72 = p69:GetAttribute("Raycast")
	local v73
	if v71 then
		v73 = p70.Parent
		for _, v74 in v71:split(".") do
			if not v73 then
				return
			end
			v73 = v73:FindFirstChild(v74)
		end
	else
		v73 = p70
	end
	if v72 then
		local v75 = (p70.CFrame * p69.CFrame).Position
		local v76 = workspace:Raycast(v75, v72, v_u_4)
		if not v76 then
			return
		end
		local v77 = p69:GetAttribute("RaycastHitOffset") or Vector3.new(0, 0, 0)
		v73 = CFrame.new(v76.Position + v77) * (p70.CFrame - p70.Position)
	end
	v_u_1.Emit(p69, v73)
end
function v_u_1.AutoEnabled(p78, p79)
	-- upvalues: (copy) v_u_1
	local v80 = p78:GetAttribute("Parent")
	local v81 = p79.Parent
	if v80 then
		for _, v82 in v80:split(".") do
			if not v81 then
				return
			end
			v81 = v81:FindFirstChild(v82)
		end
	end
	if v81 then
		local v83 = tonumber(p78:GetAttribute("Time"))
		v_u_1.Enable({ "ParticleEmitter", "Trail", "Beam" }, p78, v81, v83)
	end
end
function v_u_1.AutoEffects(p84, p85)
	-- upvalues: (copy) v_u_1
	for _, v86 in p84:GetChildren() do
		if v_u_1[("Auto%*"):format(v86.Name)] then
			for _, v87 in v86:GetChildren() do
				v_u_1[("Auto%*"):format(v86.Name)](v87, p85)
			end
		end
	end
end
return v_u_1