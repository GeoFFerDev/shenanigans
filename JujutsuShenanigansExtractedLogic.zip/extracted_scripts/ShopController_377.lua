-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("TextChatService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Utils
local v_u_6 = v_u_5.Sounds
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = game:GetService("MarketplaceService")
local v10 = v_u_1.CreateController({
	["Name"] = "ShopController"
})
local v_u_11 = {
	[718947270] = "GamePass",
	[718699461] = "GamePass",
	[742180133] = "GamePass",
	[857428668] = "GamePass",
	[984868818] = "GamePass",
	[1151174294] = "GamePass"
}
local v_u_12 = {
	15691934088,
	15692322754,
	16379484942,
	16380012541,
	16938511900
}
local v_u_13 = {
	"Looking to buy something?",
	"Welcome to the shop!",
	"Hope you\'ll buy something this time.",
	"Check out the selection!",
	"What\'s up?",
	"Got something you\'re looking for?",
	"I\'ve got some stuff for you!",
	"It\'s time to spend!",
	"How\'s the portable shop service?",
	"Welcome!",
	"Hope you have fun shopping!",
	"Get me out of here.",
	"Buying something for someone? We have gifting options!",
	"hiiiii!!!!!!",
	"How are you?",
	"How\'s your day?",
	"feed me cash",
	"omg hiiiiii!!!",
	"Thinking about buying some emotes?",
	"Thinking about gifting gamepasses?"
}
local v_u_14 = {
	"ow",
	"yeow",
	"yeowch",
	"stop",
	"stop it",
	"that hurts"
}
function v10.KnitStart(_)
	-- upvalues: (copy) v_u_4, (ref) v_u_7, (ref) v_u_8, (copy) v_u_6, (copy) v_u_3, (copy) v_u_11, (copy) v_u_9, (copy) v_u_2, (copy) v_u_5, (copy) v_u_12, (copy) v_u_13, (copy) v_u_14
	local v_u_15 = v_u_4.PlayerGui:WaitForChild("Menus")
	local v_u_16 = v_u_15.Group.Shop
	v_u_16:SetAttribute("Loaded", true)
	local v_u_17 = v_u_15.Keeper
	local v_u_18 = v_u_17.Keeper
	v_u_7.Notification:Connect(function(p19, p20, p21)
		-- upvalues: (ref) v_u_8, (ref) v_u_6
		if p20 == 1 then
			v_u_8:PlaySound(v_u_6.Misc.UI.Purchase, workspace, game.SoundService.Effect)
			v_u_8:Notification(p19, Color3.fromRGB(255, 255, 0), p21)
			return
		elseif p20 == 2 then
			v_u_8:Notification(p19, Color3.fromRGB(255, 255, 255), p21)
		elseif p20 == 3 then
			v_u_8:PlaySound(v_u_6.Misc.UI.Announcement, workspace, game.SoundService.Effect)
			v_u_8:Notification(p19, Color3.fromRGB(255, 78, 119), p21)
		end
	end)
	v_u_7.Chat:Connect(function(p22)
		-- upvalues: (ref) v_u_3
		v_u_3.TextChannels.RBXGeneral:DisplaySystemMessage(p22)
	end)
	local function v_u_26(p23)
		-- upvalues: (copy) v_u_16, (ref) v_u_8, (ref) v_u_6
		for _, v24 in v_u_16.Categories:GetChildren() do
			if v24:IsA("TextButton") then
				v24.Select.Visible = v24 == p23
			end
		end
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		for _, v25 in v_u_16.Items:GetChildren() do
			v25.Visible = v25.Name == p23.Name
		end
		v_u_16.Gift.Visible = p23:GetAttribute("Gift") and true or false
	end
	local function v_u_31(p_u_27)
		-- upvalues: (copy) v_u_17, (copy) v_u_15, (copy) v_u_16, (copy) v_u_18
		if v_u_17:FindFirstChild("Chat") then
			v_u_17:FindFirstChild("Chat"):Destroy()
		end
		local v_u_28 = v_u_15.Preset.Chat:Clone()
		v_u_28.Parent = v_u_17
		task.spawn(function()
			-- upvalues: (copy) p_u_27, (copy) v_u_28, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18
			for v29 = 1, #p_u_27 do
				if not v_u_28.Parent then
					break
				end
				v_u_16.Talk:Play()
				local v30 = p_u_27
				v_u_17.Chat.Text = string.sub(v30, 0, v29)
				v_u_18.Head.Mouth.Transparency = v29 % 2
				task.wait(0.035)
			end
			if v_u_28.Parent then
				v_u_18.Head.Mouth.Transparency = 1
			end
		end)
		return v_u_28
	end
	for _, v_u_32 in v_u_16.Categories:GetChildren() do
		if v_u_32:IsA("TextButton") then
			v_u_32.MouseButton1Down:Connect(function()
				-- upvalues: (copy) v_u_26, (copy) v_u_32
				v_u_26(v_u_32)
			end)
		end
	end
	local v_u_33 = v_u_4.UserId
	local v_u_34 = nil
	for v_u_35, _ in v_u_11 do
		local v_u_36 = v_u_15.Preset.Gamepass:Clone()
		v_u_36.Parent = v_u_16.Items.Gamepass.Gamepasses
		task.spawn(function()
			-- upvalues: (ref) v_u_9, (copy) v_u_35, (copy) v_u_36
			local v37 = v_u_9:GetProductInfo(v_u_35, Enum.InfoType.GamePass)
			local v38 = v37.Name
			v_u_36.Gamepass.Text = v38
			v_u_36.Purchase.Robux.Text = "\238\128\130" .. (v37.PriceInRobux or "NIL")
			v_u_36.Description.Text = v37.Description or ""
			v_u_36.Name = v38
			v_u_36.Icon.Image = "rbxassetid://13600173502"
		end)
		v_u_36.Purchase.Robux.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_33, (ref) v_u_4, (ref) v_u_7, (copy) v_u_35, (copy) v_u_15, (copy) v_u_36, (ref) v_u_34
			v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
			if v_u_33 == nil then
				return
			elseif v_u_33 == v_u_4.UserId then
				v_u_7.Purchase:Fire(v_u_35, v_u_33)
			else
				v_u_15.Warning.Buttons.Robux.Text = v_u_36.Purchase.Robux.Text
				v_u_15.Warning.TextLabel.Text = ("You are <font color= \"rgb(240, 40, 10)\">buying a %s for another player</font> \nIf you would like to buy a %s for yourself, close the gifting menu and try again \nIf you would like to continue to purchase, press the purchase button below \n Otherwise, press the cancel button below"):format("gamepass", "gamepass")
				v_u_15.Warning.Visible = true
				v_u_34 = v_u_35
			end
		end)
	end
	v_u_15.Warning.Buttons.Robux.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (copy) v_u_15, (ref) v_u_7, (ref) v_u_34, (ref) v_u_33
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_15.Warning.Visible = false
		v_u_7.Purchase:Fire(v_u_34, v_u_33)
	end)
	v_u_15.Warning.Buttons.Cancel.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (copy) v_u_15
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_15.Warning.Visible = false
	end)
	local v_u_39 = v_u_16.Gift.Players
	local v_u_40 = v_u_16.Gift.For
	local v41 = v_u_16.Gift.Gift
	local function v_u_48(p_u_42, p43, p44)
		-- upvalues: (copy) v_u_15, (copy) v_u_39, (ref) v_u_33, (ref) v_u_8, (ref) v_u_6
		local v_u_45 = v_u_15.Preset.Player:Clone()
		v_u_45.Name = p_u_42
		v_u_45.Display.Text = p44 or p43
		v_u_45.Main.Text = "(@" .. p43 .. ")"
		v_u_45.Parent = v_u_39
		v_u_45.Select.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_33, (copy) p_u_42, (ref) v_u_8, (ref) v_u_6, (ref) v_u_39, (copy) v_u_45
			v_u_33 = p_u_42
			v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
			for _, v46 in v_u_39:GetChildren() do
				if v46:IsA("Frame") then
					if v46 == v_u_45 then
						v46.BackgroundTransparency = 0.5
					else
						v46.BackgroundTransparency = 1
					end
				end
			end
		end)
		task.spawn(function()
			-- upvalues: (copy) p_u_42, (copy) v_u_45
			local v47 = game.Players:GetUserThumbnailAsync(p_u_42, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size48x48)
			v_u_45.Icon.Image = v47
		end)
		return v_u_45
	end
	local v_u_49 = tick()
	local function v_u_60()
		-- upvalues: (copy) v_u_40, (ref) v_u_33, (copy) v_u_39, (ref) v_u_4, (copy) v_u_48, (ref) v_u_49
		local v_u_50 = v_u_40.Text
		v_u_33 = nil
		for _, v51 in v_u_39:GetChildren() do
			if v51:IsA("Frame") then
				if game.Players:GetPlayerByUserId(v51.Name) then
					v51.BackgroundTransparency = 1
				else
					v51:Destroy()
				end
			end
		end
		local v52 = #game.Players:GetChildren() - 1
		for _, v53 in game.Players:GetChildren() do
			if v53 ~= v_u_4 then
				local v54 = v_u_39:FindFirstChild(v53.UserId) or v_u_48(v53.UserId, v53.Name, v53.DisplayName)
				if v_u_50 ~= "" then
					local v55 = v53.Name
					local v56 = #v_u_50
					v54.Visible = string.sub(v55, 0, v56) == v_u_50
					if v54.Visible == false then
						v52 = v52 - 1
					end
				end
			end
		end
		if v52 == 0 and v_u_50 ~= "" then
			pcall(function()
				-- upvalues: (ref) v_u_49, (copy) v_u_50, (ref) v_u_4, (ref) v_u_48
				v_u_49 = tick()
				local v57 = v_u_49
				local v58 = game.Players:GetUserIdFromNameAsync(v_u_50)
				if v58 == v_u_4.UserId then
					return
				else
					local v59 = game:GetService("UserService"):GetUserInfosByUserIdsAsync({ v58 })
					if v_u_49 == v57 and v59 then
						v_u_48(v59[1].Id, v59[1].Username, v59[1].DisplayName)
					end
				end
			end)
		end
	end
	v_u_40:GetPropertyChangedSignal("Text"):Connect(v_u_60)
	local v_u_61 = false
	v_u_16.Items.Merch:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (ref) v_u_61, (copy) v_u_16, (ref) v_u_9, (copy) v_u_15, (ref) v_u_8, (ref) v_u_6, (ref) v_u_4
		if v_u_61 ~= true then
			v_u_61 = true
			local v62 = game.ReplicatedStorage.Remotes.ShopUGC:InvokeServer()
			v_u_16.Items.Merch.Loading.Visible = false
			for v_u_63, v_u_64 in v62 do
				task.delay(0.1 * v_u_63, function()
					-- upvalues: (ref) v_u_9, (copy) v_u_64, (ref) v_u_15, (copy) v_u_63, (ref) v_u_16, (ref) v_u_8, (ref) v_u_6, (ref) v_u_4
					local v65 = v_u_9:GetProductInfo(v_u_64, Enum.InfoType.Asset)
					local v66 = v_u_15.Preset.MerchItem:Clone()
					v66.LayoutOrder = v_u_63
					v66.Price.Text = "\238\128\130" .. v65.PriceInRobux
					if v_u_63 <= 2 then
						v66.BackgroundColor3 = Color3.fromRGB(170, 255, 255)
					end
					v66.Image = "rbxthumb://type=Asset&id=" .. v_u_64 .. "&w=150&h=150"
					v66.Parent = v_u_16.Items.Merch.Merch
					v66.MouseButton1Down:Connect(function()
						-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_9, (ref) v_u_4, (ref) v_u_64
						v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
						v_u_9:PromptPurchase(v_u_4, v_u_64)
					end)
				end)
			end
		end
	end)
	v_u_16.Items.Rewards.TextBox.Redeem.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (copy) v_u_16
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.Code:Fire(v_u_16.Items.Rewards.TextBox.Text)
		v_u_16.Items.Rewards.TextBox.Text = ""
	end)
	v41.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (copy) v_u_39, (copy) v_u_40, (ref) v_u_2, (copy) v_u_60, (ref) v_u_33, (ref) v_u_4
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		if v_u_39.Visible == false then
			v_u_39.Visible = true
			v_u_40.Visible = true
			v_u_39.Position = UDim2.new(0, -20, -0.5, 0)
			v_u_40.Position = UDim2.new(0, -20, -0.5, -10)
			v_u_2:Create(v_u_39, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["Position"] = UDim2.new(0, -20, 0, 0)
			}):Play()
			v_u_2:Create(v_u_40, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["Position"] = UDim2.new(0, -20, 0, -10)
			}):Play()
			v_u_8:PlaySound(v_u_6.Misc.UI.Wrap, workspace, game.SoundService.Effect)
			v_u_40.Text = ""
			v_u_60()
		else
			v_u_39.Visible = false
			v_u_40.Visible = false
			v_u_33 = v_u_4.UserId
		end
	end)
	local v_u_67 = v_u_16.Items.Shop.Shop.Emote.Right
	local v68 = v_u_16.Items.Shop.Shop.MVP
	local v69 = v_u_16.Items.Shop.Shop.Soda
	local v70 = v_u_16.Items.Shop.Shop.Item
	local v_u_71 = 1
	local v_u_72 = {
		1,
		2,
		5,
		10
	}
	local v_u_73 = 1
	v_u_67.Multiplier.Alt.Multiplier.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_71, (ref) v_u_73, (copy) v_u_72, (copy) v_u_67
		v_u_71 = v_u_71 + 1
		if v_u_71 > 4 then
			v_u_71 = 1
		end
		v_u_73 = v_u_72[v_u_71]
		v_u_67.Multiplier.Alt.Multiplier.Text = ("%dx"):format(v_u_73)
		v_u_67.Purchase.Robux.Text = ("\238\128\130%d"):format(v_u_73 * 25)
		v_u_67.Purchase.Cash.Text = ("$%d"):format(v_u_73 * 250)
	end)
	local v_u_74 = {
		[1758079520] = 1,
		[3415518126] = 2,
		[3415518509] = 5,
		[3415518615] = 10
	}
	v_u_67.Purchase.Robux.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_33, (ref) v_u_4, (ref) v_u_7, (ref) v_u_73, (copy) v_u_15, (ref) v_u_34, (copy) v_u_74
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		if v_u_33 == nil then
			return
		end
		if v_u_33 == v_u_4.UserId then
			v_u_7.PurchaseEmote:Fire(true, v_u_73)
			return
		end
		v_u_15.Warning.Buttons.Robux.Text = ("\238\128\130%d"):format(v_u_73 * 25)
		v_u_15.Warning.TextLabel.Text = ("You are <font color= \"rgb(240, 40, 10)\">buying a %s for another player</font> \nIf you would like to buy a %s for yourself, close the gifting menu and try again \nIf you would like to continue to purchase, press the purchase button below \n Otherwise, press the cancel button below"):format("product", "product")
		v_u_34 = 1758079520
		for v75, v76 in next, v_u_74 do
			if v76 == v_u_73 then
				v_u_34 = v75
				break
			end
		end
		v_u_15.Warning.Visible = true
	end)
	v_u_67.Purchase.Cash.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (ref) v_u_73
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.PurchaseEmote:Fire(false, v_u_73)
	end)
	v68.Purchase.Robux.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.PurchaseMVP:Fire(true)
	end)
	v68.Purchase.Cash.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.PurchaseMVP:Fire(false)
	end)
	v69.Purchase.Cash.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.PurchaseSoda:Fire()
	end)
	v70.Purchase.Cash.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
		v_u_8:PlaySound(v_u_6.Misc.UI.Click, workspace, game.SoundService.Effect)
		v_u_7.PurchaseItem:Fire()
	end)
	local v77 = v_u_5.Animations.Misc.ShopOpen
	local v_u_78 = {}
	for _, v79 in v_u_12 do
		v77.AnimationId = "rbxassetid://" .. v79
		local v80 = v_u_18.Humanoid:LoadAnimation(v77)
		table.insert(v_u_78, v80)
	end
	local v_u_81 = nil
	local v_u_82 = nil
	v_u_16:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_16, (copy) v_u_78, (ref) v_u_81, (copy) v_u_17, (ref) v_u_82, (copy) v_u_31, (ref) v_u_13, (copy) v_u_18, (ref) v_u_2, (copy) v_u_39, (copy) v_u_40, (ref) v_u_33, (ref) v_u_4
		if v_u_16.Visible == true then
			local v_u_83 = v_u_78[math.random(1, #v_u_78)]
			v_u_83:Play(0, nil, 1)
			v_u_81 = v_u_83:GetMarkerReachedSignal("Chat"):Connect(function()
				-- upvalues: (copy) v_u_83, (ref) v_u_17, (ref) v_u_82, (ref) v_u_31, (ref) v_u_13
				v_u_83:AdjustSpeed(0)
				v_u_17.Button.Visible = true
				v_u_82 = v_u_31(v_u_13[math.random(1, #v_u_13)])
			end)
			v_u_18.Head.Mouth.Transparency = 1
			v_u_17.Button.Visible = false
			v_u_17.ImageTransparency = 1
			v_u_17.Position = UDim2.new(0.75, 0, 0.675, 0)
			v_u_2:Create(v_u_17, TweenInfo.new(2, Enum.EasingStyle.Elastic), {
				["Position"] = UDim2.new(0.75, 0, 0.875, 0)
			}):Play()
			v_u_2:Create(v_u_17, TweenInfo.new(1, Enum.EasingStyle.Exponential), {
				["ImageTransparency"] = 0
			}):Play()
		else
			if v_u_81 then
				v_u_81:Disconnect()
				v_u_81 = nil
			end
			if v_u_82 then
				v_u_82:Destroy()
				v_u_82 = nil
			end
			for _, v84 in v_u_78 do
				v84:Stop(0)
			end
			v_u_2:Create(v_u_17, TweenInfo.new(0), {
				["ImageTransparency"] = 1
			}):Play()
			v_u_39.Visible = false
			v_u_40.Visible = false
			v_u_17.Button.Visible = false
			v_u_33 = v_u_4.UserId
		end
	end)
	v_u_17.Button.MouseButton1Down:Connect(function()
		-- upvalues: (copy) v_u_17, (ref) v_u_2, (ref) v_u_8, (ref) v_u_6, (ref) v_u_82, (copy) v_u_31, (ref) v_u_14
		v_u_17.Size = UDim2.new(0.275, 0, 0.55, 0)
		v_u_17.AnchorPoint = Vector2.new(0.5, 0.9)
		v_u_2:Create(v_u_17, TweenInfo.new(1, Enum.EasingStyle.Elastic), {
			["Size"] = UDim2.new(0.25, 0, 0.6, 0),
			["AnchorPoint"] = Vector2.new(0.5, 1)
		}):Play()
		v_u_8:PlaySound(v_u_6.Misc.UI.Squeak, workspace, game.SoundService.Effect)
		v_u_82 = v_u_31(v_u_14[math.random(1, #v_u_14)])
	end)
	local v85, v86 = pcall(function()
		-- upvalues: (ref) v_u_4
		return game:GetService("PolicyService"):GetPolicyInfoForPlayerAsync(v_u_4)
	end)
	if v85 and v86.ArePaidRandomItemsRestricted then
		v_u_67.Purchase.Robux.Visible = false
		v_u_67.Gift.Visible = false
		v68.Purchase.Robux.Visible = false
	end
end
function v10.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("ShopService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v10