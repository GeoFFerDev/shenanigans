-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("HttpService")
local v_u_2 = require("./Helper")
local v_u_3 = {
	["damage"] = 12,
	["spawnTime"] = 0.55,
	["telegraphTime"] = 0.18,
	["backOffset"] = 16,
	["throwSpeed"] = 1520,
	["backRotDeg"] = 50,
	["margin"] = 10,
	["indicatorTime"] = 0.75,
	["throwTTL"] = 1.6,
	["multiTTL"] = 1.6
}
local v4 = script.Parent.Assets.Sprites
local v_u_5 = v4.Indicator
local v_u_6 = v4.Knifes
local v_u_7 = Random.new()
local v_u_8 = {}
v_u_8.__index = v_u_8
v_u_8.Compute = {}
function v_u_8.new(p9, p_u_10, p11, p12, p13)
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_7, (copy) v_u_1, (copy) v_u_8, (copy) v_u_6, (copy) v_u_5
	local v14 = p13 or {}
	local v15 = v14.fromGui
	local v16 = v14.damage or v_u_3.damage
	local v17 = v14.spawnTime or v_u_3.spawnTime
	local v18 = v14.telegraphTime or v_u_3.telegraphTime
	local v19 = v14.backOffset or v_u_3.backOffset
	local v20 = v14.throwSpeed or v_u_3.throwSpeed
	local v21 = v14.backRotDeg or v_u_3.backRotDeg
	local v22 = v14.margin or v_u_3.margin
	local v23 = v14.spawnSide
	local v24 = v14.indicated or false
	local v25 = v14.indicatorTime or v_u_3.indicatorTime
	local v26 = v14.throwTTL or v_u_3.throwTTL
	local v27 = v14.multiTTL or v_u_3.multiTTL
	local v28 = p11.AbsoluteSize.X * 0.5
	local v29 = p11.AbsoluteSize.Y * 0.5
	local v_u_30 = v_u_2.resolveEffectFolders(p11)
	local v31
	if v15 and v14.targetPos then
		v31 = v_u_2.absToCenteredOffset(v_u_2.centerAbs(v15) + v14.targetPos, p11)
	elseif v14.targetPos then
		v31 = Vector2.new(v_u_2.roundpx(v14.targetPos.X), v_u_2.roundpx(v14.targetPos.Y))
	elseif v23 == "Left" or v23 == "Right" then
		local v32 = v29 * 0.5 - v22
		local v33 = math.max(0, v32)
		local v34 = Vector2.new(0, v_u_2.roundpx(v_u_7:NextNumber(-v33, v33)))
		v31 = v_u_2.snapV2ToGrid(v34, 16, 16, v_u_2.centerAbs(v15))
	elseif v23 == "Top" or v23 == "Bottom" then
		local v35 = v28 * 0.5 - v22
		local v36 = math.max(0, v35)
		local v37 = Vector2.new(v_u_2.roundpx(v_u_7:NextNumber(-v36, v36)), 0)
		v31 = v_u_2.snapV2ToGrid(v37, 16, 16, v_u_2.centerAbs(v15))
	else
		local v38 = v28 * 0.5 - v22
		local v39 = math.max(0, v38)
		local v40 = v29 * 0.5 - v22
		local v41 = math.max(0, v40)
		local v42 = Vector2.new(v_u_2.roundpx(v_u_7:NextNumber(-v39, v39)), v_u_2.roundpx(v_u_7:NextNumber(-v41, v41)))
		v31 = v_u_2.snapV2ToGrid(v42, 16, 16, v_u_2.centerAbs(v15))
	end
	local v43 = {
		["Signals"] = p9,
		["State"] = p_u_10,
		["Contents"] = p11,
		["Kind"] = p12,
		["Damage"] = v16,
		["SpawnTime"] = v17,
		["TeleTime"] = v18,
		["BackOffset"] = v19,
		["ThrowSpeed"] = v20,
		["BackRot"] = v21,
		["Margin"] = v22,
		["IndicatorTime"] = v25,
		["ThrowTTL"] = v26,
		["MultiTTL"] = v27,
		["Target"] = v31,
		["UUID"] = v_u_1:GenerateGUID(false),
		["_Alive"] = true,
		["Phase"] = v24 and "INDICATE" or "SPAWN",
		["KnifeGui"] = nil,
		["Atk"] = nil,
		["Indicator"] = nil,
		["Exclaim"] = nil,
		["TimeSec"] = 0,
		["PhaseSec"] = 0,
		["ThrowSec"] = 0,
		["parkPos"] = Vector2.zero,
		["startPos"] = Vector2.zero,
		["shootDir"] = Vector2.xAxis,
		["faceRot"] = 0,
		["startRot"] = 0,
		["Multi"] = {
			["Phase"] = "NONE",
			["PSec"] = 0,
			["Guis"] = {},
			["Dirs"] = {},
			["Start"] = {},
			["Park"] = {},
			["FromTH"] = {},
			["Pos"] = {},
			["RotS"] = {},
			["RotF"] = {},
			["Atk"] = {},
			["N"] = 0
		}
	}
	local v44 = v_u_8
	local v_u_45 = setmetatable(v43, v44)
	if v14.targetPos then
		local v46 = v_u_45.Target - Vector2.zero
		if v46.Magnitude < 1e-6 then
			v46 = Vector2.new(1, 0)
		end
		v_u_45.shootDir = v46.Unit
	elseif v23 == "Left" then
		v_u_45.shootDir = Vector2.new(1, 0)
	elseif v23 == "Right" then
		v_u_45.shootDir = Vector2.new(-1, 0)
	elseif v23 == "Top" then
		v_u_45.shootDir = Vector2.new(0, 1)
	elseif v23 == "Bottom" then
		v_u_45.shootDir = Vector2.new(0, -1)
	else
		local v47 = v_u_7:NextInteger(1, 4)
		v_u_45.shootDir = v47 == 1 and Vector2.new(1, 0) or v47 == 2 and Vector2.new(-1, 0) or (v47 == 3 and Vector2.new(0, 1) or Vector2.new(0, -1))
	end
	v_u_45.faceRot = v_u_2.dirToRotation(v_u_45.shootDir)
	v_u_45.startRot = v_u_45.faceRot - v_u_45.BackOffset
	local v48, v49 = v_u_2.parkAndStartForRay(v_u_45.Contents, v_u_45.Target, v_u_45.shootDir, v_u_45.Margin)
	v_u_45.parkPos = v48
	v_u_45.startPos = v49
	local v50 = v_u_6:FindFirstChild(p12)
	if not v50 then
		v_u_45._Alive = false
		return v_u_45
	end
	local v_u_51 = v50:Clone()
	v_u_51.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_51.Parent = v_u_30
	v_u_51.Position = UDim2.new(0.5, v_u_45.startPos.X, 0.5, v_u_45.startPos.Y)
	v_u_51.Rotation = v_u_45.startRot
	v_u_45.KnifeGui = v_u_51
	local v_u_52 = p_u_10.Attacks
	v_u_52[v_u_51] = {
		["Kind"] = "Knife",
		["Mode"] = p12,
		["Pos"] = v_u_45.startPos,
		["Dmg"] = 0,
		["Rot"] = v_u_45.startRot,
		["AbsSize"] = v_u_51.AbsoluteSize,
		["Destroy"] = function()
			-- upvalues: (copy) v_u_52, (copy) v_u_51
			if v_u_52[v_u_51] then
				v_u_52[v_u_51] = nil
			end
			if v_u_51 then
				v_u_51:Destroy()
			end
		end
	}
	v_u_45.Atk = v_u_52[v_u_51]
	if v_u_45.Phase == "INDICATE" then
		local v53 = v_u_5:Clone()
		v53.AnchorPoint = Vector2.new(0.5, 0.5)
		v53.Parent = v_u_45.Contents
		v53.Position = UDim2.new(0.5, v_u_2.roundpx(v_u_45.Target.X), 0.5, v_u_2.roundpx(v_u_45.Target.Y))
		v_u_45.Indicator = v53
		local v54 = v53:FindFirstChild("Exclamation")
		if v54 and v54:IsA("ImageLabel") then
			v_u_45.Exclaim = v54
			v_u_45.Exclaim.ImageTransparency = 0.25
		end
	end
	local function v_u_69()
		-- upvalues: (ref) v_u_2, (copy) v_u_45, (ref) v_u_6, (copy) v_u_30, (copy) p_u_10
		local v55, v56, v57 = v_u_2.sharedIndicatorRadii(v_u_45.Contents, v_u_45.Target, v_u_45.Margin, v_u_45.BackOffset)
		v_u_45.Multi.N = 0
		v_u_45.Multi.Phase = "SPAWN"
		v_u_45.Multi.PSec = 0
		for v58 = 1, 4 do
			local v59 = v55[v58]
			local _, v60 = v_u_2.parkAndStartForRay(v_u_45.Contents, v_u_45.Target, v59, v_u_45.Margin)
			local v61 = v_u_45.Target - v59 * v57
			local v62 = v_u_2.dirToRotation(v59)
			local v63 = v62 - v_u_45.BackOffset
			local v64 = v_u_6:FindFirstChild(v_u_45.Kind)
			if v64 then
				local v_u_65 = v64:Clone()
				v_u_65.AnchorPoint = Vector2.new(0.5, 0.5)
				v_u_65.Parent = v_u_30
				v_u_65.Position = UDim2.new(0.5, v_u_2.roundpx(v60.X), 0.5, v_u_2.roundpx(v60.Y))
				v_u_65.Rotation = v63
				local v66 = v_u_45.Multi
				v66.N = v66.N + 1
				local v67 = v_u_45.Multi.N
				v_u_45.Multi.Guis[v67] = v_u_65
				v_u_45.Multi.Dirs[v67] = v59
				v_u_45.Multi.Start[v67] = v60
				v_u_45.Multi.Park[v67] = v_u_45.Target - v59 * v56
				v_u_45.Multi.FromTH[v67] = v61
				v_u_45.Multi.Pos[v67] = v60
				v_u_45.Multi.RotS[v67] = v63
				v_u_45.Multi.RotF[v67] = v62
				local v68 = {
					["Kind"] = "Knife",
					["Mode"] = v_u_45.Kind,
					["Pos"] = v60,
					["Dmg"] = 0,
					["Rot"] = v63,
					["AbsSize"] = v_u_65.AbsoluteSize,
					["Destroy"] = function()
						-- upvalues: (ref) p_u_10, (copy) v_u_65
						if p_u_10.Attacks[v_u_65] then
							p_u_10.Attacks[v_u_65] = nil
						end
						if v_u_65 then
							v_u_65:Destroy()
						end
					end
				}
				p_u_10.Attacks[v_u_65] = v68
				v_u_45.Multi.Atk[v67] = v68
			end
		end
	end
	v_u_8.Compute[v_u_45.UUID] = function(p70)
		-- upvalues: (copy) v_u_45, (ref) v_u_2, (copy) v_u_69
		if v_u_45._Alive then
			if not v_u_45._once then
				v_u_45._c0 = Color3.fromRGB(255, 234, 0)
				v_u_45._c1 = Color3.fromRGB(255, 64, 64)
				v_u_45._once = true
			end
			local v71 = v_u_2.toSec(p70)
			local v72 = v_u_2.unitScale(v_u_45.Contents, v_u_45.State.Arena.BaselineMin)
			local v73 = v_u_45
			v73.TimeSec = v73.TimeSec + v71
			local v74 = v_u_45
			v74.PhaseSec = v74.PhaseSec + v71
			if v_u_45.Multi and v_u_45.Multi.Phase ~= "NONE" then
				local v75 = v_u_45.Multi
				v75.PSec = v75.PSec + v71
				local v76 = v75.Guis
				local v77 = v75.Atk
				local v78 = v75.Pos
				local v79 = v75.Start
				local v80 = v75.Park
				local v81 = v75.RotS
				local v82 = v75.RotF
				local v83 = v75.Dirs
				local v84 = v75.FromTH
				if v75.Phase == "SPAWN" then
					if not v_u_45.Sounded then
						v_u_45.Signals.spawnSound:Fire("Knife Throw")
						v_u_45.Sounded = true
					end
					local v85 = v75.PSec / v_u_45.SpawnTime
					local v86 = math.clamp(v85, 0, 1)
					local v87 = v_u_2.easeOutCubic(v86)
					for v88 = 1, v75.N do
						local v89 = v79[v88]
						local v90 = v80[v88]
						local v91 = v81[v88] + (v82[v88] - v81[v88]) * v87
						local v92 = v89.X + (v90.X - v89.X) * v87
						local v93 = v89.Y + (v90.Y - v89.Y) * v87
						local v94 = Vector2.new(v92, v93)
						v78[v88] = v94
						local v95 = v76[v88]
						if v95 then
							v95.Position = UDim2.new(0.5, v_u_2.roundpx(v92), 0.5, v_u_2.roundpx(v93))
							v95.Rotation = v91
						end
						local v96 = v77[v88]
						if v96 then
							if v_u_2.setRotAndCacheAabb then
								v_u_2.setRotAndCacheAabb(v96, v91)
							else
								v96.Rot = v91
							end
							v96.Pos = v94
							v96.Dmg = 0
						end
					end
					if v86 >= 1 then
						v75.Phase = "TELEGRAPH"
						v75.PSec = 0
						for v97 = 1, v75.N do
							local v98 = v76[v97]
							if v98 then
								v98.Rotation = v82[v97]
							end
							local v99 = v77[v97]
							if v99 then
								if v_u_2.setRotAndCacheAabb then
									v_u_2.setRotAndCacheAabb(v99, v82[v97])
								else
									v99.Rot = v82[v97]
								end
							end
						end
					end
					return
				end
				if v75.Phase == "TELEGRAPH" then
					local v100 = v75.PSec / v_u_45.TeleTime
					local v101 = math.clamp(v100, 0, 1)
					local v102 = v_u_45.BackOffset * v_u_2.easeOutCubic(v101)
					for v103 = 1, v75.N do
						local v104 = v80[v103] - v83[v103] * v102
						v78[v103] = v104
						local v105 = v76[v103]
						if v105 then
							v105.Position = UDim2.new(0.5, v_u_2.roundpx(v104.X), 0.5, v_u_2.roundpx(v104.Y))
						end
						local v106 = v77[v103]
						if v106 then
							v106.Pos = v104
							v106.Dmg = 0
						end
					end
					if v101 >= 1 then
						v75.Phase = "THROW"
						v75.PSec = 0
						for v107 = 1, v75.N do
							v78[v107] = v84[v107]
						end
					end
					return
				end
				if v75.Phase == "THROW" then
					local v108 = v_u_45.ThrowSpeed * v72 * v71
					for v109 = 1, v75.N do
						local v110 = v78[v109] + v83[v109] * v108
						v78[v109] = v110
						local v111 = v76[v109]
						if v111 then
							v111.Position = UDim2.new(0.5, v_u_2.roundpx(v110.X), 0.5, v_u_2.roundpx(v110.Y))
						end
						local v112 = v77[v109]
						if v112 then
							v112.Pos = v110
							v112.Dmg = v_u_45.Damage
						end
					end
					if v75.PSec >= v_u_45.MultiTTL then
						v_u_45:Destroy()
					end
					return
				end
			end
			if v_u_45.Phase == "INDICATE" then
				if v_u_45.Indicator then
					local v113 = v_u_45.PhaseSec / v_u_45.IndicatorTime
					local v114 = math.clamp(v113, 0, 1)
					v_u_45.Indicator.ImageColor3 = v_u_45._c0:Lerp(v_u_45._c1, v114)
					if v_u_45.Exclaim then
						v_u_45.Exclaim.ImageColor3 = v_u_45.Indicator.ImageColor3
						local v115 = 6.283185307179586 * (v_u_45.TimeSec * 3)
						local v116 = 0.5 - math.cos(v115) * 0.5
						v_u_45.Exclaim.ImageTransparency = v116 * 0.75 + 0.25
					end
				end
				if v_u_45.PhaseSec >= v_u_45.IndicatorTime then
					if v_u_45.Indicator then
						v_u_45.Indicator:Destroy()
						v_u_45.Indicator = nil
						v_u_45.Exclaim = nil
					end
					v_u_45.PhaseSec = 0
					v_u_69()
					v_u_45.Phase = "MULTI"
					if v_u_45.KnifeGui then
						v_u_45.KnifeGui.Visible = false
					end
				end
				return
			elseif v_u_45.Phase == "SPAWN" then
				if not v_u_45.Sound then
					v_u_45.Signals.spawnSound:Fire("Knife Throw")
					v_u_45.Sound = true
				end
				local v117 = v_u_45.PhaseSec / v_u_45.SpawnTime
				local v118 = math.clamp(v117, 0, 1)
				local v119 = v_u_2.easeOutCubic(v118)
				local v120 = v_u_45.startPos.X + (v_u_45.parkPos.X - v_u_45.startPos.X) * v119
				local v121 = v_u_45.startPos.Y + (v_u_45.parkPos.Y - v_u_45.startPos.Y) * v119
				local v122 = v_u_45.startRot + (v_u_45.faceRot - v_u_45.startRot) * v119
				v_u_45.KnifeGui.Position = UDim2.new(0.5, v_u_2.roundpx(v120), 0.5, v_u_2.roundpx(v121))
				v_u_45.KnifeGui.Rotation = v122
				if v_u_2.setRotAndCacheAabb then
					v_u_2.setRotAndCacheAabb(v_u_45.Atk, v122)
				else
					v_u_45.Atk.Rot = v122
				end
				v_u_45.Atk.Pos = Vector2.new(v120, v121)
				v_u_45.Atk.Dmg = 0
				if v118 >= 1 then
					v_u_45.Phase = "TELEGRAPH"
					v_u_45.PhaseSec = 0
					if v_u_45.KnifeGui then
						v_u_45.KnifeGui.Rotation = v_u_45.faceRot
					end
					if v_u_2.setRotAndCacheAabb then
						v_u_2.setRotAndCacheAabb(v_u_45.Atk, v_u_45.faceRot)
						return
					end
					v_u_45.Atk.Rot = v_u_45.faceRot
				end
				return
			elseif v_u_45.Phase == "TELEGRAPH" then
				local v123 = v_u_45.PhaseSec / v_u_45.TeleTime
				local v124 = math.clamp(v123, 0, 1)
				local v125 = v_u_45.BackOffset * v_u_2.easeOutCubic(v124)
				local v126 = v_u_45.parkPos - v_u_45.shootDir * v125
				v_u_45.KnifeGui.Position = UDim2.new(0.5, v_u_2.roundpx(v126.X), 0.5, v_u_2.roundpx(v126.Y))
				v_u_45.Atk.Pos = v126
				v_u_45.Atk.Dmg = 0
				if v124 >= 1 then
					v_u_45.Phase = "THROW"
					v_u_45.PhaseSec = 0
					v_u_45.ThrowSec = 0
					if v_u_45.KnifeGui then
						v_u_45.KnifeGui.Rotation = v_u_45.faceRot
					end
				end
				return
			elseif v_u_45.Phase == "THROW" then
				local v127 = v_u_45
				v127.ThrowSec = v127.ThrowSec + v71
				local v128 = v_u_45.ThrowSpeed * v72 * v71
				local v129 = v_u_45.Atk.Pos + v_u_45.shootDir * v128
				v_u_45.KnifeGui.Position = UDim2.new(0.5, v_u_2.roundpx(v129.X), 0.5, v_u_2.roundpx(v129.Y))
				v_u_45.Atk.Pos = v129
				v_u_45.Atk.Dmg = v_u_45.Damage
				if v_u_45.ThrowSec >= v_u_45.ThrowTTL then
					v_u_45:Destroy()
				end
			end
		else
			return
		end
	end
	return v_u_45
end
function v_u_8.Destroy(p130)
	-- upvalues: (copy) v_u_8
	if p130._Alive then
		p130._Alive = false
		if p130.UUID and v_u_8.Compute[p130.UUID] then
			v_u_8.Compute[p130.UUID] = nil
		end
		local v131 = p130.State
		if v131 then
			v131 = p130.State.Attacks
		end
		if p130.Atk and v131 then
			v131[p130.KnifeGui] = nil
		end
		if p130.KnifeGui then
			p130.KnifeGui:Destroy()
		end
		if p130.Indicator then
			p130.Indicator:Destroy()
		end
		for v132 = 1, p130.Multi.N do
			local v133 = p130.Multi.Guis[v132]
			if v131 and (v133 and v131[v133]) then
				v131[v133] = nil
			end
			if v133 then
				v133:Destroy()
			end
		end
		table.clear(p130)
		setmetatable(p130, nil)
	end
end
function v_u_8.Step(p134)
	-- upvalues: (copy) v_u_8
	for _, v135 in pairs(v_u_8.Compute) do
		v135(p134)
	end
end
return v_u_8