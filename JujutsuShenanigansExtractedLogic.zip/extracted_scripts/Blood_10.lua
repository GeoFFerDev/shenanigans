-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = RaycastParams.new()
v_u_1.FilterType = Enum.RaycastFilterType.Include
v_u_1.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_2 = CFrame.Angles(-1.5707963267948966, 0, 0)
script:GetActor():BindToMessageParallel("Ray", function(p3)
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	if p3.Parent then
		local v4 = p3:GetAttribute("RT")
		local v5 = p3.CFrame
		local v6 = v5.UpVector
		local v7 = workspace:Raycast(v5.Position + v6, -v6 * 3, v_u_1)
		local v8
		if v7 then
			local v9 = CFrame.lookAlong(v7.Position + v7.Normal * 0.1, v7.Normal) * v_u_2 * CFrame.Angles(0, v4, 0)
			v8 = { v7.Instance.CFrame:ToObjectSpace(v9), v7.Instance }
		else
			v8 = true
		end
		if v8 == true then
			task.synchronize()
			p3:Destroy()
		elseif v8 ~= nil then
			task.synchronize()
			p3:SetAttribute("CF", v8[1])
			p3.Ref.Value = v8[2]
			p3.CFrame = v8[2].CFrame:ToWorldSpace(v8[1])
			p3.Locked = false
		end
	else
		return
	end
end)