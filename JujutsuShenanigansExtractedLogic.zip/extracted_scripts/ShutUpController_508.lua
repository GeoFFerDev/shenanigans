-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "ShutUpController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_38 = {
		["Startup"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_7.Charles.ShutUp.Swing, v13, game.SoundService.Effect)
			end
		end,
		["Throw"] = function(p14)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = v_u_6.Todo.Swing:Clone()
				v16.Weld.Part0 = v15
				v16.Parent = workspace.Effects
				v_u_2:AddItem(v16, 0.6)
				v16.Core.Wind:Emit(12)
				v_u_3:Create(v16.Weld, TweenInfo.new(0.4), {
					["C1"] = v16.Weld.C1 * CFrame.Angles(0, -3.141592653589793, 0)
				}):Play()
				v_u_3:Create(v16.Beam, TweenInfo.new(0.4), {
					["Width0"] = 0
				}):Play()
			end
		end,
		["Swing"] = function(p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_6.Charles.StabWind:Clone()
				v19:PivotTo(v18.CFrame * CFrame.new(1, 1, 4) * CFrame.Angles(0, 2.792526803190927, 0))
				v19.Parent = workspace.Effects
				v_u_2:AddItem(v19, 0.3)
				v_u_3:Create(v19.Shock, TweenInfo.new(0.15), {
					["Size"] = Vector3.new(0, 25, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:Create(v19.Shock2, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1,
					["Position"] = v19.Shock2.Position + v18.CFrame.LookVector * 8
				}):Play()
			end
		end,
		["Hit"] = function(p20)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_10:Flash(p20, Color3.new(1, 1, 1), 1)
				v_u_10:PlaySound(v_u_7.Charles.ShutUp.Stab, v21, game.SoundService.Effect)
				task.wait(0.7)
				v_u_10:PlaySound(v_u_7.Charles.ShutUp.Throw, v21, game.SoundService.Effect)
			end
		end,
		["Hit1"] = function(p22, p23)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				v_u_10:Flash(p23, Color3.new(1, 1, 1), 0.5)
				v_u_10:PlaySound(v_u_7.Charles.ShutUp.Hit, v24, game.SoundService.Effect)
				if v_u_4 == p22 or v_u_4.Character == p23 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Hit2"] = function(p25, p26)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v27 = p26:FindFirstChild("HumanoidRootPart")
			if v27 then
				v_u_10:Flash(p26, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Charles.ShutUp.Hit2, v27, game.SoundService.Effect)
				if v_u_4 == p25 or v_u_4.Character == p26 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Jump"] = function(p28)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = v_u_6.Gojo.Twofold:Clone()
				v30.Size = Vector3.new(24, 0, 24)
				v30.CFrame = v29.CFrame * CFrame.new(0, -6, -1) * CFrame.Angles(0, 0, 0)
				v30.Transparency = 0.5
				v30.Parent = workspace.Effects
				v30.Swing2.Swing1:Emit(10)
				v_u_3:Create(v30, TweenInfo.new(0.3, Enum.EasingStyle.Exponential), {
					["CFrame"] = v30.CFrame + v30.CFrame.UpVector * 5,
					["Size"] = Vector3.new(0, 15, 0)
				}):Play()
				v_u_2:AddItem(v30, 0.4)
				v_u_10:PlaySound(v_u_7.Misc.Swing.Fist3, v29, game.SoundService.Effect)
			end
		end,
		["Crush"] = function(p31, p32)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v33 = v_u_6.Hiromi.Shockwave:Clone()
			v33.Position = p32
			v33.Parent = workspace.Effects
			local v34 = v33.CFrame
			local v35 = CFrame.Angles
			local v36 = math.random(-179, 179)
			v33.CFrame = v34 * v35(0, math.rad(v36), 0)
			v_u_3:Create(v33.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(15, 0, 15)
			}):Play()
			v_u_3:Create(v33.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v33.Floor.Glow:Emit(1)
			v33.Floor.Ring:Emit(10)
			v_u_2:AddItem(v33, 1.5)
			local v37 = v_u_6.Choso.CounterSwing.Shock:Clone()
			v37.Size = Vector3.new(6, 30, 6)
			v37.CFrame = CFrame.new(p32 + Vector3.new(0, 5, 0)) * CFrame.Angles(0, 0, 0)
			v37.Parent = workspace.Effects
			v_u_2:AddItem(v37, 0.2)
			v_u_3:Create(v37, TweenInfo.new(0.2), {
				["Size"] = Vector3.new(25, 0, 25),
				["Transparency"] = 1,
				["Position"] = v37.Position - Vector3.new(0, 10, 0)
			}):Play()
			v_u_10:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v33, game.SoundService.Effect)
			if v_u_4 == p31 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end
	}
	v_u_9.Effects:Connect(function(p39, ...)
		-- upvalues: (copy) v_u_38
		local v40 = v_u_38[p39]
		if v40 then
			v40(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("ShutUpService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11