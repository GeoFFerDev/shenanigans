-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "PebbleThrowController"
})
function v12.KnitStart(_)
	-- upvalues: (copy) v_u_2, (ref) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_26 = {
		["Interp"] = function(p13, p_u_14)
			-- upvalues: (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v_u_16 = p_u_14.CFrame
				local v_u_17 = tick()
				local v_u_18 = p_u_14:GetPropertyChangedSignal("Position"):Connect(function()
					-- upvalues: (ref) v_u_16, (copy) p_u_14, (ref) v_u_17
					v_u_16 = p_u_14.CFrame
					v_u_17 = tick()
				end)
				local v_u_19 = nil
				v_u_19 = v_u_2.Stepped:Connect(function()
					-- upvalues: (copy) p_u_14, (ref) v_u_19, (copy) v_u_18, (ref) v_u_16, (ref) v_u_17
					if p_u_14.Position and p_u_14.Anchored ~= false then
						workspace:BulkMoveTo({ p_u_14 }, { v_u_16 + v_u_16.LookVector * (130 * (tick() - v_u_17)) }, Enum.BulkMoveMode.FireCFrameChanged)
					else
						v_u_19:Disconnect()
						v_u_18:Disconnect()
					end
				end)
				v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Throw, v15, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Mahito.WideSPStrike.Crush, v15, game.SoundService.Effect)
				local v20 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v20.Position = v15.Position + v15.CFrame.LookVector * 5.5
				v20.Parent = workspace.Effects
				v_u_3:AddItem(v20, 1)
				v20.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v20.Wind.Color = v20.Sparks.Color
				v20.Wind2.Color = v20.Sparks.Color
				v20.Sparks:Emit(20)
				v20.Wind:Emit(7)
				v20.Wind2:Emit(7)
				if v_u_4.Character == p13 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Stomp"] = function(p21, p22)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v23 = p21:FindFirstChild("HumanoidRootPart")
			if v23 then
				v_u_11:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v23, game.SoundService.Effect)
				v_u_11:DustBreak(p22 + Vector3.new(0, 1, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
				if v_u_4:DistanceFromCharacter(v23.Position) < 20 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["Hit"] = function(p24)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				v_u_11:Flash(p24, Color3.new(0.333333, 0.666667, 1))
				v_u_11:PlaySound(v_u_7.Itadori.DivergentFist.DivergentHit, v25, game.SoundService.Effect)
			end
		end
	}
	v_u_9.Effects:Connect(function(p27, ...)
		-- upvalues: (copy) v_u_26
		local v28 = v_u_26[p27]
		if v28 then
			v28(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("PebbleThrowService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12