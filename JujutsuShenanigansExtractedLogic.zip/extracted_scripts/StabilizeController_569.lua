-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v10 = RaycastParams.new()
v10.FilterType = Enum.RaycastFilterType.Include
v10.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "StabilizeController"
})
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_11
	local v_u_33 = {
		["Start"] = function(p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:PlaySound(v_u_7.Nanami.Stabilize.Start, v16, game.SoundService.Effect)
			end
		end,
		["Whoosh"] = function(p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_6.Choso.CounterSwing:Clone()
				v19:PivotTo(v18.CFrame * CFrame.new(0, 0, -6))
				v19.Parent = workspace.Effects
				v19.Shockwave:Destroy()
				v_u_2:AddItem(v19, 0.3)
				v19.Shock.Size = Vector3.new(10, 2, 10)
				v_u_3:Create(v19.Shock, TweenInfo.new(0.15), {
					["Size"] = Vector3.new(2, 15, 2),
					["Transparency"] = 1,
					["Position"] = v19.Shock2.Position + v18.CFrame.LookVector * 3
				}):Play()
				v_u_3:Create(v19.Shock2, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1,
					["Position"] = v19.Shock2.Position + v18.CFrame.LookVector * 3
				}):Play()
			end
		end,
		["Hit"] = function(p20, p21, p22)
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2, (ref) v_u_9, (ref) v_u_12, (ref) v_u_7
			local v23 = p20:FindFirstChild("HumanoidRootPart")
			if v23 then
				local v24 = p21:FindFirstChild("HumanoidRootPart")
				if v24 then
					if v_u_4.Character == p20 or v_u_4.Character == p21 then
						v_u_8.CurrentShaker:Shake(p22 and v_u_8.Presets.HeavyHit or v_u_8.Presets.LightHit)
					end
					local v25 = v_u_6.Nanami.HitFX:Clone()
					local v26 = Instance.new("Model")
					v25.Parent = v26
					v26:ScaleTo(1.5)
					v_u_2:AddItem(v26, 0.1)
					v25.Parent = workspace.Effects
					v25.CFrame = CFrame.new(v24.Position.X, v23.Position.Y, v24.Position.Z)
					v_u_2:AddItem(v25, 2)
					for _, v27 in pairs(v25:GetDescendants()) do
						if v27:IsA("ParticleEmitter") then
							v27:Emit(v27:GetAttribute("EmitCount"))
							if p22 then
								v27.TimeScale = 0.35
							end
						end
					end
					if p22 then
						for _ = 1, 20 do
							v_u_9:Blood(p21.Head.CFrame, math.random(5, 60), 20, 20)
						end
					end
					v_u_12:Flash(p21, Color3.new(1, 1, 1))
					v_u_12:PlaySound(p22 and v_u_7.Nanami.CrossCut.RatioHit or v_u_7.Nanami.CrossCut.Hit2, v24, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Spin"] = function(p28, p29, p30)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v31 = p28:FindFirstChild("HumanoidRootPart")
			if v31 then
				local v_u_32 = v_u_12:PlaySound(p30 and v_u_7.Nanami.Stabilize.Spin or v_u_7.Nanami.Stabilize.SpinShort, v31, game.SoundService.Effect)
				p29.AncestryChanged:Once(function()
					-- upvalues: (copy) v_u_32
					v_u_32:Destroy()
				end)
			end
		end
	}
	v_u_11.Effects:Connect(function(p34, ...)
		-- upvalues: (copy) v_u_33
		local v35 = v_u_33[p34]
		if v35 then
			v35(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_13, (ref) v_u_12
	v_u_11 = v_u_1.GetService("StabilizeService")
	v_u_13 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v14