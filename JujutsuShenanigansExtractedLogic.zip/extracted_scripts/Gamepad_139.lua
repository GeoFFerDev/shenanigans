-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(script.Parent.Parent.Trove)
local v_u_2 = require(script.Parent.Parent.Signal)
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("HapticService")
local v_u_5 = game:GetService("GuiService")
local v_u_6 = game:GetService("RunService")
local function v_u_12()
	-- upvalues: (copy) v_u_3
	local v7 = nil
	local v8 = v_u_3:GetNavigationGamepads()
	if #v8 > 1 then
		for _, v9 in ipairs(v8) do
			if v7 == nil or v9.Value < v7.Value then
				v7 = v9
			end
		end
	else
		local v10 = v_u_3:GetConnectedGamepads()
		for _, v11 in ipairs(v10) do
			if v7 == nil or v11.Value < v7.Value then
				v7 = v11
			end
		end
	end
	if v7 and not v_u_3:GetGamepadConnected(v7) then
		v7 = nil
	end
	return v7
end
local v_u_13 = {}
v_u_13.__index = v_u_13
function v_u_13.new(p14)
	-- upvalues: (copy) v_u_13, (copy) v_u_1, (copy) v_u_2
	local v15 = v_u_13
	local v16 = setmetatable({}, v15)
	v16._trove = v_u_1.new()
	v16._gamepadTrove = v16._trove:Construct(v_u_1)
	v16.ButtonDown = v16._trove:Construct(v_u_2)
	v16.ButtonUp = v16._trove:Construct(v_u_2)
	v16.Connected = v16._trove:Construct(v_u_2)
	v16.Disconnected = v16._trove:Construct(v_u_2)
	v16.GamepadChanged = v16._trove:Construct(v_u_2)
	v16.DefaultDeadzone = 0.05
	v16.SupportsVibration = false
	v16.State = {}
	v16:_setupGamepad(p14)
	v16:_setupMotors()
	return v16
end
function v_u_13._setupActiveGamepad(p_u_17, p_u_18)
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v19 = p_u_17._gamepad
	if p_u_18 == v19 then
		return
	else
		p_u_17._gamepadTrove:Clean()
		table.clear(p_u_17.State)
		local v20
		if p_u_18 then
			v20 = v_u_4:IsVibrationSupported(p_u_18)
		else
			v20 = false
		end
		p_u_17.SupportsVibration = v20
		p_u_17._gamepad = p_u_18
		if p_u_18 then
			for _, v21 in ipairs(v_u_3:GetGamepadState(p_u_18)) do
				p_u_17.State[v21.KeyCode] = v21
			end
			p_u_17._gamepadTrove:Add(p_u_17, "StopMotors")
			p_u_17._gamepadTrove:Connect(v_u_3.InputBegan, function(p22, p23)
				-- upvalues: (copy) p_u_18, (copy) p_u_17
				if p22.UserInputType == p_u_18 then
					p_u_17.ButtonDown:Fire(p22.KeyCode, p23)
				end
			end)
			p_u_17._gamepadTrove:Connect(v_u_3.InputEnded, function(p24, p25)
				-- upvalues: (copy) p_u_18, (copy) p_u_17
				if p24.UserInputType == p_u_18 then
					p_u_17.ButtonUp:Fire(p24.KeyCode, p25)
				end
			end)
			if v19 == nil then
				p_u_17.Connected:Fire()
			end
			p_u_17.GamepadChanged:Fire(p_u_18)
		else
			p_u_17.Disconnected:Fire()
			p_u_17.GamepadChanged:Fire(nil)
		end
	end
end
function v_u_13._setupGamepad(p_u_26, p_u_27)
	-- upvalues: (copy) v_u_3, (copy) v_u_12
	if p_u_27 then
		p_u_26._trove:Connect(v_u_3.GamepadConnected, function(p28)
			-- upvalues: (copy) p_u_27, (copy) p_u_26
			if p28 == p_u_27 then
				p_u_26:_setupActiveGamepad(p_u_27)
			end
		end)
		p_u_26._trove:Connect(v_u_3.GamepadDisconnected, function(p29)
			-- upvalues: (copy) p_u_27, (copy) p_u_26
			if p29 == p_u_27 then
				p_u_26:_setupActiveGamepad(nil)
			end
		end)
		if v_u_3:GetGamepadConnected(p_u_27) then
			p_u_26:_setupActiveGamepad(p_u_27)
			return
		end
	else
		local function v31()
			-- upvalues: (ref) v_u_12, (copy) p_u_26
			local v30 = v_u_12()
			if v30 ~= p_u_26._gamepad then
				p_u_26:_setupActiveGamepad(v30)
			end
		end
		p_u_26._trove:Connect(v_u_3.GamepadConnected, v31)
		p_u_26._trove:Connect(v_u_3.GamepadDisconnected, v31)
		p_u_26:_setupActiveGamepad((v_u_12()))
	end
end
function v_u_13._setupMotors(p32)
	p32._setMotorIds = {}
	for _, v33 in ipairs(Enum.VibrationMotor:GetEnumItems()) do
		p32._setMotorIds[v33] = 0
	end
end
function v_u_13.GetThumbstick(p34, p35, p36)
	local v37 = p34.State[p35].Position
	local v38 = p36 or p34.DefaultDeadzone
	local v39 = Vector2.new
	local v40 = v37.X
	local v41 = math.abs(v40) < v38 and 0 or (math.abs(v40) - v38) / (1 - v38) * math.sign(v40)
	local v42 = v37.Y
	return v39(v41, math.abs(v42) < v38 and 0 or (math.abs(v42) - v38) / (1 - v38) * math.sign(v42))
end
function v_u_13.GetTrigger(p43, p44, p45)
	local v46 = p43.State[p44].Position.Z
	local v47 = p45 or p43.DefaultDeadzone
	return math.abs(v46) < v47 and 0 or (math.abs(v46) - v47) / (1 - v47) * math.sign(v46)
end
function v_u_13.IsButtonDown(p48, p49)
	-- upvalues: (copy) v_u_3
	return v_u_3:IsGamepadButtonDown(p48._gamepad, p49)
end
function v_u_13.IsMotorSupported(p50, p51)
	-- upvalues: (copy) v_u_4
	return v_u_4:IsMotorSupported(p50._gamepad, p51)
end
function v_u_13.SetMotor(p52, p53, p54)
	-- upvalues: (copy) v_u_4
	local v55 = p52._setMotorIds
	v55[p53] = v55[p53] + 1
	local v56 = p52._setMotorIds[p53]
	v_u_4:SetMotor(p52._gamepad, p53, p54)
	return v56
end
function v_u_13.PulseMotor(p_u_57, p_u_58, p59, p_u_60)
	-- upvalues: (copy) v_u_6
	local v_u_61 = p_u_57:SetMotor(p_u_58, p59)
	local function v_u_62()
		-- upvalues: (copy) p_u_57, (copy) p_u_58, (copy) v_u_61
		if p_u_57._setMotorIds[p_u_58] == v_u_61 then
			p_u_57:StopMotor(p_u_58)
		end
	end
	local v_u_63 = time()
	local v_u_64 = nil
	v_u_64 = v_u_6.Heartbeat:Connect(function()
		-- upvalues: (copy) v_u_63, (copy) p_u_60, (ref) v_u_64, (copy) v_u_62
		if p_u_60 <= time() - v_u_63 then
			v_u_64:Disconnect()
			v_u_62()
		end
	end)
	local v65 = v_u_64
	p_u_57._gamepadTrove:Add(v65)
end
function v_u_13.StopMotor(p66, p67)
	p66:SetMotor(p67, 0)
end
function v_u_13.StopMotors(p68)
	for _, v69 in ipairs(Enum.VibrationMotor:GetEnumItems()) do
		if p68:IsMotorSupported(v69) then
			p68:StopMotor(v69)
		end
	end
end
function v_u_13.IsConnected(p70)
	-- upvalues: (copy) v_u_3
	if p70._gamepad then
		return v_u_3:GetGamepadConnected(p70._gamepad)
	else
		return false
	end
end
function v_u_13.GetUserInputType(p71)
	return p71._gamepad
end
function v_u_13.SetAutoSelectGui(_, p72)
	-- upvalues: (copy) v_u_5
	v_u_5.AutoSelectGuiEnabled = p72
end
function v_u_13.IsAutoSelectGuiEnabled(_)
	-- upvalues: (copy) v_u_5
	return v_u_5.AutoSelectGuiEnabled
end
function v_u_13.Destroy(p73)
	p73._trove:Destroy()
end
return v_u_13