-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "OverLuckController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_4, (copy) v_u_2, (copy) v_u_7, (ref) v_u_10
	local v_u_34 = {
		["Charge"] = function(p14)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_12:Flash(p14, Color3.fromRGB(85, 255, 127), 1)
				v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Charge, v15, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p16, p17, p_u_18)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9, (ref) v_u_4, (ref) v_u_2
			local v19 = p16:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Dash, v19, game.SoundService.Effect)
				local v20 = v_u_6.Utils.Itadori.RushWind:Clone()
				v20.CFrame = v19.CFrame
				v20.Parent = workspace.Effects
				v20.Dust:Emit(7)
				v20.Ring:Emit(7)
				v20.Dash1.Dash:Emit(1)
				v20.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v20, 2)
				if v_u_5.Character == p16 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					local v_u_21 = Instance.new("NumberValue", p17)
					v_u_21.Value = 50 * p_u_18
					p17:GetAttributeChangedSignal("Swing"):Connect(function()
						-- upvalues: (ref) v_u_4, (copy) v_u_21, (copy) p_u_18
						v_u_4:Create(v_u_21, TweenInfo.new(0.2), {
							["Value"] = 25 * p_u_18
						}):Play()
						task.wait(0.2)
						v_u_4:Create(v_u_21, TweenInfo.new(0.5, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
							["Value"] = 50 * p_u_18
						}):Play()
					end)
					repeat
						p17.Velocity = v19.CFrame.LookVector * v_u_21.Value
						v_u_2.Stepped:Wait()
					until not (p17.Parent and v19.Parent)
				end
			end
		end,
		["Swing"] = function(p22, p23)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v24 = p22:FindFirstChild("HumanoidRootPart")
			if v24 then
				if p23 == 1 then
					v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Speed2, v24, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_8.Misc.Swing.Fist2, v24, game.SoundService.Effect)
					return
				elseif p23 == 4 then
					v_u_12:PlaySound(v_u_8.Misc.Swing.Fist2, v24, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Swing, v24, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_8.Misc.Swing.Fist3, v24, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["HeavySwing"] = function(p25, p26)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v27 = p25:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v28 = v_u_7.Itadori.CrushingBlow:Clone()
				v28.Air.Position = Vector3.new(0, 40, 0)
				v28.CFrame = v27.CFrame * CFrame.new(p26 and -3 or 3, 0, 0) * CFrame.Angles(1.5707963267948966, 0, 0)
				v28.Parent = workspace.Effects
				v_u_3:AddItem(v28, 1)
				v28.PointLight.Color = Color3.fromRGB(85, 255, 127)
				v_u_4:Create(v28.PointLight, TweenInfo.new(1), {
					["Brightness"] = 0
				}):Play()
				if p26 then
					v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Speed1, v27, game.SoundService.Effect)
				end
				v28.Beam.Color = ColorSequence.new(Color3.fromRGB(85, 255, 127))
				v28.Floor.Sparks.Color = ColorSequence.new(Color3.fromRGB(85, 255, 127))
				v28.Floor.Ring:Emit(20)
				v28.Floor.Sparks:Emit(20)
				v_u_4:Create(v28.Air, TweenInfo.new(0.15), {
					["Position"] = Vector3.new(0, 0, 0)
				}):Play()
				v_u_4:Create(v28, TweenInfo.new(0.4), {
					["CFrame"] = v28.CFrame + v27.CFrame.LookVector * 30
				}):Play()
				if v_u_5.Character == p25 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end,
		["Hit"] = function(p29, p30, p31)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			local v32 = p30:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_12:Flash(p30, Color3.new(1, 1, 1))
				if p31 == true then
					v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Hit1, v32, game.SoundService.Effect)
				elseif p31 == false then
					v_u_12:PlaySound(v_u_8.Hakari.OverLuck.Hit2, v32, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v32, game.SoundService.Effect)
				end
				local v33 = v_u_7.Hakari.RoughHit:Clone()
				v33.Position = v32.Position
				v33.Parent = workspace.Effects
				v_u_3:AddItem(v33, 1)
				v_u_4:Create(v33.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v33.Glow:Emit(1)
				v33.Sparks:Emit(50)
				v33.Wind:Emit(7)
				v33.Wind2:Emit(7)
				if v_u_5 == p29 or v_u_5.Character == p30 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p35, ...)
		-- upvalues: (copy) v_u_34
		local v36 = v_u_34[p35]
		if v36 then
			v36(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("OverLuckService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13