-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "kills",
	["Description"] = "Changes the kill amount of a player",
	["Group"] = { "Owner", "HeadMod", "Developer" },
	["Args"] = {
		{
			["Type"] = "username",
			["Name"] = "Username"
		},
		{
			["Type"] = "number",
			["Name"] = "amount"
		}
	}
}
return v1