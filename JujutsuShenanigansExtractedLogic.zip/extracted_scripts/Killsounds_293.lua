-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 1,
	["SortOrder"] = 6,
	["Val"] = "VolKS",
	["Desc"] = "Toggle global player killsounds"
}