-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.EffectUtils)
local v_u_10 = require(v_u_5.Knit.Trove)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "UltraCannonController"
})
function v14.KnitStart(_)
	-- upvalues: (copy) v_u_10, (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4, (ref) v_u_13, (copy) v_u_9, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_8, (ref) v_u_11
	local v_u_76 = {
		["Start"] = function(p15, p16, p17, p18)
			-- upvalues: (ref) v_u_10, (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_4, (ref) v_u_13
			local v19 = p15:FindFirstChild("HumanoidRootPart")
			if v19 then
				local v20 = v_u_10.new()
				v20:AttachToInstance(p16)
				v20:Add(v_u_12:PlaySound(v_u_7.Mechamaru.UltraCannon.Start, v19, game.SoundService.Effect))
				local v21 = p15:FindFirstChild("Left Arm")
				if v21 then
					local v22 = v20:Clone(v_u_6.Mechamaru["Hand blasterL"])
					v22.Weld.Part0 = v21
					if p15:GetAttribute("Moveset") ~= "Mechamaru" then
						v22.BlasterL.Transparency = 1
						v22.Neon.Transparency = 1
					end
					v22.Parent = p15
				end
				if p18 and (p17 and v_u_4.Character == p18) then
					repeat
						p17:FireServer((v_u_13:GetMouseTarget(75)))
						task.wait()
					until not p17.Parent
				end
			end
		end,
		["FireCannon"] = function(p23)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_12, (ref) v_u_7, (ref) v_u_2, (ref) v_u_3, (ref) v_u_5, (ref) v_u_4, (ref) v_u_8
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraCannonVFX.FireCannon, v24)
				v_u_12:PlaySound(v_u_7.Mechamaru.UltraCannon.Shoot, v24, game.SoundService.Effect)
			end
			local v25 = p23:FindFirstChild("Hand blasterL")
			if v25 then
				v_u_9.Enable("ParticleEmitter", v25, nil, nil, true)
			end
			local v26 = v_u_6.Mechamaru.CannonFire:Clone()
			v26:PivotTo(v24.CFrame * CFrame.new(0, 0, -34))
			v26.Parent = workspace.Effects
			v_u_2:AddItem(v26, 1)
			for _, v27 in v26:GetChildren() do
				local v28 = v_u_3
				local v29 = TweenInfo.new(0.3)
				local v30 = {}
				local v31 = v27.Size.Z
				v30.Size = Vector3.new(0, 0, v31)
				v30.CFrame = v27.CFrame - v27.CFrame.LookVector * 5
				v28:Create(v27, v29, v30):Play()
				v_u_2:AddItem(v27, 0.3)
			end
			local v32 = Instance.new("Model")
			local v33 = v_u_5.Utils.Itadori.RushWind:Clone()
			v33.CFrame = v24.CFrame * CFrame.new(0, -1, 0)
			v33.Parent = v32
			v32.Parent = workspace.Effects
			v32:ScaleTo(0.6)
			v33.Ring:Emit(7)
			v33.Dash1.Dash:Emit(1)
			v33.Dash2.Dash:Emit(1)
			v_u_3:Create(v33, TweenInfo.new(1, Enum.EasingStyle.Quad), {
				["CFrame"] = v33.CFrame - v33.CFrame.LookVector * 16
			}):Play()
			v_u_2:AddItem(v32, 2)
			if v_u_4.Character == p23 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end,
		["AlbatrosStart"] = function(p_u_34, p35)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_12, (ref) v_u_7, (ref) v_u_10, (ref) v_u_2, (ref) v_u_4
			local v36 = p_u_34:FindFirstChild("HumanoidRootPart")
			if v36 then
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraCannonVFX.AlbatrosStart, v36)
				v_u_12:PlaySound(v_u_7.Mechamaru.UltraCannon.Albatros, v36, game.SoundService.Effect)
			end
			local v_u_37 = v_u_10.new()
			v_u_37:AttachToInstance(p35)
			local v38 = p_u_34:FindFirstChild("Head")
			if v38 and p_u_34:GetAttribute("Moveset") == "Mechamaru" then
				local v39 = v_u_37:Clone(v_u_6.Mechamaru["Mecha mouth blaster"])
				v39.Weld.Part0 = v38
				v39.Parent = p_u_34
			end
			local function v44(p40)
				-- upvalues: (copy) p_u_34, (ref) v_u_6, (ref) v_u_9, (copy) v_u_37, (ref) v_u_2
				local v41 = p_u_34:FindFirstChild(p40)
				if v41 then
					local v_u_42 = v_u_6.Mechamaru[("Booster%*"):format((p40:sub(1, 1)))]:Clone()
					v_u_42.Weld.Part0 = v41
					local v43 = v_u_42:FindFirstChildOfClass("UnionOperation")
					v43.Stage1:Destroy()
					v43.Stage2:Destroy()
					if p_u_34:GetAttribute("Moveset") ~= "Mechamaru" then
						v_u_9.Visibility(v_u_42, false)
					end
					v_u_37:Add(function()
						-- upvalues: (ref) v_u_2, (copy) v_u_42, (ref) v_u_9
						v_u_2:AddItem(v_u_42, 0.3)
						v_u_9.Visibility(v_u_42, false, 0.15)
					end)
					v_u_42.Parent = p_u_34
				end
			end
			v44("Left Arm")
			v44("Right Arm")
			local _ = v_u_4.Character == p_u_34
		end,
		["AlbatrosCharge"] = function(p45, p46)
			-- upvalues: (ref) v_u_10, (ref) v_u_9, (ref) v_u_6, (ref) v_u_4, (ref) v_u_8
			local v47 = p45:FindFirstChild("HumanoidRootPart")
			if v47 then
				local v48 = v_u_10.new()
				v48:AttachToInstance(p46)
				v48:Add(v_u_9.Enable("ParticleEmitter", v_u_6.Mechamaru.UltraCannonVFX.AlbatrosCharge.Enable.AlbatrosChargeEnable, v47))
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraCannonVFX.AlbatrosCharge, v47)
			end
			local v49 = p45:FindFirstChild("Hand blasterL")
			if v49 then
				v_u_9.Enable("ParticleEmitter", v49, nil, nil, true)
			end
			if v_u_4.Character == p45 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
			end
		end,
		["AlbatrosFire"] = function(p_u_50, p_u_51)
			-- upvalues: (ref) v_u_10, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v_u_52 = p_u_50:FindFirstChild("HumanoidRootPart")
			if v_u_52 then
				local v53 = v_u_10.new()
				v53:AttachToInstance(p_u_51)
				local v_u_54 = 37.5
				local v_u_55 = v53:Add(v_u_9.Enable({ "ParticleEmitter", "Beam" }, v_u_6.Mechamaru.UltraCannonVFX.AlbatrosFire.Beam, v_u_52, 1.75))
				v_u_55.Weld.C0 = CFrame.Angles(0, 3.141592653589793, 0)
				local v56 = v_u_52:FindFirstChild("AlbatrosChargeEnable")
				if v56 then
					v56:Destroy()
				end
				local v_u_57 = v53:Add(v_u_9.Enable("ParticleEmitter", v_u_6.Mechamaru.UltraCannonVFX.AlbatrosFire.Enable, v_u_52, 1.75))
				local v58 = p_u_50:FindFirstChild("BoosterL")
				if v58 then
					v58 = v58:FindFirstChildOfClass("UnionOperation")
				end
				if v58 then
					v_u_9.Enable("ParticleEmitter", v_u_6.Mechamaru.UltraCannonVFX.AlbatrosFire.BoosterLEnable, v58, 1.75)
				end
				local v59 = p_u_50:FindFirstChild("BoosterR")
				if v59 then
					v59 = v59:FindFirstChildOfClass("UnionOperation")
				end
				if v59 then
					v_u_9.Enable("ParticleEmitter", v_u_6.Mechamaru.UltraCannonVFX.AlbatrosFire.BoosterREnable, v59, 1.75)
				end
				task.spawn(function()
					-- upvalues: (ref) v_u_6, (copy) p_u_51, (ref) v_u_9, (copy) v_u_52
					local v60 = v_u_6.Mechamaru.UltraCannonVFX.AlbatrosRepeat.ConeSwirl
					local v61 = v60:GetAttribute("RepeatCount")
					local v62 = v60:GetAttribute("RepeatDelay")
					for _ = 1, v61 do
						if not p_u_51.Parent then
							break
						end
						v_u_9.AutoMeshes(v60, v_u_52)
						task.wait(v62)
					end
				end)
				task.spawn(function()
					-- upvalues: (copy) p_u_51, (copy) v_u_52, (ref) v_u_54, (copy) v_u_55, (copy) v_u_57, (ref) v_u_6, (ref) v_u_2, (ref) v_u_9, (ref) v_u_4, (copy) p_u_50, (ref) v_u_8
					for _ = 1, 21 do
						if not (p_u_51.Parent and v_u_52.Parent) then
							break
						end
						local v63 = workspace:Raycast(v_u_52.Position, v_u_52.CFrame.LookVector * 37.5, _G.MapParams)
						v_u_54 = v63 and v63.Distance or 37.5
						if v_u_55.Parent then
							v_u_55.End.CFrame = CFrame.new(0, 0, v_u_54)
							v_u_55.End2.CFrame = CFrame.new(0, 0, v_u_54 / 1.2)
							v_u_55.Attachment.CFrame = CFrame.new(0, 0, v_u_54 / 3) * CFrame.Angles(0, 3.141592653589793, 0)
						end
						if v_u_57.Parent then
							local v64 = v_u_57.Wind
							local v65 = v_u_54 / 1.3
							v64.Size = vector.create(1, 0.187, v65)
							v_u_57.Wind.Weld.C0 = CFrame.new(0, -3.1, -v_u_54 / 1.2)
							for _, v66 in v_u_57.Attachment1:GetChildren() do
								if v66:IsA("ParticleEmitter") then
									v66.Speed = NumberRange.new(0, v66:GetAttribute("MaxSpeed") * (v_u_54 / 37.5))
								end
							end
						end
						for _, v67 in v_u_6.Mechamaru.UltraCannonVFX.AlbatrosRepeat.Beam:GetChildren() do
							local v68 = v67.Start:Clone()
							v_u_2:AddItem(v68, 0.15)
							v68.CFrame = v_u_52.CFrame * v68.CFrame
							local v69 = v67.End.Size
							local v70 = v_u_9.Tween
							local v71 = {
								["CFrame"] = v_u_52.CFrame * CFrame.new(0, 0, -v_u_54 / 2 - 2)
							}
							local v72 = v69.X
							local v73 = v69.Y
							local v74 = v69.Z - 23 + v_u_54
							v71.Size = vector.create(v72, v73, v74)
							v70(v68, 0.15, "Cubic", "Out", v71)
							v68.Parent = workspace.Effects
						end
						if v_u_4.Character == p_u_50 then
							v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
						end
						task.wait(0.07)
					end
					task.wait(0.2)
					if p_u_51.Parent and v_u_4.Character == p_u_50 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
					end
				end)
				v_u_9.AutoEffects(v_u_6.Mechamaru.UltraCannonVFX.FireCannon, v_u_52)
				if v_u_4.Character == p_u_50 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
				end
			end
		end,
		["AlbatrosHit"] = function(p75)
			-- upvalues: (ref) v_u_12
			if p75:FindFirstChild("HumanoidRootPart") then
				v_u_12:Flash(p75, Color3.fromRGB(255, 255, 255))
			end
		end
	}
	v_u_11.Effects:Connect(function(p77, ...)
		-- upvalues: (copy) v_u_76
		local v78 = v_u_76[p77]
		if v78 then
			v78(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("UltraCannonService")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetController("ToolController")
end
return v14