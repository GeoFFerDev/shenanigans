-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

require(script.Parent.TypeDefinitions)
local v_u_1 = game:GetService("TestService")
local v_u_2 = require(script.Parent.Table)
local v_u_3 = {}
v_u_3.__index = v_u_3
v_u_3.__type = "Signal"
local v_u_4 = {}
v_u_4.__index = v_u_4
v_u_4.__type = "SignalConnection"
function v_u_3.new(p5)
	-- upvalues: (copy) v_u_3
	local v6 = v_u_3
	return setmetatable({
		["Name"] = p5,
		["Connections"] = {},
		["YieldingThreads"] = {}
	}, v6)
end
local function v_u_14(p_u_7, p_u_8, p9)
	-- upvalues: (copy) v_u_1
	local v11 = coroutine.create(function()
		-- upvalues: (copy) p_u_7, (copy) p_u_8
		local v10 = p_u_8
		p_u_7(unpack(v10))
	end)
	local v12, v13 = coroutine.resume(v11)
	if not v12 then
		v_u_1:Error(string.format("Exception thrown in your %s event handler: %s", p9, v13))
		v_u_1:Checkpoint(debug.traceback(v11))
	end
end
function v_u_3.Connect(p15, p16)
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	local v17 = getmetatable(p15) == v_u_3
	assert(v17, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Connect", "Signal.new()"))
	local v18 = v_u_4
	local v19 = setmetatable({
		["Signal"] = p15,
		["Delegate"] = p16,
		["Index"] = -1
	}, v18)
	v19.Index = #p15.Connections + 1
	v_u_2.insert(p15.Connections, v19.Index, v19)
	return v19
end
function v_u_3.Fire(p20, ...)
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_14
	local v21 = getmetatable(p20) == v_u_3
	assert(v21, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Fire", "Signal.new()"))
	local v22 = v_u_2.pack(...)
	local v23 = p20.Connections
	local v24 = p20.YieldingThreads
	for v25 = 1, #v23 do
		local v26 = v23[v25]
		if v26.Delegate ~= nil then
			v_u_14(v26.Delegate, v22, v26.Signal.Name)
		end
	end
	for v27 = 1, #v24 do
		local v28 = v24[v27]
		if v28 ~= nil then
			coroutine.resume(v28, ...)
		end
	end
end
function v_u_3.FireSync(p29, ...)
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	local v30 = getmetatable(p29) == v_u_3
	assert(v30, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("FireSync", "Signal.new()"))
	local v31 = v_u_2.pack(...)
	local v32 = p29.Connections
	local v33 = p29.YieldingThreads
	for v34 = 1, #v32 do
		local v35 = v32[v34]
		if v35.Delegate ~= nil then
			v35.Delegate(unpack(v31))
		end
	end
	for v36 = 1, #v33 do
		local v37 = v33[v36]
		if v37 ~= nil then
			coroutine.resume(v37, ...)
		end
	end
end
function v_u_3.Wait(p38)
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	local v39 = getmetatable(p38) == v_u_3
	assert(v39, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Wait", "Signal.new()"))
	local v40 = coroutine.running()
	v_u_2.insert(p38.YieldingThreads, v40)
	local v41 = { coroutine.yield() }
	v_u_2.removeObject(p38.YieldingThreads, v40)
	return unpack(v41)
end
function v_u_3.Dispose(p42)
	-- upvalues: (copy) v_u_3
	local v43 = getmetatable(p42) == v_u_3
	assert(v43, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Dispose", "Signal.new()"))
	local v44 = p42.Connections
	for v45 = 1, #v44 do
		v44[v45]:Disconnect()
	end
	p42.Connections = {}
	setmetatable(p42, nil)
end
function v_u_4.Disconnect(p46)
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	local v47 = getmetatable(p46) == v_u_4
	assert(v47, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Disconnect", "private function NewConnection()"))
	v_u_2.remove(p46.Signal.Connections, p46.Index)
	p46.SignalStatic = nil
	p46.Delegate = nil
	p46.YieldingThreads = {}
	p46.Index = -1
	setmetatable(p46, nil)
end
return v_u_3