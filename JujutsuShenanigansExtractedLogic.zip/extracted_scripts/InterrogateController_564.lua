-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
local v10 = require(v_u_5.Modules.SraikoVFX)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "InterrogateController"
})
local _ = v10.Emit
local _ = v10.Enabled
local _ = v10.EmitMesh
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_5, (copy) v_u_2, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_11
	local v_u_64 = {
		["Start"] = function(p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:PlaySound(v_u_7.Todo.BruteForce.Start, v16, game.SoundService.Effect)
				v_u_12:ArmFlash(p15["Left Arm"], Color3.fromRGB(129, 168, 203), 0.7)
			end
		end,
		["Swing"] = function(p17)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_12:PlaySound(v_u_7.Misc.Swing.Fist, v18, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p19)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			local v_u_20 = p19:FindFirstChild("HumanoidRootPart")
			if v_u_20 then
				local v21 = Instance.new("Model")
				local v22 = v_u_5.Utils.Itadori.RushWind:Clone()
				v22.CFrame = v_u_20.CFrame * CFrame.new(0, -1, 0)
				v22.Parent = v21
				v21.Parent = workspace.Effects
				v21:ScaleTo(0.6)
				v22.Ring:Emit(7)
				v22.Dash1.Dash:Emit(1)
				v22.Dash2.Dash:Emit(1)
				v_u_2:AddItem(v21, 2)
				local v23 = v_u_6.Itadori.Shock:Clone()
				v23.CFrame = v_u_20.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v23.Parent = workspace.Effects
				v_u_3:Create(v23, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v23, 0.2)
				task.delay(0.1, function()
					-- upvalues: (ref) v_u_6, (copy) v_u_20, (ref) v_u_3, (ref) v_u_2
					local v24 = v_u_6.Itadori.Shock:Clone()
					v24.CFrame = (v_u_20.CFrame - v_u_20.CFrame.Position + v_u_20.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
					v24.Parent = workspace.Effects
					v_u_3:Create(v24, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v24, 0.2)
				end)
			end
		end,
		["FinalSwing"] = function(p25, p26, p27)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_7, (ref) v_u_8
			local v28 = p25:FindFirstChild("HumanoidRootPart")
			if v28 then
				local v29 = v_u_6.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v29.CFrame = v28.CFrame * CFrame.new(2, 1, -5)
				v29.Parent = workspace.Effects
				v29.Wind:Emit(20)
				v29.PointLight:Destroy()
				v29.Back1.Back:Emit(1)
				v29.Back2.Back:Emit(1)
				v_u_2:AddItem(v29, 3)
				if p27 then
					if v_u_4.Character == p25 or v_u_4.Character == p26 then
						local v_u_30 = Instance.new("ColorCorrectionEffect", game.Lighting)
						v_u_30.Saturation = -1
						v_u_30.Contrast = 10
						v_u_2:AddItem(v_u_30, 1.5)
						v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
							["FieldOfView"] = 35
						}):Play()
						v_u_3:Create(v_u_30, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
							["Saturation"] = -0.5,
							["Contrast"] = 0
						}):Play()
						task.delay(1, function()
							-- upvalues: (ref) v_u_3, (copy) v_u_30
							v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["FieldOfView"] = 70
							}):Play()
							v_u_3:Create(v_u_30, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
								["Saturation"] = 0
							}):Play()
						end)
					end
					for _, v31 in v29:GetDescendants() do
						if v31:IsA("ParticleEmitter") then
							v31.TimeScale = 0
						end
					end
					task.wait(1)
					for _, v32 in v29:GetDescendants() do
						if v32:IsA("ParticleEmitter") then
							v32.TimeScale = 1
						end
					end
				end
				v_u_3:Create(v29.Back1, TweenInfo.new(2), {
					["CFrame"] = v29.Back1.CFrame - v29.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_3:Create(v29.Back2, TweenInfo.new(2), {
					["CFrame"] = v29.Back2.CFrame - v29.Back2.CFrame.LookVector * 20
				}):Play()
				local v33 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v33.Size = Vector3.new(6, 30, 6)
				v33.CFrame = v28.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v33.Parent = workspace.Effects
				v_u_2:AddItem(v33, 0.2)
				v_u_3:Create(v33, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = v33.Position + v28.CFrame.LookVector * 10
				}):Play()
				v_u_12:PlaySound(v_u_7.Mahito.Stockpile.Swing2, v28, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Todo.BruteForce.Swing, v28, game.SoundService.Effect)
				if v_u_4.Character == p25 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Ohno"] = function(p34, p35)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_6, (ref) v_u_2
			local v36 = p34:FindFirstChild("HumanoidRootPart")
			if v36 then
				if v_u_4.Character == p34 or v_u_4.Character == p35 then
					v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["FieldOfView"] = 50
					}):Play()
					task.delay(1.5, function()
						-- upvalues: (ref) v_u_3
						v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
							["FieldOfView"] = 70
						}):Play()
					end)
				end
				local v37 = v_u_6.Mechamaru.Dust:Clone()
				v37.bigimpact:Destroy()
				v37.Smoke2:Destroy()
				v37.Position = v36.Position - Vector3.new(0, 3, 0)
				v37.Parent = workspace.Effects
				v_u_2:AddItem(v37, 2.5)
				for _, v38 in v37:GetChildren() do
					v38:Emit(v38:GetAttribute("EmitCount"))
					v_u_3:Create(v38, TweenInfo.new(0.4), {
						["TimeScale"] = 0.1
					}):Play()
				end
				task.wait(1.5)
				for _, v39 in v37:GetChildren() do
					v39:Emit(v39:GetAttribute("EmitCount"))
					v39.TimeScale = 1
				end
			end
		end,
		["Hit"] = function(p40)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8
			local v41 = p40:FindFirstChild("HumanoidRootPart")
			if v41 then
				local v42 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v42.Position = v41.Position
				v42.Parent = workspace.Effects
				v_u_2:AddItem(v42, 1)
				v42.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
				v42.Wind.Color = v42.Sparks.Color
				v42.Wind2.Color = v42.Sparks.Color
				v42.Sparks:Emit(50)
				v42.Wind:Emit(7)
				v42.Wind2:Emit(7)
				v_u_12:Flash(p40, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v41, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Todo.BruteForce.Hit, v41, game.SoundService.Effect)
				local v43 = v_u_6.Mechamaru.Dust:Clone()
				v43.bigimpact:Destroy()
				v43.Smoke2:Destroy()
				v43.Position = v41.Position - Vector3.new(0, 3, 0)
				v43.Parent = workspace.Effects
				v_u_2:AddItem(v43, 2)
				for _, v44 in v43:GetChildren() do
					v44:Emit(v44:GetAttribute("EmitCount"))
				end
				for _ = 1, 20 do
					v_u_9:Blood(p40.Head.CFrame, math.random(5, 80), 25, 25)
				end
				if (workspace.CurrentCamera.CFrame.Position - v41.Position).Magnitude < 80 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Grab"] = function(p45, p46)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_8
			local v47 = p45:FindFirstChild("HumanoidRootPart")
			if v47 then
				v_u_12:Flash(p45, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Gojo.LapseBlue.Grab, v47, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Nanami.Interrogate["Grab" .. p46], v47, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v47.Position).Magnitude < 80 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Chat"] = function(p48, p49, p50)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			if p48.Head:FindFirstChild("HiromiText") then
				p48.Head.HiromiText:Destroy()
			end
			v_u_12:PlaySound(v_u_7.Hiromi.DeadlySentence.Talk, p48.Head, game.SoundService.Voice).PlaybackSpeed = p50
			local v_u_51 = v_u_6.Hiromi.DeadlySentencing.HiromiText:Clone()
			v_u_51.TextLabel.Text = p49
			v_u_51.Parent = p48.Head
			v_u_2:AddItem(v_u_51, 1.5)
			task.delay(1, function()
				-- upvalues: (copy) v_u_51, (ref) v_u_3
				if v_u_51.Parent then
					v_u_3:Create(v_u_51.TextLabel, TweenInfo.new(0.5), {
						["BackgroundTransparency"] = 1,
						["TextTransparency"] = 1
					}):Play()
					v_u_3:Create(v_u_51.TextLabel.UIStroke, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
			end)
		end,
		["FinalHit"] = function(p_u_52, p53)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8
			local v54 = p_u_52:FindFirstChild("HumanoidRootPart")
			if v54 then
				local v55 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v55.Position = v54.Position
				v55.Parent = workspace.Effects
				v_u_2:AddItem(v55, 1)
				v55.Sparks.Color = ColorSequence.new(Color3.fromRGB(85, 170, 255))
				v55.Wind.Color = v55.Sparks.Color
				v55.Wind2.Color = v55.Sparks.Color
				v55.Sparks:Emit(50)
				v55.Wind:Emit(7)
				v55.Wind2:Emit(7)
				v_u_12:Flash(p_u_52, Color3.new(1, 1, 1))
				local v_u_56 = v_u_6.Mechamaru.Dust:Clone()
				v_u_56.bigimpact:Destroy()
				v_u_56.Smoke2:Destroy()
				v_u_56.Position = v54.Position - Vector3.new(0, 3, 0)
				v_u_56.Parent = workspace.Effects
				v_u_2:AddItem(v_u_56, 2.5)
				for _, v57 in v_u_56:GetChildren() do
					v57:Emit(v57:GetAttribute("EmitCount"))
				end
				if p53 then
					v_u_12:PlaySound(v_u_7.Nanami.Interrogate.FinisherHit, v54, game.SoundService.Effect)
					v_u_12:PlaySound(v_u_7.Nanami.Interrogate.Freeze, v54, game.SoundService.Effect)
					local v_u_58 = v_u_6.Naoya.BleedFreeze.Attachment:Clone()
					v_u_58.Parent = p_u_52.Head
					v_u_58.Blood:Emit(100)
					task.delay(0.05, function()
						-- upvalues: (copy) v_u_58, (ref) v_u_9, (copy) p_u_52
						v_u_58.Blood.TimeScale = 0
						task.wait(0.95)
						v_u_58.Blood.TimeScale = 1
						for _ = 1, 20 do
							v_u_9:Blood(p_u_52.Head.CFrame, math.random(5, 80), 25, 25)
						end
					end)
					for _, v59 in v_u_56:GetChildren() do
						v59.TimeScale = 0
					end
					task.delay(1, function()
						-- upvalues: (copy) v_u_56
						for _, v60 in v_u_56:GetChildren() do
							v60.TimeScale = 1
						end
					end)
				else
					v_u_12:PlaySound(v_u_7.Nanami.Interrogate.Hit, v54, game.SoundService.Effect)
					for _ = 1, 20 do
						v_u_9:Blood(p_u_52.Head.CFrame, math.random(5, 80), 25, 25)
					end
				end
				if (workspace.CurrentCamera.CFrame.Position - v54.Position).Magnitude < 80 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.SnapOh)
				end
			end
		end,
		["FinalHit2"] = function(p61)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_8
			local v62 = p61:FindFirstChild("HumanoidRootPart")
			if v62 then
				local v63 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v63.Position = v62.Position
				v63.Parent = workspace.Effects
				v_u_2:AddItem(v63, 1)
				v63.Sparks.Color = ColorSequence.new(Color3.fromRGB(85, 170, 255))
				v63.Wind.Color = v63.Sparks.Color
				v63.Wind2.Color = v63.Sparks.Color
				v63.Sparks:Emit(50)
				v63.Wind:Emit(7)
				v63.Wind2:Emit(7)
				v_u_12:Flash(p61, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v62, game.SoundService.Effect)
				v_u_12:PlaySound(v_u_7.Todo.BruteForce.Hit, v62, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v62.Position).Magnitude < 80 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p65, ...)
		-- upvalues: (copy) v_u_64
		local v66 = v_u_64[p65]
		if v66 then
			v66(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("InterrogateService")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetController("ToolController")
end
return v14