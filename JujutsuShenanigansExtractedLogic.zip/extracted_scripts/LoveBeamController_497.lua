-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v_u_4 = game.ReplicatedStorage
local _ = v_u_4.Animations
local v_u_5 = v_u_4.Utils
local v_u_6 = v_u_4.Sounds
local v_u_7 = require(v_u_4.Modules.CameraShaker)
require(v_u_4.Modules.BloodyZee)
local v_u_8 = nil
local v_u_9 = nil
local v10 = v_u_1.CreateController({
	["Name"] = "LoveBeamController"
})
local v_u_11 = workspace.CurrentCamera
local function v_u_27(p12, p13, p14)
	local v15 = p14.Z - 20 - p14.X / 2
	local v16 = math.max(v15, 0)
	local _ = p12.BlackStart.Size.X
	p12.BlackStart.CFrame = p13 * CFrame.new(0, 0, -10) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v17 = p12.BlackStart
	local v18 = p14.X
	local v19 = p14.Y
	v17.Size = Vector3.new(v18, 20, v19)
	p12.PinkStart.CFrame = p12.BlackStart.CFrame
	p12.PinkStart.Size = p12.BlackStart.Size * Vector3.new(0.875, 1, 0.875)
	p12.BlackMiddle.CFrame = p13 * CFrame.new(0, 0, -(v16 / 2 + 20)) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v20 = p12.BlackMiddle
	local v21 = p14.X
	local v22 = p14.Y
	v20.Size = Vector3.new(v21, v16, v22)
	p12.PinkMiddle.CFrame = p12.BlackMiddle.CFrame
	p12.PinkMiddle.Size = p12.BlackMiddle.Size * Vector3.new(0.875, 1, 0.875)
	p12.BlackEnd.CFrame = p13 * CFrame.new(0, 0, -(v16 + 20 + p14.X / 4)) * CFrame.Angles(1.5707963267948966, 0, 0)
	local v23 = p12.BlackEnd
	local v24 = p14.X
	local v25 = p14.X / 2
	local v26 = p14.X
	v23.Size = Vector3.new(v24, v25, v26)
	p12.PinkEnd.CFrame = p12.BlackEnd.CFrame
	p12.PinkEnd.Size = p12.BlackEnd.Size * Vector3.new(0.875, 1, 0.875)
end
function v10.KnitStart(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_2, (copy) v_u_27, (copy) v_u_11, (copy) v_u_7, (copy) v_u_4
	local v_u_28 = Random.new()
	local v_u_62 = {
		["StartSound"] = function(p29, p30)
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			if p29 and p29.Parent then
				v_u_9:PlaySound(v_u_6.Yuta.LoveBeam.ChargeSFX, p29, game.SoundService.Effect)
				local v31 = p30:FindFirstChild("HumanoidRootPart")
				if v31 then
					v_u_9:PlaySound(v_u_6.Yuta.LoveBeam.Voiceline, v31, game.SoundService.Voice)
				end
			else
				return
			end
		end,
		["Track"] = function(p32, p33, p34)
			-- upvalues: (ref) v_u_3
			if p32.Parent then
				v_u_3:Create(p32, TweenInfo.new(p34 or 0.3), {
					["CFrame"] = p33
				}):Play()
			end
		end,
		["Bubble"] = function(p35, p36)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_2
			if p35.Parent then
				local v37 = v_u_5.Yuta.LoveBeam.ChargeBall.Size
				local v38 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, true)
				v_u_3:Create(p35, TweenInfo.new(0.2), {
					["Size"] = v37
				}):Play()
				v_u_3:Create(p35.Outline, TweenInfo.new(0.2), {
					["Size"] = v37 + Vector3.new(0.07, 0.07, 0.07)
				}):Play()
				task.wait(0.2)
				repeat
					task.wait(0.05)
					local v39 = v_u_5.Yuta.LoveBeam.ChargeBall:Clone()
					local v40 = v39.Size
					v39.Size = Vector3.new(0, 0, 0)
					v39.Outline.Size = Vector3.new(0, 0, 0)
					local v41 = math.random(-10, 10) / 10
					local v42 = math.random(-10, 10) / 10
					local v43 = math.random(-10, 10) / 10
					local v44 = (Vector3.new(v41, v42, v43) * 9000000000).Unit
					local v45 = Instance.new("Attachment")
					v45.Position = v44 * (v40.Magnitude / 4)
					v45.Parent = p35
					local v46 = Instance.new("RigidConstraint")
					v46.Attachment0 = v45
					v46.Attachment1 = v39.Attachment
					v46.Parent = v45
					v39.Anchored = false
					v39.Parent = p35
					v_u_3:Create(v39.Outline, v38, {
						["Size"] = v40 + Vector3.new(0.07, 0.07, 0.07)
					}):Play()
					v_u_3:Create(v39, v38, {
						["Size"] = v40
					}):Play()
					v_u_2:AddItem(v39, 0.3)
					v_u_2:AddItem(v45, 0.3)
				until not (p35.Parent and p36.Parent)
			end
		end,
		["SmallBeam"] = function(p_u_47, p_u_48)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_6, (ref) v_u_27, (ref) v_u_11, (ref) v_u_7, (copy) v_u_28, (ref) v_u_3
			local v_u_49 = v_u_5.Yuta.LoveBeam.Beam:Clone()
			v_u_9:PlaySound(v_u_6.Yuta.LoveBeam.SmallBeam, v_u_49.BlackMiddle, game.SoundService.Effect)
			for _, v50 in v_u_49:GetDescendants() do
				if v50:IsA("Beam") then
					v50.Enabled = false
				elseif v50:IsA("ParticleEmitter") then
					v_u_9:ResizeParticle(v50, 0.3)
				end
			end
			v_u_49.BlackStart.Glow.Position = Vector3.new(0, -10, 0)
			local v51 = v_u_5.Yuta.LoveBeam.ChargeBall2:Clone()
			v51.CFrame = p_u_47
			v51.Transparency = 1
			v51.Parent = workspace.Effects
			for _, v52 in v51:GetDescendants() do
				if v52:IsA("ParticleEmitter") then
					v_u_9:ResizeParticle(v52, 0.5)
				end
			end
			v_u_9:PlayParticles(v51.Attachment1)
			local v_u_53 = Instance.new("Vector3Value")
			v_u_53.Value = Vector3.new(2, 2, 180)
			v_u_27(v_u_49, p_u_47, (Vector3.new(2, 2, p_u_48:GetAttribute("BeamLength"))))
			v_u_49.Parent = workspace.Effects
			local v_u_54 = false
			task.spawn(function()
				-- upvalues: (ref) v_u_11, (copy) p_u_47, (ref) v_u_7, (ref) v_u_54, (ref) v_u_28, (ref) v_u_27, (copy) v_u_49, (copy) v_u_53, (copy) p_u_48
				local v55
				if (v_u_11.CFrame.Position - p_u_47.Position).Magnitude < 180 then
					v55 = v_u_7.CurrentShaker:ShakeSustain(v_u_7.Presets.HeavyHit)
				else
					v55 = nil
				end
				repeat
					local v56 = v_u_54 and Vector3.new(0, 0, 0) or Vector3.new(1, 1, 0) * v_u_28:NextNumber(1, 5)
					local v57 = p_u_48
					v_u_27(v_u_49, p_u_47, v_u_53.Value * Vector3.new(1, 1, 0) + v56 + Vector3.new(0, 0, v57:GetAttribute("BeamLength")))
					task.wait()
				until not p_u_48.Parent
				if v55 then
					v55:StartFadeOut(0.2)
				end
			end)
			task.wait(0.3)
			v_u_3:Create(v_u_53, TweenInfo.new(0.3), {
				["Value"] = Vector3.new(0, 0, 180)
			}):Play()
			v_u_54 = true
			for _, v58 in v_u_49:GetDescendants() do
				if v58:IsA("ParticleEmitter") or (v58:IsA("PointLight") or v58:IsA("SpotLight")) then
					v58.Enabled = false
				end
			end
			task.wait(1)
			v_u_49:Destroy()
			v51:Destroy()
		end,
		["Hit"] = function(p59)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_4, (ref) v_u_2
			local v60 = p59:FindFirstChild("HumanoidRootPart")
			if v60 then
				v_u_9:Flash(p59, Color3.fromRGB(255, 85, 255))
				v_u_9:PlaySound(v_u_6.Yuta.LoveBeam.SmallBeamHit, v60, game.SoundService.Effect)
				local v61 = v_u_4.Utils.Yuta.LoveBeam.BeamHit:Clone()
				v61.CFrame = v60.CFrame
				v61.Parent = workspace.Effects
				v_u_2:AddItem(v61, 1)
				v_u_9:PlayParticles(v61)
			end
		end
	}
	LoveBeamService.Effects:Connect(function(p63, ...)
		-- upvalues: (copy) v_u_62
		local v64 = v_u_62[p63]
		if v64 then
			v64(...)
		end
	end)
end
function v10.KnitInit(_)
	-- upvalues: (copy) v_u_1, (ref) v_u_8, (ref) v_u_9
	LoveBeamService = v_u_1.GetService("LoveBeamService")
	v_u_8 = v_u_1.GetController("HitboxController")
	v_u_9 = v_u_1.GetController("FXController")
end
return v10