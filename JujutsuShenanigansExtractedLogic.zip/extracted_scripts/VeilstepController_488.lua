-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "VeilstepController"
})
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Include
v_u_12.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_8, (copy) v_u_4, (copy) v_u_12, (ref) v_u_10
	local v_u_47 = {
		["Sound"] = function(p13)
			-- upvalues: (ref) v_u_9, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_9:PlaySound(v_u_7.Yuta.Veilstep, v14, game.SoundService.Effect)
			end
		end,
		["Sound2"] = function(p15)
			-- upvalues: (ref) v_u_9, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_9:PlaySound(v_u_7.Yuta.VeilstepJump, v16, game.SoundService.Effect)
			end
		end,
		["Dust"] = function(p17, p18)
			-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_2
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_9:DustTrail(p18, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
				local v20 = workspace
				local v21 = p17.Position - Vector3.new(0, 2, 0)
				local v22 = -v19.Size.Y * 1.6
				local v23 = v20:Raycast(v21, Vector3.new(0, v22, 0), _G.MapParams)
				if v23 then
					local v24 = v_u_6.Yuta.Veilstep.Dust:Clone()
					v24.CFrame = CFrame.lookAlong(v23.Position + Vector3.new(0, 2, 0), p17.LookVector, Vector3.new(0, 1, 0))
					v24.Parent = workspace.Effects
					v_u_2:AddItem(v24, 1)
					for _, v_u_25 in v24:GetDescendants() do
						if v_u_25:IsA("ParticleEmitter") then
							if v_u_25.Name == "Smoke2" then
								v_u_25.Color = ColorSequence.new(v23.Instance.Color)
							end
							task.delay(v_u_25:GetAttribute("EmitDelay"), function()
								-- upvalues: (copy) v_u_25
								v_u_25:Emit(v_u_25:GetAttribute("EmitCount"))
							end)
						end
					end
				end
			end
		end,
		["DiveFloorHit"] = function(p26)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_9, (ref) v_u_7, (ref) v_u_8
			local v27 = workspace:Raycast(p26.Position + Vector3.new(0, 2, 0), Vector3.new(0, -4, 0), _G.MapParams)
			if v27 then
				local v28 = v_u_6.Hiromi.Shockwave:Clone()
				v28.Position = v27.Position
				v28.Parent = workspace.Effects
				local v29 = v28.CFrame
				local v30 = CFrame.Angles
				local v31 = math.random(-179, 179)
				v28.CFrame = v29 * v30(0, math.rad(v31), 0)
				v_u_3:Create(v28.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
					["Scale"] = Vector3.new(15, 0, 15)
				}):Play()
				v_u_3:Create(v28.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
					["Transparency"] = 1
				}):Play()
				v28.Floor.Glow:Emit(1)
				v28.Floor.Ring:Emit(10)
				v_u_2:AddItem(v28, 1.5)
				local v32 = v_u_6.Yuta.Veilstep.CEImpact:Clone()
				v32.Position = v27.Position
				v32.Parent = workspace.Effects
				v_u_2:AddItem(v32, 2)
				v_u_3:Create(v32.PointLight, TweenInfo.new(0.6), {
					["Brightness"] = 0
				}):Play()
				v32.Glow:Emit(1)
				v32.Sparks:Emit(50)
				v32.Sparks2:Emit(20)
				v32.Wind2:Emit(7)
				v_u_3:Create(v32.Air, TweenInfo.new(0.2), {
					["Position"] = Vector3.new(0, 0, 0)
				}):Play()
				v_u_9:PlaySound(v_u_7.Hakari.Shock, v32, game.SoundService.Effect)
				v_u_9:PlaySound(v_u_7.Yuta.VeilstepHit, v32, game.SoundService.Effect)
				v_u_9:PlaySound(v_u_7.Hakari.Impact, v32, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v27.Position).Magnitude < 150 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
			if (p26.Position - workspace.CurrentCamera.CFrame.Position).Magnitude < 25 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["SpinRing"] = function(p33)
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			local v34 = p33:FindFirstChild("HumanoidRootPart")
			if v34 then
				local v35 = v_u_6.Yuta.Veilstep.Spin.SpinRing:Clone()
				v35.Parent = v34
				v_u_2:AddItem(v35, 0.5)
				v35.Ring:Emit(10)
			end
		end,
		["Hit"] = function(p36, p37)
			-- upvalues: (ref) v_u_9, (ref) v_u_7
			local v38 = p36:FindFirstChild("HumanoidRootPart")
			if v38 then
				v_u_9:Flash(p36, p37 and Color3.fromRGB(255, 170, 255) or Color3.new(1, 1, 1))
				local v39 = v_u_9:PlaySound(v_u_7.Yuta.M1.Hit4, v38, game.SoundService.Effect)
				v39.Volume = v39.Volume * 2
			end
		end,
		["DiveHitbox"] = function(p40, p41, p42)
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_12
			local v43 = p40:FindFirstChild("HumanoidRootPart")
			if not v43 then
				return
			end
			local v44 = p40:FindFirstChild("Right Arm")
			if not v44 then
				return
			end
			local v_u_45 = v_u_9:PlaySound(v_u_7.Yuta.VeilstepDive, v43, game.SoundService.Effect)
			p41.AncestryChanged:Once(function()
				-- upvalues: (copy) v_u_45
				v_u_45:Destroy()
			end)
			if p40 == v_u_4.Character then
				while true do
					local v46 = workspace:Raycast(v44.Position, p41.Velocity.Unit * 10, v_u_12)
					if v46 then
						p42:FireServer(v46.Position, v46.Normal)
						p41:Destroy()
					end
					task.wait(0.025)
					if not p41.Parent then
						goto l6
					end
				end
			else
				::l6::
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p48, ...)
		-- upvalues: (copy) v_u_47
		local v49 = v_u_47[p48]
		if v49 then
			v49(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_9
	v_u_10 = v_u_1.GetService("VeilstepService")
	v_u_9 = v_u_1.GetController("FXController")
end
return v11