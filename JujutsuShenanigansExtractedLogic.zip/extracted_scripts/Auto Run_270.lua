-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 1,
	["SortOrder"] = 2,
	["Val"] = "AutoRun",
	["Desc"] = "lazy man >:P"
}