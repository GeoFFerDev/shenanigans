-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

game:GetService("ReplicatedStorage")
local v_u_1 = game:GetService("TweenService")
game:GetService("SoundService")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("RunService")
local v4 = game:GetService("Players")
local v5 = script.Parent.Des
local v_u_6 = require(v5.Signal)
local v_u_7 = require(v5.Trove)
local v_u_8 = v4.LocalPlayer
local v_u_9 = v_u_8.PlayerGui
local v_u_10 = require("@self/Controller")
local v_u_11 = require("@self/Knifes")
local v_u_12 = require("@self/Sweep")
local v_u_13 = require("@self/Shake")
local v_u_14 = require("@self/Bits")
local v_u_15 = require("@self/Gray")
local v_u_16 = require("@self/Flower")
local v_u_17 = require("@self/Helper")
local v_u_18 = require("@self/Sequencer")
local v_u_19 = script.Assets.Sounds
local v_u_20 = script.Assets.GUI
local v_u_21 = script.Assets.Chara
local v_u_22 = script.Assets.Animations
local v_u_23 = {
	["IN"] = TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.In),
	["FADE"] = TweenInfo.new(0.45, Enum.EasingStyle.Cubic, Enum.EasingDirection.InOut),
	["FLICKER"] = TweenInfo.new(0.08, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut),
	["HEART"] = TweenInfo.new(0.08, Enum.EasingStyle.Linear, Enum.EasingDirection.In)
}
local v_u_24 = Random.new()
local v_u_25 = script.Assets.Sprites
local v_u_26 = {}
v_u_26.__index = v_u_26
local v_u_27 = nil
local function v_u_29(p28)
	-- upvalues: (copy) v_u_17, (copy) v_u_19
	v_u_17.playLocalSound(v_u_19, p28)
end
function v_u_26._stepAspect(p_u_30, p31)
	-- upvalues: (copy) v_u_17
	local v32 = v_u_17.toSec(p31)
	local v_u_33 = p_u_30.AspectRatio
	local v34 = p_u_30.State.Arena.Ratio
	local v_u_35 = p_u_30.Arena.Parent.AbsoluteSize
	local function v50()
		-- upvalues: (copy) p_u_30, (copy) v_u_35, (copy) v_u_33
		local v36 = p_u_30.State.Arena.Kind == "2D" and p_u_30.State.Arena.ActualSize or UDim2.new(p_u_30.State.Arena.ActualSize.X.Scale, 0, 0, p_u_30.State.Player.Size.Y * 1.5)
		local v37 = v_u_35.X * v36.X.Scale + v36.X.Offset
		local v38 = v_u_35.Y * v36.Y.Scale + v36.Y.Offset
		local v39 = Vector2.new(v37, v38)
		local v40 = v39.X
		local v41 = v39.Y
		local v42 = v40 / math.max(1, v41)
		local v43 = v_u_33.Parent == p_u_30.Arena and v_u_33.AspectRatio
		if not v43 then
			local v44 = p_u_30.Arena.Size
			local v45 = v_u_35.X * v44.X.Scale + v44.X.Offset
			local v46 = v_u_35.Y * v44.Y.Scale + v44.Y.Offset
			local v47 = Vector2.new(v45, v46)
			local v48 = v47.Y
			local v49 = math.max(1, v48)
			v43 = v47.X / v49
		end
		p_u_30.Aspect.active = true
		p_u_30.Aspect.disabling = true
		p_u_30.Aspect.t = 0
		p_u_30.Aspect.from = v43
		p_u_30.Aspect.to = v42
		if v_u_33.Parent ~= p_u_30.Arena then
			v_u_33.Parent = p_u_30.Arena
		end
		v_u_33.AspectRatio = v43
	end
	if v34 == nil then
		if v_u_33.Parent == p_u_30.Arena and not p_u_30.Aspect.disabling then
			v50()
		end
	elseif p_u_30.Aspect.active or v_u_33.Parent == p_u_30.Arena then
		if p_u_30.Aspect.active and (not p_u_30.Aspect.disabling and p_u_30.Aspect.to ~= v34) then
			p_u_30.Aspect.to = v34
		end
	else
		local v51 = p_u_30.Arena.Size
		local v52 = v_u_35.X * v51.X.Scale + v51.X.Offset
		local v53 = v_u_35.Y * v51.Y.Scale + v51.Y.Offset
		local v54 = Vector2.new(v52, v53)
		local v55 = v54.Y
		local v56 = math.max(1, v55)
		local v57 = v54.X / v56
		p_u_30.Aspect.active = true
		p_u_30.Aspect.disabling = false
		p_u_30.Aspect.t = 0
		p_u_30.Aspect.from = v57
		p_u_30.Aspect.to = v34
		v_u_33.Parent = p_u_30.Arena
		v_u_33.AspectRatio = v57
	end
	if p_u_30.Aspect.active then
		local v58 = p_u_30.Aspect
		local v59 = p_u_30.Aspect.t + v32 / p_u_30.Aspect.dur
		v58.t = math.min(1, v59)
		local v60 = v_u_17.easeInOutCubic(p_u_30.Aspect.t)
		local v61 = p_u_30.Aspect.from
		local v62 = p_u_30.Aspect.to
		v_u_33.AspectRatio = math.lerp(v61, v62, v60)
		if p_u_30.Aspect.t >= 1 then
			if p_u_30.Aspect.disabling then
				v_u_33.Parent = script
			end
			p_u_30.Aspect.active = false
			p_u_30.Aspect.disabling = false
		end
	end
end
function v_u_26._setupIntro(p63)
	-- upvalues: (copy) v_u_1, (copy) v_u_23, (copy) v_u_17
	if p63._Stopped then
		return
	else
		local v64 = p63.GUI.Canvas.Heart
		local v65 = p63.Arena.Contents.Controller
		local v66 = v65.AbsoluteSize
		v64.ImageTransparency = 1
		v64.AnchorPoint = Vector2.new(0.5, 0.5)
		v64.Position = UDim2.fromScale(0.5, 0.5)
		v64.Size = UDim2.fromOffset(v66.X, v66.Y)
		p63.GUI.Canvas.Decorations.GroupTransparency = 1
		p63.GUI.Canvas.Contents.GroupTransparency = 1
		v_u_1:Create(p63.GUI.Canvas.Decorations, v_u_23.FADE, {
			["GroupTransparency"] = 0
		}):Play()
		for _ = 1, 4 do
			if p63._Stopped then
				return
			end
			v_u_1:Create(v64, v_u_23.FLICKER, {
				["ImageTransparency"] = 0
			}):Play()
			task.wait(0.08)
			v_u_1:Create(v64, v_u_23.FLICKER, {
				["ImageTransparency"] = 0.85
			}):Play()
			task.wait(0.08)
		end
		v_u_1:Create(v64, v_u_23.HEART, {
			["ImageTransparency"] = 0
		}):Play()
		local v67 = v_u_17.centerAbs(v65)
		local v68 = v_u_17.centerAbs(v64.Parent)
		local v69 = v_u_17.roundpx(v67.X - v68.X)
		local v70 = v_u_17.roundpx(v67.Y - v68.Y)
		local v71 = v_u_1:Create(v64, v_u_23.IN, {
			["Position"] = UDim2.new(0.5, v69, 0.5, v70)
		})
		v71:Play()
		v71.Completed:Wait()
		if not p63._Stopped then
			v_u_1:Create(p63.GUI.Canvas.Contents, v_u_23.FADE, {
				["GroupTransparency"] = 0
			}):Play()
			v64:Destroy()
		end
	end
end
function v_u_26._setupViewport(p72)
	-- upvalues: (copy) v_u_21, (copy) v_u_22
	local v73 = p72.Character.Viewport
	local v74 = Instance.new("Camera")
	v74.CFrame = CFrame.new(0, 0.5, -6) * CFrame.Angles(0, 3.141592653589793, 0)
	v74.Parent = v73
	v73.CurrentCamera = v74
	local v75 = v_u_21:Clone()
	v75.Parent = v73.WorldModel
	v75:PivotTo(CFrame.new())
	v75.Humanoid.Animator:LoadAnimation(v_u_22.Idle):Play()
end
function v_u_26._breakNow(p76)
	if not p76._Broken then
		p76._Broken = true
		p76.Controller:Break()
		if p76.Sequencer then
			p76.Sequencer:Stop()
		end
	end
end
function v_u_26.setRatio(p77, p78)
	p77.State.Arena.Ratio = p78
end
function v_u_26.setSize(p79, p80)
	if p80 then
		p79.State.Arena.ActualSize = p80
	else
		p79.State.Arena.ActualSize = UDim2.fromScale(0.53, 0.4)
	end
end
function v_u_26.setKind(p81, p82)
	p81.State.Arena.Kind = p82
end
function v_u_26.Initialize(p_u_83)
	-- upvalues: (copy) v_u_20, (copy) v_u_9, (copy) v_u_8, (copy) v_u_17, (copy) v_u_25, (copy) v_u_19
	p_u_83.GUI = v_u_20:Clone()
	p_u_83.GUI.Parent = v_u_9
	p_u_83.Character = p_u_83.GUI.Canvas.Contents.Character
	p_u_83.Actions = p_u_83.GUI.Canvas.Contents.Actions
	p_u_83.Status = p_u_83.GUI.Canvas.Contents.Status
	p_u_83.Arena = p_u_83.GUI.Canvas.Contents.Arena
	p_u_83.AspectRatio = Instance.new("UIAspectRatioConstraint")
	p_u_83.AspectRatio.Parent = script
	p_u_83.Status.User.Text = v_u_8.Name
	p_u_83.State.Arena.BaselineMin = p_u_83.Arena.Contents.AbsoluteSize.X
	p_u_83.State.Arena.Size = p_u_83.Arena.Contents.AbsoluteSize
	p_u_83.Trove:Connect(p_u_83.Arena.Contents:GetPropertyChangedSignal("AbsoluteSize"), function()
		-- upvalues: (copy) p_u_83
		p_u_83.State.Arena.BaselineMin = p_u_83.Arena.Contents.AbsoluteSize.X
		p_u_83.State.Arena.Size = p_u_83.Arena.Contents.AbsoluteSize
	end)
	local v84 = v_u_17.unitScale(p_u_83.Arena.Contents, p_u_83.State.Arena.BaselineMin)
	p_u_83.GUI.Canvas.Heart.Size = v_u_17.scaleUDim2(UDim2.fromOffset(16, 16), v84)
	p_u_83.Arena.Contents.Controller.Size = v_u_17.scaleUDim2(UDim2.fromOffset(16, 16), v84)
	for _, v85 in ipairs(v_u_25:GetDescendants()) do
		if v85:IsA("ImageLabel") and not v85:GetAttribute("keepSize") then
			if not v85:GetAttribute("Size") then
				v85:SetAttribute("Size", v85.Size)
			end
			v85.Size = v_u_17.scaleUDim2(v85:GetAttribute("Size"), v84)
		end
	end
	v_u_17.playLocalSound(v_u_19, "Start")
	p_u_83:_setupViewport()
	p_u_83:_setupIntro()
end
function v_u_26.Stop(p_u_86, _)
	-- upvalues: (copy) v_u_17, (copy) v_u_1, (copy) v_u_23, (ref) v_u_27
	if not p_u_86._Stopped then
		p_u_86._Stopped = true
		v_u_17.stopLocalSounds()
		if p_u_86.Sequencer then
			p_u_86.Sequencer:Stop()
		end
		v_u_1:Create(p_u_86.GUI.Canvas.Contents, v_u_23.FADE, {
			["GroupTransparency"] = 1
		}):Play()
		v_u_1:Create(p_u_86.GUI.Canvas.Decorations, v_u_23.FADE, {
			["GroupTransparency"] = 1
		}):Play()
		task.delay(v_u_23.FADE.Time, function()
			-- upvalues: (ref) v_u_27, (copy) p_u_86
			if v_u_27 == p_u_86 then
				v_u_27 = nil
			end
			p_u_86:Destroy()
		end)
	end
end
function v_u_26.new(p_u_87)
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_26, (copy) v_u_8, (copy) v_u_10, (copy) v_u_13, (copy) v_u_18, (copy) v_u_3, (copy) v_u_17, (copy) v_u_11, (copy) v_u_16, (copy) v_u_12, (copy) v_u_14, (copy) v_u_15, (copy) v_u_29, (copy) v_u_24
	local v88 = {
		["Trove"] = v_u_7.new(),
		["Signals"] = {
			["spawnSound"] = v_u_6.new(),
			["onDamage"] = v_u_6.new(),
			["onShake"] = v_u_6.new()
		},
		["UUID"] = v_u_2:GenerateGUID(false)
	}
	local v89 = v_u_26
	local v_u_90 = setmetatable(v88, v89)
	local v91 = v_u_8.Character
	if v91 then
		v91 = v91:FindFirstChildOfClass("Humanoid")
	end
	if v91 then
		v_u_90.Humanoid = v91
		local v92 = {
			["Player"] = {
				["Size"] = Vector2.new(),
				["Pos"] = Vector2.new(),
				["Vel"] = Vector2.new(),
				["Req"] = Vector2.new(),
				["Accel"] = 0.12,
				["Speed"] = 3,
				["_Locked"] = false,
				["_Tick"] = 0,
				["_Held"] = {}
			},
			["Arena"] = {
				["ActualSize"] = UDim2.fromScale(0.53, 0.4),
				["BaselineMin"] = Vector2.new(),
				["Size"] = Vector2.new(),
				["Kind"] = "2D",
				["Ratio"] = nil
			},
			["Attacks"] = {},
			["Visuals"] = {}
		}
		v_u_90.State = v92
		v_u_90.Aspect = {
			["active"] = false,
			["disabling"] = false,
			["t"] = 0,
			["dur"] = 0.28,
			["from"] = nil,
			["to"] = nil
		}
		v_u_90:Initialize()
		local v93 = v_u_90.Arena.Contents.Controller
		v_u_90.Controller = v_u_10.new(v_u_90.Trove, v_u_90.Signals, v_u_90.State, v93, v_u_90.GUI)
		v_u_90.Shake = v_u_13.new(v_u_90.Trove, v_u_90.State, v_u_90.Arena)
		v_u_90.Sequencer = v_u_18.new(v_u_90.Trove, v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, v_u_90.GUI)
		v_u_90.Trove:Connect(v_u_3.PostSimulation, function(p94)
			-- upvalues: (copy) v_u_90, (ref) v_u_17, (ref) v_u_11, (ref) v_u_16, (ref) v_u_12, (ref) v_u_14, (ref) v_u_15
			if not v_u_90._Stopped then
				local v95 = v_u_17.toFrame(p94)
				v_u_90:Step(v95)
				v_u_90.Controller:Step(v95)
				v_u_90.Shake:Step(v95)
				v_u_11.Step(v95)
				v_u_16.Step(v95)
				v_u_12.Step(v95)
				v_u_14.Step(v95)
				v_u_15.Step(v95)
			end
		end)
		v_u_90.Trove:Connect(v_u_90.Signals.onDamage, function(p96)
			-- upvalues: (copy) v_u_90, (copy) p_u_87
			local v97 = v_u_90.Humanoid
			local v98 = v_u_90.Humanoid.Health - p96
			local v99 = v_u_90.Humanoid.MaxHealth
			v97.Health = math.clamp(v98, 1, v99)
			v_u_90.Shake:Shake({
				["amp"] = 12,
				["freq"] = 10,
				["duration"] = 0.2,
				["falloff"] = "cubic"
			})
			p_u_87:FireServer(p96)
			if v_u_90.Humanoid.Health <= 1 then
				v_u_90:_breakNow()
				task.delay(3, function()
					-- upvalues: (ref) v_u_90
					if v_u_90.Stop and not v_u_90._Stopped then
						v_u_90:Stop("fail")
					end
				end)
			end
		end)
		v_u_90.Trove:Connect(v_u_90.Signals.onShake, function(p100)
			-- upvalues: (copy) v_u_90
			v_u_90.Shake:Shake(p100)
		end)
		v_u_90.Trove:Connect(v_u_90.Signals.spawnSound, v_u_29)
		v_u_90.Trove:Add(v_u_90.Signals.spawnSound)
		v_u_90.Trove:Add(v_u_90.Signals.onDamage)
		v_u_90.Trove:Add(v_u_90.Signals.onShake)
		v_u_90.Trove:Add(v_u_90.GUI)
		local v102 = {
			["id"] = "Pattern.A",
			["time"] = 2.4,
			["run"] = function()
				-- upvalues: (copy) v_u_90, (ref) v_u_12, (ref) v_u_11, (ref) v_u_24
				v_u_90:setRatio(1)
				v_u_90:setKind("2D")
				v_u_90:setSize(UDim2.fromScale(0.4, 0.3))
				v_u_90.Sequencer:Defer(0.2, function()
					-- upvalues: (ref) v_u_90, (ref) v_u_12
					for _ = 1, 5 do
						if not v_u_90.Sequencer:_sleep(0.3) then
							break
						end
						v_u_12.newSweep(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, "Horizontal", {
							["fromGui"] = v_u_90.Arena.Contents,
							["targetPos"] = v_u_90.State.Player.Pos
						})
					end
				end)
				local v101 = { "Right", "Left" }
				for _ = 1, 12 do
					if not v_u_90.Sequencer:_sleep(0.2) then
						break
					end
					v_u_11.new(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, "Normal", {
						["fromGui"] = v_u_90.Arena.Contents,
						["spawnSide"] = v101[v_u_24:NextInteger(1, 2)]
					})
				end
			end
		}
		v_u_90.Sequencer:setBetween(0.45, 0.55):AddEntry(v102):AddEntry({
			["id"] = "Pattern.A",
			["time"] = 2.4,
			["run"] = function()
				-- upvalues: (copy) v_u_90, (ref) v_u_11
				v_u_90:setRatio()
				v_u_90:setKind("2D")
				v_u_90:setSize()
				v_u_90.Sequencer:Defer(0.2, function()
					-- upvalues: (ref) v_u_90, (ref) v_u_11
					for _ = 1, 3 do
						if not v_u_90.Sequencer:_sleep(0.6) then
							break
						end
						v_u_11.new(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, "Normal", {
							["fromGui"] = v_u_90.Arena.Contents,
							["indicated"] = true
						})
					end
				end)
				for _ = 1, 12 do
					if not v_u_90.Sequencer:_sleep(0.2) then
						break
					end
					v_u_11.new(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, "Normal", {
						["fromGui"] = v_u_90.Arena.Contents,
						["targetPos"] = v_u_90.State.Player.Pos
					})
				end
			end
		}):AddEntry({
			["id"] = "Pattern.B",
			["time"] = 2,
			["run"] = function()
				-- upvalues: (copy) v_u_90, (ref) v_u_17, (ref) v_u_12, (ref) v_u_24
				v_u_90:setRatio()
				v_u_90:setKind("2D")
				v_u_90:setSize()
				local v103 = v_u_17.gridCenters(v_u_90.Arena.Contents, 3, 3, 12)
				local v104 = { "Horizontal", "Vertical", "Both" }
				for _, v105 in ipairs(v103) do
					if not v_u_90.Sequencer:_sleep(0.15) then
						break
					end
					v_u_12.newSweep(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, v104[v_u_24:NextInteger(1, 3)], {
						["fromGui"] = v_u_90.Arena.Contents,
						["targetPos"] = v105
					})
				end
			end
		}):AddEntry({
			["id"] = "Pattern.B",
			["time"] = 2.7,
			["run"] = function()
				-- upvalues: (copy) v_u_90, (ref) v_u_17, (ref) v_u_12, (ref) v_u_11
				v_u_90:setRatio()
				v_u_90:setKind("2D")
				v_u_90:setSize()
				local v106 = v_u_17.gridCenters(v_u_90.Arena.Contents, 4, 5, 12)
				for _, v107 in ipairs(v106) do
					v_u_12.newSweep(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, "Both", {
						["fromGui"] = v_u_90.Arena.Contents,
						["targetPos"] = v107,
						["telegraph"] = 1.9,
						["expand"] = 0.22,
						["shrink"] = 0.3,
						["thickness"] = 12,
						["flashRate"] = 9,
						["damage"] = 6,
						["slash"] = 2
					})
				end
				v_u_90.Sequencer:Defer(0.95, function()
					-- upvalues: (ref) v_u_90, (ref) v_u_11
					for _ = 1, 6 do
						if not v_u_90.Sequencer:_sleep(0.15) then
							break
						end
						v_u_11.new(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, "StillPunish", {
							["fromGui"] = v_u_90.Arena.Contents,
							["targetPos"] = v_u_90.State.Player.Pos
						})
					end
				end)
			end
		}):AddEntry({
			["id"] = "Pattern.B",
			["time"] = 2.9,
			["run"] = function()
				-- upvalues: (copy) v_u_90, (ref) v_u_12, (ref) v_u_11
				v_u_90:setRatio(1)
				v_u_90:setKind("2D")
				v_u_90:setSize()
				v_u_12.newSpin(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, {
					["fromGui"] = v_u_90.Arena.Contents
				})
				v_u_90.Sequencer:Defer(0.5, function()
					-- upvalues: (ref) v_u_90, (ref) v_u_11
					for _ = 1, 12 do
						if not v_u_90.Sequencer:_sleep(0.15) then
							break
						end
						v_u_11.new(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, "MovePunish", {
							["fromGui"] = v_u_90.Arena.Contents
						})
					end
				end)
			end
		}):AddEntry({
			["id"] = "Pattern.B",
			["time"] = 3,
			["run"] = function()
				-- upvalues: (copy) v_u_90, (ref) v_u_12
				v_u_90:setRatio()
				v_u_90:setKind("1D")
				v_u_90:setSize(UDim2.fromScale(0.4, 0.3))
				for _ = 1, 12 do
					if not v_u_90.Sequencer:_sleep(0.2) then
						break
					end
					v_u_12.newSweep(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, "Vertical", {
						["targetPos"] = v_u_90.State.Player.Pos,
						["thickness"] = 24
					})
				end
			end
		}):AddEntry({
			["id"] = "Flowers.A",
			["time"] = 1.1,
			["run"] = function()
				-- upvalues: (copy) v_u_90, (ref) v_u_16
				v_u_90:setRatio()
				v_u_90:setKind("2D")
				v_u_90:setSize()
				for _ = 1, 3 do
					if not v_u_90.Sequencer:_sleep(0.3) then
						break
					end
					v_u_16.new(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, {
						["fromGui"] = v_u_90.Arena.Contents,
						["targetPos"] = v_u_90.State.Player.Pos,
						["spawnSide"] = "Top"
					})
				end
			end
		}):AddEntry({
			["id"] = "Flowers.B",
			["time"] = 0.15,
			["run"] = function()
				-- upvalues: (ref) v_u_16, (copy) v_u_90
				v_u_16.new(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, {
					["fromGui"] = v_u_90.Arena.Contents,
					["targetPos"] = v_u_90.State.Player.Pos,
					["spawnSide"] = "Top"
				})
			end
		}):AddEntry({
			["id"] = "Hearts.A",
			["time"] = 1,
			["run"] = function()
				-- upvalues: (copy) v_u_90, (ref) v_u_15
				v_u_90:setRatio()
				v_u_90:setKind("2D")
				v_u_90:setSize()
				for _ = 1, 3 do
					if not v_u_90.Sequencer:_sleep(0.3) then
						break
					end
					v_u_15.new(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, {
						["fromGui"] = v_u_90.Arena.Contents
					})
				end
			end
		}):AddEntry({
			["id"] = "Hearts.B",
			["time"] = 0.15,
			["run"] = function()
				-- upvalues: (ref) v_u_15, (copy) v_u_90
				v_u_15.new(v_u_90.Signals, v_u_90.State, v_u_90.Arena.Contents, {
					["fromGui"] = v_u_90.Arena.Contents
				})
			end
		})
		v_u_90.Sequencer:Start()
		return v_u_90
	end
	v_u_90:Destroy()
end
function v_u_26.Step(p108, p109)
	-- upvalues: (copy) v_u_17
	local v110 = v_u_17.easeOutCubic
	local v111 = p109 * -1
	local v112 = v110(1 - math.exp(v111))
	p108:_stepAspect(p109)
	local v113 = p108.State.Player
	local v114 = p108.State.Arena
	local v115 = p108.Arena.Size
	local v116
	if v114.Kind == "2D" then
		v116 = v114.ActualSize
	else
		v116 = UDim2.new(v114.ActualSize.X.Scale, 0, 0, v113.Size.Y * 1.75)
	end
	p108.Arena.Size = v115:Lerp(v116, v112)
	local v117 = p108.Humanoid.Health
	local v118 = p108.Humanoid.MaxHealth
	local v119 = p108.Status.Health.Contents.Fill
	local v120 = v117 / v118
	local v121 = math.clamp(v120, 0, 1)
	v119.Size = v119.Size:Lerp(UDim2.fromScale(v121, 1), v112)
end
function v_u_26.Destroy(p122)
	p122.Trove:Destroy()
	if p122.GUI then
		p122.GUI:Destroy()
	end
	table.clear(p122)
	setmetatable(p122, nil)
end
function v_u_26.DoEvent(p123)
	-- upvalues: (ref) v_u_27, (copy) v_u_26, (copy) v_u_8
	if not v_u_27 or v_u_27._Stopped then
		v_u_27 = v_u_26.new(p123)
		v_u_8:GetAttributeChangedSignal("InMinigame"):Once(function()
			-- upvalues: (ref) v_u_27
			if v_u_27 ~= nil then
				v_u_27:Stop()
			end
		end)
	end
end
return v_u_26