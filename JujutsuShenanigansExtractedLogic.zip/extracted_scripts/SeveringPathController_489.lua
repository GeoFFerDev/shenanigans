-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local v_u_4 = v3.Utils
local v_u_5 = v3.Sounds
require(v3.Modules.CameraShaker)
local v_u_6 = nil
local v_u_7 = nil
local v8 = v_u_1.CreateController({
	["Name"] = "SeveringPathController"
})
local v_u_9 = {
	15,
	-15,
	-20,
	60,
	-30,
	-15,
	30,
	0,
	80
}
function v8.KnitStart(_)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (ref) v_u_6, (copy) v_u_5, (copy) v_u_9, (ref) v_u_7
	local v_u_37 = {
		["Start"] = function(p10)
			-- upvalues: (ref) v_u_4, (ref) v_u_2, (ref) v_u_6, (ref) v_u_5
			local v11 = p10.SetAssets:FindFirstChild("YutaSword")
			if v11 then
				local v12 = p10:FindFirstChild("HumanoidRootPart")
				if v12 then
					local v13 = v11.Sword.Blade
					local v14 = v_u_4.Yuta.ResoluteSlash.SwordBurst.Attachment0:Clone()
					local v15 = v_u_4.Yuta.ResoluteSlash.SwordBurst.Center:Clone()
					v14.Parent = v13
					v15.Parent = v13
					v_u_2:AddItem(v14, 0.5)
					v_u_2:AddItem(v15, 4)
					v14.Burst1:Emit(1)
					v15.Burst2:Emit(1)
					local v16 = v_u_6:PlaySound(v_u_5.Yuta.Leap, v12, game.SoundService.Effect)
					v16.Volume = 0.5
					v16.PlaybackSpeed = 1.5
					task.wait(0.3)
					v15:Destroy()
					local v17 = v_u_4.Yuta.ResoluteSlash.SwordBurst.Sparks:Clone()
					v17.Parent = v13
					v_u_2:AddItem(v17, 0.7)
					v17:Emit(30)
				end
			else
				return
			end
		end,
		["Swing"] = function(p18, p19)
			-- upvalues: (ref) v_u_6, (ref) v_u_5
			local v20 = p18:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = v_u_6:PlaySound(v_u_5.Yuta.M1:FindFirstChild("Swing" .. math.random(1, 3)), v20, game.SoundService.Effect)
				if not p19 then
					v21.PlaybackSpeed = 1.2
				end
			end
		end,
		["PunchSwing"] = function(p22)
			-- upvalues: (ref) v_u_6, (ref) v_u_5
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			if v23 then
				v_u_6:PlaySound(v_u_5.Hiromi.Throw2, v23, game.SoundService.Effect).PlaybackSpeed = math.random(9, 11) / 10
			end
		end,
		["Hit"] = function(p24, p25, p26)
			-- upvalues: (ref) v_u_6, (ref) v_u_5, (ref) v_u_4, (ref) v_u_9, (ref) v_u_2
			local v27 = p24:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v28 = p25:FindFirstChild("HumanoidRootPart")
				if v28 then
					v_u_6:Flash(p25, Color3.fromRGB(255, 170, 255))
					local v29 = p26 % 3
					local v30 = v29 == 0 and 3 or v29
					v_u_6:PlaySound(v_u_5.Yuta.M1:FindFirstChild("Hit" .. v30), v28, game.SoundService.Effect)
					local v31 = v_u_4.Yuta.SlashHit:Clone()
					v31.Slash.Color = ColorSequence.new(Color3.fromRGB(255, 85, 255))
					local v32 = CFrame.lookAlong(v28.Position, v27.CFrame.LookVector)
					local v33 = CFrame.Angles
					local v34 = v_u_9[p26] or 0
					v31.CFrame = v32 * v33(0, 0, (math.rad(v34)))
					v31.Parent = workspace.Effects
					v_u_2:AddItem(v31, 0.5)
					v31.Slash:Emit(5)
				end
			else
				return
			end
		end,
		["AirHit"] = function(p35, _)
			-- upvalues: (ref) v_u_6, (ref) v_u_5
			local v36 = p35:FindFirstChild("HumanoidRootPart")
			if v36 then
				v_u_6:Flash(p35, Color3.new(1, 1, 1))
				v_u_6:PlaySound(v_u_5.Yuta.M1.Hit4, v36, game.SoundService.Effect)
			end
		end
	}
	v_u_7.Effects:Connect(function(p38, ...)
		-- upvalues: (copy) v_u_37
		local v39 = v_u_37[p38]
		if v39 then
			v39(...)
		end
	end)
end
function v8.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_6
	v_u_7 = v_u_1.GetService("SeveringPathService")
	v_u_6 = v_u_1.GetController("FXController")
end
return v8