-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "emote",
	["Description"] = "Adds / Remove an emote from a player\'s inventory",
	["Group"] = { "Owner", "Developer" },
	["Args"] = {
		{
			["Type"] = "player",
			["Name"] = "Player"
		},
		{
			["Type"] = "string",
			["Name"] = "Emote"
		},
		{
			["Type"] = "boolean",
			["Name"] = "Clear"
		}
	}
}
return v1