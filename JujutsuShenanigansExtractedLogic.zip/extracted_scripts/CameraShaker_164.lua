-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local _ = game:GetService("Players").LocalPlayer
local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = debug.profilebegin
local v_u_3 = debug.profileend
local v4 = Vector3.new
local v_u_5 = CFrame.new
local v_u_6 = CFrame.Angles
local v_u_7 = math.rad
local v_u_8 = v4()
local v_u_9 = require(script.CameraShakeInstance)
local v_u_10 = v_u_9.CameraShakeState
v_u_1.CameraShakeInstance = v_u_9
v_u_1.Presets = require(script.CameraShakePresets)
function v_u_1.new(p11, p12)
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	local v13 = type(p11) == "number"
	assert(v13, "RenderPriority must be a number (e.g.: Enum.RenderPriority.Camera.Value)")
	local v14 = type(p12) == "function"
	assert(v14, "Callback must be a function")
	local v15 = {
		["_running"] = false,
		["_renderName"] = "CameraShaker",
		["_renderPriority"] = p11,
		["_posAddShake"] = v_u_8,
		["_rotAddShake"] = v_u_8,
		["_camShakeInstances"] = {},
		["_removeInstances"] = {},
		["_callback"] = p12
	}
	local v16 = v_u_1
	return setmetatable(v15, v16)
end
function v_u_1.Start(p_u_17)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if not p_u_17._running then
		p_u_17._running = true
		local v_u_18 = p_u_17._callback
		game:GetService("RunService"):BindToRenderStep(p_u_17._renderName, p_u_17._renderPriority, function(p19)
			-- upvalues: (ref) v_u_2, (copy) p_u_17, (ref) v_u_3, (copy) v_u_18
			v_u_2("CameraShakerUpdate")
			local v20 = p_u_17:Update(p19)
			v_u_3()
			v_u_18(v20)
		end)
	end
end
function v_u_1.Stop(p21)
	if p21._running then
		game:GetService("RunService"):UnbindFromRenderStep(p21._renderName)
		p21._running = false
	end
end
function v_u_1.StopSustained(p22, p23)
	for _, v24 in pairs(p22._camShakeInstances) do
		if v24.fadeOutDuration == 0 then
			v24:StartFadeOut(p23 or v24.fadeInDuration)
		end
	end
end
function v_u_1.Update(p25, p26)
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7
	local v27 = v_u_8
	local v28 = v_u_8
	local v29 = p25._camShakeInstances
	for v30 = 1, #v29 do
		local v31 = v29[v30]
		local v32 = v31:GetState()
		if v32 == v_u_10.Inactive and v31.DeleteOnInactive then
			p25._removeInstances[#p25._removeInstances + 1] = v30
		elseif v32 ~= v_u_10.Inactive then
			local v33 = v31:UpdateShake(p26)
			v27 = v27 + v33 * v31.PositionInfluence
			v28 = v28 + v33 * v31.RotationInfluence
		end
	end
	for v34 = #p25._removeInstances, 1, -1 do
		local v35 = p25._removeInstances[v34]
		table.remove(v29, v35)
		p25._removeInstances[v34] = nil
	end
	return v_u_5(v27) * v_u_6(0, v_u_7(v28.Y), 0) * v_u_6(v_u_7(v28.X), 0, (v_u_7(v28.Z)))
end
local v_u_36 = {
	["StartFadeOut"] = function() end,
	["StartFadeIn"] = function() end
}
function v_u_1.Shake(p37, p38)
	-- upvalues: (copy) v_u_36
	if not _G.Settings.ScreenShake then
		return v_u_36
	end
	local v39
	if type(p38) == "table" then
		v39 = p38._camShakeInstance
	else
		v39 = false
	end
	assert(v39, "ShakeInstance must be of type CameraShakeInstance")
	p37._camShakeInstances[#p37._camShakeInstances + 1] = p38
	return p38
end
function v_u_1.ShakeSustain(p40, p41)
	-- upvalues: (copy) v_u_36
	if not _G.Settings.ScreenShake then
		return v_u_36
	end
	local v42
	if type(p41) == "table" then
		v42 = p41._camShakeInstance
	else
		v42 = false
	end
	assert(v42, "ShakeInstance must be of type CameraShakeInstance")
	p40._camShakeInstances[#p40._camShakeInstances + 1] = p41
	p41:StartFadeIn(p41.fadeInDuration)
	return p41
end
function v_u_1.ShakeOnce(p43, p44, p45, p46, p47, p48, p49)
	-- upvalues: (copy) v_u_36, (copy) v_u_9
	if not _G.Settings.ScreenShake then
		return v_u_36
	end
	local v50 = v_u_9.new(p44, p45, p46, p47)
	v50.PositionInfluence = typeof(p48) == "Vector3" and p48 and p48 or Vector3.new(0.15, 0.15, 0.15)
	v50.RotationInfluence = typeof(p49) == "Vector3" and p49 and p49 or Vector3.new(1, 1, 1)
	p43._camShakeInstances[#p43._camShakeInstances + 1] = v50
	return v50
end
function v_u_1.StartShake(p51, p52, p53, p54, p55, p56)
	-- upvalues: (copy) v_u_36, (copy) v_u_9
	if not _G.Settings.ScreenShake then
		return v_u_36
	end
	local v57 = v_u_9.new(p52, p53, p54)
	v57.PositionInfluence = typeof(p55) == "Vector3" and p55 and p55 or Vector3.new(0.15, 0.15, 0.15)
	v57.RotationInfluence = typeof(p56) == "Vector3" and p56 and p56 or Vector3.new(1, 1, 1)
	v57:StartFadeIn(p54)
	p51._camShakeInstances[#p51._camShakeInstances + 1] = v57
	return v57
end
local v59 = v_u_1.new(Enum.RenderPriority.Camera.Value, function(p58)
	workspace.CurrentCamera.CFrame = workspace.CurrentCamera.CFrame * p58
end)
v59:Start()
v_u_1.CurrentShaker = v59
return v_u_1