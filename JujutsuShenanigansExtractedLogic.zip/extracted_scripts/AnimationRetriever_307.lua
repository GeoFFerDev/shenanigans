-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = {}
local v_u_2 = {}
v_u_2.__index = v_u_2
local v_u_3 = game:GetService("RunService")
function v_u_2.Clean(p4)
	if p4.Disposal then
		for v5, v6 in next, p4.Disposal do
			local v7 = typeof(v6)
			if v7 == "Instance" then
				v6:Destroy()
			elseif v7 == "RBXScriptConnection" then
				v6:Disconnect()
			elseif v7 == "table" then
				if getmetatable(v6) and rawget(v6, "_RenderName") then
					v6:Stop()
				end
			elseif v7 == "thread" then
				pcall(task.cancel, v6)
			elseif v7 == "function" then
				task.spawn(v6)
			end
			p4.Disposal[v5] = nil
		end
	end
end
function v_u_2.Cleanup(p8)
	p8:Clean()
	table.clear(p8)
end
v_u_2.Destroy = v_u_2.Cleanup
function v_u_2.Task(p9, p10)
	if not p9.Disposal then
		return p10
	end
	local v11 = p9.Disposal
	table.insert(v11, p10)
	return p10
end
function v_u_2.BindToRender(p12, p_u_13, p14, p15)
	-- upvalues: (copy) v_u_3
	if p12.Disposal then
		v_u_3:BindToRenderStep(p_u_13, p14, p15)
		local v16 = p12.Disposal
		local function v17()
			-- upvalues: (ref) v_u_3, (copy) p_u_13
			v_u_3:UnbindFromRenderStep(p_u_13)
		end
		table.insert(v16, v17)
	end
end
function v_u_1.WaitForAnimation(p18, p_u_19, p20)
	local v21 = next
	local v22, v23 = p18:GetPlayingAnimationTracks()
	local v_u_24 = nil
	for _, v25 in v21, v22, v23 do
		if v25.Animation and v25.Animation.AnimationId == p_u_19.AnimationId then
			v_u_24 = v25
			break
		end
	end
	if not v_u_24 then
		local v_u_26 = coroutine.running()
		local v_u_27 = nil
		local v_u_28 = nil
		v_u_28 = p18.AnimationPlayed:Connect(function(p29)
			-- upvalues: (copy) p_u_19, (ref) v_u_28, (ref) v_u_24, (ref) v_u_27, (copy) v_u_26
			if p29.Animation and p29.Animation.AnimationId == p_u_19.AnimationId then
				v_u_28:Disconnect()
				v_u_24 = p29
				pcall(task.cancel, v_u_27)
				coroutine.resume(v_u_26)
			end
		end)
		v_u_27 = task.delay(p20 or 1, function()
			-- upvalues: (ref) v_u_28, (copy) v_u_26
			v_u_28:Disconnect()
			coroutine.resume(v_u_26)
		end)
		coroutine.yield()
	end
	return v_u_24
end
function v_u_1.new(p_u_30, p31)
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v32 = p_u_30:FindFirstChild("Torso")
	local v33 = p_u_30:FindFirstChild("HumanoidRootPart")
	local v34 = p_u_30:FindFirstChild("Humanoid")
	if not (v32 and (v33 and v34)) then
		return nil
	end
	local v35 = v_u_1.WaitForAnimation(v34, p31, 3)
	if not v35 then
		return nil
	end
	local v36 = v_u_2
	local v_u_37 = setmetatable({
		["Disposal"] = {}
	}, v36)
	v_u_37:Task(v35.Stopped:Once(function()
		-- upvalues: (copy) v_u_37
		v_u_37:Cleanup()
	end))
	v_u_37:Task(p_u_30.AncestryChanged:Connect(function()
		-- upvalues: (copy) p_u_30, (copy) v_u_37
		if not p_u_30.Parent then
			v_u_37:Cleanup()
		end
	end))
	return {
		["Torso"] = p_u_30.Torso,
		["RootPart"] = v33,
		["Animation"] = v35,
		["Job"] = v_u_37
	}
end
return v_u_1