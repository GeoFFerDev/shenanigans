-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "RikaThrowController"
})
function v11.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_8
	local v_u_21 = {
		["TrackCamera"] = function(p12, p13)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4
			v_u_10:PlaySound(v_u_7.Yuta.Rika.ThrowStart, p13, game.SoundService.Effect)
			workspace.CurrentCamera.CameraSubject = p13
			while not p12:GetAttribute("Disabled") and p12.Parent do
				p12:FireServer(workspace.CurrentCamera.CFrame.LookVector)
				task.wait()
			end
			workspace.CurrentCamera.CameraSubject = v_u_4.Character.Humanoid
		end,
		["Sniper"] = function(p14, p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = p14:FindFirstChild("HumanoidRootPart")
				if v17 then
					local v_u_18 = v_u_6.Itadori.DivergentFist.BlackFlashHit:Clone()
					v_u_18.Position = v17.Position
					v_u_18.Parent = workspace.Effects
					v_u_2:AddItem(v_u_18, 1)
					local v19 = v_u_6.Itadori.DivergentFist.FinisherDrag:Clone()
					v19.Parent = v17
					v_u_2:AddItem(v19, 0.3)
					v_u_10:Flash(p14, Color3.new(1, 0, 0))
					v_u_10:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlashHit, v17, game.SoundService.Effect)
					v_u_10:PlaySound(v_u_7.Yuta.BlackFlash.Land3, v16, game.SoundService.Music)
					v_u_18.Wind2:Emit(8)
					v_u_3:Create(v_u_18.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_18
						v_u_18.Blast:Emit(8)
						v_u_18.Sparks:Emit(15)
						v_u_18.Lightning:Emit(6)
						v_u_18.Wind:Emit(7)
					end)
					if v_u_4.Character == p15 or v_u_4.Character == p14 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						local v20 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v20.Parent = game.Lighting
						task.wait(0.04)
						v20.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v20.Brightness = 200
						v20.Contrast = -1000
						task.wait(0.04)
						v20:Destroy()
					end
				end
			else
				return
			end
		end
	}
	RikaThrowService.Effects:Connect(function(p22, ...)
		-- upvalues: (copy) v_u_21
		local v23 = v_u_21[p22]
		if v23 then
			v23(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (copy) v_u_1, (ref) v_u_9, (ref) v_u_10
	RikaThrowService = v_u_1.GetService("RikaThrowService")
	v_u_9 = v_u_1.GetController("HitboxController")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11