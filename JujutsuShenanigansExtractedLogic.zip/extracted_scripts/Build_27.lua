-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "build",
	["Description"] = "Loads a player\'s build into the game",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"Mod"
	},
	["Args"] = {
		{
			["Type"] = "username",
			["Name"] = "Username"
		},
		{
			["Type"] = "number",
			["Name"] = "Slot"
		},
		{
			["Type"] = "number",
			["Name"] = "Version",
			["Optional"] = true
		}
	}
}
return v1