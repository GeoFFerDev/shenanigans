-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "BloodEdgeController"
})
local v_u_14 = RaycastParams.new()
v_u_14.FilterType = Enum.RaycastFilterType.Include
v_u_14.FilterDescendantsInstances = { workspace.Map, workspace.Spawns, workspace.Domains }
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_4, (copy) v_u_14, (copy) v_u_8, (copy) v_u_9, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (ref) v_u_10
	local v_u_32 = {
		["Draw"] = function(p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:PlaySound(v_u_7.Mahito.DrillSplit.Unmorph, v16, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p17)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_12:PlaySound(v_u_7.Choso.BloodEdge.Dash, v18, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p19, _, p20)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_14
			local v21 = p19:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_12:PlaySound(v_u_7.Mahito.CrushingRushdown.Leap, v21, game.SoundService.Effect)
				if v_u_4.Character == p19 then
					task.wait(0.5)
					repeat
						task.wait()
					until not p20.Parent or workspace:Raycast(v21.Position + v21.CFrame.LookVector * 1.5, Vector3.new(0, -6, 0), v_u_14)
					if not p20.Parent then
						return
					end
					p20:FireServer(v21.Position + v21.CFrame.LookVector * 1.5)
				end
			end
		end,
		["Hit"] = function(p22)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			if v23 then
				v_u_12:Flash(p22, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Choso.BloodEdge.StabHit, v23, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v23.Position).Magnitude < 150 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					for _ = 1, 2 do
						v_u_9:Blood(p22.Torso.CFrame, math.random(40, 90), 45, 45)
					end
				end
			end
		end,
		["FinalHit"] = function(p24)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v25 = p24:FindFirstChild("HumanoidRootPart")
			if v25 then
				v_u_12:Flash(p24, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_7.Itadori.CursedStrikes.Hit, v25, game.SoundService.Effect)
			end
		end,
		["Crush"] = function(p26, p27)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_3
			local v28 = v_u_6.Itadori.CrushingBlow:Clone()
			v28.Position = p27
			v28.PointLight:Destroy()
			v28.Air:Destroy()
			v28.Parent = workspace.Effects
			v28.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 0, 0))
			v28.Floor.Sparks.Color = ColorSequence.new(Color3.new(1, 0, 0))
			v28.Floor.Ring:Emit(10)
			v28.Floor.Sparks:Emit(10)
			v28.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v28, 1.5)
			v_u_12:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v28, game.SoundService.Effect)
			if v_u_4 == p26 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
			local v29 = CFrame.lookAt(p27 + Vector3.new(0, 5, 0), p27)
			local v30 = v_u_6.Choso.CounterSwing:Clone()
			v30:PivotTo(v29 * CFrame.new(2, 1, -4))
			for _, v31 in v30:GetChildren() do
				v31.Color = Color3.new(1, 0.5, 0.5)
			end
			v30.Parent = workspace.Effects
			v_u_2:AddItem(v30, 0.3)
			v_u_3:Create(v30.Shock, TweenInfo.new(0.2), {
				["Size"] = Vector3.new(0, 25, 0),
				["Transparency"] = 1
			}):Play()
			v_u_3:Create(v30.Shock2, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(8, 0, 8),
				["Transparency"] = 1,
				["Position"] = v30.Shock2.Position + v29.LookVector * 3
			}):Play()
			v_u_3:Create(v30.Shockwave, TweenInfo.new(0.3), {
				["Size"] = Vector3.new(0, 30, 0),
				["Transparency"] = 1,
				["CFrame"] = v30.Shockwave.CFrame * CFrame.Angles(0, 3.12413936106985, 0)
			}):Play()
		end
	}
	v_u_10.Effects:Connect(function(p33, ...)
		-- upvalues: (copy) v_u_32
		local v34 = v_u_32[p33]
		if v34 then
			v34(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("BloodEdgeService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13