-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("RunService")
local v_u_2 = workspace.CurrentCamera
return function(p_u_3, p_u_4, p5)
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v_u_6 = p5 or CFrame.identity
	v_u_2.CameraType = Enum.CameraType.Scriptable
	local v7 = p_u_4:FindFirstChild("AttachTo")
	local v_u_8 = v7 and v7.Value or p_u_4:FindFirstChild("camera")
	local v_u_9 = tick()
	local v_u_10 = nil
	local function v11()
		-- upvalues: (ref) v_u_10, (copy) p_u_4, (ref) v_u_2
		v_u_10:Disconnect()
		pcall(p_u_4.Destroy, p_u_4)
		v_u_2.CameraType = Enum.CameraType.Custom
	end
	local function v12()
		-- upvalues: (copy) p_u_4, (copy) v_u_9, (ref) v_u_10, (ref) v_u_2, (copy) p_u_3, (ref) v_u_6, (copy) v_u_8
		if p_u_4.Parent and tick() - v_u_9 <= 30 then
			if p_u_3 then
				p_u_4:PivotTo(p_u_3.CFrame * v_u_6)
			end
			v_u_2.CFrame = v_u_8.CFrame
		else
			v_u_10:Disconnect()
			pcall(p_u_4.Destroy, p_u_4)
			v_u_2.CameraType = Enum.CameraType.Custom
		end
	end
	v_u_10 = v_u_1.RenderStepped:Connect(v12)
	if p_u_4.Parent and tick() - v_u_9 <= 30 then
		if p_u_3 then
			p_u_4:PivotTo(p_u_3.CFrame * v_u_6)
		end
		v_u_2.CFrame = v_u_8.CFrame
	else
		v_u_10:Disconnect()
		pcall(p_u_4.Destroy, p_u_4)
		v_u_2.CameraType = Enum.CameraType.Custom
	end
	return v11
end