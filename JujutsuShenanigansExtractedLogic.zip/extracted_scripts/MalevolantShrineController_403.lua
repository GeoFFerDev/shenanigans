-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = v5.Animations
local v_u_7 = v5.Utils
local v_u_8 = v5.Sounds
local v_u_9 = require(v5.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "MalevolantShrineController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_4, (copy) v_u_6, (copy) v_u_7, (copy) v_u_3, (copy) v_u_2, (copy) v_u_9, (ref) v_u_10
	local v_u_47 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_11:PlaySound(v_u_8.Itadori.MalevolantShrine.Voice, v14, game.SoundService.Voice)
				v_u_11:DomainBurst(v14)
				local v15 = v_u_4.Character
				if v15 and v15:FindFirstChild("HumanoidRootPart") then
					local v16 = v15:FindFirstChild("HumanoidRootPart")
					if (v14.Position - v16.Position).Magnitude <= 37.5 then
						v_u_11:Domain(p13, function(p17, p18)
							-- upvalues: (ref) v_u_6
							p18.Humanoid:LoadAnimation(v_u_6.Itadori.DomainWarn):Play(0)
							p17.Panel.ImageLabel.Image = "rbxassetid://14812133399"
							p17.Panel.ImageLabel.Size = UDim2.new(0.8, 0, 0.8, 0)
							p17.Panel.Viewport.LightColor = Color3.fromRGB(255, 155, 155)
							p17.Panel.Viewport.Ambient = Color3.fromRGB(0, 0, 0)
							p17.Panel.Viewport.LightDirection = Vector3.new(0, 1, 0)
						end)
					end
				end
			end
		end,
		["Opening"] = function(p19, p20, p_u_21, p22)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_11, (ref) v_u_8, (ref) v_u_9
			local v_u_23 = v_u_7.Itadori.MalevolantShrine.DomainBG:Clone()
			v_u_23.Parent = p19
			v_u_23.CFrame = p19.CFrame
			task.spawn(function()
				-- upvalues: (copy) p_u_21, (copy) v_u_23
				repeat
					task.wait()
				until not (p_u_21.Parent and (p_u_21.Parent.Parent and p_u_21.Parent.Parent.Parent))
				v_u_23:Destroy()
			end)
			local v_u_24 = Instance.new("ColorCorrectionEffect", game.Lighting)
			v_u_24.Name = "DomainCC"
			v_u_3:Create(v_u_24, TweenInfo.new(2), {
				["Saturation"] = -1,
				["Contrast"] = 1
			}):Play()
			local v_u_25 = nil
			if p22 then
				local v_u_26 = v_u_11:PlaySound(v_u_8.Itadori.MalevolantShrine.Music, workspace, game.SoundService.Music, true)
				v_u_26.TimePosition = 1.5
				game.SoundService.AmbientReverb = Enum.ReverbType.Arena
				task.spawn(function()
					-- upvalues: (copy) p_u_21, (ref) v_u_3, (copy) v_u_26, (ref) v_u_2, (ref) v_u_25, (copy) v_u_24
					repeat
						task.wait()
					until not (p_u_21.Parent and (p_u_21.Parent.Parent and p_u_21.Parent.Parent.Parent))
					game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
					v_u_3:Create(v_u_26, TweenInfo.new(2), {
						["Volume"] = 0
					}):Play()
					v_u_2:AddItem(v_u_26, 2)
					if v_u_25 then
						v_u_25:StartFadeOut(1)
					end
					v_u_24:Destroy()
				end)
			else
				local v_u_27 = p20.DomainGround
				v_u_27.Surround.Enabled = true
				v_u_3:Create(v_u_27.Surround, TweenInfo.new(0.8), {
					["ShapePartial"] = 1
				}):Play()
				v_u_2:AddItem(v_u_27, 2)
				v_u_11:PlaySound(v_u_8.Itadori.MalevolantShrine.Ring, workspace, game.SoundService.Effect)
				task.delay(0.8, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_27, (ref) v_u_11
					v_u_3:Create(v_u_27, TweenInfo.new(0.4), {
						["Transparency"] = 0
					}):Play()
					v_u_11:DomainMapFade(Color3.fromRGB(0, 0, 0), 0.4, 1.6)
				end)
				local v_u_28 = v_u_11:PlaySound(v_u_8.Itadori.MalevolantShrine.Music, workspace, game.SoundService.Music, true)
				local v_u_29 = v_u_11:PlaySound(v_u_8.Itadori.MalevolantShrine.Ready, workspace, game.SoundService.Effect)
				game.SoundService.AmbientReverb = Enum.ReverbType.Arena
				task.spawn(function()
					-- upvalues: (copy) p_u_21, (ref) v_u_3, (copy) v_u_28, (ref) v_u_2, (copy) v_u_29, (ref) v_u_25, (copy) v_u_24
					repeat
						task.wait()
					until not (p_u_21.Parent and (p_u_21.Parent.Parent and p_u_21.Parent.Parent.Parent))
					game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
					v_u_3:Create(v_u_28, TweenInfo.new(2), {
						["Volume"] = 0
					}):Play()
					v_u_2:AddItem(v_u_28, 2)
					if v_u_29 then
						v_u_3:Create(v_u_29, TweenInfo.new(0.5), {
							["Volume"] = 0
						}):Play()
					end
					if v_u_25 then
						v_u_25:StartFadeOut(1)
					end
					v_u_24:Destroy()
				end)
				task.wait(1.5)
			end
			local v30 = v_u_23.Floor.Shrine
			v30:SetPrimaryPartCFrame(v_u_23.Floor.CFrame - Vector3.new(0, 30, 0))
			v_u_3:Create(v30.Shrine, TweenInfo.new(1.5, Enum.EasingStyle.Circular, Enum.EasingDirection.Out), {
				["CFrame"] = v_u_23.Floor.CFrame + Vector3.new(0, 10, 0)
			}):Play()
			v_u_3:Create(v30.Skulls, TweenInfo.new(2, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["CFrame"] = v_u_23.Floor.CFrame + Vector3.new(0, 3, 0)
			}):Play()
			v_u_23.Floor.Ripple.Enabled = true
			if not p22 then
				v_u_11:PlaySound(v_u_8.Itadori.MalevolantShrine.WaterSplash, v30.Shrine, game.SoundService.Effect)
				v_u_23.Floor.Water.Splash:Emit(10)
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				task.wait(1)
				if not (p_u_21 and p_u_21.Parent) then
					return
				end
			end
			v_u_3:Create(v_u_23.Floor.Attachment.Charge, TweenInfo.new(0.4, Enum.EasingStyle.Cubic, Enum.EasingDirection.In), {
				["TimeScale"] = 1
			}):Play()
			v_u_3:Create(v_u_24, TweenInfo.new(0.5), {
				["Saturation"] = 0,
				["Brightness"] = 0.1,
				["Contrast"] = 0.5,
				["TintColor"] = Color3.fromRGB(255, 195, 195)
			}):Play()
			local _ = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.LightHit)
			v_u_3:Create(v_u_23, TweenInfo.new(1.25, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
				["Color"] = Color3.fromRGB(136, 62, 62)
			}):Play()
			task.wait(0.5)
			v_u_23.Floor.Attachment.Charge.Enabled = false
			v_u_23.Slash1.Enabled = true
			v_u_23.Slash2.Enabled = true
			v_u_23.Sparks.Enabled = true
		end,
		["Shatter"] = function(p31)
			-- upvalues: (ref) v_u_7, (ref) v_u_2, (ref) v_u_11, (ref) v_u_8, (ref) v_u_3
			local v32 = v_u_7.Domain:Clone()
			v32.Transparency = 1
			v32.CanCollide = false
			v32.Position = p31
			v32.Shatter.Color = ColorSequence.new(Color3.new(0, 0, 0))
			v32.Parent = workspace.Effects
			v_u_2:AddItem(v32, 3)
			for _, v33 in v32:GetChildren() do
				if v33.Name == "Shatter" then
					v33:Emit(100)
				else
					v33:Destroy()
				end
			end
			v_u_11:PlaySound(v_u_8.Itadori.MalevolantShrine.Shatter, v32, game.SoundService.Effect)
			v32.Transparency = 0
			v32.Color = Color3.new(0, 0, 0)
			v_u_3:Create(v32, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v32.Position).Magnitude > 150 then
					return
				end
				local v34 = Random.new()
				local v35 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v36 = v_u_7.Gojo.Shard:Clone()
					local v37 = v34:NextUnitVector().Unit
					local v38 = math.random(1, 8)
					local v39 = math.random
					v36.Size = Vector3.new(0.1, v38, v39(1, 8))
					v36.CFrame = CFrame.lookAlong(p31, v37) * CFrame.Angles(1.5707963267948966, 0, 0) + v37 * 37.5
					v36.CFrame = v36.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v36.Color = Color3.new(0, 0, 0)
					v36.CanCollide = true
					v36.CollisionGroup = "Effects"
					v36.Parent = workspace.Effects
					local v40 = math.random(-50, 50)
					local v41 = math.random(-50, 50)
					local v42 = math.random
					v36.RotVelocity = Vector3.new(v40, v41, v42(-50, 50))
					v36.Transparency = 0
					v36.Material = Enum.Material.Neon
					v_u_3:Create(v36, v35, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_2:AddItem(v36, 4)
				end
			end
		end,
		["Hit"] = function(p43, p44)
			-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_8
			local v45 = p43:FindFirstChild("HumanoidRootPart")
			if not v45 then
				return
			end
			local v46 = v_u_7.Itadori.MalevolantShrine.Hit:Clone()
			v46.Parent = workspace.Effects
			v46.Weld.Part1 = v45
			while true do
				task.wait(math.random(10, 20) / 100)
				if p44.Value == true then
					v46.Slash1.Enabled = false
					v46.Slash2.Enabled = false
				else
					v46.Slash1.Enabled = true
					v46.Slash2.Enabled = true
					v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Slash, v45, game.SoundService.Effect)
				end
				if not p44 or (not p44.Parent or p43:GetAttribute("Dead")) then
					v46:Destroy()
					if p43:GetAttribute("Dead") then
						v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Explode, v45, game.SoundService.Effect)
						v_u_11:Bleed(p43)
					end
					return
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p48, ...)
		-- upvalues: (copy) v_u_47
		local v49 = v_u_47[p48]
		if v49 then
			v49(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("MalevolantShrineService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12