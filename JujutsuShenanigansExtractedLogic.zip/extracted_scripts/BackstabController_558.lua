-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = require(v5.Modules.BloodyZee)
local v10 = RaycastParams.new()
v10.FilterType = Enum.RaycastFilterType.Include
v10.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "BackstabController"
})
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_9, (copy) v_u_4, (copy) v_u_8, (ref) v_u_11
	local v_u_24 = {
		["Start"] = function(p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:PlaySound(v_u_7.Haruta.Backstab, v16, game.SoundService.Effect)
			end
		end,
		["Whoosh"] = function(p17)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v18 = p17:FindFirstChild("HumanoidRootPart")
			if v18 then
				v_u_12:PlaySound(v_u_7.Haruta.Backstab, v18, game.SoundService.Effect)
				local v19 = v_u_6.Choso.CounterSwing:Clone()
				v19:PivotTo(v18.CFrame * CFrame.new(-1, 0, -8) * CFrame.Angles(0, 0.17453292519943295, 0))
				v19.Parent = workspace.Effects
				v19.Shockwave:Destroy()
				v_u_2:AddItem(v19, 0.3)
				v19.Shock.Size = Vector3.new(10, 2, 10)
				v_u_3:Create(v19.Shock, TweenInfo.new(0.125), {
					["Size"] = Vector3.new(2, 15, 2),
					["Transparency"] = 1,
					["Position"] = v19.Shock2.Position + v18.CFrame.LookVector * 3
				}):Play()
				v_u_3:Create(v19.Shock2, TweenInfo.new(0.1), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1,
					["Position"] = v19.Shock2.Position + v18.CFrame.LookVector * 3
				}):Play()
			end
		end,
		["Stab"] = function(p20, p21, p22)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8
			if p20:FindFirstChild("HumanoidRootPart") then
				local v23 = p21:FindFirstChild("HumanoidRootPart")
				if v23 then
					v_u_12:Flash(p21, Color3.new(0.745098, 0, 0.0117647))
					v_u_12:PlaySound(p22 and v_u_7.Haruta.BackstabBack or v_u_7.Haruta.BackstabFront, v23, game.SoundService.Effect)
					for _ = 1, 20 do
						v_u_9:Blood(p21.Torso.CFrame, math.random(5, 80), 25, 25)
					end
					if p20 == v_u_4.Character or p21 == v_u_4.Character then
						if p22 then
							v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
							return
						end
						v_u_8.CurrentShaker:ShakeSustain(v_u_8.Presets.HeavyHit):StartFadeOut(0.4)
					end
				end
			else
				return
			end
		end
	}
	v_u_11.Effects:Connect(function(p25, ...)
		-- upvalues: (copy) v_u_24
		local v26 = v_u_24[p25]
		if v26 then
			v26(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_13, (ref) v_u_12
	v_u_11 = v_u_1.GetService("BackstabService")
	v_u_13 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v14