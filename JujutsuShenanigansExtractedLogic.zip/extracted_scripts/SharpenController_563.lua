-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v9 = require(v5.Modules.SraikoVFX)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "SharpenController"
})
local v_u_14 = v9.Emit
local _ = v9.Enabled
local v_u_15 = v9.EmitMesh
function v13.KnitStart(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (ref) v_u_11, (copy) v_u_7, (copy) v_u_8, (copy) v_u_4, (copy) v_u_3, (copy) v_u_14, (copy) v_u_15, (ref) v_u_10
	local v_u_49 = {
		["Hit"] = function(p16, p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_8, (ref) v_u_4
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
				v19.Position = v18.Position
				v19.Parent = workspace.Effects
				v_u_2:AddItem(v19, 1)
				v19.Sparks.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255))
				v19.Wind.Color = v19.Sparks.Color
				v19.Wind2.Color = v19.Sparks.Color
				v19.Sparks:Emit(50)
				v19.Wind:Emit(7)
				v19.Wind2:Emit(7)
				v_u_11:Flash(p16, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v18, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Todo.BruteForce.Hit, v18, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v18.Position).Magnitude < 80 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
				if p17 then
					v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Explode, v18, game.SoundService.Effect)
					v_u_11:Bleed(p16)
					if v_u_4.Character == p16 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						local v20 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v20.TintColor = Color3.new(1, 1, 1)
						v20.Parent = game.Lighting
						task.wait(0.04)
						v20.Brightness = 200
						v20.Contrast = -1000
						task.wait(0.04)
						v20:Destroy()
					end
				end
			end
		end,
		["Slash2"] = function(p21)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v22 = p21:FindFirstChild("HumanoidRootPart")
			if v22 then
				v_u_11:PlaySound(v_u_7.Nanami.Sharpen.JumpSlash, v22, game.SoundService.Effect)
				local v23 = v_u_6.Nanami.Sharpen.SharpenAir.SlashEmit:Clone()
				v23.CFrame = v22.CFrame - Vector3.new(0, 5, 0)
				v23.Parent = workspace.Effects
				for _, v24 in pairs(v23:GetDescendants()) do
					if v24:IsA("ParticleEmitter") then
						v24:Emit(v24:GetAttribute("EmitCount"))
					end
				end
				v_u_2:AddItem(v23, 1.5)
				local v25 = v_u_6.Nanami.Sharpen.SharpenAir.SlashBeam:Clone()
				v25.CFrame = v22.CFrame
				v25.Parent = workspace.Effects
				v_u_2:AddItem(v25, 1.5)
				for _, v26 in pairs(v25:GetDescendants()) do
					if v26:IsA("Beam") then
						v26.Enabled = true
					end
				end
				for _, v_u_27 in pairs(v25:GetDescendants()) do
					if v_u_27:IsA("Beam") then
						v_u_3:Create(v_u_27, TweenInfo.new(0.19), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
						task.delay(0.29000000000000004, function()
							-- upvalues: (copy) v_u_27
							v_u_27.Enabled = false
							v_u_27.Width0 = 17
							v_u_27.Width1 = 17
						end)
					end
				end
				if v_u_4.Character == p21 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["CleaverSlam"] = function(p28)
			-- upvalues: (ref) v_u_14, (ref) v_u_6, (ref) v_u_15
			local v29 = p28:FindFirstChild("HumanoidRootPart")
			if v29 then
				v_u_14(v_u_6.Nanami.Sharpen.VFX.DustLand.Emit.VFX, v29.CFrame, false, 1.5)
				v_u_15(v_u_6.Nanami.Sharpen.VFX.DustLand.Meshes.MeshDownSlam, v29.CFrame * v_u_6.Nanami.Sharpen.VFX.DustLand.Meshes.MeshDownSlam.WorldPivot)
			end
		end,
		["CleaverTrail"] = function(p30)
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			local v31 = p30:FindFirstChild("HumanoidRootPart")
			if v31 then
				local v32 = v_u_6.Nanami.Sharpen.VFX.MovingTrail.Trail:Clone()
				v32.Weld.Part0 = v31
				v32.Parent = p30
				v_u_2:AddItem(v32, 2)
				task.wait(0.4)
				for _, v33 in v32:GetDescendants() do
					if v33:IsA("ParticleEmitter") or v33:IsA("Trail") then
						v33.Enabled = false
					end
				end
			end
		end,
		["Slash"] = function(p34, _)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_14, (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v35 = p34:FindFirstChild("HumanoidRootPart")
			if v35 then
				v_u_11:PlaySound(v_u_7.Nanami.Sharpen.Slash, v35, game.SoundService.Effect)
				v_u_14(v_u_6.Nanami.Sharpen.VFX.SlashR.Emit.Slash, v35.CFrame, false, 3)
				local v36 = v_u_6.Nanami.Sharpen.VFX.Slash.Slash:Clone()
				v36.CFrame = v35.CFrame
				v36.Parent = workspace.Effects
				v_u_2:AddItem(v36, 1.5)
				for _, v37 in pairs(v36:GetDescendants()) do
					if v37:IsA("Beam") or v37:IsA("ParticleEmitter") then
						v37.Enabled = true
					end
				end
				for _, v_u_38 in pairs(v36:GetDescendants()) do
					if v_u_38:IsA("Beam") then
						v_u_3:Create(v_u_38, TweenInfo.new(0.12), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
						task.delay(0.22, function()
							-- upvalues: (copy) v_u_38
							v_u_38.Enabled = false
							v_u_38.Width0 = 25
							v_u_38.Width1 = 25
						end)
					elseif v_u_38:IsA("ParticleEmitter") then
						v_u_38.Enabled = false
					end
				end
			end
		end,
		["RatioBar"] = function(p39, p40)
			-- upvalues: (ref) v_u_3, (ref) v_u_11, (ref) v_u_7
			local v41 = p40.SharpenRatio.Weld.C1
			p40.SharpenRatio.Weld.C1 = v41 * CFrame.Angles(0, 0, 1.5707963267948966)
			v_u_3:Create(p40.SharpenRatio.Weld, TweenInfo.new(0.03, Enum.EasingStyle.Linear), {
				["C1"] = v41 * CFrame.Angles(0, 0, 3.141592653589793)
			}):Play()
			task.wait(0.03)
			v_u_3:Create(p40.SharpenRatio.Weld, TweenInfo.new(0.06, Enum.EasingStyle.Linear), {
				["C1"] = v41 * CFrame.Angles(0, 0, 4.71238898038469)
			}):Play()
			task.wait(0.06)
			v_u_3:Create(p40.SharpenRatio.Weld, TweenInfo.new(0.6, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
				["C1"] = v41
			}):Play()
			if p39 then
				p39 = p39:FindFirstChild("HumanoidRootPart")
			end
			if p39 then
				v_u_11:PlaySound(v_u_7.Nanami.Sharpen.JumpWindup, p39, game.SoundService.Effect)
			end
		end,
		["RatioBreak"] = function(p42, p43)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_6, (ref) v_u_2, (ref) v_u_8
			v_u_11:PlaySound(v_u_7.Nanami.Sharpen.RatioHit, p43, game.SoundService.Effect)
			p43.Shock.Transparency = 0
			task.wait(0.03)
			p43.Shock.Transparency = 1
			local v_u_44 = p43.SharpenRatio.Front
			local v_u_45 = p43.SharpenRatio.Back
			v_u_44.Bar.Visible = false
			v_u_44.Cursor.Visible = false
			v_u_44.FakeBar1.Visible = true
			v_u_44.FakeBar2.Visible = true
			v_u_45.Bar.Visible = false
			v_u_45.Cursor.Visible = false
			v_u_45.FakeBar1.Visible = true
			v_u_45.FakeBar2.Visible = true
			local v46 = TweenInfo.new(0.7, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
			local v47 = TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.In)
			v_u_3:Create(v_u_44.FakeBar1, v46, {
				["Rotation"] = 45
			}):Play()
			v_u_3:Create(v_u_44.FakeBar2, v46, {
				["Rotation"] = 45
			}):Play()
			v_u_3:Create(v_u_45.FakeBar1, v46, {
				["Rotation"] = -45
			}):Play()
			v_u_3:Create(v_u_45.FakeBar2, v46, {
				["Rotation"] = -45
			}):Play()
			v_u_3:Create(v_u_44.FakeBar1, v47, {
				["ImageTransparency"] = 1
			}):Play()
			v_u_3:Create(v_u_44.FakeBar2, v47, {
				["ImageTransparency"] = 1
			}):Play()
			v_u_3:Create(v_u_45.FakeBar1, v47, {
				["ImageTransparency"] = 1
			}):Play()
			v_u_3:Create(v_u_45.FakeBar2, v47, {
				["ImageTransparency"] = 1
			}):Play()
			if v_u_4 == p42 then
				local v_u_48 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
				v_u_48.TintColor = Color3.fromRGB(60, 60, 60)
				v_u_48.Brightness = -0.8
				v_u_48.Contrast = 0
				v_u_48.Saturation = 0
				v_u_48.Parent = game.Lighting
				v_u_44.AlwaysOnTop = true
				v_u_45.AlwaysOnTop = true
				task.spawn(function()
					-- upvalues: (copy) v_u_48, (ref) v_u_3, (ref) v_u_2, (ref) v_u_8, (copy) v_u_44, (copy) v_u_45
					task.wait(0.04)
					task.wait(0.04)
					v_u_48.Brightness = -0.6
					v_u_3:Create(v_u_48, TweenInfo.new(0.2), {
						["Brightness"] = 0,
						["TintColor"] = Color3.new(1, 1, 1)
					}):Play()
					v_u_2:AddItem(v_u_48, 0.2)
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					task.wait(0.2)
					v_u_44.AlwaysOnTop = false
					v_u_45.AlwaysOnTop = false
				end)
			end
		end
	}
	v_u_10.Effects:Connect(function(p50, ...)
		-- upvalues: (copy) v_u_49
		local v51 = v_u_49[p50]
		if v51 then
			v51(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("SharpenService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("ToolController")
end
return v13