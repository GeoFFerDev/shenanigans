-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local v_u_7 = v_u_6.Animations
local v_u_8 = v_u_6.Utils
local v_u_9 = v_u_6.Sounds
local v_u_10 = require(v_u_6.Modules.CameraShaker)
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "HiromiController"
})
local function v_u_18(p15, p16)
	-- upvalues: (ref) v_u_13, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4
	if p15.Head:FindFirstChild("HiromiText") then
		p15.Head.HiromiText:Destroy()
	end
	v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Talk, p15.Head, game.SoundService.Voice)
	local v_u_17 = v_u_8.Hiromi.DeadlySentencing.HiromiText:Clone()
	v_u_17.TextLabel.Text = p16
	v_u_17.Parent = p15.Head
	v_u_3:AddItem(v_u_17, 1.5)
	task.delay(1, function()
		-- upvalues: (copy) v_u_17, (ref) v_u_4
		if v_u_17.Parent then
			v_u_4:Create(v_u_17.TextLabel, TweenInfo.new(0.5), {
				["BackgroundTransparency"] = 1,
				["TextTransparency"] = 1
			}):Play()
			v_u_4:Create(v_u_17.TextLabel.UIStroke, TweenInfo.new(0.5), {
				["Transparency"] = 1
			}):Play()
		end
	end)
end
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_13, (copy) v_u_9, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_10, (copy) v_u_6, (copy) v_u_18, (copy) v_u_2, (ref) v_u_11, (ref) v_u_12
	local v_u_235 = {
		["Hit"] = function(p19, p20)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v21 = p19:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_13:Flash(p19, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit" .. p20), v21, game.SoundService.Effect)
			end
		end,
		["Dodge2"] = function(p22)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_7
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			if v23 then
				local v24 = v_u_8.Damage.HitGlow:Clone()
				if p22:GetScale() ~= 1 then
					v24:ScaleTo(p22:GetScale())
				end
				v24.Parent = workspace.Effects
				v_u_3:AddItem(v24, 0.5)
				for _, v25 in v24:GetChildren() do
					local v26 = p22:FindFirstChild(v25.Name)
					if v26 then
						v25.CFrame = v26.CFrame
					end
					v25.Color = Color3.new(0, 0, 0)
					v25.Anchored = true
					v_u_4:Create(v25, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
				v_u_13:PlaySound(v_u_9.Itadori.ManjiKick.Dodge, v23, game.SoundService.Effect)
				local v27 = {
					"Dodge1",
					"Dodge2",
					"Dodge3",
					"Dodge4",
					"Dodge5"
				}
				for _, v28 in p22.Humanoid:GetPlayingAnimationTracks() do
					if table.find(v27, v28.Name) then
						v28:Stop(0.02)
					end
				end
				p22.Humanoid:LoadAnimation(v_u_7.Hiromi.Dodge:GetChildren()[math.random(1, 5)]):Play(0.02)
			end
		end,
		["Dodge"] = function(p29)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_7
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				local v31 = v_u_8.Damage.HitGlow:Clone()
				if p29:GetScale() ~= 1 then
					v31:ScaleTo(p29:GetScale())
				end
				v31.Parent = workspace.Effects
				v_u_3:AddItem(v31, 0.5)
				for _, v32 in v31:GetChildren() do
					local v33 = p29:FindFirstChild(v32.Name)
					if v33 then
						v32.CFrame = v33.CFrame
					end
					v32.Color = Color3.new(1, 0.807843, 0.423529)
					v32.Anchored = true
					v32.Transparency = 0.1
					v_u_4:Create(v32, TweenInfo.new(0.5), {
						["Transparency"] = 1
					}):Play()
				end
				v_u_13:PlaySound(v_u_9.Itadori.ManjiKick.Dodge, v30, game.SoundService.Effect)
				local v34 = {
					"Dodge1",
					"Dodge2",
					"Dodge3",
					"Dodge4",
					"Dodge5"
				}
				for _, v35 in p29.Humanoid:GetPlayingAnimationTracks() do
					if table.find(v34, v35.Name) then
						v35:Stop(0.02)
					end
				end
				p29.Humanoid:LoadAnimation(v_u_7.Hiromi.Dodge:GetChildren()[math.random(1, 5)]):Play(0.02)
			end
		end,
		["ChaseHit"] = function(p36, p37)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
			local v38 = p36:FindFirstChild("HumanoidRootPart")
			if v38 then
				local v39 = p37:FindFirstChild("HumanoidRootPart")
				if v39 then
					v_u_13:Flash(p37, Color3.new(1, 1, 1))
					v_u_13:PlaySound(v_u_9.Gojo.M1:FindFirstChild("Hit3"), v39, game.SoundService.Effect)
					local v40 = v_u_8.ChaseHit:Clone()
					local v41 = CFrame.new
					local v42 = v39.Position
					local v43 = v38.Position.X
					local v44 = v39.Position.Y
					local v45 = v38.Position.Z
					v40.CFrame = v41(v42, (Vector3.new(v43, v44, v45))) * CFrame.Angles(0, 3.141592653589793, 0)
					v40.Parent = workspace.Effects
					v40.Ring:Emit(7)
					v40.Sparks:Emit(12)
					v_u_3:AddItem(v40, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p46)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			local v47 = p46.HumanoidRootPart
			if v47 then
				local v48 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v48.CFrame = v47.CFrame * CFrame.new(0, 1, -4)
				v48.Size = Vector3.new(0, 0, 2)
				v48.Parent = workspace.Effects
				v_u_4:Create(v48, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v48, 0.3)
				v_u_13:PlaySound(v_u_9.Misc.Chase, v47, game.SoundService.Effect)
				v_u_13:DustTrail(p46, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing"] = function(p49)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v50 = p49:FindFirstChild("HumanoidRootPart")
			if v50 then
				v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v50, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p51, p52, p53)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			local v54 = p51.HumanoidRootPart
			if v54 then
				if p53 == "Down" then
					v_u_13:ArmFlash(p51["Right Leg"], Color3.fromRGB(255, 170, 0), 0.4)
					v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v54, game.SoundService.Effect)
					return
				elseif p53 == "Up" then
					v_u_13:ArmFlash(p51["Left Arm"], Color3.fromRGB(255, 170, 0), 0.3)
					v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v54, game.SoundService.Effect)
					return
				else
					local v55 = p51.SetAssets:FindFirstChild("Gavel")
					local v56 = p51.SetAssets:FindFirstChild("ExecSword")
					if v55 then
						v_u_13:PlaySound(v_u_9.Hiromi.M1Swing["Swing" .. p52], v54, game.SoundService.Effect)
						if p52 == 3 then
							local v57 = v_u_8.Hiromi.CombatTrail2:Clone()
							v57.Weld.Part0 = v55
							v57.Parent = workspace.Effects
							task.wait(0.35)
							v57.Trail.Enabled = false
							v_u_4:Create(v57, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v57, 0.2)
						else
							local v58 = v_u_8.Hiromi.CombatTrail:Clone()
							v58.Weld.Part0 = v55
							v58.Parent = workspace.Effects
							task.wait(p52 == 2 and 0.6 or 0.35)
							v58.Trail.Enabled = false
							v_u_4:Create(v58, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v58, 0.2)
						end
					else
						if v56 then
							if p52 == 4 then
								v_u_13:ArmFlash(p51["Left Arm"], Color3.fromRGB(255, 170, 0), 0.3)
								v_u_13:PlaySound(v_u_9.Misc.Swing.Fist, v54, game.SoundService.Effect)
								return
							end
							v_u_13:PlaySound(v_u_9.Hiromi.M1SwordSwing["Swing" .. p52], v54, game.SoundService.Effect)
						end
						return
					end
				end
			else
				return
			end
		end,
		["Chat"] = function(p_u_59, p60, p_u_61)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v62 = p_u_59:FindFirstChild("HumanoidRootPart")
			if v62 then
				task.spawn(function()
					-- upvalues: (ref) v_u_8, (copy) p_u_59, (ref) v_u_4, (ref) v_u_3
					local v63 = v_u_8.Hiromi.Dialogue:Clone()
					v63.Parent = p_u_59.Torso
					local v64 = v63.Chat1.Position
					v63.Chat1.Position = v64 - UDim2.new(0, 0, 0.15, 0)
					v_u_4:Create(v63.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v64
					}):Play()
					v_u_4:Create(v63.Chat1, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_4:Create(v63.Chat1.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(0.7)
					local v65 = v63.Chat2.Position
					v63.Chat2.Position = v65 - UDim2.new(0, 0, 0.15, 0)
					v_u_4:Create(v63.Chat2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = v65
					}):Play()
					v_u_4:Create(v63.Chat2, TweenInfo.new(0.3), {
						["BackgroundTransparency"] = 0
					}):Play()
					v_u_4:Create(v63.Chat2.Sub, TweenInfo.new(0.3), {
						["TextTransparency"] = 0
					}):Play()
					task.wait(1.3)
					v_u_3:AddItem(v63, 0.6)
					for _, v66 in v63:GetDescendants() do
						if v66:IsA("Frame") then
							v_u_4:Create(v66, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["Position"] = v66.Position - UDim2.new(0, 0, 0.2, 0),
								["BackgroundTransparency"] = 1
							}):Play()
						elseif v66:IsA("TextLabel") then
							v_u_4:Create(v66, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
								["TextTransparency"] = 1
							}):Play()
						end
					end
				end)
				v_u_13:PlaySound(v_u_9.Hiromi.Awaken, v62, game.SoundService.Effect)
				for _, v67 in p_u_61:GetChildren() do
					if v67.Name == "Attachment" then
						local v68 = v67.Position
						v67.Position = Vector3.new(0, 0, 0)
						v_u_4:Create(v67, TweenInfo.new(0.6, Enum.EasingStyle.Circular, Enum.EasingDirection.In), {
							["Position"] = v68
						}):Play()
					end
				end
				p60.Weld.C0 = CFrame.new(0, 0, 0)
				p60.Weld.Part0 = p_u_61
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_8, (copy) p_u_61, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (copy) p_u_59, (ref) v_u_10
					for _ = 1, 10 do
						local v_u_69 = v_u_8.Hiromi.GavelShard:Clone()
						v_u_69.Position = p_u_61.Position
						v_u_69.Size = v_u_69.Size * (math.random(30, 100) / 100)
						local v70 = math.random(-50, 50)
						local v71 = math.random(-50, 50)
						local v72 = math.random
						v_u_69.Velocity = Vector3.new(v70, v71, v72(-50, 50))
						local v73 = math.random(-50, 50)
						local v74 = math.random(-50, 50)
						local v75 = math.random
						v_u_69.RotVelocity = Vector3.new(v73, v74, v75(-50, 50))
						v_u_69.Parent = workspace.Effects
						v_u_3:AddItem(v_u_69, 2)
						task.delay(1, function()
							-- upvalues: (ref) v_u_4, (copy) v_u_69
							v_u_4:Create(v_u_69, TweenInfo.new(1), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
						end)
					end
					if v_u_5.Character == p_u_59 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
					end
				end)
				local v76 = v_u_8.Hiromi.SwordBuild.Charge:Clone()
				v_u_3:AddItem(v76, 1)
				v76.Parent = p_u_61
				task.wait(0.7)
				v76:Destroy()
				for _, v77 in v_u_8.Hiromi.SwordBuild.Create:GetChildren() do
					local v78 = v77:Clone()
					v78.Parent = p_u_61
					v_u_3:AddItem(v78, 1.5)
					v78:Emit(v78:GetAttribute("EmitCount"))
				end
			end
		end,
		["Launch"] = function(p79, p80)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v81 = p79:FindFirstChild("HumanoidRootPart")
			if v81 then
				local v82 = v_u_8.Gojo.LapseBlue.Throw:Clone()
				v82.CFrame = CFrame.new(v81.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v82.Size = Vector3.new(0, 0, 5)
				v82.Parent = workspace.Effects
				v_u_4:Create(v82, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v82.Position + Vector3.new(0, p80, 0)
				}):Play()
				v_u_3:AddItem(v82, 0.3)
				if p80 < 0 then
					v_u_13:PlaySound(v_u_9.Megumi.Mahoraga.Throw.Break, v81, game.SoundService.Effect)
					v_u_13:DustBreak(v81.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v81.Position) < 20 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
					end
				end
			end
		end,
		["Startup"] = function(p_u_83)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7, (ref) v_u_8, (ref) v_u_4
			local v84 = p_u_83:FindFirstChild("HumanoidRootPart")
			if v84 then
				v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Voice, v84, game.SoundService.Voice)
				v_u_13:DomainBurst(v84)
				local v85 = v_u_5.Character
				if v85 and v85:FindFirstChild("HumanoidRootPart") then
					local v86 = v85:FindFirstChild("HumanoidRootPart")
					if (v84.Position - v86.Position).Magnitude <= 37.5 then
						v_u_13:Domain(p_u_83, function(p87, p88)
							-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_4, (copy) p_u_83
							p88.Humanoid:LoadAnimation(v_u_7.Hiromi.DomainWarn):Play(0)
							p87.Panel.ImageLabel:Destroy()
							local v89 = v_u_8.Hiromi.DeadlySentencing.JudgemanPanel:Clone()
							v89.Parent = p87.Panel
							p87.Panel.BackgroundColor3 = Color3.new(0, 0, 0)
							v_u_4:Create(v89, TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
								["Position"] = UDim2.new(0.41, 0, 0.3, 0),
								["ImageTransparency"] = 0
							}):Play()
							p87.Panel.Camera.CFrame = p88.HumanoidRootPart.CFrame * CFrame.new(2.16096544, -1.70169497, -4.07498741, -0.891988277, 0.183446124, 0.41316402, -1.49011612e-8, 0.913961232, -0.405801684, -0.452058613, -0.361970335, -0.815242589)
							p87.Panel.Viewport.LightColor = Color3.fromRGB(255, 249, 166)
							p87.Panel.Viewport.Ambient = Color3.fromRGB(0, 0, 0)
							p87.Panel.Viewport.LightDirection = Vector3.new(1, -1, -1)
							local v90 = p_u_83.SetAssets:FindFirstChild("Gavel")
							if v90 then
								local v91 = v90:Clone()
								v91.Extensions:Destroy()
								v91.Weld.Part0 = p88["Right Arm"]
								v91.Parent = p88
							end
						end)
					end
				end
			end
		end,
		["Opening"] = function(p92, p_u_93, p_u_94, p_u_95, p96, p_u_97, p98)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5, (ref) v_u_6, (ref) v_u_18
			local v_u_99 = v_u_8.Hiromi.DeadlySentencing.DomainBG:Clone()
			v_u_99.Parent = p92
			v_u_99.CFrame = p92.CFrame
			v_u_99.Domain:PivotTo(p92.CFrame + Vector3.new(0, 1, 0))
			v_u_99.Judgeman:PivotTo(CFrame.new(1, 10000, 1))
			task.spawn(function()
				-- upvalues: (copy) p_u_94, (copy) v_u_99
				repeat
					task.wait()
				until not (p_u_94.Parent and (p_u_94.Parent.Parent and p_u_94.Parent.Parent.Parent))
				v_u_99:Destroy()
			end)
			if not p98 then
				local v_u_100 = p_u_93.DomainGround
				v_u_100.Surround.ShapePartial = 1
				v_u_100.Surround.Enabled = true
				v_u_3:AddItem(v_u_100, 2)
				task.spawn(function()
					-- upvalues: (copy) v_u_99, (copy) p_u_93, (ref) v_u_4, (ref) v_u_3
					local v101 = TweenInfo.new(0.4)
					local v102 = v_u_99.Judgeman:Clone()
					v102:PivotTo(p_u_93.CFrame * CFrame.Angles(0, 3.141592653589793, 0) - p_u_93.CFrame.LookVector * 25 + Vector3.new(0, 10, 0))
					for _, v103 in v102:GetDescendants() do
						if (v103:IsA("Decal") or v103:IsA("BasePart")) and v103.Transparency == 0 then
							v103.Transparency = 1
							v_u_4:Create(v103, v101, {
								["Transparency"] = 0
							}):Play()
						end
					end
					v102.Parent = p_u_93
					v_u_3:AddItem(v102, 2)
				end)
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_100, (ref) v_u_13
					v_u_4:Create(v_u_100, TweenInfo.new(0.25), {
						["Transparency"] = 0
					}):Play()
					v_u_13:DomainMapFade(Color3.new(1, 1, 1), 0.25, 1)
				end)
				task.wait(1)
				if not (p_u_94 and p_u_94.Parent) then
					return
				end
				v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Create, workspace, game.SoundService.Effect)
				v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
				v_u_99.Color = Color3.new(1, 1, 1)
				v_u_4:Create(v_u_99, TweenInfo.new(0.5), {
					["Color"] = Color3.fromRGB(253, 234, 141)
				}):Play()
				for _, v104 in v_u_99.Domain:GetDescendants() do
					if v104:IsA("BasePart") and v104.Transparency == 0 then
						local v105 = v104.CFrame
						local v106 = math.random(100, 200)
						v104.CFrame = (v105 - Vector3.new(0, v106, 0)) * CFrame.Angles(math.random(-3.141592653589793, 3.141592653589793), math.random(-3.141592653589793, 3.141592653589793), math.random(-3.141592653589793, 3.141592653589793))
						v104.Transparency = 0
						v_u_4:Create(v104, TweenInfo.new(math.random(1, 2), Enum.EasingStyle.Exponential), {
							["CFrame"] = v105,
							["Transparency"] = 0
						}):Play()
					end
				end
				for _, v107 in v_u_99:GetDescendants() do
					if v107:IsA("Beam") and v107.Parent.Parent == v_u_99 then
						v107.LightEmission = 1
						v_u_4:Create(v107, TweenInfo.new(1), {
							["LightEmission"] = 0
						}):Play()
					end
				end
			end
			local v_u_108 = v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.LightHit)
			if v_u_99.Parent then
				v_u_99.Destroying:Connect(function()
					-- upvalues: (copy) v_u_108
					v_u_108:StartFadeOut(1)
				end)
				task.spawn(function()
					-- upvalues: (copy) v_u_99, (copy) p_u_97
					local v109 = v_u_99.Judgeman
					v109:PivotTo(v_u_99.CFrame * CFrame.Angles(0, 3.141592653589793, 0) - v_u_99.CFrame.LookVector * 25 + Vector3.new(0, 10, 0))
					local v110 = 0
					while true do
						local v111 = task.wait()
						v110 = v110 + v111 * 2
						if v109.Parent and (p_u_97 and p_u_97.Parent) then
							local v112 = p_u_97.HumanoidRootPart.Position
							local v113 = CFrame.lookAt
							local v114 = v_u_99.Position
							local v115 = v112.X
							local v116 = v_u_99.Position.Y
							local v117 = v112.Z
							local v118 = v113(v114, (Vector3.new(v115, v116, v117)))
							local v119 = v109:GetPivot()
							local v120 = v118 + v118.LookVector * 40
							local v121 = math.sin(v110) * 1.5 + 10
							v109:PivotTo((v119:Lerp(v120 + Vector3.new(0, v121, 0), 4 * v111)))
						end
						if not v_u_99.Parent then
							return
						end
					end
				end)
				task.delay(p98 and 0 or 2, function()
					-- upvalues: (copy) v_u_99, (copy) p_u_93, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
					if v_u_99.Parent then
						local _ = v_u_99.Domain.Saws.MainBlade.Blade.CFrame
						for _, v122 in pairs(v_u_99.Domain.Saws:GetChildren()) do
							v122:SetAttribute("cf", v122.Blade.CFrame)
						end
						p_u_93:GetAttributeChangedSignal("VisualHealth"):Connect(function()
							-- upvalues: (ref) v_u_99, (ref) p_u_93, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10
							if v_u_99.Parent then
								local v123 = p_u_93:GetAttribute("VisualHealth")
								local v124 = v_u_99.Domain.Saws:GetChildren()
								local v125 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
								local v126 = false
								for _, v127 in pairs(v124) do
									if v123 < v127:GetAttribute("DecreaseHP") then
										v_u_4:Create(v127.Blade, v125, {
											["CFrame"] = v127:GetAttribute("cf") - Vector3.new(0, 45, 0)
										}):Play()
										if not v126 then
											v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.BladeFallRope, workspace, game.SoundService.Effect)
											task.delay(0.3, function()
												-- upvalues: (ref) v_u_10, (ref) v_u_13, (ref) v_u_9
												v_u_10.CurrentShaker:Shake(v_u_10.Presets.Snap)
												v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence["BladeFall" .. math.random(1, 2)], workspace, game.SoundService.Effect)
											end)
											v126 = true
										end
									end
								end
							end
						end)
					end
				end)
				local v_u_128 = v_u_8.Hiromi.DeadlySentencing.Choose:Clone()
				v_u_128.Parent = v_u_5.PlayerGui
				local v_u_129 = TweenInfo.new(0.5)
				v_u_4:Create(v_u_128.Title, v_u_129, {
					["TextTransparency"] = 0.5
				}):Play()
				v_u_4:Create(v_u_128.Crime, v_u_129, {
					["TextTransparency"] = 0.5
				}):Play()
				local v_u_130 = require(v_u_6.Modules.DeadlyData)
				task.delay(p98 and 0 or 1.2, function()
					-- upvalues: (copy) v_u_128, (ref) v_u_4, (copy) v_u_129, (copy) p_u_93, (ref) v_u_5, (copy) p_u_97, (ref) v_u_13, (ref) v_u_9, (copy) p_u_95, (ref) v_u_18, (copy) v_u_130, (copy) v_u_99
					if v_u_128.Parent then
						v_u_4:Create(v_u_128.Confess, v_u_129, {
							["BackgroundTransparency"] = 0.5,
							["TextTransparency"] = 0
						}):Play()
						v_u_4:Create(v_u_128.Silence, v_u_129, {
							["BackgroundTransparency"] = 0.5,
							["TextTransparency"] = 0
						}):Play()
						v_u_4:Create(v_u_128.Denial, v_u_129, {
							["BackgroundTransparency"] = 0.5,
							["TextTransparency"] = 0
						}):Play()
						v_u_4:Create(v_u_128.Health, v_u_129, {
							["BackgroundTransparency"] = 0.5
						}):Play()
						v_u_4:Create(v_u_128.Health.Bar, v_u_129, {
							["BackgroundTransparency"] = 0
						}):Play()
						v_u_4:Create(v_u_128.Health.Marks.Bar1, v_u_129, {
							["BackgroundTransparency"] = 0.5
						}):Play()
						v_u_4:Create(v_u_128.Health.Marks.Bar2, v_u_129, {
							["BackgroundTransparency"] = 0.5
						}):Play()
						p_u_93:GetAttributeChangedSignal("UI"):Connect(function()
							-- upvalues: (ref) v_u_5, (ref) p_u_97, (ref) p_u_93, (ref) v_u_128, (ref) v_u_13, (ref) v_u_9
							if v_u_5.Character == p_u_97 then
								return
							end
							if p_u_93:GetAttribute("UI") ~= true == false then
								v_u_128.Timer.Visible = true
								for v131 = 3, 1, -1 do
									if v_u_128.Timer.Visible == false then
										break
									end
									v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Tick, workspace, game.SoundService.Effect)
									v_u_128.Timer.Text = v131
									task.wait(1)
								end
							end
						end)
						p_u_93:GetAttributeChangedSignal("UI2"):Connect(function()
							-- upvalues: (ref) v_u_5, (ref) p_u_97, (ref) p_u_93, (ref) v_u_128, (ref) v_u_13, (ref) v_u_9
							if v_u_5.Character ~= p_u_97 then
								return
							end
							local v132 = p_u_93:GetAttribute("UI2")
							if v132 == nil then
								v_u_128.Confess.Visible = true
								v_u_128.Silence.Visible = true
								v_u_128.Denial.Visible = true
								v_u_128.Timer.Visible = false
								v_u_128.Confess.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
								v_u_128.Silence.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
								v_u_128.Denial.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
								return
							end
							if v132 == true then
								v_u_128.Confess.Visible = false
								v_u_128.Silence.Visible = false
								v_u_128.Denial.Visible = false
								return
							end
							if v132 == false then
								v_u_128.Timer.Visible = true
								for v133 = 3, 1, -1 do
									if v_u_128.Timer.Visible == false then
										break
									end
									v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Tick, workspace, game.SoundService.Effect)
									v_u_128.Timer.Text = v133
									task.wait(1)
								end
								v_u_128.Timer.Visible = false
							end
						end)
						local v_u_134 = v_u_128.Denial
						local v_u_135 = "DenialCount"
						local v_u_136 = "DENIAL"
						p_u_93:GetAttributeChangedSignal("DenialCount"):Connect(function()
							-- upvalues: (ref) p_u_93, (copy) v_u_135, (ref) v_u_5, (ref) p_u_97, (copy) v_u_134, (copy) v_u_136
							local v137 = p_u_93:GetAttribute(v_u_135) or 0
							if v137 > 0 and v_u_5.Character ~= p_u_97 then
								v_u_134.Text = v_u_136 .. " (" .. v137 .. ")"
							else
								v_u_134.Text = v_u_136
								v_u_134.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							end
						end)
						local v_u_138 = v_u_128.Silence
						local v_u_139 = "SilenceCount"
						local v_u_140 = "SILENCE"
						p_u_93:GetAttributeChangedSignal("SilenceCount"):Connect(function()
							-- upvalues: (ref) p_u_93, (copy) v_u_139, (ref) v_u_5, (ref) p_u_97, (copy) v_u_138, (copy) v_u_140
							local v141 = p_u_93:GetAttribute(v_u_139) or 0
							if v141 > 0 and v_u_5.Character ~= p_u_97 then
								v_u_138.Text = v_u_140 .. " (" .. v141 .. ")"
							else
								v_u_138.Text = v_u_140
								v_u_138.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							end
						end)
						local v_u_142 = v_u_128.Confess
						local v_u_143 = "ConfessCount"
						local v_u_144 = "CONFESS"
						p_u_93:GetAttributeChangedSignal("ConfessCount"):Connect(function()
							-- upvalues: (ref) p_u_93, (copy) v_u_143, (ref) v_u_5, (ref) p_u_97, (copy) v_u_142, (copy) v_u_144
							local v145 = p_u_93:GetAttribute(v_u_143) or 0
							if v145 > 0 and v_u_5.Character ~= p_u_97 then
								v_u_142.Text = v_u_144 .. " (" .. v145 .. ")"
							else
								v_u_142.Text = v_u_144
								v_u_142.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							end
						end)
						local function v148(p_u_146, p_u_147)
							-- upvalues: (ref) v_u_5, (ref) p_u_97, (ref) v_u_128, (ref) v_u_13, (ref) v_u_9, (ref) p_u_95
							if v_u_5.Character == p_u_97 then
								p_u_146.AutoButtonColor = false
								p_u_146.MouseEnter:Connect(function()
									-- upvalues: (copy) p_u_146
									p_u_146.BackgroundColor3 = Color3.fromRGB(160, 160, 160)
								end)
								p_u_146.MouseLeave:Connect(function()
									-- upvalues: (copy) p_u_146
									p_u_146.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
								end)
							end
							p_u_146.MouseButton1Down:Connect(function()
								-- upvalues: (ref) v_u_5, (ref) p_u_97, (ref) v_u_128, (copy) p_u_146, (ref) v_u_13, (ref) v_u_9, (ref) p_u_95, (copy) p_u_147
								if v_u_5.Character == p_u_97 then
									v_u_128.Confess.Visible = false
									v_u_128.Silence.Visible = false
									v_u_128.Denial.Visible = false
								end
								v_u_128.Confess.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
								v_u_128.Silence.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
								v_u_128.Denial.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
								p_u_146.BackgroundColor3 = Color3.fromRGB(160, 160, 160)
								v_u_13:PlaySound(v_u_9.Misc.UI.Click, workspace, game.SoundService.Effect)
								p_u_95:FireServer(p_u_147)
							end)
						end
						v148(v_u_128.Denial, 1)
						v148(v_u_128.Silence, 2)
						v148(v_u_128.Confess, 3)
						local v_u_149 = 0
						p_u_95.OnClientEvent:Connect(function(p150, p151, p152, p153, p154, p155)
							-- upvalues: (ref) v_u_128, (ref) v_u_18, (ref) v_u_130, (ref) p_u_93, (ref) p_u_97, (ref) v_u_99, (ref) v_u_13, (ref) v_u_9, (ref) v_u_149, (ref) v_u_4
							if p150 and (p151 and p152) then
								v_u_128.Timer.Visible = false
								if p155 and p155.Parent then
									v_u_18(p155, v_u_130.Dialog[p150][1][p151])
								end
								task.wait(0.75)
								if p_u_93 and (p_u_93.Parent and (p_u_97 and p_u_97.Parent)) then
									v_u_18(p150 == 3 and (p151 == 3 and p152 == p151) and v_u_99.Judgeman or p_u_97, p151 == p152 and v_u_130.Dialog[p150][2][p151] or v_u_130.DialogFail[p153])
									if p151 ~= p152 then
										if p153 == 4 then
											v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Sure, p_u_97.Head, game.SoundService.Voice)
										else
											v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.TalkFail, p_u_97.Head, game.SoundService.Voice)
										end
									end
								end
								if v_u_149 ~= p154 then
									v_u_149 = p154
									v_u_4:Create(v_u_128.Health.Bar, TweenInfo.new(p154 >= 3 and 0.65 or 0.8, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
										["Size"] = UDim2.new(p154 / 3, 0, 1, 0)
									}):Play()
									v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Fill, workspace, game.SoundService.Effect)
								end
								if p154 then
									if p154 < 3 then
										task.wait(0.75)
										v_u_128.Confess.Visible = true
										v_u_128.Silence.Visible = true
										v_u_128.Denial.Visible = true
										return
									end
									v_u_99.Judgeman.Face.Face.Transparency = 1
									v_u_99.Judgeman.Face.Face2.Transparency = 0
								end
							end
						end)
					end
				end)
				v_u_128.Crime.Text = v_u_130.Crimes[p96]
				local v_u_156 = v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Music, workspace, game.SoundService.Music, true)
				local v_u_157 = v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Travel, workspace, game.SoundService.Effect, true)
				v_u_4:Create(v_u_157, TweenInfo.new(2), {
					["Volume"] = 0.7
				}):Play()
				game.SoundService.AmbientReverb = Enum.ReverbType.Auditorium
				task.spawn(function()
					-- upvalues: (copy) p_u_94, (ref) v_u_4, (copy) v_u_156, (ref) v_u_3, (copy) v_u_157, (copy) v_u_128
					repeat
						task.wait()
					until not (p_u_94.Parent and (p_u_94.Parent.Parent and p_u_94.Parent.Parent.Parent))
					game.SoundService.AmbientReverb = Enum.ReverbType.NoReverb
					v_u_4:Create(v_u_156, TweenInfo.new(2), {
						["Volume"] = 0
					}):Play()
					v_u_3:AddItem(v_u_156, 2)
					if v_u_157 then
						v_u_157:Destroy()
					end
					if v_u_128 then
						v_u_128:Destroy()
					end
				end)
			else
				v_u_108:StartFadeOut(1)
			end
		end,
		["Shatter"] = function(p158)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_4
			local v159 = v_u_8.Domain:Clone()
			v159.Transparency = 1
			v159.CanCollide = false
			v159.Position = p158
			v159.Parent = workspace.Effects
			v_u_3:AddItem(v159, 3)
			for _, v160 in v159:GetChildren() do
				if v160.Name == "Shatter" then
					v160:Emit(100)
				else
					v160:Destroy()
				end
			end
			v_u_13:PlaySound(v_u_9.Hiromi.DeadlySentence.Shatter, v159, game.SoundService.Effect)
			v159.Transparency = 0
			v_u_4:Create(v159, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			if _G.Settings.DesPHY then
				task.wait(0.04)
				if (workspace.CurrentCamera.CFrame.Position - v159.Position).Magnitude > 150 then
					return
				end
				local v161 = Random.new()
				local v162 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v163 = v_u_8.Gojo.Shard:Clone()
					local v164 = v161:NextUnitVector().Unit
					local v165 = math.random(1, 8)
					local v166 = math.random
					v163.Size = Vector3.new(0.1, v165, v166(1, 8))
					v163.CFrame = CFrame.lookAlong(p158, v164) * CFrame.Angles(1.5707963267948966, 0, 0) + v164 * 37.5
					v163.CFrame = v163.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v163.CanCollide = true
					v163.CollisionGroup = "Effects"
					v163.Parent = workspace.Effects
					local v167 = math.random(-50, 50)
					local v168 = math.random(-50, 50)
					local v169 = math.random
					v163.RotVelocity = Vector3.new(v167, v168, v169(-50, 50))
					v163.Transparency = 0
					v163.Material = Enum.Material.Neon
					v_u_4:Create(v163, v162, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_3:AddItem(v163, 4)
				end
			end
		end,
		["LightShatter"] = function(p170)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5
			local v171 = v_u_8.Hiromi.DeadlySentencing.LightShatter:Clone()
			v171.Position = p170
			v171.Parent = workspace.Effects
			v_u_3:AddItem(v171, 3)
			v171.Shatter:Emit(50)
			v171.Surround:Emit(150)
			v_u_4:Create(v171, TweenInfo.new(0.2), {
				["Transparency"] = 1
			}):Play()
			v_u_13:PlaySound(v_u_9.Gojo.Teleport, v171, game.SoundService.Effect)
			if v_u_5.Character and (v_u_5.Character.HumanoidRootPart.Position - p170).Magnitude < 35 then
				v_u_13:DomainMapFade(Color3.new(1, 1, 1), 0, 0.15)
				v171.DomainGround.Position = p170 - Vector3.new(0, 3, 0)
				v171.Surround:Emit(100)
			end
			if _G.Settings.DesPHY then
				if (workspace.CurrentCamera.CFrame.Position - v171.Position).Magnitude > 150 then
					return
				end
				local v172 = Random.new()
				local v173 = TweenInfo.new(4, Enum.EasingStyle.Exponential, Enum.EasingDirection.In)
				for _ = 1, 80 do
					local v174 = v_u_8.Gojo.Shard:Clone()
					local v175 = v172:NextUnitVector().Unit
					local v176 = math.random(1, 8) / 2
					local v177 = math.random(1, 8) / 2
					v174.Size = Vector3.new(0.1, v176, v177)
					v174.CFrame = CFrame.lookAlong(p170, v175) * CFrame.Angles(1.5707963267948966, 0, 0) + v175 * 37.5
					v174.CFrame = v174.CFrame * CFrame.Angles(0, math.random(0, 3.141592653589793), 0)
					v174.CanCollide = true
					v174.CollisionGroup = "Effects"
					v174.Parent = workspace.Effects
					local v178 = math.random(-50, 50)
					local v179 = math.random(-50, 50)
					local v180 = math.random
					v174.RotVelocity = Vector3.new(v178, v179, v180(-50, 50))
					v174.Transparency = 0
					v174.Material = Enum.Material.Neon
					v_u_4:Create(v174, v173, {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_3:AddItem(v174, 4)
				end
			end
		end,
		["Confiscate"] = function(p181, p182)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_3
			if p181:FindFirstChild("HumanoidRootPart") then
				local v183 = p181.Head:FindFirstChild("Confiscate")
				if v183 then
					local v184 = v183.TextLabel
					v184.Size = v184.Size + UDim2.new(0, 0, 1, 0)
					v183.TextLabel.Text = v183.TextLabel.Text .. "\n- [" .. p182 .. "]"
				else
					local v_u_185 = v_u_8.Hiromi.Confiscate:Clone()
					v_u_185.Parent = p181.Head
					task.delay(3, function()
						-- upvalues: (ref) v_u_4, (ref) v_u_185
						v_u_4:Create(v_u_185.TextLabel, TweenInfo.new(1), {
							["TextTransparency"] = 1
						}):Play()
					end)
					v_u_3:AddItem(v_u_185, 4)
					local v186 = v_u_185.TextLabel
					v186.Size = v186.Size + UDim2.new(0, 0, 1, 0)
					v_u_185.TextLabel.Text = "- [" .. p182 .. "]"
				end
			end
		end,
		["AmpliStart"] = function(p187)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v188 = p187:FindFirstChild("HumanoidRootPart")
			if v188 then
				v_u_13:Flash(p187, Color3.new(0.666667, 1, 1), 1)
				v_u_13:PlaySound(v_u_9.Hiromi.Amplification.Start, v188, game.SoundService.Effect)
				if v_u_5.Character == p187 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["AmpliAbsorb"] = function(p189)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v190 = p189:FindFirstChild("HumanoidRootPart")
			if v190 then
				local v191 = v_u_8.Hiromi.AmpliAbsorb:Clone()
				v191.CFrame = v190.CFrame
				v191.Parent = workspace.Effects
				v_u_3:AddItem(v191, 1)
				v191.Aura:Emit(50)
				v191.Hit:Emit(50)
				v191.Wind2:Emit(10)
				local v192 = v_u_8.Gojo.LapseBlue.LapseBlue.Grab:Clone()
				v192.Size = Vector3.new(20, 20, 20)
				v192.Anchored = true
				v192.CFrame = v190.CFrame
				v192.Parent = workspace.Effects
				local v193 = Instance.new("Highlight", v192)
				v193.FillTransparency = 1
				v193.OutlineTransparency = 1
				v192.Transparency = 50
				v_u_4:Create(v192, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Transparency"] = 1,
					["Size"] = Vector3.new(13, 13, 13)
				}):Play()
				v_u_3:AddItem(v192, 1)
				v_u_13:Flash(p189, Color3.new(0.666667, 1, 1), 1)
				v_u_13:PlaySound(v_u_9.Hiromi.Amplification.Absorb, v190, game.SoundService.Effect)
				if v_u_5.Character == p189 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["Interp"] = function(p_u_194)
			-- upvalues: (ref) v_u_2
			local v_u_195 = p_u_194.CFrame
			local v_u_196 = tick()
			local v_u_197 = p_u_194:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_195, (copy) p_u_194, (ref) v_u_196
				v_u_195 = p_u_194.CFrame
				v_u_196 = tick()
			end)
			local v_u_198 = nil
			v_u_198 = v_u_2.Stepped:Connect(function(_, _)
				-- upvalues: (copy) p_u_194, (ref) v_u_198, (copy) v_u_197, (ref) v_u_195, (ref) v_u_196
				if p_u_194.Parent and not p_u_194:GetAttribute("Rebound") then
					workspace:BulkMoveTo({ p_u_194 }, { v_u_195 + v_u_195.LookVector * (120 * (tick() - v_u_196)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_198:Disconnect()
					v_u_197:Disconnect()
				end
			end)
		end,
		["Recall"] = function(p199, p200, p201, p202)
			-- upvalues: (ref) v_u_13, (ref) v_u_9
			local v203 = p199:FindFirstChild("HumanoidRootPart")
			if not v203 then
				return
			end
			local v204 = tick()
			v_u_13:PlaySound(v_u_9.Yuki.Rebound.Bounce, v203, game.SoundService.Effect)
			p200:SetAttribute("Rebound", true)
			local v205 = 15 * (p202 / 0.5)
			while true do
				local v206 = task.wait()
				local v207 = (tick() - v204) / p202
				local v208 = p201:Lerp(v203.Position, v207)
				local v209 = v207 * 3.14
				local v210 = math.sin(v209) * v205
				local v211 = v208 + Vector3.new(0, v210, 0)
				p200.CFrame = CFrame.lookAlong(v211, p201 - v203.Position)
				if p200:FindFirstChild("Gavel") then
					local v212 = p200.Gavel.Weld
					local v213 = v212.C1
					local v214 = CFrame.Angles
					local v215 = -600 * v206
					v212.C1 = v213 * v214(math.rad(v215), 0, 0)
				end
				if not v203.Parent or p202 < tick() - v204 then
					if p200 then
						p200:Destroy()
					end
					return
				end
			end
		end,
		["HammerHit"] = function(p216, p217)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10
			local v218 = p217:FindFirstChild("HumanoidRootPart")
			if v218 then
				local v219 = v_u_8.Hiromi.Whack:Clone()
				v219.CFrame = v218.CFrame
				v219.Parent = workspace.Effects
				v_u_3:AddItem(v219, 1.5)
				for _, v220 in v219:GetDescendants() do
					if v220:IsA("ParticleEmitter") then
						v220:Emit(v220:GetAttribute("EmitCount"))
					end
				end
				v_u_13:Flash(p217, Color3.new(1, 1, 1))
				v_u_13:PlaySound(v_u_9.Hiromi.Verdict.Hit1, v218, game.SoundService.Effect)
				if v_u_5 == p216 or v_u_5.Character == p217 then
					v_u_10.CurrentShaker:Shake(v_u_10.Presets.LightHit)
				end
			end
		end,
		["Dash"] = function(p221, _)
			-- upvalues: (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3, (ref) v_u_4
			local v_u_222 = p221:FindFirstChild("HumanoidRootPart")
			if v_u_222 then
				v_u_13:PlaySound(v_u_9.Itadori.Rush.Rush, v_u_222, game.SoundService.Effect)
				local v223 = v_u_8.Choso.CounterSwing.Shock:Clone()
				v223.Size = Vector3.new(6, 30, 6)
				v223.CFrame = v_u_222.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v223.Parent = workspace.Effects
				v_u_3:AddItem(v223, 0.2)
				v_u_4:Create(v223, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = v223.Position + v_u_222.CFrame.LookVector * 10
				}):Play()
				for v224 = 1, 4 do
					task.delay(0.04 * v224, function()
						-- upvalues: (ref) v_u_8, (copy) v_u_222, (ref) v_u_4, (ref) v_u_3
						local v225 = v_u_8.Itadori.Shock:Clone()
						v225.CFrame = CFrame.lookAlong(v_u_222.Position, v_u_222.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
						v225.Transparency = 0.3
						v225.Parent = workspace.Effects
						v_u_4:Create(v225, TweenInfo.new(0.15), {
							["Size"] = Vector3.new(20, 0, 20),
							["Transparency"] = 1
						}):Play()
						v_u_3:AddItem(v225, 0.15)
					end)
				end
			end
		end,
		["HammerSwap"] = function(p226, p227)
			-- upvalues: (ref) v_u_8, (ref) v_u_3, (ref) v_u_13, (ref) v_u_9
			local v228 = p226:FindFirstChild("HumanoidRootPart")
			if v228 then
				local v229 = Instance.new("Model")
				local v230 = v_u_8.Hiromi.SwordBuild:Clone()
				v230.Parent = v229
				v229:ScaleTo(2)
				v230.Position = p227:IsA("Attachment") and p227.WorldPosition or p227.Position
				v229.Parent = workspace.Effects
				v_u_3:AddItem(v229, 1.5)
				for _, v231 in v230:GetDescendants() do
					if v231:IsA("ParticleEmitter") then
						if v231.Parent ~= v230.Create then
							v231.Enabled = false
						end
						v231:Emit(v231:GetAttribute("EmitCount"))
					end
				end
				v_u_13:PlaySound(v_u_9.Hiromi.Recall, v228, game.SoundService.Effect)
			end
		end,
		["HammerIFrame"] = function(p232, p233)
			-- upvalues: (ref) v_u_13
			if p232:FindFirstChild("HumanoidRootPart") then
				local v_u_234 = v_u_13:Flash(p232, Color3.fromRGB(255, 170, 0), 1)
				p233.AncestryChanged:Once(function()
					-- upvalues: (copy) v_u_234
					v_u_234:Destroy()
				end)
			end
		end
	}
	v_u_11.Effects:Connect(function(p236, ...)
		-- upvalues: (copy) v_u_235
		local v237 = v_u_235[p236]
		if v237 then
			v237(...)
		end
	end)
	v_u_11.Hitbox:Connect(function(p238, p239, p240)
		-- upvalues: (ref) v_u_12, (ref) v_u_4
		local v241 = p239.HumanoidRootPart
		if not v241 then
			return
		end
		local v242 = nil
		while true do
			local v243 = v_u_12:SphereHitbox(p239, CFrame.new(0, 0, -4), 8)
			for _, v244 in v243 do
				local v245 = v244:FindFirstChild("Info")
				if v245 then
					local v246 = v245:FindFirstChild("Knockback")
					if not v246 or v246.Value ~= false then
						v242 = v243
						break
					end
				end
			end
			if v242 then
				local v247 = p238:FindFirstChildWhichIsA("NumberValue")
				if v247 then
					v_u_4:Create(v247, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p238.Parent then
				break
			end
		end
		p240:FireServer(v242, v241.CFrame)
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("HiromiService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14