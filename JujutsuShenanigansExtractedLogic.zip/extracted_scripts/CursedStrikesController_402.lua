-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = RaycastParams.new()
v_u_9.FilterType = Enum.RaycastFilterType.Include
v_u_9.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "CursedStrikesController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_8, (ref) v_u_10, (copy) v_u_9, (ref) v_u_11
	local v_u_49 = {
		["Swing"] = function(p14)
			-- upvalues: (ref) v_u_12, (ref) v_u_7
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_12:PlaySound(v_u_7.Itadori.CursedStrikes.Startup, v15, game.SoundService.Effect)
			end
		end,
		["Leap"] = function(p16, p17)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7
			local v18 = p16:FindFirstChild("HumanoidRootPart")
			if v18 then
				local v19 = v_u_6.Gojo.HardHit:Clone()
				v19.CFrame = v18.CFrame * CFrame.Angles(1.9198621771937625, 0, 0)
				v19.Ring.RotSpeed = NumberRange.new(300, 600)
				v19.Ring.Speed = NumberRange.new(0.1, 20)
				v19.Parent = workspace.Effects
				v19.Ring:Emit(15)
				v_u_2:AddItem(v19, 0.5)
				p17.Position = v18.Position + Vector3.new(0, 12, 0)
				v_u_12:PlaySound(v_u_7.Itadori.CursedStrikes.Spin, v18, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p20, p_u_21)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_5, (ref) v_u_12, (ref) v_u_7
			local v_u_22 = p20:FindFirstChild("HumanoidRootPart")
			if v_u_22 then
				if p_u_21 == true then
					local v23 = v_u_6.Gojo.HardHit:Clone()
					v23.CFrame = v_u_22.CFrame * CFrame.Angles(-0.7853981633974483, 0, 0)
					v23.Ring.RotSpeed = NumberRange.new(500, 1000)
					v23.Ring.Speed = NumberRange.new(0.1, 60)
					v23.Ring.Drag = 2
					v23.Ring.Lifetime = NumberRange.new(0.2, 0.5)
					v23.Parent = workspace.Effects
					v23.Sparks:Emit(20)
					v23.Ring:Emit(30)
					v_u_2:AddItem(v23, 0.5)
					task.delay(0.05, function()
						-- upvalues: (ref) v_u_6, (copy) v_u_22, (ref) v_u_3, (ref) v_u_2
						local v24 = v_u_6.Itadori.Shock:Clone()
						v24.CFrame = v_u_22.CFrame * CFrame.Angles(0.7853981633974483, 0, 0)
						v24.Parent = workspace.Effects
						v_u_3:Create(v24, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v24, 0.2)
						task.wait(0.05)
						local v25 = v_u_6.Itadori.Shock:Clone()
						v25.CFrame = v_u_22.CFrame * CFrame.Angles(0.7853981633974483, 0, 0)
						v25.Parent = workspace.Effects
						v_u_3:Create(v25, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v25, 0.2)
					end)
				else
					local v26 = Instance.new("Model")
					local v27 = v_u_5.Utils.Itadori.RushWind:Clone()
					v27.CFrame = p_u_21 * CFrame.new(0, -1, 0)
					v27.Parent = v26
					v26.Parent = workspace.Effects
					v26:ScaleTo(0.6)
					v27.Ring:Emit(7)
					v27.Dash1.Dash:Emit(1)
					v27.Dash2.Dash:Emit(1)
					v_u_2:AddItem(v26, 2)
					local v28 = v_u_6.Itadori.Shock:Clone()
					v28.CFrame = p_u_21 * CFrame.Angles(1.5707963267948966, 0, 0)
					v28.Parent = workspace.Effects
					v_u_3:Create(v28, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v28, 0.2)
					task.delay(0.1, function()
						-- upvalues: (ref) v_u_6, (copy) p_u_21, (copy) v_u_22, (ref) v_u_3, (ref) v_u_2
						local v29 = v_u_6.Itadori.Shock:Clone()
						v29.CFrame = (p_u_21 - p_u_21.Position + v_u_22.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
						v29.Parent = workspace.Effects
						v_u_3:Create(v29, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v29, 0.2)
					end)
				end
				v_u_12:PlaySound(v_u_7.Itadori.Rush.Rush, v_u_22, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p30, p31)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v32 = p30:FindFirstChild("HumanoidRootPart")
			if v32 then
				v_u_12:Flash(p30, Color3.new(1, 1, 1))
				if p31 then
					v_u_12:PlaySound(v_u_7.Itadori.CursedStrikes.Hit, v32, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit" .. math.random(1, 4)), v32, game.SoundService.Effect)
				end
				if v_u_4.Character == p30 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["Crush"] = function(p33, p34)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v35 = v_u_6.Itadori.CrushingBlow:Clone()
			v35.Position = p34
			v35.Parent = workspace.Effects
			v_u_3:Create(v35.Air, TweenInfo.new(0.2), {
				["Position"] = Vector3.new(0, 0, 0)
			}):Play()
			v_u_3:Create(v35.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v35.Floor.Glow:Emit(1)
			v35.Floor.Ring:Emit(10)
			v35.Floor.Sparks:Emit(10)
			v_u_2:AddItem(v35, 1.5)
			v_u_12:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v35, game.SoundService.Effect)
			if v_u_4 == p33 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["FinalHit"] = function(p36, p37)
			-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v38 = p36:FindFirstChild("HumanoidRootPart")
			local v39 = p37:FindFirstChild("HumanoidRootPart")
			v_u_12:Flash(p37, Color3.new(1, 1, 1))
			v_u_12:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v39, game.SoundService.Effect)
			local v40 = CFrame.new(v38.Position, v39.Position + Vector3.new(0, 2, 0))
			local v41 = v_u_6.Gojo.HardHit:Clone()
			v41.CFrame = v40 + v40.LookVector * 3.5
			v41.Parent = workspace.Effects
			v41.Dust:Emit(5)
			v41.Ring:Emit(5)
			v41.Sparks:Emit(10)
			v_u_2:AddItem(v41, 0.5)
			if v_u_4.Character == p36 or v_u_4.Character == p37 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["BlackFlashHit"] = function(p42, p43, p44)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_12, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			if p42:FindFirstChild("HumanoidRootPart") then
				local v45 = p43:FindFirstChild("HumanoidRootPart")
				if v45 then
					local v_u_46 = v_u_6.Itadori.DivergentFist.BlackFlashHit:Clone()
					v_u_46.Position = v45.Position
					v_u_46.Parent = workspace.Effects
					v_u_2:AddItem(v_u_46, 1)
					local v47 = v_u_6.Itadori.DivergentFist.FinisherDrag:Clone()
					v47.Parent = v45
					v_u_2:AddItem(v47, 0.3)
					v_u_12:Flash(p43, Color3.new(1, 0, 0))
					v_u_12:PlaySound(v_u_7.Itadori.DivergentFist.BlackFlashHit, v45, game.SoundService.Effect)
					v_u_46.Wind2:Emit(8)
					v_u_3:Create(v_u_46.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_46
						v_u_46.Blast:Emit(8)
						v_u_46.Sparks:Emit(15)
						v_u_46.Lightning:Emit(6)
						v_u_46.Wind:Emit(7)
					end)
					if v_u_4.Character == p42 or v_u_4.Character == p43 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
						if not p44 then
							return
						end
						local v48 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
						v48.Parent = game.Lighting
						task.wait(0.04)
						v48.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v48.Brightness = 200
						v48.Contrast = -1000
						task.wait(0.04)
						v48:Destroy()
					end
				end
			else
				return
			end
		end
	}
	v_u_10.Effects:Connect(function(p50, ...)
		-- upvalues: (copy) v_u_49
		local v51 = v_u_49[p50]
		if v51 then
			v51(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p52, p53, p54)
		-- upvalues: (ref) v_u_9, (ref) v_u_11
		local v55 = p53.HumanoidRootPart
		if not v55 then
			return
		end
		while true do
			local v56 = workspace:Raycast(v55.Position, p52.Velocity.Unit * 7, v_u_9)
			local v57 = v_u_11:SphereHitbox(p53, CFrame.new(0, -5, -5), 12)
			if #v57 > 0 or v56 then
				local v58
				if v56 then
					v58 = v56.Position
				else
					v58 = v56
				end
				p54:FireServer(v57, v58)
				if v56 then
					p52:Destroy()
				end
			end
			task.wait(0.025)
			if not p52.Parent then
				return
			end
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("CursedStrikesService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13