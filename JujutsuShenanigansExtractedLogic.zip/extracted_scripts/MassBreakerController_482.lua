-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "MassBreakerController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (ref) v_u_11, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_34 = {
		["Startup"] = function(p13)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v14 = p13:FindFirstChild("HumanoidRootPart")
			if v14 then
				v_u_10:PlaySound(v_u_7.Yuki.Mass.Start, v14, game.SoundService.Effect)
			end
		end,
		["Dash"] = function(p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7
			local v_u_16 = p15:FindFirstChild("HumanoidRootPart")
			if v_u_16 then
				local v17 = v_u_6.Choso.CounterSwing.Shock:Clone()
				v17.Size = Vector3.new(6, 30, 6)
				v17.CFrame = v_u_16.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v17.Parent = workspace.Effects
				v_u_2:AddItem(v17, 0.2)
				v_u_3:Create(v17, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(25, 0, 25),
					["Transparency"] = 1,
					["Position"] = v17.Position + v_u_16.CFrame.LookVector * 10
				}):Play()
				v_u_10:PlaySound(v_u_7.Yuki.Mass.Miss, v_u_16, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Yuki.Mass.Dash, v_u_16, game.SoundService.Effect)
				for v18 = 1, 4 do
					task.delay(0.04 * v18, function()
						-- upvalues: (ref) v_u_6, (copy) v_u_16, (ref) v_u_3, (ref) v_u_2
						local v19 = v_u_6.Itadori.Shock:Clone()
						v19.CFrame = CFrame.lookAlong(v_u_16.Position, v_u_16.Velocity) * CFrame.Angles(1.5707963267948966, 0, 0)
						v19.Transparency = 0.3
						v19.Parent = workspace.Effects
						v_u_3:Create(v19, TweenInfo.new(0.15), {
							["Size"] = Vector3.new(20, 0, 20),
							["Transparency"] = 1
						}):Play()
						v_u_2:AddItem(v19, 0.15)
					end)
				end
			end
		end,
		["Aerial"] = function(p20, p21)
			-- upvalues: (ref) v_u_11
			local v22 = p20:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = p20:FindFirstChild("Humanoid")
				if v23 then
					local v24 = Instance.new("BodyGyro", v22)
					v24.P = 10000
					v24.MaxTorque = Vector3.new(40000, 40000, 40000)
					p21.Position = v22.Position + Vector3.new(0, 6, 0)
					v23.PlatformStand = true
					repeat
						local v25 = v_u_11:GetMouseTarget()
						v24.CFrame = p21:GetAttribute("Aim") or CFrame.new(v22.Position, v25)
						task.wait()
					until not p21.Parent
					v24:Destroy()
					v23.PlatformStand = false
				end
			else
				return
			end
		end,
		["Hit"] = function(p26, p27, p28)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v29 = p27:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = v_u_6.Yuki.MassHit:Clone()
				v30.CFrame = CFrame.lookAlong(v29.Position, p28.LookVector)
				v30.Parent = workspace.Effects
				v_u_2:AddItem(v30, 1)
				for _, v31 in v30:GetDescendants() do
					if v31:IsA("ParticleEmitter") then
						v31:Emit(v31:GetAttribute("EmitCount"))
					end
				end
				local v32 = v_u_6.Gojo.LapseBlue.LapseBlue.Grab:Clone()
				v32.Size = Vector3.new(40, 40, 40)
				v32.Weld.Part0 = v29
				v32.Parent = workspace.Effects
				local v33 = Instance.new("Highlight", v32)
				v33.FillTransparency = 1
				v33.OutlineTransparency = 1
				v32.Transparency = 50
				v_u_3:Create(v32, TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(0, 0, 0),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v32, 0.4)
				v_u_10:Flash(p27, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Yuki.Mass.Hit, v29, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Yuki.Mass.Hit2, v29, game.SoundService.Effect)
				if v_u_4 == p26 or v_u_4.Character == p27 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p35, ...)
		-- upvalues: (copy) v_u_34
		local v36 = v_u_34[p35]
		if v36 then
			v36(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("MassBreakerService")
	v_u_10 = v_u_1.GetController("FXController")
	v_u_11 = v_u_1.GetController("ToolController")
end
return v12