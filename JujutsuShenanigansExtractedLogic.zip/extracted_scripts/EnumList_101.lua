-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return require(script.Parent._Index["sleitnick_enum-list@2.1.0"]["enum-list"])