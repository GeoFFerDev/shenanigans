-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 9,
	["Desc"] = "When you just need to chill"
}
local v_u_2 = game:GetService("TweenService")
function v1.Callback(p3)
	-- upvalues: (copy) v_u_2
	if p3 == true and _G.LocalSettings.Goodnight == true then
		_G.LocalSettings.Goodnight = false
		_G.SettingUpdate.Goodnight:Fire()
	end
	if p3 == true and _G.LocalSettings.Darkness == true then
		_G.LocalSettings.Darkness = false
		_G.SettingUpdate.Darkness:Fire()
	end
	if p3 == true then
		v_u_2:Create(game.Lighting, TweenInfo.new(0.5), {
			["ClockTime"] = 17.7,
			["Ambient"] = Color3.fromRGB(172, 109, 33),
			["OutdoorAmbient"] = Color3.fromRGB(255, 163, 87),
			["FogColor"] = Color3.fromRGB(84, 0, 0)
		}):Play()
	else
		v_u_2:Create(game.Lighting, TweenInfo.new(0.5), {
			["ClockTime"] = 14.5,
			["Ambient"] = Color3.new(1, 1, 1),
			["OutdoorAmbient"] = Color3.new(1, 1, 1),
			["FogColor"] = Color3.new(1, 1, 1)
		}):Play()
	end
end
return v1