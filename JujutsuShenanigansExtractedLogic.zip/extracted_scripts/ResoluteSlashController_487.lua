-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("AssetService")
local v_u_3 = game:GetService("HttpService")
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_4 = game:GetService("Debris")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game.Players.LocalPlayer
local v7 = game.ReplicatedStorage
local _ = v7.Animations
local v_u_8 = v7.Utils
local v_u_9 = v7.Sounds
local v_u_10 = require(v7.Modules.CameraShaker)
local v_u_11 = require(v7.Modules.StaticLightning)
local v_u_12 = require(v7.Modules.LightningBeams)
local v_u_13 = Random.new()
local v_u_14 = nil
local v_u_15 = nil
local v16 = v_u_1.CreateController({
	["Name"] = "ResoluteSlashController"
})
function decode(p_u_17)
	-- upvalues: (copy) v_u_3
	local v_u_18 = nil
	if not pcall(function()
		-- upvalues: (copy) p_u_17, (ref) v_u_18, (ref) v_u_3
		v_u_18 = v_u_3:JSONDecode((("{\"m\":null,\"t\":\"buffer\",\"zbase64\":\"%*\"}"):format(p_u_17)))
	end) then
		v_u_18 = v_u_3:JSONDecode((("{\"m\":null,\"t\":\"buffer\",\"base64\":\"%*\"}"):format(p_u_17)))
	end
	return buffer.readstring(v_u_18, 0, buffer.len(v_u_18))
end
function v16.KnitStart(_)
	-- upvalues: (copy) v_u_8, (copy) v_u_4, (ref) v_u_14, (copy) v_u_9, (copy) v_u_6, (copy) v_u_5, (copy) v_u_2, (copy) v_u_13, (copy) v_u_12, (copy) v_u_10, (copy) v_u_11, (ref) v_u_15
	local v_u_19 = {}
	for v20, v21 in v_u_8.Yuta.ResoluteSlash.BlackFlashFlipbook:GetChildren() do
		v_u_19[v20] = buffer.fromstring(decode(v21:GetAttribute("Image")))
	end
	local v_u_22 = v_u_8.Yuta.ResoluteSlash.BlackFlashFlipbook:GetAttribute("Size")
	local v_u_23 = Random.new()
	local v_u_128 = {
		["WarnAndTrack"] = function(p24, p25, p26, p27)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9, (ref) v_u_6
			local v28 = p24:FindFirstChild("HumanoidRootPart")
			if v28 then
				local v29 = v_u_8.Itadori.CounterHit.Feint:Clone()
				for _, v30 in v29:GetChildren() do
					v30.Color = ColorSequence.new(Color3.fromRGB(255, 170, 255))
					v30.TimeScale = 0.7
				end
				v29.Parent = v28
				v29.Sparks:Emit(30)
				v29.Ring:Emit(6)
				v_u_4:AddItem(v29, 1)
				local v31 = p26:FindFirstChild("HumanoidRootPart")
				if v31 then
					if not p27 then
						v_u_14:PlaySound(v_u_9.Yuta.SwordGrab, v31, game.SoundService.Effect)
					end
					if p26 == v_u_6.Character then
						repeat
							task.wait()
							p25.CFrame = CFrame.new(v31.Position, v28.Position)
						until not p25.Parent
					end
				end
			else
				return
			end
		end,
		["Teleport"] = function(p32, p33)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5
			local v34 = p32:FindFirstChild("HumanoidRootPart")
			if v34 then
				v_u_14:PlaySound(v_u_9.Yuta.Leap, v34, game.SoundService.Effect)
				v_u_14:DustTrail(p32, 0.2, CFrame.Angles(0, -1.5707963267948966, 0))
				local v35 = v_u_8.Goku.Vanish
				local v36 = v35.Limb.Attachment
				local v37 = v35.Head.Attachment
				local v38 = v35.Torso.Attachment
				local v39 = v35.Limb2.Attachment
				local v40 = v35.Head2.Attachment
				local v41 = v35.Torso2.Attachment
				local function v47(p42, p_u_43, p_u_44)
					-- upvalues: (ref) v_u_4
					local v45 = p42:Clone()
					v45.Parent = p_u_44
					v45.Vanish:Emit(1)
					v_u_4:AddItem(v45, 0.3)
					task.delay(0.1, function()
						-- upvalues: (copy) p_u_43, (copy) p_u_44, (ref) v_u_4
						local v46 = p_u_43:Clone()
						v46.Parent = p_u_44
						v46.Vanish:Emit(1)
						v_u_4:AddItem(v46, 0.3)
					end)
				end
				local v48 = {}
				for _, v49 in p32:GetDescendants() do
					if v49:IsA("BasePart") or v49:IsA("Decal") and v49.Transparency ~= 1 then
						v48[v49] = v49.Transparency
						v49.Transparency = 1
					end
				end
				v47(v38, v41, p32.Torso)
				v47(v37, v40, p32.Head)
				v47(v36, v39, p32["Right Arm"])
				v47(v36, v39, p32["Left Arm"])
				v47(v36, v39, p32["Right Leg"])
				v47(v36, v39, p32["Left Leg"])
				task.wait(0.15)
				for _, v50 in p32:GetDescendants() do
					if v48[v50] then
						v_u_5:Create(v50, TweenInfo.new(0.1), {
							["Transparency"] = v48[v50]
						}):Play()
					end
				end
				if not p33 then
					local v51 = p32.SetAssets:FindFirstChild("YutaSword")
					if not v51 then
						return
					end
					local v52 = v51.Sword.Blade
					local v53 = v_u_8.Yuta.ResoluteSlash.SwordBurst2.SwordB2:Clone()
					v53.Parent = v52
					v_u_4:AddItem(v53, 1)
					for _, v_u_54 in v53:GetDescendants() do
						if v_u_54:IsA("ParticleEmitter") then
							task.delay(v_u_54:GetAttribute("EmitDelay"), function()
								-- upvalues: (copy) v_u_54
								v_u_54:Emit(v_u_54:GetAttribute("EmitCount"))
							end)
						end
					end
					task.wait(0.1)
					local v55 = v_u_8.Yuta.ResoluteSlash.SwordBurst.Center:Clone()
					v55.Parent = v52
					v_u_4:AddItem(v55, 0.2)
					v55.Glow:Emit(1)
				end
			end
		end,
		["ChargeEffect"] = function(p56)
			-- upvalues: (ref) v_u_8, (ref) v_u_4
			local v57 = p56.SetAssets:FindFirstChild("YutaSword")
			if v57 then
				local v58 = v57.Sword.Blade
				local v59 = v_u_8.Yuta.ResoluteSlash.SwordBurst.Attachment0:Clone()
				local v60 = v_u_8.Yuta.ResoluteSlash.SwordBurst.Center:Clone()
				v59.Parent = v58
				v60.Parent = v58
				v_u_4:AddItem(v59, 0.5)
				v_u_4:AddItem(v60, 4)
				v59.Burst1:Emit(1)
				v60.Burst2:Emit(1)
				task.wait(0.2)
				v60:Destroy()
				local v61 = v_u_8.Yuta.ResoluteSlash.SwordBurst.Sparks:Clone()
				v61.Parent = v58
				v_u_4:AddItem(v61, 0.7)
				v61:Emit(30)
			end
		end,
		["Confused"] = function(p62)
			-- upvalues: (ref) v_u_8, (ref) v_u_4
			local v63 = p62:FindFirstChild("Head")
			if v63 then
				local v64 = v_u_8.Yuta.ResoluteSlash.Confused.Attachment:Clone()
				v64.Parent = v63
				v64.Question:Emit(1)
				v_u_4:AddItem(v64, 1)
			end
		end,
		["Swing"] = function(p65)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			local v66 = p65:FindFirstChild("HumanoidRootPart")
			if v66 then
				if p65.SetAssets:FindFirstChild("YutaSword") then
					v_u_14:PlaySound(v_u_9.Yuta.Swing, v66, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Slash"] = function(p67, p68)
			-- upvalues: (ref) v_u_8, (ref) v_u_4, (ref) v_u_14, (ref) v_u_9
			local v69 = v_u_8.Yuta.ResoluteSlash.SlashHit.Attachment:Clone()
			v69.Parent = p68.Head
			v69.WorldCFrame = CFrame.lookAlong(v69.WorldPosition, p67)
			v69.Slash:Emit(2)
			v_u_4:AddItem(v69, 0.5)
			v_u_14:PlaySound(v_u_9.Yuta.ResoluteSlash, p68.Head, game.SoundService.Effect)
		end,
		["Hit"] = function(p70, p71)
			-- upvalues: (ref) v_u_14, (ref) v_u_9
			v_u_14:Flash(p70, Color3.fromRGB(255, 170, 255))
			if p71 then
				v_u_14:PlaySound(v_u_9.Yuta.ResoluteHit, p70.Head, game.SoundService.Effect)
			end
		end,
		["BlackFlashWindup"] = function(p72)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_2, (copy) v_u_22, (copy) v_u_19, (copy) v_u_23
			local v73 = p72:FindFirstChild("HumanoidRootPart")
			if v73 then
				local v74 = p72["Left Arm"].LeftGripAttachment
				if v74 then
					v_u_14:PlaySound(v_u_9.Yuta.BlackFlash.Windup, v73, game.SoundService.Music)
					v_u_14:PlaySound(v_u_9.Yuta.BlackFlash.Windup2, v73, game.SoundService.Effect)
					local v75 = v_u_8.Yuta.ResoluteSlash.BlackFlashWindup:Clone()
					local v76 = v75.BB.Frame
					v75.Parent = workspace.Effects
					local v77 = v_u_2:CreateEditableImage({
						["Size"] = v_u_22
					})
					v76.ImageContent = Content.fromObject(v77)
					local v78 = 0.5 / #v_u_19
					local v79 = #v_u_19 * 1.8
					local v80 = 0
					for _ = 1, 2 do
						for _, v81 in v_u_19 do
							local v82 = v73.Position + v_u_23:NextUnitVector() * 4
							local v83 = v74.WorldPosition
							local v84 = v80 / v79
							v75.Position = v82:Lerp(v83, (math.clamp(v84, 0, 1)))
							v80 = v80 + 1
							v77:WritePixelsBuffer(Vector2.zero, v77.Size, v81)
							task.wait(v78)
						end
					end
					v75:Destroy()
				end
			else
				return
			end
		end,
		["BlackFlash"] = function(p_u_85, p_u_86, p_u_87)
			-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_5, (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (ref) v_u_12, (ref) v_u_6, (ref) v_u_10
			local v88 = p_u_85:FindFirstChild("HumanoidRootPart")
			if v88 then
				local v_u_89 = p_u_86:FindFirstChild("HumanoidRootPart")
				if v_u_89 then
					v_u_14:PlaySound(v_u_9.Yuta.BlackFlash.Land2, v88, game.SoundService.Effect)
					local v_u_90 = v_u_14:PlaySound(v_u_9.Yuta.BlackFlash.Land, v88, game.SoundService.Music)
					task.delay(5, function()
						-- upvalues: (ref) v_u_5, (copy) v_u_90
						v_u_5:Create(v_u_90, TweenInfo.new(3), {
							["Volume"] = 0
						}):Play()
					end)
					local v_u_91 = p_u_86.Head.FaceFrontAttachment
					local v_u_92 = v_u_8.Itadori.DivergentFist.BlackFlashHit:Clone()
					v_u_92.Position = v_u_89.Position
					v_u_92.Parent = workspace.Effects
					v_u_4:AddItem(v_u_92, 1)
					v_u_92.Wind2:Emit(8)
					v_u_5:Create(v_u_92.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_92
						v_u_92.Blast:Emit(8)
						v_u_92.Sparks:Emit(15)
						v_u_92.Lightning:Emit(6)
						v_u_92.Wind:Emit(7)
					end)
					v_u_14:Flash(p_u_86, Color3.new(1, 0, 0))
					v_u_14:PlaySound(v_u_9.Itadori.DivergentFist.BlackFlashHit, v_u_89, game.SoundService.Effect)
					task.spawn(function()
						-- upvalues: (copy) v_u_89, (ref) v_u_13, (ref) v_u_12, (copy) v_u_91, (copy) p_u_87, (copy) p_u_86, (copy) p_u_85
						local v93 = Instance.new("Model", workspace.Effects)
						local v94 = Instance.new("Highlight", v93)
						v94.DepthMode = Enum.HighlightDepthMode.Occluded
						v94.OutlineColor = Color3.new(1, 0, 0)
						v94.FillColor = Color3.new(0, 0, 0)
						v94.FillTransparency = 0
						repeat
							local v95 = Instance.new("Attachment", v_u_89)
							v95.Position = v_u_13:NextUnitVector() * 30
							local v_u_96 = v_u_12.new(v_u_91, v95, nil, v93)
							v_u_96.Color = Color3.new(1, 0, 0)
							v_u_96.PulseSpeed = 300
							v_u_96.FadeLength = 0.35
							v_u_96.MaxRadius = 20
							v_u_96.MinRadius = 0
							v_u_96.AnimationSpeed = 75
							v_u_96.MinThicknessMultiplier = 0.1
							v_u_96.MaxThicknessMultiplier = 3
							task.delay(0.1, function()
								-- upvalues: (copy) v_u_96
								v_u_96:Destroy()
							end)
							task.wait(0.02)
						until not (p_u_87.Parent and (p_u_86.Parent and p_u_85.Parent))
						v93:Destroy()
					end)
					if v_u_6.Character == p_u_85 or v_u_6.Character == p_u_86 then
						v_u_10.CurrentShaker:Shake(v_u_10.Presets.HeavyHit)
						local v97 = v_u_8.Itadori.DivergentFist.BlackFlashCC:Clone()
						v97.Parent = game.Lighting
						task.wait(0.04)
						v97.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v97.Brightness = 200
						v97.Contrast = -1000
						task.wait(0.04)
						v97:Destroy()
					end
				end
			else
				return
			end
		end,
		["BlackFlashTrail"] = function(p98)
			-- upvalues: (ref) v_u_8, (ref) v_u_11, (ref) v_u_5
			local v99 = Random.new()
			local v100 = v_u_8.Yuta.ResoluteSlash.Disk
			local v101 = Instance.new("Model", workspace.Effects)
			local v102 = Instance.new("Highlight")
			v102.FillColor = Color3.new()
			v102.OutlineTransparency = 1
			v102.FillTransparency = 0
			v102.DepthMode = Enum.HighlightDepthMode.Occluded
			v102.Parent = v101
			local v103 = workspace:Raycast(p98.Position, p98.LookVector * 100, _G.MapParams)
			local v104 = (not v103 and 100 or v103.Distance) / 20
			if v104 >= 1 then
				local v105 = v_u_11.ThicknessFade(0.5, 1.2)
				local v106 = {}
				for v107 = 1, v104 do
					local v108 = (p98 * CFrame.new(0, 0, -20 * v107 + 5)).Position
					for _ = 1, 5 do
						local v109 = 20
						local v110 = v99:NextUnitVector()
						local v111 = workspace:Raycast(v108, v110 * v109, _G.MapParams)
						if v111 then
							v109 = v111.Distance
						end
						local v112 = v_u_11.CreateBolt
						local v113 = {
							["Position1"] = v108,
							["Position2"] = v108 + v110 * v109
						}
						local v114 = v109 / 6
						v113.PartCount = math.floor(v114)
						v113.Thickness = v105
						v113.Color = Color3.new(1, 0, 0)
						v113.Parent = v101
						local v_u_115 = v112(v113)
						if v111 then
							local v116 = v99:NextNumber(2, 4)
							local v117 = v100:Clone()
							v117.CFrame = CFrame.lookAlong(v111.Position, v111.Normal) * CFrame.Angles(0, 1.5707963267948966, 0)
							v117.Size = v117.Size * Vector3.new(1, v116, v116)
							v117.Parent = v101
							table.insert(v_u_115, v117)
						end
						table.insert(v106, v_u_115)
						for _, v118 in v_u_115 do
							v118.Transparency = 1
						end
						task.spawn(function()
							-- upvalues: (copy) v_u_115, (ref) v_u_5
							for _, v119 in v_u_115 do
								task.wait(0.02)
								v119.Transparency = 0
								v_u_5:Create(v119, TweenInfo.new(0.2), {
									["Size"] = v119.Size * Vector3.new(0.5, 0.5, 1)
								}):Play()
							end
							task.wait(0.1)
							for _, v120 in v_u_115 do
								v120:Destroy()
								task.wait(0.02)
							end
						end)
					end
					task.wait(0.1)
				end
				task.wait(0.3)
				v101:Destroy()
			end
		end,
		["FinalThrow"] = function(p121, p122, p123)
			-- upvalues: (ref) v_u_8, (ref) v_u_5, (ref) v_u_4, (ref) v_u_6, (ref) v_u_14, (ref) v_u_10
			local v124 = p121:FindFirstChild("HumanoidRootPart")
			if v124 then
				local v125 = p122.Position
				local _ = p122.LookVector
				local v126 = v_u_8.Itadori.DivergentFist.BlackFlashLaunch:Clone()
				v126.CFrame = v124.CFrame * CFrame.new(2, 1, -5)
				v126.Parent = workspace.Effects
				v126.Wind:Emit(20)
				v126.Sparks:Emit(20)
				v126.Flare:Emit(20)
				v126.Back1.Back:Emit(1)
				v126.Back2.Back:Emit(1)
				v_u_5:Create(v126.Back1, TweenInfo.new(2), {
					["CFrame"] = v126.Back1.CFrame - v126.Back1.CFrame.LookVector * 20
				}):Play()
				v_u_5:Create(v126.Back2, TweenInfo.new(2), {
					["CFrame"] = v126.Back2.CFrame - v126.Back2.CFrame.LookVector * 20
				}):Play()
				v_u_5:Create(v126.PointLight, TweenInfo.new(1), {
					["Brightness"] = 0
				}):Play()
				v_u_4:AddItem(v126, 3)
				if v_u_6.Character == p121 or v_u_6.Character == p123 then
					local v127 = v_u_8.Itadori.DivergentFist.BlackFlashCC:Clone()
					v127.Parent = game.Lighting
					task.wait(0.04)
					v127.TintColor = Color3.new(1, 1, 1)
					task.wait(0.04)
					v127.Brightness = 200
					v127.Contrast = -1000
					task.wait(0.04)
					v127:Destroy()
				end
				v_u_14:Flash(p121, Color3.new(1, 0, 0))
				v_u_14:Bleed(p123)
				if (workspace.CurrentCamera.CFrame.Position - v125).Magnitude <= 80 then
					v_u_10.CurrentShaker:ShakeSustain(v_u_10.Presets.Snap):StartFadeOut(1)
				end
			end
		end
	}
	v_u_15.Effects:Connect(function(p129, ...)
		-- upvalues: (copy) v_u_128
		local v130 = v_u_128[p129]
		if v130 then
			v130(...)
		end
	end)
end
function v16.KnitInit(_)
	-- upvalues: (ref) v_u_15, (copy) v_u_1, (ref) v_u_14
	v_u_15 = v_u_1.GetService("ResoluteSlashService")
	v_u_14 = v_u_1.GetController("FXController")
end
return v16