-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = RaycastParams.new()
v_u_9.FilterType = Enum.RaycastFilterType.Include
v_u_9.FilterDescendantsInstances = { workspace.Map, workspace.Domains }
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "RushController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_5, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (copy) v_u_6, (copy) v_u_3, (ref) v_u_12, (ref) v_u_10
	local v_u_40 = {
		["Dash"] = function(p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				v_u_11:PlaySound(v_u_7.Itadori.Rush.Rush, v15, game.SoundService.Effect)
				local v16 = v_u_5.Utils.Itadori.RushWind:Clone()
				v16.CFrame = v15.CFrame
				v16.Parent = workspace.Effects
				v16.Dust:Emit(7)
				v16.Ring:Emit(7)
				v16.Dash1.Dash:Emit(1)
				v16.Dash2.Dash:Emit(1)
				v_u_2:AddItem(v16, 2)
				if v_u_4.Character == p14 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Hit"] = function(_, p17, p18, p19, p20)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_9
			local v21 = p17:FindFirstChild("HumanoidRootPart")
			if not v21 then
				return
			end
			local v22 = p18:FindFirstChild("HumanoidRootPart")
			if not v22 then
				return
			end
			v_u_11:Flash(p18, Color3.new(1, 1, 1))
			v_u_11:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit1"), v22, game.SoundService.Effect)
			v_u_11:PlaySound(v_u_7.Itadori.Rush.RushHit, v22, game.SoundService.Effect)
			if v_u_4.Character == p17 or v_u_4.Character == p18 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
			if v_u_4.Character == p17 then
				::l9::
				return
			else
				while true do
					local v23 = 65 * task.wait()
					if not workspace:Raycast(v21.Position, p19 * v23, v_u_9) then
						v21.CFrame = v21.CFrame + p19 * v23
					end
					if not (v21.Parent and p20.Parent) then
						goto l9
					end
				end
			end
		end,
		["FinalHit"] = function(p24, p25)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v26 = p25:FindFirstChild("HumanoidRootPart")
			if v26 then
				v_u_11:Flash(p25, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit2"), v26, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Itadori.Rush.RushBreak, v26, game.SoundService.Effect)
				if v_u_4 == p24 or v_u_4.Character == p25 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
				task.wait(0.2)
				v_u_11:Flash(p25, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.M1:FindFirstChild("Hit4"), v26, game.SoundService.Effect)
				if v_u_4 == p24 or v_u_4.Character == p25 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["AerialHit"] = function(p27, p28)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2
			local v29 = p27:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = p28:FindFirstChild("HumanoidRootPart")
				if v30 then
					v_u_11:Flash(p28, Color3.new(1, 1, 1))
					v_u_11:PlaySound(v_u_7.Itadori.CraniumSmash.Hit2, v30, game.SoundService.Effect)
					v_u_11:PlaySound(v_u_7.Itadori.Rush.RushLaunch, v29, game.SoundService.Effect)
					if v_u_4.Character == p27 or v_u_4.Character == p28 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
					end
					local v31 = CFrame.new(v30.Position, v29.CFrame * CFrame.new(0, -250, -40).Position)
					local v32 = v_u_6.Gojo.HardHit:Clone()
					v32.CFrame = v31 + v31.LookVector * 4
					v32.Parent = workspace.Effects
					v32.Dust:Emit(5)
					v32.Ring:Emit(5)
					v32.Sparks:Emit(10)
					v_u_2:AddItem(v32, 0.5)
				end
			else
				return
			end
		end,
		["Jump"] = function(p33, p34)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_12
			local v35 = p34.Parent.Parent:FindFirstChild("HumanoidRootPart")
			if not v35 then
				return
			end
			local v36 = v35.CFrame.LookVector * 5
			if v_u_4.Character == v35.Parent then
				v_u_3:Create(p34, TweenInfo.new(0.5), {
					["P"] = 100000
				}):Play()
				repeat
					p34.Position = p33.Position - v36
					task.wait()
				until not (p34.Parent and p33)
				::l6::
				return
			else
				while true do
					if v_u_12.lastRecvServer[v35.Parent] ~= nil then
						v_u_12.lastRecvServer[v35.Parent] = false
					end
					local v37 = v35.CFrame - v35.Position + p33.Position - v36
					v35.CFrame = v35.CFrame:Lerp(v37, 0.15)
					task.wait()
					if not (p34.Parent and p33) then
						goto l6
					end
				end
			end
		end,
		["JumpBurst"] = function(p38)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_7
			local v39 = v_u_6.Itadori.CrushingBlow:Clone()
			v39.Position = p38
			v39.PointLight:Destroy()
			v39.Air:Destroy()
			v39.Parent = workspace.Effects
			v39.Floor.Wind2.Color = ColorSequence.new(Color3.new(1, 0, 0))
			v39.Floor.Sparks.Color = ColorSequence.new(Color3.new(1, 0, 0))
			v39.Floor.Ring:Emit(10)
			v39.Floor.Sparks:Emit(10)
			v39.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v39, 1.5)
			v_u_11:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v39, game.SoundService.Effect)
		end
	}
	v_u_10.Effects:Connect(function(p41, ...)
		-- upvalues: (copy) v_u_40
		local v42 = v_u_40[p41]
		if v42 then
			v42(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("RushService")
	v_u_11 = v_u_1.GetController("FXController")
	v_u_12 = v_u_1.GetController("JoinController")
end
return v13