-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "MokouController"
})
function v13.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (ref) v_u_10, (ref) v_u_11
	local v_u_79 = {
		["Hit"] = function(p14, p15)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v16 = p14:FindFirstChild("HumanoidRootPart")
			if v16 then
				v_u_12:Flash(p14, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Misc.M.M1:FindFirstChild("Hit" .. p15), v16, game.SoundService.Effect)
				local v17 = v_u_7.Misc.M.Hit:Clone()
				v17.CFrame = v16.CFrame * CFrame.new(math.random(-20, 20) / 10, math.random(-20, 20) / 10, math.random(-10, 10) / 10)
				v17.Parent = workspace.Effects
				v17.Sparks:Emit(20)
				v_u_4:Create(v17, TweenInfo.new(0.15), {
					["Size"] = Vector3.new(7, 7, 7),
					["Transparency"] = 1,
					["Color"] = Color3.new(1, 0.333333, 0)
				}):Play()
				v_u_3:AddItem(v17, 0.6)
				if p15 == 4 then
					v17.Flames:Emit(20)
				end
			end
		end,
		["ChaseHit"] = function(p18, p19)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v20 = p18:FindFirstChild("HumanoidRootPart")
			if v20 then
				local v21 = p19:FindFirstChild("HumanoidRootPart")
				if v21 then
					v_u_12:Flash(p19, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Misc.M.M1:FindFirstChild("Hit3"), v20, game.SoundService.Effect)
					local v22 = v_u_7.ChaseHit:Clone()
					local v23 = CFrame.new
					local v24 = v21.Position
					local v25 = v20.Position.X
					local v26 = v21.Position.Y
					local v27 = v20.Position.Z
					v22.CFrame = v23(v24, (Vector3.new(v25, v26, v27))) * CFrame.Angles(0, 3.141592653589793, 0)
					v22.Parent = workspace.Effects
					v22.Ring:Emit(7)
					v22.Sparks:Emit(12)
					v_u_3:AddItem(v22, 0.5)
					local v28 = v_u_7.Misc.M.Hit:Clone()
					v28.CFrame = v20.CFrame * CFrame.new(math.random(-20, 20) / 10, math.random(-20, 20) / 10, math.random(-10, 10) / 10)
					v28.Parent = workspace.Effects
					v28.Sparks:Emit(20)
					v_u_4:Create(v28, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(7, 7, 7),
						["Transparency"] = 1,
						["Color"] = Color3.new(1, 0.333333, 0)
					}):Play()
					v_u_3:AddItem(v28, 0.6)
				end
			else
				return
			end
		end,
		["AerialHit"] = function(p29, p30)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3
			local v31 = p29:FindFirstChild("HumanoidRootPart")
			if v31 then
				local v32 = p30:FindFirstChild("HumanoidRootPart")
				if v32 then
					v_u_12:Flash(p30, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Itadori.CraniumSmash.Hit2, v32, game.SoundService.Effect)
					if v_u_5.Character == p29 or v_u_5.Character == p30 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
					end
					local v33 = CFrame.new(v31.Position, v32.Position - Vector3.new(0, 4, 0))
					local v34 = v_u_7.Gojo.HardHit:Clone()
					v34.CFrame = v33 + v33.LookVector * 4
					v34.Parent = workspace.Effects
					v34.Dust:Emit(5)
					v34.Ring:Emit(5)
					v34.Sparks:Emit(10)
					v_u_3:AddItem(v34, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p35)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v36 = p35.HumanoidRootPart
			if v36 then
				local v37 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v37.CFrame = v36.CFrame * CFrame.new(0, 1, -4)
				v37.Size = Vector3.new(0, 0, 2)
				v37.Parent = workspace.Effects
				v_u_4:Create(v37, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v37, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v36, game.SoundService.Effect)
				v_u_12:DustTrail(p35, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["Swing2"] = function(p38, p39, p40)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v41 = p38.HumanoidRootPart
			if v41 then
				v_u_12:PlaySound(v_u_8.Misc.M.Swing[math.clamp(p39, 1, 4)], v41, game.SoundService.Effect)
				if p40 == "Down" then
					v_u_12:ArmFlash(p38["Right Leg"], Color3.fromRGB(255, 85, 0), 0.4)
					return
				elseif p40 == "Up" then
					v_u_12:ArmFlash(p38["Right Arm"], Color3.fromRGB(255, 85, 0), 0.3)
					return
				elseif p39 == 1 then
					v_u_12:ArmFlash(p38["Left Arm"], Color3.fromRGB(255, 85, 0), 0.3)
					return
				elseif p39 == 2 or p39 == 3 then
					v_u_12:ArmFlash(p38["Right Leg"], Color3.fromRGB(255, 85, 0), 0.3)
					return
				elseif p39 == 4 then
					v_u_12:ArmFlash(p38["Left Leg"], Color3.fromRGB(255, 85, 0), 0.4)
				elseif p39 == 5 then
					v_u_12:ArmFlash(p38["Right Arm"], Color3.fromRGB(255, 85, 0), 0.4)
				end
			else
				return
			end
		end,
		["Launch"] = function(p42, p43)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v44 = p42:FindFirstChild("HumanoidRootPart")
			if v44 then
				local v45 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v45.CFrame = CFrame.new(v44.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v45.Size = Vector3.new(0, 0, 5)
				v45.Parent = workspace.Effects
				v_u_4:Create(v45, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v45.Position + Vector3.new(0, p43, 0)
				}):Play()
				v_u_3:AddItem(v45, 0.3)
				if p43 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v44, game.SoundService.Effect)
					v_u_12:DustBreak(v44.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v44.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["Revive"] = function(p_u_46, p_u_47, p48)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7, (ref) v_u_12, (ref) v_u_8
			task.spawn(function()
				-- upvalues: (ref) v_u_5, (copy) p_u_46, (copy) p_u_47, (ref) v_u_3, (ref) v_u_4
				if v_u_5 == p_u_46 then
					workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
				end
				repeat
					task.wait()
				until not (p_u_47.Parent and (p_u_46.Character and p_u_46.Parent))
				if v_u_5 == p_u_46 then
					workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
					workspace.CurrentCamera.CameraSubject = p_u_46.Character:WaitForChild("Humanoid")
				end
				local v49 = Instance.new("Highlight", p_u_46.Character)
				v49.DepthMode = Enum.HighlightDepthMode.Occluded
				v49.OutlineColor = Color3.fromRGB(255, 255, 127)
				v49.FillColor = Color3.fromRGB(255, 255, 127)
				v49.FillTransparency = 0
				v_u_3:AddItem(v49, 0.7)
				v_u_4:Create(v49, TweenInfo.new(0.7, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
					["FillTransparency"] = 1,
					["OutlineTransparency"] = 1,
					["FillColor"] = Color3.fromRGB(0, 0, 0),
					["OutlineColor"] = Color3.fromRGB(255, 0, 0)
				}):Play()
			end)
			if (workspace.CurrentCamera.CFrame.Position - p48.Position).Magnitude < 150 then
				v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(1)
			end
			local v50 = v_u_7.Misc.M.Revive:Clone()
			v50.CFrame = p48
			v50.Parent = workspace.Effects
			v_u_12:PlaySound(v_u_8.Misc.M.Revive, v50, game.SoundService.Effect)
			v_u_3:AddItem(v50, 3)
			for _, v51 in v50.Activate:GetChildren() do
				if (v51:GetAttribute("EmitDuration") or 0) > 0 then
					v51.Enabled = true
				end
				if (v51:GetAttribute("EmitCount") or 0) > 0 then
					v51:Emit(v51:GetAttribute("EmitCount") or 0)
				end
			end
			task.wait(0.6)
			for _, v52 in v50.Activate:GetChildren() do
				v52.Enabled = false
			end
			for _, v_u_53 in v50.Explode:GetChildren() do
				if (v_u_53:GetAttribute("EmitDuration") or 0) > 0 then
					v_u_53.Enabled = true
					task.delay(v_u_53:GetAttribute("EmitDuration") or 0, function()
						-- upvalues: (copy) v_u_53
						v_u_53.Enabled = false
					end)
				end
				if (v_u_53:GetAttribute("EmitCount") or 0) > 0 then
					v_u_53:Emit(v_u_53:GetAttribute("EmitCount") or 0)
				end
			end
		end,
		["Wing"] = function(p54, p55)
			-- upvalues: (ref) v_u_7, (ref) v_u_3
			local v_u_56 = v_u_7.Misc.M.wing:Clone()
			v_u_56.Parent = p54.Torso
			p55:GetPropertyChangedSignal("Value"):Connect(function()
				-- upvalues: (copy) v_u_56
				for _, v57 in v_u_56.Left:GetDescendants() do
					if v57:IsA("ParticleEmitter") or (v57:IsA("Beam") or v57:IsA("PointLight")) then
						v57.Enabled = true
					end
				end
				for _, v58 in v_u_56.prewing:GetDescendants() do
					if v58:IsA("ParticleEmitter") or (v58:IsA("Beam") or v58:IsA("PointLight")) then
						v58.Enabled = false
					end
				end
				for _, v59 in v_u_56.right:GetDescendants() do
					if v59:IsA("ParticleEmitter") or (v59:IsA("Beam") or v59:IsA("PointLight")) then
						v59.Enabled = true
					end
				end
			end)
			repeat
				task.wait()
			until not p55:IsDescendantOf(workspace.Characters)
			v_u_3:AddItem(v_u_56, 1.5)
			for _, v60 in v_u_56:GetDescendants() do
				if v60:IsA("ParticleEmitter") or (v60:IsA("Beam") or v60:IsA("PointLight")) then
					v60.Enabled = false
				end
			end
		end,
		["WingFly"] = function(p61)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_4
			local v62 = p61.HumanoidRootPart
			if v62 then
				local v63 = v_u_7.Misc.M.WingFly:Clone()
				v63:PivotTo(v62.CFrame)
				v63.Parent = workspace.Effects
				v_u_3:AddItem(v63, 3)
				for _, v64 in v63.WHAT["1"]:GetDescendants() do
					if v64:IsA("ParticleEmitter") then
						v64:Emit(v64:GetAttribute("EmitCount"))
					end
				end
				v_u_4:Create(v63.WHAT, TweenInfo.new(0.4, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = Vector3.new(18, 18, 18),
					["Color"] = Color3.fromRGB(255, 64, 0),
					["Transparency"] = 1
				}):Play()
				v_u_4:Create(v63.Mesh.Start, TweenInfo.new(1.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = v63.Mesh.End.Size,
					["Transparency"] = 1,
					["CFrame"] = v63.Mesh.End.CFrame
				}):Play()
				v_u_4:Create(v63.Mesh2.Start, TweenInfo.new(2, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = v63.Mesh2.End.Size,
					["Transparency"] = 1,
					["CFrame"] = v63.Mesh2.End.CFrame
				}):Play()
				v_u_4:Create(v63.Mesh3.Start, TweenInfo.new(2.5, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
					["Size"] = v63.Mesh3.End.Size,
					["Transparency"] = 1,
					["CFrame"] = v63.Mesh3.End.CFrame
				}):Play()
				v63.Mesh.End:Destroy()
				v63.Mesh2.End:Destroy()
				v63.Mesh3.End:Destroy()
			end
		end,
		["Interp"] = function(p_u_65, p66, p67, p68)
			-- upvalues: (ref) v_u_2
			local v_u_69 = p68:Clone()
			v_u_69.CFrame = p66
			v_u_69.Parent = workspace.Effects
			local v_u_70 = tick() + p67
			local v_u_71 = nil
			v_u_71 = v_u_2.Stepped:Connect(function(_, p72)
				-- upvalues: (copy) p_u_65, (copy) v_u_70, (copy) v_u_69, (ref) v_u_71
				if p_u_65.Parent and v_u_70 >= tick() then
					v_u_69.CFrame = v_u_69.CFrame:Lerp(v_u_69.CFrame * p_u_65.Value, p72)
				else
					v_u_69:Destroy()
					v_u_71:Disconnect()
				end
			end)
		end,
		["Kill"] = function(p73)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_5, (ref) v_u_9, (ref) v_u_4
			local v74 = p73.HumanoidRootPart
			if v74 then
				v_u_12:PlaySound(v_u_8.Misc.M.Kill, v74, game.SoundService.Effect)
				for _, v75 in p73:GetDescendants() do
					if v75:IsA("BasePart") or v75:IsA("Decal") then
						v75.Transparency = 1
					end
				end
				local v76 = v_u_7.Misc.M.TouhouBurst.Attachment:Clone()
				v76.Parent = v74
				v76.Burst:Emit(1)
				v76.Power:Emit(6)
				v76.Power2:Emit(1)
				if v_u_5.Character == p73 then
					v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap):StartFadeOut(2)
					game.Lighting.ExposureCompensation = 3
					v_u_4:Create(game.Lighting, TweenInfo.new(1), {
						["ExposureCompensation"] = 0
					}):Play()
				end
			end
		end,
		["Awaken"] = function(p77)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v78 = p77.HumanoidRootPart
			if v78 then
				v_u_12:PlaySound(v_u_8.Misc.M.MokouUlt, v78, game.SoundService.Effect)
			end
		end
	}
	v_u_10.Effects:Connect(function(p80, ...)
		-- upvalues: (copy) v_u_79
		local v81 = v_u_79[p80]
		if v81 then
			v81(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p82, p83, p84)
		-- upvalues: (ref) v_u_11, (ref) v_u_4
		local v85 = p83.HumanoidRootPart
		if not v85 then
			return
		end
		local v86 = nil
		while true do
			local v87 = v_u_11:SphereHitbox(p83, CFrame.new(0, 0, -4), 8)
			for _, v88 in v87 do
				local v89 = v88:FindFirstChild("Info")
				if v89 then
					local v90 = v89:FindFirstChild("Knockback")
					if not v90 or v90.Value ~= false then
						v86 = v87
						break
					end
				end
			end
			if v86 then
				local v91 = p82:FindFirstChildWhichIsA("NumberValue")
				if v91 then
					v_u_4:Create(v91, TweenInfo.new(0.1), {
						["Value"] = 0
					}):Play()
				end
				break
			end
			task.wait(0.05)
			if not p82.Parent then
				break
			end
		end
		p84:FireServer(v86, v85.CFrame)
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("MokouService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
v13.SpawnAnim = "109651238159963"
v13.SpawnFunc = {
	["Startup"] = function(p_u_92, p93)
		-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_5, (copy) v_u_6
		local v94 = p_u_92.HumanoidRootPart
		if v94 then
			v_u_12:PlaySound(v_u_8.Misc.M.MokouSpawnVoice, v94, game.SoundService.Voice)
			local v95 = v_u_12:PlaySound(v_u_8.Misc.M.MokouSpawn, v94, game.SoundService.Effect)
			table.insert(p93, v95)
			task.wait(0.1)
			if v95.Parent then
				local v96 = v_u_7.Misc.M.SnapArm:Clone()
				v96.Weld.Part0 = p_u_92["Right Arm"]
				v96.Parent = workspace.Effects
				v96.Core.Sparks:Emit(15)
				v96.Core.Burst:Emit(1)
				table.insert(p93, v96)
				if v_u_5.Character == p_u_92 then
					local v_u_97 = require(v_u_6.Modules.TekrinnDialogue)
					local v98 = v_u_97.Speak
					local v99 = {}
					local v100 = {
						["Text"] = "I\'ll show you the legendary phoenix...",
						["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 0, 0)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 170, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 255, 255)) }),
						["TextStrokeColor"] = Color3.new(0.333333, 0, 0),
						["Bold"] = false,
						["Italic"] = true,
						["Shake"] = {
							["Enabled"] = false,
							["Intensity"] = 1,
							["Lifetime"] = 1
						},
						["TypeSpeed"] = 0.08
					}
					__set_list(v99, 1, {v100})
					v98(p_u_92, v99)
					task.delay(3.8, function()
						-- upvalues: (copy) p_u_92, (copy) v_u_97
						if p_u_92.Parent then
							local v101 = v_u_97.Speak
							local v102 = p_u_92
							local v103 = {}
							local v104 = {
								["Text"] = "that grows stronger each time it\'s reborn.",
								["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 0, 0)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 170, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 255, 255)) }),
								["TextStrokeColor"] = Color3.new(0.333333, 0, 0),
								["Bold"] = false,
								["Italic"] = true,
								["Shake"] = {
									["Enabled"] = true,
									["Intensity"] = 3,
									["Lifetime"] = 1
								},
								["TypeSpeed"] = 0.025
							}
							__set_list(v103, 1, {v104})
							v101(v102, v103)
						end
					end)
				end
			end
		else
			return
		end
	end,
	["Hitbox"] = function(p105, p106)
		-- upvalues: (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_9
		local v107 = p105.HumanoidRootPart
		if v107 then
			local v108 = v_u_7.Misc.M.FlameArm:Clone()
			v108.Weld.Part0 = p105["Left Arm"]
			v108.Parent = workspace.Effects
			v108.Core.Sparks:Emit(25)
			v108.Core.Ring:Emit(6)
			v108.Core.Flash:Emit(1)
			v108.Core.Burst:Emit(1)
			v108.Core.Flare:Emit(1)
			v108.Core.Heat:Emit(2)
			v_u_4:Create(v108.PointLight, TweenInfo.new(1.5), {
				["Brightness"] = 0,
				["Color"] = Color3.new(1, 0, 0)
			}):Play()
			v_u_4:Create(v108.Core.Flames, TweenInfo.new(1.5), {
				["Rate"] = 0
			}):Play()
			table.insert(p106, v108)
			local v109 = v_u_7.Hiromi.Shockwave:Clone()
			v109.Position = v107.Position - Vector3.new(0, 3, 0)
			v109.Parent = workspace.Effects
			local v110 = v109.CFrame
			local v111 = CFrame.Angles
			local v112 = math.random(-179, 179)
			v109.CFrame = v110 * v111(0, math.rad(v112), 0)
			v_u_4:Create(v109.mesh.Mesh, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Scale"] = Vector3.new(15, 0, 15)
			}):Play()
			v_u_4:Create(v109.mesh.Decal, TweenInfo.new(0.5, Enum.EasingStyle.Exponential), {
				["Transparency"] = 1
			}):Play()
			v109.Floor.Glow:Emit(1)
			v109.Floor.Ring:Emit(10)
			v_u_3:AddItem(v109, 1.5)
			if (workspace.CurrentCamera.CFrame.Position - v107.Position).Magnitude < 150 then
				v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
			end
		end
	end
}
return v13