-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("HttpService")
local v_u_2 = require("./Helper")
local v_u_3 = require("./Bits")
local v_u_4 = {
	["expandTime"] = 0.38,
	["explodeTime"] = 1.42,
	["explodeSize"] = Vector2.new(3, 3),
	["damage"] = 6,
	["bitsCount"] = 6,
	["spawnMargin"] = 24
}
local v_u_5 = script.Parent.Assets.Sprites.Other.Heart
local v_u_6 = Random.new()
local v_u_7 = {}
v_u_7.__index = v_u_7
v_u_7.Compute = {}
function v_u_7.new(p8, p9, p10, p11)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_6, (copy) v_u_1, (copy) v_u_7, (copy) v_u_5, (copy) v_u_3
	local v12 = p11 or {}
	local v13 = v12.expandTime or v_u_4.expandTime
	local v14 = v12.explodeTime or v_u_4.explodeTime
	local v15 = v12.explodeSize or v_u_4.explodeSize
	local v_u_16 = v12.damage or v_u_4.damage
	local v17 = v12.bitsCount or v_u_4.bitsCount
	local v18 = v12.attackSpace or p10
	local v19 = v12.easeAppear
	if type(v19) == "string" then
		v19 = v19 == "back" and v_u_2.easeOutBack or v_u_2.easeOutExpo
	elseif type(v19) ~= "function" then
		v19 = v_u_2.easeOutBack
	end
	local v20 = v12.easeExplode
	if type(v20) == "string" then
		v20 = v20 == "back" and v_u_2.easeOutBack or v_u_2.easeOutExpo
	elseif type(v20) ~= "function" then
		v20 = v_u_2.easeOutExpo
	end
	local v21
	if v12.pos then
		v21 = v12.fromGui and v_u_2.absToCenteredOffset(v_u_2.centerAbs(v12.fromGui), p10) + v12.pos or Vector2.new(v_u_2.roundpx(v12.pos.X), v_u_2.roundpx(v12.pos.Y))
	else
		local v22 = p10.AbsoluteSize
		local v23 = v22.X * 0.5
		local v24 = v22.Y * 0.5
		local v25 = v_u_4.spawnMargin
		v21 = Vector2.new(v_u_2.roundpx(v_u_6:NextNumber(-v23 + v25, v23 - v25)), v_u_2.roundpx(v_u_6:NextNumber(-v24 + v25, v24 - v25)))
	end
	local v26 = {
		["Signals"] = p8,
		["State"] = p9,
		["Contents"] = p10,
		["AttackSpace"] = v18,
		["ExpandTime"] = v13,
		["ExplodeTime"] = v14,
		["ExplodeSize"] = v15,
		["Damage"] = v_u_16,
		["BitsCount"] = v17,
		["BitsParams"] = v12.bitsParams,
		["EaseAppear"] = v19,
		["EaseExplode"] = v20,
		["UUID"] = v_u_1:GenerateGUID(false),
		["Alive"] = true,
		["Phase"] = "APPEAR",
		["Time"] = 0,
		["Gui"] = nil,
		["Scale"] = nil,
		["Explosion"] = nil,
		["Atk"] = nil
	}
	local v27 = v_u_7
	local v_u_28 = setmetatable(v26, v27)
	local v29 = v_u_5:Clone()
	v29.AnchorPoint = Vector2.new(0.5, 0.5)
	v29.Position = UDim2.new(0.5, v21.X, 0.5, v21.Y)
	v29.Parent = p10
	local v30 = v29:FindFirstChild("Explosion")
	v30.AnchorPoint = Vector2.new(0.5, 0.5)
	v30.Position = UDim2.fromScale(0.5, 0.5)
	v30.Size = UDim2.fromOffset(0, 0)
	v30.Visible = false
	if v30:IsA("ImageLabel") then
		v30.ImageTransparency = 0
	else
		v30.BackgroundTransparency = 0
	end
	v_u_28.Gui = v29
	v_u_28.Scale = v29:FindFirstChildOfClass("UIScale")
	v_u_28.Explosion = v30
	v_u_28.Scale.Scale = 0
	v_u_7.Compute[v_u_28.UUID] = function(p31)
		-- upvalues: (copy) v_u_28, (ref) v_u_2, (ref) v_u_3, (copy) v_u_16
		if v_u_28.Alive then
			local v32 = v_u_2.toSec(p31)
			local v33 = v_u_28
			v33.Time = v33.Time + v32
			if v_u_28.Phase == "APPEAR" then
				if not v_u_28.Sounded then
					v_u_28.Signals.spawnSound:Fire("Explosion 2")
					v_u_28.Sounded = true
				end
				local v34 = v_u_28.Time
				local v35 = v_u_28.ExpandTime
				local v36 = v34 / math.max(v35, 1e-6)
				local v37 = math.clamp(v36, 0, 1)
				v_u_28.Scale.Scale = v_u_28.EaseAppear(v37)
				if v37 >= 1 then
					v_u_28.Phase = "EXPLODE"
					v_u_28.Time = 0
					v_u_28.Gui.ImageTransparency = 1
					v_u_28.Explosion.Visible = true
					v_u_3.new(v_u_28.State, v_u_28.AttackSpace, "Gray", v_u_28.BitsCount, Vector2.zero, {
						["fromGui"] = v_u_28.Gui,
						["ttl"] = v_u_28.BitsParams and v_u_28.BitsParams.ttl or nil,
						["gravity"] = v_u_28.BitsParams and v_u_28.BitsParams.gravity or nil,
						["vxMin"] = v_u_28.BitsParams and v_u_28.BitsParams.vxMin or nil,
						["vxMax"] = v_u_28.BitsParams and v_u_28.BitsParams.vxMax or nil,
						["vyMin"] = v_u_28.BitsParams and v_u_28.BitsParams.vyMin or nil,
						["vyMax"] = v_u_28.BitsParams and v_u_28.BitsParams.vyMax or nil,
						["spinMin"] = v_u_28.BitsParams and v_u_28.BitsParams.spinMin or nil,
						["spinMax"] = v_u_28.BitsParams and v_u_28.BitsParams.spinMax or nil,
						["damage"] = v_u_16
					})
					local v38 = v_u_2.centerAbs(v_u_28.Gui)
					local v39 = {
						["Kind"] = "GrayExplosion",
						["Pos"] = v_u_2.absToCenteredOffset(v38, v_u_28.AttackSpace),
						["Radius"] = 0,
						["Dmg"] = 0,
						["Destroy"] = function()
							-- upvalues: (ref) v_u_28
							if v_u_28.State and v_u_28.State.Attacks then
								v_u_28.State.Attacks[v_u_28.Explosion] = nil
							end
						end
					}
					v_u_28.State.Attacks[v_u_28.Explosion] = v39
					v_u_28.Atk = v_u_28.State.Attacks[v_u_28.Explosion]
				end
				return
			elseif v_u_28.Phase == "EXPLODE" then
				if not v_u_28.Shaked then
					v_u_28.Signals.onShake:Fire({
						["amp"] = 12,
						["freq"] = 10,
						["duration"] = 0.2,
						["falloff"] = "cubic"
					})
					v_u_28.Shaked = true
				end
				local _ = v_u_28.State and (v_u_28.State.Arena and v_u_2.unitScale(v_u_28.AttackSpace, v_u_28.State.Arena.BaselineMin))
				local v40 = Vector2.new(v_u_28.ExplodeSize.X, v_u_28.ExplodeSize.Y)
				local v41 = v_u_28.Time
				local v42 = v_u_28.ExplodeTime
				local v43 = v41 / math.max(v42, 1e-6)
				local v44 = math.clamp(v43, 0, 1)
				local v45 = v_u_28.EaseExplode(v44)
				local v46 = v40.X
				local v47 = math.lerp(0, v46, v45)
				local v48 = v40.Y
				local v49 = math.lerp(0, v48, v45)
				v_u_28.Explosion.Size = UDim2.fromScale(v47, v49)
				if v_u_28.Explosion:IsA("ImageLabel") then
					v_u_28.Explosion.ImageTransparency = v45
				else
					v_u_28.Explosion.BackgroundTransparency = v45
				end
				if v_u_28.Atk then
					local v50 = v_u_2.centerAbs(v_u_28.Gui)
					v_u_28.Atk.Pos = v_u_2.absToCenteredOffset(v50, v_u_28.AttackSpace)
					v_u_28.Atk.Radius = math.min(v47, v49) * 0.5
					v_u_28.Atk.Dmg = v45 <= 0.5 and v_u_28.Damage or 0
				end
				if v44 >= 1 then
					v_u_28.Phase = "DONE"
					v_u_28.Time = 0
				end
				return
			elseif v_u_28.Phase == "DONE" then
				v_u_28:Destroy()
			end
		else
			return
		end
	end
	return v_u_28
end
function v_u_7.Destroy(p51)
	-- upvalues: (copy) v_u_7
	if p51.Alive then
		p51.Alive = false
		if p51.UUID and v_u_7.Compute[p51.UUID] then
			v_u_7.Compute[p51.UUID] = nil
		end
		if p51.State and (p51.State.Attacks and p51.Atk) then
			p51.State.Attacks[p51.Explosion] = nil
		end
		if p51.Gui then
			p51.Gui:Destroy()
		end
		p51.Gui = nil
		p51.Scale = nil
		p51.Explosion = nil
		p51.Atk = nil
		table.clear(p51)
		setmetatable(p51, nil)
	end
end
function v_u_7.Step(p52)
	-- upvalues: (copy) v_u_7
	for _, v53 in pairs(v_u_7.Compute) do
		v53(p52)
	end
end
return v_u_7