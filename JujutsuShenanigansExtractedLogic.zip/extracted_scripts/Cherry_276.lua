-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Btn"] = 1,
	["SortOrder"] = 5,
	["Desc"] = "pink everywhere"
}
local v_u_2 = nil
local v_u_3 = game:GetService("RunService")
function v1.Callback(p4)
	-- upvalues: (ref) v_u_2, (copy) v_u_3
	if p4 == true then
		v_u_2 = game.ReplicatedStorage.Utils.Misc.Rain:Clone()
		v_u_2.Rain.Enabled = false
		v_u_2.Blossom.Enabled = true
		v_u_2.Parent = workspace.Effects
		local v_u_5 = v_u_2.Blossom.BlossomCC
		v_u_5.Parent = game.Lighting
		local v_u_6 = nil
		v_u_6 = v_u_3.Stepped:Connect(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_6, (copy) v_u_5
			if v_u_2 then
				v_u_2.Position = workspace.CurrentCamera.CFrame.Position + Vector3.new(0, 30, 0)
			else
				v_u_6:Disconnect()
				v_u_5:Destroy()
			end
		end)
		return
	elseif v_u_2 then
		v_u_2:Destroy()
		v_u_2 = nil
	end
end
return v1