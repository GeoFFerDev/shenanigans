-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = game:GetService("RunService")
game:GetService("Debris")
game:GetService("TweenService")
local v_u_3 = game.Players.LocalPlayer
function v1.Start(_, p_u_4, p5)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if p_u_4.Character then
		local v_u_6 = script.Innate:Clone()
		v_u_6.Parent = workspace.Effects
		table.insert(p5, v_u_6)
		task.spawn(function()
			-- upvalues: (copy) p_u_4, (copy) v_u_6
			local v7
			if p_u_4.Character then
				v7 = p_u_4.Character.Humanoid:GetAppliedDescription()
			else
				v7 = game.Players:GetHumanoidDescriptionFromUserId(p_u_4.UserId)
			end
			v_u_6.Rig.Humanoid:ApplyDescriptionReset(v7)
		end)
		local v8 = script.Voice:Clone()
		v8.SoundGroup = game.SoundService.Voice
		v8.Parent = workspace
		table.insert(p5, v8)
		local v9 = v_u_6.Rig.Humanoid:LoadAnimation(script.Character)
		local v10 = v_u_6.Camera.Humanoid:LoadAnimation(script.Camera)
		v9:Play(0, nil, 0)
		table.insert(p5, v9)
		v10:Play(0, nil, 0)
		table.insert(p5, v10)
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (copy) v_u_6
			v_u_2:BindToRenderStep("Focus", 301, function()
				-- upvalues: (ref) v_u_6
				workspace.CurrentCamera.Focus = v_u_6.Camera.Torso.CFrame
			end)
			task.wait(3)
			v_u_2:UnbindFromRenderStep("Focus")
		end)
		task.wait(1)
		local v11 = script.SukunaAtmo:Clone()
		v11.Parent = game.Lighting
		table.insert(p5, v11)
		task.wait(1.5)
		local v12 = script.DepthOfField:Clone()
		v12.Parent = game.Lighting
		table.insert(p5, v12)
		v_u_3.PlayerGui.Main.Enabled = false
		local v_u_13 = workspace.CurrentCamera
		v_u_13.FieldOfView = 41
		v_u_13.CameraType = Enum.CameraType.Scriptable
		local v14 = v_u_2.RenderStepped
		table.insert(p5, v14:Connect(function()
			-- upvalues: (copy) v_u_13, (copy) v_u_6
			v_u_13.CFrame = v_u_6.Camera.Torso.CFrame
		end))
		local v15 = tick() + 0.25
		repeat
			task.wait()
		until v9.Length > 0 and (v10.Length > 0 and v8.IsLoaded) or v15 < tick()
		v9:AdjustSpeed(1)
		v10:AdjustSpeed(1)
		v8:Play()
		v_u_6.Dust.Dust:Emit(300)
		task.wait(0.7)
		task.wait(3.5)
		task.wait(2.3)
		v9:AdjustSpeed(0)
		v10:AdjustSpeed(0)
		v_u_6.Dust.Dust.TimeScale = 0
	end
end
return v1