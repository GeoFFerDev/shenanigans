-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v6 = game.ReplicatedStorage
local _ = v6.Animations
local v_u_7 = v6.Utils
local v_u_8 = v6.Sounds
local v_u_9 = require(v6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "FocusStrikeController"
})
function v12.KnitStart(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (ref) v_u_10
	local v_u_74 = {
		["Startup"] = function(p13, p14)
			-- upvalues: (ref) v_u_11, (ref) v_u_8
			local v15 = p13:FindFirstChild("HumanoidRootPart")
			if v15 then
				if p14 ~= 2 then
					v_u_11:PlaySound(v_u_8.Hakari.OverLuck.Charge, v15, game.SoundService.Effect).PlaybackSpeed = 1.5
				end
			else
				return
			end
		end,
		["Chain"] = function(p_u_16)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_2
			local v_u_17 = p_u_16:FindFirstChild("HumanoidRootPart")
			if v_u_17 then
				v_u_11:PlaySound(v_u_8.Mahito.Variants.Transform3, v_u_17, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_8.Mahito.Chainwhip.Chains, v_u_17, game.SoundService.Effect)
				task.delay(0.4, function()
					-- upvalues: (ref) v_u_11, (ref) v_u_8, (copy) v_u_17
					v_u_11:PlaySound(v_u_8.Mahito.Chainwhip.Swing, v_u_17, game.SoundService.Effect)
				end)
				for _ = 1, 20 do
					local v18 = v_u_7.Mahito.Morph:Clone()
					v18.Weld.Part0 = p_u_16["Right Arm"]
					v18.Color = p_u_16["Right Arm"].Color
					v18.Weld.C1 = CFrame.new(math.random(-150, 150) / 100, math.random(200, 500) / 100, math.random(-150, 150) / 100)
					v18.Parent = workspace.Effects
					v18.Size = Vector3.new(1, 1, 1) * (math.random(6, 20) / 10)
					v_u_4:Create(v18, TweenInfo.new(math.random(20, 40) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_4:Create(v18.Weld, TweenInfo.new(math.random(10, 40) / 100), {
						["C1"] = CFrame.new(0, -1, 0)
					}):Play()
					v_u_3:AddItem(v18, 0.4)
				end
				local v_u_19 = v_u_7.Mahito.Whip:Clone()
				v_u_19.Parent = workspace.Effects
				local v_u_20 = {}
				local v_u_21 = {}
				for _, v22 in v_u_19:GetDescendants() do
					if (v22.Name == "S1" or (v22.Name == "S2" or (v22.Name == "S3" or (v22.Name == "S4" or (v22.Name == "S5" or v22.Name == "S6"))))) and v22:IsA("MeshPart") then
						v22.CFrame = p_u_16["Right Arm"].CFrame
						v22.Massless = false
						local v23 = Instance.new
						table.insert(v_u_20, v23("BodyForce", v22))
						v22.CollisionGroup = "Effects"
						v22.Size = v22.Size * 1.5
					elseif v22:IsA("RopeConstraint") then
						table.insert(v_u_21, v22)
						local v24 = Instance.new("Trail")
						v24.Attachment0 = v22.Attachment0
						v24.Attachment1 = v22.Attachment1
						v24.Brightness = 5
						v24.WidthScale = NumberSequence.new(1, 0)
						v24.Lifetime = 0.1
						v24.Transparency = NumberSequence.new(0.8, 1)
						v24.Parent = v22
					end
				end
				v_u_3:AddItem(v_u_19, 1.7)
				task.delay(1.5, function()
					-- upvalues: (ref) v_u_11, (ref) v_u_8, (copy) v_u_17, (ref) v_u_7, (copy) p_u_16, (ref) v_u_4, (ref) v_u_3
					v_u_11:PlaySound(v_u_8.Mahito.Variants.Transform3, v_u_17, game.SoundService.Effect)
					for _ = 1, 20 do
						local v25 = v_u_7.Mahito.Morph:Clone()
						v25.Weld.Part0 = p_u_16["Right Arm"]
						v25.Color = p_u_16["Right Arm"].Color
						v25.Weld.C1 = CFrame.new(math.random(-150, 150) / 100, math.random(400, 800) / 100, math.random(-150, 150) / 100)
						v25.Parent = workspace.Effects
						v25.Size = Vector3.new(1, 1, 1) * (math.random(6, 25) / 10)
						v_u_4:Create(v25, TweenInfo.new(math.random(20, 40) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							["Size"] = Vector3.new(0, 0, 0)
						}):Play()
						v_u_4:Create(v25.Weld, TweenInfo.new(math.random(10, 40) / 100), {
							["C1"] = CFrame.new(0, -1, 0)
						}):Play()
						v_u_3:AddItem(v25, 0.4)
					end
				end)
				local v26 = TweenInfo.new(0.8, Enum.EasingStyle.Circular, Enum.EasingDirection.InOut)
				local v_u_27 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				for _, v28 in v_u_21 do
					v_u_4:Create(v28, v26, {
						["Length"] = 3.5
					}):Play()
				end
				task.delay(0.8, function()
					-- upvalues: (copy) v_u_21, (ref) v_u_4, (copy) v_u_27, (copy) v_u_20
					for _, v_u_29 in v_u_21 do
						local v_u_30 = Instance.new("RodConstraint")
						v_u_30.Length = v_u_29.CurrentDistance
						v_u_30.Attachment0 = v_u_29.Attachment0
						v_u_30.Attachment1 = v_u_29.Attachment1
						v_u_30.Parent = v_u_29.Parent
						v_u_29.Enabled = false
						task.delay(0.4, function()
							-- upvalues: (copy) v_u_30, (copy) v_u_29, (ref) v_u_4, (ref) v_u_27
							v_u_30.Enabled = false
							v_u_29.Enabled = true
							v_u_29.Length = v_u_30.Length
							v_u_4:Create(v_u_29, v_u_27, {
								["Length"] = 0
							}):Play()
						end)
					end
					task.wait(0.4)
					for _, v31 in v_u_20 do
						v31.Parent.CanCollide = false
					end
				end)
				local v_u_32 = nil
				v_u_32 = v_u_2.Stepped:Connect(function()
					-- upvalues: (copy) p_u_16, (copy) v_u_19, (ref) v_u_32, (copy) v_u_21, (copy) v_u_20
					if p_u_16.Parent and v_u_19.Parent then
						v_u_19.CFrame = p_u_16["Right Arm"].CFrame * CFrame.new(0, -0.5, 0)
						local v33 = -220 * (v_u_21[1].Length - 0.9)
						for v34, v35 in v_u_20 do
							v35.Force = p_u_16["Right Arm"].CFrame.UpVector * v33
							if v35.Parent.CanCollide == false then
								v35:Destroy()
								v_u_20[v34] = nil
							end
						end
					else
						v_u_32:Disconnect()
					end
				end)
			end
		end,
		["Hit"] = function(_, p36)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v37 = p36:FindFirstChild("HumanoidRootPart")
			if v37 then
				v_u_11:Flash(p36, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Itadori.CraniumSmash.Hit1, v37, game.SoundService.Effect)
				local v38 = v_u_7.Mahito.FocusHit:Clone()
				v38.Parent = workspace.Effects
				v38.Position = v37.Position
				v38.Sparks:Emit(20)
				v38.Wind2:Emit(10)
				v_u_3:AddItem(v38, 0.6)
			end
		end,
		["BlackFlashHit"] = function(p39, p40)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_9
			if p39:FindFirstChild("HumanoidRootPart") then
				local v_u_41 = p40:FindFirstChild("HumanoidRootPart")
				if v_u_41 then
					for _, v42 in p40:GetChildren() do
						if v42:IsA("BasePart") then
							local v43 = v_u_7.Itadori.DivergentFist.FlashBurn:Clone()
							v43.Parent = v42
							v_u_3:AddItem(v43, 1)
						end
					end
					local v_u_44 = v_u_7.Itadori.DivergentFist.BlackFlashHit:Clone()
					v_u_44.Position = v_u_41.Position
					v_u_44.Parent = workspace.Effects
					v_u_3:AddItem(v_u_44, 1)
					v_u_11:Flash(p40, Color3.new(1, 0, 0))
					v_u_11:PlaySound(v_u_8.Itadori.DivergentFist.BlackFlashHit, v_u_41, game.SoundService.Effect)
					v_u_44.Wind2:Emit(8)
					v_u_4:Create(v_u_44.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					task.delay(0.1, function()
						-- upvalues: (copy) v_u_44, (ref) v_u_11, (ref) v_u_8, (copy) v_u_41
						v_u_44.Blast:Emit(8)
						v_u_44.Sparks:Emit(15)
						v_u_44.Lightning:Emit(6)
						v_u_44.Wind:Emit(7)
						v_u_11:PlaySound(v_u_8.Mahito.BlackFlash, v_u_41, game.SoundService.Effect)
					end)
					if v_u_5.Character == p39 or v_u_5.Character == p40 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						local v45 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v45.Parent = game.Lighting
						task.wait(0.04)
						v45.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v45.Brightness = 200
						v45.Contrast = -1000
						task.wait(0.04)
						v45:Destroy()
					end
				end
			else
				return
			end
		end,
		["Finisher1"] = function(p46, p47)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v48 = p46:FindFirstChild("HumanoidRootPart")
			if v48 then
				local v49 = p47:FindFirstChild("HumanoidRootPart")
				if v49 then
					local v50 = v_u_7.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					v50.CFrame = v48.CFrame * CFrame.new(2, 1, -5)
					v50.Parent = workspace.Effects
					v50.Wind:Emit(20)
					v50.Sparks:Emit(20)
					v50.Flare:Emit(20)
					v50.Lightning:Emit(5)
					local v51 = v_u_7.Gojo.BlackFlashHit.Sparks2:Clone()
					v51.SpreadAngle = Vector2.new(70, 70)
					v51.Acceleration = Vector3.new(0, 5, 50)
					v51.LockedToPart = true
					v51.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 6, 3), NumberSequenceKeypoint.new(1, 0, 0) })
					v51.Parent = v50
					v51:Emit(30)
					v50.Back1.Back:Emit(1)
					v50.Back2.Back:Emit(1)
					v_u_4:Create(v50.Back1, TweenInfo.new(2), {
						["CFrame"] = v50.Back1.CFrame - v50.Back1.CFrame.LookVector * 20
					}):Play()
					v_u_4:Create(v50.Back2, TweenInfo.new(2), {
						["CFrame"] = v50.Back2.CFrame - v50.Back2.CFrame.LookVector * 20
					}):Play()
					v_u_4:Create(v50.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					v_u_3:AddItem(v50, 3)
					v_u_11:PlaySound(v_u_8.Mahito.BlackFlash, v49, game.SoundService.Effect)
					v_u_11:Bleed(p47)
					if v_u_5.Character == p46 or v_u_5.Character == p47 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						local v52 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v52.Parent = game.Lighting
						task.wait(0.04)
						v52.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v52.Brightness = 200
						v52.Contrast = -1000
						task.wait(0.04)
						v52:Destroy()
					end
				end
			else
				return
			end
		end,
		["Finisher"] = function(p_u_53, p_u_54)
			-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_3, (ref) v_u_5, (ref) v_u_9
			if p_u_53:FindFirstChild("HumanoidRootPart") then
				local v_u_55 = p_u_54:FindFirstChild("HumanoidRootPart")
				if v_u_55 then
					local v_u_56 = v_u_7.Mahito.FocusHit.Burst:Clone()
					v_u_56.Parent = v_u_55
					task.delay(0.5, function()
						-- upvalues: (copy) p_u_54, (ref) v_u_11, (ref) v_u_8, (copy) v_u_55, (copy) v_u_56
						if p_u_54.Parent then
							v_u_11:PlaySound(v_u_8.Itadori.Rush.RushBreak, v_u_55, game.SoundService.Effect)
							v_u_56.Glow:Emit(1)
							task.wait(0.3)
							v_u_56.Wind:Emit(10)
							v_u_56.Wind2:Emit(10)
						end
					end)
					for _, v57 in p_u_54:GetChildren() do
						if v57:IsA("BasePart") then
							for _ = 1, 2 do
								local v_u_58 = v_u_7.Mahito.Morph:Clone()
								v_u_58.Weld.Part0 = v57
								v_u_58.Color = v57.Color
								v_u_58.Material = v57.Material
								v_u_58.Weld.C1 = CFrame.new(math.random(-v57.Size.X, v57.Size.X) / 2, math.random(-v57.Size.Y, v57.Size.Y) / 2, math.random(-v57.Size.Z, v57.Size.Z) / 2)
								v_u_58.Parent = workspace.Effects
								local v59 = math.random(20, 30) / 10
								v_u_58.Size = Vector3.new(0, 0, 0)
								v_u_4:Create(v_u_58, TweenInfo.new(0.8, Enum.EasingStyle.Back, Enum.EasingDirection.InOut), {
									["Size"] = Vector3.new(1, 1, 1) * v59
								}):Play()
								v_u_3:AddItem(v_u_58, 1.5)
								task.delay(0.8, function()
									-- upvalues: (copy) v_u_58, (ref) v_u_4
									v_u_58.Weld:Destroy()
									local v60 = v_u_58
									local v61 = math.random(-40, 40)
									local v62 = math.random(-20, 40)
									local v63 = math.random
									v60.Velocity = Vector3.new(v61, v62, v63(-40, 40))
									v_u_4:Create(v_u_58, TweenInfo.new(0.5), {
										["Size"] = Vector3.new(0, 0, 0)
									}):Play()
								end)
							end
						end
					end
					task.delay(0.8, function()
						-- upvalues: (copy) p_u_54, (ref) v_u_11, (ref) v_u_8, (copy) v_u_55, (ref) v_u_5, (copy) p_u_53, (ref) v_u_9
						if p_u_54.Parent then
							local v64 = v_u_11:PlaySound(v_u_8.Itadori.Dismantle.Explode, v_u_55, game.SoundService.Effect)
							v64.RollOffMaxDistance = 400
							v64.RollOffMinDistance = 100
							v_u_11:Bleed(p_u_54)
							if v_u_5.Character == p_u_53 or v_u_5.Character == p_u_54 then
								v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
							end
						end
					end)
				end
			else
				return
			end
		end,
		["ChainHit"] = function(_, p65)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v66 = p65:FindFirstChild("HumanoidRootPart")
			if v66 then
				v_u_11:Flash(p65, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_8.Mahito.Chainwhip.Hit, v66, game.SoundService.Effect)
				local v67 = v_u_7.Gojo.Twofold.Sparks:Clone()
				v67.Parent = v66.RootAttachment
				v67:Emit(20)
				v_u_3:AddItem(v67, 0.4)
				local v68 = v_u_7.Mahito.FocusHit:Clone()
				v68.Parent = workspace.Effects
				v68.Position = v66.Position
				v68.Sparks:Emit(20)
				v68.Wind2:Emit(10)
				v_u_3:AddItem(v68, 0.6)
			end
		end,
		["BigClub"] = function(p69)
			-- upvalues: (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v_u_70 = p69:FindFirstChild("HumanoidRootPart")
			if v_u_70 then
				v_u_11:PlaySound(v_u_8.Mahito.Variants.Transform2, v_u_70, game.SoundService.Effect)
				task.delay(0.4, function()
					-- upvalues: (ref) v_u_11, (ref) v_u_8, (copy) v_u_70
					v_u_11:PlaySound(v_u_8.Mahito.ForceGrab.Swing, v_u_70, game.SoundService.Effect)
				end)
				for _ = 1, 20 do
					local v71 = v_u_7.Mahito.Morph:Clone()
					v71.Weld.Part0 = p69["Right Arm"]
					v71.Color = p69["Right Arm"].Color
					v71.Weld.C1 = CFrame.new(math.random(-200, 200) / 100, math.random(200, 500) / 100, math.random(-200, 200) / 100)
					v71.Parent = workspace.Effects
					v71.Size = Vector3.new(1, 1, 1) * (math.random(6, 20) / 10)
					v_u_4:Create(v71, TweenInfo.new(math.random(20, 40) / 100, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
						["Size"] = Vector3.new(0, 0, 0)
					}):Play()
					v_u_4:Create(v71.Weld, TweenInfo.new(math.random(10, 40) / 100), {
						["C1"] = CFrame.new(0, -1, 0)
					}):Play()
					v_u_3:AddItem(v71, 0.4)
				end
				local v72 = v_u_7.Mahito.BigClub:Clone()
				v72.Parent = p69
				for _, v73 in pairs(v72:GetChildren()) do
					if v73:IsA("BasePart") then
						v73.Color = p69["Right Arm"].Color
					end
				end
				v72.Weld.Part0 = p69["Right Arm"]
				v_u_3:AddItem(v72, 1.9)
			end
		end
	}
	v_u_10.Effects:Connect(function(p75, ...)
		-- upvalues: (copy) v_u_74
		local v76 = v_u_74[p75]
		if v76 then
			v76(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("FocusStrikeService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12