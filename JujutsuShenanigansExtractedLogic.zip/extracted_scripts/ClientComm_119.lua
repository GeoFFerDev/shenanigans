-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(script.Parent)
require(script.Parent.Parent.Types)
local v_u_2 = require(script.Parent.Parent.Util)
local v_u_3 = {}
v_u_3.__index = v_u_3
function v_u_3.new(p4, p5, p6)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v7 = not v_u_2.IsServer
	assert(v7, "ClientComm must be constructed from the client")
	local v8 = typeof(p4) == "Instance"
	assert(v8, "Parent must be of type Instance")
	local v9 = p6 or v_u_2.DefaultCommFolderName
	local v10 = p4:WaitForChild(v9, v_u_2.WaitForChildTimeout)
	local v11 = v10 ~= nil
	local v12 = "Could not find namespace for ClientComm in parent: " .. v9
	assert(v11, v12)
	local v13 = v_u_3
	local v14 = setmetatable({}, v13)
	v14._instancesFolder = v10
	v14._usePromise = p5
	return v14
end
function v_u_3.GetFunction(p15, p16, p17, p18)
	-- upvalues: (copy) v_u_1
	return v_u_1.GetFunction(p15._instancesFolder, p16, p15._usePromise, p17, p18)
end
function v_u_3.GetSignal(p19, p20, p21, p22)
	-- upvalues: (copy) v_u_1
	return v_u_1.GetSignal(p19._instancesFolder, p20, p21, p22)
end
function v_u_3.GetProperty(p23, p24, p25, p26)
	-- upvalues: (copy) v_u_1
	return v_u_1.GetProperty(p23._instancesFolder, p24, p25, p26)
end
function v_u_3.BuildObject(p27, p28, p29)
	local v30 = {}
	local v31 = p27._instancesFolder:FindFirstChild("RF")
	local v32 = p27._instancesFolder:FindFirstChild("RE")
	local v33 = p27._instancesFolder:FindFirstChild("RP")
	if v31 then
		for _, v34 in v31:GetChildren() do
			if v34:IsA("RemoteFunction") then
				local v_u_35 = p27:GetFunction(v34.Name, p28, p29)
				v30[v34.Name] = function(_, ...)
					-- upvalues: (copy) v_u_35
					return v_u_35(...)
				end
			end
		end
	end
	if v32 then
		for _, v36 in v32:GetChildren() do
			if v36:IsA("RemoteEvent") or v36:IsA("UnreliableRemoteEvent") then
				v30[v36.Name] = p27:GetSignal(v36.Name, p28, p29)
			end
		end
	end
	if v33 then
		for _, v37 in v33:GetChildren() do
			if v37:IsA("RemoteEvent") then
				v30[v37.Name] = p27:GetProperty(v37.Name, p28, p29)
			end
		end
	end
	return v30
end
function v_u_3.Destroy(_) end
return v_u_3