-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Modules.ListData)
local v_u_6 = {
	["Autocomplete"] = function(p2)
		-- upvalues: (copy) v_u_1
		local v3 = {}
		for _, v4 in v_u_1.Items do
			if v4:lower():find(p2:lower()) then
				table.insert(v3, v4)
			end
		end
		return v3
	end,
	["Parse"] = function(p5)
		return p5
	end
}
return function(p7)
	-- upvalues: (copy) v_u_6
	p7:RegisterType("item", v_u_6)
end