-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = game:GetService("RunService")
game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
function v1.Start(_, p_u_5, p6)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_2
	if p_u_5.Character then
		local v_u_7 = script.Scene:Clone()
		v_u_7.Parent = workspace.Effects
		table.insert(p6, v_u_7)
		task.spawn(function()
			-- upvalues: (copy) p_u_5, (copy) v_u_7
			local v8
			if p_u_5.Character then
				v8 = p_u_5.Character.Humanoid:GetAppliedDescription()
			else
				v8 = game.Players:GetHumanoidDescriptionFromUserId(p_u_5.UserId)
			end
			v_u_7.Rig.Humanoid:ApplyDescriptionReset(v8)
		end)
		local v9 = script.Voice:Clone()
		v9.SoundGroup = game.SoundService.Voice
		v9.Parent = workspace
		table.insert(p6, v9)
		local v10 = script.Music:Clone()
		v10.SoundGroup = game.SoundService.Music
		v10.Parent = workspace
		table.insert(p6, v10)
		local v11 = script.Effect:Clone()
		v11.SoundGroup = game.SoundService.Effect
		v11.Parent = workspace
		table.insert(p6, v11)
		local v12 = v_u_7.Rig.Humanoid:LoadAnimation(script.Character)
		local v13 = v_u_7.Camera.Humanoid:LoadAnimation(script.Camera)
		v12:Play(0, nil, 0)
		table.insert(p6, v12)
		v13:Play(0, nil, 0)
		table.insert(p6, v13)
		task.wait(2.4)
		local v14 = script.Text:Clone()
		v14.Parent = v_u_4.PlayerGui
		v_u_3:Create(v14.Frame.TextLabel, TweenInfo.new(0.4), {
			["TextTransparency"] = 0
		}):Play()
		v_u_3:Create(v14.Frame.TextLabel.UIStroke, TweenInfo.new(0.4), {
			["Transparency"] = 0
		}):Play()
		table.insert(p6, v14)
		v_u_7.Rig["ExtraLeft Arm"].Color = v_u_7.Rig["Left Arm"].Color
		v_u_7.Rig["ExtraRight Arm"].Color = v_u_7.Rig["Right Arm"].Color
		task.wait(0.1)
		v_u_4.PlayerGui.Main.Enabled = false
		local v_u_15 = workspace.CurrentCamera
		v_u_15.CameraType = Enum.CameraType.Scriptable
		local v16 = v_u_2.RenderStepped
		table.insert(p6, v16:Connect(function()
			-- upvalues: (copy) v_u_15, (copy) v_u_7
			v_u_15.CFrame = v_u_7.Camera.Torso.CFrame
		end))
		local v17 = tick() + 0.25
		repeat
			task.wait()
		until v12.Length > 0 and (v13.Length > 0 and (v9.IsLoaded and (v10.IsLoaded and v11.IsLoaded))) or v17 < tick()
		v12:AdjustSpeed(0.9230769230769231)
		v13:AdjustSpeed(0.9230769230769231)
		v9:Play()
		v10:Play()
		v11:Play()
		task.wait(1.3)
		v_u_3:Create(v14.Frame, TweenInfo.new(0.6), {
			["BackgroundTransparency"] = 1
		}):Play()
		v_u_3:Create(v14.Frame.TextLabel.UIStroke, TweenInfo.new(0.6), {
			["Transparency"] = 1
		}):Play()
		v_u_3:Create(v14.Frame.TextLabel, TweenInfo.new(0.6), {
			["TextTransparency"] = 1
		}):Play()
		task.wait(2)
		v_u_3:Create(v_u_7.Rig.Torso.PointLight, TweenInfo.new(1), {
			["Brightness"] = 0
		}):Play()
		for _, v18 in v_u_7:GetDescendants() do
			if v18:IsA("ParticleEmitter") then
				v_u_3:Create(v18, TweenInfo.new(1), {
					["Brightness"] = 0,
					["LightEmission"] = 0
				}):Play()
			end
		end
		task.wait(3.2)
		v12:AdjustSpeed(0)
		v13:AdjustSpeed(0)
		for _, v19 in v_u_7:GetDescendants() do
			if v19:IsA("Beam") then
				v19.TextureSpeed = 0
			elseif v19:IsA("ParticleEmitter") then
				v19.TimeScale = 0
			end
		end
	end
end
return v1