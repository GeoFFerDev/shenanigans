-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
require(v4.Modules.CameraShaker)
require(v4.Modules.BloodyZee)
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "TendrilGrabController"
})
function v9.KnitStart(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_6, (copy) v_u_5, (copy) v_u_3, (copy) v_u_2, (ref) v_u_7
	local v_u_46 = {
		["Preview"] = function(p10, _)
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_5, (ref) v_u_3, (ref) v_u_2
			local v11 = p10:FindFirstChild("HumanoidRootPart")
			if not v11 then
				return
			end
			v_u_8:PlaySound(v_u_6.Naoya.TendrilGrab.Start, v11, game.SoundService.Effect)
			v_u_8:PlaySound(v_u_6.Naoya.TendrilGrab.Preview, v11, game.SoundService.Effect)
			local v12 = v_u_5.Mahito.WideSPStrike.HitArea:Clone()
			v12.Afterimages:Destroy()
			v12.groundwaveing:Destroy()
			v12.Overlay.Color3 = Color3.new(255, 0, 0)
			v12.Prog.Overlay.Color3 = Color3.new(255, 0, 0)
			local v13 = workspace:Raycast(v11.Position, Vector3.new(-0, -10, -0), _G.MapParams)
			if v13 then
				v12.Position = v13.Position
				v12.Prog.Position = v13.Position
			else
				v12.Position = v11.Position + Vector3.new(0, -3, 0)
				v12.Prog.Position = v11.Position + Vector3.new(0, -3, 0)
			end
			v12.Parent = workspace.Effects
			v12.Size = Vector3.new(50, 0.001, 50)
			v_u_3:Create(v12.Overlay, TweenInfo.new(0.25), {
				["Transparency"] = 0.5
			}):Play()
			v12.Prog.Size = Vector3.new(0, 0, 0)
			v_u_3:Create(v12.Prog.Overlay, TweenInfo.new(0.25), {
				["Transparency"] = 0.5
			}):Play()
			v_u_3:Create(v12.Prog, TweenInfo.new(0.5, Enum.EasingStyle.Linear), {
				["Size"] = Vector3.new(50, 0.001, 50)
			}):Play()
			v_u_2:AddItem(v12, 2)
			local v14 = tick()
			while true do
				task.wait()
				local v15 = workspace:Raycast(v11.Position, Vector3.new(-0, -10, -0), _G.MapParams)
				if v15 then
					v12.Position = v15.Position
					v12.Prog.Position = v15.Position
				else
					v12.Position = v11.Position + Vector3.new(0, -3, 0)
					v12.Prog.Position = v11.Position + Vector3.new(0, -3, 0)
				end
				if tick() - v14 > 0.5 then
					v_u_8:PlaySound(v_u_6.Naoya.TendrilGrab.Retrieve, v11, game.SoundService.Effect)
					v_u_3:Create(v12.Prog.Overlay, TweenInfo.new(0.25), {
						["Transparency"] = 1
					}):Play()
					v_u_3:Create(v12.Overlay, TweenInfo.new(0.25), {
						["Transparency"] = 1
					}):Play()
					return
				end
			end
		end,
		["Grab"] = function(p16, p17, p18)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3
			local v19 = p17:FindFirstChild("HumanoidRootPart")
			if not v19 then
				return
			end
			local v20 = v_u_5.Naoya.GrabModel:Clone()
			v_u_2:AddItem(v20, 6)
			local v21 = p16 * CFrame.new(0, -4, 0) * CFrame.Angles(0, 1.5707963267948966, 0)
			v20:PivotTo(v21)
			v20.Parent = workspace.Effects
			v_u_8:PlaySound(v_u_6.Naoya.TendrilGrab.Grab, v19, game.SoundService.Effect)
			for _, v22 in v20:GetChildren() do
				if v22:FindFirstChild("Weld") then
					v22:SetAttribute("OldSize", v22.Size)
					v22.Size = Vector3.new(0.1, 0.1, 0.1)
				end
			end
			local v23 = tick()
			repeat
				task.wait()
				local v24 = (tick() - v23) / 0.1
				v20:PivotTo(v21:Lerp(p16, (math.clamp(v24, 0, 1))))
			until tick() - v23 >= 0.1
			for _, v25 in v20:GetChildren() do
				local v26 = v25:FindFirstChild("Weld")
				if v26 and p17:FindFirstChild(v26:GetAttribute("AttachPart")) then
					v25.Anchored = false
					v26.Part0 = p17[v26:GetAttribute("AttachPart")]
					v_u_3:Create(v25, TweenInfo.new(0.1), {
						["Size"] = v25:GetAttribute("OldSize")
					}):Play()
				end
			end
			while true do
				task.wait()
				for _, v27 in v20:GetChildren() do
					if v27.Name == "Attach" then
						local v28 = v20:FindFirstChild(v27:GetAttribute("Attach0"), true)
						local v29 = v20:FindFirstChild(v27:GetAttribute("Attach"), true)
						if not (v28 and v29) then
							goto l19
						end
						local v30 = v28.WorldPosition
						local v31 = v29.WorldPosition
						local v32 = v31 - v30
						local v33 = v32.Magnitude
						local v34 = (v30 + v31) * 0.5
						local v35 = v32 / v33
						v27.CFrame = CFrame.fromMatrix(v34, v35:Cross(Vector3.new(0, 1, 0)).Magnitude > 1e-6 and (v35:Cross(Vector3.new(0, 1, 0)).Unit or Vector3.new(1, 0, 0)) or Vector3.new(1, 0, 0), v35)
						local v36 = v27.Size.X
						local v37 = v27.Size.Z
						v27.Size = Vector3.new(v36, v33, v37)
					end
				end
				::l19::
				if not p18.Parent then
					if _G.Settings.DesPHY then
						if (workspace.CurrentCamera.CFrame.Position - v21.Position).Magnitude > 150 then
							return
						end
						for _, v38 in v20:GetChildren() do
							for _ = 1, 2 do
								local v_u_39 = v_u_5.Hiromi.GavelShard:Clone()
								v_u_39.Color = v38.Color
								v_u_39.Material = v38.Material
								v_u_39.Position = v38.Position
								v_u_39.Size = v_u_39.Size * (math.random(4, 8) / 10)
								local v40 = math.random(-30, 30)
								local v41 = math.random(10, 30)
								local v42 = math.random
								v_u_39.Velocity = Vector3.new(v40, v41, v42(-30, 30))
								local v43 = math.random(-50, 50)
								local v44 = math.random(-50, 50)
								local v45 = math.random
								v_u_39.RotVelocity = Vector3.new(v43, v44, v45(-50, 50))
								v_u_39.Parent = workspace.Effects
								v_u_2:AddItem(v_u_39, 2)
								task.delay(1, function()
									-- upvalues: (ref) v_u_3, (copy) v_u_39
									v_u_3:Create(v_u_39, TweenInfo.new(1), {
										["Size"] = Vector3.new(0, 0, 0)
									}):Play()
								end)
							end
						end
					end
					v20:Destroy()
					v_u_8:PlaySound(v_u_6.Naoya.TendrilGrab.GrabEnd, v19, game.SoundService.Effect)
					return
				end
			end
		end
	}
	v_u_7.Effects:Connect(function(p47, ...)
		-- upvalues: (copy) v_u_46
		local v48 = v_u_46[p47]
		if v48 then
			v48(...)
		end
	end)
end
function v9.KnitInit(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (ref) v_u_8
	v_u_7 = v_u_1.GetService("TendrilGrabService")
	v_u_8 = v_u_1.GetController("FXController")
end
return v9