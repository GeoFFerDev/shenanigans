-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "disguise",
	["Description"] = "Wears the player\'s outfit",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"Mod",
		"Contrib",
		"Youtuber"
	},
	["Args"] = {
		{
			["Type"] = "players",
			["Name"] = "Players"
		},
		{
			["Type"] = "username",
			["Name"] = "To"
		}
	}
}
return v1