-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "hitbox",
	["Aliases"] = { "ht" },
	["Description"] = "Sets the transparency of hitboxes",
	["Group"] = { "Owner", "Tester", "Developer" },
	["Args"] = {
		{
			["Type"] = "boolean",
			["Name"] = "Bool"
		}
	}
}
return v1