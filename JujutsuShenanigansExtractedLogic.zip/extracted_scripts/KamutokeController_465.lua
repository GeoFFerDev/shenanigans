-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v4 = game.ReplicatedStorage
local _ = v4.Animations
local v_u_5 = v4.Utils
local v_u_6 = v4.Sounds
local v_u_7 = require(v4.Modules.CameraShaker)
local v_u_8 = require(v4.Modules.LightningBeams)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "KamutokeController"
})
function v11.KnitStart(_)
	-- upvalues: (copy) v_u_5, (ref) v_u_10, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_8, (copy) v_u_7, (ref) v_u_9
	local v_u_26 = {
		["Kamutoke"] = function(p12, p13)
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_6
			local v14 = p12:FindFirstChild("HumanoidRootPart")
			if v14 then
				local v15 = v_u_5.Heian.Kamutoke:Clone()
				v15.Handle.Weld.Part0 = p12["Right Arm"]
				v15.Parent = p13
				v_u_10:PlaySound(v_u_6.Heian.Kamutoke.Equip, v14, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_6.Heian.Kamutoke.Equip2, v14, game.SoundService.Effect)
			end
		end,
		["Strike"] = function(p_u_16)
			-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_2, (ref) v_u_8, (ref) v_u_10, (ref) v_u_6, (ref) v_u_7
			local v17 = v_u_5.Mahito.WideSPStrike.HitArea:Clone()
			v17.Size = Vector3.new(19, 0, 19)
			v17.Overlay.Color3 = Color3.new(1, 0, 0)
			v17.Prog.Overlay.Color3 = Color3.new(1, 0, 0)
			v17.Afterimages.Enabled = false
			v17.groundwaveing.Spin.Enabled = false
			v17.Position = p_u_16
			v17.Prog.Position = p_u_16
			v17.Prog.Overlay.Transparency = 1
			v17.Parent = workspace.Effects
			v_u_3:Create(v17.Prog.Overlay, TweenInfo.new(0.4), {
				["Transparency"] = 0.8
			}):Play()
			v_u_3:Create(v17.Prog, TweenInfo.new(0.7, Enum.EasingStyle.Linear), {
				["Size"] = v17.Size
			}):Play()
			v_u_2:AddItem(v17, 3)
			task.wait(0.7)
			v17.Prog:Destroy()
			local v_u_18 = v_u_5.Heian.Lightning:Clone()
			v_u_18.Position = p_u_16
			v_u_18.Parent = workspace.Effects
			v_u_2:AddItem(v_u_18, 2)
			v_u_18.Attachment.Dust:Emit(25)
			v_u_18.Attachment.Ring:Emit(25)
			v_u_18.Attachment.Wind2:Emit(6)
			local v_u_19 = v_u_8.new(v_u_18.Air, v_u_18.Attachment)
			v_u_19.PulseSpeed = 1000
			v_u_19.FadeLength = 0.25
			v_u_19.MaxRadius = 20
			v_u_19.MinRadius = 0
			v_u_19.AnimationSpeed = 300
			v_u_19.MinThicknessMultiplier = 2
			v_u_19.MaxThicknessMultiplier = 10
			v_u_19.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 0, 0)), ColorSequenceKeypoint.new(0.2, Color3.fromRGB(255, 170, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 255, 127)) })
			task.delay(0.05, function()
				-- upvalues: (copy) p_u_16, (copy) v_u_18, (copy) v_u_19, (ref) v_u_3
				local v20 = workspace:Raycast(p_u_16, Vector3.new(0, -20, 0), _G.MapParams)
				if v20 then
					v_u_18.Attachment.WorldPosition = v20.Position
				end
				task.wait(0.1)
				v_u_19:Destroy()
				v_u_18.Attachment.Burn:Emit(1)
				v_u_18.Sparks.Enabled = false
				v_u_3:Create(v_u_18.PointLight, TweenInfo.new(0.5), {
					["Brightness"] = 0
				}):Play()
			end)
			local v21 = v_u_10
			local v22 = v_u_6.Heian.Kamutoke.Fire
			local v23 = math.random
			v21:PlaySound(v22[tostring(v23(1, 4))], v_u_18, game.SoundService.Effect)
			if (workspace.CurrentCamera.CFrame.Position - p_u_16).Magnitude < 40 then
				v_u_7.CurrentShaker:Shake(v_u_7.Presets.Snap)
				return
			elseif (workspace.CurrentCamera.CFrame.Position - p_u_16).Magnitude < 100 then
				v_u_7.CurrentShaker:Shake(v_u_7.Presets.HeavyHit)
			elseif (workspace.CurrentCamera.CFrame.Position - p_u_16).Magnitude < 200 then
				v_u_7.CurrentShaker:Shake(v_u_7.Presets.LightHit)
			end
		end,
		["Finisher"] = function(p24)
			-- upvalues: (ref) v_u_10, (ref) v_u_6
			local v25 = p24.HumanoidRootPart
			if v25 then
				v_u_10:Burn(p24)
				v_u_10:PlaySound(v_u_6.Gojo.HollowPurple.Hit, v25, game.SoundService.Effect)
			end
		end
	}
	v_u_9.Effects:Connect(function(p27, ...)
		-- upvalues: (copy) v_u_26
		local v28 = v_u_26[p27]
		if v28 then
			v28(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("KamutokeService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11