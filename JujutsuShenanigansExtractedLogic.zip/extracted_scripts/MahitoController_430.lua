-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game.Players.LocalPlayer
local v_u_6 = game.ReplicatedStorage
local _ = v_u_6.Animations
local v_u_7 = v_u_6.Utils
local v_u_8 = v_u_6.Sounds
local v_u_9 = require(v_u_6.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "MahitoController"
})
function v14.KnitStart(_)
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2, (copy) v_u_6, (ref) v_u_10, (ref) v_u_11
	local v_u_201 = {
		["Hit"] = function(p15, p16, p17, p18)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v19 = p15:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_12:Flash(p15, Color3.new(1, 1, 1))
				if p17 == 1 and not p18 then
					v_u_12:PlaySound(v_u_8.Mahito.Variants.M1:FindFirstChild("Hit" .. p16), v19, game.SoundService.Effect)
					return
				elseif p17 == 2 and p18 ~= "Up" then
					v_u_12:PlaySound(v_u_8.Mahito.Variants.M2:FindFirstChild("Hit" .. p16), v19, game.SoundService.Effect)
					return
				elseif p17 == 4 then
					v_u_12:PlaySound(v_u_8.Mahito.Variants.M3:FindFirstChild("Hit" .. p16), v19, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit" .. p16), v19, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["BladeHit"] = function(p20)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_12:Flash(p20, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.M1.Hit1, v21, game.SoundService.Effect)
			end
		end,
		["ChaseHit"] = function(p22, p23)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_3
			local v24 = p22:FindFirstChild("HumanoidRootPart")
			if v24 then
				local v25 = p23:FindFirstChild("HumanoidRootPart")
				if v25 then
					v_u_12:Flash(p23, Color3.new(1, 1, 1))
					v_u_12:PlaySound(v_u_8.Gojo.M1:FindFirstChild("Hit3"), v25, game.SoundService.Effect)
					local v26 = v_u_7.ChaseHit:Clone()
					local v27 = CFrame.new
					local v28 = v25.Position
					local v29 = v24.Position.X
					local v30 = v25.Position.Y
					local v31 = v24.Position.Z
					v26.CFrame = v27(v28, (Vector3.new(v29, v30, v31))) * CFrame.Angles(0, 3.141592653589793, 0)
					v26.Parent = workspace.Effects
					v26.Ring:Emit(7)
					v26.Sparks:Emit(12)
					v_u_3:AddItem(v26, 0.5)
				end
			else
				return
			end
		end,
		["Chase"] = function(p32)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8
			local v33 = p32.HumanoidRootPart
			if v33 then
				local v34 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v34.CFrame = v33.CFrame * CFrame.new(0, 1, -4)
				v34.Size = Vector3.new(0, 0, 2)
				v34.Parent = workspace.Effects
				v_u_4:Create(v34, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(9, 9, 0),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v34, 0.3)
				v_u_12:PlaySound(v_u_8.Misc.Chase, v33, game.SoundService.Effect)
				v_u_12:DustTrail(p32, 0.4, CFrame.Angles(0, -1.5707963267948966, 0))
			end
		end,
		["ChaseStart"] = function(p35, p36)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v37 = p35.HumanoidRootPart
			if v37 then
				if p36 == 1 then
					v_u_12:PlaySound(v_u_8.Mahito.Variants.StrikeStart, v37, game.SoundService.Effect)
				else
					v_u_12:PlaySound(v_u_8.Mahito.Variants.Spin, v37, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Chase2"] = function(p38, p39, p40)
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_12, (ref) v_u_8, (ref) v_u_2, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_6
			local v_u_41 = p38.HumanoidRootPart
			if v_u_41 then
				if v_u_5.Character == p38 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
				if p39 == 1 then
					v_u_12:PlaySound(v_u_8.Mahito.Variants.Strike, v_u_41, game.SoundService.Effect)
					v_u_2.Stepped:Wait()
					local v_u_42 = CFrame.new(p40, v_u_41.Position)
					local v43 = (p40 - v_u_41.Position).Magnitude
					local v44 = v_u_7.Mahito.Dash:Clone()
					v44.CFrame = v_u_42 + v_u_42.LookVector * v43 / 2
					v44.Size = Vector3.new(5, 5, v43)
					v44.Parent = workspace.Effects
					v_u_4:Create(v44, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(0, 0, v43),
						["CFrame"] = v44.CFrame * CFrame.Angles(0, 0, 3.141592653589793)
					}):Play()
					v_u_3:AddItem(v44, 0.2)
					local v45 = Instance.new("Model")
					local v46 = v_u_6.Utils.Itadori.RushWind:Clone()
					v46.CFrame = v_u_41.CFrame * CFrame.new(0, -1, 0)
					v46.Parent = v45
					v45.Parent = workspace.Effects
					v45:ScaleTo(0.6)
					v46.Ring:Emit(7)
					v46.Dash1.Dash:Emit(1)
					v46.Dash2.Dash:Emit(1)
					v_u_3:AddItem(v45, 2)
					local v47 = v_u_7.Itadori.Shock:Clone()
					v47.CFrame = v_u_42 * CFrame.Angles(1.5707963267948966, 0, 0)
					v47.Parent = workspace.Effects
					v_u_4:Create(v47, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(10, 0, 10),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v47, 0.3)
					task.delay(0.075, function()
						-- upvalues: (ref) v_u_7, (copy) v_u_42, (ref) v_u_4, (ref) v_u_3, (copy) v_u_41
						local v48 = v_u_7.Itadori.Shock:Clone()
						v48.CFrame = v_u_42 * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_42.LookVector * 3
						v48.Parent = workspace.Effects
						v_u_4:Create(v48, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_3:AddItem(v48, 0.2)
						task.wait(0.075)
						local v49 = v_u_7.Itadori.Shock:Clone()
						v49.CFrame = v_u_41.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
						v49.Parent = workspace.Effects
						v_u_4:Create(v49, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_3:AddItem(v49, 0.2)
					end)
				elseif p39 == 4 then
					local v50 = v_u_7.Itadori.Shock:Clone()
					v50.CFrame = v_u_41.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v50.Parent = workspace.Effects
					v_u_4:Create(v50, TweenInfo.new(0.3), {
						["Size"] = Vector3.new(10, 0, 10),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v50, 0.3)
					task.delay(0.075, function()
						-- upvalues: (ref) v_u_7, (copy) v_u_41, (ref) v_u_4, (ref) v_u_3
						local v51 = v_u_7.Itadori.Shock:Clone()
						v51.CFrame = v_u_41.CFrame * CFrame.Angles(1.5707963267948966, 0, 0) + v_u_41.CFrame.LookVector * 3
						v51.Parent = workspace.Effects
						v_u_4:Create(v51, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_3:AddItem(v51, 0.2)
						task.wait(0.075)
						local v52 = v_u_7.Itadori.Shock:Clone()
						v52.CFrame = v_u_41.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
						v52.Parent = workspace.Effects
						v_u_4:Create(v52, TweenInfo.new(0.2), {
							["Size"] = Vector3.new(8, 0, 8),
							["Transparency"] = 1
						}):Play()
						v_u_3:AddItem(v52, 0.2)
					end)
					local v_u_53 = v_u_7.Mahito.Worms.WormLaunch.groundwaveing.groundwaveing1:Clone()
					v_u_53.EmissionDirection = Enum.NormalId.Front
					v_u_53.Parent = v_u_41
					v_u_3:AddItem(v_u_53, 1)
					task.delay(0.5, function()
						-- upvalues: (copy) v_u_53
						v_u_53.Enabled = false
					end)
					local v_u_54 = v_u_7.Mahito.Worms.WormLaunch.groundwaveing.groundwaveing3:Clone()
					v_u_54.EmissionDirection = Enum.NormalId.Front
					v_u_54.Parent = v_u_41
					v_u_3:AddItem(v_u_54, 1)
					task.delay(0.5, function()
						-- upvalues: (copy) v_u_54
						v_u_54.Enabled = false
					end)
					local v55 = v_u_41:FindFirstChild("RootJoint")
					if v55 then
						local v56 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0)
						v55.C0 = v56 * CFrame.new(7, 0, 0)
						v_u_4:Create(v55, TweenInfo.new(0.8, Enum.EasingStyle.Elastic), {
							["C0"] = v56
						}):Play()
						return
					end
				else
					local v_u_57 = v_u_7.Megumi.Wep.Attachment.Ring:Clone()
					v_u_57.Enabled = true
					v_u_57.TimeScale = 1
					v_u_57.Parent = v_u_41
					task.delay(0.4, function()
						-- upvalues: (copy) v_u_57, (ref) v_u_3
						v_u_57.Enabled = false
						v_u_3:AddItem(v_u_57, 0.5)
					end)
				end
			else
				return
			end
		end,
		["Swing"] = function(p58)
			-- upvalues: (ref) v_u_12, (ref) v_u_8
			local v59 = p58:FindFirstChild("HumanoidRootPart")
			if v59 then
				v_u_12:PlaySound(v_u_8.Misc.Swing.Fist, v59, game.SoundService.Effect)
			end
		end,
		["Swing2"] = function(p60)
			-- upvalues: (ref) v_u_4, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_3
			local v61 = p60:FindFirstChild("HumanoidRootPart")
			if v61 then
				local v62 = v61:FindFirstChild("RootJoint")
				if v62 then
					local v63 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0)
					v62.C0 = v63 * CFrame.new(7, 0, 0)
					v_u_4:Create(v62, TweenInfo.new(0.5, Enum.EasingStyle.Elastic), {
						["C0"] = v63
					}):Play()
				end
				if v_u_5.Character == p60 then
					local v_u_64 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
					task.delay(0.45, function()
						-- upvalues: (copy) v_u_64
						v_u_64:StartFadeOut(1)
					end)
				end
				local v65 = v_u_7.Mahito.Worms.DashSlash.Attachment:Clone()
				v65.Parent = v61
				v_u_3:AddItem(v65, 2.5)
				task.wait(0.45)
				for _, v66 in v65:GetChildren() do
					v66.Enabled = false
				end
				task.wait(0.1)
				v65.Wind2:Emit(10)
				v65.Sparks:Emit(10)
			end
		end,
		["Swing3"] = function(p67, p68, p69, p70)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12
			local v_u_71 = Color3.fromRGB(124, 80, 255)
			if p70 == 1 then
				local v_u_72 = p67.SetAssets:FindFirstChild("Weapon").MahitoWepR.Sword.Blade
				local v_u_73 = p67.SetAssets:FindFirstChild("Weapon").MahitoWepL.Sword.Blade
				if p69 == "Down" or p69 == "Up" then
					v_u_12:ArmFlash(p67["Right Leg"], v_u_71, 0.4)
					return
				end
				if p68 == 1 or p68 == 3 then
					if v_u_72 then
						local v_u_74 = nil
						local v_u_75 = 0.25
						task.spawn(function()
							-- upvalues: (copy) v_u_74, (copy) v_u_72, (ref) v_u_7, (copy) v_u_71, (ref) v_u_4, (ref) v_u_3, (copy) v_u_75
							if v_u_74 then
								task.wait(v_u_74)
							end
							local v76
							if v_u_72.Name == "ClubBase" then
								v76 = v_u_7.Mahito.ClubCombatTrail:Clone()
							else
								v76 = v_u_7.Mahito.SwordCombatTrail:Clone()
							end
							v76.Color = v_u_71
							v76.Weld.Part0 = v_u_72
							v76.Parent = workspace.Effects
							task.wait(0.35)
							v76.Trail.Enabled = false
							v_u_4:Create(v76, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v76, v_u_75 or 0.2)
						end)
					end
				end
				if p68 == 2 then
					if v_u_73 then
						local v_u_77 = nil
						local v_u_78 = 0.25
						task.spawn(function()
							-- upvalues: (copy) v_u_77, (copy) v_u_73, (ref) v_u_7, (copy) v_u_71, (ref) v_u_4, (ref) v_u_3, (copy) v_u_78
							if v_u_77 then
								task.wait(v_u_77)
							end
							local v79
							if v_u_73.Name == "ClubBase" then
								v79 = v_u_7.Mahito.ClubCombatTrail:Clone()
							else
								v79 = v_u_7.Mahito.SwordCombatTrail:Clone()
							end
							v79.Color = v_u_71
							v79.Weld.Part0 = v_u_73
							v79.Parent = workspace.Effects
							task.wait(0.35)
							v79.Trail.Enabled = false
							v_u_4:Create(v79, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v79, v_u_78 or 0.2)
						end)
					end
				end
				if p68 == 4 then
					if v_u_72 then
						local v_u_80 = nil
						local v_u_81 = 0.35
						task.spawn(function()
							-- upvalues: (copy) v_u_80, (copy) v_u_72, (ref) v_u_7, (copy) v_u_71, (ref) v_u_4, (ref) v_u_3, (copy) v_u_81
							if v_u_80 then
								task.wait(v_u_80)
							end
							local v82
							if v_u_72.Name == "ClubBase" then
								v82 = v_u_7.Mahito.ClubCombatTrail:Clone()
							else
								v82 = v_u_7.Mahito.SwordCombatTrail:Clone()
							end
							v82.Color = v_u_71
							v82.Weld.Part0 = v_u_72
							v82.Parent = workspace.Effects
							task.wait(0.35)
							v82.Trail.Enabled = false
							v_u_4:Create(v82, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v82, v_u_81 or 0.2)
						end)
					end
					if v_u_73 then
						local v_u_83 = nil
						local v_u_84 = 0.35
						task.spawn(function()
							-- upvalues: (copy) v_u_83, (copy) v_u_73, (ref) v_u_7, (copy) v_u_71, (ref) v_u_4, (ref) v_u_3, (copy) v_u_84
							if v_u_83 then
								task.wait(v_u_83)
							end
							local v85
							if v_u_73.Name == "ClubBase" then
								v85 = v_u_7.Mahito.ClubCombatTrail:Clone()
							else
								v85 = v_u_7.Mahito.SwordCombatTrail:Clone()
							end
							v85.Color = v_u_71
							v85.Weld.Part0 = v_u_73
							v85.Parent = workspace.Effects
							task.wait(0.35)
							v85.Trail.Enabled = false
							v_u_4:Create(v85, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v85, v_u_84 or 0.2)
						end)
					end
				end
			elseif p70 == 2 then
				local v_u_86 = p67.SetAssets:FindFirstChild("Weapon").MahitoWepR.Club.ClubBase
				local v_u_87 = p67.SetAssets:FindFirstChild("Weapon").MahitoWepL.Club.ClubBase
				if p68 == 1 or p68 == 3 then
					if v_u_86 then
						local v_u_88 = 0.1
						local v_u_89 = 0.5
						task.spawn(function()
							-- upvalues: (copy) v_u_88, (copy) v_u_86, (ref) v_u_7, (copy) v_u_71, (ref) v_u_4, (ref) v_u_3, (copy) v_u_89
							if v_u_88 then
								task.wait(v_u_88)
							end
							local v90
							if v_u_86.Name == "ClubBase" then
								v90 = v_u_7.Mahito.ClubCombatTrail:Clone()
							else
								v90 = v_u_7.Mahito.SwordCombatTrail:Clone()
							end
							v90.Color = v_u_71
							v90.Weld.Part0 = v_u_86
							v90.Parent = workspace.Effects
							task.wait(0.35)
							v90.Trail.Enabled = false
							v_u_4:Create(v90, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v90, v_u_89 or 0.2)
						end)
					end
				end
				if p68 == 2 then
					if v_u_87 then
						local v_u_91 = 0.1
						local v_u_92 = 0.5
						task.spawn(function()
							-- upvalues: (copy) v_u_91, (copy) v_u_87, (ref) v_u_7, (copy) v_u_71, (ref) v_u_4, (ref) v_u_3, (copy) v_u_92
							if v_u_91 then
								task.wait(v_u_91)
							end
							local v93
							if v_u_87.Name == "ClubBase" then
								v93 = v_u_7.Mahito.ClubCombatTrail:Clone()
							else
								v93 = v_u_7.Mahito.SwordCombatTrail:Clone()
							end
							v93.Color = v_u_71
							v93.Weld.Part0 = v_u_87
							v93.Parent = workspace.Effects
							task.wait(0.35)
							v93.Trail.Enabled = false
							v_u_4:Create(v93, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v93, v_u_92 or 0.2)
						end)
					end
				end
				if p69 == "Up" then
					v_u_12:ArmFlash(p67["Right Leg"], v_u_71, 0.4)
					return
				end
				if p68 == 4 or p69 == "Down" then
					if v_u_86 then
						local v_u_94 = 0.1
						local v_u_95 = 0.75
						task.spawn(function()
							-- upvalues: (copy) v_u_94, (copy) v_u_86, (ref) v_u_7, (copy) v_u_71, (ref) v_u_4, (ref) v_u_3, (copy) v_u_95
							if v_u_94 then
								task.wait(v_u_94)
							end
							local v96
							if v_u_86.Name == "ClubBase" then
								v96 = v_u_7.Mahito.ClubCombatTrail:Clone()
							else
								v96 = v_u_7.Mahito.SwordCombatTrail:Clone()
							end
							v96.Color = v_u_71
							v96.Weld.Part0 = v_u_86
							v96.Parent = workspace.Effects
							task.wait(0.35)
							v96.Trail.Enabled = false
							v_u_4:Create(v96, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v96, v_u_95 or 0.2)
						end)
					end
					if v_u_87 then
						local v_u_97 = 0.1
						local v_u_98 = 0.75
						task.spawn(function()
							-- upvalues: (copy) v_u_97, (copy) v_u_87, (ref) v_u_7, (copy) v_u_71, (ref) v_u_4, (ref) v_u_3, (copy) v_u_98
							if v_u_97 then
								task.wait(v_u_97)
							end
							local v99
							if v_u_87.Name == "ClubBase" then
								v99 = v_u_7.Mahito.ClubCombatTrail:Clone()
							else
								v99 = v_u_7.Mahito.SwordCombatTrail:Clone()
							end
							v99.Color = v_u_71
							v99.Weld.Part0 = v_u_87
							v99.Parent = workspace.Effects
							task.wait(0.35)
							v99.Trail.Enabled = false
							v_u_4:Create(v99, TweenInfo.new(0.1), {
								["Transparency"] = 1
							}):Play()
							v_u_3:AddItem(v99, v_u_98 or 0.2)
						end)
					end
				end
			else
				if p70 == 3 then
					if p69 == "Down" then
						v_u_12:ArmFlash(p67["Right Leg"], v_u_71, 0.4)
						return
					elseif p68 == 4 then
						v_u_12:ArmFlash(p67["Right Leg"], v_u_71, 0.4)
						return
					elseif p68 == 3 then
						v_u_12:ArmFlash(p67["Left Arm"], v_u_71, 0.35)
					else
						v_u_12:ArmFlash(p67["Right Arm"], v_u_71, 0.3)
					end
				end
				if p70 == 4 then
					if p69 == "Down" or p68 == 3 then
						v_u_12:ArmFlash(p67["Right Leg"], v_u_71, 0.4)
						return
					end
					if p68 == 1 or p68 == 2 then
						v_u_12:ArmFlash(p67["Left Arm"], v_u_71, 0.3)
						return
					end
					v_u_12:ArmFlash(p67["Right Arm"], v_u_71, 0.3)
				end
			end
		end,
		["Launch"] = function(p100, p101)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v102 = p100:FindFirstChild("HumanoidRootPart")
			if v102 then
				local v103 = v_u_7.Gojo.LapseBlue.Throw:Clone()
				v103.CFrame = CFrame.new(v102.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v103.Size = Vector3.new(0, 0, 5)
				v103.Parent = workspace.Effects
				v_u_4:Create(v103, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v103.Position + Vector3.new(0, p101, 0)
				}):Play()
				v_u_3:AddItem(v103, 0.3)
				if p101 < 0 then
					v_u_12:PlaySound(v_u_8.Megumi.Mahoraga.Throw.Break, v102, game.SoundService.Effect)
					v_u_12:DustBreak(v102.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_5:DistanceFromCharacter(v102.Position) < 20 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
				end
			end
		end,
		["M"] = function(p104, p105, p106)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v107 = p104:FindFirstChild("HumanoidRootPart")
			if v107 then
				if (workspace.CurrentCamera.CFrame.Position - v107.Position).Magnitude <= 200 then
					if p105 == 1 then
						v_u_12:PlaySound(v_u_8.Mahito.Variants.Transform1, v107, game.SoundService.Effect)
					elseif p105 == 2 then
						v_u_12:PlaySound(v_u_8.Mahito.Variants.Transform2, v107, game.SoundService.Effect)
					else
						v_u_12:PlaySound(v_u_8.Mahito.Variants.Transform3, v107, game.SoundService.Effect)
					end
					if v_u_5.Character == p104 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
					end
					for _, v108 in p106 do
						local v109 = v108.Size.X / 0.02
						local v110 = v108.Size.Y / 0.02
						local v111 = v108.Size.Z / 0.02
						for _ = 1, 12 do
							local v112 = v_u_7.Mahito.Morph:Clone()
							v112.Weld.Part0 = v108
							v112.Color = v108.Color
							v112.Material = v108.Material
							v112.Weld.C0 = CFrame.new(math.random(-v109, v109) / 100, math.random(-v110, v110) / 100, math.random(-v111, v111) / 100)
							v112.Parent = workspace.Effects
							local v113 = math.random(100, 200) / 100
							local v114 = math.random(10, 40) / 100
							v112.Size = Vector3.new(1, 1, 1) * v113
							v_u_4:Create(v112, TweenInfo.new(v114, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
							v_u_4:Create(v112.Weld, TweenInfo.new(v114, Enum.EasingStyle.Back, Enum.EasingDirection.InOut), {
								["C0"] = CFrame.new(0, 3, 0)
							}):Play()
							v_u_3:AddItem(v112, v114)
						end
					end
				end
			else
				return
			end
		end,
		["Chat2"] = function(p115)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_3
			local v116 = p115:FindFirstChild("Torso")
			if v116 then
				local v117 = v_u_7.Mahito.Worms.Dialogue2:Clone()
				v117.Parent = v116
				local v118 = v117.Chat1.Position
				v117.Chat1.Position = v118 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v117.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v118
				}):Play()
				v_u_4:Create(v117.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v117.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.5)
				local v119 = v117.Chat2.Position
				v117.Chat2.Position = v119 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v117.Chat2, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v119
				}):Play()
				v_u_4:Create(v117.Chat2, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v117.Chat2.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(0.3)
				v_u_12:PlaySound(v_u_8.Gojo.BlindsOff, v116, game.SoundService.Effect)
				task.wait(0.6)
				v_u_3:AddItem(v117, 0.6)
				for _, v120 in v117:GetDescendants() do
					if v120:IsA("Frame") then
						v_u_4:Create(v120, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = v120.Position - UDim2.new(0, 0, 0.2, 0),
							["BackgroundTransparency"] = 1
						}):Play()
					elseif v120:IsA("TextLabel") then
						v_u_4:Create(v120, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["Worms"] = function(p121)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_8, (ref) v_u_12, (ref) v_u_4, (ref) v_u_9
			local v_u_122 = p121:FindFirstChild("HumanoidRootPart")
			if v_u_122 then
				local v_u_123 = v_u_7.Mahito.Worms.WormLaunch:Clone()
				v_u_123.CFrame = v_u_122.CFrame + v_u_122.CFrame.LookVector * 3 - Vector3.new(0, 3, 0)
				v_u_123.Parent = workspace.Effects
				v_u_3:AddItem(v_u_123, 3)
				local v_u_124 = {
					Color3.fromRGB(170, 170, 127),
					Color3.fromRGB(255, 170, 255),
					Color3.fromRGB(85, 170, 127),
					Color3.fromRGB(85, 85, 127),
					Color3.fromRGB(85, 85, 0)
				}
				for v_u_125 = 1, 15 do
					task.delay(0.08 * (v_u_125 - 1), function()
						-- upvalues: (copy) v_u_122, (ref) v_u_7, (copy) v_u_124, (ref) v_u_3, (ref) v_u_8, (ref) v_u_12, (copy) v_u_125, (copy) v_u_123, (ref) v_u_4
						if (workspace.CurrentCamera.CFrame.Position - v_u_122.Position).Magnitude <= 300 then
							local v126 = v_u_7.Mahito.Worms.Worm:Clone()
							local v127 = v_u_122.CFrame
							local v128 = CFrame.Angles
							local v129 = math.random(70, 110)
							local v130 = math.rad(v129)
							local v131 = math.random(-20, 20)
							v126:SetPrimaryPartCFrame(v127 * v128(v130, math.rad(v131), 0) + Vector3.new(0, -3, 0) + v_u_122.CFrame.LookVector * 3)
							local v132 = v126["1"].CFrame.LookVector * math.random(120, 200)
							local v133 = v126["1"]
							local v134 = math.random(-200, 200)
							local v135 = math.random(-200, 200)
							local v136 = math.random
							v133.RotVelocity = Vector3.new(v134, v135, v136(-200, 200))
							local v137 = v_u_124[math.random(1, #v_u_124)]
							for _, v138 in v126:GetChildren() do
								v138.Color = v137
								v138.Velocity = v132
							end
							v126.Parent = workspace.Effects
							v_u_3:AddItem(v126, 3)
							for v139 = 2, 8 do
								local v140 = v126[tostring(v139)]
								local v141 = v139 - 1
								local v142 = v126[tostring(v141)]
								local v143 = Instance.new("Attachment", v140)
								local v144 = Instance.new("Attachment", v142)
								v143.Position = Vector3.new(0, 0, -1.5)
								v144.Position = Vector3.new(0, 0, 1.5)
								local v145 = Instance.new("BallSocketConstraint")
								v145.Attachment0 = v143
								v145.Attachment1 = v144
								v145.LimitsEnabled = true
								v145.Parent = v143
							end
							v_u_8.Mahito.Worms.Fire.PlaybackSpeed = math.random(140, 200) / 100
							v_u_12:PlaySound(v_u_8.Mahito.Worms.Fire, v126["1"], game.SoundService.Effect)
							if v_u_125 == 15 then
								for _, v146 in v_u_123:GetDescendants() do
									if v146:IsA("ParticleEmitter") then
										v146.Enabled = false
									end
								end
							end
							task.wait(0.4)
							for v147 = 1, 8 do
								local v148 = v126[tostring(v147)]
								v148.CanCollide = true
								v148.Anchored = false
							end
							task.wait(1.6)
							local v149 = TweenInfo.new(0.1111111111111111)
							local v150 = {
								["Size"] = Vector3.new(0, 0, 0)
							}
							for v151 = 8, 1, -1 do
								v_u_4:Create(v126[tostring(v151)], v149, v150):Play()
								task.wait(0.1111111111111111)
							end
						end
					end)
				end
				if (workspace.CurrentCamera.CFrame.Position - v_u_122.Position).Magnitude < 150 then
					local v_u_152 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.Snap)
					task.delay(1, function()
						-- upvalues: (copy) v_u_152
						v_u_152:StartFadeOut(1)
					end)
				end
			end
		end,
		["Spit"] = function(p153)
			-- upvalues: (ref) v_u_3, (ref) v_u_7, (ref) v_u_12, (ref) v_u_8, (ref) v_u_6
			local v_u_154 = p153:FindFirstChild("HumanoidRootPart")
			if v_u_154 then
				local v155 = Instance.new("Attachment", p153.Head)
				v155.Position = Vector3.new(0, -0.25, -0.6)
				v_u_3:AddItem(v155, 1)
				local v156 = v_u_7.Mahito.Worms.Spit:Clone()
				v156.Parent = v155
				v156:Emit(30)
				v_u_12:PlaySound(v_u_8.Mahito.Worms.Spit, v_u_154, game.SoundService.Effect)
				task.delay(0.4, function()
					-- upvalues: (ref) v_u_12, (ref) v_u_8, (copy) v_u_154
					v_u_12:PlaySound(v_u_8.Gojo.GrabBlinds, v_u_154, game.SoundService.Effect)
				end)
				local v157 = Instance.new("Model", p153)
				v157.Name = "BodyRepelStart"
				v_u_3:AddItem(v157, 1)
				for _, v158 in v_u_6.Utils.Mahito.BodyRepel.BodyRepelStart:GetChildren() do
					local v159 = v158:Clone()
					v159[v158.Name].Part0 = v_u_154
					v159.Parent = v157
					task.wait(0.03)
				end
			end
		end,
		["Chat"] = function(p160)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_3
			local v161 = p160:FindFirstChild("Torso")
			if v161 then
				v_u_12:PlaySound(v_u_8.Gojo.BlindsOff, v161, game.SoundService.Effect)
				local v162 = v_u_7.Mahito.Worms.Dialogue:Clone()
				v162.Parent = v161
				local v163 = v162.Chat1.Position
				v162.Chat1.Position = v163 - UDim2.new(0, 0, 0.15, 0)
				v_u_4:Create(v162.Chat1, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Position"] = v163
				}):Play()
				v_u_4:Create(v162.Chat1, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0
				}):Play()
				v_u_4:Create(v162.Chat1.Sub, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
				task.wait(1)
				v_u_3:AddItem(v162, 0.6)
				for _, v164 in v162:GetDescendants() do
					if v164:IsA("Frame") then
						v_u_4:Create(v164, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["Position"] = v164.Position - UDim2.new(0, 0, 0.2, 0),
							["BackgroundTransparency"] = 1
						}):Play()
					elseif v164:IsA("TextLabel") then
						v_u_4:Create(v164, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
							["TextTransparency"] = 1
						}):Play()
					end
				end
			end
		end,
		["Worms2"] = function(p165)
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4
			local v_u_166 = p165:FindFirstChild("HumanoidRootPart")
			if v_u_166 then
				local v167 = {}
				for _, v168 in p165:GetChildren() do
					if v168:IsA("BasePart") and (v168 ~= v_u_166 and v168.Transparency ~= 1) then
						local v169 = v168.Color
						table.insert(v167, v169)
					end
				end
				local v_u_170 = v_u_7.Mahito.Worms.FleshSpread:Clone()
				v_u_170.Color = ColorSequence.new(v167[math.random(1, #v167)])
				v_u_170.Parent = v_u_166
				v_u_3:AddItem(v_u_170, 2)
				task.delay(0.8, function()
					-- upvalues: (copy) v_u_170, (ref) v_u_12, (ref) v_u_8, (copy) v_u_166
					v_u_170.Enabled = false
					task.wait(0.4)
					v_u_12:PlaySound(v_u_8.Mahito.Worms.Whip, v_u_166, game.SoundService.Effect)
				end)
				v_u_12:PlaySound(v_u_8.Mahito.Worms.Morph, v_u_166, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v_u_166.Position).Magnitude < 150 then
					local v_u_171 = v_u_9.CurrentShaker:ShakeSustain(v_u_9.Presets.HeavyHit)
					task.delay(0.8, function()
						-- upvalues: (copy) v_u_171
						v_u_171:StartFadeOut(1)
					end)
				end
				local v_u_172 = TweenInfo.new(0.4, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out)
				for v173 = 1, 15 do
					if (workspace.CurrentCamera.CFrame.Position - v_u_166.Position).Magnitude > 300 then
						task.wait()
					else
						local v_u_174 = math.random(90, 130) / 100
						local v_u_175 = v_u_7.Mahito.Worms.Morph2:Clone()
						if v173 % 4 ~= 0 then
							v_u_175.Decal:Destroy()
						end
						v_u_175.Color = v167[math.random(1, #v167)]
						local v176 = v_u_175.Weld
						v176.C0 = v176.C0 * CFrame.Angles(math.random(0, 3.141592653589793), math.random(0, 3.141592653589793), math.random(0, 3.141592653589793))
						v_u_175.Weld.Part0 = v_u_166
						v_u_175.Parent = workspace.Effects
						v_u_3:AddItem(v_u_175, 2)
						v_u_4:Create(v_u_175.Weld, TweenInfo.new(v_u_174 + 0.4, Enum.EasingStyle.Exponential), {
							["C0"] = v_u_175.Weld.C0 * CFrame.Angles(math.random(0, 3.141592653589793), math.random(0, 3.141592653589793), math.random(0, 3.141592653589793))
						}):Play()
						task.spawn(function()
							-- upvalues: (copy) v_u_174, (ref) v_u_4, (copy) v_u_175, (copy) v_u_172
							local v177 = v_u_174 / 5
							v_u_4:Create(v_u_175, TweenInfo.new(v_u_174 * 0.66, Enum.EasingStyle.Elastic), {
								["Size"] = Vector3.new(1, 1, 1) * math.random(80, 140) / 10
							}):Play()
							task.delay(v_u_174 * 0.33, function()
								-- upvalues: (ref) v_u_4, (ref) v_u_175, (ref) v_u_174
								v_u_4:Create(v_u_175, TweenInfo.new(v_u_174 * 0.33, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
									["Size"] = Vector3.new(0, 0, 10)
								}):Play()
							end)
							local v178 = TweenInfo.new(v177, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
							for v179 = 1, 5 do
								local v180 = CFrame.new(math.random(-40, 40) / 3, math.random(-10, 50) / 5, math.random(-20, 20) / 3)
								local v181 = v179 / 6
								local v182 = {
									["C1"] = v180:Lerp(CFrame.new(), v181)
								}
								v_u_4:Create(v_u_175.Weld, v178, v182):Play()
								task.wait(v177)
							end
							v_u_4:Create(v_u_175, v_u_172, {
								["Size"] = Vector3.new(0, 0, 0)
							}):Play()
						end)
						task.wait()
					end
				end
			end
		end,
		["Dash"] = function(p183, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7, (ref) v_u_4
			local v_u_184 = p183:FindFirstChild("HumanoidRootPart")
			if v_u_184 then
				v_u_12:PlaySound(v_u_8.Itadori.Rush.Rush, v_u_184, game.SoundService.Effect)
				local v185 = v_u_6.Utils.Itadori.RushWind:Clone()
				v185.CFrame = v_u_184.CFrame
				v185.Parent = workspace.Effects
				v185.Dust:Emit(7)
				v185.Ring:Emit(7)
				v185.Dash1.Dash:Emit(1)
				v185.Dash2.Dash:Emit(1)
				v_u_3:AddItem(v185, 2)
				local v186 = v_u_7.Itadori.Shock:Clone()
				v186.CFrame = v_u_184.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v186.Parent = workspace.Effects
				v_u_4:Create(v186, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1
				}):Play()
				v_u_3:AddItem(v186, 0.2)
				task.delay(0.1, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_184, (ref) v_u_4, (ref) v_u_3
					local v187 = v_u_7.Itadori.Shock:Clone()
					v187.CFrame = v_u_184.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
					v187.Parent = workspace.Effects
					v_u_4:Create(v187, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_3:AddItem(v187, 0.2)
				end)
				v_u_12:PlaySound(v_u_8.Mahito.Transfig.Start, v_u_184, game.SoundService.Effect)
				local v188 = v_u_7.Mahito.EyeGlow:Clone()
				v188.Weld.Part0 = p183.Head
				v188.Parent = workspace.Effects
				v_u_3:AddItem(v188, 1)
				v188.Eye1.Glow:Emit(1)
				v188.Eye2.Glow:Emit(1)
				v188.Glow:Emit(1)
				task.wait(0.8)
				v188.Trail1.Trail.Enabled = false
				v188.Trail2.Trail.Enabled = false
			end
		end,
		["BlackFlashImpact"] = function(p189, p190)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7
			if p189:FindFirstChild("HumanoidRootPart") then
				local v191 = p190:FindFirstChild("HumanoidRootPart")
				if v191 then
					v_u_12:Flash(p190, Color3.new(1, 0, 0))
					v_u_12:PlaySound(v_u_8.Itadori.DivergentFist.BlackFlashHit, v191, game.SoundService.Effect)
					if v_u_5.Character == p189 or v_u_5.Character == p190 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						local v192 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v192.Parent = game.Lighting
						task.wait(0.04)
						v192.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v192.Brightness = 200
						v192.Contrast = -1000
						task.wait(0.04)
						v192:Destroy()
					end
				end
			else
				return
			end
		end,
		["BlackFlashHit"] = function(p193, p194)
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v195 = p193:FindFirstChild("HumanoidRootPart")
			if v195 then
				local v196 = p194:FindFirstChild("HumanoidRootPart")
				if v196 then
					local v197 = v_u_7.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					v197.CFrame = v195.CFrame * CFrame.new(2, 1, -5)
					v197.Parent = workspace.Effects
					v197.Wind:Emit(20)
					v197.Sparks:Emit(20)
					v197.Flare:Emit(20)
					v197.Lightning:Emit(25)
					v197.Back1.Back:Emit(1)
					v197.Back2.Back:Emit(1)
					v_u_4:Create(v197.Back1, TweenInfo.new(2), {
						["CFrame"] = v197.Back1.CFrame - v197.Back1.CFrame.LookVector * 20
					}):Play()
					v_u_4:Create(v197.Back2, TweenInfo.new(2), {
						["CFrame"] = v197.Back2.CFrame - v197.Back2.CFrame.LookVector * 20
					}):Play()
					v_u_4:Create(v197.PointLight, TweenInfo.new(1), {
						["Brightness"] = 0
					}):Play()
					v_u_3:AddItem(v197, 3)
					v_u_12:Flash(p194, Color3.new(1, 0, 0), 2)
					v_u_12:PlaySound(v_u_8.Mahito.BlackFlash, v196, game.SoundService.Effect)
					if v_u_5.Character == p193 or v_u_5.Character == p194 then
						v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
						local v198 = v_u_7.Itadori.DivergentFist.BlackFlashCC:Clone()
						v198.Parent = game.Lighting
						task.wait(0.04)
						v198.Brightness = 200
						v198.Contrast = -1000
						task.wait(0.04)
						v198.TintColor = Color3.new(1, 1, 1)
						task.wait(0.04)
						v198.Brightness = -200
						v198.Contrast = 1000
						task.wait(0.04)
						v198:Destroy()
					end
				end
			else
				return
			end
		end,
		["Eat"] = function(p199)
			-- upvalues: (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
			local v200 = p199:FindFirstChild("HumanoidRootPart")
			if v200 then
				v_u_12:Flash(p199, Color3.new(0.333333, 0.333333, 0.498039), 1)
				v_u_12:PlaySound(v_u_8.Mahito.Eat, v200, game.SoundService.Effect)
				if v_u_5.Character == p199 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p202, ...)
		-- upvalues: (copy) v_u_201
		local v203 = v_u_201[p202]
		if v203 then
			v203(...)
		end
	end)
	v_u_10.Hitbox:Connect(function(p204, p205, p206, p207)
		-- upvalues: (ref) v_u_11, (ref) v_u_4
		local v208 = p205.HumanoidRootPart
		if not v208 then
			return
		end
		if p207 then
			while true do
				local v209 = v_u_11:SphereHitbox(p205, CFrame.new(0, 0, 0), 12)
				if #v209 > 0 then
					p206:FireServer(v209, v208.CFrame)
				end
				task.wait(0.05)
				if not p204.Parent then
					goto l8
				end
			end
		else
			local v210 = nil
			while true do
				local v211 = v_u_11:SphereHitbox(p205, CFrame.new(0, 0, -4), 8)
				for _, v212 in v211 do
					local v213 = v212:FindFirstChild("Info")
					if v213 then
						local v214 = v213:FindFirstChild("Knockback")
						if not v214 or v214.Value ~= false then
							v210 = v211
							break
						end
					end
				end
				if v210 then
					local v215 = p204:FindFirstChildWhichIsA("NumberValue")
					if v215 then
						v_u_4:Create(v215, TweenInfo.new(0.1), {
							["Value"] = 0
						}):Play()
					end
					break
				end
				task.wait(0.05)
				if not p204.Parent then
					break
				end
			end
			p206:FireServer(v210, v208.CFrame)
			::l8::
			return
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
	v_u_10 = v_u_1.GetService("MahitoService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
	v_u_13 = v_u_1.GetController("ToolController")
end
return v14