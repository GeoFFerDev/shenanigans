-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("TweenService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
task.wait()
local v4 = {
	Vector3.new(0, 0, 4),
	Vector3.new(4, 0, 0),
	Vector3.new(0, 0, -4),
	Vector3.new(-4, 0, 0)
}
local v_u_5 = {}
for v6 = 1, 4 do
	if script.Parent:FindFirstChild("Blood" .. v6) then
		v_u_5[v6] = v1:Create(script.Parent["Blood" .. v6], TweenInfo.new(2, Enum.EasingStyle.Exponential), {
			["Position"] = v4[v6]
		})
		v_u_5[v6]:Play()
	end
end
script.Parent:WaitForChild("Smear").Enabled = false
function quadraticBezier(p7, p8, p9, p10)
	return (1 - p7) ^ 2 * p8 + 2 * (1 - p7) * p7 * p9 + p7 ^ 2 * p10
end
local v_u_11 = CFrame.new(0, 3, 0) * CFrame.Angles(-0.3490658503988659, 0, 0)
local v_u_12 = 0
v_u_2.Stepped:Connect(function(_, p13)
	-- upvalues: (ref) v_u_12, (copy) v_u_11
	v_u_12 = v_u_12 + 1 * p13
	local v14 = script.Parent.Weld
	local v15 = v14.C1
	local v16 = CFrame.Angles
	local v17 = 160 * p13
	v14.C1 = v15 * v16(0, math.rad(v17), 0)
	local v18 = script.Parent.Weld
	local v19 = v_u_12
	local v20 = v_u_12
	local v21 = v_u_11 * CFrame.Angles(math.sin(v19) * 10, 0, math.sin(v20) * 10)
	local v22 = v_u_12
	local v23 = math.sin(v22) - 1
	v18.C0 = v21 + Vector3.new(0, v23, 0)
end)
local v_u_24 = script.Parent.Parent.Parent
local v_u_25 = v_u_24.HumanoidRootPart
if script.Parent:GetAttribute("Charge") < 4 then
	for v26 = 4, script.Parent:GetAttribute("Charge") + 1, -1 do
		if script.Parent:FindFirstChild("Blood" .. v26) then
			script.Parent["Blood" .. v26]:Destroy()
		end
	end
end
script.Parent:GetAttributeChangedSignal("Charge"):Connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_25, (copy) v_u_2, (copy) v_u_24
	local v_u_27 = script.Parent["Blood" .. script.Parent:GetAttribute("Charge") + 1]
	v_u_3:AddItem(v_u_27, 1)
	if v_u_5[script.Parent:GetAttribute("Charge") + 1] then
		v_u_5[script.Parent:GetAttribute("Charge") + 1]:Cancel()
		v_u_5[script.Parent:GetAttribute("Charge") + 1]:Destroy()
	end
	task.delay(0.6, function()
		-- upvalues: (copy) v_u_27
		v_u_27.Trail.Enabled = false
		v_u_27.ParticleEmitter:Destroy()
		local v28 = game.ReplicatedStorage.Utils.Choso.PiercingBlood.Start.Burst:Clone()
		v28.Parent = v_u_27
		v28:Emit(4)
	end)
	local v_u_29 = v_u_27.WorldPosition
	v_u_27.Parent = v_u_25
	v_u_27.WorldPosition = v_u_29
	local v_u_30 = CFrame.new(math.random(1, 2) == 1 and -8 or 8, math.random(4, 7), -4)
	local v_u_31 = tick()
	local v_u_32 = nil
	v_u_32 = v_u_2.Stepped:Connect(function()
		-- upvalues: (copy) v_u_27, (ref) v_u_32, (copy) v_u_31, (ref) v_u_24, (ref) v_u_25, (copy) v_u_30, (copy) v_u_29
		if v_u_27.Parent then
			local v33 = (tick() - v_u_31) / 0.6
			local v34 = v_u_24["Right Arm"].Position - v_u_24["Right Arm"].CFrame.UpVector * 1
			local v35 = (v_u_25.CFrame * v_u_30).Position
			v_u_27.WorldPosition = quadraticBezier(v33, v_u_29, v35, v34)
		else
			v_u_32:Disconnect()
		end
	end)
end)