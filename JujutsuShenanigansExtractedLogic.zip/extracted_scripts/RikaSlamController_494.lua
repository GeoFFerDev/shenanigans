-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
game:GetService("TweenService")
local _ = game.Players.LocalPlayer
local v3 = game.ReplicatedStorage
local _ = v3.Animations
local v_u_4 = v3.Utils
local v_u_5 = v3.Sounds
require(v3.Modules.CameraShaker)
require(v3.Modules.BloodyZee)
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v9 = v_u_1.CreateController({
	["Name"] = "RikaSlamController"
})
function v9.KnitStart(_)
	-- upvalues: (ref) v_u_7, (copy) v_u_5, (copy) v_u_4, (copy) v_u_2, (ref) v_u_8
	local v_u_19 = {
		["StartSound"] = function(p10)
			-- upvalues: (ref) v_u_7, (ref) v_u_5
			if p10 and p10.Parent then
				v_u_7:PlaySound(v_u_5.Yuta.Rika.SlamTry, p10, game.SoundService.Effect)
			end
		end,
		["GrabLand"] = function(p11, p12)
			-- upvalues: (ref) v_u_7, (ref) v_u_5
			if p11 and p11.Parent then
				local v_u_13 = v_u_7:PlaySound(v_u_5.Yuta.Rika.SlamLand, p11, game.SoundService.Effect)
				p12.AncestryChanged:Once(function()
					-- upvalues: (copy) v_u_13
					v_u_13:Destroy()
				end)
			end
		end,
		["Ring"] = function(p14, p15)
			-- upvalues: (ref) v_u_4, (ref) v_u_2
			local v16 = p14:FindFirstChild("Torso")
			local v17 = p14:FindFirstChild("RootPart")
			if v16 and v17 then
				local v18 = v_u_4.Yuta.RingSwing:Clone()
				v18.CFrame = CFrame.lookAlong(v16.Position, v17.CFrame.LookVector)
				v18.Parent = workspace.Effects
				v_u_2:AddItem(v18, 0.6)
				v18[("%*"):format(p15)].Ring:Emit(8)
			end
		end
	}
	v_u_8.Effects:Connect(function(p20, ...)
		-- upvalues: (copy) v_u_19
		local v21 = v_u_19[p20]
		if v21 then
			v21(...)
		end
	end)
end
function v9.KnitInit(_)
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (ref) v_u_6, (ref) v_u_7
	v_u_8 = v_u_1.GetService("RikaSlamService")
	v_u_6 = v_u_1.GetController("HitboxController")
	v_u_7 = v_u_1.GetController("FXController")
end
return v9