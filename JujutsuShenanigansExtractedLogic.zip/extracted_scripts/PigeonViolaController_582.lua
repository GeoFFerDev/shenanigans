-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Debris")
game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v9 = require(v5.Modules.SraikoVFX)
local _ = v9.Enabled
local _ = v9.Emit
local _ = v9.EmitMesh
local v_u_10 = v_u_6.Mechamaru.PigeonViolaVFX
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v14 = v_u_1.CreateController({
	["Name"] = "PigeonViolaController"
})
function v14.KnitStart(_)
	-- upvalues: (copy) v_u_10, (copy) v_u_3, (ref) v_u_13, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_2, (copy) v_u_6, (ref) v_u_11
	local v_u_39 = {
		["Start"] = function(p15)
			-- upvalues: (ref) v_u_10, (ref) v_u_3, (ref) v_u_13, (ref) v_u_7
			local v16 = p15:FindFirstChild("HumanoidRootPart")
			if v16 then
				local function v20(p17)
					-- upvalues: (ref) v_u_10, (ref) v_u_3
					if p17 then
						local v_u_18 = v_u_10.Hands:Clone()
						v_u_18.Parent = p17
						v_u_3:AddItem(v_u_18, 2)
						task.delay(0.5, function()
							-- upvalues: (copy) v_u_18
							for _, v19 in v_u_18:QueryDescendants("ParticleEmitter") do
								v19.Enabled = false
							end
						end)
					end
				end
				v20(p15:FindFirstChild("Right Arm"))
				v20(p15:FindFirstChild("Left Arm"))
				v_u_13:PlaySound(v_u_7.Mechamaru.PigeonViola.Start, v16, game.SoundService.Effect)
			end
		end,
		["Spawn"] = function(p21)
			-- upvalues: (ref) v_u_10, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v22 = p21:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = v_u_10.Spawn:Clone()
				v23.Parent = v22
				v_u_3:AddItem(v23, 2)
				for _, v24 in v23:QueryDescendants("ParticleEmitter") do
					v24:Emit(v24:GetAttribute("EmitCount"))
				end
				if v_u_4.Character == p21 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
				task.wait(0.1)
				local v25 = v_u_10.Stars:Clone()
				v25.Weld.Part0 = v22
				v25.Parent = workspace.Effects
				v_u_3:AddItem(v25, 2)
				task.wait(0.2)
				for _, v26 in v25:QueryDescendants("ParticleEmitter") do
					v26.Enabled = false
				end
			end
		end,
		["Shoot"] = function(p27)
			-- upvalues: (ref) v_u_4, (ref) v_u_8
			if p27:FindFirstChild("HumanoidRootPart") then
				if v_u_4.Character == p27 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["Interp"] = function(p_u_28)
			-- upvalues: (ref) v_u_2
			local v_u_29 = p_u_28.CFrame
			local v_u_30 = tick()
			local v_u_31 = p_u_28:GetPropertyChangedSignal("Position"):Connect(function()
				-- upvalues: (ref) v_u_29, (copy) p_u_28, (ref) v_u_30
				v_u_29 = p_u_28.CFrame
				v_u_30 = tick()
			end)
			local v_u_32 = nil
			v_u_32 = v_u_2.Stepped:Connect(function()
				-- upvalues: (copy) p_u_28, (ref) v_u_32, (copy) v_u_31, (ref) v_u_29, (ref) v_u_30
				if p_u_28.Parent then
					workspace:BulkMoveTo({ p_u_28 }, { v_u_29 + v_u_29.LookVector * (p_u_28:GetAttribute("Speed") * (tick() - v_u_30)) }, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_32:Disconnect()
					v_u_31:Disconnect()
				end
			end)
		end,
		["Hit"] = function(p33, p34)
			-- upvalues: (ref) v_u_13, (ref) v_u_7
			local v35 = p33:FindFirstChild("HumanoidRootPart")
			if v35 then
				v_u_13:Flash(p33, p34)
				v_u_13:PlaySound(v_u_7.Mechamaru.PigeonViola:FindFirstChild("Hit" .. math.random(1, 2)), v35, game.SoundService.Effect)
			end
		end,
		["Explode"] = function(p36, p37)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8
			local v38 = v_u_6.Mahito.CrushingRushdown.DrillImpact:Clone()
			v38.Position = p37.Position
			v38.Parent = workspace.Effects
			v_u_3:AddItem(v38, 1)
			v38.Sparks.Brightness = 45
			v38.Sparks.LightEmission = 0
			v38.Sparks.Color = ColorSequence.new(p37.Color)
			v38.Sparks:Emit(50)
			v38.Wind:Emit(7)
			v38.Wind2:Emit(7)
			if v_u_4.Character == p36 or v_u_4:DistanceFromCharacter(p37.Position) < 30 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
			end
		end
	}
	v_u_11.Effects:Connect(function(p40, ...)
		-- upvalues: (copy) v_u_39
		local v41 = v_u_39[p40]
		if v41 then
			v41(...)
		end
	end)
end
function v14.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13
	v_u_11 = v_u_1.GetService("PigeonViolaService")
	v_u_12 = v_u_1.GetController("HitboxController")
	v_u_13 = v_u_1.GetController("FXController")
end
return v14