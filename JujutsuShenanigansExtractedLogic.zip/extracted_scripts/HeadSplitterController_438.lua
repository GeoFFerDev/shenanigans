-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
require(v_u_5.Modules.BloodyZee)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "HeadSplitterController"
})
function v12.KnitStart(_)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_3, (copy) v_u_6, (ref) v_u_11, (copy) v_u_7, (copy) v_u_5, (copy) v_u_8, (ref) v_u_9
	local v_u_28 = {
		["Weave"] = function(p_u_13, p_u_14)
			-- upvalues: (ref) v_u_4, (ref) v_u_2, (ref) v_u_3, (ref) v_u_6, (ref) v_u_11, (ref) v_u_7, (ref) v_u_5
			local v15 = p_u_13:FindFirstChild("HumanoidRootPart")
			if v15 then
				if v_u_4.Character == p_u_13 or v_u_4.Character == p_u_14 then
					local v_u_16 = Instance.new("ColorCorrectionEffect", game.Lighting)
					v_u_2:AddItem(v_u_16, 2)
					v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["FieldOfView"] = 50
					}):Play()
					v_u_3:Create(v_u_16, TweenInfo.new(1.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
						["Saturation"] = -0.5
					}):Play()
					task.delay(1.5, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_16, (ref) v_u_6, (copy) p_u_14, (ref) v_u_2
						v_u_3:Create(workspace.CurrentCamera, TweenInfo.new(1, Enum.EasingStyle.Exponential, Enum.EasingDirection.InOut), {
							["FieldOfView"] = 70
						}):Play()
						v_u_3:Create(v_u_16, TweenInfo.new(0.5, Enum.EasingStyle.Exponential, Enum.EasingDirection.In), {
							["Saturation"] = 0
						}):Play()
						task.wait(0.6)
						local v17 = v_u_6.Mahito.WideSPStrike.ScreenSlash:Clone()
						v17.Base.Rotation = 90
						v17.Parent = p_u_14.Head
						v_u_3:Create(v17.Base.Base2, TweenInfo.new(0.3, Enum.EasingStyle.Exponential), {
							["BackgroundTransparency"] = 1
						}):Play()
						v_u_3:Create(v17.Base.Frame, TweenInfo.new(0.1), {
							["BackgroundTransparency"] = 1
						}):Play()
						v_u_2:AddItem(v17, 0.3)
					end)
				end
				task.spawn(function()
					-- upvalues: (ref) v_u_6, (ref) v_u_2, (copy) p_u_13, (ref) v_u_3
					local v18 = TweenInfo.new(0.5)
					for _ = 1, 30 do
						local v19 = v_u_6.Damage.HitGlow:Clone()
						v_u_2:AddItem(v19, 0.5)
						v19.Parent = workspace.Effects
						for _, v20 in v19:GetChildren() do
							v20.Color = Color3.fromRGB(170, 170, 255)
							v20.Anchored = true
							v20.CFrame = p_u_13[v20.Name].CFrame
							v_u_3:Create(v20, v18, {
								["Transparency"] = 1
							}):Play()
						end
						task.wait(0.075)
					end
				end)
				local v21 = v_u_6.Gojo.Teleport:Clone()
				v21.CFrame = v15.CFrame
				v21.Parent = workspace.Effects
				v_u_2:AddItem(v21, 1.1)
				v21.Floor.Dust:Emit(30)
				v_u_11:Flash(p_u_13, Color3.fromRGB(170, 170, 255), 2)
				v_u_11:PlaySound(v_u_7.Mahito.HeadSplit.Weave, v15, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Mahito.DrillSplit.Leap, v15, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Mahito.HeadSplit.Weave2, v15, game.SoundService.Effect)
				v_u_11:PlaySound(v_u_7.Mahito.HeadSplit.Bass, v15, game.SoundService.Effect)
				task.delay(0.7, function()
					-- upvalues: (ref) v_u_11, (ref) v_u_7, (copy) p_u_14
					v_u_11:PlaySound(v_u_7.Mahito.HeadSplit.What, p_u_14.HumanoidRootPart, game.SoundService.Voice)
				end)
				local v_u_22 = v_u_5.Utils.Itadori.EyeTrails:Clone()
				v_u_22.Weld.Part0 = p_u_13.Head
				v_u_22.Parent = workspace.Effects
				v_u_22.Trail1.Trail.Lifetime = 0.7
				v_u_22.Trail2.Trail.Lifetime = 0.7
				v_u_22.Glow:Emit(1)
				task.delay(2.5, function()
					-- upvalues: (copy) v_u_22, (ref) v_u_2
					v_u_22.Trail1.Trail.Enabled = false
					v_u_22.Trail2.Trail.Enabled = false
					v_u_22.Eye1.Glow.Enabled = false
					v_u_22.Eye2.Glow.Enabled = false
					v_u_22.Sparks:Emit(15)
					v_u_2:AddItem(v_u_22, 0.7)
				end)
				task.wait(1.5)
				local v23 = v_u_6.Mahito.Sparks:Clone()
				v23.Parent = p_u_13.Torso
				v_u_3:Create(v23, TweenInfo.new(0.5), {
					["Rate"] = 100
				}):Play()
				task.wait(0.5)
				v23:Destroy()
				v_u_11:PlaySound(v_u_7.Mahito.HeadSplit.Slash, v15, game.SoundService.Effect)
			end
		end,
		["Hit"] = function(p24, p25)
			-- upvalues: (ref) v_u_11, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6
			local v26 = p24:FindFirstChild("HumanoidRootPart")
			if v26 then
				v_u_11:Flash(p24, Color3.new(1, 1, 1))
				v_u_11:PlaySound(v_u_7.Itadori.Dismantle.Slash, v26, game.SoundService.Effect)
				if (workspace.CurrentCamera.CFrame.Position - v26.Position).Magnitude < 150 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
					local v27 = v_u_6.Itadori.DivergentFist.BlackFlashCC:Clone()
					v27.TintColor = Color3.new(1, 1, 1)
					v27.Parent = game.Lighting
					task.wait(0.04)
					v27.Brightness = 200
					v27.Contrast = -1000
					task.wait(0.04)
					v27:Destroy()
				end
				if p25 then
					v_u_11:PlaySound(v_u_7.Mahito.DrillSplit.Drill, v26, game.SoundService.Effect)
					v_u_11:Bleed(p24)
				end
			end
		end
	}
	v_u_9.Effects:Connect(function(p29, ...)
		-- upvalues: (copy) v_u_28
		local v30 = v_u_28[p29]
		if v30 then
			v30(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10, (ref) v_u_11
	v_u_9 = v_u_1.GetService("HeadSplitterService")
	v_u_10 = v_u_1.GetController("HitboxController")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12