-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

return {
	["Btn"] = 3,
	["SortOrder"] = 1,
	["Val"] = "VolFX",
	["Desc"] = "Change the volume for sound effects",
	["Max"] = 2,
	["Callback"] = function(p1)
		game.SoundService.Effect.Volume = p1
	end
}