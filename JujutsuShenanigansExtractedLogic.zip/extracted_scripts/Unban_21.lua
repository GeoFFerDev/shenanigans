-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Name"] = "unban",
	["Description"] = "Returns the player\'s ability to join the game",
	["Group"] = {
		"Owner",
		"Developer",
		"HeadMod",
		"HeadMod",
		"Mod"
	},
	["Args"] = {
		{
			["Type"] = "username",
			["Name"] = "Username"
		}
	}
}
return v1