-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
require(v5.Modules.BloodyZee)
local v9 = v_u_1.CreateController({
	["Name"] = "StaffExtendController"
})
local v_u_10 = nil
local v_u_11 = nil
local _ = workspace.CurrentCamera
function v9.KnitStart(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (ref) v_u_11
	local v_u_31 = {
		["Start"] = function(p12)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v13 = p12:FindFirstChild("HumanoidRootPart")
			if v13 then
				v_u_10:PlaySound(v_u_7.Goku.StaffExtend.Swing, v13, game.SoundService.Effect)
			end
		end,
		["Swing"] = function(p14)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			local v15 = p14:FindFirstChild("HumanoidRootPart")
			if v15 then
				local v16 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v16.Transparency = 0.75
				v16.CFrame = v15.CFrame * CFrame.new(-0.15, -0.25, -1)
				v16.Size = Vector3.new(2, 2, 0)
				v16.Parent = workspace.Effects
				v_u_3:Create(v16, TweenInfo.new(0.2), {
					["Position"] = v16.Position + v15.CFrame.LookVector * 7,
					["Size"] = Vector3.new(0, 0, 5),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v16, 0.2)
				local v17 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v17.Transparency = 0.65
				v17.CFrame = v15.CFrame * CFrame.new(-0.15, -0.25, -8)
				v17.Size = Vector3.new(0, 0, 2.5)
				v17.Parent = workspace.Effects
				v_u_3:Create(v17, TweenInfo.new(0.15), {
					["Position"] = v17.Position + v15.CFrame.LookVector * -2.5,
					["Size"] = Vector3.new(2.25, 2.25, 0.4),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v17, 0.15)
			end
		end,
		["Hit"] = function(p18, p19)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v20 = p19:FindFirstChild("HumanoidRootPart")
			if v20 then
				v_u_10:Flash(p19, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Goku.StaffExtend.Hit, v20, game.SoundService.Effect)
				if v_u_4.Character == p18 or v_u_4.Character == p19 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.Snap)
				end
			end
		end,
		["UpriseExtend"] = function(p21)
			-- upvalues: (ref) v_u_3
			local v22 = p21:FindFirstChild("HumanoidRootPart")
			if v22 then
				local v23 = workspace:Raycast((v22.CFrame * CFrame.new(-0.219, 0, -1.245)).Position, Vector3.new(0, -75, 0), _G.MapParams)
				local v24 = v23 and p21.SetAssets:FindFirstChild("GokuStick")
				if v24 then
					v24.Uprise.Uprise.Enabled = false
					task.wait()
					v24.Uprise.Anchored = true
					if v23.Distance < 10 then
						v24.Uprise.CFrame = CFrame.new(v23.Position)
						return
					end
					v_u_3:Create(v24.Uprise, TweenInfo.new(0.2), {
						["CFrame"] = CFrame.new(v23.Position)
					}):Play()
				end
			end
		end,
		["UpriseEnd"] = function(p25)
			if p25:FindFirstChild("HumanoidRootPart") then
				local v26 = p25.SetAssets:FindFirstChild("GokuStick")
				if v26 then
					v26.Uprise.Anchored = false
					task.wait()
					v26.Uprise.Uprise.Enabled = true
				end
			end
		end,
		["Launch"] = function(p27, p28)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v29 = p27:FindFirstChild("HumanoidRootPart")
			if v29 then
				local v30 = v_u_6.Gojo.LapseBlue.Throw:Clone()
				v30.CFrame = CFrame.new(v29.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
				v30.Size = Vector3.new(0, 0, 5)
				v30.Parent = workspace.Effects
				v_u_3:Create(v30, TweenInfo.new(0.3), {
					["Size"] = Vector3.new(8, 8, 0),
					["Transparency"] = 1,
					["Position"] = v30.Position + Vector3.new(0, p28, 0)
				}):Play()
				v_u_2:AddItem(v30, 0.3)
				if p28 < 0 then
					v_u_10:PlaySound(v_u_7.Megumi.Mahoraga.Throw.Break, v29, game.SoundService.Effect)
					v_u_10:DustBreak(v29.Position + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), 6, 15, 0.4, 1)
					if v_u_4:DistanceFromCharacter(v29.Position) < 20 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
					end
				end
			end
		end
	}
	v_u_11.Effects:Connect(function(p32, ...)
		-- upvalues: (copy) v_u_31
		local v33 = v_u_31[p32]
		if v33 then
			v33(...)
		end
	end)
end
function v9.KnitInit(_)
	-- upvalues: (ref) v_u_11, (copy) v_u_1, (ref) v_u_10
	v_u_11 = v_u_1.GetService("StaffExtendService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v9