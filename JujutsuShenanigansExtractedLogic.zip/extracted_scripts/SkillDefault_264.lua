-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["LineItems"] = {
		["WAIT"] = {
			{ "TIME", 2, 1 }
		},
		["SKILL"] = {
			{ "MOVE", 3, "Divergent Fist" },
			{ "SPEED", 2, 1 },
			{ "CANCEL LAST", 1, false },
			{ "ENABLE VARIANTS", 1, true },
			{ "HOLD FOR", 2, 0 },
			{ "START", 2, 0 }
		},
		["SPECIAL"] = {
			{ "SPEC", 3, "Limitless" },
			{ "SPEED", 2, 1 },
			{ "CANCEL LAST", 1, false },
			{ "ENABLE VARIANTS", 1, true }
		},
		["ANIM"] = {
			{
				"PREVIEW",
				4,
				{ 0, 15 }
			},
			{
				"ANIM_USE",
				3,
				{ 1, 1 }
			},
			{ "LOOPED", 1, false },
			{ "SPEED", 2, 1 },
			{ "FADE IN", 2, 0.1 },
			{ "FADE OUT", 2, 0 },
			{ "LAST HIT", 2, -1 }
		},
		["SFX"] = {
			{ "ID", 2, 12222253 },
			{ "SPEED", 2, 1 },
			{ "VOLUME", 2, 0.5 },
			{ "START", 2, 0 },
			{ "END", 2, 500 },
			{ "CANCEL", 1, false },
			{ "GLOBAL", 1, false },
			{ "PROJECTILE TAG", 3, nil }
		},
		["VELO"] = {
			{ "FORCE", 5, "0, 0, 0" },
			{ "TIME", 2, 0 },
			{ "FADE", 1, false },
			{ "TRACK", 1, false },
			{ "LAST HIT", 2, -1 },
			{ "RAGDOLL", 2, 0 },
			{ "TRUE RAGDOLL", 1, false },
			{ "RELATIVE FROM BRANCH", 1, false }
		},
		["CONNECT"] = {
			{ "SIGNAL", 3, "Nothing" },
			{ "TIME", 2, 0.1 },
			{ "RANGE", 2, (1 / 0) }
		},
		["HITBOX"] = {
			{
				"PREVIEW",
				7,
				{ 0, 15 }
			},
			{ "POSITION", 5, "0, 0, 4" },
			{ "ROTATION", 5, "0, 0, 0" },
			{ "SIZE", 5, "6, 6, 6" },
			{ "STUN", 2, 1 },
			{ "STUN ANIM", 1, false },
			{ "DAMAGE", 2, 1 },
			{ "DEBREE", 2, 0 },
			{ "ATTACK TYPE", 3, "Melee" },
			{ "BLOCKABLE", 1, true },
			{ "360 BLOCK", 1, false },
			{ "CANCEL ENEMY", 1, true },
			{ "CLEAR KNOCKBACK", 1, false },
			{ "CAN KILL", 1, true },
			{ "HIT RAGDOLL", 1, false },
			{ "HIT USER", 1, false },
			{ "SINGLE TARGET", 1, true },
			{ "BRANCH", 3, nil },
			{ "BRANCH TARGET", 3, nil },
			{ "BRANCH FINISHER", 3, nil },
			{ "PROJECTILE TAG", 3, nil }
		},
		["ULTGIB"] = {
			{ "AMOUNT", 2, 5 }
		},
		["HPGIB"] = {
			{ "AMOUNT", 2, 5 }
		},
		["EVGIB"] = {
			{ "AMOUNT", 2, 5 }
		},
		["HITCNCL"] = {
			{ "TIME", 2, 1 },
			{ "FLIP", 1, false },
			{ "ENDLAG", 2, 1 },
			{ "BRANCH", 3, nil }
		},
		["BRANCH"] = {
			{ "BRANCH", 3, nil },
			{ "RANDOM", 8, nil },
			{ "LAST HIT", 2, -1 }
		},
		["VISUAL"] = {
			{ "EFFECT", 3, "Slash" },
			{ "AMOUNT", 2, 1 },
			{ "TEXTURE", 2, 0 },
			{ "COLOR", 6, "255, 255, 255" },
			{ "ALT COLOR", 6, "255, 255, 255" },
			{ "OPACITY", 2, 0 },
			{ "ALT OPACITY", 2, 0 },
			{ "POSITION", 5, "0, 0, 0" },
			{ "ALT POSITION", 5, "0, 0, 0" },
			{ "ROTATION", 5, "0, 0, 0" },
			{ "ALT ROTATION", 5, "0, 0, 0" },
			{ "SIZE", 2, 1 },
			{ "ALT SIZE", 2, 1 },
			{ "TIME", 2, 1 },
			{ "LAST HIT", 2, -1 },
			{ "BODY PART", 3, "HumanoidRootPart" },
			{ "VISUAL TAG", 3, nil },
			{ "PROJECTILE TAG", 3, nil },
			{ "RUN ON SERVER", 1, false },
			{ "CANCEL ON INTERRUPT", 1, false },
			{ "RELATIVE FROM BRANCH", 1, false },
			{ "EASING STYLE", 3, "Linear" },
			{ "EASING DIRECTION", 3, "In" }
		},
		["LOOP"] = {
			{ "LOOP BACK", 2, 1 },
			{ "LOOP AMOUNT", 2, 3 },
			{ "HOLD", 1, false }
		},
		["GRAB"] = {
			{ "BODY PART", 3, "HumanoidRootPart" },
			{ "BODY PART2", 3, "HumanoidRootPart" },
			{ "POSITION", 5, "0, 0, 0" },
			{ "ROTATION", 5, "0, 0, 0" },
			{ "TIME", 2, 1 },
			{ "LAST HIT", 2, 1 }
		},
		["PROJECTILE"] = {
			{ "PROJECTILE TAG", 3, nil },
			{ "POSITION", 5, "0, 0, 0" },
			{ "ROTATION", 5, "0, 0, 0" },
			{ "SIZE", 5, "6, 6, 6" },
			{ "SPEED", 2, 1 },
			{ "TIME", 2, 1 },
			{ "STUN", 2, 1 },
			{ "STUN ANIM", 1, false },
			{ "DAMAGE", 2, 1 },
			{ "DEBREE", 2, 0 },
			{ "ATTACK TYPE", 3, "Melee" },
			{ "BLOCKABLE", 1, true },
			{ "360 BLOCK", 1, false },
			{ "CANCEL ENEMY", 1, true },
			{ "CLEAR KNOCKBACK", 1, false },
			{ "CAN KILL", 1, true },
			{ "HIT RAGDOLL", 1, false },
			{ "HIT USER", 1, false },
			{ "AIM LAST HIT", 2, -1 },
			{ "CONTINUE", 1, false },
			{ "BRANCH", 3, nil },
			{ "BRANCH TARGET", 3, nil },
			{ "BRANCH COLLIDED", 3, nil },
			{ "FILTER INTERVAL", 2, 1 }
		},
		["COUNTER"] = {
			{ "ATTACK TYPE2", 3, "Melee" },
			{ "TIME", 2, 1 },
			{ "STUN", 2, 1 },
			{ "CANCEL ENEMY", 1, true },
			{ "BRANCH", 3, nil },
			{ "BRANCH TARGET", 3, nil },
			{ "REMOVE ON HIT", 1, true }
		},
		["TAG"] = {
			{ "TAG", 3, nil },
			{ "VALUE", 3, nil },
			{ "TIME", 2, 1 },
			{ "CHECK", 1, false },
			{ "ADD/REMOVE", 1, true },
			{ "SET", 1, true },
			{ "BRANCH", 3, nil },
			{ "LAST HIT", 2, -1 }
		},
		["STATE"] = {
			{ "STATE", 3, "Stun" },
			{ "VALUE", 2, 1 },
			{ "TIME", 2, 1 },
			{ "CANCEL ON END", 1, false },
			{ "DISABLE BURST", 1, false },
			{ "LAST HIT", 2, -1 }
		},
		["AIR"] = {
			{ "FLIP", 1, false }
		},
		["JUMP"] = {
			{ "FLIP", 1, false }
		},
		["AIM"] = {
			{ "FLIP", 1, false }
		},
		["ULT"] = {
			{ "FLIP", 1, false }
		},
		["HP"] = {
			{ "AMOUNT", 2, 10 },
			{ "FLIP", 1, false }
		},
		["BAR"] = {
			{ "AMOUNT", 2, 5 },
			{ "FLIP", 1, false }
		},
		["DOMAIN"] = {
			{ "FLIP", 1, false }
		},
		["DUR"] = {
			{ "DURABILITY", 2, 1 }
		}
	},
	["defaultProp"] = {
		["DMG"] = 1,
		["KNOCK"] = 1,
		["KEEP"] = false,
		["REP"] = false,
		["INV"] = false,
		["REP2"] = false,
		["AWK"] = false,
		["AWK2"] = false,
		["USE"] = false,
		["USEONDEATH"] = false,
		["NOSTUN"] = false,
		["NOCANCEL"] = false,
		["VAR"] = "-"
	}
}
return v1