-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v_u_5 = game.ReplicatedStorage
local _ = v_u_5.Animations
local v_u_6 = v_u_5.Utils
local v_u_7 = v_u_5.Sounds
local v_u_8 = require(v_u_5.Modules.CameraShaker)
local v_u_9 = require(v_u_5.Modules.BloodyZee)
require(v_u_5.Modules.SraikoVFX)
local v_u_10 = nil
local v_u_11 = nil
local v12 = v_u_1.CreateController({
	["Name"] = "CleavingWhirlController"
})
function v12.KnitStart(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (ref) v_u_11, (copy) v_u_7, (copy) v_u_3, (copy) v_u_5, (ref) v_u_10
	local v_u_60 = {
		["Hit"] = function(p13, p14, p15)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_4, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11, (ref) v_u_7
			local v16 = p13:FindFirstChild("HumanoidRootPart")
			if v16 then
				local v17 = p14:FindFirstChild("HumanoidRootPart")
				if v17 then
					local v18 = v_u_6.Nanami.CleavingWhirlwind.Hit:Clone()
					v18.Parent = v17
					local v19 = CFrame.lookAt
					local v20 = v17.Position
					local v21 = v16.Position.X
					local v22 = v17.Position.Y
					local v23 = v16.Position.Z
					v18.WorldCFrame = v19(v20, (Vector3.new(v21, v22, v23)))
					for _, v24 in pairs(v18:GetDescendants()) do
						if v24:IsA("ParticleEmitter") then
							v24:Emit(v24:GetAttribute("EmitCount"))
						end
					end
					v_u_2:AddItem(v18, 1)
					if v_u_4.Character == p13 or v_u_4.Character == p14 then
						v_u_8.CurrentShaker:Shake(v_u_8.Presets.MediumHit)
					end
					if p15 then
						for _ = 1, 10 do
							v_u_9:Blood(CFrame.lookAt(v17.Position, v16.Position) * CFrame.Angles(0, 3.141592653589793, 0), math.random(20, 100), 25, 25)
						end
					end
					v_u_11:Flash(p14, Color3.new(1, 1, 1))
					v_u_11:PlaySound(p15 and v_u_7.Nanami.CleavingWhirlwind.RatioHit or v_u_7.Nanami.CleavingWhirlwind.Hit, v16, game.SoundService.Effect)
				end
			else
				return
			end
		end,
		["Start"] = function(p25, p26)
			-- upvalues: (ref) v_u_11, (ref) v_u_7
			local v27 = p25:FindFirstChild("HumanoidRootPart")
			if v27 then
				local v_u_28 = v_u_11:PlaySound(v_u_7.Nanami.CleavingWhirlwind.Start, v27, game.SoundService.Effect)
				p26.AncestryChanged:Once(function()
					-- upvalues: (copy) v_u_28
					v_u_28:Destroy()
				end)
			end
		end,
		["CleaverEmit"] = function(p29, p_u_30)
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			local v31 = p29:FindFirstChild("HumanoidRootPart")
			if v31 then
				local v32 = v_u_6.Nanami.CleavingWhirlwind.VFX:Clone()
				v32.CFrame = v31.CFrame
				v32.Parent = workspace.Effects
				for _, v33 in pairs(v32:GetDescendants()) do
					if v33:IsA("ParticleEmitter") then
						v33:Emit(v33:GetAttribute("EmitCount"))
					end
				end
				v_u_2:AddItem(v32, 1.5)
				local v_u_34 = p29.SetAssets:FindFirstChild("NanamiCleaver")
				if v_u_34 then
					for _, v35 in pairs(v_u_34:GetDescendants()) do
						if v35:IsA("ParticleEmitter") then
							v35.Enabled = true
						end
					end
					task.delay(0.65, function()
						-- upvalues: (copy) p_u_30, (copy) v_u_34
						if p_u_30 or p_u_30.Parent then
							for _, v36 in pairs(v_u_34:GetDescendants()) do
								if v36:IsA("ParticleEmitter") then
									v36.Enabled = false
								end
							end
						end
					end)
				end
				if p_u_30 then
					p_u_30.AncestryChanged:Once(function()
						-- upvalues: (copy) v_u_34
						for _, v37 in pairs(v_u_34:GetDescendants()) do
							if v37:IsA("ParticleEmitter") then
								v37.Enabled = false
							end
						end
					end)
				end
			else
				return
			end
		end,
		["Slash"] = function(p38)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v39 = p38:FindFirstChild("HumanoidRootPart")
			if v39 then
				local v40 = v_u_6.Nanami.CleavingWhirlwind.SlashEmit:Clone()
				v40.CFrame = v39.CFrame
				v40.Parent = workspace.Effects
				for _, v41 in pairs(v40:GetDescendants()) do
					if v41:IsA("ParticleEmitter") then
						v41:Emit(v41:GetAttribute("EmitCount"))
					end
				end
				v_u_2:AddItem(v40, 1.5)
				local v42 = v_u_6.Nanami.CleavingWhirlwind.SlashBeam:Clone()
				v42.CFrame = v39.CFrame
				v42.Parent = workspace.Effects
				v_u_2:AddItem(v42, 1.5)
				for _, v43 in pairs(v42:GetDescendants()) do
					if v43:IsA("Beam") then
						v43.Enabled = true
					end
				end
				for _, v_u_44 in pairs(v42:GetDescendants()) do
					if v_u_44:IsA("Beam") then
						v_u_3:Create(v_u_44, TweenInfo.new(0.19), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
						task.delay(0.29000000000000004, function()
							-- upvalues: (copy) v_u_44
							v_u_44.Enabled = false
							v_u_44.Width0 = 17
							v_u_44.Width1 = 17
						end)
					end
				end
			end
		end,
		["Swing"] = function(p45, p46)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2
			if p45:FindFirstChild("HumanoidRootPart") then
				local v47 = p45.SetAssets:FindFirstChild("NanamiCleaver")
				if v47 then
					local v48 = v_u_6.Nanami.CombatTrail:Clone()
					v48.Weld.Part0 = v47.Blade
					v48.Parent = workspace.Effects
					task.wait(p46 or 0.3)
					v48.Trail.Enabled = false
					v_u_3:Create(v48, TweenInfo.new(0.1), {
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v48, 0.2)
				end
			else
				return
			end
		end,
		["Whoosh"] = function(p49)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_3
			local v50 = p49:FindFirstChild("HumanoidRootPart")
			if v50 then
				local v51 = v_u_6.Todo.Swing:Clone()
				local v52 = Instance.new("Model")
				v51.Parent = v52
				v52:ScaleTo(1.3)
				v_u_2:AddItem(v52, 0.2)
				v51.Weld.C0 = v51.Weld.C0 * CFrame.new(0, -1, -0.5) * CFrame.Angles(0, 0, 0.17453292519943295) * CFrame.Angles(0, 0, 0.8726646259971648)
				v51.Weld.Part0 = v50
				v51.Parent = workspace.Effects
				v_u_2:AddItem(v51, 0.6)
				v51.Core.Wind:Emit(10)
				v_u_3:Create(v51.Weld, TweenInfo.new(0.2), {
					["C1"] = v51.Weld.C1 * CFrame.Angles(0.08726646259971647, -3.141592653589793, 0)
				}):Play()
				v_u_3:Create(v51.Beam, TweenInfo.new(0.2), {
					["Width0"] = 0
				}):Play()
			end
		end,
		["Dash"] = function(p53)
			-- upvalues: (ref) v_u_5, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3
			local v_u_54 = p53:FindFirstChild("HumanoidRootPart")
			if v_u_54 then
				local v55 = Instance.new("Model")
				local v56 = v_u_5.Utils.Itadori.RushWind:Clone()
				v56.CFrame = v_u_54.CFrame * CFrame.new(0, -1, 0)
				v56.Parent = v55
				v55.Parent = workspace.Effects
				v55:ScaleTo(0.6)
				v56.Ring:Emit(7)
				v56.Dash1.Dash:Emit(1)
				v56.Dash2.Dash:Emit(1)
				v_u_2:AddItem(v55, 2)
				local v57 = v_u_6.Itadori.Shock:Clone()
				v57.CFrame = v_u_54.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				v57.Parent = workspace.Effects
				v_u_3:Create(v57, TweenInfo.new(0.2), {
					["Size"] = Vector3.new(8, 0, 8),
					["Transparency"] = 1
				}):Play()
				v_u_2:AddItem(v57, 0.2)
				task.delay(0.05, function()
					-- upvalues: (ref) v_u_6, (copy) v_u_54, (ref) v_u_3, (ref) v_u_2
					local v58 = v_u_6.Itadori.Shock:Clone()
					v58.CFrame = (v_u_54.CFrame - v_u_54.CFrame.Position + v_u_54.Position) * CFrame.Angles(1.5707963267948966, 0, 0)
					v58.Parent = workspace.Effects
					v_u_3:Create(v58, TweenInfo.new(0.2), {
						["Size"] = Vector3.new(8, 0, 8),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v58, 0.2)
				end)
			end
		end,
		["Finisher"] = function(p59)
			-- upvalues: (ref) v_u_11
			if p59:FindFirstChild("HumanoidRootPart") then
				v_u_11:Bleed(p59)
			end
		end
	}
	v_u_10.Effects:Connect(function(p61, ...)
		-- upvalues: (copy) v_u_60
		local v62 = v_u_60[p61]
		if v62 then
			v62(...)
		end
	end)
end
function v12.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11
	v_u_10 = v_u_1.GetService("CleavingWhirlService")
	v_u_11 = v_u_1.GetController("FXController")
end
return v12