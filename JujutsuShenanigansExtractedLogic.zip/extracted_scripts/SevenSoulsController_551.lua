-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
game:GetService("Debris")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Lighting")
game:GetService("StarterGui")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v6 = v5.Animations
local _ = v5.Utils
local _ = v5.Sounds
local v_u_7 = v_u_4:WaitForChild("PlayerGui")
require(v5.Modules.CameraShaker)
local v8 = require(v5.Modules.SraikoVFX)
require(v5.TEMP_CHARA_STUFF.VelocityHandler)
local v_u_9 = require(v5.TEMP_CHARA_STUFF.AnimationRetriever)
local v_u_10 = require(v5.TEMP_CHARA_STUFF.EffectUtility)
local v_u_11 = require(v5.TEMP_CHARA_STUFF.CameraShake)
local v_u_12 = require(v5.TEMP_CHARA_STUFF.Vignette)
require(v5.TEMP_CHARA_STUFF.RockHandler)
require(v5.TEMP_CHARA_STUFF.Smoke)
require(v5.TEMP_CHARA_STUFF.Afterimage)
require(v5.TEMP_CHARA_STUFF.MoonUtil)
local v_u_13 = require(v5.TEMP_CHARA_STUFF.RunCameraRig)
local v_u_14 = require(v5.TEMP_CHARA_STUFF.Create_Clone)
require(v5.TEMP_CHARA_STUFF.VelocityUtil)
local v_u_15 = require(v5.TEMP_CHARA_STUFF.Utility)
local v_u_16 = require(v5.TEMP_CHARA_STUFF.Yuki_FOV)
require(v5.Modules.EffectUtils)
local v_u_17 = require(script.quickutil.MeshEmit)
local v_u_18 = require(script.Parent.FightController.Fight_UI)
local v_u_19 = require(script.quickutil)
local _ = v8.Enabled
local _ = v8.Emit
local _ = v8.EmitMesh
local _ = {
	["Ambient"] = v_u_3.Ambient,
	["Brightness"] = v_u_3.Brightness,
	["ColorShift_Bottom"] = v_u_3.ColorShift_Bottom,
	["ColorShift_Top"] = v_u_3.ColorShift_Top,
	["ClockTime"] = v_u_3.ClockTime,
	["EnvironmentDiffuseScale"] = v_u_3.EnvironmentDiffuseScale,
	["EnvironmentSpecularScale"] = v_u_3.EnvironmentSpecularScale,
	["ExposureCompensation"] = v_u_3.ExposureCompensation,
	["FogColor"] = v_u_3.FogColor,
	["FogEnd"] = v_u_3.FogEnd,
	["FogStart"] = v_u_3.FogStart,
	["GeographicLatitude"] = v_u_3.GeographicLatitude,
	["GlobalShadows"] = v_u_3.GlobalShadows,
	["OutdoorAmbient"] = v_u_3.OutdoorAmbient,
	["ShadowSoftness"] = v_u_3.ShadowSoftness,
	["TimeOfDay"] = v_u_3.TimeOfDay
}
local v_u_20 = script.effects
local v_u_21 = script.windup_effects
local v_u_22 = Color3.fromRGB(255, 50, 50)
local function v_u_27(p23)
	-- upvalues: (copy) v_u_22, (copy) v_u_2
	for _, v24 in ipairs(p23:GetChildren()) do
		if v24:IsA("BasePart") and v24.Name ~= "HumanoidRootPart" then
			local v25 = Instance.new("Part")
			v25.Size = v24.Size
			v25.CFrame = v24.CFrame
			v25.Anchored = true
			v25.CanCollide = false
			v25.CanQuery = false
			v25.CanTouch = false
			v25.Material = Enum.Material.Neon
			v25.Color = v_u_22
			v25.Transparency = 0.3
			local v26 = v24:FindFirstChildOfClass("SpecialMesh")
			if v26 then
				v26:Clone().Parent = v25
			end
			v25.Parent = workspace.Effects
			v_u_2:Create(v25, TweenInfo.new(0.25), {
				["Transparency"] = 1
			}):Play()
			task.delay(0.3, v25.Destroy, v25)
		end
	end
end
local v_u_28 = nil
local v_u_29 = nil
local v_u_30 = nil
local v31 = v_u_1.CreateController({
	["Name"] = "SevenSoulsController"
})
local v_u_32 = v6.Misc.C.SevenSouls
local v_u_33 = game:GetService("Players").LocalPlayer
function v31.KnitStart(_)
	-- upvalues: (copy) v_u_9, (copy) v_u_32, (copy) v_u_4, (copy) v_u_14, (copy) v_u_10, (copy) v_u_21, (copy) v_u_11, (copy) v_u_27, (copy) v_u_12, (copy) v_u_2, (copy) v_u_16, (copy) v_u_3, (copy) v_u_33, (copy) v_u_20, (copy) v_u_19, (copy) v_u_17, (copy) v_u_15, (copy) v_u_18, (copy) v_u_7, (copy) v_u_13, (ref) v_u_28
	local v_u_108 = {
		["Start"] = function(p_u_34)
			-- upvalues: (ref) v_u_9, (ref) v_u_32, (ref) v_u_4, (ref) v_u_14, (ref) v_u_10, (ref) v_u_21, (ref) v_u_11, (ref) v_u_27, (ref) v_u_12, (ref) v_u_2, (ref) v_u_16, (ref) v_u_3
			local v_u_35 = v_u_9.new(p_u_34, v_u_32.Windup)
			if v_u_35 ~= nil then
				local v_u_36 = v_u_35.Animation
				local v_u_37 = v_u_35.Job
				local v_u_38 = v_u_35.RootPart
				local v39 = v_u_35.Torso
				v_u_35.IsLocalSource = v_u_4.Character == p_u_34
				local v_u_40 = v_u_37:Task(v_u_14(p_u_34))
				for _, v41 in ipairs(v_u_40:GetDescendants()) do
					if v41:IsA("BasePart") or v41:IsA("Decal") then
						v41.Transparency = 1
					end
				end
				local v42 = v_u_10.AddSFX
				local v43 = script.sfx.windup
				local v44
				if v_u_35.IsLocalSource then
					v44 = workspace or v_u_38
				else
					v44 = v_u_38
				end
				v_u_37:Task(v42(v43, v44, 0.3))
				v_u_40.Parent = workspace.Effects
				local v_u_45 = v_u_37:Task(v_u_21.head:Clone())
				v_u_10.Arc.ToggleAttachment(v_u_45, true)
				v_u_10.Emit(v_u_45, true)
				v_u_45.Parent = p_u_34.Head
				local v_u_46 = v_u_37:Task(v_u_21.dash:Clone())
				v_u_46.Parent = v_u_38
				local v_u_47 = v_u_21.aura:Clone()
				v_u_47.Parent = v39
				v_u_37:Task(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_47
					v_u_10.Arc.ToggleAttachment(v_u_47, false)
					task.delay(2, v_u_47.Destroy, v_u_47)
				end)
				v_u_37:Task(v_u_36:GetMarkerReachedSignal("step"):Connect(function(_)
					-- upvalues: (ref) v_u_10, (copy) p_u_34, (ref) v_u_11
					if v_u_10.Distance_Close(p_u_34) then
						v_u_11(1.25, 12.5, 0.01, 0.5, Vector3.new(0.8, 0.8, 0.8))
					end
				end))
				v_u_37:Task(v_u_36:GetMarkerReachedSignal("boost"):Once(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_45, (copy) v_u_46, (copy) v_u_47, (ref) v_u_21, (copy) v_u_38, (copy) v_u_35, (ref) v_u_11
					v_u_10.Arc.ToggleAttachment(v_u_45, false)
					v_u_10.Arc.ToggleAttachment(v_u_46, true)
					v_u_10.Arc.ToggleAttachment(v_u_47, true)
					v_u_10.Arc.CloneAndEmit(v_u_21.dash_burst, v_u_38)
					v_u_10.Emit(v_u_46, true)
					if v_u_35.IsLocalSource then
						v_u_11(0.85, 8.5, 0.01, 2.5, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
					end
				end))
				v_u_37:Task(v_u_36:GetMarkerReachedSignal("dash"):Connect(function()
					-- upvalues: (ref) v_u_27, (copy) p_u_34, (copy) v_u_35, (ref) v_u_12, (ref) v_u_10, (ref) v_u_11
					task.spawn(function()
						-- upvalues: (ref) v_u_27, (ref) p_u_34, (ref) v_u_35, (ref) v_u_12
						for _ = 1, 4 do
							v_u_27(p_u_34)
							if v_u_35.IsLocalSource then
								v_u_12(Color3.fromRGB(255, 50, 50), 0.35, 0.35)
							end
							task.wait(0.05)
						end
					end)
					if v_u_10.Distance_Close(p_u_34) then
						v_u_11(1.5, 15, 0.01, 0.5, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
					end
				end))
				v_u_37:Task(v_u_36:GetMarkerReachedSignal("jump"):Once(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_46
					v_u_10.Arc.ToggleAttachment(v_u_46, false)
				end))
				v_u_37:Task(task.delay(3.466666666666667, function()
					-- upvalues: (copy) v_u_40, (ref) v_u_32, (copy) v_u_36, (ref) v_u_2, (copy) v_u_37, (ref) v_u_27
					local v48 = v_u_40.Humanoid.Animator:LoadAnimation(v_u_32.Windup_Clone)
					v48:Play(0, nil, v_u_36.Speed)
					v48.Stopped:Once(function()
						-- upvalues: (ref) v_u_40
						v_u_40:Destroy()
					end)
					for _, v49 in ipairs(v_u_40:GetDescendants()) do
						if v49:IsA("BasePart") and v49.Name ~= "HumanoidRootPart" or v49:IsA("Decal") then
							v_u_2:Create(v49, TweenInfo.new(0.1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
								["Transparency"] = 0
							}):Play()
						end
					end
					v_u_37:Task(v_u_36:GetMarkerReachedSignal("dash"):Connect(function()
						-- upvalues: (ref) v_u_27, (ref) v_u_40
						task.spawn(function()
							-- upvalues: (ref) v_u_27, (ref) v_u_40
							for _ = 1, 4 do
								v_u_27(v_u_40)
								task.wait(0.05)
							end
						end)
					end))
				end))
				if v_u_35.IsLocalSource then
					local v_u_50 = Enum.EasingStyle.Quad
					local v_u_51 = Enum.EasingDirection.Out
					v_u_16.Tween(55, { 1.1, v_u_50, v_u_51 })
					v_u_37:Task(function()
						-- upvalues: (ref) v_u_16
						v_u_16.Tween(70, { 0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out }, true)
					end)
					local v_u_52 = script.ColorCorrection:Clone()
					v_u_52.Contrast = 0.75
					v_u_52.Parent = v_u_3
					v_u_37:Task(v_u_52)
					local v_u_53 = v_u_2:Create(v_u_52, TweenInfo.new(1.1, v_u_50, v_u_51), {
						["TintColor"] = Color3.fromRGB(140, 140, 140),
						["Contrast"] = 0
					})
					v_u_53:Play()
					v_u_53.Completed:Once(function()
						-- upvalues: (ref) v_u_53, (ref) v_u_2, (copy) v_u_52, (copy) v_u_50
						v_u_53 = v_u_2:Create(v_u_52, TweenInfo.new(0.75, v_u_50, Enum.EasingDirection.Out), {
							["TintColor"] = Color3.fromRGB(140, 75, 75)
						})
						v_u_53:Play()
					end)
					local v_u_54 = v_u_3.Brightness
					v_u_2:Create(v_u_3, TweenInfo.new(1.1, v_u_50, v_u_51), {
						["Brightness"] = 2
					}):Play()
					v_u_37:Task(v_u_36:GetMarkerReachedSignal("boost"):Connect(function()
						-- upvalues: (ref) v_u_53, (ref) v_u_2, (copy) v_u_52, (copy) v_u_50, (copy) v_u_51, (ref) v_u_3, (copy) v_u_54, (ref) v_u_16, (copy) v_u_37
						v_u_53:Cancel()
						v_u_2:Create(v_u_52, TweenInfo.new(0.3, v_u_50, v_u_51), {
							["TintColor"] = Color3.fromRGB(255, 215, 215)
						}):Play()
						local v55 = {
							["Brightness"] = v_u_54
						}
						v_u_2:Create(v_u_3, TweenInfo.new(0.3, v_u_50, v_u_51), v55):Play()
						v_u_16.Tween(100, { 0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut })
						v_u_37:Task(task.delay(1.25, function()
							-- upvalues: (ref) v_u_16
							v_u_16.Tween(70, { 2.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut })
						end))
					end))
					v_u_37:Task(v_u_36:GetMarkerReachedSignal("jump"):Connect(function()
						-- upvalues: (ref) v_u_2, (copy) v_u_52, (copy) v_u_50, (copy) v_u_51
						v_u_2:Create(v_u_52, TweenInfo.new(0.5, v_u_50, v_u_51), {
							["TintColor"] = Color3.fromRGB(255, 255, 255)
						}):Play()
					end))
				end
			end
		end,
		["Slash"] = function(p56)
			-- upvalues: (ref) v_u_21, (ref) v_u_10, (ref) v_u_12, (ref) v_u_11
			local v57 = v_u_21.Hit:Clone()
			v57:PivotTo(p56.CFrame * CFrame.new(0, 0.5, -2.75))
			v57.Parent = workspace.Effects
			v_u_10.Emit(v57)
			if v_u_10.Distance_Close(p56.Parent) then
				v_u_12(Color3.fromRGB(255, 50, 50), 0.5, 0.5)
				v_u_11(1.5, 15, 0.01, 0.5, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.2, 0.2, 0.2))
			end
		end,
		["Hit"] = function(p_u_58, p59)
			-- upvalues: (ref) v_u_9, (ref) v_u_32, (ref) v_u_4, (ref) v_u_33, (ref) v_u_10, (ref) v_u_14, (ref) v_u_20, (ref) v_u_11, (ref) v_u_12, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (ref) v_u_18, (ref) v_u_7, (ref) v_u_2, (ref) v_u_13, (ref) v_u_3
			local v60 = v_u_9.new(p_u_58, v_u_32.Full)
			if v60 ~= nil then
				local v_u_61 = v60.Animation
				local v_u_62 = v60.Job
				local v_u_63 = v60.RootPart
				local _ = v60.Torso
				v60.IsLocalSource = v_u_4.Character == p_u_58
				local v_u_64 = v_u_33.Character == p59
				local v_u_65 = v60.IsLocalSource or v_u_64
				v_u_62:Task(v_u_10.AddSFX(script.sfx.hit, v_u_65 and workspace or v_u_63, 0.2))
				local v_u_66, _, v67 = v_u_14(p_u_58)
				v_u_66.Parent = workspace.Effects
				local v_u_68 = v_u_66.Humanoid.Animator:LoadAnimation(v_u_32.Full_Clone)
				v_u_68:Play(0, nil, v_u_61.Speed)
				local v_u_69 = false
				v_u_62:Task(function()
					-- upvalues: (ref) v_u_69, (copy) v_u_66
					if not v_u_69 then
						v_u_66:Destroy()
					end
				end)
				v_u_68.Stopped:Once(function()
					-- upvalues: (copy) v_u_66
					v_u_66:Destroy()
				end)
				local v_u_70 = v_u_20.spin:Clone()
				v_u_10.Weld(v_u_70, v_u_66.Torso)
				v_u_70.Parent = workspace.Effects
				local v_u_71 = v_u_20.head:Clone()
				v_u_10.Weld(v_u_71, p_u_58.Head)
				v_u_71.Parent = workspace.Effects
				local v_u_72 = v_u_20.playerslashes:Clone()
				v_u_10.Weld(v_u_72, v_u_63)
				v_u_72.Parent = workspace.Effects
				local v_u_73 = v_u_20.cloneslashes:Clone()
				v_u_10.Weld(v_u_73, v67 or v_u_63)
				v_u_73.Parent = workspace.Effects
				v_u_62:Task(v_u_70)
				v_u_62:Task(v_u_71)
				v_u_62:Task(v_u_72)
				v_u_62:Task(v_u_73)
				v_u_62:Task(v_u_61:GetMarkerReachedSignal("slash"):Connect(function(p74)
					-- upvalues: (ref) v_u_10, (copy) p_u_58, (ref) v_u_11, (ref) v_u_12, (ref) v_u_19, (copy) v_u_72
					if v_u_10.Distance_Close(p_u_58) then
						v_u_11(1, 10, 0.01, 0.4, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
						v_u_12(Color3.fromRGB(255, 50, 50), 0.35, 0.35)
					end
					v_u_19:emit(v_u_72[p74])
				end))
				v_u_62:Task(v_u_68:GetMarkerReachedSignal("slash"):Connect(function(p75)
					-- upvalues: (ref) v_u_10, (copy) p_u_58, (ref) v_u_11, (ref) v_u_12, (ref) v_u_19, (copy) v_u_73
					if v_u_10.Distance_Close(p_u_58) then
						v_u_11(1, 10, 0.01, 0.4, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.25, 0.25, 0.25))
						v_u_12(Color3.fromRGB(255, 50, 50), 0.35, 0.35)
					end
					v_u_19:emit(v_u_73[p75])
				end))
				v_u_62:Task(v_u_68:GetMarkerReachedSignal("spin"):Connect(function(p76)
					-- upvalues: (ref) v_u_10, (copy) p_u_58, (ref) v_u_11, (ref) v_u_19, (copy) v_u_70
					if v_u_10.Distance_Close(p_u_58) then
						v_u_11(0.5, 5, 0.01, 0.6, Vector3.new(0.2, 0.2, 0.2), Vector3.new(0.8, 0.8, 0.8))
					end
					v_u_19:interact(v_u_70, "ParticleEmitter", "Enabled", p76 == "true")
				end))
				v_u_62:Task(v_u_61:GetMarkerReachedSignal("on_qte"):Connect(function(p77)
					-- upvalues: (copy) v_u_62, (ref) v_u_10, (copy) v_u_65, (copy) v_u_63
					if p77 == "1" then
						v_u_62:Task(v_u_10.AddSFX(script.sfx.qte_1, v_u_65 and workspace or v_u_63, 0.2))
					elseif p77 == "2" then
						v_u_62:Task(v_u_10.AddSFX(script.sfx.qte_2, v_u_65 and workspace or v_u_63, 0.2))
					end
				end))
				v_u_62:Task(v_u_61:GetMarkerReachedSignal("eye"):Once(function()
					-- upvalues: (ref) v_u_10, (copy) p_u_58, (ref) v_u_11, (ref) v_u_12, (ref) v_u_19, (copy) v_u_71
					if v_u_10.Distance_Close(p_u_58) then
						v_u_11(0.1, 5, 0.01, 0.4, Vector3.new(0.7, 0.7, 0.7))
						v_u_12(Color3.fromRGB(255, 50, 50), 0.6, 0.4, true)
					end
					v_u_19:emit(v_u_71)
				end))
				v_u_62:Task(v_u_61:GetMarkerReachedSignal("big_slash"):Connect(function()
					-- upvalues: (ref) v_u_10, (copy) p_u_58, (ref) v_u_11, (ref) v_u_20, (copy) v_u_63, (ref) v_u_19
					if v_u_10.Distance_Close(p_u_58, 50) then
						v_u_11(1, 10, 0.01, 0.75, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
					end
					local v78 = v_u_20.bigslash:Clone()
					v78.CFrame = v_u_63.CFrame * CFrame.new(0.067, 4.312, 1.263)
					v78.Parent = workspace.Effects
					v_u_19:emit(v78)
					v_u_19:interact(v78.beam, "Beam", "Brightness", 2)
					v_u_19:interact(v78.beam, "Beam", "TextureSpeed", -6)
					v_u_19:interact(v78.beam, "Beam", "Width1", 34)
					v_u_19:tweendescendant(v78.beam, "Beam", 1.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["Brightness"] = 0,
						["TextureSpeed"] = -0.6,
						["Width1"] = 6
					})
					v_u_19:interact(v78, "PointLight", "Brightness", 2)
					v_u_19:tweendescendant(v78, "PointLight", 3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["Brightness"] = 0
					})
					v_u_19:interact(v78.beams, "Beam", "Brightness", 2)
					v_u_19:interact(v78.beams, "Beam", "TextureSpeed", 8)
					v_u_19:interact(v78.beams, "Beam", "Width1", 35)
					v_u_19:tweendescendant(v78.beams, "Beam", 1.4, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["Brightness"] = 0,
						["TextureSpeed"] = 0.6,
						["Width1"] = 25
					})
					task.delay(10, v78.Destroy, v78)
				end))
				v_u_62:Task(v_u_61:GetMarkerReachedSignal("boom"):Connect(function()
					-- upvalues: (ref) v_u_10, (copy) p_u_58, (ref) v_u_11, (ref) v_u_20, (copy) v_u_63, (ref) v_u_19, (ref) v_u_17
					if v_u_10.Distance_Close(p_u_58, 50) then
						v_u_11(1.3, 13, 0.01, 0.75, Vector3.new(0.8, 0.8, 0.8), Vector3.new(0.3, 0.3, 0.3))
					end
					local v_u_79 = v_u_20.soulbeam:Clone()
					v_u_79:PivotTo(v_u_63.CFrame * CFrame.new(0, 1, -6.032))
					v_u_79.Parent = workspace.Effects
					task.delay(10, v_u_79.Destroy, v_u_79)
					v_u_19:interact(v_u_79, "Beam", "Width0", 130)
					v_u_19:interact(v_u_79, "Beam", "Width1", 150)
					v_u_19:tweendescendant(v_u_79, "Beam", 0.1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, {
						["Width1"] = 90,
						["Width0"] = 40
					})
					task.delay(0.05, function()
						-- upvalues: (ref) v_u_19, (copy) v_u_79
						v_u_19:tweendescendant(v_u_79, "Beam", 2, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["Width1"] = 0,
							["Width0"] = 0
						})
					end)
					v_u_79.att2.Position = Vector3.new(0, 213.13, 0)
					v_u_19:tweensingle(v_u_79.att2, 2, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["Position"] = Vector3.new(0, 107.661, 0)
					})
					v_u_19:interact(v_u_79, "ParticleEmitter", "Enabled", true)
					task.delay(0.9, function()
						-- upvalues: (ref) v_u_19, (copy) v_u_79
						v_u_19:interact(v_u_79, "ParticleEmitter", "Enabled", false)
					end)
					local v80 = v_u_20.soulactivate:Clone()
					v80.CFrame = v_u_63.CFrame * CFrame.new(0, 1, -6.032)
					v80.Parent = workspace.Effects
					v_u_19:emit(v80)
					task.delay(10, v80.Destroy, v80)
					local v81 = v_u_20.meshes.beam:Clone()
					v81:PivotTo(v_u_63.CFrame)
					for _, v82 in ipairs(v81:GetDescendants()) do
						if v82.Name == "Start" then
							v_u_17(v82, true)
						end
					end
					v81:Destroy()
				end))
				if v_u_65 then
					local v_u_83 = false
					if v60.IsLocalSource then
						v_u_62:Task(v_u_61:GetMarkerReachedSignal("qte"):Connect(function(p_u_84)
							-- upvalues: (copy) p_u_58, (ref) v_u_15, (ref) v_u_18, (copy) v_u_62, (ref) v_u_83
							local v_u_85 = p_u_58:FindFirstChild("CharaSevenSoulsRemote")
							if v_u_85 ~= nil then
								v_u_18(p_u_58, v_u_85, v_u_62, {
									["AttackTime"] = v_u_15.Seed:NextNumber(0.725, 0.9),
									["RemoteFire"] = function(p86)
										-- upvalues: (copy) p_u_84, (ref) v_u_83, (copy) v_u_85
										local v87 = p_u_84
										local v88 = tonumber(v87)
										if v88 == 1 then
											v_u_83 = p86
										end
										return v_u_85:FireServer(p86, v88)
									end
								})
							end
						end))
						v_u_62:Task(v_u_61:GetMarkerReachedSignal("on_qte"):Connect(function(p89)
							-- upvalues: (ref) v_u_83, (ref) v_u_69, (copy) v_u_66, (ref) v_u_32, (copy) v_u_68, (copy) v_u_61
							if p89 == "1" and not v_u_83 then
								v_u_69 = true
								local v90 = v_u_66.Humanoid.Animator:LoadAnimation(v_u_32.FirstQTEMiss_Clone)
								v_u_68:Destroy()
								v_u_68:Stop(0)
								v90:Play(0, nil, v_u_61.Speed)
								v90.Stopped:Once(function()
									-- upvalues: (ref) v_u_66
									v_u_66:Destroy()
								end)
							end
						end))
					end
					local v_u_91 = v_u_62:Task(script.Videos:Clone())
					v_u_91.Name = "CharaVideos"
					v_u_91.Parent = v_u_7
					v_u_62:Task(v_u_61:GetMarkerReachedSignal("camera"):Connect(function()
						-- upvalues: (copy) v_u_64, (ref) v_u_83, (ref) v_u_7, (copy) v_u_62, (ref) v_u_10, (copy) v_u_63, (ref) v_u_32, (copy) v_u_61, (ref) v_u_2, (copy) p_u_58, (ref) v_u_13, (ref) v_u_19, (ref) v_u_33, (copy) v_u_91, (ref) v_u_3
						if v_u_64 or v_u_83 then
							local v_u_92 = script.Parent.AtonementController.Vignette:Clone()
							v_u_92.Parent = v_u_7
							v_u_62:Task(v_u_92)
							local v_u_93 = script.Camera:Clone()
							v_u_10.Weld(v_u_93, v_u_63)
							v_u_93.Parent = workspace.Effects
							v_u_62:Task(v_u_93)
							local v_u_94 = false
							local v_u_95 = v_u_93.Humanoid.Animator:LoadAnimation(v_u_32.Full_Camera)
							v_u_95:Play(0, nil, v_u_61.Speed)
							task.delay(0.016666666666666666, function()
								-- upvalues: (ref) v_u_63, (ref) v_u_62, (ref) v_u_61, (ref) v_u_2, (ref) p_u_58, (ref) v_u_13, (copy) v_u_93, (ref) v_u_94
								local v_u_96 = script.Heart:Clone()
								for _, v97 in ipairs(v_u_96:GetChildren()) do
									if v97:IsA("BasePart") then
										local v98 = Instance.new("Motor6D")
										v98.Part0 = v_u_63
										v98.Part1 = v97
										v98.Name = v97.Name
										v98.Parent = v_u_63
									end
								end
								v_u_62:Task(v_u_61:GetMarkerReachedSignal("boom"):Once(function()
									-- upvalues: (copy) v_u_96, (ref) v_u_2
									local v99 = TweenInfo.new(1.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
									for _, v100 in ipairs(v_u_96:GetDescendants()) do
										if v100:IsA("BasePart") and v100.Transparency == 0 then
											v_u_2:Create(v100, v99, {
												["Transparency"] = 1
											}):Play()
										elseif v100:IsA("Light") then
											v_u_2:Create(v100, v99, {
												["Brightness"] = 0
											}):Play()
										end
									end
								end))
								v_u_96.Parent = p_u_58
								v_u_62:Task(function()
									-- upvalues: (copy) v_u_96
									task.delay(0.5, v_u_96.Destroy, v_u_96)
								end)
								v_u_62:Task(v_u_13(v_u_63, v_u_93, nil, {
									["DontSaveCameraPosition"] = true,
									["DontDoTransition"] = true
								}, function(p101)
									-- upvalues: (ref) v_u_94
									v_u_94 = not p101
								end))
							end)
							v_u_62:Task(v_u_95:GetMarkerReachedSignal("wind"):Connect(function(p102)
								-- upvalues: (ref) v_u_94, (ref) v_u_19, (copy) v_u_93
								if not v_u_94 then
									v_u_19:interact(v_u_93.wind, "ParticleEmitter", "Enabled", p102 == "true")
								end
							end))
							v_u_62:Task(v_u_61:GetMarkerReachedSignal("big_slash"):Connect(function()
								-- upvalues: (ref) v_u_62, (ref) v_u_33, (ref) v_u_91
								v_u_62:Task(task.delay(0.6, function()
									-- upvalues: (ref) v_u_33, (ref) v_u_91
									if not v_u_33:GetAttribute("Epileptic_Mode") and math.random(1, 5) == 1 then
										v_u_91.Frame.SevenSouls.Visible = true
										v_u_91.Frame.SevenSouls:Play()
										v_u_91.Frame.SevenSouls.Ended:Once(function()
											-- upvalues: (ref) v_u_91
											v_u_91.Frame.SevenSouls.Visible = false
										end)
									end
								end))
							end))
							v_u_62:Task(v_u_61:GetMarkerReachedSignal("boom"):Connect(function()
								-- upvalues: (ref) v_u_61, (copy) v_u_95, (ref) v_u_3, (ref) v_u_2, (copy) v_u_92
								v_u_61:AdjustSpeed(0.8)
								v_u_95:AdjustSpeed(0.8)
								local v103 = script.ColorCorrection:Clone()
								v103.Contrast = 0.25
								v103.Parent = v_u_3
								v_u_2:Create(v103, TweenInfo.new(0.9833333333333333, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
									["Contrast"] = 0
								}):Play()
								task.delay(0.9833333333333333, v103.Destroy, v103)
								local v104 = v_u_3.Brightness
								local v105 = v_u_3.ExposureCompensation
								v_u_3.Brightness = 0
								v_u_3.ExposureCompensation = 0.35
								v_u_2:Create(v_u_3, TweenInfo.new(0.9833333333333333, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
									["Brightness"] = v104,
									["ExposureCompensation"] = v105
								}):Play()
								v_u_92.Image.ImageTransparency = 0.2
								v_u_2:Create(v_u_92.Image, TweenInfo.new(0.9833333333333333, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
									["ImageTransparency"] = 1
								}):Play()
								local v106 = v_u_3:FindFirstChildOfClass("BloomEffect")
								if v106 ~= nil then
									local v107 = v106.Intensity
									v106.Intensity = 1.4
									v_u_2:Create(v106, TweenInfo.new(0.9833333333333333, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
										["Intensity"] = v107
									}):Play()
								end
							end))
							v_u_62:Task(v_u_95.Stopped:Connect(function()
								-- upvalues: (copy) v_u_93
								v_u_93:Destroy()
							end))
						end
					end))
				end
			end
		end
	}
	v_u_28.Effects:Connect(function(p109, ...)
		-- upvalues: (ref) v_u_108
		local v110 = v_u_108[p109]
		if v110 then
			v110(...)
		end
	end)
end
function v31.KnitInit(_)
	-- upvalues: (ref) v_u_28, (copy) v_u_1, (ref) v_u_29, (ref) v_u_30
	v_u_28 = v_u_1.GetService("SevenSoulsService")
	v_u_29 = v_u_1.GetController("HitboxController")
	v_u_30 = v_u_1.GetController("FXController")
end
return v31