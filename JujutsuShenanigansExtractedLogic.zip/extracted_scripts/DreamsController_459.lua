-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local v_u_6 = v5.Animations
local v_u_7 = v5.Utils
local v_u_8 = v5.Sounds
local v_u_9 = require(v5.Modules.CameraShaker)
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v13 = v_u_1.CreateController({
	["Name"] = "DreamsController"
})
function v13.KnitStart(_)
	-- upvalues: (copy) v_u_4, (ref) v_u_12, (copy) v_u_6, (copy) v_u_7, (copy) v_u_2, (copy) v_u_3, (copy) v_u_8, (copy) v_u_9, (ref) v_u_10
	local v_u_36 = {
		["Start"] = function(p14)
			-- upvalues: (ref) v_u_4, (ref) v_u_12, (ref) v_u_6
			if v_u_4.Character == p14 then
				v_u_12:Flash(p14, Color3.new(0, 0, 0), 0.5)
				local v15 = workspace.Effects:FindFirstChild("FollowTakada")
				if v15 and v_u_4.Character == p14 then
					local v16 = v15.Humanoid:LoadAnimation(v_u_6.Todo.TakadaJoint.Emote)
					v16:Play(nil, nil, 3)
					task.wait(1.4)
					v16:Stop()
				end
			end
		end,
		["Hit"] = function(p17, p18)
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_2, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				if v_u_4 == p17 then
					local v20 = v_u_7.Todo.HeavyHit:Clone()
					v20.Position = v19.Position
					v20.Parent = workspace.Effects
					v_u_2:AddItem(v20, 1)
					v20.Sparks:Emit(50)
					v20.Ring:Emit(2)
					v20.Wind2:Emit(7)
					v20.Hearts:Emit(40)
					v_u_3:Create(v20.PointLight, TweenInfo.new(0.75), {
						["Brightness"] = 0
					}):Play()
				else
					local v21 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
					v21.Position = v19.Position
					v21.Parent = workspace.Effects
					v_u_2:AddItem(v21, 1)
					v21.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v21.Wind.Color = v21.Sparks.Color
					v21.Wind2.Color = v21.Sparks.Color
					v21.Sparks:Emit(50)
					v21.Wind:Emit(7)
					v21.Wind2:Emit(7)
				end
				v_u_12:Flash(p18, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Hakari.EnergySurge.Hit1, v19, game.SoundService.Effect)
				if v_u_4 == p17 or v_u_4.Character == p18 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.HeavyHit)
				end
			end
		end,
		["Hit2"] = function(p22, p23)
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_2, (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9
			local v24 = p23:FindFirstChild("HumanoidRootPart")
			if v24 then
				if v_u_4 == p22 then
					local v25 = v_u_7.Todo.HeavyHit:Clone()
					v25.Position = v24.Position
					v25.Parent = workspace.Effects
					v_u_2:AddItem(v25, 1)
					v25.Sparks:Emit(50)
					v25.Ring:Emit(2)
					v25.Wind2:Emit(7)
					v25.Hearts:Emit(40)
					v_u_3:Create(v25.PointLight, TweenInfo.new(0.75), {
						["Brightness"] = 0
					}):Play()
				else
					local v26 = v_u_7.Mahito.CrushingRushdown.DrillImpact:Clone()
					v26.Position = v24.Position
					v26.Parent = workspace.Effects
					v_u_2:AddItem(v26, 1)
					v26.Sparks.Color = ColorSequence.new(Color3.new(1, 1, 1))
					v26.Wind.Color = v26.Sparks.Color
					v26.Wind2.Color = v26.Sparks.Color
					v26.Sparks:Emit(50)
					v26.Wind:Emit(7)
					v26.Wind2:Emit(7)
				end
				v_u_12:Flash(p23, Color3.new(1, 1, 1))
				v_u_12:PlaySound(v_u_8.Hakari.EnergySurge.Hit2, v24, game.SoundService.Effect)
				if v_u_4 == p22 or v_u_4.Character == p23 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.Snap)
				end
			end
		end,
		["Swing"] = function(p27, p28)
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_3, (ref) v_u_2, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9
			local v29 = p27:FindFirstChild("HumanoidRootPart")
			if v29 then
				if v_u_4.Character == p27 then
					local v30 = v_u_7.Hakari.Barrage.ColorArm:Clone()
					v30.Color = Color3.fromRGB(255, 170, 255)
					v30.Attachment.Flames.Color = ColorSequence.new(Color3.fromRGB(255, 170, 255))
					local v31 = v29.CFrame * CFrame.new((p28 == 1 or p28 == 3) and 3 or -3, 1, 0)
					local v32 = CFrame.Angles
					local v33 = (p28 == 1 or p28 == 3) and 10 or -10
					v30.CFrame = v31 * v32(1.5707963267948966, math.rad(v33), 0)
					v_u_3:Create(v30, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Transparency"] = 1,
						["CFrame"] = v30.CFrame + v29.CFrame.LookVector * 12
					}):Play()
					v30.Parent = workspace.Effects
					v30.Attachment.Flames:Emit(7)
					v30.Attachment.Wind:Emit(2)
					local v34 = v_u_7.Gojo.LapseBlue.Throw:Clone()
					v34.CFrame = v29.CFrame - v29.Position + v30.Position + v29.CFrame.LookVector * 8
					v34.Size = Vector3.new(0, 0, 1)
					v34.Parent = v30
					v_u_3:Create(v34, TweenInfo.new(0.15), {
						["Size"] = Vector3.new(4, 4, 0),
						["Transparency"] = 1
					}):Play()
					v_u_2:AddItem(v30, 0.2)
				end
				if p28 == 3 then
					local v35 = v_u_7.Itadori.DivergentFist.BlackFlashLaunch:Clone()
					v35.CFrame = v29.CFrame * CFrame.new(2, 1, -5)
					v35.Parent = workspace.Effects
					v35.Wind:Emit(20)
					v35.PointLight:Destroy()
					v35.Back1.Back:Emit(1)
					v35.Back2.Back:Emit(1)
					v_u_3:Create(v35.Back1, TweenInfo.new(2), {
						["CFrame"] = v35.Back1.CFrame - v35.Back1.CFrame.LookVector * 20
					}):Play()
					v_u_3:Create(v35.Back2, TweenInfo.new(2), {
						["CFrame"] = v35.Back2.CFrame - v35.Back2.CFrame.LookVector * 20
					}):Play()
					v_u_2:AddItem(v35, 3)
				end
				v_u_12:PlaySound(v_u_8.Hakari.EnergySurge.Swing, v29, game.SoundService.Effect)
				if v_u_4.Character == p27 then
					v_u_9.CurrentShaker:Shake(v_u_9.Presets.LightHit)
				end
			end
		end
	}
	v_u_10.Effects:Connect(function(p37, ...)
		-- upvalues: (copy) v_u_36
		local v38 = v_u_36[p37]
		if v38 then
			v38(...)
		end
	end)
end
function v13.KnitInit(_)
	-- upvalues: (ref) v_u_10, (copy) v_u_1, (ref) v_u_11, (ref) v_u_12
	v_u_10 = v_u_1.GetService("DreamsService")
	v_u_11 = v_u_1.GetController("HitboxController")
	v_u_12 = v_u_1.GetController("FXController")
end
return v13