-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = require(game.ReplicatedStorage.Knit.Knit)
game:GetService("UserInputService")
game:GetService("RunService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game.Players.LocalPlayer
local v5 = game.ReplicatedStorage
local _ = v5.Animations
local v_u_6 = v5.Utils
local v_u_7 = v5.Sounds
local v_u_8 = require(v5.Modules.CameraShaker)
local v_u_9 = nil
local v_u_10 = nil
local v11 = v_u_1.CreateController({
	["Name"] = "CrusshJawController"
})
function v11.KnitStart(_)
	-- upvalues: (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (ref) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (ref) v_u_9
	local v_u_31 = {
		["Crush"] = function(p12, p13)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v14 = v_u_6.Itadori.CrushingBlow:Clone()
			v14.Position = p13
			v14.Parent = workspace.Effects
			v_u_3:Create(v14.Air, TweenInfo.new(0.2), {
				["Position"] = Vector3.new(0, 0, 0)
			}):Play()
			v_u_3:Create(v14.PointLight, TweenInfo.new(0.6), {
				["Brightness"] = 0
			}):Play()
			v14.Flames:Emit(20)
			v14.Floor.Glow:Emit(1)
			v14.Floor.Ring:Emit(10)
			v14.Floor.Sparks:Emit(10)
			v14.Floor.Wind2:Emit(8)
			v_u_2:AddItem(v14, 1.5)
			v_u_10:PlaySound(v_u_7.Itadori.CrushingBlow.GroundImpact, v14, game.SoundService.Effect)
			if v_u_4 == p12 then
				v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
			end
		end,
		["Chomp"] = function(p15, p16)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v17 = p15:FindFirstChild("HumanoidRootPart")
			if v17 then
				v_u_10:PlaySound(v_u_7.Locust.Chomp["Bite" .. p16], v17, game.SoundService.Effect)
				if v_u_4.Character == p15 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Bite"] = function(p18)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v19 = p18:FindFirstChild("HumanoidRootPart")
			if v19 then
				v_u_10:Flash(p18, Color3.fromRGB(255, 255, 255))
				v_u_10:PlaySound(v_u_7.Locust.Chomp.Hit, v19, game.SoundService.Effect)
				if v_u_4.Character == p18 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.HeavyHit)
				end
			end
		end,
		["Hit"] = function(p20)
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v21 = p20:FindFirstChild("HumanoidRootPart")
			if v21 then
				v_u_10:Flash(p20, Color3.new(1, 1, 1))
				v_u_10:PlaySound(v_u_7.Itadori.CrushingBlow.Hit1, v21, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Itadori.CrushingBlow.Hit2, v21, game.SoundService.Effect)
				if v_u_4.Character == p20 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
			end
		end,
		["Dash"] = function(p22)
			-- upvalues: (ref) v_u_6, (ref) v_u_3, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v23 = p22:FindFirstChild("HumanoidRootPart")
			if v23 then
				local v24 = v_u_6.Locust.MucusFire:Clone()
				v24.CFrame = v23.CFrame * CFrame.new(0, 0, -5)
				v24.Parent = workspace.Effects
				v24.Wind:Emit(20)
				v24.Back1.Back:Emit(1)
				v24.Back2.Back:Emit(1)
				v_u_3:Create(v24.Back1, TweenInfo.new(2), {
					["CFrame"] = v24.Back1.CFrame - v24.Back1.CFrame.LookVector * 10
				}):Play()
				v_u_3:Create(v24.Back2, TweenInfo.new(2), {
					["CFrame"] = v24.Back2.CFrame - v24.Back2.CFrame.LookVector * 10
				}):Play()
				v_u_2:AddItem(v24, 2)
				v_u_10:PlaySound(v_u_7.Locust.Chomp.Dash, v23, game.SoundService.Effect)
				if v_u_4.Character == p22 then
					v_u_8.CurrentShaker:Shake(v_u_8.Presets.LightHit)
				end
				for _ = 1, 5 do
					local v_u_25 = v_u_6.Mahito.BodyRepel["Wind" .. math.random(1, 5)]:Clone()
					local v26 = v23.CFrame
					local v27 = CFrame.Angles
					local v28 = math.random(0, 360)
					v_u_25.CFrame = v26 * v27(1.5707963267948966, math.rad(v28), 0)
					v_u_25.Transparency = 0.5
					v_u_25.Size = Vector3.new(6, 6, 6)
					v_u_3:Create(v_u_25, TweenInfo.new(0.3, Enum.EasingStyle.Quad), {
						["CFrame"] = v_u_25.CFrame + v23.CFrame.LookVector * 3,
						["Size"] = Vector3.new(7, 0, 7)
					}):Play()
					v_u_2:AddItem(v_u_25, 0.3)
					v_u_25.Parent = workspace.Effects
					v_u_3:Create(v_u_25, TweenInfo.new(0.15), {
						["Transparency"] = 0.5
					}):Play()
					task.delay(0.15, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_25
						v_u_3:Create(v_u_25, TweenInfo.new(0.15), {
							["Transparency"] = 1
						}):Play()
					end)
					task.wait(0.06)
				end
			end
		end,
		["Leap"] = function(p29)
			-- upvalues: (ref) v_u_10, (ref) v_u_7
			local v30 = p29:FindFirstChild("HumanoidRootPart")
			if v30 then
				v_u_10:PlaySound(v_u_7.Locust.Chomp.Throw, v30, game.SoundService.Effect)
				v_u_10:PlaySound(v_u_7.Locust.Chomp.Slam, v30, game.SoundService.Effect)
			end
		end
	}
	v_u_9.Effects:Connect(function(p32, ...)
		-- upvalues: (copy) v_u_31
		local v33 = v_u_31[p32]
		if v33 then
			v33(...)
		end
	end)
end
function v11.KnitInit(_)
	-- upvalues: (ref) v_u_9, (copy) v_u_1, (ref) v_u_10
	v_u_9 = v_u_1.GetService("CrushJawService")
	v_u_10 = v_u_1.GetController("FXController")
end
return v11